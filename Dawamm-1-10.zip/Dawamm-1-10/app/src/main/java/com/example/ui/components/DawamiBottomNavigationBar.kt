package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

enum class MainBottomTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val targetScreen: Screen
) {
    HOME(
        title = "الرئيسية",
        selectedIcon = Icons.Filled.Dashboard,
        unselectedIcon = Icons.Outlined.Dashboard,
        targetScreen = Screen.Selection
    ),
    TRAINER(
        title = "المدرب",
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person,
        targetScreen = Screen.TrainerGroup
    ),
    STUDENTS(
        title = "الطالب",
        selectedIcon = Icons.Filled.Group,
        unselectedIcon = Icons.Outlined.Group,
        targetScreen = Screen.StudentsGroup
    ),
    REPORTS(
        title = "التقارير",
        selectedIcon = Icons.Filled.Assessment,
        unselectedIcon = Icons.Outlined.Assessment,
        targetScreen = Screen.ReportsGroup
    );

    companion object {
        fun fromScreen(screen: Screen): MainBottomTab? {
            return when (screen) {
                is Screen.Selection -> HOME
                is Screen.TrainerGroup, is Screen.Courses, is Screen.Attendance,
                is Screen.TrainerFinances, is Screen.Subjects, is Screen.LessonPreparation,
                is Screen.AssignmentSetup, is Screen.SubjectReferences, is Screen.CurriculumGroup -> TRAINER
                is Screen.StudentsGroup, is Screen.StudentAttendance, is Screen.Students,
                is Screen.Grades, is Screen.TheoryExamGrader, is Screen.StudentViolations,
                is Screen.CourseAttendanceAnalytics -> STUDENTS
                is Screen.ReportsGroup, is Screen.Reports, is Screen.StudentReports,
                is Screen.GradeReports, is Screen.TeachingStats -> REPORTS
                else -> null
            }
        }
    }
}

/**
 * Modern, adaptive bottom navigation bar designed for "دوامي الذكي".
 * - Fully RTL compliant
 * - 48dp minimum interactive touch targets
 * - Generous spacing, no text clipping
 * - Light and Dark theme supported
 * - Matches current theme tokens (DawamiNavy, DawamiGold, DawamiTeal)
 */
@Composable
fun DawamiBottomNavigationBar(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val activeTab = MainBottomTab.fromScreen(currentScreen)

    // Ensure strict RTL layout flow
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(
            modifier = modifier
                .fillMaxWidth()
                .navigationBarsPadding(),
            color = if (isDarkTheme) Color(0xFF0F172A) else Color.White,
            tonalElevation = 6.dp,
            shadowElevation = 8.dp,
            border = androidx.compose.foundation.BorderStroke(
                width = 1.dp,
                color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFE2E8F0)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 60.dp)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                MainBottomTab.values().forEach { tab ->
                    val isSelected = (activeTab == tab)

                    val animatedBgColor by animateColorAsState(
                        targetValue = if (isSelected) {
                            if (isDarkTheme) DawamiNavy.copy(alpha = 0.35f) else DawamiNavy.copy(alpha = 0.10f)
                        } else Color.Transparent,
                        animationSpec = tween(220),
                        label = "tab_bg_${tab.name}"
                    )

                    val animatedContentColor by animateColorAsState(
                        targetValue = if (isSelected) {
                            if (isDarkTheme) DawamiGold else DawamiNavy
                        } else {
                            if (isDarkTheme) Color(0xFF94A3B8) else Color(0xFF64748B)
                        },
                        animationSpec = tween(220),
                        label = "tab_content_${tab.name}"
                    )

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(animatedBgColor)
                            .clickable {
                                if (currentScreen != tab.targetScreen) {
                                    viewModel.navigateTo(tab.targetScreen)
                                }
                            }
                            .padding(vertical = 4.dp, horizontal = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title,
                                tint = animatedContentColor,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = tab.title,
                                color = animatedContentColor,
                                fontSize = 11.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
