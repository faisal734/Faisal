package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.database.AppDatabase
import com.example.utils.AudioPlayerHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val courseId = intent.getIntExtra("course_id", -1)
        val courseName = intent.getStringExtra("course_name") ?: ""
        val type = intent.getStringExtra("type") ?: if (intent.hasExtra("message") && !intent.getStringExtra("message").isNullOrEmpty()) "custom" else "trainer_start"
        val titleInput = intent.getStringExtra("title") ?: "تنبيه دوامي ⏰"
        val messageInput = intent.getStringExtra("message") ?: ""
        val explicitVoiceGender = intent.getStringExtra("voice_gender")

        val sharedPrefs = context.getSharedPreferences("dawami_prefs", Context.MODE_PRIVATE)
        val isSmartEnabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
        if (!isSmartEnabled && type != "test") return

        // Check day of week rules (Friday strictly blocked, Thursday customizable)
        val calendar = java.util.Calendar.getInstance()
        val dayOfWeek = calendar.get(java.util.Calendar.DAY_OF_WEEK)

        if (type != "custom" && type != "test") {
            // 1. Friday: strictly blocked
            if (dayOfWeek == java.util.Calendar.FRIDAY) {
                return
            }

            // 2. Thursday: check if Thursday notifications are enabled by user
            if (dayOfWeek == java.util.Calendar.THURSDAY) {
                val isThursdayEnabled = sharedPrefs.getBoolean("is_thursday_notifications_enabled", false)
                if (!isThursdayEnabled) {
                    return
                }
            }
        }

        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        val wakeLock = powerManager?.newWakeLock(
            android.os.PowerManager.PARTIAL_WAKE_LOCK,
            "Dawami:AlarmNotificationWakeLock"
        )?.apply {
            setReferenceCounted(false)
            acquire(60 * 1000L)
        }
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context)

                // 3. Official Holidays check: strictly blocked like Friday
                if (type != "custom" && type != "test") {
                    val enabledHolidays = db.officialHolidayDao().getEnabledHolidaysSync()
                    val isHoliday = enabledHolidays.any { it.isEnabled && it.startDate.isNotBlank() && it.endDate.isNotBlank() && currentDate >= it.startDate && currentDate <= it.endDate }
                    if (isHoliday) {
                        return@launch
                    }
                }

                // Check if course is valid and active (not completed and not expired)
                if (type != "custom" && type != "test" && courseId > 0) {
                    val course = db.courseDao().getCourseById(courseId)
                    val isCourseEnded = course == null || course.isCompleted || (course.endDate.isNotBlank() && course.endDate < currentDate)
                    if (isCourseEnded) {
                        NotificationHelper.cancelCourseReminders(context, courseId)
                        return@launch
                    }
                }

                var speakMessage = messageInput
                var shouldShowNotification = true

                when (type) {
                    "custom", "test" -> {
                        shouldShowNotification = true
                        if (speakMessage.isEmpty()) {
                            speakMessage = "تنبيه اختبار تجريبي من تطبيق دوامي"
                        }
                    }
                    "trainer_start", "trainer_start_15m", "trainer_start_10m", "trainer_start_5m" -> {
                        val isEnabled = sharedPrefs.getBoolean("is_trainer_start_reminder_enabled", true)
                        if (!isEnabled) {
                            shouldShowNotification = false
                        } else {
                            val customPattern = sharedPrefs.getString("trainer_start_reminder_text", "الرجاء الاستعداد للدورة، باقي من الوقت [mins] دقيقة") ?: "الرجاء الاستعداد للدورة، باقي من الوقت [mins] دقيقة"
                            val minsStr = when (type) {
                                "trainer_start_15m" -> "15"
                                "trainer_start_10m" -> "10"
                                "trainer_start_5m" -> "5"
                                else -> sharedPrefs.getInt("trainer_reminder_minutes", 15).toString()
                            }
                            speakMessage = customPattern.replace("[course]", courseName).replace("[mins]", minsStr)
                        }
                    }
                    "trainer_checkin", "trainer_checkin_1m", "trainer_checkin_5m", "trainer_checkin_10m", "trainer_checkin_30m", "trainer_checkin_60m", "smart_checkup_10m", "smart_checkup_60m" -> {
                        val isEnabled = sharedPrefs.getBoolean("is_trainer_check_in_reminder_enabled", true)
                        if (!isEnabled) {
                            shouldShowNotification = false
                        } else {
                            val attendance = db.attendanceDao().getAttendanceByCourseAndDateSync(courseId, currentDate)
                            if (attendance != null && attendance.actualCheckIn.isNotEmpty()) {
                                shouldShowNotification = false // Automatically stop if movement already recorded!
                            } else {
                                val customText = sharedPrefs.getString("trainer_check_in_prompt_text", "الرجاء تحضير نفسك في حافظة الدوام") ?: "الرجاء تحضير نفسك في حافظة الدوام"
                                speakMessage = when (type) {
                                    "trainer_checkin_5m" -> "تذكير (بعد 5 دقائق): $customText".replace("[course]", courseName)
                                    "trainer_checkin_10m" -> "تذكير (بعد 10 دقائق): $customText".replace("[course]", courseName)
                                    "trainer_checkin_30m" -> "تذكير هامة (بعد 30 دقيقة): لم يتم تسجيل تحضير المدرب في دورة [course]".replace("[course]", courseName)
                                    "trainer_checkin_60m" -> "تذكير متأخر (بعد ساعة): لم يتم تسجيل تحضير المدرب في دورة [course]".replace("[course]", courseName)
                                    else -> customText.replace("[course]", courseName)
                                }
                            }
                        }
                    }
                    "trainer_checkout", "trainer_checkout_5m", "trainer_checkout_10m", "trainer_checkout_30m", "trainer_checkout_60m" -> {
                        val isEnabled = sharedPrefs.getBoolean("is_trainer_check_out_reminder_enabled", true)
                        if (!isEnabled) {
                            shouldShowNotification = false
                        } else {
                            val attendance = db.attendanceDao().getAttendanceByCourseAndDateSync(courseId, currentDate)
                            if (attendance != null && attendance.actualCheckOut.isNotEmpty()) {
                                shouldShowNotification = false // Automatically stop if movement already recorded!
                            } else {
                                val customText = sharedPrefs.getString("trainer_check_out_prompt_text", "الرجاء انصرافك وتسجيل خروجك من حافظة الدوام") ?: "الرجاء انصرافك وتسجيل خروجك من حافظة الدوام"
                                speakMessage = when (type) {
                                    "trainer_checkout_5m" -> "تذكير انصراف (بعد 5 دقائق): $customText".replace("[course]", courseName)
                                    "trainer_checkout_10m" -> "تذكير انصراف (بعد 10 دقائق): $customText".replace("[course]", courseName)
                                    "trainer_checkout_30m" -> "تذكير انصراف (بعد 30 دقيقة): لم يتم تسجيل انصراف المدرب في دورة [course]".replace("[course]", courseName)
                                    "trainer_checkout_60m" -> "تذكير انصراف متأخر (بعد ساعة): لم يتم تسجيل انصراف المدرب في دورة [course]".replace("[course]", courseName)
                                    else -> customText.replace("[course]", courseName)
                                }
                            }
                        }
                    }
                    "student_checkin", "student_checkin_5m", "student_checkin_10m", "student_checkin_30m", "student_checkin_60m" -> {
                        val isRemindEnabled = sharedPrefs.getBoolean("is_student_check_in_reminder_enabled", true)
                        val isSuccessEnabled = sharedPrefs.getBoolean("is_student_check_in_success_enabled", true)

                        val attendance = db.attendanceDao().getAttendanceByCourseAndDateSync(courseId, currentDate)
                        val isTrainerCheckedIn = attendance != null && attendance.actualCheckIn.isNotEmpty()

                        if (!isTrainerCheckedIn) {
                            // Don't alert students unless trainer checked in first!
                            shouldShowNotification = false
                        } else {
                            val studentAttList = db.studentAttendanceDao().getStudentAttendanceByCourseAndDateSync(courseId, currentDate)
                            val isAttendanceComplete = studentAttList.isNotEmpty() && studentAttList.none { it.status == "لم يسجل" }

                            if (isAttendanceComplete) {
                                if (isSuccessEnabled && type == "student_checkin") {
                                    val customSuccessText = sharedPrefs.getString("student_check_in_success_text", "لقد تم تحضير الطلاب بنجاح شكرا لك") ?: "لقد تم تحضير الطلاب بنجاح شكرا لك"
                                    speakMessage = customSuccessText.replace("[course]", courseName)
                                } else {
                                    shouldShowNotification = false
                                }
                            } else {
                                if (isRemindEnabled) {
                                    val customText = sharedPrefs.getString("student_check_in_remind_text", "أستاذ فيصل الرجاء تحضير الطلاب") ?: "أستاذ فيصل الرجاء تحضير الطلاب"
                                    speakMessage = when (type) {
                                        "student_checkin_5m" -> "تذكير تحضير الطلاب (بعد 5 دقائق): $customText".replace("[course]", courseName)
                                        "student_checkin_10m" -> "تذكير تحضير الطلاب (بعد 10 دقائق): $customText".replace("[course]", courseName)
                                        "student_checkin_30m" -> "تذكير (بعد 30 دقيقة): لم يكتمل تحضير الطلاب في دورة [course]".replace("[course]", courseName)
                                        "student_checkin_60m" -> "تذكير متأخر (بعد ساعة): لم يكتمل تحضير الطلاب في دورة [course]".replace("[course]", courseName)
                                        else -> customText.replace("[course]", courseName)
                                    }
                                } else {
                                    shouldShowNotification = false
                                }
                            }
                        }
                    }
                    "student_checkout", "student_checkout_5m", "student_checkout_10m", "student_checkout_30m", "student_checkout_60m" -> {
                        val isRemindEnabled = sharedPrefs.getBoolean("is_student_check_out_reminder_enabled", true)
                        val isSuccessEnabled = sharedPrefs.getBoolean("is_student_check_out_success_enabled", true)

                        val attendance = db.attendanceDao().getAttendanceByCourseAndDateSync(courseId, currentDate)
                        val isTrainerCheckedOut = attendance != null && attendance.actualCheckOut.isNotEmpty()

                        if (!isTrainerCheckedOut) {
                            // Don't alert student checkout unless trainer checked out first!
                            shouldShowNotification = false
                        } else {
                            val studentAttList = db.studentAttendanceDao().getStudentAttendanceByCourseAndDateSync(courseId, currentDate)
                            val isCheckoutComplete = studentAttList.isNotEmpty() && studentAttList.none { it.status == "حضور" && it.actualCheckOut.isEmpty() }

                            if (isCheckoutComplete) {
                                if (isSuccessEnabled && type == "student_checkout") {
                                    val customSuccessText = sharedPrefs.getString("student_check_out_success_text", "تم تسجيل انصراف الطلاب بنجاح") ?: "تم تسجيل انصراف الطلاب بنجاح"
                                    speakMessage = customSuccessText.replace("[course]", courseName)
                                } else {
                                    shouldShowNotification = false
                                }
                            } else {
                                if (isRemindEnabled) {
                                    val customText = sharedPrefs.getString("student_check_out_remind_text", "أستاذ فيصل الرجاء تحضير انصراف الطلاب") ?: "أستاذ فيصل الرجاء تحضير انصراف الطلاب"
                                    speakMessage = when (type) {
                                        "student_checkout_5m" -> "تذكير انصراف الطلاب (بعد 5 دقائق): $customText".replace("[course]", courseName)
                                        "student_checkout_10m" -> "تذكير انصراف الطلاب (بعد 10 دقائق): $customText".replace("[course]", courseName)
                                        "student_checkout_30m" -> "تذكير (بعد 30 دقيقة): لم يكتمل انصراف الطلاب في دورة [course]".replace("[course]", courseName)
                                        "student_checkout_60m" -> "تذكير متأخر (بعد ساعة): لم يكتمل انصراف الطلاب في دورة [course]".replace("[course]", courseName)
                                        else -> customText.replace("[course]", courseName)
                                    }
                                } else {
                                    shouldShowNotification = false
                                }
                            }
                        }
                    }
                }

                if (shouldShowNotification && type != "test") {
                    val now = System.currentTimeMillis()
                    val lastFiredKey = "last_fired_${courseId}_${type}"
                    val lastFiredTime = sharedPrefs.getLong(lastFiredKey, 0L)
                    if (type != "custom" && now - lastFiredTime < 2 * 60 * 1000L) {
                        shouldShowNotification = false
                    } else if (speakMessage.isNotEmpty() && speakMessage == lastSpokenMessage && now - lastSpokenTime < 3000L) {
                        shouldShowNotification = false
                    } else {
                        lastSpokenMessage = speakMessage
                        lastSpokenTime = now
                        sharedPrefs.edit().putLong(lastFiredKey, now).apply()
                    }
                }

                if (shouldShowNotification) {
                    val targetVoiceGender = explicitVoiceGender ?: sharedPrefs.getString("voice_gender", "female") ?: "female"
                    showNotification(context, titleInput, speakMessage)

                    val rawSoundName = when (type) {
                        "trainer_start" -> {
                            val trainerMins = sharedPrefs.getInt("trainer_reminder_minutes", 15)
                            when (trainerMins) {
                                15 -> "precourse_15min"
                                10 -> "precourse_10min"
                                5 -> "precourse_5min"
                                else -> "precourse_15min"
                            }
                        }
                        "trainer_start_15m" -> "precourse_15min"
                        "trainer_start_10m" -> "precourse_10min"
                        "trainer_start_5m" -> "precourse_5min"
                        "trainer_checkin", "trainer_checkin_1m", "trainer_checkin_5m", "trainer_checkin_10m", "trainer_checkin_30m", "trainer_checkin_60m", "smart_checkup_10m", "smart_checkup_60m" -> "trainer_checkin_prompt"
                        "student_checkin", "student_checkin_5m", "student_checkin_10m", "student_checkin_30m", "student_checkin_60m" -> "student_checkin_prompt"
                        "trainer_checkout", "trainer_checkout_5m", "trainer_checkout_10m", "trainer_checkout_30m", "trainer_checkout_60m" -> "trainer_checkout_prompt"
                        "student_checkout", "student_checkout_5m", "student_checkout_10m", "student_checkout_30m", "student_checkout_60m" -> "student_checkout_prompt"
                        "trainer_checkin_success" -> "trainer_checkin_success"
                        "student_checkin_success" -> "student_checkin_success"
                        "trainer_checkout_success" -> "trainer_checkout_success"
                        "student_checkout_success" -> "student_checkout_success"
                        else -> null
                    }

                    playRawAudioOrFallback(context, rawSoundName, speakMessage, targetVoiceGender)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                try {
                    val sharedPrefs = context.getSharedPreferences("dawami_prefs", Context.MODE_PRIVATE)
                    val trainerMins = sharedPrefs.getInt("trainer_reminder_minutes", 15)
                    val checkInMins = sharedPrefs.getInt("student_check_in_reminder_minutes", 10)
                    val checkOutMins = sharedPrefs.getInt("student_check_out_reminder_minutes", 10)
                    val dbInstance = AppDatabase.getDatabase(context)
                    val course = if (courseId > 0) dbInstance.courseDao().getCourseById(courseId) else null
                    if (course != null && !course.isCompleted && (course.endDate.isBlank() || course.endDate >= currentDate)) {
                        // Only reschedule next cycle after checkout alarms or end of lecture so pre-course alarms are not canceled
                        if (type.contains("checkout")) {
                            NotificationHelper.scheduleCourseReminders(context, course, trainerMins, checkInMins, checkOutMins)
                        }
                    } else if (courseId > 0 && course?.isCompleted == true) {
                        NotificationHelper.cancelCourseReminders(context, courseId)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    try {
                        if (wakeLock?.isHeld == true) {
                            wakeLock.release()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    try {
                        pendingResult.finish()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    private fun showNotification(context: Context, title: String, message: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val sharedPrefs = context.getSharedPreferences("dawami_prefs", Context.MODE_PRIVATE)
        val soundName = sharedPrefs.getString("notification_sound", "الافتراضي 🔔") ?: "الافتراضي 🔔"

        val soundUri = getSoundUri(context, soundName)
        val channelId = "dawami_alarm_clock_channel_${soundName.hashCode()}"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "منبه دوامي الذكي (أولوية قصوى)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قناة منبه الساعة العاجلة لحافظة الدوام - تخترق الصامت وعدم الإزعاج"
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 600, 200, 600, 200, 600)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                setBypassDnd(true)
                val audioAttributes = AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .build()
                setSound(soundUri, audioAttributes)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            (System.currentTimeMillis() % 10000).toInt(),
            mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            (System.currentTimeMillis() % 10000).toInt() + 1,
            mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setSound(soundUri, android.media.AudioManager.STREAM_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(pendingIntent)

        val notificationId = (System.currentTimeMillis() % 100000).toInt()
        notificationManager.notify(notificationId, builder.build())
    }

    private suspend fun playRawAudioOrFallback(context: Context, rawName: String?, fallbackText: String, voiceGender: String) {
        if (!rawName.isNullOrEmpty()) {
            try {
                val resId = AudioPlayerHelper.getRawResourceId(context, rawName)
                if (resId != 0) {
                    val afd = context.resources.openRawResourceFd(resId)
                    if (afd != null && afd.length > 100L) {
                        val deferred = kotlinx.coroutines.CompletableDeferred<Unit>()
                        val mediaPlayer = android.media.MediaPlayer().apply {
                            setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ALARM)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build()
                            )
                            setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                            afd.close()
                            prepare()
                            start()
                        }
                        mediaPlayer.setOnCompletionListener { mp ->
                            try { mp.release() } catch (_: Exception) {}
                            deferred.complete(Unit)
                        }
                        mediaPlayer.setOnErrorListener { mp, _, _ ->
                            try { mp.release() } catch (_: Exception) {}
                            deferred.complete(Unit)
                            true
                        }
                        try {
                            kotlinx.coroutines.withTimeoutOrNull(12000L) {
                                deferred.await()
                            }
                        } catch (_: Exception) {}
                        return
                    } else {
                        afd?.close()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        speakText(context, fallbackText, voiceGender)
    }

    private suspend fun speakText(context: Context, text: String, voiceGender: String) {
        val deferred = kotlinx.coroutines.CompletableDeferred<Unit>()
        
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        mainHandler.post {
            var tts: TextToSpeech? = null
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.let { ttsEngine ->
                        val locale = Locale("ar")
                        if (ttsEngine.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE) {
                            ttsEngine.language = locale
                        }

                        when (voiceGender.lowercase()) {
                            "female" -> {
                                ttsEngine.setPitch(1.48f)
                                ttsEngine.setSpeechRate(1.05f)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    try {
                                        val arabicVoices = ttsEngine.voices?.filter { it.locale.language == "ar" } ?: emptyList()
                                        val femaleVoice = arabicVoices.find { v ->
                                            val name = v.name.lowercase()
                                            name.contains("female") || name.contains("ard") || name.contains("woman") ||
                                            name.contains("f0") || name.contains("f1") ||
                                            (v.features?.any { it.contains("female", ignoreCase = true) } == true)
                                        }
                                        if (femaleVoice != null) {
                                            ttsEngine.voice = femaleVoice
                                        }
                                    } catch (_: Exception) {}
                                }
                            }
                            "male" -> {
                                ttsEngine.setPitch(0.68f)
                                ttsEngine.setSpeechRate(0.92f)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    try {
                                        val arabicVoices = ttsEngine.voices?.filter { it.locale.language == "ar" } ?: emptyList()
                                        val maleVoice = arabicVoices.find { v ->
                                            val name = v.name.lowercase()
                                            name.contains("male") || name.contains("arc") || name.contains("arb") ||
                                            name.contains("man") || name.contains("m0") ||
                                            (v.features?.any { it.contains("male", ignoreCase = true) } == true)
                                        }
                                        if (maleVoice != null) {
                                            ttsEngine.voice = maleVoice
                                        }
                                    } catch (_: Exception) {}
                                }
                            }
                            else -> {
                                ttsEngine.setPitch(1.0f)
                                ttsEngine.setSpeechRate(1.0f)
                            }
                        }

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            val audioAttributes = AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ALARM)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build()
                            ttsEngine.setAudioAttributes(audioAttributes)
                        }

                        val params = Bundle().apply {
                            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
                            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_ALARM)
                        }

                        ttsEngine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) {
                                try { ttsEngine.shutdown() } catch (_: Exception) {}
                                deferred.complete(Unit)
                            }
                            override fun onError(utteranceId: String?) {
                                try { ttsEngine.shutdown() } catch (_: Exception) {}
                                deferred.complete(Unit)
                            }
                        })

                        val result = ttsEngine.speak(text, TextToSpeech.QUEUE_FLUSH, params, "dawami_tts_id")
                        if (result != TextToSpeech.SUCCESS) {
                            try { ttsEngine.shutdown() } catch (_: Exception) {}
                            deferred.complete(Unit)
                        }
                    } ?: deferred.complete(Unit)
                } else {
                    try { tts?.shutdown() } catch (_: Exception) {}
                    deferred.complete(Unit)
                }
            }
        }

        try {
            kotlinx.coroutines.withTimeoutOrNull(8000L) {
                deferred.await()
            }
        } catch (_: Exception) {}
    }

    companion object {
        @Volatile
        private var lastSpokenMessage: String? = null
        @Volatile
        private var lastSpokenTime: Long = 0L

        fun getSoundUri(context: Context, soundName: String): android.net.Uri {
            return when {
                soundName.contains("رنين كلاسيكي") -> {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                }
                soundName.contains("تنبيه رقمي") -> {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                }
                soundName.contains("جرس ذكي") -> {
                    getSystemSoundUri(context, 1) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                }
                soundName.contains("رادار لطيف") -> {
                    getSystemSoundUri(context, 2) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                }
                else -> {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                }
            }
        }

        private fun getSystemSoundUri(context: Context, index: Int): android.net.Uri? {
            return try {
                val manager = RingtoneManager(context).apply {
                    setType(RingtoneManager.TYPE_NOTIFICATION)
                }
                val cursor = manager.cursor
                if (cursor != null && cursor.moveToPosition(index)) {
                    manager.getRingtoneUri(index)
                } else {
                    null
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}
