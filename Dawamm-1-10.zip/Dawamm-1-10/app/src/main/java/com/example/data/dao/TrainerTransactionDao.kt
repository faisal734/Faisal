package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.TrainerTransaction
import kotlinx.coroutines.flow.Flow

@Dao
interface TrainerTransactionDao {
    @Query("SELECT * FROM trainer_transactions ORDER BY date DESC, id DESC")
    fun getAllTransactions(): Flow<List<TrainerTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TrainerTransaction): Long

    @Update
    suspend fun updateTransaction(transaction: TrainerTransaction)

    @Delete
    suspend fun deleteTransaction(transaction: TrainerTransaction)

    @Query("DELETE FROM trainer_transactions")
    suspend fun deleteAll()

    @Query("UPDATE trainer_transactions SET courseName = :newName WHERE courseId = :courseId")
    suspend fun updateCourseName(courseId: Int, newName: String)
}
