package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.ThemePreset
import com.example.ui.theme.ThemePresetsCatalog
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeStudioDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val currentThemeId by viewModel.selectedThemeId.collectAsState()
    val allPresets = remember { ThemePresetsCatalog.presets }
    
    val activePreset = remember(currentThemeId) {
        ThemePresetsCatalog.getById(currentThemeId)
    }

    var previewPreset by remember { mutableStateOf<ThemePreset?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(24.dp)),
            color = if (activePreset.isDark) activePreset.surface else Color.White,
            tonalElevation = 8.dp,
            shadowElevation = 16.dp
        ) {
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val isCompact = maxWidth < 600.dp
                val columns = if (isCompact) GridCells.Fixed(2) else GridCells.Fixed(3)

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(activePreset.primary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Palette,
                                    contentDescription = null,
                                    tint = activePreset.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = "🎨 الثيمات",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = activePreset.onSurface
                                )
                                Text(
                                    text = "اختر المظهر المفضل لهوية تطبيق دوامي",
                                    fontSize = 11.sp,
                                    color = activePreset.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(activePreset.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = activePreset.onSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Themes Grid List
                    LazyVerticalGrid(
                        columns = columns,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 12.dp)
                    ) {
                        items(allPresets, key = { it.id }) { preset ->
                            val isSelected = preset.id == currentThemeId

                            ThemeThumbnailCard(
                                preset = preset,
                                isSelected = isSelected,
                                onSelect = {
                                    viewModel.selectTheme(preset.id)
                                },
                                onPreviewClick = {
                                    previewPreset = preset
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Confirm Bar
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = activePreset.surfaceVariant.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, activePreset.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "المظهر الحالي: ${activePreset.name}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = activePreset.onSurface
                                )
                                Text(
                                    text = if (activePreset.isDark) "مظهر ليلي مريح للعين 🌙" else "مظهر نهاري ناصع ومشرق ☀️",
                                    fontSize = 11.sp,
                                    color = activePreset.onSurfaceVariant
                                )
                            }

                            Button(
                                onClick = onDismiss,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = activePreset.primary,
                                    contentColor = activePreset.onPrimary
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تم الاعتماد", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // Comprehensive Interactive Preview Modal Dialog
    if (previewPreset != null) {
        LargePreviewModal(
            preset = previewPreset!!,
            activePreset = activePreset,
            onDismiss = { previewPreset = null },
            onApply = {
                viewModel.selectTheme(previewPreset!!.id)
                previewPreset = null
            }
        )
    }
}

/**
 * Visual Mini Canvas Mockup of the App matching the user requested specifications.
 */
@Composable
fun ThemeThumbnailCard(
    preset: ThemePreset,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onPreviewClick: () -> Unit
) {
    val borderColor by animateColorAsState(
        if (isSelected) Color(0xFFF59E0B) else preset.outline.copy(alpha = 0.7f),
        label = "borderColor"
    )
    val borderWidth = if (isSelected) 2.5.dp else 1.dp

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(borderWidth, borderColor, RoundedCornerShape(18.dp))
            .background(if (preset.isDark) preset.surface else Color.White)
            .clickable(onClick = onSelect)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Real-feeling background representation
        val backgroundModifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(0.7.dp, preset.outline.copy(alpha = 0.5f), RoundedCornerShape(12.dp))

        Box(
            modifier = when (preset.id) {
                3 -> backgroundModifier.background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFFEC4899), Color(0xFF8B5CF6), Color(0xFF3B82F6))
                    )
                )
                4 -> backgroundModifier.background(Color(0xFF050B14))
                5 -> backgroundModifier.background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1E1B4B), Color(0xFF03001E))
                    )
                )
                7 -> backgroundModifier.background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFFFFF1F2), Color(0xFFFFE4E6))
                    )
                )
                8 -> backgroundModifier.background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0B132B), Color(0xFF1C2541))
                    )
                )
                9 -> backgroundModifier.background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFF1E1B4B), Color(0xFF312E81))
                    )
                )
                else -> backgroundModifier.background(preset.background)
            }.padding(6.dp)
        ) {
            if (preset.id == 4) {
                CyberMotherboardBackground(animate = false)
            }
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Mini Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(preset.surface.copy(alpha = 0.85f))
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "دوامي",
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Bold,
                        color = preset.primary
                    )
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(preset.primary, CircleShape)
                    )
                }

                // Mini Statistics & Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    listOf("حضور" to "24", "غياب" to "2").forEach { (lbl, valStr) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(preset.surface.copy(alpha = 0.9f))
                                .border(0.5.dp, preset.outline.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                .padding(vertical = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = valStr,
                                    fontSize = 7.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = preset.primary
                                )
                                Text(
                                    text = lbl,
                                    fontSize = 5.sp,
                                    color = preset.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Mini Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(14.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(preset.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "تسجيل الحضور",
                        fontSize = 6.sp,
                        fontWeight = FontWeight.Bold,
                        color = preset.onPrimary
                    )
                }

                // Mini Bottom Navigation
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(3.dp))
                        .background(preset.surface.copy(alpha = 0.85f))
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(3.dp).background(preset.primary, CircleShape))
                    Box(modifier = Modifier.size(3.dp).background(preset.outline, CircleShape))
                    Box(modifier = Modifier.size(3.dp).background(preset.outline, CircleShape))
                }
            }

            // Selection Checkmark Badge
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(2.dp)
                        .size(18.dp)
                        .background(Color(0xFFF59E0B), CircleShape)
                        .border(1.5.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "تم الاختيار",
                        tint = Color.White,
                        modifier = Modifier.size(10.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Title and Selection status
        Text(
            text = preset.name,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) preset.primary else preset.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isSelected) "✓ مستخدم حالياً" else preset.category,
                fontSize = 9.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color(0xFFF59E0B) else preset.onSurfaceVariant
            )

            // Preview Button inside the card
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(preset.primary.copy(alpha = 0.1f))
                    .clickable(onClick = onPreviewClick)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "معاينة 🔍",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = preset.primary
                )
            }
        }
    }
}

/**
 * Large, realistic full screen preview modal that displays how the theme matches the actual app screens.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LargePreviewModal(
    preset: ThemePreset,
    activePreset: ThemePreset,
    onDismiss: () -> Unit,
    onApply: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(24.dp)),
            color = if (activePreset.isDark) activePreset.surface else Color.White,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Top Header of the Modal
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "شاشة معاينة: ${preset.name}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = activePreset.onSurface
                        )
                        Text(
                            text = "هذه مجرد معاينة للشكل العام ولا يتم التطبيق إلا عند الضغط على اعتماد المظهر",
                            fontSize = 11.sp,
                            color = activePreset.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(activePreset.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = activePreset.onSurface,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Realistic Mock App Area representation
                val backgroundModifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, preset.outline, RoundedCornerShape(16.dp))

                Box(
                    modifier = when (preset.id) {
                        3 -> backgroundModifier.background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFFEC4899), Color(0xFF8B5CF6), Color(0xFF3B82F6))
                            )
                        )
                        4 -> backgroundModifier.background(Color(0xFF050B14))
                        5 -> backgroundModifier.background(
                            Brush.radialGradient(
                                colors = listOf(Color(0xFF1E1B4B), Color(0xFF03001E))
                            )
                        )
                        7 -> backgroundModifier.background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFFFFF1F2), Color(0xFFFFE4E6))
                            )
                        )
                        8 -> backgroundModifier.background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF0B132B), Color(0xFF1C2541))
                            )
                        )
                        9 -> backgroundModifier.background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF1E1B4B), Color(0xFF312E81))
                            )
                        )
                        else -> backgroundModifier.background(preset.background)
                    }.padding(12.dp)
                ) {
                    if (preset.id == 4) {
                        CyberMotherboardBackground(animate = false)
                    }
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // 1. Mock Header
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = preset.surface.copy(alpha = 0.9f),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, preset.outline.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(preset.primary.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "🎓",
                                            fontSize = 14.sp
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = "معهد ايلازون العالي للتدريب",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = preset.onSurface
                                        )
                                        Text(
                                            text = "نظام المتابعة الأكاديمية الذكي",
                                            fontSize = 8.sp,
                                            color = preset.onSurfaceVariant
                                        )
                                    }
                                }

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Notifications, null, tint = preset.primary, modifier = Modifier.size(16.dp))
                                    Icon(Icons.Default.Settings, null, tint = preset.onSurfaceVariant, modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        // 2. Mock Body Content Cards Scrollable Simulation
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(vertical = 10.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Statistics Cards
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("📊 نسبة الحضور" to "92%", "👥 الطلاب" to "23 طالب", "🏢 قاعات التدريب" to "4 قاعات").forEach { (lbl, valStr) ->
                                    Surface(
                                        modifier = Modifier.weight(1f),
                                        color = preset.surface.copy(alpha = 0.92f),
                                        shape = RoundedCornerShape(10.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, preset.outline.copy(alpha = 0.3f))
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(8.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(text = valStr, fontSize = 12.sp, fontWeight = FontWeight.Black, color = preset.primary)
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(text = lbl, fontSize = 8.sp, color = preset.onSurfaceVariant, textAlign = TextAlign.Center)
                                        }
                                    }
                                }
                            }

                            // Interactive Mock Student Row Card
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = preset.surface.copy(alpha = 0.95f),
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, preset.outline)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(CircleShape)
                                                    .background(preset.primary.copy(alpha = 0.1f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("أ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = preset.primary)
                                            }
                                            Column {
                                                Text("ابراهيم الهلالي", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = preset.onSurface)
                                                Text("دورة البرمجة بلغة Kotlin والمظهر الحديث", fontSize = 8.sp, color = preset.onSurfaceVariant)
                                            }
                                        }

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(preset.primary.copy(alpha = 0.15f))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text("حاضر ✓", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = preset.primary)
                                        }
                                    }
                                    
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Divider(color = preset.outline.copy(alpha = 0.3f))
                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("التفاعل والمشاركة اليومية:", fontSize = 8.5.sp, color = preset.onSurfaceVariant)
                                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                            repeat(5) {
                                                Text("⭐", fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            // Beautiful Call To Action Button
                            Button(
                                onClick = {},
                                modifier = Modifier.fillMaxWidth().height(38.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = preset.primary,
                                    contentColor = preset.onPrimary
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.TouchApp, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تسجيل حضور الدفعة بالكامل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // 3. Mock Navigation Bar
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = preset.surface.copy(alpha = 0.95f),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, preset.outline.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.People, null, tint = preset.primary, modifier = Modifier.size(18.dp))
                                    Text("الطلاب", fontSize = 7.sp, color = preset.primary, fontWeight = FontWeight.Bold)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.QrCodeScanner, null, tint = preset.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(18.dp))
                                    Text("التحضير", fontSize = 7.sp, color = preset.onSurfaceVariant)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Assignment, null, tint = preset.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(18.dp))
                                    Text("الدرجات", fontSize = 7.sp, color = preset.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Modal Footer Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = activePreset.primary
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, activePreset.outline)
                    ) {
                        Text("إغلاق المعاينة", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Button(
                        onClick = onApply,
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = activePreset.primary,
                            contentColor = activePreset.onPrimary
                        )
                    ) {
                        Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("اعتماد وتطبيق المظهر 🎨", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
