package com.example.ui.screens

import androidx.activity.compose.BackHandler
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentViolation
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

private val WarningOrange = Color(0xFFD97706)
private val WarningOrangeBg = Color(0xFFFFFBEB)
private val WarningRed = Color(0xFFDC2626)
private val WarningRedBg = Color(0xFFFEF2F2)
private val WarningAmber = Color(0xFFF59E0B)
private val SuccessGreen = Color(0xFF10B981)

val PRESET_VIOLATIONS = listOf(
    Pair("🖥️ عدم إغلاق جهاز الحاسوب بالشكل الصحيح", "أجهزة ومعمل"),
    Pair("⏰ تأخير متكرر عن بداية المحاضرة", "حضور وتأخير"),
    Pair("📵 استخدام الجوال أثناء الشرح", "سلوك وقاعة"),
    Pair("🥤 إدخال مأكولات أو مشروبات للمعمل", "أجهزة ومعمل"),
    Pair("🚫 غياب متكرر بدون عذر مقبول", "حضور وتأخير"),
    Pair("🔌 العبث بتوصيلات وأسلاك المعمل", "أجهزة ومعمل"),
    Pair("📢 التحدث ومقاطعة الشرح في القاعة", "سلوك وقاعة"),
    Pair("📝 عدم إحضار الأدوات أو الدفتر", "سلوك وقاعة")
)

val PRESET_ACTIONS = listOf(
    "تنبيه شفهي أول",
    "إنذار رسمي أول (تحذير من حسم درجات السلوك عند التكرار)",
    "إنذار نهائي (إشعار بحسم درجة عند تكرار المخالفة)",
    "إحالة لإدارة التدريب / المشرف الأكاديمي",
    "تعهد خطي بعدم تكرار المخالفة"
)

fun buildSingleViolationShareText(violation: StudentViolation): String {
    val builder = StringBuilder()
    if (violation.subjectName.isNotBlank()) {
        builder.append("المادة : ${violation.subjectName}\n")
    }
    builder.append("إشعار مخالفة وانضباط\n\n")
    builder.append("اسم الطالب : ${violation.studentName}\n")
    builder.append("المخالفة : ${violation.violationTitle}\n")
    builder.append("التاريخ : ${violation.date}")
    if (violation.time.isNotBlank()) {
        builder.append(" (${violation.time})")
    }
    builder.append("\n")
    builder.append("الإجراء المتخذ : ${violation.actionTaken}\n")
    if (violation.notes.isNotBlank()) {
        builder.append("ملاحظات : ${violation.notes}\n")
    }
    builder.append("\nالرجاء من جميع الطلاب الالتزام التام بتعليمات المعمل والمحافظة على الأجهزة.\n")
    builder.append("بالتوفيق للجميع")
    return builder.toString()
}

fun buildGroupViolationsReportText(
    courseName: String,
    subjectName: String,
    date: String,
    violations: List<StudentViolation>
): String {
    val builder = StringBuilder()
    builder.append("📋 تقرير المخالفات والانضباط\n")
    if (courseName.isNotBlank()) builder.append("الدورة / الدفعة : $courseName\n")
    if (subjectName.isNotBlank()) builder.append("المادة : $subjectName\n")
    builder.append("التاريخ : $date\n")
    builder.append("عدد المخالفات المرصودة : ${violations.size}\n")
    builder.append("────────────────────\n")
    violations.forEachIndexed { index, v ->
        builder.append("${index + 1}. ${v.studentName} : ${v.violationTitle}\n")
        builder.append("   الإجراء: ${v.actionTaken}\n")
    }
    builder.append("────────────────────\n")
    builder.append("نأمل من جميع المتدربين الالتزام التام والتقيد بالتعليمات.\n")
    builder.append("مع تمنياتنا للجميع بالتوفيق والنجاح.")
    return builder.toString()
}

fun sendViolationWhatsApp(context: Context, phoneNumber: String, text: String) {
    try {
        var cleanNumber = phoneNumber.replace("+", "").replace("-", "").replace(" ", "").trim()
        if (cleanNumber.startsWith("00")) {
            cleanNumber = cleanNumber.substring(2)
        }
        if (!cleanNumber.startsWith("967") && cleanNumber.startsWith("7") && cleanNumber.length == 9) {
            cleanNumber = "967$cleanNumber"
        }
        
        // Copy to clipboard for easy fallback
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            clipboard?.setPrimaryClip(ClipData.newPlainText("Violation Notice", text))
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val encodedText = URLEncoder.encode(text, "UTF-8")
        val uriStr = if (cleanNumber.isNotBlank()) {
            "https://api.whatsapp.com/send?phone=$cleanNumber&text=$encodedText"
        } else {
            "https://api.whatsapp.com/send?text=$encodedText"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriStr))
        context.startActivity(intent)
        Toast.makeText(context, "تم نسخ نص الإشعار وتوجيه الرسالة لواتساب 💬", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        // Fallback to standard share sheet
        try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                putExtra(Intent.EXTRA_TEXT, text)
                type = "text/plain"
            }
            context.startActivity(Intent.createChooser(sendIntent, "مشاركة إشعار المخالفة"))
        } catch (ex: Exception) {
            Toast.makeText(context, "تعذر فتح تطبيق الواتساب", Toast.LENGTH_SHORT).show()
        }
    }
}

fun copyToClipboard(context: Context, text: String, label: String = "Violation Notice") {
    try {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(context, "تم نسخ النص إلى الحافظة بنجاح 📋", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(context, "فشل النسخ: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentViolationsScreen(
    viewModel: MainViewModel,
    studentViewModel: StudentViewModel? = null,
    showMainLayout: Boolean = true
) {
    val context = LocalContext.current
    val isDark = com.example.ui.theme.LocalThemePreset.current.isDark

    val dbCourses by viewModel.dbCourses.collectAsState()
    val dbStudents by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val dbSubjects by viewModel.dbSubjects.collectAsState()
    val dbViolations by (studentViewModel?.allViolations ?: viewModel.dbStudentViolations).collectAsState()
    val selectedCourseForAttendance by viewModel.selectedCourseForStudentAttendance.collectAsState()
    val attendanceDateInput by viewModel.studentAttendanceDateInput.collectAsState()

    // Determine initial course selection
    var selectedCourseId by remember {
        mutableStateOf<Long?>(selectedCourseForAttendance?.id?.toLong() ?: dbCourses.firstOrNull()?.id?.toLong())
    }
    LaunchedEffect(selectedCourseForAttendance, dbCourses) {
        if (selectedCourseId == null) {
            selectedCourseId = selectedCourseForAttendance?.id?.toLong() ?: dbCourses.firstOrNull()?.id?.toLong()
        }
    }

    val currentCourse = dbCourses.find { it.id.toLong() == selectedCourseId }
    val courseStudents = remember(selectedCourseId, dbStudents) {
        if (selectedCourseId != null) {
            dbStudents.filter { it.courseId == selectedCourseId?.toInt() }
        } else {
            dbStudents
        }
    }

    var selectedSubjectFilter by remember { mutableStateOf("الكل") }
    var selectedCategoryFilter by remember { mutableStateOf("الكل") }
    var searchQuery by remember { mutableStateOf("") }

    // Dialog States
    var showAddDialog by remember { mutableStateOf(false) }
    var editingViolation by remember { mutableStateOf<StudentViolation?>(null) }
    var violationToDelete by remember { mutableStateOf<StudentViolation?>(null) }
    var showGroupReportDialog by remember { mutableStateOf(false) }
    var showBroadcastDialog by remember { mutableStateOf(false) }

    // Filtered Violations List
    val filteredViolations = remember(
        dbViolations, selectedCourseId, selectedSubjectFilter, selectedCategoryFilter, searchQuery
    ) {
        dbViolations.filter { v ->
            val matchCourse = (selectedCourseId == null || v.courseId == selectedCourseId)
            val matchSubject = (selectedSubjectFilter == "الكل" || v.subjectName == selectedSubjectFilter)
            val matchCategory = (selectedCategoryFilter == "الكل" || v.violationType == selectedCategoryFilter)
            val matchSearch = searchQuery.isBlank() || v.studentName.contains(searchQuery, ignoreCase = true) || v.violationTitle.contains(searchQuery, ignoreCase = true)
            matchCourse && matchSubject && matchCategory && matchSearch
        }
    }

    // Repetition map (StudentId + ViolationTitle -> count)
    val violationCounts = remember(dbViolations) {
        val map = mutableMapOf<Pair<Long, String>, Int>()
        dbViolations.forEach { v ->
            val key = Pair(v.studentId, v.violationTitle)
            map[key] = (map[key] ?: 0) + 1
        }
        map
    }

    val totalViolationsCount = filteredViolations.size
    val uniqueViolatingStudents = filteredViolations.map { it.studentId }.distinct().size

    if (showMainLayout) {
        BackHandler {
            viewModel.navigateBack()
        }
    }

    Scaffold(
        topBar = {
            if (showMainLayout) {
                TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = WarningOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                "سجل المخالفات والانضباط",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy
                            )
                            if (currentCourse != null) {
                                Text(
                                    currentCourse.name,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = DawamiNavy
                        )
                    }
                },
                actions = {
                    // Group Report Action
                    IconButton(
                        onClick = {
                            if (filteredViolations.isEmpty()) {
                                Toast.makeText(context, "لا توجد مخالفات لمشاركتها", Toast.LENGTH_SHORT).show()
                            } else {
                                showGroupReportDialog = true
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "مشاركة تقرير جماعي",
                            tint = DawamiNavy
                        )
                    }

                    // Broadcast to individuals Action
                    IconButton(
                        onClick = {
                            if (filteredViolations.isEmpty()) {
                                Toast.makeText(context, "لا توجد مخالفات لإرسالها", Toast.LENGTH_SHORT).show()
                            } else {
                                showBroadcastDialog = true
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.SendToMobile,
                            contentDescription = "إرسال فردي سريع للجميع",
                            tint = DawamiNavy
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = WarningOrange,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                icon = { Icon(Icons.Default.AddAlert, contentDescription = null) },
                text = { Text("تسجيل مخالفة ➕", fontWeight = FontWeight.Bold) }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(if (isDark) MaterialTheme.colorScheme.background else Color(0xFFF8FAFC)),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Course & Subject Selectors
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Course selector row
                        if (dbCourses.size > 1) {
                            Text("الدورة / الدفعة:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(dbCourses) { course ->
                                    val isSelected = selectedCourseId == course.id.toLong()
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { selectedCourseId = course.id.toLong() },
                                        label = { Text(course.name, fontSize = 11.sp) },
                                        leadingIcon = if (isSelected) {
                                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                        } else null,
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = DawamiNavy,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }
                        }

                        // Search Bar
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("بحث باسم الطالب أو نوع المخالفة...", fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                            trailingIcon = if (searchQuery.isNotEmpty()) {
                                {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "مسح", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            } else null,
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        // Category Filter Chips
                        val categories = listOf("الكل", "أجهزة ومعمل", "حضور وتأخير", "سلوك وقاعة", "أخرى")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(categories) { cat ->
                                val isSelected = selectedCategoryFilter == cat
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedCategoryFilter = cat },
                                    label = { Text(cat, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = WarningOrange,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Statistics Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = WarningOrangeBg),
                    border = BorderStroke(1.dp, WarningOrange.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("إجمالي المخالفات", fontSize = 11.sp, color = Color(0xFF78350F))
                            Text("$totalViolationsCount", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = WarningOrange)
                        }
                        Divider(modifier = Modifier.height(30.dp).width(1.dp), color = WarningOrange.copy(alpha = 0.3f))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("الطلاب المخالفين", fontSize = 11.sp, color = Color(0xFF78350F))
                            Text("$uniqueViolatingStudents", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        }
                        Divider(modifier = Modifier.height(30.dp).width(1.dp), color = WarningOrange.copy(alpha = 0.3f))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("أعلى مخالفة", fontSize = 11.sp, color = Color(0xFF78350F))
                            val topViolation = filteredViolations.groupBy { it.violationTitle }
                                .maxByOrNull { it.value.size }?.key
                            Text(
                                if (topViolation != null) {
                                    topViolation.take(15) + if (topViolation.length > 15) "..." else ""
                                } else "لا توجد",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            // Quick Info Note
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DawamiNavy.copy(alpha = 0.05f)),
                    border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.15f))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
                        Text(
                            "الإجراءات المسجلة هنا توثيقية ورادعة للتنبيه والمتابعة، ولا تقوم بالخصم التلقائي من كشف الدرجات.",
                            fontSize = 11.sp,
                            color = DawamiNavy,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // Empty State or List
            if (filteredViolations.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(SuccessGreen.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                            Text(
                                "لا توجد مخالفات مسجلة 🎉",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy
                            )
                            Text(
                                "سجل الطلاب نظيف ومنتظم، اضغط على زر (تسجيل مخالفة ➕) لإضافة مخالفة جديدة عند الحاجة.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(filteredViolations, key = { it.id }) { violation ->
                    val repeatCount = violationCounts[Pair(violation.studentId, violation.violationTitle)] ?: 1

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (repeatCount > 1) WarningRed.copy(alpha = 0.4f) else WarningOrange.copy(alpha = 0.3f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Header Row: Student name & badges
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (repeatCount > 1) WarningRed.copy(alpha = 0.12f)
                                                else WarningOrange.copy(alpha = 0.12f)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            violation.studentName.take(1),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = if (repeatCount > 1) WarningRed else WarningOrange
                                        )
                                    }
                                    Column {
                                        Text(
                                            violation.studentName,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy
                                        )
                                        if (violation.studentPhone.isNotBlank()) {
                                            Text(
                                                "📞 ${violation.studentPhone}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }

                                // Date & Repetition Badges
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    if (repeatCount > 1) {
                                        Surface(
                                            color = WarningRedBg,
                                            shape = RoundedCornerShape(6.dp),
                                            border = BorderStroke(1.dp, WarningRed.copy(alpha = 0.3f))
                                        ) {
                                            Text(
                                                "⚠️ تكرار: $repeatCount مرات",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = WarningRed,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            violation.date,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Divider(color = Color(0xFFF1F5F9))

                            // Violation Title & Subject
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Surface(
                                        color = WarningOrange.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            violation.violationType,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = WarningOrange,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    if (violation.subjectName.isNotBlank()) {
                                        Surface(
                                            color = DawamiTeal.copy(alpha = 0.1f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                violation.subjectName,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = DawamiTeal,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }

                                Text(
                                    violation.violationTitle,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF1E293B)
                                )
                            }

                            // Action Banner
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = if (violation.actionTaken.contains("إنذار نهائي") || violation.actionTaken.contains("إحالة"))
                                    WarningRedBg
                                else
                                    WarningOrangeBg,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (violation.actionTaken.contains("إنذار نهائي") || violation.actionTaken.contains("إحالة"))
                                        WarningRed.copy(alpha = 0.25f)
                                    else
                                        WarningOrange.copy(alpha = 0.25f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Gavel,
                                        contentDescription = null,
                                        tint = if (violation.actionTaken.contains("إنذار نهائي") || violation.actionTaken.contains("إحالة"))
                                            WarningRed
                                        else
                                            WarningOrange,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        "الإجراء: ${violation.actionTaken}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (violation.actionTaken.contains("إنذار نهائي") || violation.actionTaken.contains("إحالة"))
                                            Color(0xFF991B1B)
                                        else
                                            Color(0xFF92400E)
                                    )
                                }
                            }

                            if (violation.notes.isNotBlank()) {
                                Text(
                                    "ملاحظات: ${violation.notes}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                            }

                            // Action Buttons: WhatsApp, Copy, Edit, Delete
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    // WhatsApp Button
                                    Button(
                                        onClick = {
                                            val shareText = buildSingleViolationShareText(violation)
                                            sendViolationWhatsApp(context, violation.studentPhone, shareText)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("واتساب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // Copy Text Button
                                    OutlinedButton(
                                        onClick = {
                                            val shareText = buildSingleViolationShareText(violation)
                                            copyToClipboard(context, shareText)
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("نسخ", fontSize = 11.sp)
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    IconButton(
                                        onClick = { editingViolation = violation },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = DawamiNavy, modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(
                                        onClick = { violationToDelete = violation },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Spacing for FAB
            item {
                Spacer(modifier = Modifier.height(64.dp))
            }
        }
    }

    // Add / Edit Dialog
    if (showAddDialog || editingViolation != null) {
        ViolationFormDialog(
            isEdit = editingViolation != null,
            initialViolation = editingViolation,
            students = courseStudents,
            subjects = dbSubjects.map { it.name }.distinct(),
            courseId = selectedCourseId ?: 0L,
            onDismiss = {
                showAddDialog = false
                editingViolation = null
            },
            onSaveSingle = { newOrUpdated ->
                if (editingViolation != null) {
                    if (studentViewModel != null) {
                        studentViewModel.updateViolation(newOrUpdated)
                    } else {
                        viewModel.updateViolation(newOrUpdated)
                    }
                    Toast.makeText(context, "تم تحديث المخالفة بنجاح", Toast.LENGTH_SHORT).show()
                } else {
                    if (studentViewModel != null) {
                        studentViewModel.insertViolation(newOrUpdated)
                    } else {
                        viewModel.insertViolation(newOrUpdated)
                    }
                    Toast.makeText(context, "تم تسجيل المخالفة بنجاح ⚠️", Toast.LENGTH_SHORT).show()
                }
                showAddDialog = false
                editingViolation = null
            },
            onSaveMultiple = { violationsList ->
                if (studentViewModel != null) {
                    studentViewModel.insertViolations(violationsList)
                } else {
                    viewModel.insertViolations(violationsList)
                }
                Toast.makeText(context, "تم تسجيل المخالفة لـ ${violationsList.size} طلاب بنجاح ⚠️", Toast.LENGTH_SHORT).show()
                showAddDialog = false
                editingViolation = null
            }
        )
    }

    // Delete Confirmation Dialog
    if (violationToDelete != null) {
        AlertDialog(
            onDismissRequest = { violationToDelete = null },
            title = { Text("تأكيد الحذف", fontWeight = FontWeight.Bold) },
            text = {
                Text("هل أنت متأكد من رغبتك في حذف مخالفة الطالب (${violationToDelete?.studentName})؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val toDel = violationToDelete
                        if (toDel != null) {
                            if (studentViewModel != null) {
                                studentViewModel.deleteViolation(toDel)
                            } else {
                                viewModel.deleteViolation(toDel)
                            }
                        }
                        violationToDelete = null
                        Toast.makeText(context, "تم حذف المخالفة", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { violationToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Group Summary Report Dialog
    if (showGroupReportDialog) {
        val todayStr = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date())
        val reportText = remember(filteredViolations, currentCourse, selectedSubjectFilter) {
            buildGroupViolationsReportText(
                courseName = currentCourse?.name ?: "",
                subjectName = if (selectedSubjectFilter != "الكل") selectedSubjectFilter else "",
                date = todayStr,
                violations = filteredViolations
            )
        }

        AlertDialog(
            onDismissRequest = { showGroupReportDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Summarize, contentDescription = null, tint = WarningOrange)
                    Text("تقرير المخالفات العام", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "معاينة نص التقرير الجماعي:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Text(
                            reportText,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(10.dp),
                            lineHeight = 16.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        sendViolationWhatsApp(context, "", reportText)
                        showGroupReportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة عبر الواتساب")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        copyToClipboard(context, reportText)
                        showGroupReportDialog = false
                    }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ النص")
                }
            }
        )
    }

    // Broadcast Dialog to Individuals
    if (showBroadcastDialog) {
        AlertDialog(
            onDismissRequest = { showBroadcastDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.SendToMobile, contentDescription = null, tint = DawamiTeal)
                    Text("إرسال فردي سريع للطلاب", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "اضغط على زر الواتساب بجانب اسم أي طالب لإرسال إشعار المخالفة الفردي والخاص به مباشرة:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    filteredViolations.forEach { v ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(v.studentName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                    Text(v.violationTitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Button(
                                    onClick = {
                                        val text = buildSingleViolationShareText(v)
                                        sendViolationWhatsApp(context, v.studentPhone, text)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إرسال", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBroadcastDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViolationFormDialog(
    isEdit: Boolean,
    initialViolation: StudentViolation?,
    students: List<Student>,
    subjects: List<String>,
    courseId: Long,
    onDismiss: () -> Unit,
    onSaveSingle: (StudentViolation) -> Unit,
    onSaveMultiple: (List<StudentViolation>) -> Unit
) {
    val todayStr = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date())
    val currentTimeStr = SimpleDateFormat("hh:mm a", Locale("ar")).format(Date())

    var isMultipleSelection by remember { mutableStateOf(false) }
    var selectedStudentId by remember { mutableStateOf<Long?>(initialViolation?.studentId ?: students.firstOrNull()?.id?.toLong()) }
    val selectedStudentIds = remember { mutableStateListOf<Long>() }

    var subjectName by remember { mutableStateOf(initialViolation?.subjectName ?: subjects.firstOrNull() ?: "") }
    var violationType by remember { mutableStateOf(initialViolation?.violationType ?: "أجهزة ومعمل") }
    var violationTitle by remember { mutableStateOf(initialViolation?.violationTitle ?: "") }
    var actionTaken by remember { mutableStateOf(initialViolation?.actionTaken ?: PRESET_ACTIONS[1]) }
    var date by remember { mutableStateOf(initialViolation?.date ?: todayStr) }
    var time by remember { mutableStateOf(initialViolation?.time ?: currentTimeStr) }
    var notes by remember { mutableStateOf(initialViolation?.notes ?: "") }

    var customViolationTitle by remember { mutableStateOf("") }
    var isCustomViolation by remember { mutableStateOf(false) }
    var customAction by remember { mutableStateOf("") }
    var isCustomAction by remember { mutableStateOf(false) }

    var studentSearchText by remember { mutableStateOf("") }

    val filteredStudents = remember(students, studentSearchText) {
        if (studentSearchText.isBlank()) students
        else students.filter { it.name.contains(studentSearchText, ignoreCase = true) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(
                    if (isEdit) Icons.Default.Edit else Icons.Default.AddAlert,
                    contentDescription = null,
                    tint = WarningOrange
                )
                Text(
                    if (isEdit) "تعديل مخالفة مسجلة" else "تسجيل مخالفة جديدة",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = DawamiNavy
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Single vs Multiple Selector (only in Add Mode)
                if (!isEdit) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = !isMultipleSelection,
                            onClick = { isMultipleSelection = false },
                            label = { Text("طالب واحد", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DawamiNavy,
                                selectedLabelColor = Color.White
                            )
                        )
                        FilterChip(
                            selected = isMultipleSelection,
                            onClick = { isMultipleSelection = true },
                            label = { Text("تحديد جماعي (مجموعة طلاب)", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DawamiNavy,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                // Student Selection
                if (isEdit) {
                    Text("الطالب: ${initialViolation?.studentName}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DawamiNavy)
                } else if (!isMultipleSelection) {
                    Text("اختر الطالب:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                    OutlinedTextField(
                        value = studentSearchText,
                        onValueChange = { studentSearchText = it },
                        placeholder = { Text("بحث في أسماء الطلاب...", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 140.dp),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        LazyColumn(modifier = Modifier.padding(4.dp)) {
                            items(filteredStudents) { st ->
                                val isSelected = selectedStudentId == st.id.toLong()
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedStudentId = st.id.toLong() }
                                        .background(if (isSelected) DawamiNavy.copy(alpha = 0.1f) else Color.Transparent)
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(st.name, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                    if (isSelected) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Multiple Selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("اختر الطلاب (${selectedStudentIds.size} محدد):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = {
                                selectedStudentIds.clear()
                                selectedStudentIds.addAll(students.map { it.id.toLong() })
                            }) {
                                Text("تحديد الكل", fontSize = 10.sp)
                            }
                            TextButton(onClick = { selectedStudentIds.clear() }) {
                                Text("إلغاء", fontSize = 10.sp)
                            }
                        }
                    }
                    OutlinedTextField(
                        value = studentSearchText,
                        onValueChange = { studentSearchText = it },
                        placeholder = { Text("بحث في أسماء الطلاب...", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 140.dp),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        LazyColumn(modifier = Modifier.padding(4.dp)) {
                            items(filteredStudents) { st ->
                                val isChecked = selectedStudentIds.contains(st.id.toLong())
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (isChecked) selectedStudentIds.remove(st.id.toLong())
                                            else selectedStudentIds.add(st.id.toLong())
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(st.name, fontSize = 12.sp)
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { checked ->
                                            if (checked) selectedStudentIds.add(st.id.toLong())
                                            else selectedStudentIds.remove(st.id.toLong())
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Subject Name Selection (if available)
                if (subjects.isNotEmpty()) {
                    Text("المادة:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(subjects) { sub ->
                            val isSelected = subjectName == sub
                            FilterChip(
                                selected = isSelected,
                                onClick = { subjectName = sub },
                                label = { Text(sub, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DawamiTeal,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }

                // Preset Violations
                Text("نوع المخالفة الشائعة (اختر بنقرة سريعة):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    PRESET_VIOLATIONS.forEach { (presetTitle, cat) ->
                        val isSelected = (!isCustomViolation && violationTitle == presetTitle)
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    isCustomViolation = false
                                    violationTitle = presetTitle
                                    violationType = cat
                                },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) WarningOrange.copy(alpha = 0.15f) else Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, if (isSelected) WarningOrange else Color(0xFFE2E8F0))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    presetTitle,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color(0xFF92400E) else Color(0xFF1E293B)
                                )
                                if (isSelected) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    // Custom Violation Option
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                isCustomViolation = true
                                violationType = "أخرى"
                            },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isCustomViolation) WarningOrange.copy(alpha = 0.15f) else Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, if (isCustomViolation) WarningOrange else Color(0xFFE2E8F0))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "✍️ مخالفة مخصصة أخرى...",
                                fontSize = 12.sp,
                                fontWeight = if (isCustomViolation) FontWeight.Bold else FontWeight.Normal,
                                color = if (isCustomViolation) Color(0xFF92400E) else Color(0xFF1E293B)
                            )
                            if (isCustomViolation) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    if (isCustomViolation) {
                        OutlinedTextField(
                            value = customViolationTitle,
                            onValueChange = {
                                customViolationTitle = it
                                violationTitle = it
                            },
                            label = { Text("اكتب عنوان المخالفة بالتفصيل") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }

                // Deterrent Actions Selector
                Text("الإجراء التحذيري المتخذ (نص رادع):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    PRESET_ACTIONS.forEach { action ->
                        val isSelected = (!isCustomAction && actionTaken == action)
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    isCustomAction = false
                                    actionTaken = action
                                },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) DawamiNavy.copy(alpha = 0.12f) else Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, if (isSelected) DawamiNavy else Color(0xFFE2E8F0))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    action,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) DawamiNavy else Color(0xFF1E293B)
                                )
                                if (isSelected) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    // Custom Action Option
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isCustomAction = true },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isCustomAction) DawamiNavy.copy(alpha = 0.12f) else Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, if (isCustomAction) DawamiNavy else Color(0xFFE2E8F0))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "✍️ إجراء تحذيري مخصص...",
                                fontSize = 11.sp,
                                fontWeight = if (isCustomAction) FontWeight.Bold else FontWeight.Normal,
                                color = if (isCustomAction) DawamiNavy else Color(0xFF1E293B)
                            )
                            if (isCustomAction) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    if (isCustomAction) {
                        OutlinedTextField(
                            value = customAction,
                            onValueChange = {
                                customAction = it
                                actionTaken = it
                            },
                            label = { Text("اكتب الإجراء المتخذ") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }

                // Date & Time
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("التاريخ") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    OutlinedTextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("الوقت") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                // Notes Field
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات إضافية (اختياري)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalTitle = if (isCustomViolation) customViolationTitle.trim() else violationTitle.trim()
                    val finalAction = if (isCustomAction) customAction.trim() else actionTaken.trim()

                    if (finalTitle.isBlank()) {
                        return@Button
                    }

                    if (isEdit && initialViolation != null) {
                        onSaveSingle(
                            initialViolation.copy(
                                subjectName = subjectName,
                                violationType = violationType,
                                violationTitle = finalTitle,
                                actionTaken = finalAction,
                                date = date,
                                time = time,
                                notes = notes
                            )
                        )
                    } else if (isMultipleSelection) {
                        if (selectedStudentIds.isEmpty()) {
                            return@Button
                        }
                        val list = selectedStudentIds.mapNotNull { stId ->
                            val st = students.find { it.id.toLong() == stId } ?: return@mapNotNull null
                            StudentViolation(
                                courseId = courseId,
                                subjectName = subjectName,
                                studentId = st.id.toLong(),
                                studentName = st.name,
                                studentPhone = st.phoneNumber,
                                violationType = violationType,
                                violationTitle = finalTitle,
                                actionTaken = finalAction,
                                date = date,
                                time = time,
                                notes = notes
                            )
                        }
                        onSaveMultiple(list)
                    } else {
                        val st = students.find { it.id.toLong() == selectedStudentId } ?: return@Button
                        onSaveSingle(
                            StudentViolation(
                                courseId = courseId,
                                subjectName = subjectName,
                                studentId = st.id.toLong(),
                                studentName = st.name,
                                studentPhone = st.phoneNumber,
                                violationType = violationType,
                                violationTitle = finalTitle,
                                actionTaken = finalAction,
                                date = date,
                                time = time,
                                notes = notes
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = WarningOrange)
            ) {
                Text(if (isEdit) "حفظ التعديلات" else "تسجيل المخالفة ⚠️", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
