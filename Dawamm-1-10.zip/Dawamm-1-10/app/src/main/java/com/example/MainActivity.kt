package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.flow.first
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.fragment.app.FragmentActivity
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import kotlinx.coroutines.launch
import com.example.ui.components.DawamiNavigationDrawerContent
import com.example.ui.components.LocalDrawerOpener
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.DawamiViewModelFactory
import com.example.ui.viewmodel.AppAdminViewModel
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.GradingViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.ui.viewmodel.Screen
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.ExistingPeriodicWorkPolicy
import java.util.concurrent.TimeUnit
import com.example.workers.AttendanceAlertWorker

class MainActivity : FragmentActivity() {
  private val viewModel: MainViewModel by viewModels { DawamiViewModelFactory(application) }
  private val gradingViewModel: GradingViewModel by viewModels { DawamiViewModelFactory(application) }
  private val studentViewModel: StudentViewModel by viewModels { DawamiViewModelFactory(application) }
  private val attendanceViewModel: AttendanceViewModel by viewModels { DawamiViewModelFactory(application) }
  private val courseViewModel: CourseViewModel by viewModels { DawamiViewModelFactory(application) }
  private val adminViewModel: AppAdminViewModel by viewModels { DawamiViewModelFactory(application) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    // Schedule Attendance Alert Worker safely
    try {
        val alertWorkRequest = PeriodicWorkRequestBuilder<AttendanceAlertWorker>(30, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "AttendanceAlertWorker",
            ExistingPeriodicWorkPolicy.KEEP,
            alertWorkRequest
        )
        // Ensure all active course alarms are scheduled and fresh
        com.example.notification.NotificationHelper.scheduleAllActiveCourseReminders(applicationContext)
    } catch (e: Exception) {
        android.util.Log.e("MainActivity", "WorkManager init: ${e.localizedMessage}")
    }

    // 1. Request notification permission on Android 13+ (API 33+)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    // 2. Request Battery Optimization Exemption upon launch to ensure background alarms & pre-course voice alerts fire on time
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val powerManager = getSystemService(android.content.Context.POWER_SERVICE) as? android.os.PowerManager
        if (powerManager != null && !powerManager.isIgnoringBatteryOptimizations(packageName)) {
            val prefs = getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
            val askedBattery = prefs.getBoolean("has_prompted_battery_optimization_v1", false)
            if (!askedBattery) {
                prefs.edit().putBoolean("has_prompted_battery_optimization_v1", true).apply()
                try {
                    val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = android.net.Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    try {
                        val intent = android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        startActivity(intent)
                    } catch (_: Exception) {}
                }
            }
        }
    }

    // 3. Request Exact Alarm permission on Android 12+ (API 31+) if needed
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val alarmManager = getSystemService(android.content.Context.ALARM_SERVICE) as? android.app.AlarmManager
        if (alarmManager != null && !alarmManager.canScheduleExactAlarms()) {
            val prefs = getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
            val askedExact = prefs.getBoolean("has_prompted_exact_alarm_v1", false)
            if (!askedExact) {
                prefs.edit().putBoolean("has_prompted_exact_alarm_v1", true).apply()
                try {
                    val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                        data = android.net.Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (_: Exception) {}
            }
        }
    }

    // Temporary data fix for Asrar's Access grade as requested by the user
    val fixPrefs = getSharedPreferences("data_fixes", android.content.Context.MODE_PRIVATE)
    if (!fixPrefs.getBoolean("fix_asrar_access_grade_v2", false)) {
        val database = com.example.data.database.AppDatabase.getDatabase(this)
        val studentGradeDao = database.studentGradeDao()
        kotlinx.coroutines.MainScope().launch {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val allGrades = studentGradeDao.getAllGrades().first()
                    val targetGrade = allGrades.find { 
                        (it.studentName.contains("أسرار") || it.studentName.contains("اسرار")) && 
                        (it.subjectName.contains("أكسس") || it.subjectName.contains("اكسس") || it.subjectName.contains("قواعد البيانات"))
                    }

                    if (targetGrade != null) {
                        // Correcting grade to 39 as requested
                        val updated = targetGrade.withManualFinalGrading(39.0)
                        studentGradeDao.insertGrade(updated)
                        fixPrefs.edit().putBoolean("fix_asrar_access_grade_v2", true).apply()
                    }
                } catch (e: Exception) {
                    android.util.Log.e("MainActivity", "DataFix error: ${e.message}")
                }
            }
        }
    }

    setContent {
      val isDarkTheme by viewModel.isDarkTheme.collectAsState()
      val selectedThemeId by viewModel.selectedThemeId.collectAsState()
      MyApplicationTheme(presetId = selectedThemeId, darkTheme = isDarkTheme) {
        val currentScreen by viewModel.currentScreen.collectAsState()

        val showQuickAttendance by viewModel.showQuickAttendanceAssistantDialog.collectAsState()
        if (showQuickAttendance) {
            com.example.ui.screens.QuickAttendanceAssistantDialog(
                viewModel = viewModel,
                courseViewModel = courseViewModel,
                attendanceViewModel = attendanceViewModel,
                onDismiss = { viewModel.dismissQuickAttendanceAssistant() }
            )
        }

        val showDatePicker by viewModel.showModernDatePicker.collectAsState()
        val showTimePicker by viewModel.showModernTimePicker.collectAsState()
        val showDeveloperContactDialog by viewModel.showDeveloperContactDialog.collectAsState()
        val showThemeStudio by viewModel.showThemeStudioDialog.collectAsState()

        if (showThemeStudio) {
            com.example.ui.components.ThemeStudioDialog(
                viewModel = viewModel,
                onDismiss = { viewModel.dismissThemeStudio() }
            )
        }

        if (showDatePicker) {
            com.example.ui.components.ModernDatePickerDialog(
                onDateSelected = { viewModel.onDateSelectedCallback?.invoke(it) },
                onDismiss = { viewModel.dismissDatePicker() }
            )
        }

        if (showTimePicker) {
            com.example.ui.components.ModernTimePickerDialog(
                onTimeSelected = { viewModel.onTimeSelectedCallback?.invoke(it) },
                onDismiss = { viewModel.dismissTimePicker() }
            )
        }

        if (showDeveloperContactDialog) {
            com.example.ui.components.DeveloperContactDialog(
                onDismiss = { viewModel.dismissDeveloperContactDialog() }
            )
        }

        val weekendWarningDay by viewModel.showWeekendWarning.collectAsState()
        if (weekendWarningDay != null) {
            val isHoliday = weekendWarningDay?.contains("إجازة رسمية") == true
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { viewModel.dismissWeekendWarning() },
                title = {
                    androidx.compose.material3.Text(
                        text = if (isHoliday) "تنبيه إجازة رسمية / عطلة 🌴" else "تنبيه عطلة نهاية الأسبوع ⚠️",
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                        color = androidx.compose.ui.graphics.Color(0xFF1E3A8A) // DawamiNavy style
                    )
                },
                text = {
                    androidx.compose.material3.Text(
                        text = if (isHoliday) {
                            "لقد اخترت يوم ($weekendWarningDay)، وهو يوافق أيام العطلات والإجازات الرسمية المعتمدة في النظام. يرجى التأكيد والتأكد من صحة إدخالك رصداً للحركة."
                        } else {
                            "لقد اخترت يوم ($weekendWarningDay)، وهو يوافق أيام عطلة نهاية الأسبوع (الخميس والجمعة). يرجى التأكيد والتأكد من صحة إدخالك رصداً للحركة."
                        },
                        color = androidx.compose.ui.graphics.Color.DarkGray
                    )
                },
                confirmButton = {
                    androidx.compose.material3.TextButton(onClick = { viewModel.dismissWeekendWarning() }) {
                        androidx.compose.material3.Text("حسناً، استمر 👍", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = androidx.compose.ui.graphics.Color(0xFF1E3A8A))
                    }
                },
                containerColor = androidx.compose.ui.graphics.Color.White,
                shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp)
            )
        }

        com.example.ui.components.NotificationCenterDialog(viewModel = viewModel, isDark = isDarkTheme)

        val transientMsg by viewModel.transientFlashMessage.collectAsState()

        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val coroutineScope = rememberCoroutineScope()

        val isAuthScreen = currentScreen in listOf(
            Screen.Splash,
            Screen.Activation,
            Screen.Register,
            Screen.Login
        )

        androidx.activity.compose.BackHandler(enabled = drawerState.isOpen) {
            coroutineScope.launch { drawerState.close() }
        }

        CompositionLocalProvider(
            LocalDrawerOpener provides {
                coroutineScope.launch {
                    if (drawerState.isClosed) drawerState.open() else drawerState.close()
                }
            }
        ) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = !isAuthScreen,
                drawerContent = {
                    DawamiNavigationDrawerContent(
                        viewModel = viewModel,
                        onCloseDrawer = {
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                }
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    if (selectedThemeId == 4) {
                        com.example.ui.components.CyberMotherboardBackground()
                    }
                    val navController = rememberNavController()

                    LaunchedEffect(currentScreen) {
                        val currentDest = navController.currentDestination
                        if (currentDest != null && currentDest.route != currentScreen.route) {
                            try {
                                val isAuthScreen = currentScreen in listOf(
                                    Screen.Splash,
                                    Screen.Activation,
                                    Screen.Register,
                                    Screen.Login
                                )
                                navController.navigate(currentScreen.route) {
                                    if (!isAuthScreen && currentDest.route in listOf(
                                            Screen.Splash.route,
                                            Screen.Activation.route,
                                            Screen.Register.route,
                                            Screen.Login.route
                                        )
                                    ) {
                                        popUpTo(navController.graph.startDestinationId) {
                                            inclusive = false
                                        }
                                    } else {
                                        popUpTo(navController.graph.startDestinationId) {
                                            saveState = false
                                        }
                                    }
                                    launchSingleTop = true
                                    restoreState = false
                                }
                            } catch (e: Exception) {
                                android.util.Log.e("MainActivity", "Navigation error: ${e.localizedMessage}")
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = Screen.Splash.route,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        composable(Screen.Splash.route) { SplashScreen(viewModel) }
                        composable(Screen.Activation.route) { ActivationScreen(viewModel) }
                        composable(Screen.Register.route) { RegisterScreen(viewModel) }
                        composable(Screen.Login.route) { LoginScreen(viewModel) }
                        composable(Screen.Selection.route) { SelectionScreen(viewModel, courseViewModel, studentViewModel, attendanceViewModel) }
                        composable(Screen.Courses.route) { CoursesScreen(viewModel, courseViewModel, studentViewModel, attendanceViewModel) }
                        composable(Screen.Attendance.route) { AttendanceRecordsScreen(viewModel, attendanceViewModel) }
                        composable(Screen.Reports.route) { ReportsScreen(viewModel, attendanceViewModel, courseViewModel) }
                        composable(Screen.Students.route) { StudentsScreen(viewModel, studentViewModel) }
                        composable(Screen.StudentAttendance.route) { StudentAttendanceRecordsScreen(viewModel, attendanceViewModel, studentViewModel) }
                        composable(Screen.StudentReports.route) { StudentReportsScreen(viewModel, studentViewModel, courseViewModel, attendanceViewModel) }
                        composable(Screen.InstituteSettings.route) { InstituteSettingsScreen(viewModel) }
                        composable(Screen.Grades.route) { GradesScreen(viewModel, gradingViewModel) }
                        composable(Screen.GradeReports.route) { GradeReportsScreen(viewModel, gradingViewModel) }
                        composable(Screen.BackupRestore.route) { BackupRestoreScreen(viewModel, courseViewModel, studentViewModel, attendanceViewModel, gradingViewModel, adminViewModel) }
                        composable(Screen.ChangeCredentials.route) { ChangeCredentialsScreen(viewModel) }
                        composable(Screen.AppFeaturesGuide.route) { AppFeaturesGuideScreen(viewModel) }
                        composable(Screen.SmartSettings.route) { SmartSettingsScreen(viewModel) }
                        composable(Screen.LessonPreparation.route) { LessonPreparationScreen(viewModel, courseViewModel, attendanceViewModel) }
                        composable(Screen.Subjects.route) { SubjectsScreen(viewModel, courseViewModel) }
                        composable(Screen.OnboardingSetup.route) { OnboardingSetupScreen(viewModel, courseViewModel, studentViewModel, attendanceViewModel, gradingViewModel) }
                        composable(Screen.TeachingStats.route) { TeachingStatsScreen(viewModel, courseViewModel, attendanceViewModel) }
                        composable(Screen.AssignmentSetup.route) { AssignmentSetupScreen(viewModel, courseViewModel, studentViewModel, gradingViewModel) }
                        composable(Screen.SubjectReferences.route) { SubjectReferencesScreen(viewModel, courseViewModel) }
                        composable(Screen.TrainerFinances.route) { TrainerFinancesScreen(viewModel, adminViewModel) }
                        composable(Screen.ActivityLogs.route) { ActivityLogsScreen(viewModel, adminViewModel) }
                        composable(Screen.TheoryExamGrader.route) { TheoryExamGraderScreen(viewModel, gradingViewModel) }
                        composable(Screen.StudentViolations.route) { StudentViolationsScreen(viewModel, studentViewModel) }
                        composable(Screen.CourseAttendanceAnalytics.route) { CourseAttendanceAnalyticsScreen(viewModel, attendanceViewModel, studentViewModel) }
                        composable(Screen.OfficialHolidays.route) { OfficialHolidaysScreen(viewModel) }
                        composable(Screen.TrainerProfile.route) {
                            TrainerProfileScreen(viewModel, courseViewModel, studentViewModel, attendanceViewModel)
                        }
                        composable(Screen.TrainerGroup.route) { TrainerGroupScreen(viewModel, courseViewModel, attendanceViewModel, adminViewModel) }
                        composable(Screen.StudentsGroup.route) { StudentsGroupScreen(viewModel, gradingViewModel, studentViewModel, attendanceViewModel) }
                        composable(Screen.CurriculumGroup.route) { CurriculumGroupScreen(viewModel, gradingViewModel, courseViewModel, attendanceViewModel, studentViewModel) }
                        composable(Screen.ReportsGroup.route) { ReportsGroupScreen(viewModel, gradingViewModel, attendanceViewModel, studentViewModel, adminViewModel, courseViewModel) }
                        composable(Screen.SettingsGroup.route) { SettingsGroupScreen(viewModel, adminViewModel, courseViewModel, studentViewModel, attendanceViewModel, gradingViewModel) }
                    }

                    transientMsg?.let { notif ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 40.dp),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            com.example.ui.components.TransientFlashMessageBar(
                                notification = notif,
                                onDismiss = { viewModel.dismissFlashMessage() },
                                onOpenCenter = {
                                    viewModel.dismissFlashMessage()
                                    viewModel.openNotificationCenter()
                                },
                                isDark = isDarkTheme
                            )
                        }
                    }
                }
            }
        }
      }
    }
  }
}
