package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentAttendance
import com.example.data.entity.StudentGradeConfig
import com.example.data.entity.StudentViolation
import com.example.data.entity.Subject
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentsScreen(
    viewModel: MainViewModel,
    studentViewModel: StudentViewModel? = null,
    showMainLayout: Boolean = true
) {
    val dbCourses by viewModel.dbCourses.collectAsState()
    val showCompletedCourses by viewModel.showCompletedCoursesInDropdowns.collectAsState()
    val dbAllStudents by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val dbAllStudentAttendance by viewModel.dbAllStudentAttendance.collectAsState()
    val selectedCourse by viewModel.selectedCourseForStudents.collectAsState()
    val studentName by viewModel.studentNameInput.collectAsState()
    val studentPhoneInput by viewModel.studentPhoneInput.collectAsState()

    var isCourseDropdownExpanded by remember { mutableStateOf(false) }

    var studentToDelete by remember { mutableStateOf<Student?>(null) }
    var showDeleteStudentConfirmDialog by remember { mutableStateOf(false) }

    var studentToEdit by remember { mutableStateOf<Student?>(null) }
    var editStudentNameInput by remember { mutableStateOf("") }
    var showEditStudentDialog by remember { mutableStateOf(false) }
    var showEditStudentConfirmDialog by remember { mutableStateOf(false) }

    var studentForStatusManagement by remember { mutableStateOf<Student?>(null) }
    var showStatusManagementDialog by remember { mutableStateOf(false) }

    var studentForAttendanceMovement by remember { mutableStateOf<Student?>(null) }
    var showStudentAttendanceMovementDialog by remember { mutableStateOf(false) }

    var studentFor360 by remember { mutableStateOf<Student?>(null) }
    var showStudent360Dialog by remember { mutableStateOf(false) }
    var studentSearchQuery by remember { mutableStateOf("") }
    var studentStatusFilter by remember { mutableStateOf("الكل") }

    var showManualPhoneDialog by remember { mutableStateOf(false) }
    var manualPhoneToEdit by remember { mutableStateOf("") }
    var editStudentPhoneInput by remember { mutableStateOf("") }
    var contactPickerForEdit by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val contactPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickContact(),
        onResult = { contactUri ->
            if (contactUri != null) {
                try {
                    val resolver = context.contentResolver
                    val cursor = resolver.query(contactUri, null, null, null, null)
                    var name = ""
                    var hasPhone = false
                    var contactId = ""
                    if (cursor != null && cursor.moveToFirst()) {
                        val idCol = cursor.getColumnIndex(android.provider.ContactsContract.Contacts._ID)
                        if (idCol >= 0) contactId = cursor.getString(idCol)
                        
                        val nameCol = cursor.getColumnIndex(android.provider.ContactsContract.Contacts.DISPLAY_NAME)
                        if (nameCol >= 0) name = cursor.getString(nameCol)
                        
                        val hasPhoneCol = cursor.getColumnIndex(android.provider.ContactsContract.Contacts.HAS_PHONE_NUMBER)
                        if (hasPhoneCol >= 0) {
                            hasPhone = cursor.getInt(hasPhoneCol) > 0
                        }
                    }
                    cursor?.close()
                    
                    var phone = ""
                    if (hasPhone && contactId.isNotEmpty()) {
                        val phoneCursor = resolver.query(
                            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            android.provider.ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            arrayOf(contactId),
                            null
                        )
                        if (phoneCursor != null && phoneCursor.moveToFirst()) {
                            val numCol = phoneCursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)
                            if (numCol >= 0) {
                                phone = phoneCursor.getString(numCol)
                            }
                        }
                        phoneCursor?.close()
                    }
                    
                    var nameImported = false
                    if (name.isNotEmpty()) {
                        if (contactPickerForEdit) {
                            // عند تعديل بطاقة الطالب: لا يتم تعديل أو استبدال الاسم، بل يتم تحميل الرقم فقط
                        } else {
                            // عند إضافة طالب جديد: يتم فحص حقل الاسم، فإذا كان فارغاً يتم ملؤه، وإذا كان فيه اسم يتم الاحتفاظ به
                            if (viewModel.studentNameInput.value.isBlank()) {
                                viewModel.studentNameInput.value = name
                                nameImported = true
                            }
                        }
                    }
                    
                    if (phone.isNotEmpty()) {
                        val cleanedPhone = phone.replace(Regex("[^0-9+]"), "").trim()
                        val startsWithYemen = cleanedPhone.startsWith("+967") || 
                                              cleanedPhone.startsWith("967") || 
                                              cleanedPhone.startsWith("00967")
                                              
                        if (startsWithYemen) {
                            var finalPhone = cleanedPhone
                            if (finalPhone.startsWith("00967")) {
                                finalPhone = "+" + finalPhone.substring(2)
                            } else if (finalPhone.startsWith("967")) {
                                finalPhone = "+$finalPhone"
                            }
                            if (contactPickerForEdit) {
                                editStudentPhoneInput = finalPhone
                                Toast.makeText(context, "تم تحديث رقم الهاتف بنجاح 📱", Toast.LENGTH_SHORT).show()
                            } else {
                                viewModel.studentPhoneInput.value = finalPhone
                                if (nameImported) {
                                    Toast.makeText(context, "تم استيراد الاسم ورقم الهاتف بنجاح 👤📱", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "تم استيراد رقم الهاتف بنجاح 📱", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            var localPart = cleanedPhone
                            if (localPart.startsWith("00")) {
                                localPart = localPart.substring(2)
                            }
                            if (localPart.startsWith("+")) {
                                localPart = localPart.substring(1)
                            }
                            if (localPart.startsWith("0")) {
                                localPart = localPart.substring(1)
                            }
                            val suggestedNumber = "+967$localPart"
                            if (contactPickerForEdit) {
                                editStudentPhoneInput = suggestedNumber
                                Toast.makeText(context, "تم تحديث رقم الهاتف بنجاح: $suggestedNumber 📱", Toast.LENGTH_SHORT).show()
                            } else {
                                manualPhoneToEdit = suggestedNumber
                                showManualPhoneDialog = true
                            }
                        }
                    } else {
                        Toast.makeText(context, "لا يوجد رقم هاتف مسجل لجهة الاتصال هذه.", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "خطأ أثناء قراءة جهة الاتصال: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    )

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            if (isGranted) {
                contactPickerLauncher.launch(null)
            } else {
                Toast.makeText(context, "يجب منح صلاحية الوصول لجهات الاتصال لاستيراد رقم الطالب.", Toast.LENGTH_LONG).show()
            }
        }
    )

    val courseStudents = if (selectedCourse != null) {
        dbAllStudents.filter { it.courseId == selectedCourse!!.id }
    } else {
        emptyList()
    }

    val filteredCourseStudents = remember(courseStudents, studentSearchQuery, studentStatusFilter, selectedCourse) {
        val isCourseCompleted = selectedCourse?.isCompleted == true
        courseStudents.filter { s ->
            val matchesSearch = studentSearchQuery.isBlank() ||
                s.name.contains(studentSearchQuery.trim(), ignoreCase = true) ||
                s.phoneNumber.contains(studentSearchQuery.trim())
            val effectiveStatus = when {
                s.status == "خريج" -> "خريج"
                (s.status == "مستمر" || s.status.isBlank()) && isCourseCompleted -> "خريج"
                s.status.isBlank() -> "مستمر"
                else -> s.status
            }
            val matchesStatus = when (studentStatusFilter) {
                "مستمر" -> effectiveStatus == "مستمر"
                "خريج" -> effectiveStatus == "خريج"
                "توقيف قيد" -> effectiveStatus == "توقيف قيد"
                "منسحب" -> effectiveStatus == "منسحب"
                else -> true
            }
            matchesSearch && matchesStatus
        }
    }

    MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->
        if (showEditStudentConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showEditStudentConfirmDialog = false },
                title = {
                    Text(
                        text = "تأكيد تعديل بيانات الطالب 👤",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = DawamiNavy
                    )
                },
                text = {
                    Text(
                        text = "هل أنت متأكد من رغبتك في حفظ التعديلات الجديدة لبيانات الطالب '${studentToEdit?.name}'؟",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.updateStudentDetails(studentToEdit!!, editStudentNameInput, editStudentPhoneInput)
                            Toast.makeText(context, "تم تحديث بيانات الطالب وسجلاته بنجاح! ✨", Toast.LENGTH_SHORT).show()
                            showEditStudentDialog = false
                            showEditStudentConfirmDialog = false
                        }
                    ) {
                        Text("تأكيد وحفظ", color = DawamiNavy, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showEditStudentConfirmDialog = false }
                    ) {
                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                shape = RoundedCornerShape(10.dp),
                containerColor = MaterialTheme.colorScheme.surface
            )
        }
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.School, contentDescription = null, tint = DawamiNavy)
                            Text("إدارة طلاب الدورة", color = DawamiNavy, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        Text(
                            text = "اختر الدورة التدريبية ثم قم بإضافة الطلاب وتحديث بياناتهم.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )

                        ExposedDropdownMenuBox(
                            expanded = isCourseDropdownExpanded,
                            onExpandedChange = { isCourseDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = selectedCourse?.name ?: "الرجاء اختيار الدورة",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("اختر الدورة التدريبية", fontSize = 11.sp) },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCourseDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = isCourseDropdownExpanded,
                                onDismissRequest = { isCourseDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                            )
                                            Icon(
                                                imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = null,
                                                tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.toggleShowCompletedCoursesInDropdowns()
                                    }
                                )
                                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                                val displayedCourses = if (showCompletedCourses) dbCourses else dbCourses.filter { !it.isCompleted }
                                displayedCourses.forEach { course ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = if (course.isCompleted) "${course.name} (منتهية 🔒)" else course.name,
                                                fontSize = 11.sp,
                                                color = if (course.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                            )
                                        },
                                        onClick = {
                                            viewModel.selectCourseForStudents(course)
                                            isCourseDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        if (selectedCourse != null) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = Color(0xFFE2E8F0))

                            Text(
                                "إضافة طالب جديد 👤",
                                color = DawamiNavy,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )

                            OutlinedTextField(
                                value = studentName,
                                onValueChange = { viewModel.studentNameInput.value = it },
                                label = { Text("اسم الطالب", fontSize = 11.sp) },
                                placeholder = { Text("مثال: محمد أحمد علي", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                singleLine = true
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = studentPhoneInput,
                                    onValueChange = { viewModel.studentPhoneInput.value = it },
                                    label = { Text("رقم الهاتف (اختياري)", fontSize = 11.sp) },
                                    placeholder = { Text("مثال: +967775379042", fontSize = 11.sp) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                                )

                                Button(
                                    onClick = {
                                        contactPickerForEdit = false
                                        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                                            contactPickerLauncher.launch(null)
                                        } else {
                                            permissionLauncher.launch(android.Manifest.permission.READ_CONTACTS)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContactPhone,
                                        contentDescription = "استيراد من جهات الاتصال",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("جهات الاتصال", fontSize = 10.sp, color = Color.White)
                                }
                            }

                            Button(
                                onClick = {
                                    if (studentName.isNotBlank()) {
                                        viewModel.addStudent()
                                    } else {
                                        Toast.makeText(context, "يرجى إدخال اسم الطالب!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("إضافة الطالب", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            if (selectedCourse == null) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = Color(0xFFCBD5E1),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "الرجاء اختيار الدورة التدريبية لعرض الطلاب",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            } else if (courseStudents.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.PeopleOutline,
                                contentDescription = null,
                                tint = Color(0xFFCBD5E1),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "لا يوجد طلاب مسجلين في هذه الدورة حالياً",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            } else {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp, bottom = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Header Title with Count
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "قائمة الطلاب المسجلين (${filteredCourseStudents.size} من أصل ${courseStudents.size})",
                                color = DawamiNavy,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Search Bar
                        OutlinedTextField(
                            value = studentSearchQuery,
                            onValueChange = { studentSearchQuery = it },
                            placeholder = { Text("ابحث عن طالب بالاسم أو رقم الهاتف...", fontSize = 11.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
                            },
                            trailingIcon = {
                                if (studentSearchQuery.isNotBlank()) {
                                    IconButton(onClick = { studentSearchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "مسح البحث", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )

                        // Status Filter Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val statusList = listOf("الكل", "مستمر", "خريج", "توقيف قيد", "منسحب")
                            statusList.forEach { st ->
                                FilterChip(
                                    selected = studentStatusFilter == st,
                                    onClick = { studentStatusFilter = st },
                                    label = { Text(st, fontSize = 10.sp) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = DawamiNavy,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }

                if (filteredCourseStudents.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("لا توجد نتائج مطابقة للبحث أو التصفية", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                } else {
                    items(filteredCourseStudents, key = { it.id }) { student ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    studentFor360 = student
                                    showStudent360Dialog = true
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // 1. Student Header Row (Avatar + Name + Status + Details)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = DawamiNavy.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.size(42.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Person, contentDescription = null, tint = DawamiNavy)
                                        }
                                    }

                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = student.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.5.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )

                                            // Status Badge
                                            val effectiveStatus = when {
                                                student.status == "خريج" -> "خريج"
                                                selectedCourse?.isCompleted == true && (student.status == "مستمر" || student.status.isBlank()) -> "خريج"
                                                student.status.isBlank() -> "مستمر"
                                                else -> student.status
                                            }
                                            val statusColor = when (effectiveStatus) {
                                                "مستمر" -> Color(0xFF137333)
                                                "خريج" -> Color(0xFF0D9488)
                                                "توقيف قيد" -> Color(0xFFB06000)
                                                "منسحب" -> Color(0xFFC5221F)
                                                else -> Color(0xFF137333)
                                            }
                                            val statusBg = when (effectiveStatus) {
                                                "مستمر" -> Color(0xFFE6F4EA)
                                                "خريج" -> Color(0xFFCCFBF1)
                                                "توقيف قيد" -> Color(0xFFFEF7E0)
                                                "منسحب" -> Color(0xFFFCE8E6)
                                                else -> Color(0xFFE6F4EA)
                                            }
                                            Surface(
                                                color = statusBg,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                val displayStatus = if (student.statusChangeDate.isNotBlank() && (effectiveStatus == "توقيف قيد" || effectiveStatus == "منسحب")) {
                                                    "$effectiveStatus (${student.statusChangeDate})"
                                                } else if (effectiveStatus == "خريج") {
                                                    "خريج 🎓"
                                                } else {
                                                    effectiveStatus
                                                }
                                                Text(
                                                    text = displayStatus,
                                                    color = statusColor,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }

                                        // Course Name & Phone Number
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            if (student.courseName.isNotBlank()) {
                                                Text(
                                                    text = "📚 ${student.courseName}",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Phone,
                                                    contentDescription = null,
                                                    tint = if (student.phoneNumber.isNotBlank()) DawamiNavy else Color.Gray,
                                                    modifier = Modifier.size(11.dp)
                                                )
                                                Text(
                                                    text = if (student.phoneNumber.isNotBlank()) student.phoneNumber else "لا يوجد رقم هاتف",
                                                    fontSize = 10.5.sp,
                                                    color = if (student.phoneNumber.isNotBlank()) DawamiNavy else Color.Gray,
                                                    fontWeight = if (student.phoneNumber.isNotBlank()) FontWeight.Medium else FontWeight.Normal,
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                    }
                                }

                                // Subtle divider
                                HorizontalDivider(
                                    thickness = 0.6.dp,
                                    color = Color(0xFFF1F5F9)
                                )

                                // 2. Action Icons Bar
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = {
                                            studentFor360 = student
                                            showStudent360Dialog = true
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AssignmentInd,
                                            contentDescription = "الملف الشامل 360°",
                                            tint = DawamiGold,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            studentForAttendanceMovement = student
                                            showStudentAttendanceMovementDialog = true
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.EventNote,
                                            contentDescription = "سجل حركات الحضور بالمواد",
                                            tint = DawamiTeal,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            studentForStatusManagement = student
                                            showStatusManagementDialog = true
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ManageAccounts,
                                            contentDescription = "إدارة شؤون الطالب",
                                            tint = Color(0xFF0284C7),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            studentToEdit = student
                                            editStudentNameInput = student.name
                                            editStudentPhoneInput = student.phoneNumber
                                            contactPickerForEdit = true
                                            showEditStudentDialog = true
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "تعديل الاسم والهاتف", tint = DawamiNavy, modifier = Modifier.size(19.dp))
                                    }
                                    IconButton(
                                        onClick = {
                                            studentToDelete = student
                                            showDeleteStudentConfirmDialog = true
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
 
                            if (showEditStudentDialog && studentToEdit?.id == student.id) {
                                AlertDialog(
                                    onDismissRequest = { showEditStudentDialog = false },
                                    title = {
                                        Text(
                                            text = "تعديل بيانات الطالب 📝",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = DawamiNavy
                                        )
                                    },
                                    text = {
                                        Column(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text("قم بتعديل بيانات الطالب أدناه وسيقوم النظام بتحديث كافة السجلات والدرجات المرتبطة به تلقائياً.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            OutlinedTextField(
                                                value = editStudentNameInput,
                                                onValueChange = { editStudentNameInput = it },
                                                label = { Text("اسم الطالب الجديد") },
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(12.dp),
                                                singleLine = true
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                OutlinedTextField(
                                                    value = editStudentPhoneInput,
                                                    onValueChange = { editStudentPhoneInput = it },
                                                    label = { Text("رقم هاتف الطالب") },
                                                    placeholder = { Text("مثال: +967775379042") },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(12.dp),
                                                    singleLine = true,
                                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                                                )
                                                Button(
                                                    onClick = {
                                                        contactPickerForEdit = true
                                                        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                                                            contactPickerLauncher.launch(null)
                                                        } else {
                                                            permissionLauncher.launch(android.Manifest.permission.READ_CONTACTS)
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                                    shape = RoundedCornerShape(10.dp),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ContactPhone,
                                                        contentDescription = "تحميل جهة الاتصال",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("تحميل جهة الاتصال", fontSize = 10.sp, color = Color.White)
                                                }
                                            }
                                        }
                                    },
                                    confirmButton = {
                                        TextButton(
                                            onClick = {
                                                if (editStudentNameInput.isNotBlank()) {
                                                    showEditStudentConfirmDialog = true
                                                    if (!showEditStudentConfirmDialog) Toast.makeText(context, "تم تحديث بيانات الطالب وسجلاته بنجاح!", Toast.LENGTH_SHORT).show(); if (showEditStudentConfirmDialog) { /* do nothing */ } else
                                                    showEditStudentDialog = false
                                                } else {
                                                    Toast.makeText(context, "الرجاء إدخال اسم صحيح!", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        ) {
                                            Text("حفظ", color = DawamiNavy, fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    dismissButton = {
                                        TextButton(
                                            onClick = { showEditStudentDialog = false }
                                        ) {
                                            Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            }




                            if (showDeleteStudentConfirmDialog && studentToDelete?.id == student.id) {
                                AlertDialog(
                                    onDismissRequest = { showDeleteStudentConfirmDialog = false },
                                    title = {
                                        Text(
                                            text = "تأكيد حذف الطالب 🗑️",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = DawamiNavy
                                        )
                                    },
                                    text = {
                                        Text(
                                            text = "هل أنت متأكد من حذف الطالب '${studentToDelete?.name}' وكافة سجلات الحضور والغياب والدرجات الخاصة به نهائياً؟ لا يمكن التراجع عن هذا الإجراء.",
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    confirmButton = {
                                        TextButton(
                                            onClick = {
                                                viewModel.deleteStudent(studentToDelete!!)
                                                Toast.makeText(context, "تم حذف الطالب وسجلاته بنجاح!", Toast.LENGTH_SHORT).show()
                                                showDeleteStudentConfirmDialog = false
                                            }
                                        ) {
                                            Text("نعم، احذف", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    dismissButton = {
                                        TextButton(
                                            onClick = { showDeleteStudentConfirmDialog = false }
                                        ) {
                                            Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showStatusManagementDialog && studentForStatusManagement != null) {
        val student = studentForStatusManagement!!
        var selectedStatus by remember { mutableStateOf(student.status) }
        var targetCourseId by remember { mutableStateOf<Int?>(null) }
        var isTransferCourseDropdownExpanded by remember { mutableStateOf(false) }
        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH).format(java.util.Date())
        var statusChangeDate by remember { mutableStateOf(todayStr) }
        var showStatusDatePicker by remember { mutableStateOf(false) }
        var showStatusChangeConfirmDialog by remember { mutableStateOf(false) }
        var futureAttendanceRecords by remember { mutableStateOf<List<com.example.data.entity.StudentAttendance>>(emptyList()) }
        var isSmartDateSuggested by remember { mutableStateOf(false) }
        var smartDateMessage by remember { mutableStateOf("") }
        
        LaunchedEffect(selectedStatus) {
            if (selectedStatus != student.status && (selectedStatus == "توقيف قيد" || selectedStatus == "منسحب")) {
                val latestAttendance = dbAllStudentAttendance
                    .filter { it.studentId == student.id && it.status == "حضور" }
                    .maxByOrNull { it.date }
                if (latestAttendance != null) {
                    statusChangeDate = latestAttendance.date
                    isSmartDateSuggested = true
                    smartDateMessage = "النظام الذكي: لقد وجدنا أن آخر يوم حضور فعلي للطالب كان بتاريخ (${latestAttendance.date}). تم تعيينه تلقائياً كتاريخ للتوقيف."
                } else {
                    statusChangeDate = todayStr
                    isSmartDateSuggested = true
                    smartDateMessage = "النظام الذكي: لا يوجد سجل حضور سابق للطالب، تم تحديد تاريخ اليوم افتراضياً."
                }
            } else {
                statusChangeDate = todayStr
                isSmartDateSuggested = false
            }
        }

        // المواد المشتركة بين دورة الطالب الحالية والدورة المستهدفة للنقل
        val studentOldCourseSubjects = remember(
            student.courseId,
            student.id,
            viewModel.dbCourseSubjects.value,
            viewModel.dbSubjects.value,
            viewModel.dbAllStudentAttendance.value,
            viewModel.dbAllGrades.value
        ) {
            val fromCrossRef = viewModel.dbCourseSubjects.value
                .filter { it.courseId == student.courseId }
                .mapNotNull { cs -> viewModel.dbSubjects.value.find { it.id == cs.subjectId }?.name }

            val fromAttendance = viewModel.dbAllStudentAttendance.value
                .filter { it.studentId == student.id && it.courseId == student.courseId }
                .map { it.subjectName.trim().ifEmpty { "عام" } }

            val fromGrades = viewModel.dbAllGrades.value
                .filter { it.studentId == student.id && it.courseId == student.courseId }
                .map { it.subjectName.trim().ifEmpty { "عام" } }

            (fromCrossRef + fromAttendance + fromGrades)
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .distinct()
                .sorted()
        }

        // حساب المواد المشتركة فقط مع الدورة المستهدفة
        val commonSubjectsWithTarget = remember(studentOldCourseSubjects, targetCourseId, viewModel.dbCourseSubjects.value, viewModel.dbSubjects.value, viewModel.dbAllGradeConfigs.value) {
            if (targetCourseId == null) emptyList<String>()
            else {
                val targetSubjectsFromCrossRef = viewModel.dbCourseSubjects.value
                    .filter { it.courseId == targetCourseId }
                    .mapNotNull { cs -> viewModel.dbSubjects.value.find { it.id == cs.subjectId }?.name?.trim() }

                val targetGradeConfig = viewModel.dbAllGradeConfigs.value.find { it.courseId == targetCourseId }
                val targetSubjectsFromConfig = if (targetGradeConfig != null) {
                    if (targetGradeConfig.isDiploma) targetGradeConfig.getDiplomaSubjects().map { it.trim() }
                    else StudentGradeConfig.deserializeFields(targetGradeConfig.customFieldsJson).map { it.first.substringBefore("_").trim() }.distinct()
                } else emptyList()

                val allTargetSubjects = (targetSubjectsFromCrossRef + targetSubjectsFromConfig).distinct()
                studentOldCourseSubjects.filter { oldSubj ->
                    allTargetSubjects.any { it.equals(oldSubj, ignoreCase = true) }
                }
            }
        }

        // خيار النقل: "CUSTOM" (نقل مواد محددة وتصفير الباقي) أو "RESET_ALL" (تصفير كامل الدرجات والحضور)
        var transferMode by remember { mutableStateOf("CUSTOM") } // "CUSTOM" or "RESET_ALL"
        val subjectsSelectedToTransfer = remember { mutableStateMapOf<String, Boolean>() }

        // عند تغيير المواد المشتركة، تفعيل نقلها افتراضياً
        LaunchedEffect(commonSubjectsWithTarget) {
            subjectsSelectedToTransfer.clear()
            commonSubjectsWithTarget.forEach { subj ->
                subjectsSelectedToTransfer[subj] = true
            }
        }

        AlertDialog(
            onDismissRequest = {
                showStatusManagementDialog = false
                studentForStatusManagement = null
            },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ManageAccounts,
                        contentDescription = null,
                        tint = DawamiNavy
                    )
                    Text(
                        text = "إدارة شؤون الطالب",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "الطالب: ${student.name}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Section 1: Update status
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "تعديل حالة القيد والانتظام:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = DawamiNavy
                        )
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val statuses = listOf("مستمر", "خريج", "توقيف قيد", "منسحب")
                            statuses.forEach { status ->
                                val isSelected = selectedStatus == status
                                val bg = if (isSelected) {
                                    when (status) {
                                        "مستمر" -> Color(0xFFE6F4EA)
                                        "خريج" -> Color(0xFFCCFBF1)
                                        "توقيف قيد" -> Color(0xFFFEF7E0)
                                        "منسحب" -> Color(0xFFFCE8E6)
                                        else -> DawamiNavy.copy(alpha = 0.1f)
                                    }
                                } else Color.Transparent
                                val borderCol = if (isSelected) {
                                    when (status) {
                                        "مستمر" -> Color(0xFF137333)
                                        "خريج" -> Color(0xFF0D9488)
                                        "توقيف قيد" -> Color(0xFFB06000)
                                        "منسحب" -> Color(0xFFC5221F)
                                        else -> DawamiNavy
                                    }
                                } else Color.LightGray

                                val txtCol = if (isSelected) {
                                    when (status) {
                                        "مستمر" -> Color(0xFF137333)
                                        "خريج" -> Color(0xFF0D9488)
                                        "توقيف قيد" -> Color(0xFFB06000)
                                        "منسحب" -> Color(0xFFC5221F)
                                        else -> DawamiNavy
                                    }
                                } else Color.Gray

                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { selectedStatus = status },
                                    color = bg,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, borderCol)
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = status,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = txtCol
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Show Date Picker for Status Change if needed
                    val showDatePicker = (selectedStatus == "توقيف قيد" || selectedStatus == "منسحب") && selectedStatus != student.status
                    if (showDatePicker) {
                        if (isSmartDateSuggested) {
                            Surface(
                                color = Color(0xFFF0FDF4),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF166534), modifier = Modifier.size(20.dp))
                                    Text(
                                        text = smartDateMessage,
                                        fontSize = 11.sp,
                                        color = Color(0xFF166534),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "تاريخ التغيير (سيبدأ مسح الحركات المسجلة من اليوم التالي):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = DawamiNavy
                        )
                        OutlinedTextField(
                            value = statusChangeDate,
                            onValueChange = {},
                            modifier = Modifier.fillMaxWidth().clickable { showStatusDatePicker = true },
                            readOnly = true,
                            enabled = false,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = Color.Gray
                            ),
                            trailingIcon = {
                                IconButton(onClick = { showStatusDatePicker = true }) {
                                    Icon(Icons.Default.CalendarToday, contentDescription = "اختيار التاريخ", tint = DawamiNavy)
                                }
                            }
                        )
                        if (showStatusDatePicker) {
                            val cal = java.util.Calendar.getInstance()
                            android.app.DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val fMonth = String.format("%02d", m + 1)
                                    val fDay = String.format("%02d", d)
                                    statusChangeDate = "$y-$fMonth-$fDay"
                                    showStatusDatePicker = false
                                },
                                cal.get(java.util.Calendar.YEAR),
                                cal.get(java.util.Calendar.MONTH),
                                cal.get(java.util.Calendar.DAY_OF_MONTH)
                            ).apply {
                                setOnDismissListener { showStatusDatePicker = false }
                            }.show()
                        }
                    }

                    HorizontalDivider(color = Color(0xFFE2E8F0))

                    // Section 2: Course transfer
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "نقل الطالب إلى دورة أخرى:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = DawamiNavy
                        )

                        Text(
                            text = "حدد الدورة الجديدة وخيارات تصفير الحضور أو الدرجات لمواد الدورة الحالية.",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        ExposedDropdownMenuBox(
                            expanded = isTransferCourseDropdownExpanded,
                            onExpandedChange = { isTransferCourseDropdownExpanded = it }
                        ) {
                            val selectedTargetCourseName = dbCourses.find { it.id == targetCourseId }?.name ?: "اختر الدورة المستهدفة..."
                            OutlinedTextField(
                                value = selectedTargetCourseName,
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTransferCourseDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = TextStyle(fontSize = 11.sp),
                                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                            )

                            ExposedDropdownMenu(
                                expanded = isTransferCourseDropdownExpanded,
                                onDismissRequest = { isTransferCourseDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                            )
                                            Icon(
                                                imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = null,
                                                tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.toggleShowCompletedCoursesInDropdowns()
                                    }
                                )
                                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                                val displayedCourses = if (showCompletedCourses) dbCourses else dbCourses.filter { !it.isCompleted }
                                displayedCourses.filter { it.id != student.courseId }.forEach { course ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = if (course.isCompleted) "${course.name} (منتهية 🔒)" else course.name,
                                                fontSize = 11.sp,
                                                color = if (course.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                            )
                                        },
                                        onClick = {
                                            targetCourseId = course.id
                                            isTransferCourseDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // إذا تم اختيار دورة مستهدفة، نظهر خيارات نقل الدرجات والحضور للمواد المشتركة فقط
                        if (targetCourseId != null) {
                            val targetCourse = dbCourses.find { it.id == targetCourseId }
                            Spacer(modifier = Modifier.height(6.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SwapHoriz,
                                            contentDescription = null,
                                            tint = DawamiNavy,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "خيارات ترحيل الدرجات والحضور للدورة المستهدفة:",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = DawamiNavy
                                        )
                                    }

                                    // الخيارين الرئيسيين:
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        // الخيار 1: نقل مخصص مع اختيار المواد المشتركة
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (transferMode == "CUSTOM") DawamiTeal.copy(alpha = 0.08f) else Color.Transparent)
                                                .clickable { transferMode = "CUSTOM" }
                                                .padding(horizontal = 6.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected = transferMode == "CUSTOM",
                                                onClick = { transferMode = "CUSTOM" },
                                                colors = RadioButtonDefaults.colors(selectedColor = DawamiTeal),
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Column {
                                                Text(
                                                    text = "نقل درجات وحضور المواد المشتركة المحددة 📑",
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (transferMode == "CUSTOM") DawamiTeal else MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "تُنقل درجات وحضور المواد المحددة، ويتم تصفير باقي المواد في الدورة الجديدة.",
                                                    fontSize = 9.sp,
                                                    color = Color.Gray
                                                )
                                            }
                                        }

                                        // الخيار 2: تصفير كامل الدرجات والحضور
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (transferMode == "RESET_ALL") Color(0xFFEF4444).copy(alpha = 0.08f) else Color.Transparent)
                                                .clickable { transferMode = "RESET_ALL" }
                                                .padding(horizontal = 6.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected = transferMode == "RESET_ALL",
                                                onClick = { transferMode = "RESET_ALL" },
                                                colors = RadioButtonDefaults.colors(selectedColor = Color(0xFFEF4444)),
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Column {
                                                Text(
                                                    text = "تصفير كامل الدرجات والحضور (البدء من الصفر) 🗑️",
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (transferMode == "RESET_ALL") Color(0xFFDC2626) else MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "يبدأ الطالب الدورة الجديدة بسجل أبيض خالٍ من أي درجات أو غياب سابق.",
                                                    fontSize = 9.sp,
                                                    color = Color.Gray
                                                )
                                            }
                                        }
                                    }

                                    // إذا تم اختيار النقل المخصص، نعرض قائمة المواد المشتركة فقط
                                    if (transferMode == "CUSTOM") {
                                        HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp), color = Color(0xFFE2E8F0))
                                        
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "المواد المشتركة بين الدورتين (${commonSubjectsWithTarget.size} مواد):",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = DawamiNavy
                                            )
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(
                                                    text = "تحديد الكل",
                                                    fontSize = 9.5.sp,
                                                    color = DawamiTeal,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .clickable {
                                                            commonSubjectsWithTarget.forEach { subjectsSelectedToTransfer[it] = true }
                                                        }
                                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                                Text("•", fontSize = 9.5.sp, color = Color.Gray)
                                                Text(
                                                    text = "إلغاء الكل",
                                                    fontSize = 9.5.sp,
                                                    color = Color.Gray,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .clickable {
                                                            commonSubjectsWithTarget.forEach { subjectsSelectedToTransfer[it] = false }
                                                        }
                                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }

                                        if (commonSubjectsWithTarget.isEmpty()) {
                                            Text(
                                                text = "لا توجد مواد مشتركة مسماة بين دورة [${student.courseName}] والدورة المستهدفة [${targetCourse?.name ?: ""}]. سيتم إلحاق الطالب بالمواد الجديدة فارغة.",
                                                fontSize = 9.5.sp,
                                                color = Color(0xFFD97706),
                                                modifier = Modifier.padding(vertical = 4.dp)
                                            )
                                        } else {
                                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                commonSubjectsWithTarget.forEach { subjName ->
                                                    val isChecked = subjectsSelectedToTransfer[subjName] ?: true
                                                    Surface(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clickable {
                                                                subjectsSelectedToTransfer[subjName] = !isChecked
                                                            },
                                                        color = if (isChecked) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                                                        shape = RoundedCornerShape(6.dp),
                                                        border = BorderStroke(0.5.dp, if (isChecked) DawamiTeal.copy(alpha = 0.5f) else Color(0xFFE2E8F0))
                                                    ) {
                                                        Row(
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .padding(horizontal = 8.dp, vertical = 6.dp),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Row(
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                modifier = Modifier.weight(1f)
                                                            ) {
                                                                Checkbox(
                                                                    checked = isChecked,
                                                                    onCheckedChange = { subjectsSelectedToTransfer[subjName] = it },
                                                                    modifier = Modifier.size(22.dp)
                                                                )
                                                                Spacer(modifier = Modifier.width(6.dp))
                                                                Text(
                                                                    text = subjName,
                                                                    fontSize = 10.5.sp,
                                                                    fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal,
                                                                    color = MaterialTheme.colorScheme.onSurface
                                                                )
                                                            }
                                                            Surface(
                                                                color = if (isChecked) DawamiTeal.copy(alpha = 0.1f) else Color.LightGray.copy(alpha = 0.2f),
                                                                shape = RoundedCornerShape(4.dp)
                                                            ) {
                                                                Text(
                                                                    text = if (isChecked) "نقل الدرجات والحضور ✅" else "تصفير في الدورة الجديدة ⚪",
                                                                    fontSize = 8.5.sp,
                                                                    fontWeight = FontWeight.SemiBold,
                                                                    color = if (isChecked) DawamiTeal else Color.Gray,
                                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val executeSave = {
                            // 1. Process Status change
                            if (selectedStatus != student.status) {
                                viewModel.updateStudentStatus(student, selectedStatus, statusChangeDate)
                                Toast.makeText(context, "تم تحديث حالة قيد الطالب بنجاح! 💾", Toast.LENGTH_SHORT).show()
                            }
                            
                            // 2. Process Course Transfer
                            if (targetCourseId != null) {
                                val targetCourse = dbCourses.find { it.id == targetCourseId }
                                if (targetCourse != null) {
                                    val (attResetSet, grdResetSet) = if (transferMode == "RESET_ALL") {
                                        // تصفير جميع المواد المسجلة للطالب
                                        val allOldSubjs = studentOldCourseSubjects.toSet()
                                        Pair(allOldSubjs, allOldSubjs)
                                    } else {
                                        // في النقل المخصص: المواد المشتركة التي تم إلغاء تحديدها + المواد غير المشتركة يتم تصفيرها
                                        val unselectedCommons = commonSubjectsWithTarget.filter { subjectsSelectedToTransfer[it] == false }.toSet()
                                        val nonCommons = studentOldCourseSubjects.filter { oldSubj ->
                                            !commonSubjectsWithTarget.any { it.equals(oldSubj, ignoreCase = true) }
                                        }.toSet()
                                        val subjectsToReset = unselectedCommons + nonCommons
                                        Pair(subjectsToReset, subjectsToReset)
                                    }

                                    viewModel.transferStudentToCourse(
                                        studentId = student.id,
                                        newCourseId = targetCourse.id,
                                        newCourseName = targetCourse.name,
                                        attendanceResetSubjects = attResetSet,
                                        gradesResetSubjects = grdResetSet
                                    )
                                    Toast.makeText(context, "تم نقل الطالب إلى دورة ${targetCourse.name} بنجاح! 🚀", Toast.LENGTH_LONG).show()
                                }
                            }

                            showStatusManagementDialog = false
                            studentForStatusManagement = null
                        }

                        if (selectedStatus != student.status && (selectedStatus == "توقيف قيد" || selectedStatus == "منسحب")) {
                            val futureRecords = dbAllStudentAttendance.filter { att ->
                                att.studentId == student.id && att.date > statusChangeDate
                            }
                            if (futureRecords.isNotEmpty()) {
                                futureAttendanceRecords = futureRecords
                                showStatusChangeConfirmDialog = true
                            } else {
                                executeSave()
                            }
                        } else {
                            executeSave()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ التغييرات 💾", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showStatusManagementDialog = false
                        studentForStatusManagement = null
                    }
                ) {
                    Text("إلغاء", color = Color.Gray, fontSize = 11.sp)
                }
            },
            shape = RoundedCornerShape(12.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
        if (showStatusChangeConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showStatusChangeConfirmDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFC5221F))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تنبيه: مسح الحركات المترتبة على تغيير الحالة", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DawamiNavy)
                    }
                },
                text = {
                    Text(
                        """لقد قمت بتغيير حالة الطالب (${student.name}) إلى ($selectedStatus) بتاريخ $statusChangeDate.

توجد عدد (${futureAttendanceRecords.size}) حركات مسجلة للطالب في تواريخ لاحقة بعد هذا التاريخ.

سيتم مسح جميع الحركات والدرجات المسجلة بعد تاريخ ($statusChangeDate) تلقائياً لضمان دقة السجلات.""",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            // Delete the future attendance records
                            viewModel.deleteStudentAttendanceRecordBulk(futureAttendanceRecords)
                            
                            // Process Status change
                            viewModel.updateStudentStatus(student, selectedStatus, statusChangeDate)
                            
                            // Process Course Transfer if any
                            if (targetCourseId != null) {
                                val targetCourse = dbCourses.find { it.id == targetCourseId }
                                if (targetCourse != null) {
                                    val (attResetSet, grdResetSet) = if (transferMode == "RESET_ALL") {
                                        val allOldSubjs = studentOldCourseSubjects.toSet()
                                        Pair(allOldSubjs, allOldSubjs)
                                    } else {
                                        val unselectedCommons = commonSubjectsWithTarget.filter { subjectsSelectedToTransfer[it] == false }.toSet()
                                        val nonCommons = studentOldCourseSubjects.filter { oldSubj ->
                                            !commonSubjectsWithTarget.any { it.equals(oldSubj, ignoreCase = true) }
                                        }.toSet()
                                        val subjectsToReset = unselectedCommons + nonCommons
                                        Pair(subjectsToReset, subjectsToReset)
                                    }
                                    viewModel.transferStudentToCourse(
                                        studentId = student.id,
                                        newCourseId = targetCourse.id,
                                        newCourseName = targetCourse.name,
                                        attendanceResetSubjects = attResetSet,
                                        gradesResetSubjects = grdResetSet
                                    )
                                }
                            }
                            
                            Toast.makeText(context, "تم تغيير حالة الطالب ومسح (${futureAttendanceRecords.size}) حركات بنجاح 🔄", Toast.LENGTH_LONG).show()
                            showStatusChangeConfirmDialog = false
                            showStatusManagementDialog = false
                            studentForStatusManagement = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC5221F))
                    ) {
                        Text("تأكيد ومسح الحركات اللاحقة 🗑️", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showStatusChangeConfirmDialog = false }) {
                        Text("إلغاء التعديل ✖️", color = DawamiNavy, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                },
                containerColor = Color(0xFFFEF2F2)
            )
        }

    }

    if (showManualPhoneDialog) {
        AlertDialog(
            onDismissRequest = { showManualPhoneDialog = false },
            title = {
                Text(
                    text = "تأكيد رقم هاتف الطالب 📞",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "تم جلب رقم هاتف غير مضاف إليه مفتاح اليمن الدولي (+967). الرجاء التحقق من الرقم وتأكيده أدناه:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = manualPhoneToEdit,
                        onValueChange = { manualPhoneToEdit = it },
                        label = { Text("رقم الهاتف") },
                        placeholder = { Text("مثال: +967775379042") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (manualPhoneToEdit.isNotBlank()) {
                            viewModel.studentPhoneInput.value = manualPhoneToEdit
                            showManualPhoneDialog = false
                            Toast.makeText(context, "تم تحديد الرقم المقترح بنجاح!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "الرجاء إدخال رقم هاتف صحيح!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("تأكيد وحفظ", color = DawamiNavy, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showManualPhoneDialog = false }
                ) {
                    Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            shape = RoundedCornerShape(10.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }


        if (showStudentAttendanceMovementDialog && studentForAttendanceMovement != null) {
        StudentAttendanceMovementDialog(
            viewModel = viewModel,
            student = studentForAttendanceMovement!!,
            onDismiss = {
                showStudentAttendanceMovementDialog = false
                studentForAttendanceMovement = null
            }
        )
    }

    if (showStudent360Dialog && studentFor360 != null) {
        Student360Dialog(
            student = studentFor360!!,
            viewModel = viewModel,
            studentViewModel = studentViewModel,
            onDismiss = {
                showStudent360Dialog = false
                studentFor360 = null
            },
            onOpenAttendanceMovement = { st ->
                studentForAttendanceMovement = st
                showStudentAttendanceMovementDialog = true
            },
            onOpenStatusManagement = { st ->
                studentForStatusManagement = st
                showStatusManagementDialog = true
            },
            onOpenEdit = { st ->
                studentToEdit = st
                editStudentNameInput = st.name
                editStudentPhoneInput = st.phoneNumber
                contactPickerForEdit = true
                showEditStudentDialog = true
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentAttendanceMovementDialog(
    viewModel: MainViewModel,
    student: Student,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val dbCourses by viewModel.dbCourses.collectAsState()
    val allAttendance by viewModel.dbAllStudentAttendance.collectAsState()
    val dbSubjects by viewModel.dbSubjects.collectAsState()

    val studentCourse = remember(dbCourses, student.courseId) {
        dbCourses.find { it.id == student.courseId }
    }

    val studentRecords = remember(allAttendance, student.id) {
        allAttendance.filter { it.studentId == student.id }
            .sortedByDescending { it.date }
    }

    // Available subjects for this student / course
    val availableSubjects = remember(studentRecords, dbSubjects, studentCourse) {
        val courseSubs = if (studentCourse != null) {
            dbSubjects.filter { sub ->
                (studentCourse.diplomaName.isNotEmpty() && sub.diplomaName.equals(studentCourse.diplomaName, ignoreCase = true)) ||
                (studentCourse.departmentName.isNotEmpty() && sub.departmentName.equals(studentCourse.departmentName, ignoreCase = true))
            }.map { it.name }
        } else emptyList()
        val recordSubs = studentRecords.map { it.subjectName }.filter { it.isNotBlank() }
        (listOf("جميع المواد") + (courseSubs + recordSubs).distinct()).distinct()
    }

    var selectedSubjectFilter by remember { mutableStateOf("جميع المواد") }
    var isSubjectFilterDropdownExpanded by remember { mutableStateOf(false) }

    // Filtered records
    val filteredRecords = remember(studentRecords, selectedSubjectFilter) {
        if (selectedSubjectFilter == "جميع المواد") {
            studentRecords
        } else {
            studentRecords.filter { it.subjectName.equals(selectedSubjectFilter, ignoreCase = true) }
        }
    }

    val presentCount = remember(filteredRecords) { filteredRecords.count { it.status == "حضور" } }
    val absentCount = remember(filteredRecords) { filteredRecords.count { it.status == "غياب" || it.status == "غائب" } }
    val excusedCount = remember(filteredRecords) { filteredRecords.count { it.status == "مستأذن" } }
    val leaveCount = remember(filteredRecords) { filteredRecords.count { it.status == "إجازة" } }

    // States for Add / Edit Dialog
    var showAddOrEditDialog by remember { mutableStateOf(false) }
    var editingRecord by remember { mutableStateOf<StudentAttendance?>(null) }
    var inputDate by remember { mutableStateOf("") }
    var inputSubject by remember { mutableStateOf("") }
    var inputStatus by remember { mutableStateOf("حضور") }
    var inputCheckIn by remember { mutableStateOf("") }
    var inputCheckOut by remember { mutableStateOf("") }
    var inputNote by remember { mutableStateOf("") }
    var isSubjectInputDropdownExpanded by remember { mutableStateOf(false) }

    // Delete Confirmation State
    var recordToDelete by remember { mutableStateOf<StudentAttendance?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    val courseSubjectsOnly = remember(dbSubjects, studentCourse) {
        val list = if (studentCourse != null) {
            dbSubjects.filter { sub ->
                (studentCourse.diplomaName.isNotEmpty() && sub.diplomaName.equals(studentCourse.diplomaName, ignoreCase = true)) ||
                (studentCourse.departmentName.isNotEmpty() && sub.departmentName.equals(studentCourse.departmentName, ignoreCase = true))
            }.map { it.name }
        } else emptyList()
        list.ifEmpty { listOf("عام") }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = CircleShape,
                    color = DawamiTeal.copy(alpha = 0.15f),
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.EventNote,
                            contentDescription = null,
                            tint = DawamiTeal,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "سجل حركات الحضور بالمواد 📋",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = DawamiNavy
                    )
                    Text(
                        text = "${student.name} • ${studentCourse?.name ?: ""}",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Top control: Subject filter & Add button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Subject filter dropdown
                    ExposedDropdownMenuBox(
                        expanded = isSubjectFilterDropdownExpanded,
                        onExpandedChange = { isSubjectFilterDropdownExpanded = it },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = selectedSubjectFilter,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("تصفية بالمادة", fontSize = 10.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSubjectFilterDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = TextStyle(fontSize = 11.sp)
                        )
                        ExposedDropdownMenu(
                            expanded = isSubjectFilterDropdownExpanded,
                            onDismissRequest = { isSubjectFilterDropdownExpanded = false }
                        ) {
                            availableSubjects.forEach { sub ->
                                DropdownMenuItem(
                                    text = { Text(sub, fontSize = 11.sp) },
                                    onClick = {
                                        selectedSubjectFilter = sub
                                        isSubjectFilterDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Add new movement button
                    Button(
                        onClick = {
                            val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                            editingRecord = null
                            inputDate = today
                            inputSubject = if (selectedSubjectFilter != "جميع المواد") selectedSubjectFilter else courseSubjectsOnly.firstOrNull() ?: "عام"
                            inputStatus = "حضور"
                            inputCheckIn = studentCourse?.startTime ?: ""
                            inputCheckOut = studentCourse?.endTime ?: ""
                            inputNote = ""
                            showAddOrEditDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تسجيل حركة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Summary cards row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        modifier = Modifier.weight(1f),
                        color = DawamiNavy.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("الإجمالي", fontSize = 9.sp, color = Color.Gray)
                            Text("${filteredRecords.size}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        }
                    }
                    Surface(
                        modifier = Modifier.weight(1f),
                        color = Color(0xFF137333).copy(alpha = 0.1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("حضور", fontSize = 9.sp, color = Color(0xFF137333))
                            Text("$presentCount", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF137333))
                        }
                    }
                    Surface(
                        modifier = Modifier.weight(1f),
                        color = Color(0xFFC5221F).copy(alpha = 0.1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("غياب", fontSize = 9.sp, color = Color(0xFFC5221F))
                            Text("$absentCount", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC5221F))
                        }
                    }
                    Surface(
                        modifier = Modifier.weight(1f),
                        color = Color(0xFFB06000).copy(alpha = 0.1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("أخرى", fontSize = 9.sp, color = Color(0xFFB06000))
                            Text("${excusedCount + leaveCount}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB06000))
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFFE2E8F0))

                // Records list
                if (filteredRecords.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.EventBusy, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("لا توجد حركات حضور مسجلة لهذا الفلتر", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredRecords, key = { "${it.id}_${it.date}_${it.subjectName}" }) { record ->
                            val statusBg = when (record.status) {
                                "حضور" -> Color(0xFFE6F4EA)
                                "غياب", "غائب" -> Color(0xFFFCE8E6)
                                "مستأذن" -> Color(0xFFFEF7E0)
                                "إجازة" -> Color(0xFFE8F0FE)
                                else -> Color(0xFFF1F3F4)
                            }
                            val statusColor = when (record.status) {
                                "حضور" -> Color(0xFF137333)
                                "غياب", "غائب" -> Color(0xFFC5221F)
                                "مستأذن" -> Color(0xFFB06000)
                                "إجازة" -> Color(0xFF1A73E8)
                                else -> Color.DarkGray
                            }

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = "${record.date} (${viewModel.getArabicDayOfWeek(record.date)})",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = DawamiNavy
                                            )
                                            Surface(
                                                color = statusBg,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = record.status,
                                                    color = statusColor,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }

                                        if (record.subjectName.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Icon(Icons.Default.MenuBook, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(11.dp))
                                                Text(
                                                    text = "المادة: ${record.subjectName}",
                                                    fontSize = 10.sp,
                                                    color = DawamiTeal,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }

                                        if (record.actualCheckIn.isNotBlank() || record.actualCheckOut.isNotBlank()) {
                                            val inStr = if (record.actualCheckIn.isNotBlank()) formatTimeTo12HourArabic(record.actualCheckIn) else "غير محدد"
                                            val outStr = if (record.actualCheckOut.isNotBlank()) formatTimeTo12HourArabic(record.actualCheckOut) else "لم يسجل"
                                            Text(
                                                text = "دخول: $inStr • خروج: $outStr",
                                                fontSize = 9.5.sp,
                                                color = Color.Gray
                                            )
                                        }

                                        if (record.studentNote.isNotBlank()) {
                                            Text(
                                                text = "ملاحظة: ${record.studentNote}",
                                                fontSize = 9.5.sp,
                                                color = Color(0xFFB06000)
                                            )
                                        }
                                    }

                                    // Action buttons for this record
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(
                                            onClick = {
                                                editingRecord = record
                                                inputDate = record.date
                                                inputSubject = record.subjectName.ifEmpty { courseSubjectsOnly.firstOrNull() ?: "عام" }
                                                inputStatus = record.status
                                                inputCheckIn = record.actualCheckIn
                                                inputCheckOut = record.actualCheckOut
                                                inputNote = record.studentNote
                                                showAddOrEditDialog = true
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Edit,
                                                contentDescription = "تعديل",
                                                tint = DawamiNavy,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        IconButton(
                                            onClick = {
                                                recordToDelete = record
                                                showDeleteConfirmDialog = true
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "حذف",
                                                tint = Color.Red,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
            ) {
                Text("إغلاق", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        },
        shape = RoundedCornerShape(12.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )

    // --- Add / Edit Dialog ---
    if (showAddOrEditDialog) {
        val isEditMode = editingRecord != null
        AlertDialog(
            onDismissRequest = { showAddOrEditDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = if (isEditMode) Icons.Default.Edit else Icons.Default.AddCircle,
                        contentDescription = null,
                        tint = DawamiNavy
                    )
                    Text(
                        text = if (isEditMode) "تعديل حركة حضور ✏️" else "تسجيل حركة حضور جديدة ➕",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Date picker field
                    OutlinedTextField(
                        value = "$inputDate (${viewModel.getArabicDayOfWeek(inputDate)})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("التاريخ", fontSize = 10.sp) },
                        trailingIcon = {
                            IconButton(onClick = {
                                val cal = java.util.Calendar.getInstance()
                                android.app.DatePickerDialog(
                                    context,
                                    { _, y, m, d ->
                                        val fMonth = String.format("%02d", m + 1)
                                        val fDay = String.format("%02d", d)
                                        inputDate = "$y-$fMonth-$fDay"
                                    },
                                    cal.get(java.util.Calendar.YEAR),
                                    cal.get(java.util.Calendar.MONTH),
                                    cal.get(java.util.Calendar.DAY_OF_MONTH)
                                ).show()
                            }) {
                                Icon(Icons.Default.CalendarToday, contentDescription = "اختيار التاريخ", tint = DawamiNavy)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = TextStyle(fontSize = 11.sp)
                    )

                    // Subject dropdown
                    ExposedDropdownMenuBox(
                        expanded = isSubjectInputDropdownExpanded,
                        onExpandedChange = { isSubjectInputDropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = inputSubject,
                            onValueChange = { inputSubject = it },
                            label = { Text("المادة التدريبية", fontSize = 10.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSubjectInputDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = TextStyle(fontSize = 11.sp)
                        )
                        ExposedDropdownMenu(
                            expanded = isSubjectInputDropdownExpanded,
                            onDismissRequest = { isSubjectInputDropdownExpanded = false }
                        ) {
                            courseSubjectsOnly.forEach { sub ->
                                DropdownMenuItem(
                                    text = { Text(sub, fontSize = 11.sp) },
                                    onClick = {
                                        inputSubject = sub
                                        isSubjectInputDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Status selection buttons
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الحالة:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf("حضور", "غياب", "مستأذن", "إجازة").forEach { st ->
                                val isSel = inputStatus == st
                                val bgCol = if (isSel) {
                                    when (st) {
                                        "حضور" -> Color(0xFFE6F4EA)
                                        "غياب" -> Color(0xFFFCE8E6)
                                        "مستأذن" -> Color(0xFFFEF7E0)
                                        else -> Color(0xFFE8F0FE)
                                    }
                                } else Color.Transparent
                                val borderCol = if (isSel) {
                                    when (st) {
                                        "حضور" -> Color(0xFF137333)
                                        "غياب" -> Color(0xFFC5221F)
                                        "مستأذن" -> Color(0xFFB06000)
                                        else -> Color(0xFF1A73E8)
                                    }
                                } else Color.LightGray
                                val txtCol = if (isSel) borderCol else Color.Gray

                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { inputStatus = st },
                                    color = bgCol,
                                    shape = RoundedCornerShape(6.dp),
                                    border = BorderStroke(1.dp, borderCol)
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(st, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = txtCol)
                                    }
                                }
                            }
                        }
                    }

                    // Times row (only if status is حضور or مستأذن)
                    if (inputStatus == "حضور" || inputStatus == "مستأذن") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = if (inputCheckIn.isNotBlank()) formatTimeTo12HourArabic(inputCheckIn) else "",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("وقت الدخول", fontSize = 10.sp) },
                                trailingIcon = {
                                    IconButton(onClick = {
                                        val cal = java.util.Calendar.getInstance()
                                        android.app.TimePickerDialog(
                                            context,
                                            { _, h, m ->
                                                inputCheckIn = String.format("%02d:%02d", h, m)
                                            },
                                            cal.get(java.util.Calendar.HOUR_OF_DAY),
                                            cal.get(java.util.Calendar.MINUTE),
                                            false
                                        ).show()
                                    }) {
                                        Icon(Icons.Default.AccessTime, contentDescription = null, tint = DawamiNavy)
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = TextStyle(fontSize = 11.sp)
                            )

                            OutlinedTextField(
                                value = if (inputCheckOut.isNotBlank()) formatTimeTo12HourArabic(inputCheckOut) else "",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("وقت الخروج", fontSize = 10.sp) },
                                trailingIcon = {
                                    IconButton(onClick = {
                                        val cal = java.util.Calendar.getInstance()
                                        android.app.TimePickerDialog(
                                            context,
                                            { _, h, m ->
                                                inputCheckOut = String.format("%02d:%02d", h, m)
                                            },
                                            cal.get(java.util.Calendar.HOUR_OF_DAY),
                                            cal.get(java.util.Calendar.MINUTE),
                                            false
                                        ).show()
                                    }) {
                                        Icon(Icons.Default.AccessTime, contentDescription = null, tint = DawamiNavy)
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = TextStyle(fontSize = 11.sp)
                            )
                        }
                    }

                    // Note field
                    OutlinedTextField(
                        value = inputNote,
                        onValueChange = { inputNote = it },
                        label = { Text("ملاحظة الأستاذ (اختياري)", fontSize = 10.sp) },
                        placeholder = { Text("سبب الغياب، مبرر الاستئذان...", fontSize = 10.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = TextStyle(fontSize = 11.sp),
                        maxLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputDate.isBlank()) {
                            Toast.makeText(context, "الرجاء تحديد التاريخ!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val courseId = student.courseId
                        val courseName = studentCourse?.name ?: ""
                        val recordToSave = (editingRecord ?: StudentAttendance(
                            studentId = student.id,
                            studentName = student.name,
                            courseId = courseId,
                            courseName = courseName,
                            date = inputDate,
                            dayOfWeek = viewModel.getArabicDayOfWeek(inputDate),
                            actualCheckIn = if (inputStatus == "حضور" || inputStatus == "مستأذن") inputCheckIn else "",
                            actualCheckOut = if (inputStatus == "حضور" || inputStatus == "مستأذن") inputCheckOut else "",
                            status = inputStatus
                        )).copy(
                            date = inputDate,
                            dayOfWeek = viewModel.getArabicDayOfWeek(inputDate),
                            status = inputStatus,
                            subjectName = inputSubject,
                            actualCheckIn = if (inputStatus == "حضور" || inputStatus == "مستأذن") inputCheckIn else "",
                            actualCheckOut = if (inputStatus == "حضور" || inputStatus == "مستأذن") inputCheckOut else "",
                            studentNote = inputNote,
                            updatedAt = System.currentTimeMillis()
                        )

                        viewModel.insertStudentAttendance(recordToSave)
                        Toast.makeText(context, if (isEditMode) "تم تعديل حركة الحضور بنجاح! 💾" else "تم تسجيل حركة الحضور بنجاح! 🌟", Toast.LENGTH_SHORT).show()
                        showAddOrEditDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddOrEditDialog = false }) {
                    Text("إلغاء", fontSize = 11.sp, color = Color.Gray)
                }
            },
            shape = RoundedCornerShape(12.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    // --- Delete Confirmation Dialog ---
    if (showDeleteConfirmDialog && recordToDelete != null) {
        val rec = recordToDelete!!
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = {
                Text(
                    text = "تأكيد حذف الحركة 🗑️",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف حركة يوم ${rec.date} لمادة (${rec.subjectName.ifEmpty { "عام" }}) بحالة (${rec.status})؟ سيتم تحديث الإحصائيات المرتبطة فوراً.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteStudentAttendanceRecord(rec)
                        Toast.makeText(context, "تم حذف الحركة بنجاح وتحديث الإحصائيات!", Toast.LENGTH_SHORT).show()
                        showDeleteConfirmDialog = false
                        recordToDelete = null
                    }
                ) {
                    Text("نعم، احذف", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("إلغاء", color = Color.Gray)
                }
            },
            shape = RoundedCornerShape(10.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

