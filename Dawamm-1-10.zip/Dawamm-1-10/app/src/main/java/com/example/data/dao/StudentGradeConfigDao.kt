package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Delete
import com.example.data.entity.StudentGradeConfig
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentGradeConfigDao {
    @Query("SELECT * FROM student_grade_configs")
    fun getAllGradeConfigs(): Flow<List<StudentGradeConfig>>

    @Query("SELECT * FROM student_grade_configs WHERE courseId = :courseId LIMIT 1")
    fun getGradeConfigForCourse(courseId: Int): Flow<StudentGradeConfig?>

    @Query("SELECT * FROM student_grade_configs WHERE courseId = :courseId LIMIT 1")
    suspend fun getGradeConfigForCourseSync(courseId: Int): StudentGradeConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGradeConfig(config: StudentGradeConfig): Long

    @Delete
    suspend fun deleteGradeConfig(config: StudentGradeConfig)
    
    @Query("DELETE FROM student_grade_configs WHERE courseId = :courseId")
    suspend fun deleteGradeConfigByCourseId(courseId: Int)

    @Query("DELETE FROM student_grade_configs")
    suspend fun deleteAllGradeConfigs()
}
