package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.components.AppHeader
import com.example.ui.components.DawamiBottomNavigationBar
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.*

@Composable
fun TrainerProfileScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    showMainLayout: Boolean = true
) {
    val context = LocalContext.current
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val loggedInUser by viewModel.loggedInUser.collectAsState()
    val notifications by viewModel.inAppNotifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    // Trainer Config Flows
    val trainerNameConfig by viewModel.trainerNameConfig.collectAsState()
    val trainerTitleConfig by viewModel.trainerTitleConfig.collectAsState()
    val trainerPhoneConfig by viewModel.trainerPhoneConfig.collectAsState()
    val trainerEmailConfig by viewModel.trainerEmailConfig.collectAsState()
    val trainerIdNumberConfig by viewModel.trainerIdNumberConfig.collectAsState()
    val trainerBioConfig by viewModel.trainerBioConfig.collectAsState()
    val trainerAvatarUriConfig by viewModel.trainerAvatarUriConfig.collectAsState()
    val trainerSignatureUriConfig by viewModel.trainerSignatureUriConfig.collectAsState()

    // Live Database Stats
    val dbCourses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val dbAllStudents by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val dbAttendance by (attendanceViewModel?.allAttendance ?: viewModel.dbAttendance).collectAsState()
    val dbAllStudentAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()

    // Editable Local State
    var nameInput by remember(trainerNameConfig) { mutableStateOf(trainerNameConfig) }
    var titleInput by remember(trainerTitleConfig) { mutableStateOf(trainerTitleConfig) }
    var phoneInput by remember(trainerPhoneConfig) { mutableStateOf(trainerPhoneConfig) }
    var emailInput by remember(trainerEmailConfig) { mutableStateOf(trainerEmailConfig) }
    var idNumberInput by remember(trainerIdNumberConfig) { mutableStateOf(trainerIdNumberConfig) }
    var bioInput by remember(trainerBioConfig) { mutableStateOf(trainerBioConfig) }
    var avatarUriInput by remember(trainerAvatarUriConfig) { mutableStateOf(trainerAvatarUriConfig) }
    var signatureUriInput by remember(trainerSignatureUriConfig) { mutableStateOf(trainerSignatureUriConfig) }

    // Navigation Tab state
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("نظرة عامة 👤", "انضباط وتأخير المدرب ⏱️", "سجل الدورات 📚", "التوقيع والخدمات 🛠️")

    // Photo picker for Avatar
    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            avatarUriInput = uri.toString()
        }
    }

    // Photo picker for Signature
    val signaturePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            signatureUriInput = uri.toString()
        }
    }

    // Live Overall Stats calculation
    val activeCoursesCount = remember(dbCourses) { dbCourses.count { !it.isCompleted } }
    val totalCoursesCount = remember(dbCourses) { dbCourses.size }
    val totalStudentsCount = remember(dbAllStudents) { dbAllStudents.size }
    val totalSessionsTaught = remember(dbAttendance) {
        dbAttendance.map { "${it.courseId}_${it.date}" }.distinct().size
    }
    val overallStudentAttendanceRate = remember(dbAllStudentAttendance) {
        val meaningful = dbAllStudentAttendance.filter { it.status.isNotBlank() && it.status != "لم يسجل" }
        if (meaningful.isEmpty()) 100
        else {
            val presents = meaningful.count { it.status == "حضور" }
            ((presents.toDouble() / meaningful.size.toDouble()) * 100).toInt()
        }
    }

    // Live Trainer Attendance Discipline Stats (انضباط الحضور: حضور vs غياب)
    val totalTrainerAttendanceRecords = remember(dbAttendance) { dbAttendance.size }
    val trainerPresentDays = remember(dbAttendance) {
        dbAttendance.count { it.status == "حضور" || (it.status != "غياب" && it.status != "إجازة" && it.status != "استئذان") }
    }
    val trainerAbsentDays = remember(dbAttendance) {
        dbAttendance.count { it.status == "غياب" }
    }
    val trainerExcusedDays = remember(dbAttendance) {
        dbAttendance.count { it.status == "إجازة" || it.status == "استئذان" }
    }
    val totalAttendanceRequired = remember(trainerPresentDays, trainerAbsentDays) {
        trainerPresentDays + trainerAbsentDays
    }
    val trainerAttendanceRate = remember(totalAttendanceRequired, trainerPresentDays) {
        if (totalAttendanceRequired == 0) 100
        else ((trainerPresentDays.toDouble() / totalAttendanceRequired.toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    // Live Trainer Delay & Punctuality Stats (انضباط التأخير: في الوقت vs متأخر)
    val totalTrainerCheckIns = remember(dbAttendance) {
        dbAttendance.count { it.actualCheckIn.isNotBlank() || it.status == "حضور" }
    }
    val totalCheckInDelayMinutes = remember(dbAttendance) { dbAttendance.sumOf { it.checkInDelayMinutes } }
    val totalLateDepartureMinutes = remember(dbAttendance) {
        dbAttendance.filter { it.checkOutDifferenceMinutes > 0 }.sumOf { it.checkOutDifferenceMinutes }
    }
    val totalEarlyDepartureMinutes = remember(dbAttendance) {
        dbAttendance.filter { it.checkOutDifferenceMinutes < 0 }.sumOf { Math.abs(it.checkOutDifferenceMinutes) }
    }
    val trainerPunctualDays = remember(dbAttendance) {
        dbAttendance.count { it.checkInDelayMinutes == 0 && (it.actualCheckIn.isNotBlank() || it.status == "حضور") }
    }
    val trainerDelayedDays = remember(dbAttendance) {
        dbAttendance.count { it.checkInDelayMinutes > 0 }
    }
    val trainerPunctualityRate = remember(totalTrainerCheckIns, trainerPunctualDays) {
        if (totalTrainerCheckIns == 0) 100
        else ((trainerPunctualDays.toDouble() / totalTrainerCheckIns.toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    // Filter & Search state for Courses Tab
    var coursesFilterState by remember { mutableStateOf("ALL") }
    var coursesSearchQuery by remember { mutableStateOf("") }

    if (showMainLayout) {
        BackHandler {
            viewModel.navigateBack()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                if (showMainLayout) {
                    AppHeader(
                        title = "الملف الشخصي والمهني للمدرب 👤",
                        username = loggedInUser,
                        onHomeClick = { viewModel.navigateTo(Screen.Selection) },
                        isDark = isDarkTheme,
                        onToggleTheme = { viewModel.toggleTheme() },
                        unreadNotificationCount = unreadCount,
                        onNotificationClick = { viewModel.openNotificationCenter() },
                        isMainScreen = false,
                        onBackClick = { viewModel.navigateBack() }
                    )
                }
            },
            bottomBar = {
                if (showMainLayout) {
                    DawamiBottomNavigationBar(viewModel = viewModel)
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // TABS HEADER
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = DawamiNavy,
                    contentColor = Color.White,
                    edgePadding = 12.dp
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 11.5.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == index) DawamiGold else Color.White.copy(alpha = 0.85f)
                                )
                            }
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 120.dp)
                ) {
                    // HERO TRAINER BANNER (SHOWN IN FULL ON OVERVIEW & SERVICES TABS)
                    if (selectedTab == 0 || selectedTab == 3) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.15f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                colors = listOf(
                                                    DawamiNavy.copy(alpha = 0.08f),
                                                    DawamiTeal.copy(alpha = 0.04f),
                                                    Color.Transparent
                                                )
                                            )
                                        )
                                        .padding(14.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        // Avatar
                                        Box(
                                            modifier = Modifier.size(80.dp),
                                            contentAlignment = Alignment.BottomEnd
                                        ) {
                                            Surface(
                                                modifier = Modifier
                                                    .size(80.dp)
                                                    .clip(CircleShape)
                                                    .border(2.5.dp, DawamiTeal, CircleShape)
                                                .clickable {
                                                    avatarPicker.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                },
                                            color = DawamiNavy.copy(alpha = 0.1f)
                                        ) {
                                            if (avatarUriInput.isNotEmpty()) {
                                                AsyncImage(
                                                    model = avatarUriInput,
                                                    contentDescription = "صورة المدرب",
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Crop
                                                )
                                            } else {
                                                Box(
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Person,
                                                        contentDescription = null,
                                                        tint = DawamiNavy,
                                                        modifier = Modifier.size(42.dp)
                                                    )
                                                }
                                            }
                                        }

                                        // Camera overlay
                                        Surface(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .clickable {
                                                    avatarPicker.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                },
                                            color = DawamiTeal,
                                            shadowElevation = 2.dp
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CameraAlt,
                                                contentDescription = "تغيير الصورة",
                                                tint = Color.White,
                                                modifier = Modifier
                                                    .padding(4.dp)
                                                    .fillMaxSize()
                                            )
                                        }
                                    }

                                    // Info Summary
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Text(
                                            text = trainerNameConfig.ifEmpty { "المدرب المعتمد" },
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )

                                        if (trainerTitleConfig.isNotEmpty()) {
                                            Text(
                                                text = trainerTitleConfig,
                                                fontSize = 11.5.sp,
                                                color = DawamiTeal,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }

                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            if (trainerIdNumberConfig.isNotEmpty()) {
                                                Text(
                                                    text = "الرقم: $trainerIdNumberConfig",
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            if (trainerPhoneConfig.isNotEmpty()) {
                                                Text(
                                                    text = "📱 $trainerPhoneConfig",
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        // Quick Badges: Attendance & Delay Discipline Rates
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Attendance Rate Badge
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (trainerAttendanceRate >= 90) Color(0xFF10B981).copy(alpha = 0.12f) else Color(0xFFF59E0B).copy(alpha = 0.12f),
                                                border = BorderStroke(1.dp, if (trainerAttendanceRate >= 90) Color(0xFF10B981) else Color(0xFFF59E0B))
                                            ) {
                                                Text(
                                                    text = "انضباط الحضور: $trainerAttendanceRate% 📋",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (trainerAttendanceRate >= 90) Color(0xFF047857) else Color(0xFFB45309),
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }

                                            // Delay Discipline Badge
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (trainerPunctualityRate >= 90) DawamiTeal.copy(alpha = 0.12f) else Color(0xFFE11D48).copy(alpha = 0.12f),
                                                border = BorderStroke(1.dp, if (trainerPunctualityRate >= 90) DawamiTeal else Color(0xFFE11D48))
                                            ) {
                                                Text(
                                                    text = "انضباط التأخير: $trainerPunctualityRate% ⏱️",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (trainerPunctualityRate >= 90) DawamiTeal else Color(0xFFE11D48),
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                    // TAB CONTENT
                    when (selectedTab) {
                        0 -> {
                            // TAB 0: OVERVIEW & FORM EDITING
                            item {
                                // Live Training Stats Grid
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(18.dp))
                                            Text(
                                                "الملخص الإحصائي التراكمي للمدرب 📊",
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = DawamiNavy
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // Courses
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = DawamiNavy.copy(alpha = 0.06f),
                                                border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.15f))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(8.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$totalCoursesCount",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 16.sp,
                                                        color = DawamiNavy
                                                    )
                                                    Text(
                                                        text = "الدورات ($activeCoursesCount نشطة)",
                                                        fontSize = 9.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }

                                            // Students
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = DawamiTeal.copy(alpha = 0.08f),
                                                border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.2f))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(8.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$totalStudentsCount",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 16.sp,
                                                        color = DawamiTeal
                                                    )
                                                    Text(
                                                        text = "إجمالي الطلاب",
                                                        fontSize = 9.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }

                                            // Sessions
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = DawamiGold.copy(alpha = 0.1f),
                                                border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.3f))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(8.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$totalSessionsTaught",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 16.sp,
                                                        color = DawamiGold
                                                    )
                                                    Text(
                                                        text = "أيام التدريس",
                                                        fontSize = 9.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }

                                            // Student Attendance rate
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = Color(0xFF10B981).copy(alpha = 0.08f),
                                                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.25f))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(8.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$overallStudentAttendanceRate%",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 16.sp,
                                                        color = Color(0xFF047857)
                                                    )
                                                    Text(
                                                        text = "حضور الطلاب",
                                                        fontSize = 9.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }

                                        // Row 2: Trainer Attendance & Delay Discipline
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // Trainer Attendance Discipline
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = if (trainerAttendanceRate >= 90) Color(0xFF10B981).copy(alpha = 0.08f) else Color(0xFFF59E0B).copy(alpha = 0.08f),
                                                border = BorderStroke(1.dp, if (trainerAttendanceRate >= 90) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFFF59E0B).copy(alpha = 0.25f))
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(8.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Icon(Icons.Default.FactCheck, contentDescription = null, tint = if (trainerAttendanceRate >= 90) Color(0xFF047857) else Color(0xFFB45309), modifier = Modifier.size(20.dp))
                                                    Column {
                                                        Text(
                                                            text = "انضباط الحضور: $trainerAttendanceRate%",
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 11.sp,
                                                            color = if (trainerAttendanceRate >= 90) Color(0xFF047857) else Color(0xFFB45309)
                                                        )
                                                        Text(
                                                            text = "$trainerPresentDays يوم حضور | $trainerAbsentDays غياب",
                                                            fontSize = 8.5.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }

                                            // Trainer Delay Discipline
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = if (trainerPunctualityRate >= 90) DawamiTeal.copy(alpha = 0.08f) else Color(0xFFE11D48).copy(alpha = 0.08f),
                                                border = BorderStroke(1.dp, if (trainerPunctualityRate >= 90) DawamiTeal.copy(alpha = 0.25f) else Color(0xFFE11D48).copy(alpha = 0.25f))
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(8.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Icon(Icons.Default.Timer, contentDescription = null, tint = if (trainerPunctualityRate >= 90) DawamiTeal else Color(0xFFE11D48), modifier = Modifier.size(20.dp))
                                                    Column {
                                                        Text(
                                                            text = "انضباط التأخير: $trainerPunctualityRate%",
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 11.sp,
                                                            color = if (trainerPunctualityRate >= 90) DawamiTeal else Color(0xFFE11D48)
                                                        )
                                                        Text(
                                                            text = "$trainerPunctualDays في الوقت | $totalCheckInDelayMinutes د تأخير",
                                                            fontSize = 8.5.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Form to edit credentials
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Default.Badge, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
                                            Text(
                                                "البيانات المهنية والشخصية ✍️",
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = DawamiNavy
                                            )
                                        }

                                        // Full Name
                                        OutlinedTextField(
                                            value = nameInput,
                                            onValueChange = { nameInput = it },
                                            label = { Text("الاسم الكامل للمدرب *", fontSize = 11.sp) },
                                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp)) },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            singleLine = true
                                        )

                                        // Title & ID Row
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = titleInput,
                                                onValueChange = { titleInput = it },
                                                label = { Text("المسمى / اللقب المهني", fontSize = 11.sp) },
                                                placeholder = { Text("مثال: مهندس برمجيات", fontSize = 10.sp) },
                                                leadingIcon = { Icon(Icons.Default.Work, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(18.dp)) },
                                                modifier = Modifier.weight(1.2f),
                                                shape = RoundedCornerShape(10.dp),
                                                singleLine = true
                                            )

                                            OutlinedTextField(
                                                value = idNumberInput,
                                                onValueChange = { idNumberInput = it },
                                                label = { Text("الرقم الوظيفي/الأكاديمي", fontSize = 11.sp) },
                                                leadingIcon = { Icon(Icons.Default.Pin, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp)) },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                singleLine = true
                                            )
                                        }

                                        // Phone & Email Row
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = phoneInput,
                                                onValueChange = { phoneInput = it },
                                                label = { Text("رقم الهاتف للتواصل", fontSize = 11.sp) },
                                                placeholder = { Text("05xxxxxxxx", fontSize = 10.sp) },
                                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp)) },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                singleLine = true
                                            )

                                            OutlinedTextField(
                                                value = emailInput,
                                                onValueChange = { emailInput = it },
                                                label = { Text("البريد الإلكتروني", fontSize = 11.sp) },
                                                placeholder = { Text("trainer@example.com", fontSize = 10.sp) },
                                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(18.dp)) },
                                                modifier = Modifier.weight(1.2f),
                                                shape = RoundedCornerShape(10.dp),
                                                singleLine = true
                                            )
                                        }

                                        // Bio & Qualifications
                                        OutlinedTextField(
                                            value = bioInput,
                                            onValueChange = { bioInput = it },
                                            label = { Text("نبذة تعريفية ومجالات التخصص", fontSize = 11.sp) },
                                            placeholder = { Text("سجل نبذة موجزة عن المؤهلات العلمية وسنوات الخبرة...", fontSize = 10.sp) },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            minLines = 2,
                                            maxLines = 4
                                        )
                                    }
                                }
                            }
                        }

                        1 -> {
                            // TAB 1: TRAINER ATTENDANCE & DELAY STATS (انضباط الحضور وانضباط التأخير)
                            // Card 1: Attendance Discipline Indicator (حضور vs غياب - دون احتساب التأخير)
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(Icons.Default.FactCheck, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(20.dp))
                                                Text(
                                                    "شريط ومؤشر انضباط الحضور والغياب 📋",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = DawamiNavy
                                                )
                                            }

                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = if (trainerAttendanceRate >= 90) Color(0xFF10B981).copy(alpha = 0.12f) else Color(0xFFF59E0B).copy(alpha = 0.12f),
                                                border = BorderStroke(1.dp, if (trainerAttendanceRate >= 90) Color(0xFF10B981) else Color(0xFFF59E0B))
                                            ) {
                                                Text(
                                                    text = "انضباط الحضور: $trainerAttendanceRate% 🟢",
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (trainerAttendanceRate >= 90) Color(0xFF047857) else Color(0xFFB45309),
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }

                                        Text(
                                            text = "مؤشر انضباط الحضور يقيس التواجد الفعلي مقابل الغياب (دون التأثير بدقائق التأخير).",
                                            fontSize = 9.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        // Progress Bar for Attendance
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("نسبة الحضور الفعلي من إجمالي الأيام المطلوبة:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text("$trainerAttendanceRate%", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = if (trainerAttendanceRate >= 90) Color(0xFF047857) else Color(0xFFB45309))
                                            }
                                            LinearProgressIndicator(
                                                progress = { (trainerAttendanceRate / 100f).coerceIn(0f, 1f) },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(9.dp)
                                                    .clip(RoundedCornerShape(4.5.dp)),
                                                color = if (trainerAttendanceRate >= 90) Color(0xFF059669) else Color(0xFFF59E0B),
                                                trackColor = Color(0xFFFEE2E2)
                                            )
                                        }

                                        // 4 Metric Chips for Attendance
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            // Present Days
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = Color(0xFFF0FDF4),
                                                border = BorderStroke(1.dp, Color(0xFFBBF7D0))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(7.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$trainerPresentDays",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 15.sp,
                                                        color = Color(0xFF16A34A)
                                                    )
                                                    Text(
                                                        text = "أيام الحضور 🟢",
                                                        fontSize = 8.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        textAlign = TextAlign.Center
                                                    )
                                                }
                                            }

                                            // Absent Days
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = if (trainerAbsentDays > 0) Color(0xFFFFF1F2) else Color(0xFFF8FAFC),
                                                border = BorderStroke(1.dp, if (trainerAbsentDays > 0) Color(0xFFFECDD3) else Color(0xFFE2E8F0))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(7.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$trainerAbsentDays",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 15.sp,
                                                        color = if (trainerAbsentDays > 0) Color(0xFFE11D48) else Color.Gray
                                                    )
                                                    Text(
                                                        text = "أيام الغياب 🔴",
                                                        fontSize = 8.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        textAlign = TextAlign.Center
                                                    )
                                                }
                                            }

                                            // Excused / Leave
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = if (trainerExcusedDays > 0) Color(0xFFFFFBEB) else Color(0xFFF8FAFC),
                                                border = BorderStroke(1.dp, if (trainerExcusedDays > 0) Color(0xFFFDE68A) else Color(0xFFE2E8F0))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(7.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$trainerExcusedDays",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 15.sp,
                                                        color = if (trainerExcusedDays > 0) Color(0xFFD97706) else Color.Gray
                                                    )
                                                    Text(
                                                        text = "إجازة / عذر 🟡",
                                                        fontSize = 8.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        textAlign = TextAlign.Center
                                                    )
                                                }
                                            }

                                            // Total Required Days
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = DawamiNavy.copy(alpha = 0.05f),
                                                border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.15f))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(7.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$totalAttendanceRequired",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 15.sp,
                                                        color = DawamiNavy
                                                    )
                                                    Text(
                                                        text = "إجمالي الأيام 🏢",
                                                        fontSize = 8.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        textAlign = TextAlign.Center
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Card 2: Punctuality & Delay Discipline Indicator (في الوقت vs تأخير)
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(Icons.Default.Schedule, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(20.dp))
                                                Text(
                                                    "شريط ومؤشر انضباط المواعيد والتأخير ⏱️",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = DawamiNavy
                                                )
                                            }

                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = if (trainerPunctualityRate >= 90) DawamiTeal.copy(alpha = 0.12f) else Color(0xFFE11D48).copy(alpha = 0.12f),
                                                border = BorderStroke(1.dp, if (trainerPunctualityRate >= 90) DawamiTeal else Color(0xFFE11D48))
                                            ) {
                                                Text(
                                                    text = "انضباط التأخير: $trainerPunctualityRate% ⏱️",
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (trainerPunctualityRate >= 90) DawamiTeal else Color(0xFFE11D48),
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }

                                        Text(
                                            text = "مؤشر انضباط التأخير يقيس مدى الالتزام بالحضور في الموعد المحدد دون تأخير صباحي أو انصراف مبكر.",
                                            fontSize = 9.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        // Progress Bar for Punctuality
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("نسبة الحضور في الموعد المحدد (بدون تأخير):", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text("$trainerPunctualityRate%", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = if (trainerPunctualityRate >= 90) DawamiTeal else Color(0xFFE11D48))
                                            }
                                            LinearProgressIndicator(
                                                progress = { (trainerPunctualityRate / 100f).coerceIn(0f, 1f) },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(9.dp)
                                                    .clip(RoundedCornerShape(4.5.dp)),
                                                color = if (trainerPunctualityRate >= 90) DawamiTeal else Color(0xFFE11D48),
                                                trackColor = Color(0xFFE2E8F0)
                                            )
                                        }

                                        // 4 Metric Chips for Delay
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            // On-time check-ins
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = DawamiTeal.copy(alpha = 0.08f),
                                                border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.25f))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(7.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$trainerPunctualDays",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 15.sp,
                                                        color = DawamiTeal
                                                    )
                                                    Text(
                                                        text = "في الموعد ⏱️",
                                                        fontSize = 8.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        textAlign = TextAlign.Center
                                                    )
                                                }
                                            }

                                            // Delayed check-ins
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = if (trainerDelayedDays > 0) Color(0xFFFFF1F2) else Color(0xFFF8FAFC),
                                                border = BorderStroke(1.dp, if (trainerDelayedDays > 0) Color(0xFFFECDD3) else Color(0xFFE2E8F0))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(7.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$trainerDelayedDays",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 15.sp,
                                                        color = if (trainerDelayedDays > 0) Color(0xFFE11D48) else Color.Gray
                                                    )
                                                    Text(
                                                        text = "أيام بتأخير ⚠️",
                                                        fontSize = 8.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        textAlign = TextAlign.Center
                                                    )
                                                }
                                            }

                                            // Total delay minutes
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = if (totalCheckInDelayMinutes > 0) Color(0xFFFFF1F2) else Color(0xFFF0FDF4),
                                                border = BorderStroke(1.dp, if (totalCheckInDelayMinutes > 0) Color(0xFFFECDD3) else Color(0xFFBBF7D0))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(7.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$totalCheckInDelayMinutes د",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 15.sp,
                                                        color = if (totalCheckInDelayMinutes > 0) Color(0xFFE11D48) else Color(0xFF16A34A)
                                                    )
                                                    Text(
                                                        text = "دقائق التأخير ⏳",
                                                        fontSize = 8.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        textAlign = TextAlign.Center
                                                    )
                                                }
                                            }

                                            // Early Departure
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = if (totalEarlyDepartureMinutes > 0) Color(0xFFFFFBEB) else Color(0xFFF8FAFC),
                                                border = BorderStroke(1.dp, if (totalEarlyDepartureMinutes > 0) Color(0xFFFDE68A) else Color(0xFFE2E8F0))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(7.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = "$totalEarlyDepartureMinutes د",
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 15.sp,
                                                        color = if (totalEarlyDepartureMinutes > 0) Color(0xFFD97706) else Color.Gray
                                                    )
                                                    Text(
                                                        text = "انصراف مبكر 🚪",
                                                        fontSize = 8.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        textAlign = TextAlign.Center
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Card 3: Combined Reflection of Discipline in Trainer Performance
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = DawamiNavy.copy(alpha = 0.04f)),
                                    border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.15f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Default.Verified, contentDescription = null, tint = DawamiGold, modifier = Modifier.size(20.dp))
                                            Text(
                                                "انعكاس انضباط المدرب في التقييم الأكاديمي 🌟",
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = DawamiNavy
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // Attendance Rate Box
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = MaterialTheme.colorScheme.surface,
                                                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.3f))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(10.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Text("انضباط الحضور", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF047857))
                                                    Text("$trainerAttendanceRate%", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF047857))
                                                    Text(if (trainerAttendanceRate >= 95) "ممتاز 🌟" else if (trainerAttendanceRate >= 85) "جيد جداً 🟢" else "مقبول ⚠️", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                            }

                                            // Delay Rate Box
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                color = MaterialTheme.colorScheme.surface,
                                                border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.3f))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(10.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Text("انضباط التأخير", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                                    Text("$trainerPunctualityRate%", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = DawamiTeal)
                                                    Text(if (trainerPunctualityRate >= 95) "منضبط تماماً ⏱️" else if (trainerPunctualityRate >= 85) "التزام جيد 🟢" else "يحتاج تحسين ⚠️", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Per-Course Breakdown Cards
                            item {
                                Text(
                                    text = "تفاصيل انضباط الحضور والتأخير بكل دورة تدريبية 📚",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiNavy,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }

                            if (dbCourses.isEmpty()) {
                                item {
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                    ) {
                                        Text(
                                            text = "لا توجد دورات مسجلة حالياً.",
                                            fontSize = 11.sp,
                                            color = Color.Gray,
                                            modifier = Modifier.padding(16.dp),
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            } else {
                                items(dbCourses) { course ->
                                    val courseTrainerLogs = remember(dbAttendance, course.id) {
                                        dbAttendance.filter { it.courseId == course.id }
                                    }
                                    val courseCheckIns = courseTrainerLogs.size
                                    val coursePresentDays = courseTrainerLogs.count { it.status == "حضور" || (it.status != "غياب" && it.status != "إجازة" && it.status != "استئذان") }
                                    val courseAbsentDays = courseTrainerLogs.count { it.status == "غياب" }
                                    val courseAttendanceRate = if (coursePresentDays + courseAbsentDays == 0) 100 else ((coursePresentDays.toDouble() / (coursePresentDays + courseAbsentDays).toDouble()) * 100).toInt()

                                    val courseDelay = courseTrainerLogs.sumOf { it.checkInDelayMinutes }
                                    val courseLateDept = courseTrainerLogs.filter { it.checkOutDifferenceMinutes > 0 }.sumOf { it.checkOutDifferenceMinutes }
                                    val courseEarlyDept = courseTrainerLogs.filter { it.checkOutDifferenceMinutes < 0 }.sumOf { Math.abs(it.checkOutDifferenceMinutes) }
                                    val coursePunctualDays = courseTrainerLogs.count { it.checkInDelayMinutes == 0 && (it.actualCheckIn.isNotBlank() || it.status == "حضور") }
                                    val coursePunctuality = if (courseCheckIns > 0) ((coursePunctualDays.toDouble() / courseCheckIns.toDouble()) * 100).toInt() else 100

                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Icon(Icons.Default.Class, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                                                    Text(
                                                        text = course.name,
                                                        fontSize = 12.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = DawamiNavy,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }

                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = if (course.isCompleted) Color.Gray.copy(alpha = 0.12f) else DawamiTeal.copy(alpha = 0.12f)
                                                ) {
                                                    Text(
                                                        text = if (course.isCompleted) "مكتملة 🏁" else "نشطة ⚡",
                                                        fontSize = 9.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (course.isCompleted) Color.Gray else DawamiTeal,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }

                                            // Dual Progress Bars: Attendance & Punctuality
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                // Attendance Bar
                                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Text("انضباط الحضور:", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                        Text("$courseAttendanceRate%", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (courseAttendanceRate >= 90) Color(0xFF047857) else Color(0xFFB45309))
                                                    }
                                                    LinearProgressIndicator(
                                                        progress = { (courseAttendanceRate / 100f).coerceIn(0f, 1f) },
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .height(5.dp)
                                                            .clip(RoundedCornerShape(3.dp)),
                                                        color = if (courseAttendanceRate >= 90) Color(0xFF059669) else Color(0xFFF59E0B),
                                                        trackColor = Color(0xFFFEE2E2)
                                                    )
                                                }

                                                // Delay Bar
                                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Text("انضباط التأخير:", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                        Text("$coursePunctuality%", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                                    }
                                                    LinearProgressIndicator(
                                                        progress = { (coursePunctuality / 100f).coerceIn(0f, 1f) },
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .height(5.dp)
                                                            .clip(RoundedCornerShape(3.dp)),
                                                        color = if (coursePunctuality >= 90) DawamiTeal else Color(0xFFE11D48),
                                                        trackColor = Color(0xFFE2E8F0)
                                                    )
                                                }
                                            }

                                            // Detailed Breakdown Grid for this course
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                // Days Present
                                                Surface(
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = Color(0xFFF0FDF4),
                                                    border = BorderStroke(1.dp, Color(0xFFBBF7D0))
                                                ) {
                                                    Column(modifier = Modifier.padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                        Text("$coursePresentDays يوم", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                                                        Text("حضور", fontSize = 7.5.sp, color = Color.Gray)
                                                    }
                                                }

                                                // Days Absent
                                                Surface(
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = if (courseAbsentDays > 0) Color(0xFFFFF1F2) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                                ) {
                                                    Column(modifier = Modifier.padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                        Text("$courseAbsentDays يوم", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (courseAbsentDays > 0) Color(0xFFE11D48) else Color.Gray)
                                                        Text("غياب", fontSize = 7.5.sp, color = Color.Gray)
                                                    }
                                                }

                                                // Delay Minutes
                                                Surface(
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = if (courseDelay > 0) Color(0xFFFFF1F2) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                                ) {
                                                    Column(modifier = Modifier.padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                        Text("$courseDelay د", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (courseDelay > 0) Color(0xFFE11D48) else DawamiNavy)
                                                        Text("تأخير", fontSize = 7.5.sp, color = Color.Gray)
                                                    }
                                                }

                                                // Late Departure
                                                Surface(
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                                ) {
                                                    Column(modifier = Modifier.padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                        Text("$courseLateDept د", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB))
                                                        Text("انصراف متأخر", fontSize = 7.5.sp, color = Color.Gray)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        2 -> {
                            // TAB 2: COURSES & ACADEMIC BREAKDOWN (مع تفعيل التمرير الكامل والبحث والفلترة)
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(Icons.Default.MenuBook, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(20.dp))
                                                Text(
                                                    "سجل الدورات والمساقات الموكلة للمدرب 📚",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = DawamiNavy
                                                )
                                            }

                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = DawamiNavy.copy(alpha = 0.08f)
                                            ) {
                                                Text(
                                                    text = "إجمالي: $totalCoursesCount دورة",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = DawamiNavy,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                )
                                            }
                                        }

                                        Text(
                                            text = "يعرض هذا السجل كافّة الدورات التدريبية الموكلة للمدرب وحالتها مع إمكانية التمرير الكامل وإدارتها مباشرة.",
                                            fontSize = 9.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        // Search text field
                                        OutlinedTextField(
                                            value = coursesSearchQuery,
                                            onValueChange = { coursesSearchQuery = it },
                                            placeholder = { Text("بحث باسم الدورة أو الدبلوم أو القسم...", fontSize = 11.sp) },
                                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp)) },
                                            trailingIcon = {
                                                if (coursesSearchQuery.isNotEmpty()) {
                                                    IconButton(onClick = { coursesSearchQuery = "" }, modifier = Modifier.size(20.dp)) {
                                                        Icon(Icons.Default.Close, contentDescription = "مسح", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            singleLine = true
                                        )

                                        // Filter Row (All, Active, Completed)
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            val completedCount = totalCoursesCount - activeCoursesCount

                                            // All Filter
                                            Surface(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .clickable { coursesFilterState = "ALL" },
                                                color = if (coursesFilterState == "ALL") DawamiNavy else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                                border = BorderStroke(1.dp, if (coursesFilterState == "ALL") DawamiNavy else Color.Transparent)
                                            ) {
                                                Text(
                                                    text = "الكل ($totalCoursesCount)",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (coursesFilterState == "ALL") Color.White else MaterialTheme.colorScheme.onSurface,
                                                    textAlign = TextAlign.Center,
                                                    modifier = Modifier.padding(vertical = 7.dp)
                                                )
                                            }

                                            // Active Filter
                                            Surface(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .clickable { coursesFilterState = "ACTIVE" },
                                                color = if (coursesFilterState == "ACTIVE") DawamiTeal else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                                border = BorderStroke(1.dp, if (coursesFilterState == "ACTIVE") DawamiTeal else Color.Transparent)
                                            ) {
                                                Text(
                                                    text = "المستمرة 🟢 ($activeCoursesCount)",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (coursesFilterState == "ACTIVE") Color.White else MaterialTheme.colorScheme.onSurface,
                                                    textAlign = TextAlign.Center,
                                                    modifier = Modifier.padding(vertical = 7.dp)
                                                )
                                            }

                                            // Completed Filter
                                            Surface(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .clickable { coursesFilterState = "COMPLETED" },
                                                color = if (coursesFilterState == "COMPLETED") Color.Gray else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                                border = BorderStroke(1.dp, if (coursesFilterState == "COMPLETED") Color.Gray else Color.Transparent)
                                            ) {
                                                Text(
                                                    text = "المنتهية 🔒 ($completedCount)",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (coursesFilterState == "COMPLETED") Color.White else MaterialTheme.colorScheme.onSurface,
                                                    textAlign = TextAlign.Center,
                                                    modifier = Modifier.padding(vertical = 7.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            val coursesFilteredByStatus = when (coursesFilterState) {
                                "ACTIVE" -> dbCourses.filter { !it.isCompleted }
                                "COMPLETED" -> dbCourses.filter { it.isCompleted }
                                else -> dbCourses
                            }

                            val coursesToDisplay = if (coursesSearchQuery.isBlank()) {
                                coursesFilteredByStatus
                            } else {
                                val query = coursesSearchQuery.trim()
                                coursesFilteredByStatus.filter {
                                    it.name.contains(query, ignoreCase = true) ||
                                    it.diplomaName.contains(query, ignoreCase = true) ||
                                    it.departmentName.contains(query, ignoreCase = true)
                                }
                            }

                            if (coursesToDisplay.isEmpty()) {
                                item {
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                    ) {
                                        Text(
                                            text = if (coursesSearchQuery.isNotBlank()) {
                                                "لا توجد دورات مطابقة للبحث: \"$coursesSearchQuery\""
                                            } else {
                                                when (coursesFilterState) {
                                                    "ACTIVE" -> "لا توجد دورات مستمرة حالياً."
                                                    "COMPLETED" -> "لا توجد دورات منتهية ومؤرشفة حالياً."
                                                    else -> "لا توجد دورات مسجلة حالياً."
                                                }
                                            },
                                            fontSize = 11.sp,
                                            color = Color.Gray,
                                            modifier = Modifier.padding(16.dp),
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            } else {
                                items(coursesToDisplay) { course ->
                                    val courseStudents = remember(dbAllStudents, course.id) {
                                        dbAllStudents.filter { it.courseId == course.id }
                                    }
                                    val courseAttendanceLogs = remember(dbAttendance, course.id) {
                                        dbAttendance.filter { it.courseId == course.id }
                                    }
                                    val courseStudentAttendanceList = remember(dbAllStudentAttendance, courseStudents) {
                                        val studentIds = courseStudents.map { it.id }.toSet()
                                        dbAllStudentAttendance.filter { it.studentId in studentIds && it.status.isNotBlank() && it.status != "لم يسجل" }
                                    }
                                    val courseStudentAttendancePct = if (courseStudentAttendanceList.isEmpty()) 100
                                    else ((courseStudentAttendanceList.count { it.status == "حضور" }.toDouble() / courseStudentAttendanceList.size.toDouble()) * 100).toInt()

                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, if (course.isCompleted) Color(0xFFE2E8F0) else DawamiNavy.copy(alpha = 0.2f)),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            // Top Header
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Icon(Icons.Default.School, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
                                                    Text(
                                                        text = course.name,
                                                        fontSize = 13.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = DawamiNavy,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }

                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = if (course.isCompleted) Color.Gray.copy(alpha = 0.12f) else Color(0xFF10B981).copy(alpha = 0.12f),
                                                    border = BorderStroke(1.dp, if (course.isCompleted) Color.Gray.copy(alpha = 0.3f) else Color(0xFF10B981).copy(alpha = 0.4f))
                                                ) {
                                                    Text(
                                                        text = if (course.isCompleted) "منتهية ومؤرشفة 🔒" else "مستمرة ونشطة 🟢",
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (course.isCompleted) Color.Gray else Color(0xFF047857),
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }

                                            // Badges row: Students count & Diploma
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = DawamiTeal.copy(alpha = 0.08f)
                                                ) {
                                                    Text(
                                                        text = "👥 ${courseStudents.size} طالب مقيد",
                                                        fontSize = 9.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = DawamiTeal,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }

                                                if (course.diplomaName.isNotEmpty()) {
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = DawamiNavy.copy(alpha = 0.08f)
                                                    ) {
                                                        Text(
                                                            text = "🏷️ ${course.diplomaName}",
                                                            fontSize = 9.5.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = DawamiNavy,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }

                                                if (course.departmentName.isNotEmpty() && course.departmentName != course.diplomaName) {
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                                    ) {
                                                        Text(
                                                            text = "🏢 ${course.departmentName}",
                                                            fontSize = 9.5.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            // Dates and Timing Info
                                            if (course.startDate.isNotEmpty() || course.endDate.isNotEmpty() || course.startTime.isNotEmpty()) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    if (course.startDate.isNotEmpty() || course.endDate.isNotEmpty()) {
                                                        Text(
                                                            text = "📅 الفترة: ${course.startDate.ifEmpty { "..." }} إلى ${course.endDate.ifEmpty { "..." }}",
                                                            fontSize = 9.5.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                    if (course.startTime.isNotEmpty()) {
                                                        Text(
                                                            text = "⏰ ${course.startTime} - ${course.endTime}",
                                                            fontSize = 9.5.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }

                                            // Quick stats row: Sessions taught & student attendance rate
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Surface(
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = DawamiGold.copy(alpha = 0.08f),
                                                    border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.25f))
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(6.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(Icons.Default.EventAvailable, contentDescription = null, tint = DawamiGold, modifier = Modifier.size(14.dp))
                                                        Text(
                                                            text = "${courseAttendanceLogs.size} جلسة تدريسية",
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = DawamiNavy
                                                        )
                                                    }
                                                }

                                                Surface(
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = Color(0xFF10B981).copy(alpha = 0.08f),
                                                    border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.25f))
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(6.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(Icons.Default.Group, contentDescription = null, tint = Color(0xFF047857), modifier = Modifier.size(14.dp))
                                                        Text(
                                                            text = "حضور الطلاب: $courseStudentAttendancePct%",
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF047857)
                                                        )
                                                    }
                                                }
                                            }

                                            // Navigation Action Button
                                            Button(
                                                onClick = {
                                                    viewModel.selectCourseForStudents(course)
                                                    viewModel.navigateTo(Screen.Students)
                                                },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(38.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 12.dp)
                                            ) {
                                                Icon(Icons.Default.PeopleAlt, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                                                Spacer(Modifier.width(6.dp))
                                                Text(
                                                    text = "عرض وإدارة الدورة والطلاب 👥",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                                Spacer(Modifier.weight(1f))
                                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = DawamiGold, modifier = Modifier.size(14.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        3 -> {
                            // TAB 3: SIGNATURE & SERVICES SHORTCUTS
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(Icons.Default.Draw, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(18.dp))
                                                Text(
                                                    "التوقيع والختم الرقمي المعتمد 🖋️",
                                                    fontSize = 12.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = DawamiNavy
                                                )
                                            }

                                            if (signatureUriInput.isNotEmpty()) {
                                                TextButton(
                                                    onClick = { signatureUriInput = "" },
                                                    contentPadding = PaddingValues(0.dp)
                                                ) {
                                                    Text("إزالة التوقيع ❌", fontSize = 10.sp, color = MaterialTheme.colorScheme.error)
                                                }
                                            }
                                        }

                                        Text(
                                            text = "يُطبع هذا التوقيع تلقائياً في أسفل تقارير الحافظة الشهرية وكشوفات الدرجات وحضور الطلاب المعتمدة.",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            lineHeight = 14.sp
                                        )

                                        // Signature Preview or Upload Box
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(100.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .border(1.5.dp, if (signatureUriInput.isNotEmpty()) DawamiTeal else Color(0xFFCBD5E1), RoundedCornerShape(12.dp))
                                                .clickable {
                                                    signaturePicker.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                },
                                            color = if (signatureUriInput.isNotEmpty()) DawamiTeal.copy(alpha = 0.04f) else Color(0xFFF8FAFC)
                                        ) {
                                            if (signatureUriInput.isNotEmpty()) {
                                                Box(
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    AsyncImage(
                                                        model = signatureUriInput,
                                                        contentDescription = "التوقيع المعتمد",
                                                        modifier = Modifier
                                                            .fillMaxHeight()
                                                            .padding(8.dp),
                                                        contentScale = ContentScale.Fit
                                                    )
                                                }
                                            } else {
                                                Column(
                                                    modifier = Modifier.fillMaxSize(),
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.AddPhotoAlternate,
                                                        contentDescription = null,
                                                        tint = DawamiNavy.copy(alpha = 0.6f),
                                                        modifier = Modifier.size(28.dp)
                                                    )
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = "انقر هنا لاختيار أو رفع صورة التوقيع / الختم 📷",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = DawamiNavy
                                                    )
                                                    Text(
                                                        text = "PNG / JPG بخلفية واضحة أو شفافة",
                                                        fontSize = 9.sp,
                                                        color = Color.Gray
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            "خدمات المدرب وإعدادات الأمان السريعة ⚡",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy
                                        )

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // Finances shortcut
                                            Surface(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable { viewModel.navigateTo(Screen.TrainerFinances) },
                                                shape = RoundedCornerShape(10.dp),
                                                color = DawamiTeal.copy(alpha = 0.08f),
                                                border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.25f))
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Icon(Icons.Default.Payments, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(18.dp))
                                                    Column {
                                                        Text("السجل المالي 💰", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                                        Text("المستحقات والبدلات", fontSize = 8.5.sp, color = Color.Gray)
                                                    }
                                                }
                                            }

                                            // Teaching Stats shortcut
                                            Surface(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable { viewModel.navigateTo(Screen.TeachingStats) },
                                                shape = RoundedCornerShape(10.dp),
                                                color = DawamiNavy.copy(alpha = 0.06f),
                                                border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f))
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Icon(Icons.Default.QueryStats, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
                                                    Column {
                                                        Text("ساعات التدريس ⏱️", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                                        Text("تفاصيل الساعات", fontSize = 8.5.sp, color = Color.Gray)
                                                    }
                                                }
                                            }
                                        }

                                        // Change Credentials shortcut
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { viewModel.navigateTo(Screen.ChangeCredentials) },
                                            shape = RoundedCornerShape(10.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Icon(Icons.Default.LockReset, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
                                                    Column {
                                                        Text("تغيير بيانات الدخول وكلمة المرور 🔐", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                                        Text("تحديث اسم المستخدم والرمز السري للنظام", fontSize = 9.sp, color = Color.Gray)
                                                    }
                                                }
                                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // SAVE BUTTON (ALWAYS ACCESSIBLE AT BOTTOM)
                    item {
                        Button(
                            onClick = {
                                if (nameInput.isBlank()) {
                                    Toast.makeText(context, "يرجى كتابة اسم المدرب!", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.saveTrainerProfile(
                                        name = nameInput.trim(),
                                        title = titleInput.trim(),
                                        phone = phoneInput.trim(),
                                        email = emailInput.trim(),
                                        idNumber = idNumberInput.trim(),
                                        bio = bioInput.trim(),
                                        avatarUri = avatarUriInput,
                                        signatureUri = signatureUriInput
                                    )
                                    Toast.makeText(context, "تم حفظ وتحديث بيانات الملف الشخصي للمدرب بنجاح! ✅", Toast.LENGTH_LONG).show()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "حفظ بيانات الملف الشخصي 💾",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
