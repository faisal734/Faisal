package com.example.data.dao

import androidx.room.*
import com.example.data.entity.SubjectReference
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectReferenceDao {
    @Query("SELECT * FROM subject_references ORDER BY id DESC")
    fun getAllReferences(): Flow<List<SubjectReference>>

    @Query("SELECT * FROM subject_references WHERE subjectName = :subjectName ORDER BY id DESC")
    fun getReferencesForSubject(subjectName: String): Flow<List<SubjectReference>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReference(reference: SubjectReference): Long

    @Update
    suspend fun updateReference(reference: SubjectReference)

    @Delete
    suspend fun deleteReference(reference: SubjectReference)

    @Query("DELETE FROM subject_references WHERE subjectName = :subjectName")
    suspend fun deleteReferencesBySubject(subjectName: String)

    @Query("UPDATE subject_references SET subjectName = :newName WHERE subjectName = :oldName")
    suspend fun updateSubjectName(oldName: String, newName: String)

    @Query("DELETE FROM subject_references")
    suspend fun deleteAllReferences()
}
