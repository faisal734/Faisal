package com.example.data.dao

import androidx.room.*
import com.example.data.entity.SubjectAssignmentTemplate
import com.example.data.entity.StudentAssignmentSubmission
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectAssignmentTemplateDao {
    @Query("SELECT * FROM subject_assignment_templates ORDER BY displayOrder ASC, id ASC")
    fun getAllAssignmentTemplates(): Flow<List<SubjectAssignmentTemplate>>

    @Query("SELECT * FROM subject_assignment_templates WHERE subjectName = :subjectName ORDER BY displayOrder ASC, id ASC")
    fun getTemplatesForSubject(subjectName: String): Flow<List<SubjectAssignmentTemplate>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplate(template: SubjectAssignmentTemplate): Long

    @Update
    suspend fun updateTemplate(template: SubjectAssignmentTemplate)

    @Delete
    suspend fun deleteTemplate(template: SubjectAssignmentTemplate)

    @Query("DELETE FROM subject_assignment_templates WHERE subjectName = :subjectName")
    suspend fun deleteTemplatesBySubject(subjectName: String)

    @Query("UPDATE subject_assignment_templates SET subjectName = :newName WHERE subjectName = :oldName")
    suspend fun updateSubjectName(oldName: String, newName: String)

    @Query("DELETE FROM subject_assignment_templates")
    suspend fun deleteAllTemplates()
}

@Dao
interface StudentAssignmentSubmissionDao {
    @Query("SELECT * FROM student_assignment_submissions")
    fun getAllSubmissions(): Flow<List<StudentAssignmentSubmission>>

    @Query("SELECT * FROM student_assignment_submissions WHERE courseId = :courseId")
    suspend fun getSubmissionsForCourseDirect(courseId: Int): List<StudentAssignmentSubmission>

    @Query("""
        SELECT * FROM student_assignment_submissions 
        WHERE courseId = :courseId 
        AND studentId = :studentId 
        AND TRIM(LOWER(subjectName)) = TRIM(LOWER(:subjectName)) 
        AND TRIM(LOWER(assignmentTitle)) = TRIM(LOWER(:assignmentTitle)) 
        ORDER BY id DESC 
        LIMIT 1
    """)
    suspend fun getLatestSubmissionDirect(
        courseId: Int,
        subjectName: String,
        studentId: Int,
        assignmentTitle: String
    ): StudentAssignmentSubmission?

    @Query("SELECT * FROM student_assignment_submissions WHERE courseId = :courseId AND subjectName = :subjectName")
    fun getSubmissionsForCourseAndSubject(courseId: Int, subjectName: String): Flow<List<StudentAssignmentSubmission>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubmission(submission: StudentAssignmentSubmission): Long

    @Update
    suspend fun updateSubmission(submission: StudentAssignmentSubmission)

    @Delete
    suspend fun deleteSubmission(submission: StudentAssignmentSubmission)

    @Query("DELETE FROM student_assignment_submissions WHERE courseId = :courseId")
    suspend fun deleteSubmissionsByCourseId(courseId: Int)

    @Query("DELETE FROM student_assignment_submissions WHERE studentId = :studentId")
    suspend fun deleteSubmissionsByStudentId(studentId: Int)

    @Query("UPDATE student_assignment_submissions SET subjectName = :newName WHERE subjectName = :oldName")
    suspend fun updateSubjectName(oldName: String, newName: String)

    @Query("UPDATE student_assignment_submissions SET courseId = :newCourseId WHERE studentId = :studentId")
    suspend fun transferStudentSubmissions(studentId: Int, newCourseId: Int)

    @Query("DELETE FROM student_assignment_submissions")
    suspend fun deleteAllSubmissions()
}
