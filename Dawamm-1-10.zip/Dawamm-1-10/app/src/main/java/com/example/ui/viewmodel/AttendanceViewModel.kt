package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.entity.*
import com.example.data.repository.AttendanceRepository
import com.example.data.repository.CourseRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * AttendanceViewModel: المسؤول الحصري عن منطق وحالة حضور وانصراف المدرب والطلاب،
 * ومتابعة الاستراحات والملاحظات اليومية ومواضيع الجلسات التدريسية.
 */
class AttendanceViewModel(
    application: Application,
    private val attendanceRepository: AttendanceRepository = run {
        val database = AppDatabase.getDatabase(application)
        AttendanceRepository(
            database.attendanceDao(),
            database.studentAttendanceDao(),
            database.lessonTopicDao(),
            database.lessonSessionTopicDao(),
            database.dailyCourseNoteDao()
        )
    },
    private val courseRepository: CourseRepository = run {
        val database = AppDatabase.getDatabase(application)
        CourseRepository(
            database.courseDao(),
            database.subjectDao(),
            database.subjectReferenceDao()
        )
    }
) : AndroidViewModel(application) {

    // --- State Streams من الـ Repository ---
    val allCourses: StateFlow<List<Course>> = courseRepository.allCourses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAttendance: StateFlow<List<Attendance>> = attendanceRepository.allAttendance
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStudentAttendance: StateFlow<List<StudentAttendance>> = attendanceRepository.allStudentAttendance
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDailyNotes: StateFlow<List<DailyCourseNote>> = attendanceRepository.allDailyNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLessonTopics: StateFlow<List<LessonTopic>> = attendanceRepository.allLessonTopics
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLessonSessionTopics: StateFlow<List<LessonSessionTopic>> = attendanceRepository.allLessonSessionTopics
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val officialHolidayDao = AppDatabase.getDatabase(application).officialHolidayDao()
    val enabledOfficialHolidays: StateFlow<List<OfficialHoliday>> = officialHolidayDao.getEnabledHolidays()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- حقول الحالة النشطة (Selected State) ---
    private val _selectedCourse = MutableStateFlow<Course?>(null)
    val selectedCourse: StateFlow<Course?> = _selectedCourse.asStateFlow()

    private val _attendanceDate = MutableStateFlow(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
    val attendanceDate: StateFlow<String> = _attendanceDate.asStateFlow()

    private val _attendanceDay = MutableStateFlow(getArabicDayOfWeek(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())))
    val attendanceDay: StateFlow<String> = _attendanceDay.asStateFlow()

    private val _showWeekendWarning = MutableStateFlow<String?>(null)
    val showWeekendWarning: StateFlow<String?> = _showWeekendWarning.asStateFlow()

    private val _selectedSubject = MutableStateFlow("")
    val selectedSubject: StateFlow<String> = _selectedSubject.asStateFlow()

    fun selectCourse(course: Course?) {
        _selectedCourse.value = course
        if (course != null) {
            loadSavedSubjectName(course.id, _attendanceDate.value)
        }
    }

    fun setAttendanceDate(date: String) {
        _attendanceDate.value = date
        _attendanceDay.value = getArabicDayOfWeek(date)
        triggerWeekendWarningIfNeeded(date)
        _selectedCourse.value?.let { course ->
            loadSavedSubjectName(course.id, date)
        }
    }

    fun setSelectedSubject(subjectName: String) {
        _selectedSubject.value = subjectName
    }

    fun dismissWeekendWarning() {
        _showWeekendWarning.value = null
    }

    private fun normalizeDateForComparison(dateStr: String): String {
        if (dateStr.isBlank()) return ""
        val arabicDigits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
        val englishDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
        var clean = dateStr.trim()
        for (i in 0..9) {
            clean = clean.replace(arabicDigits[i], englishDigits[i])
        }
        val parts = clean.split("-")
        if (parts.size == 3) {
            val y = parts[0].toIntOrNull() ?: return clean
            val m = parts[1].toIntOrNull() ?: return clean
            val d = parts[2].toIntOrNull() ?: return clean
            return String.format(Locale.US, "%04d-%02d-%02d", y, m, d)
        }
        return clean
    }

    fun getOfficialHolidayForDate(dateStr: String): OfficialHoliday? {
        if (dateStr.isBlank()) return null
        val targetNorm = normalizeDateForComparison(dateStr)
        if (targetNorm.isEmpty()) return null
        return try {
            enabledOfficialHolidays.value.firstOrNull { holiday ->
                try {
                    if (!holiday.isEnabled || holiday.startDate.isBlank() || holiday.endDate.isBlank()) return@firstOrNull false
                    val startNorm = normalizeDateForComparison(holiday.startDate)
                    val endNorm = normalizeDateForComparison(holiday.endDate)
                    targetNorm >= startNorm && targetNorm <= endNorm
                } catch (e: Exception) {
                    false
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    fun triggerWeekendWarningIfNeeded(dateStr: String) {
        val holiday = getOfficialHolidayForDate(dateStr)
        if (holiday != null) {
            _showWeekendWarning.value = "${holiday.name} (إجازة رسمية)"
            return
        }
        val day = getArabicDayOfWeek(dateStr)
        if (day == "الخميس" || day == "الجمعة" || day == "السبت") {
            _showWeekendWarning.value = day
        }
    }

    fun loadSavedSubjectName(courseId: Int, date: String) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        var saved = sharedPrefs.getString("subject_name_of_${courseId}_${date}", "") ?: ""
        if (saved.isEmpty()) {
            saved = allStudentAttendance.value.find { it.courseId == courseId && it.date == date && it.subjectName.isNotEmpty() }?.subjectName ?: ""
        }
        _selectedSubject.value = saved
    }

    // --- Exam Decision State & Handling ---
    private val _showExamDecisionDialog = MutableStateFlow(false)
    val showExamDecisionDialog: StateFlow<Boolean> = _showExamDecisionDialog.asStateFlow()

    private val _isExamDayForNextRecord = MutableStateFlow(false)
    val isExamDayForNextRecord: StateFlow<Boolean> = _isExamDayForNextRecord.asStateFlow()

    private var pendingAttendanceAction: (() -> Unit)? = null
    private var pendingExamDecisionCourseId: Int = -1
    private var pendingExamDecisionSubjectName: String = ""

    private val studentDao = AppDatabase.getDatabase(application).studentDao()

    fun dismissExamDecisionDialog() {
        _showExamDecisionDialog.value = false
        pendingAttendanceAction = null
        pendingExamDecisionCourseId = -1
        pendingExamDecisionSubjectName = ""
    }

    fun handleExamDecision(isExam: Boolean) {
        if (isExam) {
            _isExamDayForNextRecord.value = true
        }
        val action = pendingAttendanceAction
        _showExamDecisionDialog.value = false
        pendingAttendanceAction = null
        pendingExamDecisionCourseId = -1
        pendingExamDecisionSubjectName = ""
        action?.invoke()
    }

    fun cancelTrainerCheckOut(record: Attendance) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = record.copy(
                actualCheckOut = "",
                checkOutDifferenceMinutes = 0,
                status = "حضور"
            )
            attendanceRepository.insertAttendance(updated)
            logActivity(
                category = "TRAINER",
                actionType = "UPDATE",
                title = "إلغاء انصراف المدرب: ${record.courseName}",
                description = "تم إلغاء وقت الانصراف للمدرب في تاريخ ${record.date}",
                relatedId = record.courseId.toLong()
            )
        }
    }

    fun recordTrainerCheckOutDirectly(courseId: Int, date: String, checkOutTime: String): String? {
        val course = allCourses.value.find { it.id == courseId } ?: return "الدورة التدريبية غير موجودة"
        val list = allAttendance.value
        val pendingRecord = list.find { it.courseId == course.id && it.date == date && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() }
        
        if (pendingRecord != null) {
            val checkIn = pendingRecord.actualCheckIn
            val checkInDelay = pendingRecord.checkInDelayMinutes
            val checkOutDiff = calculateMinutesDifference(checkOutTime, course.endTime)
            val totalMinutes = calculateMinutesDifference(checkOutTime, checkIn)
            val h = if (totalMinutes > 0) totalMinutes / 60 else 0
            val m = if (totalMinutes > 0) totalMinutes % 60 else 0

            val hasAlert = checkInDelay > 0 || checkOutDiff < 0
            val alertMsg = buildString {
                if (checkInDelay > 0) append("تأخير دخول ($checkInDelay د) ")
                if (checkOutDiff < 0) append("انصراف مبكر (${-checkOutDiff} د) ")
            }.trim()

            val completedRecord = pendingRecord.copy(
                actualCheckOut = checkOutTime,
                checkOutDifferenceMinutes = checkOutDiff,
                durationHours = h,
                durationMinutes = m,
                hasAlert = hasAlert,
                alertMessage = alertMsg
            )

            viewModelScope.launch(Dispatchers.IO) {
                attendanceRepository.updateAttendance(completedRecord)
                logActivity("TRAINER", "UPDATE", "انصراف المدرب", "تسجيل انصراف للأستاذ في دورة (${course.name}) الساعة $checkOutTime بعد انصراف الطلاب", course.id.toLong())
            }
            return null
        } else {
            val checkIn = course.startTime.ifEmpty { checkOutTime }
            val checkOutDiff = calculateMinutesDifference(checkOutTime, course.endTime)
            val totalMinutes = calculateMinutesDifference(checkOutTime, checkIn)
            val h = if (totalMinutes > 0) totalMinutes / 60 else 0
            val m = if (totalMinutes > 0) totalMinutes % 60 else 0
            val dayName = getArabicDayOfWeek(date)

            val newRecord = Attendance(
                id = 0,
                courseId = course.id,
                courseName = course.name,
                dayOfWeek = dayName,
                date = date,
                actualCheckIn = checkIn,
                actualCheckOut = checkOutTime,
                checkInDelayMinutes = 0,
                checkOutDifferenceMinutes = checkOutDiff,
                durationHours = h,
                durationMinutes = m,
                hasAlert = checkOutDiff < 0,
                alertMessage = if (checkOutDiff < 0) "انصراف مبكر (${-checkOutDiff} د)" else "",
                status = "حضور",
                subjectName = selectedSubject.value
            )
            viewModelScope.launch(Dispatchers.IO) {
                attendanceRepository.insertAttendance(newRecord)
                logActivity("TRAINER", "CREATE", "حضور وانصراف المدرب", "تسجيل حضور وانصراف للمدرب في دورة (${course.name}) بتاريخ $date", course.id.toLong())
            }
            return null
        }
    }

    fun autoRegisterStudentStatusForCourseAndDate(
        courseId: Int,
        dateStr: String,
        dayName: String,
        status: String,
        subjectName: String = selectedSubject.value
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val course = allCourses.value.find { it.id == courseId } ?: return@launch
            val allStudents = studentDao.getAllStudents().first()
            val courseStudents = allStudents.filter { it.courseId == courseId && (it.status == "مستمر" || it.status.isEmpty()) }
            val recordsForDate = allStudentAttendance.value.filter { it.courseId == courseId && it.date == dateStr }

            val toInsert = mutableListOf<StudentAttendance>()
            courseStudents.forEach { student ->
                val existing = recordsForDate.find { it.studentId == student.id }
                val currentSub = if (existing != null && existing.subjectName.isNotEmpty()) existing.subjectName else subjectName
                val newRecord = (existing ?: StudentAttendance(
                    id = 0,
                    studentId = student.id,
                    studentName = student.name,
                    courseId = courseId,
                    courseName = course.name,
                    dayOfWeek = dayName,
                    date = dateStr,
                    actualCheckIn = "",
                    actualCheckOut = "",
                    checkInDelayMinutes = 0,
                    checkOutDifferenceMinutes = 0,
                    hasAlert = false,
                    alertMessage = "",
                    status = status,
                    participationStars = if (status == "حضور") 5 else 0,
                    isOnBreak = false,
                    subjectName = currentSub
                )).copy(
                    status = status,
                    actualCheckIn = if (status == "حضور") (existing?.actualCheckIn?.ifEmpty { course.startTime } ?: course.startTime) else "",
                    actualCheckOut = if (status == "حضور") (existing?.actualCheckOut?.ifEmpty { course.endTime } ?: course.endTime) else "",
                    subjectName = currentSub
                )
                toInsert.add(newRecord)
            }
            if (toInsert.isNotEmpty()) {
                attendanceRepository.insertStudentAttendances(toInsert)
            }
        }
    }

    // --- Activity Logging Helper ---
    private val appActivityLogDao = AppDatabase.getDatabase(application).appActivityLogDao()

    fun logActivity(
        category: String,
        actionType: String,
        title: String,
        description: String,
        relatedId: Long? = null,
        customDateStr: String? = null,
        customTimeStr: String? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = java.util.Date()
            val sdfDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH)
            val sdfTime = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ENGLISH)
            val dateStr = customDateStr ?: sdfDate.format(now)
            val timeStr = customTimeStr ?: sdfTime.format(now)
            val log = com.example.data.entity.AppActivityLog(
                category = category,
                actionType = actionType,
                title = title,
                description = description,
                dateStr = dateStr,
                timeStr = timeStr,
                relatedId = relatedId
            )
            appActivityLogDao.insertLog(log)
        }
    }

    // --- عمليات حضور المدرب (Trainer Attendance) ---
    fun insertTrainerAttendance(attendance: Attendance) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.insertAttendance(attendance)
        }
    }

    fun updateTrainerAttendance(attendance: Attendance) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.updateAttendance(attendance)
        }
    }

    fun deleteTrainerAttendance(attendance: Attendance) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.deleteAttendance(attendance)
        }
    }

    // --- عمليات حضور الطلاب (Student Attendance) ---
    fun insertStudentAttendance(attendance: StudentAttendance) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.insertStudentAttendance(attendance)
        }
    }

    fun insertStudentAttendances(attendances: List<StudentAttendance>) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.insertStudentAttendances(attendances)
        }
    }

    fun updateStudentAttendance(attendance: StudentAttendance) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.updateStudentAttendance(attendance)
        }
    }

    fun deleteStudentAttendance(attendance: StudentAttendance) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.deleteStudentAttendance(attendance)
        }
    }

    fun deleteStudentAttendances(attendances: List<StudentAttendance>) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.deleteStudentAttendances(attendances)
        }
    }

    // --- تسجيل الحضور والانصراف السريع للطلاب ---
    fun registerStudentCheckIn(attendance: StudentAttendance, checkInTime: String, courseStartTime: String = "") {
        if (selectedSubject.value.trim().isEmpty()) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", android.widget.Toast.LENGTH_LONG).show()
            }
            return
        }
        val course = selectedCourse.value ?: allCourses.value.find { it.id == attendance.courseId }
        val startTime = if (courseStartTime.isNotEmpty()) courseStartTime else course?.startTime ?: ""
        val delay = calculateMinutesDifference(checkInTime, startTime)
        val hasAlert = delay > 0
        val alertMsg = if (delay > 0) "تأخير دخول ($delay د)" else ""
        val record = attendance.copy(
            actualCheckIn = checkInTime,
            checkInDelayMinutes = if (delay > 0) delay else 0,
            hasAlert = hasAlert,
            alertMessage = alertMsg,
            status = "حضور",
            subjectName = selectedSubject.value
        )
        insertStudentAttendance(record)
    }

    fun registerStudentCheckOut(attendance: StudentAttendance, checkOutTime: String, courseEndTime: String = ""): Boolean {
        if (attendance.status != "حضور" || attendance.actualCheckIn.isEmpty()) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(getApplication(), "عذراً، لا يمكن تسجيل انصراف للطالب (${attendance.studentName}) لأنه لم يسجل دخولاً أولاً! ⚠️", android.widget.Toast.LENGTH_LONG).show()
            }
            return false
        }
        if (selectedSubject.value.trim().isEmpty()) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", android.widget.Toast.LENGTH_LONG).show()
            }
            return false
        }
        val course = selectedCourse.value ?: allCourses.value.find { it.id == attendance.courseId }
        val endTime = if (courseEndTime.isNotEmpty()) courseEndTime else course?.endTime ?: ""
        val delay = attendance.checkInDelayMinutes
        val checkOutDiff = calculateMinutesDifference(checkOutTime, endTime)
        val isEarly = checkOutDiff < 0
        val earlyMinutes = if (isEarly) -checkOutDiff else 0
        val hasAlert = delay > 0 || earlyMinutes > 0
        val alertMsg = buildString {
            if (delay > 0) append("تأخير دخول ($delay د) ")
            if (earlyMinutes > 0) append("انصراف مبكر ($earlyMinutes د) ")
        }.trim()

        val record = attendance.copy(
            actualCheckOut = checkOutTime,
            checkOutDifferenceMinutes = checkOutDiff,
            hasAlert = hasAlert,
            alertMessage = alertMsg,
            subjectName = selectedSubject.value
        )
        insertStudentAttendance(record)
        return true
    }

    fun registerStudentAbsent(attendance: StudentAttendance) {
        if (selectedSubject.value.trim().isEmpty()) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", android.widget.Toast.LENGTH_LONG).show()
            }
            return
        }
        val record = attendance.copy(
            actualCheckIn = "",
            actualCheckOut = "",
            checkInDelayMinutes = 0,
            checkOutDifferenceMinutes = 0,
            hasAlert = false,
            alertMessage = "",
            status = "غياب",
            participationStars = 0,
            isOnBreak = false,
            breakStartTime = "",
            breakDurationMinutes = 0,
            breakActualReturnTime = "",
            breakDelayMinutes = 0,
            subjectName = selectedSubject.value
        )
        insertStudentAttendance(record)
    }

    fun registerStudentLeave(attendance: StudentAttendance) {
        if (selectedSubject.value.trim().isEmpty()) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", android.widget.Toast.LENGTH_LONG).show()
            }
            return
        }
        val record = attendance.copy(
            actualCheckIn = "",
            actualCheckOut = "",
            checkInDelayMinutes = 0,
            checkOutDifferenceMinutes = 0,
            hasAlert = false,
            alertMessage = "",
            status = "إجازة",
            participationStars = 0,
            isOnBreak = false,
            breakStartTime = "",
            breakDurationMinutes = 0,
            breakActualReturnTime = "",
            breakDelayMinutes = 0,
            subjectName = selectedSubject.value
        )
        insertStudentAttendance(record)
    }

    fun registerStudentExcused(attendance: StudentAttendance) {
        if (selectedSubject.value.trim().isEmpty()) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", android.widget.Toast.LENGTH_LONG).show()
            }
            return
        }
        val record = attendance.copy(
            actualCheckIn = "",
            actualCheckOut = "",
            checkInDelayMinutes = 0,
            checkOutDifferenceMinutes = 0,
            hasAlert = false,
            alertMessage = "",
            status = "مستأذن",
            participationStars = 0,
            isOnBreak = false,
            breakStartTime = "",
            breakDurationMinutes = 0,
            breakActualReturnTime = "",
            breakDelayMinutes = 0,
            subjectName = selectedSubject.value
        )
        insertStudentAttendance(record)
    }

    // --- إدارة الاستراحة (Break Management) ---
    fun registerStudentBreakStart(attendance: StudentAttendance, durationMinutes: Int, startTime: String): Boolean {
        if (attendance.status != "حضور" || attendance.actualCheckIn.isEmpty() || attendance.actualCheckOut.isNotEmpty()) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(getApplication(), "عذراً، لا يمكن تسجيل خروج إلى الاستراحة للطالب (${attendance.studentName}) إلا إذا كان حاضراً حالياً ولم ينصرف بعد! ⚠️", android.widget.Toast.LENGTH_LONG).show()
            }
            return false
        }
        val record = attendance.copy(
            isOnBreak = true,
            breakStartTime = startTime,
            breakDurationMinutes = durationMinutes,
            breakActualReturnTime = "",
            breakDelayMinutes = 0
        )
        insertStudentAttendance(record)
        return true
    }

    fun registerStudentBreakEnd(attendance: StudentAttendance, returnTime: String): Boolean {
        if (attendance.status != "حضور" || !attendance.isOnBreak || attendance.breakStartTime.isEmpty()) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(getApplication(), "عذراً، لا يمكن تسجيل عودة من الاستراحة للطالب (${attendance.studentName}) لأنه لم يسجل خروجاً إليها أولاً! ⚠️", android.widget.Toast.LENGTH_LONG).show()
            }
            return false
        }
        val expectedReturn = if (attendance.breakStartTime.isNotEmpty() && attendance.breakDurationMinutes > 0) {
            addMinutesToTime(attendance.breakStartTime, attendance.breakDurationMinutes)
        } else {
            returnTime
        }
        val delay = calculateMinutesDifference(returnTime, expectedReturn)

        val record = attendance.copy(
            isOnBreak = false,
            breakActualReturnTime = returnTime,
            breakDelayMinutes = delay
        )
        insertStudentAttendance(record)
        return true
    }

    // --- الملاحظات اليومية للدورة (Daily Course Notes) ---
    fun insertDailyNote(note: DailyCourseNote) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.insertDailyNote(note)
            logActivity(
                category = "DAILY_NOTES",
                actionType = "CREATE",
                title = "إضافة ملاحظة يومية: ${note.date}",
                description = "المحتوى: ${note.note}",
                relatedId = note.courseId.toLong()
            )
        }
    }

    fun updateDailyNote(note: DailyCourseNote) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.updateDailyNote(note)
            logActivity(
                category = "DAILY_NOTES",
                actionType = "UPDATE",
                title = "تعديل ملاحظة يومية: ${note.date}",
                description = "المحتوى: ${note.note}",
                relatedId = note.courseId.toLong()
            )
        }
    }

    fun deleteDailyNote(note: DailyCourseNote) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.deleteDailyNote(note)
            logActivity(
                category = "DAILY_NOTES",
                actionType = "DELETE",
                title = "حذف ملاحظة يومية: ${note.date}",
                description = "تم حذف الملاحظة اليومية للدورة",
                relatedId = note.courseId.toLong()
            )
        }
    }

    // --- مواضيع الدروس والجلسات (Lesson Topics & Sessions) ---
    fun insertLessonTopic(topic: LessonTopic) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.insertLessonTopic(topic)
            logActivity(
                category = "LESSONS",
                actionType = "CREATE",
                title = "إضافة موضوع/قسم: ${topic.title}",
                description = "الوصف: ${topic.description}",
                relatedId = topic.subjectId.toLong()
            )
        }
    }

    fun updateLessonTopic(topic: LessonTopic) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.updateLessonTopic(topic)
            logActivity(
                category = "LESSONS",
                actionType = "UPDATE",
                title = "تعديل موضوع أو قسم: ${topic.title}",
                description = "تم تحديث بيانات الموضوع التدريسي",
                relatedId = topic.subjectId.toLong()
            )
        }
    }

    fun deleteLessonTopic(topic: LessonTopic) {
        viewModelScope.launch(Dispatchers.IO) {
            val allTopics = allLessonTopics.value
            val idsToDelete = mutableSetOf<Int>()
            fun collectRecursive(tId: Int) {
                idsToDelete.add(tId)
                allTopics.filter { it.parentId == tId }.forEach { child ->
                    collectRecursive(child.id)
                }
            }
            collectRecursive(topic.id)
            // Delete session topics for all collected IDs
            val sessionsToDelete = allLessonSessionTopics.value.filter { it.topicId in idsToDelete }
            sessionsToDelete.forEach { attendanceRepository.deleteSessionTopic(it) }
            // Delete topics
            allTopics.filter { it.id in idsToDelete }.forEach { attendanceRepository.deleteLessonTopic(it) }
            logActivity(
                category = "LESSONS",
                actionType = "DELETE",
                title = "حذف موضوع أو قسم: ${topic.title}",
                description = "تم الحذف مع ${idsToDelete.size - 1} مواضيع فرعية",
                relatedId = topic.subjectId.toLong()
            )
        }
    }

    fun insertSessionTopic(sessionTopic: LessonSessionTopic) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.insertSessionTopic(sessionTopic)
            logActivity(
                category = "LESSONS",
                actionType = "CREATE",
                title = "ربط موضوع بالجلسة التدريبية",
                description = "التاريخ: ${sessionTopic.date}",
                relatedId = sessionTopic.topicId.toLong()
            )
        }
    }

    fun updateSessionTopic(sessionTopic: LessonSessionTopic) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.updateSessionTopic(sessionTopic)
            logActivity(
                category = "LESSONS",
                actionType = "UPDATE",
                title = "تحديث حالة موضوع الجلسة التدريبية",
                description = "التاريخ: ${sessionTopic.date}",
                relatedId = sessionTopic.topicId.toLong()
            )
        }
    }

    fun deleteSessionTopic(sessionTopic: LessonSessionTopic) {
        viewModelScope.launch(Dispatchers.IO) {
            attendanceRepository.deleteSessionTopic(sessionTopic)
            logActivity(
                category = "LESSONS",
                actionType = "DELETE",
                title = "إلغاء ربط موضوع بالجلسة التدريبية",
                description = "تم إلغاء ربط الموضوع بالجلسة",
                relatedId = sessionTopic.topicId.toLong()
            )
        }
    }

    // --- دوال الحسابات الزمنية المرجعية المعتمدة ---
    companion object {
        fun getArabicDayOfWeek(dateStr: String): String {
            return try {
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                val date = sdf.parse(dateStr)
                if (date != null) {
                    val calendar = Calendar.getInstance()
                    calendar.time = date
                    when (calendar.get(Calendar.DAY_OF_WEEK)) {
                        Calendar.SUNDAY -> "الأحد"
                        Calendar.MONDAY -> "الإثنين"
                        Calendar.TUESDAY -> "الثلاثاء"
                        Calendar.WEDNESDAY -> "الأربعاء"
                        Calendar.THURSDAY -> "الخميس"
                        Calendar.FRIDAY -> "الجمعة"
                        Calendar.SATURDAY -> "السبت"
                        else -> ""
                    }
                } else ""
            } catch (e: Exception) {
                ""
            }
        }
        fun calculateMinutesDifference(time1: String, time2: String): Int {
            val clean1 = time1.trim().lowercase(Locale.US)
            val clean2 = time2.trim().lowercase(Locale.US)
            val t1 = clean1.split(":")
            val t2 = clean2.split(":")
            if (t1.size != 2 || t2.size != 2) return 0
            var h1 = t1[0].filter { it.isDigit() }.toIntOrNull() ?: 0
            val m1 = t1[1].filter { it.isDigit() }.toIntOrNull() ?: 0
            var h2 = t2[0].filter { it.isDigit() }.toIntOrNull() ?: 0
            val m2 = t2[1].filter { it.isDigit() }.toIntOrNull() ?: 0

            val isPM1 = clean1.contains("م") || clean1.contains("pm")
            val isAM1 = clean1.contains("ص") || clean1.contains("am")
            if (isPM1 && h1 < 12) h1 += 12
            if (isAM1 && h1 == 12) h1 = 0

            val isPM2 = clean2.contains("م") || clean2.contains("pm")
            val isAM2 = clean2.contains("ص") || clean2.contains("am")
            if (isPM2 && h2 < 12) h2 += 12
            if (isAM2 && h2 == 12) h2 = 0

            val min1 = h1 * 60 + m1
            val min2 = h2 * 60 + m2
            var diff = min1 - min2
            if (diff < -300) {
                diff += 720
            }
            return diff
        }

        fun addMinutesToTime(timeStr: String, minutesToAdd: Int): String {
            val clean = timeStr.trim().lowercase(Locale.US)
            val parts = clean.split(":")
            if (parts.size != 2) return timeStr
            var h = parts[0].filter { it.isDigit() }.toIntOrNull() ?: 0
            val m = parts[1].filter { it.isDigit() }.toIntOrNull() ?: 0

            val isPM = clean.contains("م") || clean.contains("pm")
            val isAM = clean.contains("ص") || clean.contains("am")
            if (isPM && h < 12) h += 12
            if (isAM && h == 12) h = 0

            var totalMinutes = h * 60 + m + minutesToAdd
            totalMinutes = (totalMinutes % 1440 + 1440) % 1440

            val finalH = totalMinutes / 60
            val finalM = totalMinutes % 60

            return String.format(Locale.US, "%02d:%02d", finalH, finalM)
        }
    }
}
