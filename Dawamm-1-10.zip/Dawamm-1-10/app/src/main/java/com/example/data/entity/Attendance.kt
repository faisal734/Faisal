package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "attendance_records")
data class Attendance(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val courseId: Int,
    val courseName: String,
    val dayOfWeek: String,       // Arabic: "الأحد", "الاثنين", ...
    val date: String,            // format: "yyyy-MM-dd"
    val actualCheckIn: String,   // format: "HH:mm"
    val actualCheckOut: String,  // format: "HH:mm"
    val checkInDelayMinutes: Int,
    val checkOutDifferenceMinutes: Int, // positive for late stay, negative for early departure
    val durationHours: Int,
    val durationMinutes: Int,
    val hasAlert: Boolean,
    val alertMessage: String,
    val isLocked: Boolean = false,
    val status: String = "حضور",
    val note: String = "", // teacher/course daily note for teacher movement
    val subjectName: String = "", // teaching subject for this record
    val systemCreatedAt: String = "", // Exact system time upon saving: "yyyy-MM-dd HH:mm:ss"
    val isTimeTampered: Boolean = false, // Flag if time tampering is suspected
    val isExamDay: Boolean = false // Flag if this attendance day is for an exam
)
