package com.example.ui.viewmodel

import com.example.ui.screens.getScoresMap
import android.app.Application
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import com.example.data.database.AppDatabase
import com.example.data.entity.Attendance
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentAttendance
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentGradeConfig
import com.example.data.entity.DailyCourseNote
import com.example.data.entity.LessonTopic
import com.example.data.entity.LessonSessionTopic
import com.example.data.entity.Subject
import com.example.data.entity.CourseSubjectCrossRef
import com.example.data.entity.TrainerTransaction
import com.example.data.entity.SubjectAssignmentTemplate
import com.example.data.entity.StudentAssignmentSubmission
import com.example.data.entity.AppActivityLog
import com.example.data.entity.StudentViolation
import com.example.data.entity.OfficialHoliday
import com.example.data.repository.AppRepository
import com.example.data.backup.BackupManager
import com.example.data.backup.BackupAnalysisReport
import com.example.data.backup.RestoreResult
import com.example.notification.NotificationHelper
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository
    val backupManager: BackupManager

    // Navigation and Authentication States
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Splash)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _isActivatedState = MutableStateFlow(false)
    val isActivatedState: StateFlow<Boolean> = _isActivatedState.asStateFlow()

    val activationTimestamp = MutableStateFlow(0L)
    val activationDurationMonths = MutableStateFlow(12)
    val activationCode = MutableStateFlow("")

    // Institute Identity Settings
    val orgType = MutableStateFlow("معهد")
    val hasCompletedOnboarding = MutableStateFlow(false)
    val instituteName = MutableStateFlow("معهد دوامي للتدريب")
    val instituteLogoSymbol = MutableStateFlow("school")
    val instituteSlogan = MutableStateFlow("نظام المتابعة والتحضير الذكي")
    val directorName = MutableStateFlow("مدير الهيئة / المؤسسة التدريبية")
    val hrManagerName = MutableStateFlow("مسؤول إدارة الموارد البشرية والتدريب")
    val trainerNameConfig = MutableStateFlow("م. فيصل العفيف")
    val trainerTitleConfig = MutableStateFlow("مدرب تقني معتمد")
    val trainerPhoneConfig = MutableStateFlow("")
    val trainerEmailConfig = MutableStateFlow("")
    val trainerIdNumberConfig = MutableStateFlow("")
    val trainerBioConfig = MutableStateFlow("")
    val trainerAvatarUriConfig = MutableStateFlow("")
    val trainerSignatureUriConfig = MutableStateFlow("")
    val instituteLogoUri = MutableStateFlow("")

    private val _lastBackupDate = MutableStateFlow("")
    val lastBackupDate: StateFlow<String> = _lastBackupDate.asStateFlow()

    fun recordBackupSuccess(customDate: String? = null) {
        val dateStr = customDate ?: java.text.SimpleDateFormat("yyyy/MM/dd - hh:mm a", java.util.Locale("ar")).format(java.util.Date())
        getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
            .edit()
            .putString("last_backup_date", dateStr)
            .apply()
        _lastBackupDate.value = dateStr
    }

    // 36 Theme Presets State & Selection
    val selectedThemeId = MutableStateFlow(
        application.getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE).getInt("selected_theme_id", 1)
    )

    // Light/Dark Theme State
    val isDarkTheme = MutableStateFlow(
        com.example.ui.theme.ThemePresetsCatalog.getById(
            application.getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE).getInt("selected_theme_id", 1)
        ).isDark
    )

    private val _showThemeStudioDialog = MutableStateFlow(false)
    val showThemeStudioDialog = _showThemeStudioDialog.asStateFlow()

    private val _showQuickAttendanceAssistantDialog = MutableStateFlow(false)
    val showQuickAttendanceAssistantDialog = _showQuickAttendanceAssistantDialog.asStateFlow()

    fun openQuickAttendanceAssistant() {
        _showQuickAttendanceAssistantDialog.value = true
    }

    fun dismissQuickAttendanceAssistant() {
        _showQuickAttendanceAssistantDialog.value = false
    }

    fun openThemeStudio() {
        _showThemeStudioDialog.value = true
    }

    fun dismissThemeStudio() {
        _showThemeStudioDialog.value = false
    }

    fun selectTheme(presetId: Int) {
        selectedThemeId.value = presetId
        val preset = com.example.ui.theme.ThemePresetsCatalog.getById(presetId)
        isDarkTheme.value = preset.isDark
        getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
            .edit()
            .putInt("selected_theme_id", presetId)
            .putBoolean("is_dark_theme", preset.isDark)
            .apply()
    }

    fun toggleTheme() {
        openThemeStudio()
    }

    // Modern Picker Dialog States
    private val _showModernDatePicker = MutableStateFlow(false)
    val showModernDatePicker = _showModernDatePicker.asStateFlow()
    var onDateSelectedCallback: ((String) -> Unit)? = null

    private val _showModernTimePicker = MutableStateFlow(false)
    val showModernTimePicker = _showModernTimePicker.asStateFlow()
    var onTimeSelectedCallback: ((String) -> Unit)? = null

    // Developer Contact Dialog State
    private val _showDeveloperContactDialog = MutableStateFlow(false)
    val showDeveloperContactDialog = _showDeveloperContactDialog.asStateFlow()

    private val _showWeekendWarning = MutableStateFlow<String?>(null)
    val showWeekendWarning = _showWeekendWarning.asStateFlow()

    fun dismissWeekendWarning() {
        _showWeekendWarning.value = null
    }

    fun triggerWeekendWarningIfNeeded(dateStr: String) {
        val holiday = getOfficialHolidayForDate(dateStr)
        if (holiday != null) {
            _showWeekendWarning.value = "${holiday.name} (إجازة رسمية)"
            return
        }
        val day = getArabicDayOfWeek(dateStr)
        if (day == "الخميس" || day == "الجمعة" || day == "السبت") {
            _showWeekendWarning.value = day
        }
    }

    fun triggerDeveloperContactDialog() {
        _showDeveloperContactDialog.value = true
    }

    fun dismissDeveloperContactDialog() {
        _showDeveloperContactDialog.value = false
    }

    fun triggerDatePicker(callback: (String) -> Unit) {
        onDateSelectedCallback = callback
        _showModernDatePicker.value = true
    }

    fun triggerTimePicker(callback: (String) -> Unit) {
        onTimeSelectedCallback = callback
        _showModernTimePicker.value = true
    }

    fun dismissDatePicker() {
        _showModernDatePicker.value = false
        onDateSelectedCallback = null
    }

    fun dismissTimePicker() {
        _showModernTimePicker.value = false
        onTimeSelectedCallback = null
    }

    // Coach Warning Thresholds
    private val _maxCumulativeDelay = MutableStateFlow(60)
    val maxCumulativeDelay = _maxCumulativeDelay.asStateFlow()

    private val _maxWeeklyAbsence = MutableStateFlow(2)
    val maxWeeklyAbsence = _maxWeeklyAbsence.asStateFlow()

    private val _maxMonthlyAbsence = MutableStateFlow(5)
    val maxMonthlyAbsence = _maxMonthlyAbsence.asStateFlow()

    // Smart Notifications State
    private val _isSmartNotificationsEnabled = MutableStateFlow(true)
    val isSmartNotificationsEnabled = _isSmartNotificationsEnabled.asStateFlow()

    private val _trainerReminderMinutes = MutableStateFlow(15)
    val trainerReminderMinutes = _trainerReminderMinutes.asStateFlow()

    private val _studentCheckInReminderMinutes = MutableStateFlow(10)
    val studentCheckInReminderMinutes = _studentCheckInReminderMinutes.asStateFlow()

    private val _studentCheckOutReminderMinutes = MutableStateFlow(3)
    val studentCheckOutReminderMinutes = _studentCheckOutReminderMinutes.asStateFlow()

    private val _notificationSound = MutableStateFlow("Default")
    val notificationSound = _notificationSound.asStateFlow()

    private val _voiceGender = MutableStateFlow("female")
    val voiceGender = _voiceGender.asStateFlow()

    fun setVoiceGender(gender: String) {
        _voiceGender.value = gender
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit().putString("voice_gender", gender).commit()
    }

    fun testVoice(gender: String = _voiceGender.value, testText: String = "مرحباً بك! أنا المساعد الصوتي لتطبيق دوامي. تم ضبط نبرة الصوت بنجاح.") {
        setVoiceGender(gender)
        sendTestNotification(
            title = "معاينة نبرة الصوت 🔊",
            message = testText,
            type = "test",
            voiceGender = gender
        )
    }

    private val _trainerGroupSelectedTab = MutableStateFlow(0)
    val trainerGroupSelectedTab: StateFlow<Int> = _trainerGroupSelectedTab.asStateFlow()

    fun setTrainerGroupTab(index: Int) {
        _trainerGroupSelectedTab.value = index
    }

    fun openTrainerGroup(tabIndex: Int = 0) {
        _trainerGroupSelectedTab.value = tabIndex
        navigateTo(Screen.TrainerGroup)
    }

    private val _studentsGroupSelectedTab = MutableStateFlow(0)
    val studentsGroupSelectedTab: StateFlow<Int> = _studentsGroupSelectedTab.asStateFlow()

    fun setStudentsGroupTab(index: Int) {
        _studentsGroupSelectedTab.value = index
    }

    fun openStudentsGroup(tabIndex: Int = 0) {
        _studentsGroupSelectedTab.value = tabIndex
        navigateTo(Screen.StudentsGroup)
    }

    private val _reportsGroupSelectedTab = MutableStateFlow(0)
    val reportsGroupSelectedTab: StateFlow<Int> = _reportsGroupSelectedTab.asStateFlow()

    fun setReportsGroupTab(index: Int) {
        _reportsGroupSelectedTab.value = index
    }

    fun openReportsGroup(tabIndex: Int = 0) {
        _reportsGroupSelectedTab.value = tabIndex
        navigateTo(Screen.ReportsGroup)
    }

    private val _settingsGroupSelectedTab = MutableStateFlow(0)
    val settingsGroupSelectedTab: StateFlow<Int> = _settingsGroupSelectedTab.asStateFlow()

    fun setSettingsGroupTab(index: Int) {
        _settingsGroupSelectedTab.value = index
    }

    fun openSettingsGroup(tabIndex: Int = 0) {
        _settingsGroupSelectedTab.value = tabIndex
        navigateTo(Screen.SettingsGroup)
    }

    // Granular toggles
    private val _isTrainerStartReminderEnabled = MutableStateFlow(true)
    val isTrainerStartReminderEnabled = _isTrainerStartReminderEnabled.asStateFlow()

    // Manual Assignment Grading per Course & Subject
    private val _manualAssignmentGradingMap = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val manualAssignmentGradingMap: StateFlow<Map<String, Boolean>> = _manualAssignmentGradingMap.asStateFlow()

    // --- Course Grading Mode ("AUTO", "MANUAL_BREAKDOWN", "MANUAL_FINAL") ---
    private val _courseGradingModes = MutableStateFlow<Map<Int, String>>(emptyMap())
    val courseGradingModes: StateFlow<Map<Int, String>> = _courseGradingModes.asStateFlow()

    fun loadCourseGradingModes() {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val allEntries = sharedPrefs.all
        val map = mutableMapOf<Int, String>()
        allEntries.forEach { (key, value) ->
            if (key.startsWith("course_grading_mode_") && value is String) {
                val cId = key.removePrefix("course_grading_mode_").toIntOrNull()
                if (cId != null) {
                    map[cId] = value
                }
            }
        }
        _courseGradingModes.value = map
    }

    fun getCourseGradingMode(courseId: Int): String {
        return _courseGradingModes.value[courseId] ?: run {
            val saved = getApplication<Application>()
                .getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
                .getString("course_grading_mode_$courseId", "AUTO") ?: "AUTO"
            saved
        }
    }

    private val _showExamDecisionDialog = MutableStateFlow(false)
    val showExamDecisionDialog = _showExamDecisionDialog.asStateFlow()

    private var pendingAttendanceAction: (() -> Unit)? = null
    private var pendingExamDecisionCourseId: Int = -1
    private var pendingExamDecisionSubjectName: String = ""

    fun dismissExamDecisionDialog() {
        _showExamDecisionDialog.value = false
        pendingAttendanceAction = null
        pendingExamDecisionCourseId = -1
        pendingExamDecisionSubjectName = ""
    }

    fun handleExamDecision(isExam: Boolean) {
        if (isExam) {
            _isExamDayForNextRecord.value = true
        } else {
            // Supplementary Lesson: increment targetDays
            if (pendingExamDecisionCourseId != -1 && pendingExamDecisionSubjectName.isNotEmpty()) {
                val stats = getCourseSubjectStats(pendingExamDecisionCourseId)
                val stat = stats.find { it.subjectName.trim().equals(pendingExamDecisionSubjectName.trim(), ignoreCase = true) }
                if (stat != null) {
                    updateCourseSubjectStatus(
                        courseId = pendingExamDecisionCourseId,
                        subjectId = stat.subjectId,
                        newStatus = stat.status, // Keep same status
                        targetDays = stat.targetDays + 1
                    )
                }
            }
        }
        val action = pendingAttendanceAction
        _showExamDecisionDialog.value = false
        pendingAttendanceAction = null
        pendingExamDecisionCourseId = -1
        pendingExamDecisionSubjectName = ""
        action?.invoke()
    }

    private val _isExamDayForNextRecord = MutableStateFlow(false)
    val isExamDayForNextRecord = _isExamDayForNextRecord.asStateFlow()

    fun setIsExamDayForNextRecord(value: Boolean) {
        _isExamDayForNextRecord.value = value
    }

    fun toggleAttendanceExamDay(record: Attendance) {
        viewModelScope.launch {
            val updated = record.copy(isExamDay = !record.isExamDay)
            repository.updateAttendance(updated)
            val stats = getCourseSubjectStats(updated.courseId)
            val stat = stats.find { it.subjectName.trim().equals(updated.subjectName.trim(), ignoreCase = true) }
            if (stat != null) {
                val newStatus = if (updated.isExamDay) "مكتملة التدريس" else "قيد التدريس"
                updateCourseSubjectStatus(updated.courseId, stat.subjectId, newStatus)
            }
        }
    }

    fun setCourseGradingMode(courseId: Int, mode: String) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit().putString("course_grading_mode_$courseId", mode).apply()
        _courseGradingModes.value = _courseGradingModes.value + (courseId to mode)
    }

    fun bulkApplyComponentGrade(courseId: Int, subjectNames: List<String>, componentName: String, score: Double, onlyIfEmpty: Boolean = false) {
        viewModelScope.launch {
            val course = dbCourses.value.find { it.id == courseId } ?: return@launch
            val students = dbAllStudents.value.filter { it.courseId == courseId && (it.status == "مستمر" || it.status.isEmpty()) }
            val currentConfig = dbAllGradeConfigs.value.find { it.courseId == courseId }
            val isDiploma = currentConfig?.isDiploma ?: course.diplomaName.isNotBlank()

            subjectNames.forEach { subjectName ->
                val currentGrades = dbAllGrades.value.filter { it.courseId == courseId && (subjectName.isEmpty() || it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true)) }

                students.forEach { student ->
                    val existing = currentGrades.find { it.studentId == student.id }
                    if (onlyIfEmpty && existing != null && existing.getTotalScore() > 0) {
                        return@forEach
                    }
                    val base = (existing ?: StudentGrade(
                        studentId = student.id,
                        studentName = student.name,
                        courseId = courseId,
                        courseName = course.name,
                        subjectName = subjectName,
                        isDiploma = isDiploma
                    )).copy(isDiploma = isDiploma)

                    val updatedGrade = if (isDiploma) {
                        when {
                            componentName.contains("حضور") -> base.copy(attendanceScore = score)
                            componentName.contains("مشاركة") -> base.copy(participationScore = score)
                            componentName.contains("تكاليف") || componentName.contains("واجبات") -> base.copy(assignmentsScore = score)
                            componentName.contains("مشاريع") || componentName.contains("مشروع") -> base.copy(projectsScore = score)
                            componentName.contains("نظري") -> base.copy(theoreticalExamScore = score)
                            componentName.contains("عملي") -> base.copy(practicalExamScore = score)
                            else -> {
                                val map = base.getScoresMap().toMutableMap()
                                map[componentName] = score
                                base.copy(customScoresJson = map.entries.joinToString("|") { "${it.key}:${it.value}" })
                            }
                        }
                    } else {
                        val map = base.getScoresMap().toMutableMap()
                        map[componentName] = score
                        base.copy(customScoresJson = map.entries.joinToString("|") { "${it.key}:${it.value}" })
                    }.withManualGrading(true)
                    saveStudentGrade(updatedGrade)
                }
            }
        }
    }

    fun bulkApplyFinalGrade(courseId: Int, subjectNames: List<String>, finalScore: Double, onlyIfEmpty: Boolean = false) {
        viewModelScope.launch {
            val course = dbCourses.value.find { it.id == courseId } ?: return@launch
            val students = dbAllStudents.value.filter { it.courseId == courseId && (it.status == "مستمر" || it.status.isEmpty()) }
            val currentConfig = dbAllGradeConfigs.value.find { it.courseId == courseId }
            val isDiploma = currentConfig?.isDiploma ?: course.diplomaName.isNotBlank()

            subjectNames.forEach { subjectName ->
                val currentGrades = dbAllGrades.value.filter { it.courseId == courseId && (subjectName.isEmpty() || it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true)) }

                students.forEach { student ->
                    val existing = currentGrades.find { it.studentId == student.id }
                    if (onlyIfEmpty && existing != null && existing.getTotalScore() > 0) {
                        return@forEach
                    }
                    val base = (existing ?: StudentGrade(
                        studentId = student.id,
                        studentName = student.name,
                        courseId = courseId,
                        courseName = course.name,
                        subjectName = subjectName,
                        isDiploma = isDiploma
                    )).copy(isDiploma = isDiploma)
                    val updatedGrade = base.withManualFinalGrading(finalScore)
                    saveStudentGrade(updatedGrade)
                }
            }
        }
    }

    fun smartPrefillBreakdownGrades(courseId: Int, subjectName: String = "") {
        viewModelScope.launch {
            val course = dbCourses.value.find { it.id == courseId } ?: return@launch
            val students = dbAllStudents.value.filter { it.courseId == courseId && (it.status == "مستمر" || it.status.isEmpty()) }
            val currentGrades = dbAllGrades.value.filter { it.courseId == courseId && (subjectName.isEmpty() || it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true)) }

            students.forEach { student ->
                val existing = currentGrades.find { it.studentId == student.id }
                if (existing != null) {
                    val updated = existing.withManualGrading(true)
                    saveStudentGrade(updated)
                }
            }
        }
    }

    fun loadManualAssignmentGradingMap() {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val allEntries = sharedPrefs.all
        val map = mutableMapOf<String, Boolean>()
        allEntries.forEach { (key, value) ->
            if (key.startsWith("manual_assignment_mode_") && value is Boolean) {
                map[key.removePrefix("manual_assignment_mode_")] = value
            }
        }
        _manualAssignmentGradingMap.value = map
    }

    fun isManualAssignmentGrading(courseId: Int, subjectName: String): Boolean {
        val key = "${courseId}_${subjectName.trim()}"
        return _manualAssignmentGradingMap.value[key] ?: false
    }

    fun setManualAssignmentGrading(courseId: Int, subjectName: String, isManual: Boolean) {
        val key = "${courseId}_${subjectName.trim()}"
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit().putBoolean("manual_assignment_mode_$key", isManual).apply()
        _manualAssignmentGradingMap.value = _manualAssignmentGradingMap.value + (key to isManual)
    }

    fun setCourseAllSubjectsManualGrading(courseId: Int, subjectNames: List<String>, isManual: Boolean) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val editor = sharedPrefs.edit()
        val current = _manualAssignmentGradingMap.value.toMutableMap()
        subjectNames.forEach { subjectName ->
            val key = "${courseId}_${subjectName.trim()}"
            editor.putBoolean("manual_assignment_mode_$key", isManual)
            current[key] = isManual
        }
        editor.apply()
        _manualAssignmentGradingMap.value = current
    }

    fun updateStudentAssignmentAndProjectScore(
        courseId: Int,
        subjectName: String,
        studentId: Int,
        studentName: String,
        assignmentScore: Double,
        projectScore: Double
    ) {
        viewModelScope.launch {
            val currentConfig = dbAllGradeConfigs.value.find { it.courseId == courseId }
            val existingGradeRecord = dbAllGrades.value.find { 
                it.studentId == studentId && it.courseId == courseId && 
                (it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true) || (it.subjectName.isEmpty() && subjectName.isEmpty()))
            }
            
            if (currentConfig?.isDiploma != false) {
                val gradeObj = StudentGrade(
                    id = existingGradeRecord?.id ?: 0,
                    studentId = studentId,
                    studentName = studentName,
                    courseId = courseId,
                    courseName = currentConfig?.courseName ?: "",
                    isDiploma = true,
                    subjectName = subjectName,
                    attendanceScore = existingGradeRecord?.attendanceScore ?: 0.0,
                    participationScore = existingGradeRecord?.participationScore ?: 0.0,
                    assignmentsScore = assignmentScore,
                    projectsScore = projectScore,
                    theoreticalExamScore = existingGradeRecord?.theoreticalExamScore ?: 0.0,
                    practicalExamScore = existingGradeRecord?.practicalExamScore ?: 0.0
                )
                saveStudentGrade(gradeObj)
            } else {
                val scoresMap = (existingGradeRecord?.getScoresMap() ?: emptyMap()).toMutableMap()
                val allConfigFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson)
                val subjectFields = allConfigFields.filter { it.first.startsWith("${subjectName}_") }
                    .map { Pair(it.first.substringAfter("${subjectName}_"), it.second) }
                val assName = subjectFields.find { it.first.contains("تكاليف") || it.first.contains("واجبات") || it.first.contains("بحوث") }?.first ?: "تكاليف"
                val projName = subjectFields.find { it.first.contains("مشاريع") || it.first.contains("مشروع") }?.first ?: "مشاريع"
                scoresMap[assName] = assignmentScore
                scoresMap[projName] = projectScore
                val gradeObj = StudentGrade(
                    id = existingGradeRecord?.id ?: 0,
                    studentId = studentId,
                    studentName = studentName,
                    courseId = courseId,
                    courseName = currentConfig.courseName,
                    isDiploma = false,
                    subjectName = subjectName,
                    customScoresJson = StudentGrade.serializeScores(scoresMap)
                )
                saveStudentGrade(gradeObj)
            }
            setManualAssignmentGrading(courseId, subjectName, true)
            logActivity(
                category = "GRADES",
                actionType = "UPDATE",
                title = "رصد يدوي لدرجات الطالب: $studentName",
                description = "المادة: $subjectName | تكاليف: $assignmentScore | مشاريع: $projectScore",
                relatedId = courseId.toLong()
            )
        }
    }

    private val _isTrainerCheckInReminderEnabled = MutableStateFlow(true)
    val isTrainerCheckInReminderEnabled = _isTrainerCheckInReminderEnabled.asStateFlow()

    private val _isStudentCheckInReminderEnabled = MutableStateFlow(true)
    val isStudentCheckInReminderEnabled = _isStudentCheckInReminderEnabled.asStateFlow()

    private val _isStudentCheckInSuccessEnabled = MutableStateFlow(true)
    val isStudentCheckInSuccessEnabled = _isStudentCheckInSuccessEnabled.asStateFlow()

    private val _isStudentCheckOutReminderEnabled = MutableStateFlow(true)
    val isStudentCheckOutReminderEnabled = _isStudentCheckOutReminderEnabled.asStateFlow()

    private val _isStudentCheckOutSuccessEnabled = MutableStateFlow(true)
    val isStudentCheckOutSuccessEnabled = _isStudentCheckOutSuccessEnabled.asStateFlow()

    private val _isThursdayNotificationsEnabled = MutableStateFlow(false)
    val isThursdayNotificationsEnabled = _isThursdayNotificationsEnabled.asStateFlow()

    private val _isFridayNotificationsEnabled = MutableStateFlow(false)
    val isFridayNotificationsEnabled = _isFridayNotificationsEnabled.asStateFlow()

    // Custom voice prompt text strings
    private val _trainerStartReminderText = MutableStateFlow("الرجاء الاستعداد للدورة، باقي من الوقت عشر دقائق")
    val trainerStartReminderText = _trainerStartReminderText.asStateFlow()

    private val _trainerCheckInPromptText = MutableStateFlow("الرجاء تحضير نفسك في حافظة الدوام")
    val trainerCheckInPromptText = _trainerCheckInPromptText.asStateFlow()

    private val _studentCheckInPromptText = MutableStateFlow("بدأت المحاضرة الرجاء تحضير الطلاب")
    val studentCheckInPromptText = _studentCheckInPromptText.asStateFlow()

    private val _studentCheckInRemindText = MutableStateFlow("أستاذ فيصل الرجاء تحضير الطلاب")
    val studentCheckInRemindText = _studentCheckInRemindText.asStateFlow()

    private val _studentCheckInSuccessText = MutableStateFlow("لقد تم تحضير الطلاب بنجاح شكرا لك")
    val studentCheckInSuccessText = _studentCheckInSuccessText.asStateFlow()

    private val _studentCheckOutPromptText = MutableStateFlow("حان وقت انصراف الطلاب")
    val studentCheckOutPromptText = _studentCheckOutPromptText.asStateFlow()

    private val _studentCheckOutRemindText = MutableStateFlow("أستاذ فيصل الرجاء تحضير انصراف الطلاب")
    val studentCheckOutRemindText = _studentCheckOutRemindText.asStateFlow()

    private val _studentCheckOutSuccessText = MutableStateFlow("تم تسجيل انصراف الطلاب بنجاح")
    val studentCheckOutSuccessText = _studentCheckOutSuccessText.asStateFlow()

    private var lastInstantSuccessCheckInTime = 0L
    private var lastInstantSuccessCheckOutTime = 0L

    private var lastObservedCourseId: Int? = null
    private var lastObservedDate: String? = null
    private var hasTriggeredCheckInForCurrentSession = false
    private var hasTriggeredCheckOutForCurrentSession = false

    fun updateSmartNotificationSettings(
        enabled: Boolean,
        trainerMins: Int,
        checkInMins: Int,
        checkOutMins: Int,
        sound: String
    ) {
        _isSmartNotificationsEnabled.value = enabled
        _trainerReminderMinutes.value = trainerMins
        _studentCheckInReminderMinutes.value = checkInMins
        val effectiveCheckOutDelay = if (checkOutMins > 0) checkOutMins else 3
        _studentCheckOutReminderMinutes.value = effectiveCheckOutDelay
        _notificationSound.value = sound

        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit()
            .putBoolean("smart_notifications_enabled", enabled)
            .putInt("trainer_reminder_minutes", trainerMins)
            .putInt("student_check_in_reminder_minutes", checkInMins)
            .putInt("student_check_out_reminder_minutes", effectiveCheckOutDelay)
            .putString("notification_sound", sound)
            .apply()

        rescheduleAllReminders()
    }

    fun updateSmartAssistantSettings(
        enabled: Boolean,
        trainerMins: Int,
        checkInMins: Int,
        checkOutMins: Int,
        sound: String,
        isTrainerStartEnabled: Boolean,
        isTrainerCheckInEnabled: Boolean,
        isStudentCheckInEnabled: Boolean,
        isStudentCheckInSuccessEnabled: Boolean,
        isStudentCheckOutEnabled: Boolean,
        isStudentCheckOutSuccessEnabled: Boolean,
        isThursdayNotificationsEnabled: Boolean,
        isFridayNotificationsEnabled: Boolean,
        trainerStartText: String,
        trainerCheckInText: String,
        studentCheckInText: String,
        studentCheckInRemindText: String,
        studentCheckInSuccessText: String,
        studentCheckOutText: String,
        studentCheckOutRemindText: String,
        studentCheckOutSuccessText: String,
        voiceGender: String = _voiceGender.value
    ) {
        _isSmartNotificationsEnabled.value = enabled
        _trainerReminderMinutes.value = trainerMins
        _studentCheckInReminderMinutes.value = checkInMins
        val effectiveCheckOutDelay = if (checkOutMins > 0) checkOutMins else 3
        _studentCheckOutReminderMinutes.value = effectiveCheckOutDelay
        _notificationSound.value = sound
        _voiceGender.value = voiceGender

        _isTrainerStartReminderEnabled.value = isTrainerStartEnabled
        _isTrainerCheckInReminderEnabled.value = isTrainerCheckInEnabled
        _isStudentCheckInReminderEnabled.value = isStudentCheckInEnabled
        _isStudentCheckInSuccessEnabled.value = isStudentCheckInSuccessEnabled
        _isStudentCheckOutReminderEnabled.value = isStudentCheckOutEnabled
        _isStudentCheckOutSuccessEnabled.value = isStudentCheckOutSuccessEnabled
        _isThursdayNotificationsEnabled.value = isThursdayNotificationsEnabled
        _isFridayNotificationsEnabled.value = isFridayNotificationsEnabled

        _trainerStartReminderText.value = trainerStartText
        _trainerCheckInPromptText.value = trainerCheckInText
        _studentCheckInPromptText.value = studentCheckInText
        _studentCheckInRemindText.value = studentCheckInRemindText
        _studentCheckInSuccessText.value = studentCheckInSuccessText
        _studentCheckOutPromptText.value = studentCheckOutText
        _studentCheckOutRemindText.value = studentCheckOutRemindText
        _studentCheckOutSuccessText.value = studentCheckOutSuccessText

        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit()
            .putBoolean("smart_notifications_enabled", enabled)
            .putInt("trainer_reminder_minutes", trainerMins)
            .putInt("student_check_in_reminder_minutes", checkInMins)
            .putInt("student_check_out_reminder_minutes", checkOutMins)
            .putString("notification_sound", sound)
            .putString("voice_gender", voiceGender)
            .putBoolean("is_trainer_start_reminder_enabled", isTrainerStartEnabled)
            .putBoolean("is_trainer_check_in_reminder_enabled", isTrainerCheckInEnabled)
            .putBoolean("is_student_check_in_reminder_enabled", isStudentCheckInEnabled)
            .putBoolean("is_student_check_in_success_enabled", isStudentCheckInSuccessEnabled)
            .putBoolean("is_student_check_out_reminder_enabled", isStudentCheckOutEnabled)
            .putBoolean("is_student_check_out_success_enabled", isStudentCheckOutSuccessEnabled)
            .putBoolean("is_thursday_notifications_enabled", isThursdayNotificationsEnabled)
            .putBoolean("is_friday_notifications_enabled", isFridayNotificationsEnabled)
            .putString("trainer_start_reminder_text", trainerStartText)
            .putString("trainer_check_in_prompt_text", trainerCheckInText)
            .putString("student_check_in_prompt_text", studentCheckInText)
            .putString("student_check_in_remind_text", studentCheckInRemindText)
            .putString("student_check_in_success_text", studentCheckInSuccessText)
            .putString("student_check_out_prompt_text", studentCheckOutText)
            .putString("student_check_out_remind_text", studentCheckOutRemindText)
            .putString("student_check_out_success_text", studentCheckOutSuccessText)
            .apply()

        rescheduleAllReminders()
    }

    fun setThursdayNotificationsEnabled(enabled: Boolean) {
        _isThursdayNotificationsEnabled.value = enabled
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit().putBoolean("is_thursday_notifications_enabled", enabled).apply()
        rescheduleAllReminders()
    }

    fun updateThresholds(delay: Int, weekly: Int, monthly: Int) {
        _maxCumulativeDelay.value = delay
        _maxWeeklyAbsence.value = weekly
        _maxMonthlyAbsence.value = monthly
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit()
            .putInt("max_cumulative_delay", delay)
            .putInt("max_weekly_absence", weekly)
            .putInt("max_monthly_absence", monthly)
            .apply()
    }

    data class StudentMetrics(
        val totalDelayMinutes: Int,
        val maxWeeklyAbsences: Int,
        val maxMonthlyAbsences: Int
    )

    fun getStudentMetrics(studentId: Int, courseId: Int): StudentMetrics {
        val studentRecords = dbAllStudentAttendance.value.filter { it.studentId == studentId && it.courseId == courseId }
        val totalDelay = studentRecords.sumOf { it.checkInDelayMinutes }

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = java.util.Calendar.getInstance()
        val absencesByWeek = mutableMapOf<String, Int>()
        val absencesByMonth = mutableMapOf<String, Int>()

        studentRecords.forEach { r ->
            if (r.status == "غياب") {
                try {
                    val d = sdf.parse(r.date)
                    if (d != null) {
                        cal.time = d
                        val weekKey = "${cal.get(java.util.Calendar.YEAR)}-W${cal.get(java.util.Calendar.WEEK_OF_YEAR)}"
                        val monthKey = "${cal.get(java.util.Calendar.YEAR)}-M${cal.get(java.util.Calendar.MONTH) + 1}"
                        absencesByWeek[weekKey] = (absencesByWeek[weekKey] ?: 0) + 1
                        absencesByMonth[monthKey] = (absencesByMonth[monthKey] ?: 0) + 1
                    }
                } catch (e: Exception) {}
            }
        }

        val maxWeekly = absencesByWeek.values.maxOrNull() ?: 0
        val maxMonthly = absencesByMonth.values.maxOrNull() ?: 0

        return StudentMetrics(totalDelay, maxWeekly, maxMonthly)
    }

    fun saveInstituteIdentity(
        name: String,
        symbol: String,
        slogan: String,
        director: String,
        hrManager: String,
        trainer: String,
        logoUri: String
    ) {
        var finalLogo = logoUri
        if (logoUri.startsWith("content://")) {
            val context = getApplication<Application>().applicationContext
            val path = copyUriToInternalStorage(context, android.net.Uri.parse(logoUri), "institute_logo.png")
            if (path.isNotEmpty()) finalLogo = path
        }

        instituteName.value = name
        instituteLogoSymbol.value = symbol
        instituteSlogan.value = slogan
        directorName.value = director
        hrManagerName.value = hrManager
        trainerNameConfig.value = trainer
        instituteLogoUri.value = finalLogo

        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit()
            .putString("institute_name", name)
            .putString("institute_logo_symbol", symbol)
            .putString("institute_slogan", slogan)
            .putString("director_name", director)
            .putString("hr_manager_name", hrManager)
            .putString("trainer_name_config", trainer)
            .putString("institute_logo_uri", finalLogo)
            .apply()
    }

    fun saveTrainerProfile(
        name: String,
        title: String,
        phone: String,
        email: String,
        idNumber: String,
        bio: String,
        avatarUri: String,
        signatureUri: String
    ) {
        var finalAvatar = avatarUri
        if (avatarUri.startsWith("content://")) {
            val context = getApplication<Application>().applicationContext
            val path = copyUriToInternalStorage(context, android.net.Uri.parse(avatarUri), "trainer_avatar.png")
            if (path.isNotEmpty()) finalAvatar = path
        }
        var finalSig = signatureUri
        if (signatureUri.startsWith("content://")) {
            val context = getApplication<Application>().applicationContext
            val path = copyUriToInternalStorage(context, android.net.Uri.parse(signatureUri), "trainer_signature.png")
            if (path.isNotEmpty()) finalSig = path
        }

        trainerNameConfig.value = name
        trainerTitleConfig.value = title
        trainerPhoneConfig.value = phone
        trainerEmailConfig.value = email
        trainerIdNumberConfig.value = idNumber
        trainerBioConfig.value = bio
        trainerAvatarUriConfig.value = finalAvatar
        trainerSignatureUriConfig.value = finalSig

        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit()
            .putString("trainer_name_config", name)
            .putString("trainer_title_config", title)
            .putString("trainer_phone_config", phone)
            .putString("trainer_email_config", email)
            .putString("trainer_id_number_config", idNumber)
            .putString("trainer_bio_config", bio)
            .putString("trainer_avatar_uri_config", finalAvatar)
            .putString("trainer_signature_uri_config", finalSig)
            .apply()

        logActivity(
            category = "المدرب",
            actionType = "تحديث",
            title = "تحديث الملف الشخصي للمدرب",
            description = "تم تحديث بيانات الملف الشخصي للمدرب: $name"
        )
    }

    fun saveOnboardingSetup(
        orgTypeVal: String,
        instName: String,
        dirName: String,
        logoUri: String,
        departments: List<com.example.ui.screens.DepartmentItem>
    ) {
        orgType.value = orgTypeVal
        instituteName.value = instName
        directorName.value = dirName
        instituteLogoUri.value = logoUri
        hasCompletedOnboarding.value = true

        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit()
            .putString("org_type", orgTypeVal)
            .putString("institute_name", instName)
            .putString("director_name", dirName)
            .putString("institute_logo_uri", logoUri)
            .putBoolean("has_completed_onboarding", true)
            .apply()

        saveCurriculumStructure(departments)
    }

    fun saveCurriculumStructure(
        departments: List<com.example.ui.screens.DepartmentItem>,
        onComplete: (() -> Unit)? = null
    ) {
        // Insert default or created subjects into Database and delete removed ones
        viewModelScope.launch {
            val newSubjectsSet = mutableSetOf<Triple<String, String, String>>() // <deptName, diplomaName, subName>
            departments.forEach { dept ->
                dept.diplomas.forEach { diploma ->
                    diploma.subjects.forEach { subName ->
                        newSubjectsSet.add(Triple(dept.name.trim(), diploma.name.trim(), subName.trim()))
                    }
                }
            }

            // 1. Delete subjects that are no longer in the list safely without deleting active subjects or unmanaged depts
            val managedDeptNames = departments.map { it.name.trim() }.toSet()
            dbSubjects.value.forEach { existingSub ->
                val deptNorm = existingSub.departmentName.trim().ifBlank { "أقسام عامة" }
                val dipNorm = existingSub.diplomaName.trim().ifBlank { "دبلومات وبرامج عامة" }
                val key = Triple(deptNorm, dipNorm, existingSub.name.trim())
                if (deptNorm in managedDeptNames && key !in newSubjectsSet) {
                    val hasCourseAssignment = dbCourseSubjects.value.any { it.subjectId == existingSub.id }
                    val hasTopics = dbLessonTopics.value.any { it.subjectId == existingSub.id }
                    val hasGrades = dbAllGrades.value.any { it.subjectName.equals(existingSub.name, ignoreCase = true) }
                    if (!hasCourseAssignment && !hasTopics && !hasGrades) {
                        repository.deleteSubject(existingSub)
                    }
                }
            }

            // 2. Insert new subjects
            departments.forEach { dept ->
                dept.diplomas.forEach { diploma ->
                    diploma.subjects.forEach { subName ->
                        val existing = dbSubjects.value.find { 
                            it.name == subName && 
                            it.diplomaName == diploma.name && 
                            it.departmentName == dept.name 
                        }
                        if (existing == null) {
                            repository.insertSubject(
                                Subject(
                                    name = subName,
                                    code = "",
                                    description = "مادة تابعة لـ ${diploma.name}",
                                    departmentName = dept.name,
                                    diplomaName = diploma.name
                                )
                            )
                        }
                    }
                }
            }

            // 3. Save grade configurations as templates for each department and diploma
            departments.forEach { dept ->
                val deptTemplateId = com.example.data.entity.StudentGradeConfig.getDepartmentTemplateId(dept.name)
                val deptFields = if (dept.name.contains("حاسب") || dept.name.contains("حاسوب")) {
                    listOf(
                        Pair("حضور", 5),
                        Pair("مشاركة", 5),
                        Pair("تكاليف", 10),
                        Pair("مشاريع", 20),
                        Pair("اختبار نظري", 20),
                        Pair("اختبار عملي", 40)
                    )
                } else {
                    listOf(
                        Pair("حضور", 10),
                        Pair("مشاركة", 10),
                        Pair("تكاليف", 20),
                        Pair("اختبار نظري", 30),
                        Pair("اختبار عملي", 30)
                    )
                }
                
                // Save Department Template
                val deptSubsList = dept.diplomas.flatMap { it.subjects }.distinct()
                val deptWeightsJson = deptSubsList.joinToString("|") { "${it.trim()}:100.0" }
                repository.insertGradeConfig(
                    com.example.data.entity.StudentGradeConfig(
                        courseId = deptTemplateId,
                        courseName = "قالب قسم: ${dept.name}",
                        isDiploma = true,
                        customFieldsJson = com.example.data.entity.StudentGradeConfig.serializeFields(deptFields),
                        diplomaSubjectsJson = deptSubsList.joinToString("|"),
                        subjectWeightsJson = deptWeightsJson
                    )
                )

                dept.diplomas.forEach { diploma ->
                    val diplomaTemplateId = com.example.data.entity.StudentGradeConfig.getDiplomaTemplateId(diploma.name)
                    
                    val compiledFields = mutableListOf<Pair<String, Int>>()
                    // 1. Default fields
                    compiledFields.addAll(diploma.customFields.ifEmpty { deptFields })
                    // 2. Subject specific custom fields
                    diploma.subjects.forEach { subject ->
                        val customSubFields = diploma.subjectCustomFields[subject]
                        if (customSubFields != null && customSubFields.isNotEmpty()) {
                            customSubFields.forEach { pair ->
                                compiledFields.add("${subject}_${pair.first}" to pair.second)
                            }
                        }
                    }
                    
                    val fieldsJson = com.example.data.entity.StudentGradeConfig.serializeFields(compiledFields)
                    val weightsMap = if (diploma.subjectWeights.isNotEmpty()) {
                        diploma.subjectWeights
                    } else {
                        diploma.subjects.associateWith { 100.0 }
                    }
                    val weightsJson = com.example.data.entity.StudentGradeConfig.serializeSubjectWeights(weightsMap)
                    val subsJson = diploma.subjects.joinToString("|")

                    // Save Diploma Template
                    repository.insertGradeConfig(
                        com.example.data.entity.StudentGradeConfig(
                            courseId = diplomaTemplateId,
                            courseName = "قالب دبلوم: ${diploma.name}",
                            isDiploma = true,
                            customFieldsJson = fieldsJson,
                            diplomaSubjectsJson = subsJson,
                            subjectWeightsJson = weightsJson,
                            passingGradePercentage = diploma.passingPercentage
                        )
                    )

                    // Also update existing courses matching this diploma
                    dbCourses.value.filter { it.diplomaName.trim().equals(diploma.name.trim(), ignoreCase = true) }.forEach { course ->
                        val existing = dbAllGradeConfigs.value.find { it.courseId == course.id }
                        val updatedConfig = com.example.data.entity.StudentGradeConfig(
                            courseId = course.id,
                            courseName = course.name,
                            isDiploma = true,
                            customFieldsJson = fieldsJson,
                            diplomaSubjectsJson = subsJson,
                            subjectWeightsJson = if (weightsJson.isNotBlank()) weightsJson else (existing?.subjectWeightsJson ?: ""),
                            passingGradePercentage = diploma.passingPercentage
                        )
                        repository.insertGradeConfig(updatedConfig)
                    }
                }
            }

            logActivity(
                category = "CURRICULUM",
                actionType = "UPDATE",
                title = "تحديث الهيكل الأكاديمي للأقسام والمواد",
                description = "تم تحديث ${departments.size} أقسام أكاديمية وموادها وقوالب درجاتها."
            )
            onComplete?.invoke()
        }
    }

    private fun loadInstituteIdentity() {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        orgType.value = sharedPrefs.getString("org_type", "معهد") ?: "معهد"
        hasCompletedOnboarding.value = sharedPrefs.getBoolean("has_completed_onboarding", false)
        instituteName.value = sharedPrefs.getString("institute_name", "معهد دوامي للتدريب") ?: "معهد دوامي للتدريب"
        instituteLogoSymbol.value = sharedPrefs.getString("institute_logo_symbol", "school") ?: "school"
        instituteSlogan.value = sharedPrefs.getString("institute_slogan", "نظام المتابعة والتحضير الذكي") ?: "نظام المتابعة والتحضير الذكي"
        directorName.value = sharedPrefs.getString("director_name", "مدير الهيئة / المؤسسة التدريبية") ?: "مدير الهيئة / المؤسسة التدريبية"
        hrManagerName.value = sharedPrefs.getString("hr_manager_name", "مسؤول إدارة الموارد البشرية والتدريب") ?: "مسؤول إدارة الموارد البشرية والتدريب"
        trainerNameConfig.value = sharedPrefs.getString("trainer_name_config", "م. فيصل العفيف") ?: "م. فيصل العفيف"
        trainerTitleConfig.value = sharedPrefs.getString("trainer_title_config", "مدرب تقني معتمد") ?: "مدرب تقني معتمد"
        trainerPhoneConfig.value = sharedPrefs.getString("trainer_phone_config", "") ?: ""
        trainerEmailConfig.value = sharedPrefs.getString("trainer_email_config", "") ?: ""
        trainerIdNumberConfig.value = sharedPrefs.getString("trainer_id_number_config", "") ?: ""
        trainerBioConfig.value = sharedPrefs.getString("trainer_bio_config", "") ?: ""
        trainerAvatarUriConfig.value = sharedPrefs.getString("trainer_avatar_uri_config", "") ?: ""
        trainerSignatureUriConfig.value = sharedPrefs.getString("trainer_signature_uri_config", "") ?: ""
        val savedLogo = sharedPrefs.getString("institute_logo_uri", "") ?: ""
        val internalLogo = java.io.File(getApplication<Application>().filesDir, "institute_logo.png")
        if (savedLogo.isNotEmpty()) {
            instituteLogoUri.value = savedLogo
        } else if (internalLogo.exists()) {
            instituteLogoUri.value = internalLogo.absolutePath
        } else {
            instituteLogoUri.value = ""
        }
        isBiometricEnabled.value = sharedPrefs.getBoolean("is_biometric_enabled", false)
        
        activationTimestamp.value = sharedPrefs.getLong("activation_timestamp", 0L)
        activationDurationMonths.value = sharedPrefs.getInt("activation_duration_months", 12)
        activationCode.value = sharedPrefs.getString("activation_code", "") ?: ""
    }

    fun saveBiometricEnabled(enabled: Boolean) {
        isBiometricEnabled.value = enabled
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit().putBoolean("is_biometric_enabled", enabled).apply()
    }

    // ---------- دوال البصمة المعدلة ----------
    fun isBiometricReady(): Boolean {
        val context = getApplication<Application>()
        val biometricManager = BiometricManager.from(context)
        return biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        ) == BiometricManager.BIOMETRIC_SUCCESS
    }

    suspend fun loginWithBiometrics(activity: androidx.fragment.app.FragmentActivity): Boolean {
        val context = getApplication<Application>()
                val sharedPrefs = context.getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val isRegistered = sharedPrefs.getBoolean("is_registered", false)
        if (!isRegistered) {
            _loginError.value = "يرجى تسجيل حساب أولاً قبل استخدام الدخول ببصمة الإصبع."
            return false
        }

        return suspendCancellableCoroutine { continuation ->
            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle("تسجيل الدخول ببصمة الإصبع")
                .setSubtitle("ضع إصبعك للمتابعة")
                .setDescription("استخدم بصمة إصبعك لتأكيد هويتك")
                .setNegativeButtonText("إلغاء")
                .setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_STRONG
                )
                .build()

            val executor = ContextCompat.getMainExecutor(activity)
            val biometricPrompt = BiometricPrompt(
                activity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        if (continuation.isActive) {
                            val savedUsername = sharedPrefs.getString("saved_username", "admin") ?: "admin"
                            _isLoggedIn.value = true
                            _loggedInUser.value = savedUsername
                            _loginError.value = null
                            _currentScreen.value = Screen.Selection
                            selectedRoleMode.value = "none"
                            continuation.resume(true) { }
                        }
                    }

                    override fun onAuthenticationFailed() {
                        // فشل مؤقت – لا نفعل شيئاً، prompt يبقى مفتوحاً
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        if (continuation.isActive) {
                            _loginError.value = "فشل التحقق: $errString"
                            continuation.resume(false) { }
                        }
                    }
                }
            )

            biometricPrompt.authenticate(promptInfo)

            continuation.invokeOnCancellation {
                biometricPrompt.cancelAuthentication()
            }
        }
    }

    suspend fun loginDirectlyWithBiometrics(activity: androidx.fragment.app.FragmentActivity): Boolean {
        return loginWithBiometrics(activity)
    }
    // ------------------------------------------

    fun copyUriToInternalStorage(context: android.content.Context, uri: android.net.Uri, fileName: String = "institute_logo.png"): String {
        return try {
            val contentResolver = context.contentResolver
            val inputStream = contentResolver.openInputStream(uri) ?: return ""
            val file = java.io.File(context.filesDir, fileName)
            val outputStream = java.io.FileOutputStream(file)
            inputStream.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }
            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _loggedInUser = MutableStateFlow("")
    val loggedInUser: StateFlow<String> = _loggedInUser.asStateFlow()

    val selectedRoleMode = MutableStateFlow("none")

    fun selectRoleMode(mode: String) {
        selectedRoleMode.value = mode
    }

    private val _selectedGradesTabIndex = MutableStateFlow(0)
    val selectedGradesTabIndex: StateFlow<Int> = _selectedGradesTabIndex.asStateFlow()

    fun setSelectedGradesTabIndex(tabIndex: Int) {
        _selectedGradesTabIndex.value = tabIndex
    }

    val externalNotificationsEnabled = MutableStateFlow(true)
    val reminderOffsetMinutes = MutableStateFlow(15)
    val isBiometricEnabled = MutableStateFlow(false)

    private val _includeLessonTopicsInReport = MutableStateFlow(true)
    val includeLessonTopicsInReport: StateFlow<Boolean> = _includeLessonTopicsInReport.asStateFlow()

    fun setIncludeLessonTopicsInReport(enabled: Boolean) {
        _includeLessonTopicsInReport.value = enabled
        getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
            .edit()
            .putBoolean("include_lesson_topics_in_report", enabled)
            .apply()
    }

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    // Database flow inputs
    val dbCourses: StateFlow<List<Course>>
    val dbAttendance: StateFlow<List<Attendance>>
    val dbAllStudents: StateFlow<List<Student>>
    val dbAllStudentAttendance: StateFlow<List<StudentAttendance>>
    val dbAllDailyNotes: StateFlow<List<DailyCourseNote>>
    val dbAllGrades: StateFlow<List<StudentGrade>>
    val dbAllGradeConfigs: StateFlow<List<StudentGradeConfig>>
    val dbLessonTopics: StateFlow<List<LessonTopic>>
    val dbLessonSessionTopics: StateFlow<List<LessonSessionTopic>>
    val dbSubjects: StateFlow<List<Subject>>
    val dbCourseSubjects: StateFlow<List<CourseSubjectCrossRef>>
    val dbTrainerTransactions: StateFlow<List<TrainerTransaction>>
    val dbActivityLogs: StateFlow<List<AppActivityLog>>
    val dbAssignmentTemplates: StateFlow<List<SubjectAssignmentTemplate>>
    val dbAssignmentSubmissions: StateFlow<List<StudentAssignmentSubmission>>
    val dbSubjectReferences: StateFlow<List<com.example.data.entity.SubjectReference>>
    val dbStudentViolations: StateFlow<List<StudentViolation>>
    val allOfficialHolidays: StateFlow<List<OfficialHoliday>>
    val enabledOfficialHolidays: StateFlow<List<OfficialHoliday>>

    val trainerBaseDirUri = MutableStateFlow("")
    val trainerBaseDirName = MutableStateFlow("")

    private fun findFileCaseInsensitive(parent: androidx.documentfile.provider.DocumentFile, name: String): androidx.documentfile.provider.DocumentFile? {
        val files = parent.listFiles()
        for (file in files) {
            val fileName = file.name
            if (fileName != null && fileName.equals(name, ignoreCase = true)) {
                return file
            }
        }
        return null
    }

    fun saveTrainerBaseDir(uri: String, name: String) {
        trainerBaseDirUri.value = uri
        trainerBaseDirName.value = name
        val context = getApplication<Application>()
        context.getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
            .edit()
            .putString("trainer_base_dir_uri", uri)
            .putString("trainer_base_dir_name", name)
            .apply()

        // Automatic folder structure initialization (Dawami -> Backups, References, Assignments, Reports, Topics)
        if (uri.isNotEmpty()) {
            try {
                val parsedUri = android.net.Uri.parse(uri)
                context.contentResolver.takePersistableUriPermission(
                    parsedUri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                val rootDoc = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, parsedUri)
                if (rootDoc != null && rootDoc.isDirectory) {
                    // 1. Clean up empty duplicate folders
                    val pattern = Regex("(?i)^(Backups|References|Assignments|Reports|Topics|projects)\\s*\\(\\d+\\)$")
                    val files = rootDoc.listFiles()
                    for (file in files) {
                        if (file.isDirectory) {
                            val fName = file.name ?: ""
                            if (fName.matches(pattern)) {
                                val children = file.listFiles()
                                if (children.isEmpty()) {
                                    file.delete()
                                }
                            }
                        }
                    }

                    // 2. Ensure default folders exist case-insensitively
                    val subFolders = listOf("Backups", "references", "Assignments", "Reports", "Topics", "projects")
                    for (folderName in subFolders) {
                        var subDir = findFileCaseInsensitive(rootDoc, folderName)
                        if (subDir == null || !subDir.isDirectory) {
                            rootDoc.createDirectory(folderName)
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    data class BackupOptions(
        val includeCourses: Boolean = true,
        val includeStudents: Boolean = true,
        val includeAttendance: Boolean = true,
        val includeStudentAttendance: Boolean = true,
        val includeDailyNotes: Boolean = true,
        val includeSubjects: Boolean = true,
        val includeCourseSubjects: Boolean = true,
        val includeLessonTopics: Boolean = true,
        val includeLessonSessionTopics: Boolean = true,
        val includeGradeConfigs: Boolean = true,
        val includeStudentGrades: Boolean = true,
        val includeAssignmentTemplates: Boolean = true,
        val includeAssignmentSubmissions: Boolean = true,
        val includeTrainerTransactions: Boolean = true,
        val includeSubjectReferences: Boolean = true,
        val includeActivityLogs: Boolean = true,
        val includeStudentViolations: Boolean = true,
        val includeOfficialHolidays: Boolean = true,
        val includeSettings: Boolean = true,
        val includeFunnyPenalties: Boolean = true,
        val includeManualAssignmentModes: Boolean = true
    ) {
        // Legacy compatibility properties
        val includeCoursesAndStudents: Boolean get() = includeCourses && includeStudents
        val includeGrades: Boolean get() = includeStudentGrades
        val includeTopics: Boolean get() = includeLessonTopics && includeLessonSessionTopics
        val includeReferences: Boolean get() = includeSubjectReferences
        val includeAssignments: Boolean get() = includeAssignmentTemplates && includeAssignmentSubmissions
        val includeFinances: Boolean get() = includeTrainerTransactions
        val includeViolations: Boolean get() = includeStudentViolations

        fun toDomain() = com.example.data.backup.BackupOptions(
            includeCourses = includeCourses,
            includeStudents = includeStudents,
            includeAttendance = includeAttendance,
            includeStudentAttendance = includeStudentAttendance,
            includeDailyNotes = includeDailyNotes,
            includeSubjects = includeSubjects,
            includeCourseSubjects = includeCourseSubjects,
            includeLessonTopics = includeLessonTopics,
            includeLessonSessionTopics = includeLessonSessionTopics,
            includeGradeConfigs = includeGradeConfigs,
            includeStudentGrades = includeStudentGrades,
            includeAssignmentTemplates = includeAssignmentTemplates,
            includeAssignmentSubmissions = includeAssignmentSubmissions,
            includeTrainerTransactions = includeTrainerTransactions,
            includeSubjectReferences = includeSubjectReferences,
            includeActivityLogs = includeActivityLogs,
            includeStudentViolations = includeStudentViolations,
            includeOfficialHolidays = includeOfficialHolidays,
            includeSettings = includeSettings,
            includeFunnyPenalties = includeFunnyPenalties,
            includeManualAssignmentModes = includeManualAssignmentModes
        )
    }

    data class RestoreOptions(
        val restoreCourses: Boolean = true,
        val restoreStudents: Boolean = true,
        val restoreAttendance: Boolean = true,
        val restoreStudentAttendance: Boolean = true,
        val restoreDailyNotes: Boolean = true,
        val restoreSubjects: Boolean = true,
        val restoreCourseSubjects: Boolean = true,
        val restoreLessonTopics: Boolean = true,
        val restoreLessonSessionTopics: Boolean = true,
        val restoreGradeConfigs: Boolean = true,
        val restoreGrades: Boolean = true,
        val restoreAssignmentTemplates: Boolean = true,
        val restoreAssignmentSubmissions: Boolean = true,
        val restoreTrainerTransactions: Boolean = true,
        val restoreSubjectReferences: Boolean = true,
        val restoreActivityLogs: Boolean = true,
        val restoreStudentViolations: Boolean = true,
        val restoreOfficialHolidays: Boolean = true,
        val restoreSettings: Boolean = true,
        val restoreFunnyPenalties: Boolean = true,
        val restoreManualAssignmentModes: Boolean = true
    ) {
        // Legacy compatibility properties
        val restorePrep: Boolean get() = restoreDailyNotes && restoreLessonTopics && restoreLessonSessionTopics
        val restoreFinances: Boolean get() = restoreTrainerTransactions
        val restoreReferences: Boolean get() = restoreSubjectReferences
        val restoreViolations: Boolean get() = restoreStudentViolations

        fun toDomain() = com.example.data.backup.RestoreOptions(
            restoreCourses = restoreCourses,
            restoreStudents = restoreStudents,
            restoreAttendance = restoreAttendance,
            restoreStudentAttendance = restoreStudentAttendance,
            restoreDailyNotes = restoreDailyNotes,
            restoreSubjects = restoreSubjects,
            restoreCourseSubjects = restoreCourseSubjects,
            restoreLessonTopics = restoreLessonTopics,
            restoreLessonSessionTopics = restoreLessonSessionTopics,
            restoreGradeConfigs = restoreGradeConfigs,
            restoreStudentGrades = restoreGrades,
            restoreAssignmentTemplates = restoreAssignmentTemplates,
            restoreAssignmentSubmissions = restoreAssignmentSubmissions,
            restoreTrainerTransactions = restoreTrainerTransactions,
            restoreSubjectReferences = restoreSubjectReferences,
            restoreActivityLogs = restoreActivityLogs,
            restoreStudentViolations = restoreStudentViolations,
            restoreOfficialHolidays = restoreOfficialHolidays,
            restoreSettings = restoreSettings,
            restoreFunnyPenalties = restoreFunnyPenalties,
            restoreManualAssignmentModes = restoreManualAssignmentModes
        )
    }

    fun generateBackupFileName(options: BackupOptions?, isFull: Boolean): String {
        val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd_HHmm", java.util.Locale.US).format(java.util.Date())
        if (isFull || options == null) {
            return "نسخة_شاملة_معهد_دوامي_$dateStr.json"
        }
        
        val selectedParts = mutableListOf<String>()
        if (options.includeTopics) selectedParts.add("المواضيع_والمنهج")
        if (options.includeGradeConfigs) selectedParts.add("تهيئة_الدرجات")
        if (options.includeGrades) selectedParts.add("الدرجات")
        if (options.includeAssignments) selectedParts.add("الواجبات_والتكاليف")
        if (options.includeAttendance) selectedParts.add("حضور_وغياب_الطلاب")
        if (options.includeViolations) selectedParts.add("مخالفات_الطلاب")
        if (options.includeReferences) selectedParts.add("المراجع_والمذكرات")
        if (options.includeCoursesAndStudents) selectedParts.add("الدورات_والطلاب")
        if (options.includeFinances) selectedParts.add("المالية")
        if (options.includeSettings) selectedParts.add("إعدادات_المعهد")

        val prefix = when {
            selectedParts.isEmpty() -> "نسخة_مخصصة"
            selectedParts.size == 1 -> "نسخة_" + selectedParts[0]
            selectedParts.size == 2 -> "نسخة_" + selectedParts[0] + "_و_" + selectedParts[1]
            else -> "نسخة_مخصصة_" + selectedParts[0] + "_و_" + selectedParts[1] + "_وآخر"
        }

        return "${prefix}_$dateStr.json"
    }

    data class SubfolderBackupFile(
        val name: String,
        val uri: android.net.Uri,
        val size: Long,
        val lastModified: Long
    )

    fun getBackupFilesFromSubfolder(context: android.content.Context): List<SubfolderBackupFile> {
        val baseUriStr = trainerBaseDirUri.value
        if (baseUriStr.isEmpty()) return emptyList()
        val list = mutableListOf<SubfolderBackupFile>()
        try {
            val baseUri = android.net.Uri.parse(baseUriStr)
            val rootDoc = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, baseUri)
            if (rootDoc != null && rootDoc.isDirectory) {
                val backupsDir = findFileCaseInsensitive(rootDoc, "Backups")
                if (backupsDir != null && backupsDir.isDirectory) {
                    backupsDir.listFiles().forEach { file ->
                        if (file.isFile && (file.name?.endsWith(".json", ignoreCase = true) == true || file.type == "application/json")) {
                            list.add(
                                SubfolderBackupFile(
                                    name = file.name ?: "backup.json",
                                    uri = file.uri,
                                    size = file.length(),
                                    lastModified = file.lastModified()
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list.sortedByDescending { it.lastModified }
    }

    fun getManualAssignmentModesCount(context: android.content.Context): Int {
        val prefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
        return prefs.all.keys.count { 
            it.startsWith("manual_assignment_mode_") || 
            it.startsWith("course_grading_mode_") || 
            it.startsWith("course_trainer_notes_") ||
            it.startsWith("course_assignment_modes_") || 
            it.startsWith("manual_mode_") 
        }
    }

    suspend fun createBackupInSubfolder(context: android.content.Context, options: BackupOptions? = null, customFileName: String? = null): Boolean {
        val baseUriStr = trainerBaseDirUri.value
        if (baseUriStr.isEmpty()) return false
        try {
            val baseUri = android.net.Uri.parse(baseUriStr)
            val rootDoc = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, baseUri)
            if (rootDoc != null && rootDoc.isDirectory) {
                var backupsDir = findFileCaseInsensitive(rootDoc, "Backups")
                if (backupsDir == null || !backupsDir.isDirectory) {
                    backupsDir = rootDoc.createDirectory("Backups")
                }
                if (backupsDir != null && backupsDir.isDirectory) {
                    val fileName = customFileName ?: generateBackupFileName(options, options == null)
                    val newFile = backupsDir.createFile("application/json", fileName)
                    if (newFile != null) {
                        val jsonString = exportBackupAsJson(options)
                        context.contentResolver.openOutputStream(newFile.uri)?.use { outputStream ->
                            outputStream.write(jsonString.toByteArray(Charsets.UTF_8))
                        }
                        recordBackupSuccess()
                        return true
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    suspend fun savePdfReportToReportsFolder(
        context: android.content.Context,
        suggestedFileName: String,
        writer: (java.io.OutputStream) -> Unit
    ): Boolean {
        val baseUriStr = trainerBaseDirUri.value
        if (baseUriStr.isEmpty()) return false
        try {
            val baseUri = android.net.Uri.parse(baseUriStr)
            val rootDoc = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, baseUri)
            if (rootDoc != null && rootDoc.isDirectory) {
                var reportsDir = findFileCaseInsensitive(rootDoc, "Reports")
                if (reportsDir == null || !reportsDir.isDirectory) {
                    reportsDir = rootDoc.createDirectory("Reports")
                }
                if (reportsDir != null && reportsDir.isDirectory) {
                    val cleanFileName = if (suggestedFileName.endsWith(".pdf", ignoreCase = true)) suggestedFileName else "$suggestedFileName.pdf"
                    val newFile = reportsDir.createFile("application/pdf", cleanFileName)
                    if (newFile != null) {
                        context.contentResolver.openOutputStream(newFile.uri)?.use { outputStream ->
                            writer(outputStream)
                        }
                        return true
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    val studentReportNameQuery = MutableStateFlow("")

    fun setStudentReportNameQuery(query: String) {
        studentReportNameQuery.value = query
        generateStudentReports()
    }

    private val _tempCourses = MutableStateFlow<List<Course>>(emptyList())
    val tempCourses: StateFlow<List<Course>> = _tempCourses.asStateFlow()

    private val _showCompletedCoursesInDropdowns = MutableStateFlow(false)
    val showCompletedCoursesInDropdowns: StateFlow<Boolean> = _showCompletedCoursesInDropdowns.asStateFlow()

    fun toggleShowCompletedCoursesInDropdowns() {
        val newVal = !_showCompletedCoursesInDropdowns.value
        _showCompletedCoursesInDropdowns.value = newVal
        getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
            .edit()
            .putBoolean("show_completed_courses_in_dropdowns", newVal)
            .apply()
    }

    fun setShowCompletedCoursesInDropdowns(show: Boolean) {
        _showCompletedCoursesInDropdowns.value = show
        getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
            .edit()
            .putBoolean("show_completed_courses_in_dropdowns", show)
            .apply()
    }

    val activeCourses: StateFlow<List<Course>> = combine(tempCourses, _showCompletedCoursesInDropdowns) { courses, showCompleted ->
        if (showCompleted) {
            courses
        } else {
            courses.filter { !it.isCompleted }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _tempAttendance = MutableStateFlow<List<Attendance>>(emptyList())
    val tempAttendance: StateFlow<List<Attendance>> = _tempAttendance.asStateFlow()

    val courseNameInput = MutableStateFlow("")
    val courseStartDateInput = MutableStateFlow("")
    val courseEndDateInput = MutableStateFlow("")
    val courseStartTimeInput = MutableStateFlow("")
    val courseEndTimeInput = MutableStateFlow("")
    val courseDepartmentInput = MutableStateFlow("")
    val courseDiplomaInput = MutableStateFlow("")
    val selectedCourseSubjectsInput = MutableStateFlow<Set<Int>>(emptySet())
    private val _selectedCourseForEdit = MutableStateFlow<Course?>(null)
    val selectedCourseForEdit: StateFlow<Course?> = _selectedCourseForEdit.asStateFlow()

    private val _selectedCourseForAttendance = MutableStateFlow<Course?>(null)
    val selectedCourseForAttendance: StateFlow<Course?> = _selectedCourseForAttendance.asStateFlow()
    val attendanceDayInput = MutableStateFlow("الأحد")
    val attendanceDateInput = MutableStateFlow("")
    val attendanceCheckInInput = MutableStateFlow("")
    val attendanceCheckOutInput = MutableStateFlow("")
    val attendanceStatusInput = MutableStateFlow("حضور")
    val attendanceNoteInput = MutableStateFlow("")
    
    private val _checkInAlert = MutableStateFlow<String?>(null)
    val checkInAlert: StateFlow<String?> = _checkInAlert.asStateFlow()

    private val _checkOutAlert = MutableStateFlow<String?>(null)
    val checkOutAlert: StateFlow<String?> = _checkOutAlert.asStateFlow()

    private val _calculatedDurationText = MutableStateFlow("0 ساعة و 0 دقيقة")
    val calculatedDurationText: StateFlow<String> = _calculatedDurationText.asStateFlow()

    private val _selectedAttendanceForEdit = MutableStateFlow<Attendance?>(null)
    val selectedAttendanceForEdit: StateFlow<Attendance?> = _selectedAttendanceForEdit.asStateFlow()

    private val _selectedCourseReportFilter = MutableStateFlow<String>("الكل")
    val selectedCourseReportFilter: StateFlow<String> = _selectedCourseReportFilter.asStateFlow()

    private val _selectedSubjectReportFilter = MutableStateFlow<String>("الكل")
    val selectedSubjectReportFilter: StateFlow<String> = _selectedSubjectReportFilter.asStateFlow()

    private val _reportDateFromFilter = MutableStateFlow("")
    val reportDateFromFilter: StateFlow<String> = _reportDateFromFilter.asStateFlow()

    private val _reportDateToFilter = MutableStateFlow("")
    val reportDateToFilter: StateFlow<String> = _reportDateToFilter.asStateFlow()

    private val _selectedStatusReportFilter = MutableStateFlow<String>("الكل")
    val selectedStatusReportFilter: StateFlow<String> = _selectedStatusReportFilter.asStateFlow()

    private val _selectedCourseStatusReportFilter = MutableStateFlow<String>("الكل")
    val selectedCourseStatusReportFilter: StateFlow<String> = _selectedCourseStatusReportFilter.asStateFlow()

    private val _reportGroupingMode = MutableStateFlow<String>("التاريخ")
    val reportGroupingMode: StateFlow<String> = _reportGroupingMode.asStateFlow()

    fun setReportGroupingMode(mode: String) {
        _reportGroupingMode.value = mode
        updateReportsGrouping()
    }

    private val _groupedReports = MutableStateFlow<Map<String, List<Attendance>>>(emptyMap())
    val groupedReports: StateFlow<Map<String, List<Attendance>>> = _groupedReports.asStateFlow()

    val studentNameInput = MutableStateFlow("")
    val studentPhoneInput = MutableStateFlow("")
    private val _selectedCourseForStudents = MutableStateFlow<Course?>(null)
    val selectedCourseForStudents: StateFlow<Course?> = _selectedCourseForStudents.asStateFlow()

    private val _selectedCourseForStudentAttendance = MutableStateFlow<Course?>(null)
    val selectedCourseForStudentAttendance: StateFlow<Course?> = _selectedCourseForStudentAttendance.asStateFlow()

    val studentAttendanceDateInput = MutableStateFlow("")
    val studentAttendanceDayInput = MutableStateFlow("الأحد")
    val studentAttendanceTimeInput = MutableStateFlow("")
    val studentCheckInTimeInput = MutableStateFlow("")
    val studentCheckOutTimeInput = MutableStateFlow("")
    val studentAttendanceSubjectInput = MutableStateFlow("")

    val dailyCourseNoteInput = MutableStateFlow("")

    private val _selectedStudentCourseReportFilter = MutableStateFlow<String>("")
    val selectedStudentCourseReportFilter: StateFlow<String> = _selectedStudentCourseReportFilter.asStateFlow()

    private val _selectedStudentSubjectReportFilter = MutableStateFlow<String>("الكل")
    val selectedStudentSubjectReportFilter: StateFlow<String> = _selectedStudentSubjectReportFilter.asStateFlow()

    private val _studentReportDateFromFilter = MutableStateFlow("")
    val studentReportDateFromFilter: StateFlow<String> = _studentReportDateFromFilter.asStateFlow()

    private val _studentReportDateToFilter = MutableStateFlow("")
    val studentReportDateToFilter: StateFlow<String> = _studentReportDateToFilter.asStateFlow()

    private val _selectedStudentStatusReportFilter = MutableStateFlow<String>("الكل")
    val selectedStudentStatusReportFilter: StateFlow<String> = _selectedStudentStatusReportFilter.asStateFlow()

    private val _studentReportGroupingMode = MutableStateFlow<String>("التاريخ")
    val studentReportGroupingMode: StateFlow<String> = _studentReportGroupingMode.asStateFlow()

    fun setStudentReportGroupingMode(mode: String) {
        _studentReportGroupingMode.value = mode
        generateStudentReports()
    }

    private val _studentAttendanceReports = MutableStateFlow<List<StudentAttendance>>(emptyList())
    val studentAttendanceReports: StateFlow<List<StudentAttendance>> = _studentAttendanceReports.asStateFlow()

    private val _studentGroupedReports = MutableStateFlow<Map<String, List<StudentAttendance>>>(emptyMap())
    val studentGroupedReports: StateFlow<Map<String, List<StudentAttendance>>> = _studentGroupedReports.asStateFlow()

    val studentAttendanceList: StateFlow<List<StudentAttendance>>

    fun getArabicDayOfWeek(dateStr: String): String {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdf.parse(dateStr)
            if (date != null) {
                val calendar = Calendar.getInstance()
                calendar.time = date
                when (calendar.get(Calendar.DAY_OF_WEEK)) {
                    Calendar.SUNDAY -> "الأحد"
                    Calendar.MONDAY -> "الإثنين"
                    Calendar.TUESDAY -> "الثلاثاء"
                    Calendar.WEDNESDAY -> "الأربعاء"
                    Calendar.THURSDAY -> "الخميس"
                    Calendar.FRIDAY -> "الجمعة"
                    Calendar.SATURDAY -> "السبت"
                    else -> "الأحد"
                }
            } else {
                "الأحد"
            }
        } catch (e: Exception) {
            "الأحد"
        }
    }

    fun setAttendanceDate(dateStr: String) {
        attendanceDateInput.value = dateStr
        attendanceDayInput.value = getArabicDayOfWeek(dateStr)
        triggerWeekendWarningIfNeeded(dateStr)
        _selectedCourseForAttendance.value?.let { course ->
            loadSavedSubjectName(course.id, dateStr)
        }
    }

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AppRepository(
            database.courseDao(),
            database.attendanceDao(),
            database.studentDao(),
            database.studentAttendanceDao(),
            database.dailyCourseNoteDao(),
            database.studentGradeConfigDao(),
            database.studentGradeDao(),
            database.lessonTopicDao(),
            database.lessonSessionTopicDao(),
            database.subjectDao(),
            database.trainerTransactionDao(),
            database.subjectAssignmentTemplateDao(),
            database.studentAssignmentSubmissionDao(),
            database.subjectReferenceDao(),
            database.appActivityLogDao(),
            database.studentViolationDao(),
            database.officialHolidayDao()
        )

        backupManager = BackupManager(application, database, repository)

        val sharedPrefs = application.getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        _lastBackupDate.value = sharedPrefs.getString("last_backup_date", "") ?: ""
        trainerBaseDirUri.value = sharedPrefs.getString("trainer_base_dir_uri", "") ?: ""
        trainerBaseDirName.value = sharedPrefs.getString("trainer_base_dir_name", "") ?: ""
        _isActivatedState.value = sharedPrefs.getBoolean("is_activated", false)
        _includeLessonTopicsInReport.value = sharedPrefs.getBoolean("include_lesson_topics_in_report", true)
        _maxCumulativeDelay.value = sharedPrefs.getInt("max_cumulative_delay", 60)
        _maxWeeklyAbsence.value = sharedPrefs.getInt("max_weekly_absence", 2)
        _maxMonthlyAbsence.value = sharedPrefs.getInt("max_monthly_absence", 5)

        _isSmartNotificationsEnabled.value = sharedPrefs.getBoolean("smart_notifications_enabled", true)
        _trainerReminderMinutes.value = sharedPrefs.getInt("trainer_reminder_minutes", 15)
        _studentCheckInReminderMinutes.value = sharedPrefs.getInt("student_check_in_reminder_minutes", 10)
        _studentCheckOutReminderMinutes.value = sharedPrefs.getInt("student_check_out_reminder_minutes", 3).let { if (it > 0) it else 3 }
        _notificationSound.value = sharedPrefs.getString("notification_sound", "Default") ?: "Default"
        _voiceGender.value = sharedPrefs.getString("voice_gender", "female") ?: "female"

        _isTrainerStartReminderEnabled.value = sharedPrefs.getBoolean("is_trainer_start_reminder_enabled", true)
        _isTrainerCheckInReminderEnabled.value = sharedPrefs.getBoolean("is_trainer_check_in_reminder_enabled", true)
        _isStudentCheckInReminderEnabled.value = sharedPrefs.getBoolean("is_student_check_in_reminder_enabled", true)
        _isStudentCheckInSuccessEnabled.value = sharedPrefs.getBoolean("is_student_check_in_success_enabled", true)
        _isStudentCheckOutReminderEnabled.value = sharedPrefs.getBoolean("is_student_check_out_reminder_enabled", true)
        _isStudentCheckOutSuccessEnabled.value = sharedPrefs.getBoolean("is_student_check_out_success_enabled", true)
        _isThursdayNotificationsEnabled.value = sharedPrefs.getBoolean("is_thursday_notifications_enabled", false)
        _isFridayNotificationsEnabled.value = sharedPrefs.getBoolean("is_friday_notifications_enabled", false)

        _trainerStartReminderText.value = sharedPrefs.getString("trainer_start_reminder_text", "الرجاء الاستعداد للدورة، باقي من الوقت عشر دقائق") ?: "الرجاء الاستعداد للدورة، باقي من الوقت عشر دقائق"
        _trainerCheckInPromptText.value = sharedPrefs.getString("trainer_check_in_prompt_text", "الرجاء تحضير نفسك في حافظة الدوام") ?: "الرجاء تحضير نفسك في حافظة الدوام"
        _studentCheckInPromptText.value = sharedPrefs.getString("student_check_in_prompt_text", "بدأت المحاضرة الرجاء تحضير الطلاب") ?: "بدأت المحاضرة الرجاء تحضير الطلاب"
        _studentCheckInRemindText.value = sharedPrefs.getString("student_check_in_remind_text", "أستاذ فيصل الرجاء تحضير الطلاب") ?: "أستاذ فيصل الرجاء تحضير الطلاب"
        _studentCheckInSuccessText.value = sharedPrefs.getString("student_check_in_success_text", "لقد تم تحضير الطلاب بنجاح شكرا لك") ?: "لقد تم تحضير الطلاب بنجاح شكرا لك"
        _studentCheckOutPromptText.value = sharedPrefs.getString("student_check_out_prompt_text", "حان وقت انصراف الطلاب") ?: "حان وقت انصراف الطلاب"
        _studentCheckOutRemindText.value = sharedPrefs.getString("student_check_out_remind_text", "أستاذ فيصل الرجاء تحضير انصراف الطلاب") ?: "أستاذ فيصل الرجاء تحضير انصراف الطلاب"
        _studentCheckOutSuccessText.value = sharedPrefs.getString("student_check_out_success_text", "تم تسجيل انصراف الطلاب بنجاح") ?: "تم تسجيل انصراف الطلاب بنجاح"
        _showCompletedCoursesInDropdowns.value = sharedPrefs.getBoolean("show_completed_courses_in_dropdowns", false)
        loadManualAssignmentGradingMap()
        loadCourseGradingModes()

        dbCourses = repository.allCourses.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbAttendance = repository.allAttendance.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbAllStudents = repository.allStudents.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbAllStudentAttendance = repository.allStudentAttendance.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbAllDailyNotes = repository.getAllDailyNotes().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbAllGrades = repository.allGrades.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbAllGradeConfigs = repository.allGradeConfigs.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbLessonTopics = repository.allLessonTopics.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbLessonSessionTopics = repository.allLessonSessionTopics.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbSubjects = repository.allSubjects.map { list ->
            list.sortedWith(compareBy<com.example.data.entity.Subject> { com.example.data.entity.StudentGradeConfig.getSubjectRank(it.name) }.thenBy { it.name })
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbCourseSubjects = repository.allCourseSubjects.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbTrainerTransactions = repository.allTrainerTransactions.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbActivityLogs = repository.allActivityLogs.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbAssignmentTemplates = repository.allAssignmentTemplates.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbAssignmentSubmissions = repository.allAssignmentSubmissions.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbSubjectReferences = repository.allReferences.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        dbStudentViolations = repository.allViolations.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allOfficialHolidays = repository.allOfficialHolidays.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        enabledOfficialHolidays = repository.enabledOfficialHolidays.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Rely solely on trainer inputs for assignment templates

        studentAttendanceList = kotlinx.coroutines.flow.combine(
            listOf(
                _selectedCourseForStudentAttendance,
                studentAttendanceDateInput,
                dbAllStudents,
                dbAllStudentAttendance,
                dbAllDailyNotes,
                studentAttendanceSubjectInput
            )
        ) { array ->
            val course = array[0] as com.example.data.entity.Course?
            val date = array[1] as String
            @Suppress("UNCHECKED_CAST")
            val students = array[2] as List<com.example.data.entity.Student>
            @Suppress("UNCHECKED_CAST")
            val attendances = array[3] as List<com.example.data.entity.StudentAttendance>
            @Suppress("UNCHECKED_CAST")
            val dailyNotes = array[4] as List<com.example.data.entity.DailyCourseNote>
            val currentSubject = array[5] as String

            if (course == null || date.isEmpty()) return@combine emptyList()
            val dateAttendances = attendances.filter { it.courseId == course.id && it.date == date }
            val courseStudents = students.filter { student ->
                student.courseId == course.id && (
                    student.status == "مستمر" || student.status.isEmpty() ||
                    dateAttendances.any { it.studentId == student.id && it.status != "لم يسجل" && it.status.isNotEmpty() }
                )
            }
            val currentDailyNote = dailyNotes.find { it.courseId == course.id && it.date == date }?.note ?: ""

            courseStudents.map { student ->
                val existing = dateAttendances.find { it.studentId == student.id }
                val record = existing ?: StudentAttendance(
                    studentId = student.id,
                    studentName = student.name,
                    courseId = course.id,
                    courseName = course.name,
                    date = date,
                    dayOfWeek = studentAttendanceDayInput.value,
                    status = "لم يسجل",
                    actualCheckIn = "",
                    actualCheckOut = "",
                    studentNote = "",
                    courseDailyNote = currentDailyNote
                )
                
                val finalSubjectName = if (record.subjectName.isNotEmpty()) record.subjectName else currentSubject
                record.copy(courseDailyNote = currentDailyNote, subjectName = finalSubjectName)
            }.sortedWith(
                compareBy<StudentAttendance> { if (it.status == "لم يسجل") 0 else 1 }
                    .thenByDescending { it.updatedAt }
                    .thenByDescending { it.id }
                    .thenBy { it.studentName }
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        viewModelScope.launch {
            studentAttendanceList.collect { list ->
                if (list.isEmpty()) return@collect
                val firstItem = list.first()
                val cId = firstItem.courseId
                val cDate = firstItem.date

                // Detect session switch (new course or date)
                if (cId != lastObservedCourseId || cDate != lastObservedDate) {
                    lastObservedCourseId = cId
                    lastObservedDate = cDate

                    // Initialize trigger flags to prevent playing notifications when viewing an already completed day.
                    val isCheckInCompleteOnInit = list.none { it.status == "لم يسجل" }
                    hasTriggeredCheckInForCurrentSession = isCheckInCompleteOnInit

                    val presentOnInit = list.filter { it.status == "حضور" }
                    val isCheckOutCompleteOnInit = presentOnInit.isNotEmpty() && presentOnInit.all { it.actualCheckOut.isNotEmpty() }
                    hasTriggeredCheckOutForCurrentSession = isCheckOutCompleteOnInit
                    return@collect
                }

                // Check-in completion check
                val isCheckInCurrentlyComplete = list.none { it.status == "لم يسجل" }
                if (isCheckInCurrentlyComplete) {
                    if (!hasTriggeredCheckInForCurrentSession) {
                        hasTriggeredCheckInForCurrentSession = true
                        val now = System.currentTimeMillis()
                        if (now - lastInstantSuccessCheckInTime > 4000L) {
                            lastInstantSuccessCheckInTime = now
                            val context = getApplication<Application>()
                val sharedPrefs = context.getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
                            val isSmartEnabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
                            val isSuccessEnabled = sharedPrefs.getBoolean("is_student_check_in_success_enabled", true)
                            if (isSmartEnabled && isSuccessEnabled) {
                                val customSuccessText = sharedPrefs.getString("student_check_in_success_text", "لقد تم تحضير الطلاب بنجاح شكرا لك") ?: "لقد تم تحضير الطلاب بنجاح شكرا لك"
                                val speakMsg = customSuccessText.replace("[course]", firstItem.courseName)
                                sendTestNotification("تم تحضير الطلاب 📝", speakMsg, "instant_success")
                            }
                        }
                    }
                } else {
                    hasTriggeredCheckInForCurrentSession = false
                }

                // Check-out completion check
                val presentStudents = list.filter { it.status == "حضور" }
                val isCheckOutCurrentlyComplete = presentStudents.isNotEmpty() && presentStudents.all { it.actualCheckOut.isNotEmpty() }
                if (isCheckOutCurrentlyComplete) {
                    if (!hasTriggeredCheckOutForCurrentSession) {
                        hasTriggeredCheckOutForCurrentSession = true
                        val now = System.currentTimeMillis()
                        if (now - lastInstantSuccessCheckOutTime > 4000L) {
                            lastInstantSuccessCheckOutTime = now
                            val context = getApplication<Application>()
                val sharedPrefs = context.getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
                            val isSmartEnabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
                            val isSuccessEnabled = sharedPrefs.getBoolean("is_student_check_out_success_enabled", true)
                            if (isSmartEnabled && isSuccessEnabled) {
                                val customSuccessText = sharedPrefs.getString("student_check_out_success_text", "تم تسجيل انصراف الطلاب بنجاح") ?: "تم تسجيل انصراف الطلاب بنجاح"
                                val speakMsg = customSuccessText.replace("[course]", firstItem.courseName)
                                sendTestNotification("تم انصراف الطلاب 📝", speakMsg, "instant_success")
                            }
                        }
                    }
                } else {
                    hasTriggeredCheckOutForCurrentSession = false
                }
            }
        }

        viewModelScope.launch {
            dbCourses.collect { list ->
                _tempCourses.value = list
            }
        }
        viewModelScope.launch {
            dbAttendance.collect { list ->
                _tempAttendance.value = list
            }
        }

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayStr = sdf.format(Calendar.getInstance().time)
        setAttendanceDate(todayStr)
        setStudentAttendanceDate(todayStr)

        val sdfTime = SimpleDateFormat("HH:mm", Locale.US)
        val currentTime = sdfTime.format(Calendar.getInstance().time)
        attendanceCheckInInput.value = currentTime
        attendanceCheckOutInput.value = currentTime
        studentAttendanceTimeInput.value = currentTime
        studentCheckInTimeInput.value = currentTime
        studentCheckOutTimeInput.value = currentTime

        viewModelScope.launch {
            while (true) {
                val cal = Calendar.getInstance()
                val currentTStr = sdfTime.format(cal.time)
                if (_selectedCourseForAttendance.value == null) {
                    attendanceCheckInInput.value = currentTStr
                    attendanceCheckOutInput.value = currentTStr
                }
                if (_selectedCourseForStudentAttendance.value == null) {
                    studentAttendanceTimeInput.value = currentTStr
                    studentCheckInTimeInput.value = currentTStr
                    studentCheckOutTimeInput.value = currentTStr
                }
                
                val delayMs = 60000 - (System.currentTimeMillis() % 60000)
                kotlinx.coroutines.delay(delayMs)
            }
        }

        viewModelScope.launch {
            dbAttendance.collect {
                updateReportsGrouping()
            }
        }

        viewModelScope.launch {
            kotlinx.coroutines.flow.combine(
                _selectedCourseForStudentAttendance,
                studentAttendanceDateInput,
                dbAttendance
            ) { course, date, _ ->
                if (course != null && date.isNotEmpty()) {
                    val noteObj = repository.getDailyNoteForCourseAndDateSync(course.id, date)
                    dailyCourseNoteInput.value = noteObj?.note ?: ""
                    if (course.startTime.isNotEmpty()) {
                        studentCheckInTimeInput.value = course.startTime
                    }
                    updateStudentCheckOutDefaultTime(course, date)
                } else {
                    dailyCourseNoteInput.value = ""
                }
            }.collect {}
        }

        viewModelScope.launch {
            dbAllStudentAttendance.collect {
                generateStudentReports()
            }
        }
        sanitizeAttendanceIntegrity()
        loadInstituteIdentity()
    }

    private val _registerError = MutableStateFlow<String?>(null)
    val registerError: StateFlow<String?> = _registerError.asStateFlow()

    private val _activationError = MutableStateFlow<String?>(null)
    val activationError: StateFlow<String?> = _activationError.asStateFlow()

    fun getCodeDurationMonths(code: String): Int {
        return when (code.trim()) {
            "774411" -> 1
            "dawami123" -> 3
            "778899" -> 6
            "DAWAMI-2026" -> 12
            "998877" -> 24
            else -> 12
        }
    }

    fun checkActivationExpiry() {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val isActivated = sharedPrefs.getBoolean("is_activated", false)
        if (isActivated) {
            val timestamp = sharedPrefs.getLong("activation_timestamp", 0L)
            val durationMonths = sharedPrefs.getInt("activation_duration_months", 12)
            if (timestamp > 0L) {
                val expiryMillis = timestamp + (durationMonths.toLong() * 30L * 24L * 60L * 60L * 1000L)
                val currentTime = System.currentTimeMillis()
                if (currentTime > expiryMillis) {
                    sharedPrefs.edit()
                        .putBoolean("is_activated", false)
                        .remove("activation_timestamp")
                        .remove("activation_duration_months")
                        .remove("activation_code")
                        .apply()
                    _isActivatedState.value = false
                    activationTimestamp.value = 0L
                    activationDurationMonths.value = 12
                    activationCode.value = ""
                    _currentScreen.value = Screen.Activation
                }
            }
        }
    }

    fun checkNavigationOnStart() {
        checkActivationExpiry()
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val isActivated = sharedPrefs.getBoolean("is_activated", false)
        _isActivatedState.value = isActivated
        if (!isActivated) {
            _currentScreen.value = Screen.Activation
        } else {
            val isRegistered = sharedPrefs.getBoolean("is_registered", false)
            if (isRegistered) {
                _currentScreen.value = Screen.Login
            } else {
                _currentScreen.value = Screen.Register
            }
        }
    }

    fun startTrialMode() {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val isRegistered = sharedPrefs.getBoolean("is_registered", false)
        _isActivatedState.value = false
        if (isRegistered) {
            _currentScreen.value = Screen.Login
        } else {
            _currentScreen.value = Screen.Register
        }
    }

    fun activateApp(code: String): Boolean {
        val trimmed = code.trim()
        if (trimmed == "778899" || trimmed == "DAWAMI-2026" || trimmed == "998877" || trimmed == "dawami123" || trimmed == "774411") {
            val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
            val duration = getCodeDurationMonths(trimmed)
            val now = System.currentTimeMillis()
            sharedPrefs.edit()
                .putBoolean("is_activated", true)
                .putLong("activation_timestamp", now)
                .putInt("activation_duration_months", duration)
                .putString("activation_code", trimmed)
                .apply()

            _isActivatedState.value = true
            activationTimestamp.value = now
            activationDurationMonths.value = duration
            activationCode.value = trimmed
            _activationError.value = null
            
            if (_currentScreen.value == Screen.Activation) {
                val isRegistered = sharedPrefs.getBoolean("is_registered", false)
                if (isRegistered) {
                    _currentScreen.value = Screen.Login
                } else {
                    _currentScreen.value = Screen.Register
                }
            }
            return true
        } else {
            _activationError.value = "رمز التفعيل المدخل غير صحيح! يرجى التواصل مع المطور للحصول على الرمز الخاص بجهازك."
            return false
        }
    }

    fun register(usernameStr: String, passwordStr: String, confirmPasswordStr: String) {
        val user = usernameStr.trim()
        val pass = passwordStr
        val confirm = confirmPasswordStr

        if (user.isEmpty() || pass.isEmpty() || confirm.isEmpty()) {
            _registerError.value = "يرجى تعبئة جميع الحقول"
            return
        }

        if (pass.length < 4) {
            _registerError.value = "يجب أن تكون كلمة المرور 4 خانات على الأقل"
            return
        }

        if (pass != confirm) {
            _registerError.value = "كلمة المرور وتأكيدها غير متطابقتين"
            return
        }

        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit()
            .putString("saved_username", user)
            .putString("saved_password", pass)
            .putBoolean("is_registered", true)
            .apply()

        _registerError.value = null
        _currentScreen.value = Screen.Login
    }

    fun login(usernameStr: String, passwordStr: String) {
        if (usernameStr.trim().isEmpty() || passwordStr.trim().isEmpty()) {
            _loginError.value = "يرجى إدخال اسم المستخدم وكلمة المرور"
            return
        }
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val savedUsername = sharedPrefs.getString("saved_username", "admin") ?: "admin"
        val savedPassword = sharedPrefs.getString("saved_password", "admin") ?: "admin"

        val enteredUser = usernameStr.trim()
        val enteredPass = passwordStr

        if ((enteredUser == savedUsername && enteredPass == savedPassword) || (enteredUser == "admin" && enteredPass == "admin")) {
            _isLoggedIn.value = true
            _loggedInUser.value = enteredUser
            _loginError.value = null
            val hasOnboarding = sharedPrefs.getBoolean("has_completed_onboarding", false)
            _currentScreen.value = if (hasOnboarding) Screen.Selection else Screen.OnboardingSetup
            selectedRoleMode.value = "none"
            _tempCourses.value = dbCourses.value
            _tempAttendance.value = dbAttendance.value

            // Trigger pending actions popup check after login safely
            viewModelScope.launch {
                try {
                    kotlinx.coroutines.delay(500)
                    triggerPendingActionsPopupIfNeeded()
                } catch (e: Exception) {
                    android.util.Log.e("MainViewModel", "Pending actions check failed: ${e.localizedMessage}")
                }
            }
        } else {
            _loginError.value = "اسم المستخدم أو كلمة المرور غير صحيحة"
        }
    }

    private val screenHistory = mutableListOf<Screen>()

    // قائمة الشاشات الرئيسية التي تُضاف إلى سجل الرجوع
    private val mainScreens = setOf(
        Screen.Selection,
        Screen.Courses,
        Screen.Students,
        Screen.Attendance,
        Screen.Reports,
        Screen.StudentAttendance,
        Screen.StudentReports,
        Screen.Grades,
        Screen.GradeReports,
        Screen.Login,
        Screen.Register,
        Screen.Activation
    )

    fun logout() {
        _isLoggedIn.value = false
        _currentScreen.value = Screen.Login
        selectedRoleMode.value = "none"
        screenHistory.clear()
    }

    fun navigateTo(screen: Screen) {
        val publicScreens = setOf(
            Screen.Splash,
            Screen.Activation,
            Screen.Register,
            Screen.Login,
            Screen.AppFeaturesGuide
        )
        if (!_isLoggedIn.value && screen !in publicScreens) {
            _currentScreen.value = Screen.Login
            _loginError.value = "يرجى تسجيل الدخول أولاً للوصول إلى شاشات البرنامج 🔒"
            triggerFlashMessage(
                title = "تنبيه الأمان 🔒",
                message = "يجب تسجيل الدخول باستخدام اسم المستخدم وكلمة المرور للوصول إلى شاشات التطبيق.",
                type = "warning"
            )
            return
        }

        val current = _currentScreen.value
        // أضف الشاشة الحالية إلى التاريخ طالما أنها ليست نفس الشاشة وليست شاشة البداية المؤقتة
        if (current != screen && current != Screen.Splash) {
            if (screenHistory.lastOrNull() != current) {
                screenHistory.add(current)
            }
        }
        // إذا انتقلنا إلى الشاشة الرئيسية الرئيسية، يمكننا مسح التاريخ
        if (screen == Screen.Selection) {
            screenHistory.clear()
        }
        _currentScreen.value = screen
        _loginError.value = null
        _registerError.value = null
    }

    fun navigateBack() {
        if (screenHistory.isNotEmpty()) {
            var previousScreen = screenHistory.removeAt(screenHistory.size - 1)
            if (_isLoggedIn.value) {
                if (previousScreen == Screen.Login || previousScreen == Screen.Register || previousScreen == Screen.Activation || previousScreen == Screen.Splash) {
                    previousScreen = Screen.Selection
                }
            }
            _currentScreen.value = previousScreen
        } else {
            _currentScreen.value = if (_isLoggedIn.value) Screen.Selection else Screen.Login
        }
    }

    fun updateCredentials(newUsername: String, newPassword: String): Boolean {
        if (newUsername.trim().isEmpty() || newPassword.trim().isEmpty()) {
            return false
        }
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit()
            .putString("saved_username", newUsername.trim())
            .putString("saved_password", newPassword)
            .apply()
        _loggedInUser.value = newUsername.trim()
        return true
    }

    fun selectCourseForEdit(course: Course) {
        _selectedCourseForEdit.value = course
        courseNameInput.value = course.name
        courseStartDateInput.value = course.startDate
        courseEndDateInput.value = course.endDate
        courseStartTimeInput.value = course.startTime
        courseEndTimeInput.value = course.endTime
        courseDepartmentInput.value = course.departmentName
        courseDiplomaInput.value = course.diplomaName
        
        // Populate assigned subjects in form
        val assigned = dbCourseSubjects.value
            .filter { it.courseId == course.id }
            .map { it.subjectId }
            .toSet()
        selectedCourseSubjectsInput.value = assigned
    }

    fun clearCourseForm() {
        _selectedCourseForEdit.value = null
        courseNameInput.value = ""
        courseStartDateInput.value = ""
        courseEndDateInput.value = ""
        courseStartTimeInput.value = ""
        courseEndTimeInput.value = ""
        courseDepartmentInput.value = ""
        courseDiplomaInput.value = ""
        selectedCourseSubjectsInput.value = emptySet()
    }

    fun toggleSubjectSelectionInForm(subjectId: Int) {
        val current = selectedCourseSubjectsInput.value
        if (current.contains(subjectId)) {
            selectedCourseSubjectsInput.value = current - subjectId
        } else {
            selectedCourseSubjectsInput.value = current + subjectId
        }
    }

    fun addOrUpdateCourseTemp() {
        val name = courseNameInput.value.trim()
        val startDate = courseStartDateInput.value.trim()
        val endDate = courseEndDateInput.value.trim()
        val startTime = courseStartTimeInput.value.trim()
        val endTime = courseEndTimeInput.value.trim()
        val departmentName = courseDepartmentInput.value.trim()
        val diplomaName = courseDiplomaInput.value.trim()

        if (name.isEmpty() || startDate.isEmpty() || endDate.isEmpty() || startTime.isEmpty() || endTime.isEmpty()) {
            return
        }

        viewModelScope.launch {
            val editingCourse = _selectedCourseForEdit.value
            val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
            val isActivated = sharedPrefs.getBoolean("is_activated", false)
            if (!isActivated && editingCourse == null && dbCourses.value.size >= 1) {
                Toast.makeText(
                    getApplication(),
                    "النسخة التجريبية تتيح لك إضافة دورة واحدة فقط! يرجى تفعيل البرنامج لفتح جميع المزايا.",
                    Toast.LENGTH_LONG
                ).show()
                return@launch
            }

            if (editingCourse != null) {
                val updated = editingCourse.copy(
                    name = name,
                    startDate = startDate,
                    endDate = endDate,
                    startTime = startTime,
                    endTime = endTime,
                    departmentName = departmentName,
                    diplomaName = diplomaName
                )
                repository.updateCourse(updated)
                // Schedule notifications for the updated course
                val context = getApplication<Application>()
                val sharedPrefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
                val enabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
                if (enabled) {
                    val trainerMins = sharedPrefs.getInt("trainer_reminder_minutes", 15)
                    val checkInMins = sharedPrefs.getInt("student_check_in_reminder_minutes", 10)
                    val checkOutMins = sharedPrefs.getInt("student_check_out_reminder_minutes", 10)
                    com.example.notification.NotificationHelper.scheduleCourseReminders(
                        context, updated, trainerMins, checkInMins, checkOutMins
                    )
                }

                // Delete existing cross references and insert new ones
                dbCourseSubjects.value.filter { it.courseId == editingCourse.id }.forEach {
                    repository.deleteCourseSubject(it)
                }
                selectedCourseSubjectsInput.value.forEach { subId ->
                    repository.insertCourseSubject(CourseSubjectCrossRef(editingCourse.id, subId))
                }

                // Also update StudentGradeConfig for the edited course to match selected subjects
                val updatedSubjectsList = dbSubjects.value.filter { sub ->
                    selectedCourseSubjectsInput.value.contains(sub.id)
                }.map { it.name }
                if (updatedSubjectsList.isNotEmpty()) {
                    val existingConfig = repository.getGradeConfigForCourseSync(editingCourse.id)
                    val newSubjectsJson = updatedSubjectsList.joinToString("|")
                    if (existingConfig != null) {
                        repository.insertGradeConfig(
                            existingConfig.copy(
                                courseName = name,
                                diplomaSubjectsJson = newSubjectsJson
                            )
                        )
                    }
                }
            } else {
                val newCourse = Course(
                    id = 0,
                    name = name,
                    startDate = startDate,
                    endDate = endDate,
                    startTime = startTime,
                    endTime = endTime,
                    departmentName = departmentName,
                    diplomaName = diplomaName
                )
                val newId = repository.insertCourse(newCourse)
                // Schedule notifications for the new course
                val context = getApplication<Application>()
                val sharedPrefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
                val enabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
                if (enabled) {
                    val trainerMins = sharedPrefs.getInt("trainer_reminder_minutes", 15)
                    val checkInMins = sharedPrefs.getInt("student_check_in_reminder_minutes", 10)
                    val checkOutMins = sharedPrefs.getInt("student_check_out_reminder_minutes", 10)
                    val savedCourse = newCourse.copy(id = newId.toInt())
                    com.example.notification.NotificationHelper.scheduleCourseReminders(
                        context, savedCourse, trainerMins, checkInMins, checkOutMins
                    )
                }
                // Insert cross references
                selectedCourseSubjectsInput.value.forEach { subId ->
                    repository.insertCourseSubject(CourseSubjectCrossRef(newId.toInt(), subId))
                }

                // Automatically create a Grade Config for this new course based on Diploma or Department template
                var templateConfig: com.example.data.entity.StudentGradeConfig? = null
                if (diplomaName.isNotEmpty()) {
                    val dipTemplateId = com.example.data.entity.StudentGradeConfig.getDiplomaTemplateId(diplomaName)
                    templateConfig = repository.getGradeConfigForCourseSync(dipTemplateId)
                }
                if (templateConfig == null && departmentName.isNotEmpty()) {
                    val deptTemplateId = com.example.data.entity.StudentGradeConfig.getDepartmentTemplateId(departmentName)
                    templateConfig = repository.getGradeConfigForCourseSync(deptTemplateId)
                }

                // Fallback to default computer diploma config if no template found
                val fieldsJson = templateConfig?.customFieldsJson ?: com.example.data.entity.StudentGradeConfig.serializeFields(
                    if (departmentName.contains("حاسب") || departmentName.contains("حاسوب")) {
                        listOf(
                            Pair("حضور", 5),
                            Pair("مشاركة", 5),
                            Pair("تكاليف", 10),
                            Pair("مشاريع", 20),
                            Pair("اختبار نظري", 20),
                            Pair("اختبار عملي", 40)
                        )
                    } else {
                        listOf(
                            Pair("حضور", 10),
                            Pair("مشاركة", 10),
                            Pair("تكاليف", 20),
                            Pair("اختبار نظري", 30),
                            Pair("اختبار عملي", 30)
                        )
                    }
                )

                val subjectsList = dbSubjects.value.filter { sub ->
                    selectedCourseSubjectsInput.value.contains(sub.id)
                }.map { it.name }

                val finalSubjectsJson = if (subjectsList.isNotEmpty()) {
                    subjectsList.joinToString("|")
                } else {
                    templateConfig?.diplomaSubjectsJson ?: ""
                }

                val finalWeightsJson = templateConfig?.subjectWeightsJson?.takeIf { it.isNotBlank() }
                    ?: subjectsList.joinToString("|") { "${it.trim()}:100.0" }

                val config = com.example.data.entity.StudentGradeConfig(
                    courseId = newId.toInt(),
                    courseName = name,
                    isDiploma = true,
                    customFieldsJson = fieldsJson,
                    diplomaSubjectsJson = finalSubjectsJson,
                    subjectWeightsJson = finalWeightsJson
                )
                repository.insertGradeConfig(config)

                logActivity(
                    category = "COURSES",
                    actionType = "CREATE",
                    title = "إضافة دورة جديدة: $name",
                    description = "الفترة: من $startDate إلى $endDate | الوقت: $startTime - $endTime",
                    relatedId = newId
                )
            }
            if (editingCourse != null) {
                logActivity(
                    category = "COURSES",
                    actionType = "UPDATE",
                    title = "تعديل بيانات الدورة: $name",
                    description = "الفترة: من $startDate إلى $endDate | الوقت: $startTime - $endTime",
                    relatedId = editingCourse.id.toLong()
                )
            }
            clearCourseForm()
            rescheduleAllReminders()
        }
    }

    fun deleteCourseTemp(course: Course) {
        viewModelScope.launch {
            repository.deleteCourse(course)
            if (_selectedCourseForEdit.value?.id == course.id) {
                clearCourseForm()
            }
            logActivity(
                category = "COURSES",
                actionType = "DELETE",
                title = "حذف الدورة: ${course.name}",
                description = "تم حذف الدورة وكافة البيانات التابعة لها",
                relatedId = course.id.toLong()
            )
            rescheduleAllReminders()
        }
    }

    fun toggleCourseCompleted(course: Course) {
        viewModelScope.launch {
            val updated = course.copy(isCompleted = !course.isCompleted)
            repository.updateCourse(updated)
            logActivity(
                category = "COURSES",
                actionType = if (updated.isCompleted) "COMPLETE" else "REOPEN",
                title = if (updated.isCompleted) "إنهاء دورة: ${course.name} 🏁" else "إعادة تنشيط دورة: ${course.name} 🔄",
                description = if (updated.isCompleted) "تم تعيين الدورة كمنتهية." else "تمت إعادة تنشيط الدورة كمستمرة.",
                relatedId = course.id.toLong()
            )
            rescheduleAllReminders()
        }
    }

    fun saveCoursesToDb() { }

    fun selectCourseForAttendance(course: Course?) {
        _selectedCourseForAttendance.value = course
        _selectedCourseForStudentAttendance.value = course
        if (course != null) {
            if (course.startTime.isNotEmpty()) {
                attendanceCheckInInput.value = course.startTime
            }
            if (course.endTime.isNotEmpty()) {
                attendanceCheckOutInput.value = course.endTime
            }
            recalculateAttendanceForm()
            loadSavedSubjectName(course.id, attendanceDateInput.value)
        } else {
            studentAttendanceSubjectInput.value = ""
            recalculateAttendanceForm()
        }
    }

    fun onAttendanceTimeChanged() {
        recalculateAttendanceForm()
    }

    private fun recalculateAttendanceForm() {
        val course = _selectedCourseForAttendance.value
        val checkIn = attendanceCheckInInput.value
        val checkOut = attendanceCheckOutInput.value

        if (course == null) {
            _checkInAlert.value = null
            _checkOutAlert.value = null
            _calculatedDurationText.value = "0 ساعة و 0 دقيقة"
            return
        }

        if (checkIn.isNotEmpty()) {
            val delayMinutes = calculateMinutesDifference(checkIn, course.startTime)
            if (delayMinutes > 0) {
                _checkInAlert.value = "تنبيه: يوجد تأخير في وقت الدخول بمقدار $delayMinutes دقيقة"
            } else {
                _checkInAlert.value = null
            }
        } else {
            _checkInAlert.value = null
        }

        if (checkOut.isNotEmpty()) {
            val diffMinutes = calculateMinutesDifference(checkOut, course.endTime)
            if (diffMinutes < 0) {
                _checkOutAlert.value = "تنبيه: مغادرة مبكرة بمقدار ${-diffMinutes} دقيقة عن وقت نهاية الدورة"
            } else if (diffMinutes > 30) {
                _checkOutAlert.value = "ملاحظة: تمديد إضافي بعد الدوام بمقدار $diffMinutes دقيقة"
            } else {
                _checkOutAlert.value = null
            }
        } else {
            _checkOutAlert.value = null
        }

        if (checkIn.isNotEmpty() && checkOut.isNotEmpty()) {
            val totalMinutes = calculateMinutesDifference(checkOut, checkIn)
            if (totalMinutes > 0) {
                val h = totalMinutes / 60
                val m = totalMinutes % 60
                _calculatedDurationText.value = "$h ساعة و $m دقيقة"
            } else {
                _calculatedDurationText.value = "0 ساعة و 0 دقيقة (وقت غير صالح)"
            }
        } else {
            _calculatedDurationText.value = "0 ساعة و 0 دقيقة"
        }
    }

    fun checkIsTimeTampered(currentTimeStr: String): Boolean {
        val lastRecord = dbAttendance.value.maxByOrNull { it.systemCreatedAt } ?: return false
        if (lastRecord.systemCreatedAt.isEmpty()) return false
        return currentTimeStr < lastRecord.systemCreatedAt
    }

    fun addOrUpdateAttendanceTemp(): String? {
        val course = _selectedCourseForAttendance.value ?: return "يرجى اختيار الدورة التدريبية"
        val day = attendanceDayInput.value
        val date = attendanceDateInput.value
        val checkIn = attendanceCheckInInput.value
        val checkOut = attendanceCheckOutInput.value
        val status = attendanceStatusInput.value

        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        if (todayStr > course.endDate) {
            return "عذراً، لا يمكن تسجيل حركات حضور وغياب للمدرب لأن الدورة التدريبية منتهية بالفعل! (انتهت في ${course.endDate})"
        }

        if (date < course.startDate || date > course.endDate) {
            return "عذراً، لا يمكن تسجيل حركة خارج فترة الدورة التدريبية! (فترة الدورة من ${course.startDate} إلى ${course.endDate})"
        }

        val editingAttendance = _selectedAttendanceForEdit.value
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val isActivated = sharedPrefs.getBoolean("is_activated", false)
        if (!isActivated && editingAttendance == null && dbAttendance.value.size >= 5) {
            return "عذراً، النسخة التجريبية تتيح لك إضافة 5 حركات حضور وغياب للمدرب فقط! يرجى تفعيل البرنامج لفتح جميع المزايا."
        }

        val existing = dbAttendance.value.find { 
            it.courseId == course.id && it.date == date && (editingAttendance == null || it.id != editingAttendance.id) 
        }
        if (existing != null) {
            return "عذراً، تم تسجيل حركة بالفعل لهذه الدورة في هذا اليوم!"
        }

        val isPresent = status == "حضور"

        if (isPresent && checkIn.isEmpty()) return "يرجى تحديد وقت الدخول الفعلي!"

        val finalCheckIn = if (isPresent) checkIn else ""
        val finalCheckOut = if (isPresent) checkOut else ""

        val checkInDelay = if (isPresent && finalCheckIn.isNotEmpty()) calculateMinutesDifference(finalCheckIn, course.startTime).coerceAtLeast(0) else 0
        val checkOutDiff = if (isPresent && finalCheckOut.isNotEmpty()) calculateMinutesDifference(finalCheckOut, course.endTime) else 0
        val totalMinutes = if (isPresent && finalCheckOut.isNotEmpty()) calculateMinutesDifference(finalCheckOut, finalCheckIn) else 0
        val h = if (isPresent && totalMinutes > 0) totalMinutes / 60 else 0
        val m = if (isPresent && totalMinutes > 0) totalMinutes % 60 else 0

        val hasAlert = isPresent && (checkInDelay > 0 || checkOutDiff < 0)
        val alertMsg = if (isPresent) {
            buildString {
                if (checkInDelay > 0) append("تأخير دخول ($checkInDelay د) ")
                if (checkOutDiff < 0) append("انصراف مبكر (${-checkOutDiff} د) ")
            }.trim()
        } else ""

        val sysTimeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val currentSysTime = sysTimeFormat.format(java.util.Calendar.getInstance().time)
        val sysCreatedAt = editingAttendance?.systemCreatedAt ?: currentSysTime
        val timeTampered = checkIsTimeTampered(sysCreatedAt)

        viewModelScope.launch {
            if (editingAttendance != null) {
                val newIsExamDay = _isExamDayForNextRecord.value
                val oldIsExamDay = editingAttendance.isExamDay
                val updated = editingAttendance.copy(
                    courseId = course.id,
                    courseName = course.name,
                    dayOfWeek = day,
                    date = date,
                    actualCheckIn = finalCheckIn,
                    actualCheckOut = finalCheckOut,
                    checkInDelayMinutes = checkInDelay,
                    checkOutDifferenceMinutes = checkOutDiff,
                    durationHours = h,
                    durationMinutes = m,
                    hasAlert = hasAlert,
                    alertMessage = alertMsg,
                    isLocked = true,
                    status = status,
                    note = attendanceNoteInput.value,
                    subjectName = studentAttendanceSubjectInput.value,
                    systemCreatedAt = if (editingAttendance.systemCreatedAt.isEmpty()) sysCreatedAt else editingAttendance.systemCreatedAt,
                    isTimeTampered = editingAttendance.isTimeTampered,
                    isExamDay = newIsExamDay
                )
                repository.updateAttendance(updated)
                if (oldIsExamDay != newIsExamDay) {
                    val stats = getCourseSubjectStats(course.id)
                    val stat = stats.find { it.subjectName.trim().equals(studentAttendanceSubjectInput.value.trim(), ignoreCase = true) }
                    if (stat != null) {
                        val newStatus = if (newIsExamDay) "مكتملة التدريس" else "قيد التدريس"
                        updateCourseSubjectStatus(course.id, stat.subjectId, newStatus)
                    }
                }
                logActivity(
                    category = "TRAINER",
                    actionType = "UPDATE",
                    title = "تعديل دوام المدرب: ${course.name}",
                    description = "تعديل يدوي للحالة: ${updated.status} | التاريخ: ${updated.date} | المادة: ${updated.subjectName.ifEmpty { "عام" }} | نوع الجلسة: ${if (newIsExamDay) "امتحان" else "درس"} | الدخول: ${updated.actualCheckIn.ifEmpty { "بدون" }} | الخروج: ${updated.actualCheckOut.ifEmpty { "بدون" }}",
                    relatedId = course.id.toLong()
                )
            } else {
                val newRecord = Attendance(
                    id = 0,
                    courseId = course.id,
                    courseName = course.name,
                    dayOfWeek = day,
                    date = date,
                    actualCheckIn = finalCheckIn,
                    actualCheckOut = finalCheckOut,
                    checkInDelayMinutes = checkInDelay,
                    checkOutDifferenceMinutes = checkOutDiff,
                    durationHours = h,
                    durationMinutes = m,
                    hasAlert = hasAlert,
                    alertMessage = alertMsg,
                    isLocked = true,
                    status = status,
                    note = attendanceNoteInput.value,
                    subjectName = studentAttendanceSubjectInput.value,
                    systemCreatedAt = sysCreatedAt,
                    isTimeTampered = timeTampered
                )
                repository.insertAttendance(newRecord)
                logActivity(
                    category = "TRAINER",
                    actionType = "CREATE",
                    title = "تسجيل دوام المدرب: ${course.name}",
                    description = "تسجيل يدوي للحالة: ${newRecord.status} | التاريخ: ${newRecord.date} | المادة: ${newRecord.subjectName.ifEmpty { "عام" }} | الدخول: ${newRecord.actualCheckIn.ifEmpty { "بدون" }} | الخروج: ${newRecord.actualCheckOut.ifEmpty { "بدون" }}",
                    relatedId = course.id.toLong()
                )
            }
            clearAttendanceForm()
        }
        return null
    }

    fun selectAttendanceForEdit(record: Attendance) {
        _selectedAttendanceForEdit.value = record
        val course = _tempCourses.value.find { it.id == record.courseId } ?: Course(id = record.courseId, name = record.courseName, startDate = "", endDate = "", startTime = "", endTime = "")
        _selectedCourseForAttendance.value = course
        attendanceDayInput.value = record.dayOfWeek
        attendanceDateInput.value = record.date
        attendanceCheckInInput.value = record.actualCheckIn
        attendanceCheckOutInput.value = record.actualCheckOut
        attendanceStatusInput.value = record.status
        attendanceNoteInput.value = record.note
        studentAttendanceSubjectInput.value = record.subjectName
        _isExamDayForNextRecord.value = record.isExamDay
        recalculateAttendanceForm()
    }

    fun deleteAttendanceTemp(record: Attendance) {
        viewModelScope.launch {
            repository.deleteAttendance(record)
            if (_selectedAttendanceForEdit.value?.id == record.id) {
                clearAttendanceForm()
            }
            if (record.isExamDay) {
                val stats = getCourseSubjectStats(record.courseId)
                val stat = stats.find { it.subjectName.trim().equals(record.subjectName.trim(), ignoreCase = true) }
                if (stat != null) {
                    updateCourseSubjectStatus(record.courseId, stat.subjectId, "قيد التدريس")
                }
            }
            logActivity(
                category = "TRAINER",
                actionType = "DELETE",
                title = "حذف سجل دوام المدرب: ${record.courseName}",
                description = "التاريخ: ${record.date} | الحالة المحذوفة: ${record.status}",
                relatedId = record.courseId.toLong()
            )
        }
    }

    fun deleteStudentAttendancesForDate(courseId: Int, dateStr: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val list = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == dateStr }
            if (list.isNotEmpty()) {
                repository.deleteStudentAttendances(list)
            }
            logActivity(
                category = "ATTENDANCE",
                actionType = "RESET",
                title = "حذف وتصفير حضور جميع الطلاب 🔴",
                description = "تم تصفير حضور الطلاب للدورة بالكامل بسبب حذف أو إعادة ضبط حركة المدرب بتاريخ $dateStr",
                relatedId = courseId.toLong(),
                customDateStr = dateStr
            )
        }
    }

    fun cancelTrainerCheckOut(record: Attendance) {
        viewModelScope.launch {
            val updated = record.copy(
                actualCheckOut = "",
                checkOutDifferenceMinutes = 0,
                status = "حضور"
            )
            repository.insertAttendance(updated)
            logActivity(
                category = "TRAINER",
                actionType = "UPDATE",
                title = "إلغاء انصراف المدرب: ${record.courseName}",
                description = "تم إلغاء وقت الانصراف للمدرب في تاريخ ${record.date}",
                relatedId = record.courseId.toLong()
            )
        }
    }

    fun clearAttendanceForm() {
        _selectedAttendanceForEdit.value = null
        val sdfTime = SimpleDateFormat("HH:mm", Locale.US)
        val currentTime = sdfTime.format(Calendar.getInstance().time)
        attendanceCheckInInput.value = currentTime
        attendanceCheckOutInput.value = currentTime
        attendanceStatusInput.value = "حضور"
        attendanceNoteInput.value = ""
        studentAttendanceSubjectInput.value = ""
        _isExamDayForNextRecord.value = false
        _checkInAlert.value = null
        _checkOutAlert.value = null
        _calculatedDurationText.value = "0 ساعة و 0 دقيقة"
        recalculateAttendanceForm()
    }

    fun setCheckInToCurrentTime() {
        val sdfTime = SimpleDateFormat("HH:mm", Locale.US)
        val currentTime = sdfTime.format(Calendar.getInstance().time)
        attendanceCheckInInput.value = currentTime
        recalculateAttendanceForm()
    }

    fun setCheckOutToCurrentTime() {
        val sdfTime = SimpleDateFormat("HH:mm", Locale.US)
        val currentTime = sdfTime.format(Calendar.getInstance().time)
        attendanceCheckOutInput.value = currentTime
        recalculateAttendanceForm()
    }

    fun recordCheckInOnly(): String? {
        val course = _selectedCourseForAttendance.value ?: return "يرجى اختيار الدورة التدريبية"
        val subjectName = studentAttendanceSubjectInput.value.trim()
        val date = attendanceDateInput.value
        val day = attendanceDayInput.value
        val checkIn = attendanceCheckInInput.value

        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        if (todayStr > course.endDate) {
            return "عذراً، لا يمكن تسجيل حركات حضور للمدرب لأن الدورة التدريبية منتهية بالفعل! (انتهت في ${course.endDate})"
        }

        if (date < course.startDate || date > course.endDate) {
            return "عذراً، لا يمكن تسجيل حركة خارج فترة الدورة التدريبية! (فترة الدورة من ${course.startDate} إلى ${course.endDate})"
        }

        if (checkIn.isEmpty()) return "يرجى تحديد وقت الدخول الفعلي"

        val subject = studentAttendanceSubjectInput.value.trim()
        if (subject.isEmpty()) return "يرجى اختيار المادة التدريبية لاعتمادها في التحضير ولا يمكن تركها فارغة"

        val existing = dbAttendance.value.find { it.courseId == course.id && it.date == date }
        if (existing != null) {
            if (existing.status == "غياب" || existing.status == "إجازة") {
                return "عذراً، تم تسجيل حركة (${existing.status}) بالفعل لهذه الدورة في هذا اليوم!"
            }
            if (existing.actualCheckIn.isNotEmpty() && existing.actualCheckOut.isEmpty()) {
                return "تم تسجيل دخول بالفعل لهذه الدورة في هذا اليوم، يرجى تسجيل الخروج لإتمام الحركة."
            } else if (existing.actualCheckIn.isNotEmpty() && existing.actualCheckOut.isNotEmpty()) {
                return "تم تسجيل الدخول والخروج بالكامل لهذه الدورة في هذا اليوم!"
            }
        }

        val checkInDelay = calculateMinutesDifference(checkIn, course.startTime).coerceAtLeast(0)
        val hasAlert = checkInDelay > 0
        val alertMsg = if (checkInDelay > 0) "تأخير دخول ($checkInDelay د)" else ""

        val sysTimeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val sysCreatedAt = sysTimeFormat.format(java.util.Calendar.getInstance().time)
        val timeTampered = checkIsTimeTampered(sysCreatedAt)

        val newRecord = Attendance(
            id = 0,
            courseId = course.id,
            courseName = course.name,
            dayOfWeek = day,
            date = date,
            actualCheckIn = checkIn,
            actualCheckOut = "",
            checkInDelayMinutes = checkInDelay,
            checkOutDifferenceMinutes = 0,
            durationHours = 0,
            durationMinutes = 0,
            hasAlert = hasAlert,
            alertMessage = alertMsg,
            note = attendanceNoteInput.value,
            subjectName = studentAttendanceSubjectInput.value,
            systemCreatedAt = sysCreatedAt,
            isTimeTampered = timeTampered,
            isExamDay = _isExamDayForNextRecord.value
        )

        viewModelScope.launch {
            repository.insertAttendance(newRecord)
            
            // If it was an exam day, mark subject as completed
            if (_isExamDayForNextRecord.value) {
                val stats = getCourseSubjectStats(course.id)
                val stat = stats.find { it.subjectName.trim().equals(subjectName, ignoreCase = true) }
                if (stat != null) {
                    updateCourseSubjectStatus(course.id, stat.subjectId, "مكتملة التدريس")
                }
            }
            _isExamDayForNextRecord.value = false
        }

        if (checkInDelay > 0) {
            _checkInAlert.value = "تنبيه: يوجد تأخير في وقت الدخول بمقدار $checkInDelay دقيقة"
        } else {
            _checkInAlert.value = "تم تسجيل الدخول في الوقت المحدد بنجاح!"
        }
        _checkOutAlert.value = null
        _calculatedDurationText.value = "غير مكتملة (بانتظار حركة الخروج)"

        return null
    }

    fun recordCheckOutAndComplete(): String? {
        val course = _selectedCourseForAttendance.value ?: return "يرجى اختيار الدورة التدريبية"
        val date = attendanceDateInput.value
        val checkOut = attendanceCheckOutInput.value

        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        if (todayStr > course.endDate) {
            return "عذراً، لا يمكن تسجيل حركات خروج للمدرب لأن الدورة التدريبية منتهية بالفعل! (انتهت في ${course.endDate})"
        }

        if (date < course.startDate || date > course.endDate) {
            return "عذراً، لا يمكن تسجيل حركة خارج فترة الدورة التدريبية! (فترة الدورة من ${course.startDate} إلى ${course.endDate})"
        }

        if (checkOut.isEmpty()) return "يرجى تحديد وقت الانصراف الفعلي"

        val list = dbAttendance.value
        val index = list.indexOfFirst { it.courseId == course.id && it.date == date && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() }

        if (index == -1) {
            val existing = list.find { it.courseId == course.id && it.date == date }
            if (existing != null) {
                if (existing.status == "غياب" || existing.status == "إجازة") {
                    return "عذراً، تم تسجيل حركة (${existing.status}) بالفعل لهذه الدورة في هذا اليوم!"
                }
                if (existing.actualCheckIn.isNotEmpty() && existing.actualCheckOut.isNotEmpty()) {
                    return "تم تسجيل الدخول والخروج بالكامل لهذه الدورة في هذا اليوم!"
                }
            }
            return "عذراً، يجب تسجيل حركة الدخول أولاً لهذه الدورة قبل تسجيل الخروج!"
        }

        val pendingRecord = list[index]
        val checkIn = pendingRecord.actualCheckIn

        val checkInDelay = pendingRecord.checkInDelayMinutes
        val checkOutDiff = calculateMinutesDifference(checkOut, course.endTime)
        val totalMinutes = calculateMinutesDifference(checkOut, checkIn)
        val h = if (totalMinutes > 0) totalMinutes / 60 else 0
        val m = if (totalMinutes > 0) totalMinutes % 60 else 0

        val hasAlert = checkInDelay > 0 || checkOutDiff < 0
        val alertMsg = buildString {
            if (checkInDelay > 0) append("تأخير دخول ($checkInDelay د) ")
            if (checkOutDiff < 0) append("انصراف مبكر (${-checkOutDiff} د) ")
        }.trim()

        val completedRecord = pendingRecord.copy(
            actualCheckOut = checkOut,
            checkOutDifferenceMinutes = checkOutDiff,
            durationHours = h,
            durationMinutes = m,
            hasAlert = hasAlert,
            alertMessage = alertMsg
        )

        viewModelScope.launch {
            repository.updateAttendance(completedRecord)
            
            val selStudentCourse = _selectedCourseForStudentAttendance.value
            if (selStudentCourse != null && selStudentCourse.id == course.id && studentAttendanceDateInput.value == date) {
                studentCheckOutTimeInput.value = checkOut
            }
        }

        if (checkOutDiff < 0) {
            _checkOutAlert.value = "تنبيه: مغادرة مبكرة بمقدار ${-checkOutDiff} دقيقة عن وقت نهاية الدورة"
        } else {
            _checkOutAlert.value = "تم تسجيل الخروج بنجاح واكتملت الحركة!"
        }
        _calculatedDurationText.value = "$h ساعة و $m دقيقة"

        return null
    }

    fun recordTrainerCheckOutDirectly(courseId: Int, date: String, checkOutTime: String): String? {
        val course = dbCourses.value.find { it.id == courseId } ?: return "الدورة التدريبية غير موجودة"
        val list = dbAttendance.value
        val pendingRecord = list.find { it.courseId == course.id && it.date == date && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() }
        
        if (pendingRecord != null) {
            val checkIn = pendingRecord.actualCheckIn
            val checkInDelay = pendingRecord.checkInDelayMinutes
            val checkOutDiff = calculateMinutesDifference(checkOutTime, course.endTime)
            val totalMinutes = calculateMinutesDifference(checkOutTime, checkIn)
            val h = if (totalMinutes > 0) totalMinutes / 60 else 0
            val m = if (totalMinutes > 0) totalMinutes % 60 else 0

            val hasAlert = checkInDelay > 0 || checkOutDiff < 0
            val alertMsg = buildString {
                if (checkInDelay > 0) append("تأخير دخول ($checkInDelay د) ")
                if (checkOutDiff < 0) append("انصراف مبكر (${-checkOutDiff} د) ")
            }.trim()

            val completedRecord = pendingRecord.copy(
                actualCheckOut = checkOutTime,
                checkOutDifferenceMinutes = checkOutDiff,
                durationHours = h,
                durationMinutes = m,
                hasAlert = hasAlert,
                alertMessage = alertMsg
            )

            viewModelScope.launch {
                repository.updateAttendance(completedRecord)
                logActivity("تعديل", "حضور مدرب", course.name, "تسجيل انصراف للأستاذ في دورة (${course.name}) الساعة $checkOutTime بعد انصراف الطلاب")
            }
            return null
        } else {
            // In case trainer didn't have a check-in record yet, create a full presence record
            val checkIn = course.startTime.ifEmpty { checkOutTime }
            val checkOutDiff = calculateMinutesDifference(checkOutTime, course.endTime)
            val totalMinutes = calculateMinutesDifference(checkOutTime, checkIn)
            val h = if (totalMinutes > 0) totalMinutes / 60 else 0
            val m = if (totalMinutes > 0) totalMinutes % 60 else 0
            val dayName = getArabicDayOfWeek(date)

            val newRecord = Attendance(
                id = 0,
                courseId = course.id,
                courseName = course.name,
                dayOfWeek = dayName,
                date = date,
                actualCheckIn = checkIn,
                actualCheckOut = checkOutTime,
                checkInDelayMinutes = 0,
                checkOutDifferenceMinutes = checkOutDiff,
                durationHours = h,
                durationMinutes = m,
                hasAlert = checkOutDiff < 0,
                alertMessage = if (checkOutDiff < 0) "انصراف مبكر (${-checkOutDiff} د)" else "",
                status = "حضور",
                subjectName = studentAttendanceSubjectInput.value
            )

            viewModelScope.launch {
                repository.insertAttendance(newRecord)
                logActivity("إضافة", "حضور مدرب", course.name, "تسجيل حضور وانصراف متكامل للأستاذ في دورة (${course.name}) عند انصراف الطلاب")
            }
            return null
        }
    }

    fun getStudentsPendingCheckOutCount(courseId: Int? = null, dateStr: String? = null): Int {
        val targetCourseId = courseId ?: _selectedCourseForStudentAttendance.value?.id ?: _selectedCourseForAttendance.value?.id ?: return 0
        val targetDate = dateStr ?: studentAttendanceDateInput.value.ifEmpty { attendanceDateInput.value }
        val courseStudents = dbAllStudents.value.filter { it.courseId == targetCourseId && (it.status == "مستمر" || it.status.isEmpty()) }
        val recordsForDate = dbAllStudentAttendance.value.filter { it.courseId == targetCourseId && it.date == targetDate }
        
        return courseStudents.count { std ->
            val rec = recordsForDate.find { it.studentId == std.id }
            rec != null && rec.status == "حضور" && rec.actualCheckIn.isNotEmpty() && rec.actualCheckOut.isEmpty()
        }
    }

    fun getStudentsUnrecordedCount(courseId: Int? = null, dateStr: String? = null): Int {
        val targetCourseId = courseId ?: _selectedCourseForStudentAttendance.value?.id ?: _selectedCourseForAttendance.value?.id ?: return 0
        val targetDate = dateStr ?: studentAttendanceDateInput.value.ifEmpty { attendanceDateInput.value }
        val courseStudents = dbAllStudents.value.filter { it.courseId == targetCourseId && (it.status == "مستمر" || it.status.isEmpty()) }
        val recordsForDate = dbAllStudentAttendance.value.filter { it.courseId == targetCourseId && it.date == targetDate }
        
        return courseStudents.count { std ->
            val rec = recordsForDate.find { it.studentId == std.id }
            rec == null || rec.status == "لم يسجل" || (rec.status.isEmpty())
        }
    }

    fun getStudentsUnrecordedNames(courseId: Int? = null, dateStr: String? = null): List<String> {
        val targetCourseId = courseId ?: _selectedCourseForStudentAttendance.value?.id ?: _selectedCourseForAttendance.value?.id ?: return emptyList()
        val targetDate = dateStr ?: studentAttendanceDateInput.value.ifEmpty { attendanceDateInput.value }
        val courseStudents = dbAllStudents.value.filter { it.courseId == targetCourseId && (it.status == "مستمر" || it.status.isEmpty()) }
        val recordsForDate = dbAllStudentAttendance.value.filter { it.courseId == targetCourseId && it.date == targetDate }
        
        return courseStudents.filter { std ->
            val rec = recordsForDate.find { it.studentId == std.id }
            rec == null || rec.status == "لم يسجل" || rec.status.isEmpty()
        }.map { it.name }
    }

    fun autoCheckOutPresentAndMarkAbsentUnrecordedStudents(
        checkOutTime: String,
        markUnrecordedAsAbsent: Boolean = true,
        onCompleted: ((absentNames: List<String>, checkedOutNames: List<String>) -> Unit)? = null
    ) {
        val courseId = _selectedCourseForAttendance.value?.id ?: _selectedCourseForStudentAttendance.value?.id ?: return
        val course = dbCourses.value.find { it.id == courseId } ?: return
        val targetDate = attendanceDateInput.value.ifEmpty { studentAttendanceDateInput.value }
        val dayName = getArabicDayOfWeek(targetDate)
        
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            loadSavedSubjectName(course.id, targetDate)
        }
        val currentSubject = studentAttendanceSubjectInput.value

        val courseStudents = dbAllStudents.value.filter { it.courseId == courseId && (it.status == "مستمر" || it.status.isEmpty()) }
        val recordsForDate = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == targetDate }

        val markedAbsentNames = mutableListOf<String>()
        val checkedOutNames = mutableListOf<String>()

        viewModelScope.launch(Dispatchers.IO) {
            val toInsert = mutableListOf<StudentAttendance>()
            courseStudents.forEach { student ->
                val attendance = recordsForDate.find { it.studentId == student.id }
                val finalSubject = if (attendance != null && attendance.subjectName.isNotEmpty()) attendance.subjectName else currentSubject
                
                if (attendance != null && attendance.status == "حضور" && attendance.actualCheckIn.isNotEmpty() && attendance.actualCheckOut.isEmpty()) {
                    val checkOutDiff = calculateMinutesDifference(checkOutTime, course.endTime)
                    val isEarly = checkOutDiff < 0
                    val earlyMinutes = if (isEarly) -checkOutDiff else 0
                    val delay = attendance.checkInDelayMinutes
                    val hasAlert = delay > 0 || earlyMinutes > 0
                    val alertMsg = buildString {
                        if (delay > 0) append("تأخير دخول ($delay د) ")
                        if (earlyMinutes > 0) append("انصراف مبكر ($earlyMinutes د) ")
                    }.trim()

                    val record = attendance.copy(
                        actualCheckOut = checkOutTime,
                        checkOutDifferenceMinutes = checkOutDiff,
                        hasAlert = hasAlert,
                        alertMessage = alertMsg,
                        subjectName = finalSubject
                    )
                    toInsert.add(record)
                    checkedOutNames.add(student.name)
                    logActivity("تعديل", "حضور طالب", attendance.studentName, "تم تسجيل انصراف تلقائي للطالب (${attendance.studentName}) عند انصراف المدرب الساعة $checkOutTime")
                } else if (markUnrecordedAsAbsent && (attendance == null || attendance.status == "لم يسجل" || attendance.status.isEmpty())) {
                    val newRecord = (attendance ?: StudentAttendance(
                        id = 0,
                        studentId = student.id,
                        studentName = student.name,
                        courseId = courseId,
                        courseName = course.name,
                        dayOfWeek = dayName,
                        date = targetDate,
                        actualCheckIn = "",
                        actualCheckOut = "",
                        checkInDelayMinutes = 0,
                        checkOutDifferenceMinutes = 0,
                        hasAlert = false,
                        alertMessage = "",
                        status = "غياب",
                        participationStars = 0,
                        isOnBreak = false,
                        subjectName = finalSubject
                    )).copy(
                        status = "غياب",
                        participationStars = 0,
                        isOnBreak = false,
                        subjectName = finalSubject,
                        actualCheckIn = "",
                        actualCheckOut = ""
                    )
                    toInsert.add(newRecord)
                    markedAbsentNames.add(student.name)
                    logActivity("إضافة", "حضور طالب", student.name, "تم رصد غياب تلقائي للطالب (${student.name}) لعدم تحضيره عند انصراف المدرب")
                }
            }
            if (toInsert.isNotEmpty()) {
                insertStudentAttendancesDirectly(toInsert)
            }
            onCompleted?.invoke(markedAbsentNames, checkedOutNames)
        }
    }

    fun markUnrecordedStudentsAbsent(
        courseId: Int,
        dateStr: String,
        targetStudentIds: List<Int>? = null,
        onCompleted: ((List<String>) -> Unit)? = null
    ) {
        val course = dbCourses.value.find { it.id == courseId } ?: return
        val dayName = getArabicDayOfWeek(dateStr)
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            loadSavedSubjectName(course.id, dateStr)
        }
        val currentSubject = studentAttendanceSubjectInput.value
        val courseStudents = dbAllStudents.value.filter { it.courseId == courseId }
        val recordsForDate = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == dateStr }
        val markedAbsentNames = mutableListOf<String>()
        viewModelScope.launch(Dispatchers.IO) {
            val toInsert = mutableListOf<StudentAttendance>()
            courseStudents.forEach { student ->
                if (targetStudentIds == null || student.id in targetStudentIds) {
                    val attendance = recordsForDate.find { it.studentId == student.id }
                    if (attendance == null || attendance.status == "لم يسجل" || attendance.status.isEmpty()) {
                        val finalSubject = if (attendance != null && attendance.subjectName.isNotEmpty()) attendance.subjectName else currentSubject
                        val newRecord = (attendance ?: StudentAttendance(
                            id = 0,
                            studentId = student.id,
                            studentName = student.name,
                            courseId = courseId,
                            courseName = course.name,
                            dayOfWeek = dayName,
                            date = dateStr,
                            actualCheckIn = "",
                            actualCheckOut = "",
                            checkInDelayMinutes = 0,
                            checkOutDifferenceMinutes = 0,
                            hasAlert = false,
                            alertMessage = "",
                            status = "غياب",
                            participationStars = 0,
                            isOnBreak = false,
                            subjectName = finalSubject
                        )).copy(
                            status = "غياب",
                            participationStars = 0,
                            isOnBreak = false,
                            subjectName = finalSubject,
                            actualCheckIn = "",
                            actualCheckOut = ""
                        )
                        toInsert.add(newRecord)
                        markedAbsentNames.add(student.name)
                        logActivity("إضافة", "حضور طالب", student.name, "تم رصد غياب تلقائي للطالب (${student.name}) عند الانصراف")
                    }
                }
            }
            if (toInsert.isNotEmpty()) {
                insertStudentAttendancesDirectly(toInsert)
            }
            onCompleted?.invoke(markedAbsentNames)
        }
    }

    fun rescheduleAllReminders() {
        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val sharedPrefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
            val enabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
            val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())

            val courses = repository.allCourses.first()

            // Cancel all existing alarms for all courses
            courses.forEach { course ->
                com.example.notification.NotificationHelper.cancelCourseReminders(context, course.id)
            }

            // If smart notifications are enabled, schedule alarms for active, non-ended courses only
            if (enabled) {
                val trainerMins = sharedPrefs.getInt("trainer_reminder_minutes", 15)
                val checkInMins = sharedPrefs.getInt("student_check_in_reminder_minutes", 10)
                val checkOutMins = sharedPrefs.getInt("student_check_out_reminder_minutes", 10)
                courses.filter { !it.isCompleted && (it.endDate.isBlank() || it.endDate >= todayStr) }.forEach { course ->
                    com.example.notification.NotificationHelper.scheduleCourseReminders(
                        context,
                        course,
                        trainerMins,
                        checkInMins,
                        checkOutMins
                    )
                }
            }
        }
    }

    fun sendTestNotification(
        title: String = "تنبيه اختبار دوامي 🔔🧠",
        message: String = "تم تفعيل وتحديث إعدادات التنبيهات والاشعارات الذكية بنجاح!",
        type: String = "test",
        voiceGender: String? = null
    ) {
        val context = getApplication<Application>()
        val intent = android.content.Intent(context, com.example.notification.NotificationReceiver::class.java).apply {
            putExtra("title", title)
            putExtra("message", message)
            putExtra("type", type)
            if (voiceGender != null) {
                putExtra("voice_gender", voiceGender)
            }
        }
        context.sendBroadcast(intent)

        val inAppType = when (type) {
            "instant_success" -> "success"
            "test" -> "info"
            else -> "info"
        }
        triggerFlashMessage(title, message, inAppType)
    }

    fun saveAllAttendanceToDb() { }

    fun updateReportFilter(
        courseFilter: String = selectedCourseReportFilter.value,
        dateFrom: String = reportDateFromFilter.value,
        dateTo: String = reportDateToFilter.value,
        statusFilter: String = selectedStatusReportFilter.value,
        courseStatusFilter: String = selectedCourseStatusReportFilter.value,
        subjectFilter: String = selectedSubjectReportFilter.value
    ) {
        _selectedCourseReportFilter.value = if (courseFilter.isEmpty()) "الكل" else courseFilter
        _reportDateFromFilter.value = dateFrom
        _reportDateToFilter.value = dateTo
        _selectedStatusReportFilter.value = statusFilter
        _selectedCourseStatusReportFilter.value = courseStatusFilter
        _selectedSubjectReportFilter.value = subjectFilter
        updateReportsGrouping()
    }

    private fun standardizeDate(dateStr: String): String {
        if (dateStr.isEmpty()) return ""
        val formats = listOf("yyyy-MM-dd", "yyyy/MM/dd", "dd-MM-yyyy", "dd/MM/yyyy")
        for (fmt in formats) {
            try {
                val sdf = java.text.SimpleDateFormat(fmt, java.util.Locale.US)
                sdf.isLenient = false
                val parsed = sdf.parse(dateStr.trim())
                if (parsed != null) {
                    return java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(parsed)
                }
            } catch (e: Exception) {
                // Ignore and try next
            }
        }
        return dateStr
    }

    private fun updateReportsGrouping() {
        val records = dbAttendance.value
        val courseFilter = _selectedCourseReportFilter.value
        val dateFrom = _reportDateFromFilter.value
        val dateTo = _reportDateToFilter.value
        val statusFilter = _selectedStatusReportFilter.value
        val courseStatusFilter = _selectedCourseStatusReportFilter.value
        val subjectFilter = _selectedSubjectReportFilter.value

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayStr = sdf.format(Calendar.getInstance().time)

        val dateFromStd = standardizeDate(dateFrom)
        val dateToStd = standardizeDate(dateTo)

        val filtered = records.filter { record ->
            val matchCourse = courseFilter == "الكل" || record.courseName.trim().equals(courseFilter.trim(), ignoreCase = true)
            
            val recordDateStd = standardizeDate(record.date)
            val matchFrom = dateFromStd.isEmpty() || recordDateStd >= dateFromStd
            val matchTo = dateToStd.isEmpty() || recordDateStd <= dateToStd
            
            val matchStatus = statusFilter == "الكل" || record.status == statusFilter
            
            // Resolve subject name dynamically if the record's subject name is empty
            val resolvedSubjectName = if (record.subjectName.isNotEmpty()) {
                record.subjectName
            } else {
                dbAllStudentAttendance.value.firstOrNull { studentAtt ->
                    studentAtt.courseId == record.courseId && studentAtt.date == record.date && studentAtt.subjectName.isNotEmpty()
                }?.subjectName ?: ""
            }
            val matchSubject = subjectFilter == "الكل" || resolvedSubjectName.trim().equals(subjectFilter.trim(), ignoreCase = true)

            val matchCourseStatus = if (courseStatusFilter == "الكل") {
                true
            } else {
                val course = dbCourses.value.find { it.id == record.courseId }
                if (course != null) {
                    val isActive = course.endDate >= todayStr
                    if (courseStatusFilter == "نشطة") isActive else !isActive
                } else {
                    true
                }
            }

            matchCourse && matchFrom && matchTo && matchStatus && matchCourseStatus && matchSubject
        }

        val grouped = if (_reportGroupingMode.value == "التاريخ") {
            filtered.groupBy { it.date }
        } else {
            filtered.groupBy { it.courseName }
        }
        _groupedReports.value = grouped
    }

    fun calculateMinutesDifference(time1: String, time2: String): Int {
        val clean1 = time1.trim().lowercase(java.util.Locale.US)
        val clean2 = time2.trim().lowercase(java.util.Locale.US)
        val t1 = clean1.split(":")
        val t2 = clean2.split(":")
        if (t1.size != 2 || t2.size != 2) return 0
        
        var h1 = t1[0].filter { it.isDigit() }.toIntOrNull() ?: 0
        val m1 = t1[1].filter { it.isDigit() }.toIntOrNull() ?: 0
        var h2 = t2[0].filter { it.isDigit() }.toIntOrNull() ?: 0
        val m2 = t2[1].filter { it.isDigit() }.toIntOrNull() ?: 0
        
        val isPM1 = clean1.contains("م") || clean1.contains("pm")
        val isAM1 = clean1.contains("ص") || clean1.contains("am")
        if (isPM1 && h1 < 12) h1 += 12
        if (isAM1 && h1 == 12) h1 = 0
        
        val isPM2 = clean2.contains("م") || clean2.contains("pm")
        val isAM2 = clean2.contains("ص") || clean2.contains("am")
        if (isPM2 && h2 < 12) h2 += 12
        if (isAM2 && h2 == 12) h2 = 0
        
        val min1 = h1 * 60 + m1
        val min2 = h2 * 60 + m2
        
        var diff = min1 - min2
        if (diff < -300) {
            diff += 720
        }
        return diff
    }

    fun parseTimeToMinutes(timeStr: String?): Int? {
        if (timeStr.isNullOrBlank()) return null
        val clean = timeStr.trim().lowercase(java.util.Locale.US)
        val parts = clean.split(":")
        if (parts.size < 2) return null

        var h = parts[0].filter { it.isDigit() }.toIntOrNull() ?: return null
        val m = parts[1].filter { it.isDigit() }.toIntOrNull() ?: 0

        val isPM = clean.contains("م") || clean.contains("pm")
        val isAM = clean.contains("ص") || clean.contains("am")

        if (isPM && h < 12) h += 12
        if (isAM && h == 12) h = 0

        return h * 60 + m
    }

    fun selectCourseForStudents(course: Course?) {
        _selectedCourseForStudents.value = course
    }

    fun addStudent() {
        val name = studentNameInput.value.trim()
        val phone = studentPhoneInput.value.trim()
        val course = _selectedCourseForStudents.value
        if (name.isEmpty() || course == null) return

        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val isActivated = sharedPrefs.getBoolean("is_activated", false)
        if (!isActivated && dbAllStudents.value.size >= 2) {
            Toast.makeText(
                getApplication(),
                "النسخة التجريبية تتيح لك إضافة طالبين فقط! يرجى تفعيل البرنامج لفتح جميع المزايا.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        viewModelScope.launch {
            val student = Student(
                name = name,
                courseId = course.id,
                courseName = course.name,
                phoneNumber = phone
            )
            val newStudentId = repository.insertStudent(student)
            logActivity(
                category = "STUDENTS",
                actionType = "CREATE",
                title = "تسجيل طالب جديد: $name",
                description = "الدورة: ${course.name} | رقم الهاتف: ${if (phone.isNotEmpty()) phone else "غير محدد"}",
                relatedId = course.id.toLong()
            )
            studentNameInput.value = ""
            studentPhoneInput.value = ""
        }
    }

    fun deleteStudent(student: Student) {
        viewModelScope.launch {
            repository.deleteStudent(student)
            logActivity(
                category = "STUDENTS",
                actionType = "DELETE",
                title = "حذف الطالب: ${student.name}",
                description = "الدورة: ${student.courseName}",
                relatedId = student.courseId.toLong()
            )
        }
    }

    fun updateStudentName(student: Student, newName: String) {
        viewModelScope.launch {
            repository.updateStudent(student.copy(name = newName))
            logActivity(
                category = "STUDENTS",
                actionType = "UPDATE",
                title = "تعديل اسم الطالب: $newName",
                description = "الاسم السابق: ${student.name} | الدورة: ${student.courseName}",
                relatedId = student.courseId.toLong()
            )
        }
    }

    fun updateStudentPhone(student: Student, newPhone: String) {
        viewModelScope.launch {
            repository.updateStudent(student.copy(phoneNumber = newPhone))
            logActivity(
                category = "STUDENTS",
                actionType = "UPDATE",
                title = "تحديث هاتف الطالب: ${student.name}",
                description = "الهاتف الجديد: $newPhone | الدورة: ${student.courseName}",
                relatedId = student.courseId.toLong()
            )
        }
    }

    fun updateStudentDetails(student: Student, newName: String, newPhone: String) {
        viewModelScope.launch {
            repository.updateStudent(student.copy(name = newName, phoneNumber = newPhone))
            logActivity(
                category = "STUDENTS",
                actionType = "UPDATE",
                title = "تعديل بيانات الطالب: $newName",
                description = "الهاتف: $newPhone | الدورة: ${student.courseName}",
                relatedId = student.courseId.toLong()
            )
        }
    }

    fun updateStudentStatus(student: Student, newStatus: String, changeDate: String = "") {
        viewModelScope.launch {
            repository.updateStudent(student.copy(status = newStatus, statusChangeDate = changeDate))
            logActivity(
                category = "STUDENTS",
                actionType = "UPDATE",
                title = "تحديث حالة الطالب: ${student.name}",
                description = "الحالة الجديدة: $newStatus",
                relatedId = student.courseId.toLong()
            )
        }
    }

    fun transferStudentToCourse(
        studentId: Int,
        newCourseId: Int,
        newCourseName: String,
        attendanceResetSubjects: Set<String> = emptySet(),
        gradesResetSubjects: Set<String> = emptySet()
    ) {
        viewModelScope.launch {
            val student = dbAllStudents.value.find { it.id == studentId }
            val oldCourseId = student?.courseId ?: 0
            val oldCourseName = student?.courseName ?: ""

            // 1. معالجة سجلات الحضور القديمة:
            val studentAttendanceList = dbAllStudentAttendance.value.filter {
                it.studentId == studentId && it.courseId == oldCourseId
            }
            studentAttendanceList.forEach { attRecord ->
                val subjKey = attRecord.subjectName.trim().ifEmpty { "عام" }
                if (attendanceResetSubjects.contains(subjKey)) {
                    // تصفير (حذف) حركة الحضور لهذه المادة
                    repository.deleteStudentAttendance(attRecord)
                }
                // الحركات التي لم يطلب تصفيرها تظل محفوظة في الدورة القديمة (معزولة) ولا تنقل للجديدة
            }

            // 2. معالجة سجلات الدرجات القديمة:
            val studentGradesList = dbAllGrades.value.filter {
                it.studentId == studentId && it.courseId == oldCourseId
            }
            studentGradesList.forEach { gradeRecord ->
                val subjKey = gradeRecord.subjectName.trim().ifEmpty { "عام" }
                if (gradesResetSubjects.contains(subjKey)) {
                    // تصفير (حذف) درجات هذه المادة
                    repository.deleteGrade(gradeRecord)
                }
                // الدرجات التي لم يطلب تصفيرها تظل محفوظة في الدورة القديمة
            }

            // 3. نقل بيانات الطالب الأساسية
            repository.transferStudent(studentId, newCourseId, newCourseName)

            if (student != null) {
                val detailsDesc = buildString {
                    append("تم نقل الطالب من دورة $oldCourseName إلى دورة $newCourseName.")
                    if (attendanceResetSubjects.isNotEmpty()) {
                        append(" تصفير حضور المواد: [${attendanceResetSubjects.joinToString(", ")}].")
                    }
                    if (gradesResetSubjects.isNotEmpty()) {
                        append(" تصفير درجات المواد: [${gradesResetSubjects.joinToString(", ")}].")
                    }
                }
                logActivity(
                    category = "STUDENTS",
                    actionType = "TRANSFER",
                    title = "نقل الطالب: ${student.name}",
                    description = detailsDesc,
                    relatedId = newCourseId.toLong()
                )
            }
        }
    }

    /**
     * استيراد ودمج درجات وسجلات حضور الطالب من دورة سابقة إلى دورته الحالية مع دعم معالجة التعارضات
     */
    fun importTransferredStudentGradesAndAttendance(
        studentId: Int,
        targetCourseId: Int,
        targetCourseName: String,
        subjectActions: Map<String, String>
    ) {
        viewModelScope.launch {
            val student = dbAllStudents.value.find { it.id == studentId } ?: return@launch
            
            // البحث عن سجلات الدرجات السابقة للطالب التي لا تنتمي للدورة الحالية
            val pastGrades = dbAllGrades.value.filter {
                it.studentId == studentId && it.courseId != targetCourseId && it.getTotalScore() > 0
            }
            
            var importedGradesCount = 0
            var mergedGradesCount = 0

            pastGrades.forEach { pastGrade ->
                val subjKey = pastGrade.subjectName.trim().ifEmpty { "عام" }
                val action = subjectActions[subjKey] ?: "SKIP"
                if (action == "SKIP") return@forEach

                // فحص إن كان هناك سجل حالي في الدورة المستهدفة
                val existingInTarget = dbAllGrades.value.find {
                    it.studentId == studentId && it.courseId == targetCourseId && it.subjectName.trim() == subjKey
                }

                when (action) {
                    "IMPORT", "OVERWRITE" -> {
                        val migratedGrade = if (existingInTarget != null) {
                            existingInTarget.copy(
                                attendanceScore = pastGrade.attendanceScore,
                                participationScore = pastGrade.participationScore,
                                assignmentsScore = pastGrade.assignmentsScore,
                                projectsScore = pastGrade.projectsScore,
                                theoreticalExamScore = pastGrade.theoreticalExamScore,
                                practicalExamScore = pastGrade.practicalExamScore,
                                customScoresJson = pastGrade.customScoresJson
                            )
                        } else {
                            pastGrade.copy(
                                id = 0,
                                courseId = targetCourseId,
                                courseName = targetCourseName
                            )
                        }
                        repository.insertGrade(migratedGrade)
                        importedGradesCount++
                    }
                    "MERGE" -> {
                        if (existingInTarget != null) {
                            val mergedAttendance = if (existingInTarget.attendanceScore > 0.0) existingInTarget.attendanceScore else pastGrade.attendanceScore
                            val mergedParticipation = if (existingInTarget.participationScore > 0.0) existingInTarget.participationScore else pastGrade.participationScore
                            val mergedAssignments = if (existingInTarget.assignmentsScore > 0.0) existingInTarget.assignmentsScore else pastGrade.assignmentsScore
                            val mergedProjects = if (existingInTarget.projectsScore > 0.0) existingInTarget.projectsScore else pastGrade.projectsScore
                            val mergedTheoretical = if (existingInTarget.theoreticalExamScore > 0.0) existingInTarget.theoreticalExamScore else pastGrade.theoreticalExamScore
                            val mergedPractical = if (existingInTarget.practicalExamScore > 0.0) existingInTarget.practicalExamScore else pastGrade.practicalExamScore

                            val mergedCustomScores = if (existingInTarget.customScoresJson.isNotEmpty() || pastGrade.customScoresJson.isNotEmpty()) {
                                val targetScores = com.example.data.entity.StudentGrade.deserializeScores(existingInTarget.customScoresJson)
                                val pastScores = com.example.data.entity.StudentGrade.deserializeScores(pastGrade.customScoresJson)
                                val combined = pastScores.toMutableMap()
                                targetScores.forEach { (k, v) ->
                                    if (v > 0.0) combined[k] = v
                                }
                                com.example.data.entity.StudentGrade.serializeScores(combined)
                            } else ""

                            val mergedGrade = existingInTarget.copy(
                                attendanceScore = mergedAttendance,
                                participationScore = mergedParticipation,
                                assignmentsScore = mergedAssignments,
                                projectsScore = mergedProjects,
                                theoreticalExamScore = mergedTheoretical,
                                practicalExamScore = mergedPractical,
                                customScoresJson = mergedCustomScores
                            )
                            repository.insertGrade(mergedGrade)
                            mergedGradesCount++
                        } else {
                            val migratedGrade = pastGrade.copy(
                                id = 0,
                                courseId = targetCourseId,
                                courseName = targetCourseName
                            )
                            repository.insertGrade(migratedGrade)
                            importedGradesCount++
                        }
                    }
                }
            }

            // البحث عن سجلات الحضور السابقة للطالب ونقل ما يخص المواد المحددة
            val pastAttendance = dbAllStudentAttendance.value.filter {
                it.studentId == studentId && it.courseId != targetCourseId
            }
            
            var importedAttendanceCount = 0
            pastAttendance.forEach { attRecord ->
                val subjKey = attRecord.subjectName.trim().ifEmpty { "عام" }
                val action = subjectActions[subjKey] ?: "SKIP"
                if (action != "SKIP") {
                    val alreadyRecorded = dbAllStudentAttendance.value.any {
                        it.studentId == studentId && it.courseId == targetCourseId && it.date == attRecord.date && it.subjectName.trim() == subjKey
                    }
                    if (!alreadyRecorded) {
                        val migratedAtt = attRecord.copy(
                            id = 0,
                            courseId = targetCourseId,
                            courseName = targetCourseName,
                            updatedAt = System.currentTimeMillis()
                        )
                        repository.insertStudentAttendance(migratedAtt)
                        importedAttendanceCount++
                    }
                }
            }

            logActivity(
                category = "GRADES",
                actionType = "IMPORT",
                title = "استيراد ودمج درجات الطالب: ${student.name}",
                description = "تم استيراد $importedGradesCount ودمج $mergedGradesCount مادة وحضور $importedAttendanceCount إلى دورة $targetCourseName",
                relatedId = targetCourseId.toLong()
            )

            withContext(Dispatchers.Main) {
                Toast.makeText(
                    getApplication(),
                    "تم استيراد ودمج درجات الطالب (${student.name}) بنجاح! 📥✅",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    /**
     * استيراد درجات وسجلات حضور الطالب من دورة سابقة إلى دورته الحالية لمواد محددة (أو كل المواد المشتركة)
     */
    fun importTransferredStudentGradesAndAttendance(
        studentId: Int,
        targetCourseId: Int,
        targetCourseName: String,
        selectedSubjectsToImport: Set<String>
    ) {
        val actions = selectedSubjectsToImport.associateWith { "IMPORT" }
        importTransferredStudentGradesAndAttendance(studentId, targetCourseId, targetCourseName, actions)
    }

    private fun canAddStudentAttendance(record: StudentAttendance): Boolean {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val isActivated = sharedPrefs.getBoolean("is_activated", false)
        if (isActivated) return true

        val exists = dbAllStudentAttendance.value.any { it.studentId == record.studentId && it.date == record.date }
        if (exists) return true

        if (dbAllStudentAttendance.value.size >= 5) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                Toast.makeText(
                    getApplication(),
                    "النسخة التجريبية تتيح لك رصد 5 حركات حضور وغياب للطلاب فقط! يرجى تفعيل البرنامج لفتح جميع المزايا.",
                    Toast.LENGTH_LONG
                ).show()
            }
            return false
        }
        return true
    }

    fun insertStudentAttendance(record: StudentAttendance) {
        val course = dbCourses.value.find { it.id == record.courseId }
        if (course != null) {
            val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            if (todayStr > course.endDate) {
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    Toast.makeText(
                        getApplication(),
                        "عذراً، لا يمكن تسجيل حركات حضور وغياب لأن الدورة التدريبية منتهية بالفعل! (انتهت في ${course.endDate})",
                        Toast.LENGTH_LONG
                    ).show()
                }
                return
            }
            if (record.date < course.startDate || record.date > course.endDate) {
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    Toast.makeText(
                        getApplication(),
                        "عذراً، لا يمكن تسجيل حركة خارج فترة الدورة التدريبية! (فترة الدورة من ${course.startDate} إلى ${course.endDate})",
                        Toast.LENGTH_LONG
                    ).show()
                }
                return
            }
        }
        if (!canAddStudentAttendance(record)) return
        val isAbsent = record.status == "غياب" || record.status == "غائب" || record.status == "إجازة"
        val recordWithSubject = (if (record.subjectName.isEmpty() && studentAttendanceSubjectInput.value.isNotEmpty()) {
            record.copy(subjectName = studentAttendanceSubjectInput.value)
        } else {
            record
        }).let {
            if (isAbsent) it.copy(participationStars = 0) else it
        }.copy(updatedAt = System.currentTimeMillis())
        viewModelScope.launch {
            val existing = dbAllStudentAttendance.value.find {
                it.studentId == record.studentId &&
                it.courseId == record.courseId &&
                it.date == record.date
            }
            val isUpdate = existing != null
            val actionType = if (isUpdate) "UPDATE" else "CREATE"
            val actionTitle = if (isUpdate) "تعديل حضور: ${record.studentName}" else "رصد حضور: ${record.studentName}"
            val desc = buildString {
                append("الحالة: ${record.status}")
                if (isUpdate && existing!!.status != record.status) {
                    append(" (السابقة: ${existing.status})")
                }
                append(" | المادة: ${recordWithSubject.subjectName.ifEmpty { "عام" }}")
                if (record.actualCheckIn.isNotEmpty()) append(" | دخول: ${record.actualCheckIn}")
                if (record.actualCheckOut.isNotEmpty()) append(" | خروج: ${record.actualCheckOut}")
            }

            repository.insertStudentAttendance(recordWithSubject)
            logActivity(
                category = "ATTENDANCE",
                actionType = actionType,
                title = actionTitle,
                description = desc,
                relatedId = record.courseId.toLong(),
                customDateStr = record.date
            )
        }
    }

    fun updateStudentParticipationStars(record: StudentAttendance, stars: Int) {
        if (record.status == "غياب" || record.status == "غائب" || record.status == "إجازة") {
            Toast.makeText(getApplication(), "نجوم المشاركة تكون صفر للطالب الغائب أو المجاز! ⚠️", Toast.LENGTH_SHORT).show()
            insertStudentAttendance(record.copy(participationStars = 0))
            return
        }
        val boundedStars = stars.coerceIn(0, 5)
        insertStudentAttendance(record.copy(participationStars = boundedStars))
    }

    private suspend fun insertStudentAttendanceDirectly(record: StudentAttendance) {
        val isAbsent = record.status == "غياب" || record.status == "غائب" || record.status == "إجازة"
        val recordWithSubject = (if (record.subjectName.isEmpty() && studentAttendanceSubjectInput.value.isNotEmpty()) {
            record.copy(subjectName = studentAttendanceSubjectInput.value)
        } else {
            record
        }).let {
            if (isAbsent) it.copy(participationStars = 0) else it
        }.copy(updatedAt = System.currentTimeMillis())
        repository.insertStudentAttendance(recordWithSubject)
    }

    private suspend fun insertStudentAttendancesDirectly(records: List<StudentAttendance>) {
        if (records.isEmpty()) return
        val finalRecords = records.map { record ->
            val isAbsent = record.status == "غياب" || record.status == "غائب" || record.status == "إجازة"
            (if (record.subjectName.isEmpty() && studentAttendanceSubjectInput.value.isNotEmpty()) {
                record.copy(subjectName = studentAttendanceSubjectInput.value)
            } else {
                record
            }).let {
                if (isAbsent) it.copy(participationStars = 0) else it
            }.copy(updatedAt = System.currentTimeMillis())
        }
        repository.insertStudentAttendances(finalRecords)
    }

    fun selectCourseForStudentAttendance(course: Course?) {
        _selectedCourseForStudentAttendance.value = course
        if (course != null) {
            _selectedCourseForAttendance.value = course
            if (course.startTime.isNotEmpty()) {
                studentAttendanceTimeInput.value = course.startTime
                studentCheckInTimeInput.value = course.startTime
            }
            updateStudentCheckOutDefaultTime(course, studentAttendanceDateInput.value)
            loadSavedSubjectName(course.id, studentAttendanceDateInput.value)
        }
    }

    fun setStudentAttendanceDate(dateStr: String) {
        studentAttendanceDateInput.value = dateStr
        studentAttendanceDayInput.value = getArabicDayOfWeek(dateStr)
        triggerWeekendWarningIfNeeded(dateStr)
        _selectedCourseForStudentAttendance.value?.let { course ->
            if (course.startTime.isNotEmpty()) {
                studentCheckInTimeInput.value = course.startTime
            }
            updateStudentCheckOutDefaultTime(course, dateStr)
            loadSavedSubjectName(course.id, dateStr)
        }
    }

    fun selectDiplomaForCourseForm(diplomaName: String) {
        courseDiplomaInput.value = diplomaName
        if (diplomaName.isNotEmpty()) {
            val diplomaSubjectIds = dbSubjects.value
                .filter { it.diplomaName.equals(diplomaName, ignoreCase = true) }
                .map { it.id }
                .toSet()
            if (diplomaSubjectIds.isNotEmpty()) {
                selectedCourseSubjectsInput.value = diplomaSubjectIds
            }
        }
    }

    fun loadSavedSubjectName(courseId: Int, date: String) {
        val sharedPrefs = getApplication<android.app.Application>().getSharedPreferences("dawami_prefs", android.app.Application.MODE_PRIVATE)
        // 1. If trainer already recorded a session for this course and date, prioritize its subject
        val trainerRecord = dbAttendance.value.find { it.courseId == courseId && it.date == date && it.subjectName.isNotEmpty() }
        var saved = trainerRecord?.subjectName ?: ""
        if (saved.isEmpty()) {
            saved = sharedPrefs.getString("subject_name_of_${courseId}_${date}", "") ?: ""
        }
        if (saved.isEmpty()) {
            saved = dbAllStudentAttendance.value.find { it.courseId == courseId && it.date == date && it.subjectName.isNotEmpty() }?.subjectName ?: ""
            if (saved.isEmpty()) {
                val defaultPrefSubject = sharedPrefs.getString("default_subject_of_${courseId}", "") ?: ""
                val courseCrossRefs = dbCourseSubjects.value.filter { it.courseId == courseId }
                val defaultRef = courseCrossRefs.find { cs ->
                    dbSubjects.value.find { it.id == cs.subjectId }?.name?.trim().equals(defaultPrefSubject.trim(), ignoreCase = true)
                }
                val isDefaultStillActive = defaultPrefSubject.isNotBlank() && (defaultRef == null || !defaultRef.status.contains("مكتمل"))

                if (isDefaultStillActive) {
                    saved = defaultPrefSubject
                } else {
                    // Fallback to first active subject
                    val course = activeCourses.value.find { it.id == courseId }
                    val validSubjects = dbSubjects.value.filter { sub ->
                        val ref = courseCrossRefs.find { it.subjectId == sub.id }
                        val status = ref?.status ?: "قيد التدريس"
                        val isLinked = sub.id in courseCrossRefs.map { it.subjectId } || (course?.diplomaName?.isNotEmpty() == true && sub.diplomaName.equals(course.diplomaName, ignoreCase = true))
                        isLinked && status != "مكتملة التدريس" && status != "مكتملة بالكامل" && status != "في انتظار الاختبار"
                    }
                    saved = validSubjects.firstOrNull()?.name ?: ""
                }
            }
            if (saved.isNotEmpty()) {
                sharedPrefs.edit().putString("subject_name_of_${courseId}_${date}", saved).apply()
            }
        }
        studentAttendanceSubjectInput.value = saved
    }

    fun updateStudentAttendanceSubject(subjectName: String) {
        studentAttendanceSubjectInput.value = subjectName
        val courseId = _selectedCourseForStudentAttendance.value?.id ?: _selectedCourseForAttendance.value?.id ?: return
        val date = studentAttendanceDateInput.value.ifBlank { attendanceDateInput.value }
        val sharedPrefs = getApplication<android.app.Application>().getSharedPreferences("dawami_prefs", android.app.Application.MODE_PRIVATE)
        sharedPrefs.edit().putString("subject_name_of_${courseId}_${date}", subjectName).apply()
        viewModelScope.launch {
            val toUpdate = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == date }
            toUpdate.forEach { record ->
                if (record.subjectName != subjectName) {
                    repository.insertStudentAttendance(record.copy(subjectName = subjectName))
                }
            }
            val trainerRecord = dbAttendance.value.find { it.courseId == courseId && it.date == date }
            if (trainerRecord != null) {
                if (trainerRecord.subjectName != subjectName) {
                    repository.insertAttendance(trainerRecord.copy(subjectName = subjectName))
                }
            }
        }
    }

    fun updateTeacherAttendanceSubject(subjectName: String) {
        studentAttendanceSubjectInput.value = subjectName
        val courseId = _selectedCourseForAttendance.value?.id ?: _selectedCourseForStudentAttendance.value?.id ?: return
        val date = attendanceDateInput.value.ifBlank { studentAttendanceDateInput.value }
        val sharedPrefs = getApplication<android.app.Application>().getSharedPreferences("dawami_prefs", android.app.Application.MODE_PRIVATE)
        sharedPrefs.edit().putString("subject_name_of_${courseId}_${date}", subjectName).apply()
        viewModelScope.launch {
            val toUpdate = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == date }
            toUpdate.forEach { record ->
                if (record.subjectName != subjectName) {
                    repository.insertStudentAttendance(record.copy(subjectName = subjectName))
                }
            }
            val trainerRecord = dbAttendance.value.find { it.courseId == courseId && it.date == date }
            if (trainerRecord != null) {
                if (trainerRecord.subjectName != subjectName) {
                    repository.insertAttendance(trainerRecord.copy(subjectName = subjectName))
                }
            }
        }
    }

    fun toggleStudentResearch(attendance: StudentAttendance, hasResearch: Boolean) {
        insertStudentAttendance(attendance.copy(hasResearch = hasResearch))
    }

    fun toggleStudentAssignment(attendance: StudentAttendance, hasAssignment: Boolean) {
        insertStudentAttendance(attendance.copy(hasAssignment = hasAssignment))
    }

    fun updateStudentCheckOutDefaultTime(course: Course, dateStr: String) {
        val teacherAttendance = dbAttendance.value.find { it.courseId == course.id && it.date == dateStr }
        if (teacherAttendance != null && teacherAttendance.actualCheckOut.isNotEmpty()) {
            studentCheckOutTimeInput.value = teacherAttendance.actualCheckOut
        } else {
            studentCheckOutTimeInput.value = course.endTime
        }
    }

    fun getStudentCheckOutTimeForDate(courseId: Int, dateStr: String): String? {
        val records = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == dateStr && it.actualCheckOut.isNotBlank() }
        if (records.isEmpty()) return null
        return records.groupBy { it.actualCheckOut }
            .maxByOrNull { it.value.size }?.key ?: records.first().actualCheckOut
    }

    fun getStudentCheckInTimeForDate(courseId: Int, dateStr: String): String? {
        val records = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == dateStr && it.actualCheckIn.isNotBlank() }
        if (records.isEmpty()) return null
        return records.groupBy { it.actualCheckIn }
            .maxByOrNull { it.value.size }?.key ?: records.first().actualCheckIn
    }

    fun getTrainerCheckOutTimeForDate(courseId: Int, dateStr: String): String? {
        val record = dbAttendance.value.find { it.courseId == courseId && it.date == dateStr && it.actualCheckOut.isNotBlank() }
        return record?.actualCheckOut
    }

    fun getTrainerCheckInTimeForDate(courseId: Int, dateStr: String): String? {
        val record = dbAttendance.value.find { it.courseId == courseId && it.date == dateStr && it.actualCheckIn.isNotBlank() }
        return record?.actualCheckIn
    }

    fun registerStudentCheckIn(attendance: StudentAttendance, checkInTime: String) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        val course = dbCourses.value.find { it.id == attendance.courseId } ?: return
        val delay = calculateMinutesDifference(checkInTime, course.startTime)
        val hasAlert = delay > 0
        val alertMsg = if (delay > 0) "تأخير دخول ($delay د)" else ""

        val record = attendance.copy(
            actualCheckIn = checkInTime,
            checkInDelayMinutes = if (delay > 0) delay else 0,
            hasAlert = hasAlert,
            alertMessage = alertMsg,
            status = "حضور"
        )
        insertStudentAttendance(record)
    }

    fun registerStudentCheckOut(attendance: StudentAttendance, checkOutTime: String): Boolean {
        if (attendance.status != "حضور" || attendance.actualCheckIn.isEmpty()) {
            Toast.makeText(getApplication(), "عذراً، لا يمكن تسجيل انصراف للطالب (${attendance.studentName}) لأنه لم يسجل دخولاً أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return false
        }
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return false
        }
        val course = dbCourses.value.find { it.id == attendance.courseId } ?: return false
        val delay = attendance.checkInDelayMinutes
        val checkOutDiff = calculateMinutesDifference(checkOutTime, course.endTime)
        val isEarly = checkOutDiff < 0
        val earlyMinutes = if (isEarly) -checkOutDiff else 0
        val hasAlert = delay > 0 || earlyMinutes > 0
        val alertMsg = buildString {
            if (delay > 0) append("تأخير دخول ($delay د) ")
            if (earlyMinutes > 0) append("انصراف مبكر ($earlyMinutes د) ")
        }.trim()

        val record = attendance.copy(
            actualCheckOut = checkOutTime,
            checkOutDifferenceMinutes = checkOutDiff,
            hasAlert = hasAlert,
            alertMessage = alertMsg
        )
        insertStudentAttendance(record)
        return true
    }

    fun registerStudentCheckOutIndividual(attendance: StudentAttendance, checkOutTime: String): Boolean {
        return registerStudentCheckOut(attendance, checkOutTime)
    }

    fun cancelStudentCheckOut(attendance: StudentAttendance) {
        val record = attendance.copy(
            actualCheckOut = "",
            checkOutDifferenceMinutes = 0,
            hasAlert = attendance.checkInDelayMinutes > 0,
            alertMessage = if (attendance.checkInDelayMinutes > 0) "تأخير دخول (${attendance.checkInDelayMinutes} د)" else ""
        )
        insertStudentAttendance(record)
    }

    fun registerStudentAbsent(attendance: StudentAttendance) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        val record = attendance.copy(
            actualCheckIn = "",
            actualCheckOut = "",
            checkInDelayMinutes = 0,
            checkOutDifferenceMinutes = 0,
            hasAlert = false,
            alertMessage = "",
            status = "غياب",
            participationStars = 0,
            isOnBreak = false,
            breakStartTime = "",
            breakDurationMinutes = 0,
            breakActualReturnTime = "",
            breakDelayMinutes = 0
        )
        insertStudentAttendance(record)
    }

    fun registerStudentLeave(attendance: StudentAttendance) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        val record = attendance.copy(
            actualCheckIn = "",
            actualCheckOut = "",
            checkInDelayMinutes = 0,
            checkOutDifferenceMinutes = 0,
            hasAlert = false,
            alertMessage = "",
            status = "إجازة",
            participationStars = 0,
            isOnBreak = false,
            breakStartTime = "",
            breakDurationMinutes = 0,
            breakActualReturnTime = "",
            breakDelayMinutes = 0
        )
        insertStudentAttendance(record)
    }

    fun registerStudentExcused(attendance: StudentAttendance) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        val record = attendance.copy(
            actualCheckIn = "",
            actualCheckOut = "",
            checkInDelayMinutes = 0,
            checkOutDifferenceMinutes = 0,
            hasAlert = false,
            alertMessage = "",
            status = "مستأذن",
            participationStars = 0,
            isOnBreak = false,
            breakStartTime = "",
            breakDurationMinutes = 0,
            breakActualReturnTime = "",
            breakDelayMinutes = 0
        )
        insertStudentAttendance(record)
    }

    fun addMinutesToTime(timeStr: String, minutesToAdd: Int): String {
        val clean = timeStr.trim().lowercase(java.util.Locale.US)
        val parts = clean.split(":")
        if (parts.size != 2) return timeStr
        var h = parts[0].filter { it.isDigit() }.toIntOrNull() ?: 0
        val m = parts[1].filter { it.isDigit() }.toIntOrNull() ?: 0
        
        val isPM = clean.contains("م") || clean.contains("pm")
        val isAM = clean.contains("ص") || clean.contains("am")
        if (isPM && h < 12) h += 12
        if (isAM && h == 12) h = 0
        
        var totalMinutes = h * 60 + m + minutesToAdd
        totalMinutes = (totalMinutes % 1440 + 1440) % 1440
        
        val finalH = totalMinutes / 60
        val finalM = totalMinutes % 60
        
        return String.format(java.util.Locale.US, "%02d:%02d", finalH, finalM)
    }

    fun registerStudentBreakStart(attendance: StudentAttendance, durationMinutes: Int, startTime: String): Boolean {
        if (attendance.status != "حضور" || attendance.actualCheckIn.isEmpty() || attendance.actualCheckOut.isNotEmpty()) {
            Toast.makeText(getApplication(), "عذراً، لا يمكن تسجيل خروج إلى الاستراحة للطالب (${attendance.studentName}) إلا إذا كان حاضراً حالياً ولم ينصرف بعد! ⚠️", Toast.LENGTH_LONG).show()
            return false
        }
        val record = attendance.copy(
            isOnBreak = true,
            breakStartTime = startTime,
            breakDurationMinutes = durationMinutes,
            breakActualReturnTime = "",
            breakDelayMinutes = 0
        )
        insertStudentAttendance(record)
        return true
    }

    fun registerStudentBreakEnd(attendance: StudentAttendance, returnTime: String): Boolean {
        if (attendance.status != "حضور" || !attendance.isOnBreak || attendance.breakStartTime.isEmpty()) {
            Toast.makeText(getApplication(), "عذراً، لا يمكن تسجيل عودة من الاستراحة للطالب (${attendance.studentName}) لأنه لم يسجل خروجاً إليها أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return false
        }
        val expectedReturn = if (attendance.breakStartTime.isNotEmpty() && attendance.breakDurationMinutes > 0) {
            addMinutesToTime(attendance.breakStartTime, attendance.breakDurationMinutes)
        } else {
            returnTime
        }
        val delay = calculateMinutesDifference(returnTime, expectedReturn)
        
        val record = attendance.copy(
            isOnBreak = false,
            breakActualReturnTime = returnTime,
            breakDelayMinutes = delay
        )
        insertStudentAttendance(record)
        return true
    }

    fun deleteStudentAttendanceRecord(attendance: StudentAttendance) {
        viewModelScope.launch {
            if (attendance.id != 0) {
                repository.deleteStudentAttendance(attendance)
            } else {
                val existing = dbAllStudentAttendance.value.find {
                    it.studentId == attendance.studentId &&
                    it.courseId == attendance.courseId &&
                    it.date == attendance.date
                }
                if (existing != null) {
                    repository.deleteStudentAttendance(existing)
                }
            }
            logActivity(
                category = "ATTENDANCE",
                actionType = "DELETE",
                title = "حذف سجل حضور: ${attendance.studentName}",
                description = "تم مسح وإعادة تعيين الحضور للطالب ${attendance.studentName}",
                relatedId = attendance.courseId.toLong(),
                customDateStr = attendance.date
            )
        }
    }

    fun updateStudentPrivateNote(attendance: StudentAttendance, noteText: String) {
        val record = attendance.copy(studentNote = noteText)
        insertStudentAttendance(record)
    }

    fun registerStudentCheckInBulk(attendances: List<StudentAttendance>, checkInTime: String) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val toInsert = mutableListOf<StudentAttendance>()
            attendances.forEach { attendance ->
                val course = dbCourses.value.find { it.id == attendance.courseId } ?: return@forEach
                val delay = calculateMinutesDifference(checkInTime, course.startTime)
                val hasAlert = delay > 0
                val alertMsg = if (delay > 0) "تأخير دخول ($delay د)" else ""
                val record = attendance.copy(
                    actualCheckIn = checkInTime,
                    checkInDelayMinutes = if (delay > 0) delay else 0,
                    hasAlert = hasAlert,
                    alertMessage = alertMsg,
                    status = "حضور"
                )
                toInsert.add(record)
            }
            if (toInsert.isNotEmpty()) {
                insertStudentAttendancesDirectly(toInsert)
            }
        }
    }

    fun registerStudentCheckOutIndividualBulk(attendances: List<StudentAttendance>, checkOutTime: String) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val toInsert = mutableListOf<StudentAttendance>()
            attendances.forEach { attendance ->
                if (attendance.status == "حضور" && attendance.actualCheckIn.isNotEmpty()) {
                    val course = dbCourses.value.find { it.id == attendance.courseId } ?: return@forEach
                    val delay = attendance.checkInDelayMinutes
                    val checkOutDiff = calculateMinutesDifference(checkOutTime, course.endTime)
                    val isEarly = checkOutDiff < 0
                    val earlyMinutes = if (isEarly) -checkOutDiff else 0
                    val hasAlert = delay > 0 || earlyMinutes > 0
                    val alertMsg = buildString {
                        if (delay > 0) append("تأخير دخول ($delay د) ")
                        if (earlyMinutes > 0) append("انصراف مبكر ($earlyMinutes د) ")
                    }.trim()
                    val record = attendance.copy(
                        actualCheckOut = checkOutTime,
                        checkOutDifferenceMinutes = checkOutDiff,
                        hasAlert = hasAlert,
                        alertMessage = alertMsg
                    )
                    toInsert.add(record)
                }
            }
            if (toInsert.isNotEmpty()) {
                insertStudentAttendancesDirectly(toInsert)
            }
        }
    }

    fun registerStudentPerfectAttendanceBulk(attendances: List<StudentAttendance>, checkOutTime: String? = null) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val toInsert = mutableListOf<StudentAttendance>()
            attendances.forEach { attendance ->
                val course = dbCourses.value.find { it.id == attendance.courseId } ?: return@forEach
                val actualOut = checkOutTime ?: course.endTime
                val record = attendance.copy(
                    actualCheckIn = course.startTime,
                    actualCheckOut = actualOut,
                    checkInDelayMinutes = 0,
                    checkOutDifferenceMinutes = 0,
                    hasAlert = false,
                    alertMessage = "",
                    status = "حضور"
                )
                toInsert.add(record)
            }
            if (toInsert.isNotEmpty()) {
                insertStudentAttendancesDirectly(toInsert)
            }
        }
    }

    fun cancelStudentCheckOutBulk(attendances: List<StudentAttendance>) {
        viewModelScope.launch(Dispatchers.IO) {
            val toInsert = mutableListOf<StudentAttendance>()
            attendances.forEach { attendance ->
                val record = attendance.copy(
                    actualCheckOut = "",
                    checkOutDifferenceMinutes = 0,
                    hasAlert = attendance.checkInDelayMinutes > 0,
                    alertMessage = if (attendance.checkInDelayMinutes > 0) "تأخير دخول (${attendance.checkInDelayMinutes} د)" else ""
                )
                toInsert.add(record)
            }
            if (toInsert.isNotEmpty()) {
                insertStudentAttendancesDirectly(toInsert)
            }
        }
    }

    fun registerStudentAbsentBulk(attendances: List<StudentAttendance>) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val toInsert = mutableListOf<StudentAttendance>()
            attendances.forEach { attendance ->
                val record = attendance.copy(
                    actualCheckIn = "",
                    actualCheckOut = "",
                    checkInDelayMinutes = 0,
                    checkOutDifferenceMinutes = 0,
                    hasAlert = false,
                    alertMessage = "",
                    status = "غياب",
                    participationStars = 0,
                    isOnBreak = false,
                    breakStartTime = "",
                    breakDurationMinutes = 0,
                    breakActualReturnTime = "",
                    breakDelayMinutes = 0
                )
                toInsert.add(record)
            }
            if (toInsert.isNotEmpty()) {
                insertStudentAttendancesDirectly(toInsert)
            }
        }
    }

    fun registerStudentLeaveBulk(attendances: List<StudentAttendance>) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val toInsert = mutableListOf<StudentAttendance>()
            attendances.forEach { attendance ->
                val record = attendance.copy(
                    actualCheckIn = "",
                    actualCheckOut = "",
                    checkInDelayMinutes = 0,
                    checkOutDifferenceMinutes = 0,
                    hasAlert = false,
                    alertMessage = "",
                    status = "إجازة",
                    participationStars = 0,
                    isOnBreak = false,
                    breakStartTime = "",
                    breakDurationMinutes = 0,
                    breakActualReturnTime = "",
                    breakDelayMinutes = 0
                )
                toInsert.add(record)
            }
            if (toInsert.isNotEmpty()) {
                insertStudentAttendancesDirectly(toInsert)
            }
        }
    }

    fun registerStudentExcusedBulk(attendances: List<StudentAttendance>) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val toInsert = mutableListOf<StudentAttendance>()
            attendances.forEach { attendance ->
                val record = attendance.copy(
                    actualCheckIn = "",
                    actualCheckOut = "",
                    checkInDelayMinutes = 0,
                    checkOutDifferenceMinutes = 0,
                    hasAlert = false,
                    alertMessage = "",
                    status = "مستأذن",
                    participationStars = 0,
                    isOnBreak = false,
                    breakStartTime = "",
                    breakDurationMinutes = 0,
                    breakActualReturnTime = "",
                    breakDelayMinutes = 0
                )
                toInsert.add(record)
            }
            if (toInsert.isNotEmpty()) {
                insertStudentAttendancesDirectly(toInsert)
            }
        }
    }

    fun deleteStudentAttendanceRecordBulk(attendances: List<StudentAttendance>) {
        viewModelScope.launch(Dispatchers.IO) {
            val toDelete = mutableListOf<StudentAttendance>()
            attendances.forEach { attendance ->
                if (attendance.id != 0) {
                    toDelete.add(attendance)
                } else {
                    val existing = dbAllStudentAttendance.value.find {
                        it.studentId == attendance.studentId &&
                        it.courseId == attendance.courseId &&
                        it.date == attendance.date
                    }
                    if (existing != null) {
                        toDelete.add(existing)
                    }
                }
            }
            if (toDelete.isNotEmpty()) {
                repository.deleteStudentAttendances(toDelete)
            }
        }
    }

    fun registerUnifiedCheckIn(checkInTime: String) {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        val currentList = studentAttendanceList.value
        val courseId = _selectedCourseForStudentAttendance.value?.id ?: return
        val course = dbCourses.value.find { it.id == courseId } ?: return
        val dateStr = studentAttendanceDateInput.value

        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        if (todayStr > course.endDate) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                Toast.makeText(
                    getApplication(),
                    "عذراً، لا يمكن تسجيل حركات حضور وغياب لأن الدورة التدريبية منتهية بالفعل! (انتهت في ${course.endDate})",
                    Toast.LENGTH_LONG
                ).show()
            }
            return
        }

        if (dateStr < course.startDate || dateStr > course.endDate) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                Toast.makeText(
                    getApplication(),
                    "عذراً، لا يمكن تسجيل حركة خارج فترة الدورة التدريبية! (فترة الدورة من ${course.startDate} إلى ${course.endDate})",
                    Toast.LENGTH_LONG
                ).show()
            }
            return
        }

        viewModelScope.launch {
            currentList.forEach { attendance ->
                if (attendance.status == "لم يسجل") {
                    val delay = calculateMinutesDifference(checkInTime, course.startTime)
                    val hasAlert = delay > 0
                    val alertMsg = if (delay > 0) "تأخير دخول ($delay د)" else ""

                    val record = attendance.copy(
                        actualCheckIn = checkInTime,
                        checkInDelayMinutes = if (delay > 0) delay else 0,
                        hasAlert = hasAlert,
                        alertMessage = alertMsg,
                        status = "حضور"
                    )
                    if (canAddStudentAttendance(record)) {
                        insertStudentAttendanceDirectly(record)
                    }
                }
            }
        }
    }

    fun registerUnifiedCheckOut(checkOutTime: String, markUnrecordedAsAbsent: Boolean = true): Pair<Int, List<String>> {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return Pair(0, emptyList())
        }
        val currentList = studentAttendanceList.value
        val courseId = _selectedCourseForStudentAttendance.value?.id ?: return Pair(0, emptyList())
        val course = dbCourses.value.find { it.id == courseId } ?: return Pair(0, emptyList())
        val dateStr = studentAttendanceDateInput.value
        val dayName = studentAttendanceDayInput.value
        val currentSubject = studentAttendanceSubjectInput.value

        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        if (todayStr > course.endDate) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                Toast.makeText(
                    getApplication(),
                    "عذراً، لا يمكن تسجيل حركات حضور وغياب لأن الدورة التدريبية منتهية بالفعل! (انتهت في ${course.endDate})",
                    Toast.LENGTH_LONG
                ).show()
            }
            return Pair(0, emptyList())
        }

        if (dateStr < course.startDate || dateStr > course.endDate) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                Toast.makeText(
                    getApplication(),
                    "عذراً، لا يمكن تسجيل حركة خارج فترة الدورة التدريبية! (فترة الدورة من ${course.startDate} إلى ${course.endDate})",
                    Toast.LENGTH_LONG
                ).show()
            }
            return Pair(0, emptyList())
        }

        var checkedOutCount = 0
        val absentStudentNames = mutableListOf<String>()

        viewModelScope.launch {
            currentList.forEach { attendance ->
                val finalSubject = if (attendance.subjectName.isNotEmpty()) attendance.subjectName else currentSubject
                if (attendance.status == "حضور" && attendance.actualCheckIn.isNotEmpty() && attendance.actualCheckOut.isEmpty()) {
                    val checkOutDiff = calculateMinutesDifference(checkOutTime, course.endTime)
                    val isEarly = checkOutDiff < 0
                    val earlyMinutes = if (isEarly) -checkOutDiff else 0

                    val delay = attendance.checkInDelayMinutes
                    val hasAlert = delay > 0 || earlyMinutes > 0
                    val alertMsg = buildString {
                        if (delay > 0) append("تأخير دخول ($delay د) ")
                        if (earlyMinutes > 0) append("انصراف مبكر ($earlyMinutes د) ")
                    }.trim()

                    val record = attendance.copy(
                        actualCheckOut = checkOutTime,
                        checkOutDifferenceMinutes = checkOutDiff,
                        hasAlert = hasAlert,
                        alertMessage = alertMsg,
                        subjectName = finalSubject
                    )
                    insertStudentAttendanceDirectly(record)
                    checkedOutCount++
                    logActivity("تعديل", "حضور طالب", attendance.studentName, "انصراف جماعي للطالب (${attendance.studentName}) الساعة $checkOutTime")
                } else if (markUnrecordedAsAbsent && attendance.status == "لم يسجل") {
                    val studentObj = dbAllStudents.value.find { it.id == attendance.studentId }
                    val isStudentActive = studentObj == null || studentObj.status == "مستمر" || studentObj.status.isEmpty()
                    if (isStudentActive) {
                        val record = attendance.copy(
                            actualCheckIn = "",
                            actualCheckOut = "",
                            checkInDelayMinutes = 0,
                            checkOutDifferenceMinutes = 0,
                            hasAlert = false,
                            alertMessage = "",
                            status = "غياب",
                            participationStars = 0,
                            isOnBreak = false,
                            subjectName = finalSubject
                        )
                        insertStudentAttendanceDirectly(record)
                        absentStudentNames.add(attendance.studentName)
                        logActivity("إضافة", "حضور طالب", attendance.studentName, "اعتماد غياب تلقائي للطالب (${attendance.studentName}) أثناء الانصراف الجماعي لعدم تسجيل حضور مسبق")
                    }
                }
            }
        }

        val unrecordedList = if (markUnrecordedAsAbsent) {
            currentList.filter { att ->
                att.status == "لم يسجل" && (dbAllStudents.value.find { it.id == att.studentId }?.let { it.status == "مستمر" || it.status.isEmpty() } ?: true)
            }.map { it.studentName }
        } else emptyList()
        val checkedOutTargets = currentList.count { it.status == "حضور" && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() }
        return Pair(checkedOutTargets, unrecordedList)
    }

    fun registerUnifiedLeave() {
        if (studentAttendanceSubjectInput.value.trim().isEmpty()) {
            Toast.makeText(getApplication(), "الرجاء تحديد المادة التدريسية أولاً! ⚠️", Toast.LENGTH_LONG).show()
            return
        }
        val currentList = studentAttendanceList.value
        val courseId = _selectedCourseForStudentAttendance.value?.id ?: return
        val course = dbCourses.value.find { it.id == courseId } ?: return
        val dayName = studentAttendanceDayInput.value
        val dateStr = studentAttendanceDateInput.value
        val currentDailyNote = dbAllDailyNotes.value.find { it.courseId == courseId && it.date == dateStr }?.note ?: ""

        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        if (todayStr > course.endDate) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                Toast.makeText(
                    getApplication(),
                    "عذراً، لا يمكن تسجيل حركات حضور وغياب لأن الدورة التدريبية منتهية بالفعل! (انتهت في ${course.endDate})",
                    Toast.LENGTH_LONG
                ).show()
            }
            return
        }

        if (dateStr < course.startDate || dateStr > course.endDate) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                Toast.makeText(
                    getApplication(),
                    "عذراً، لا يمكن تسجيل حركة خارج فترة الدورة التدريبية! (فترة الدورة من ${course.startDate} إلى ${course.endDate})",
                    Toast.LENGTH_LONG
                ).show()
            }
            return
        }

        viewModelScope.launch {
            currentList.forEach { attendance ->
                if (attendance.status == "لم يسجل") {
                    val record = attendance.copy(
                        actualCheckIn = "",
                        actualCheckOut = "",
                        checkInDelayMinutes = 0,
                        checkOutDifferenceMinutes = 0,
                        hasAlert = false,
                        alertMessage = "",
                        status = "إجازة",
                        dayOfWeek = dayName,
                        courseDailyNote = currentDailyNote
                    )
                    if (canAddStudentAttendance(record)) {
                        insertStudentAttendanceDirectly(record)
                    }
                }
            }
        }
    }

    fun resetIndividualAttendanceOnly(record: StudentAttendance) {
        viewModelScope.launch {
            if (record.actualCheckOut.isEmpty() && record.status != "غياب" && record.status != "إجازة") {
                repository.deleteStudentAttendance(record)
            } else {
                val updated = record.copy(
                    actualCheckIn = "",
                    checkInDelayMinutes = 0,
                    status = if (record.actualCheckOut.isNotEmpty()) "حضور" else "لم يسجل",
                    hasAlert = false,
                    alertMessage = ""
                )
                repository.insertStudentAttendance(updated)
            }
            logActivity(
                category = "ATTENDANCE",
                actionType = "RESET",
                title = "إعادة تعيين حضور طالب: ${record.studentName}",
                description = "تم مسح وقت الحضور والتأخير مع الحفاظ على الانصراف والتقييمات | التاريخ: ${record.date}",
                relatedId = record.courseId.toLong(),
                customDateStr = record.date
            )
        }
    }

    fun resetIndividualDepartureOnly(record: StudentAttendance) {
        viewModelScope.launch {
            if (record.actualCheckIn.isEmpty() && record.status != "غياب" && record.status != "إجازة") {
                repository.deleteStudentAttendance(record)
            } else {
                val updated = record.copy(
                    actualCheckOut = "",
                    checkOutDifferenceMinutes = 0
                )
                repository.insertStudentAttendance(updated)
            }
            logActivity(
                category = "ATTENDANCE",
                actionType = "RESET",
                title = "إعادة تعيين انصراف طالب: ${record.studentName}",
                description = "تم مسح وقت وفارق الانصراف مع الحفاظ على حضور وتقييم الطالب | التاريخ: ${record.date}",
                relatedId = record.courseId.toLong(),
                customDateStr = record.date
            )
        }
    }

    fun resetIndividualAll(record: StudentAttendance) {
        viewModelScope.launch {
            repository.deleteStudentAttendance(record)
            logActivity(
                category = "ATTENDANCE",
                actionType = "RESET",
                title = "تصفير وإعادة تعيين كامل لطالب: ${record.studentName}",
                description = "تم تصفير وحذف سجل حضور وانصراف الطالب بالكامل لهذا اليوم | التاريخ: ${record.date}",
                relatedId = record.courseId.toLong(),
                customDateStr = record.date
            )
        }
    }

    fun resetUnifiedAttendanceOnly(targetStudentIds: Set<Int>? = null) {
        val courseId = _selectedCourseForStudentAttendance.value?.id ?: return
        val courseName = _selectedCourseForStudentAttendance.value?.name ?: ""
        val dateStr = studentAttendanceDateInput.value
        viewModelScope.launch(Dispatchers.IO) {
            val list = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == dateStr }
            val targets = if (targetStudentIds != null) list.filter { it.studentId in targetStudentIds } else list
            
            val toDelete = mutableListOf<StudentAttendance>()
            val toUpdate = mutableListOf<StudentAttendance>()
            
            targets.forEach { record ->
                if (record.actualCheckOut.isEmpty() && record.status != "غياب" && record.status != "إجازة") {
                    toDelete.add(record)
                } else {
                    val updated = record.copy(
                        actualCheckIn = "",
                        checkInDelayMinutes = 0,
                        status = if (record.actualCheckOut.isNotEmpty()) "حضور" else "لم يسجل",
                        hasAlert = false,
                        alertMessage = ""
                    )
                    toUpdate.add(updated)
                }
            }
            
            if (toDelete.isNotEmpty()) repository.deleteStudentAttendances(toDelete)
            if (toUpdate.isNotEmpty()) repository.insertStudentAttendances(toUpdate)

            val isBatch = targetStudentIds != null
            val studentCount = targets.size
            logActivity(
                category = "ATTENDANCE",
                actionType = "RESET",
                title = if (isBatch) "إعادة تعيين الحضور لطلاب محددين ⚠️" else "إعادة تعيين الحضور لكافة الطلاب 🔄",
                description = if (isBatch) {
                    "تم إعادة تعيين الحضور لعدد ($studentCount) طلاب محددين في دورة ($courseName) بتاريخ $dateStr"
                } else {
                    "تم إعادة تعيين الحضور لكافة طلاب دورة ($courseName) بتاريخ $dateStr"
                },
                relatedId = courseId.toLong(),
                customDateStr = dateStr
            )
        }
    }

    fun resetUnifiedDepartureOnly(targetStudentIds: Set<Int>? = null) {
        val courseId = _selectedCourseForStudentAttendance.value?.id ?: return
        val courseName = _selectedCourseForStudentAttendance.value?.name ?: ""
        val dateStr = studentAttendanceDateInput.value
        viewModelScope.launch(Dispatchers.IO) {
            val list = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == dateStr }
            val targets = if (targetStudentIds != null) list.filter { it.studentId in targetStudentIds } else list
            
            val toDelete = mutableListOf<StudentAttendance>()
            val toUpdate = mutableListOf<StudentAttendance>()
            
            targets.forEach { record ->
                if (record.actualCheckIn.isEmpty() && record.status != "غياب" && record.status != "إجازة") {
                    toDelete.add(record)
                } else {
                    val updated = record.copy(
                        actualCheckOut = "",
                        checkOutDifferenceMinutes = 0
                    )
                    toUpdate.add(updated)
                }
            }
            
            if (toDelete.isNotEmpty()) repository.deleteStudentAttendances(toDelete)
            if (toUpdate.isNotEmpty()) repository.insertStudentAttendances(toUpdate)

            val isBatch = targetStudentIds != null
            val studentCount = targets.size
            logActivity(
                category = "ATTENDANCE",
                actionType = "RESET",
                title = if (isBatch) "إعادة تعيين الانصراف لطلاب محددين ⚠️" else "إعادة تعيين الانصراف لكافة الطلاب 🔄",
                description = if (isBatch) {
                    "تم إعادة تعيين الانصراف لعدد ($studentCount) طلاب محددين في دورة ($courseName) بتاريخ $dateStr"
                } else {
                    "تم إعادة تعيين الانصراف لكافة طلاب دورة ($courseName) بتاريخ $dateStr"
                },
                relatedId = courseId.toLong(),
                customDateStr = dateStr
            )
        }
    }

    fun resetUnifiedAll(targetStudentIds: Set<Int>? = null) {
        val courseId = _selectedCourseForStudentAttendance.value?.id ?: return
        val courseName = _selectedCourseForStudentAttendance.value?.name ?: ""
        val dateStr = studentAttendanceDateInput.value
        viewModelScope.launch(Dispatchers.IO) {
            val list = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == dateStr }
            val targets = if (targetStudentIds != null) list.filter { it.studentId in targetStudentIds } else list
            
            if (targets.isNotEmpty()) {
                repository.deleteStudentAttendances(targets)
            }
            
            val isBatch = targetStudentIds != null
            val studentCount = targets.size
            logActivity(
                category = "ATTENDANCE",
                actionType = "RESET",
                title = if (isBatch) "تصفير كامل لطلاب محددين 🔴" else "تصفير كامل لجميع الطلاب 🔴",
                description = if (isBatch) {
                    "تم تصفير وحذف سجل الحضور والانصراف بالكامل لعدد ($studentCount) طلاب محددين في دورة ($courseName) بتاريخ $dateStr"
                } else {
                    "تم تصفير وإعادة تعيين حضور دورة ($courseName) بالكامل لجميع الطلاب بتاريخ $dateStr"
                },
                relatedId = courseId.toLong(),
                customDateStr = dateStr
            )
        }
    }

    fun resetUnifiedAttendance() {
        resetUnifiedAll()
    }

    fun autoRegisterStudentStatusForCourseAndDate(courseId: Int, dateStr: String, dayName: String, status: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val course = dbCourses.value.find { it.id == courseId } ?: return@launch
            val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            if (todayStr > course.endDate || dateStr < course.startDate || dateStr > course.endDate) {
                return@launch
            }

            val students = dbAllStudents.value.filter { it.courseId == courseId && (it.status == "مستمر" || it.status.isEmpty()) }
            val existingAttendances = dbAllStudentAttendance.value.filter { it.courseId == courseId && it.date == dateStr }
            val currentDailyNote = dbAllDailyNotes.value.find { it.courseId == courseId && it.date == dateStr }?.note ?: ""

            val toInsert = mutableListOf<StudentAttendance>()
            students.forEach { student ->
                val existing = existingAttendances.find { it.studentId == student.id }
                val record = (existing ?: StudentAttendance(
                    studentId = student.id,
                    studentName = student.name,
                    courseId = courseId,
                    courseName = student.courseName,
                    date = dateStr,
                    dayOfWeek = dayName,
                    status = status,
                    actualCheckIn = "",
                    actualCheckOut = "",
                    studentNote = "",
                    courseDailyNote = currentDailyNote
                )).copy(
                    status = status,
                    actualCheckIn = "",
                    actualCheckOut = ""
                )
                if (canAddStudentAttendance(record)) {
                    toInsert.add(record)
                }
            }
            if (toInsert.isNotEmpty()) {
                insertStudentAttendancesDirectly(toInsert)
            }
        }
    }

    fun saveDailyCourseNote() {
        val course = _selectedCourseForStudentAttendance.value ?: return
        val date = studentAttendanceDateInput.value
        if (date.isEmpty()) return
        val noteText = dailyCourseNoteInput.value

        viewModelScope.launch {
            val existing = repository.getDailyNoteForCourseAndDateSync(course.id, date)
            if (existing != null) {
                if (noteText.trim().isEmpty()) {
                    repository.deleteDailyNote(existing)
                } else {
                    repository.updateDailyNote(existing.copy(note = noteText))
                }
            } else {
                if (noteText.trim().isNotEmpty()) {
                    repository.insertDailyNote(
                        DailyCourseNote(
                            courseId = course.id,
                            date = date,
                            note = noteText
                        )
                    )
                }
            }

            val dbRecords = dbAllStudentAttendance.value.filter { it.courseId == course.id && it.date == date }
            dbRecords.forEach { record ->
                insertStudentAttendanceDirectly(record.copy(courseDailyNote = noteText))
            }
        }
    }

    fun setStudentReportCourseFilter(courseName: String) {
        _selectedStudentCourseReportFilter.value = courseName
        generateStudentReports()
    }

    fun setStudentReportDateFrom(date: String) {
        _studentReportDateFromFilter.value = date
        generateStudentReports()
    }

    fun setStudentReportDateTo(date: String) {
        _studentReportDateToFilter.value = date
        generateStudentReports()
    }

    fun setStudentReportStatusFilter(status: String) {
        _selectedStudentStatusReportFilter.value = status
        generateStudentReports()
    }

    fun setStudentReportSubjectFilter(subject: String) {
        _selectedStudentSubjectReportFilter.value = subject
        generateStudentReports()
    }

    private var studentReportJob: Job? = null

    fun generateStudentReports() {
        studentReportJob?.cancel()
        studentReportJob = viewModelScope.launch(Dispatchers.Default) {
            val courseFilter = _selectedStudentCourseReportFilter.value
            val dateFrom = _studentReportDateFromFilter.value
            val dateTo = _studentReportDateToFilter.value
            val statusFilter = _selectedStudentStatusReportFilter.value
            val subjectFilter = _selectedStudentSubjectReportFilter.value
            val nameQuery = studentReportNameQuery.value.trim()
            val records = dbAllStudentAttendance.value
            val teacherAttendance = dbAttendance.value
            
            if (records.isEmpty()) {
                _studentAttendanceReports.value = emptyList()
                _studentGroupedReports.value = emptyMap()
                return@launch
            }

            val isCourseAll = courseFilter.isEmpty() || courseFilter == "الكل" || courseFilter == "جميع الدورات التدريبية"
            val isSubjectAll = subjectFilter.isEmpty() || subjectFilter == "الكل" || subjectFilter == "جميع المواد"
            val isStatusAll = statusFilter.isEmpty() || statusFilter == "الكل"
            val isNameAll = nameQuery.isEmpty() || nameQuery == "الكل" || nameQuery == "جميع الطلاب"

            val dateFromStd = if (dateFrom.isNotBlank()) standardizeDate(dateFrom) else ""
            val dateToStd = if (dateTo.isNotBlank()) standardizeDate(dateTo) else ""
            
            // Caching teacher dates to easily identify valid (non-ghost) student records
            val teacherDatesByCourse = teacherAttendance.groupBy { it.courseId }.mapValues { entry -> entry.value.map { it.date }.toSet() }

            val filtered = records.filter { record ->
                val validDatesForCourse = teacherDatesByCourse[record.courseId] ?: emptySet()
                if (validDatesForCourse.isNotEmpty() && !validDatesForCourse.contains(record.date)) {
                    return@filter false
                }
                
                val matchCourse = isCourseAll || record.courseName == courseFilter
                val matchSubject = isSubjectAll || record.subjectName.trim().equals(subjectFilter.trim(), ignoreCase = true)
                
                val recordDateStd = if (dateFromStd.isNotEmpty() || dateToStd.isNotEmpty()) standardizeDate(record.date) else ""
                val matchFrom = dateFromStd.isEmpty() || recordDateStd >= dateFromStd
                val matchTo = dateToStd.isEmpty() || recordDateStd <= dateToStd
                
                val matchStatus = isStatusAll || record.status == statusFilter
                val matchName = isNameAll || record.studentName.contains(nameQuery, ignoreCase = true)

                matchCourse && matchSubject && matchFrom && matchTo && matchStatus && matchName
            }

            val sorted = filtered.sortedWith(compareByDescending<StudentAttendance> { it.date }.thenBy { it.studentName })

            val grouped = when (_studentReportGroupingMode.value) {
                "الطالب" -> sorted.groupBy { it.studentName }
                "التاريخ" -> sorted.groupBy { it.date }
                "الحالة" -> sorted.groupBy { it.status }
                "المادة" -> sorted.groupBy { if (it.subjectName.isNotEmpty()) it.subjectName else "بدون مادة" }
                "الدورة" -> sorted.groupBy { it.courseName.ifEmpty { "غير محددة" } }
                else -> sorted.groupBy { it.date }
            }
            
            _studentAttendanceReports.value = sorted
            _studentGroupedReports.value = grouped
        }
    }

    fun autoSyncGradesFromAttendanceAndAssignments(courseId: Int) {
        viewModelScope.launch {
            val course = dbCourses.value.find { it.id == courseId } ?: return@launch
            var currentConfig = dbAllGradeConfigs.value.find { it.courseId == courseId }
            if (currentConfig != null) {
                if (currentConfig.isDiploma && course.diplomaName.isNotEmpty()) {
                    val dipTemplateId = StudentGradeConfig.getDiplomaTemplateId(course.diplomaName)
                    val template = dbAllGradeConfigs.value.find { it.courseId == dipTemplateId }
                    if (template != null && template.subjectWeightsJson.isNotEmpty()) {
                        currentConfig = currentConfig.copy(subjectWeightsJson = template.subjectWeightsJson)
                    }
                }
            } else if (course.diplomaName.isNotEmpty()) {
                val dipTemplateId = StudentGradeConfig.getDiplomaTemplateId(course.diplomaName)
                val template = dbAllGradeConfigs.value.find { it.courseId == dipTemplateId }
                if (template != null) {
                    currentConfig = template.copy(courseId = course.id, courseName = course.name)
                } else {
                    val siblingCourseIds = dbCourses.value.filter { it.diplomaName == course.diplomaName && it.id != course.id }.map { it.id }
                    val siblingConfig = dbAllGradeConfigs.value.find { it.courseId in siblingCourseIds }
                    if (siblingConfig != null) {
                        currentConfig = siblingConfig.copy(courseId = course.id, courseName = course.name)
                    }
                }
            }
            if (currentConfig == null) return@launch

            val students = dbAllStudents.value.filter { it.courseId == courseId }
            val grades = dbAllGrades.value.filter { it.courseId == courseId }
            val attendanceRecords = dbAllStudentAttendance.value
            val submissions = repository.getSubmissionsForCourseDirect(courseId)
            val templates = dbAssignmentTemplates.value

            val allConfigFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson ?: "")
            val rawSubjects = if (currentConfig.isDiploma) {
                currentConfig.getDiplomaSubjects()
            } else {
                allConfigFields.map { it.first.substringBefore("_") }.distinct()
            }
            val subjects = StudentGradeConfig.sortSubjectsList(rawSubjects)
            val courseSubjectStats = getCourseSubjectStats(courseId)

            students.forEach { student ->
                subjects.forEach { subject ->
                    val stat = courseSubjectStats.find { it.subjectName.trim().equals(subject.trim(), ignoreCase = true) }
                    val taughtDaysCount = stat?.taughtDaysCount ?: -1

                    val courseMode = getCourseGradingMode(courseId)
                    val existingGradeRecord = grades.find { it.studentId == student.id && it.subjectName == subject }
                    if (existingGradeRecord != null && existingGradeRecord.isManualGrading() && courseMode != "AUTO") {
                        // Skip auto-sync calculation for manually recorded and protected student grade ONLY if course is in MANUAL mode
                        return@forEach
                    }
                    val subjectFields = if (currentConfig.isDiploma) {
                        val specific = allConfigFields.filter { it.first.startsWith("${subject}_") }
                            .map { Pair(it.first.substringAfter("${subject}_"), it.second) }
                        if (specific.isNotEmpty()) {
                            specific
                        } else {
                            val plain = allConfigFields.filter { !it.first.contains("_") }
                            if (plain.isNotEmpty()) {
                                plain
                            } else {
                                listOf(
                                    Pair("حضور", 5),
                                    Pair("مشاركة", 5),
                                    Pair("تكاليف", 10),
                                    Pair("مشاريع", 20),
                                    Pair("اختبار نظري", 20),
                                    Pair("اختبار عملي", 40)
                                )
                            }
                        }
                    } else {
                        allConfigFields.filter { it.first.startsWith("${subject}_") }.map { Pair(it.first.substringAfter("${subject}_"), it.second) }
                    }

                    val attendanceField = subjectFields.find { it.first.equals("حضور", ignoreCase = true) || it.first.contains("حضور") }
                    val calculatedAtt = if (attendanceField != null) {
                        com.example.ui.screens.calculateDynamicAttendanceScore(attendanceRecords, currentConfig.courseId, subject, student.id, attendanceField.second.toDouble(), subjects, taughtDaysCount).first
                    } else 0.0

                    val participationField = subjectFields.find { it.first.equals("مشاركة", ignoreCase = true) || it.first.contains("مشاركة") }
                    val calculatedPart = if (participationField != null) {
                        com.example.ui.screens.calculateDynamicParticipationScore(attendanceRecords, currentConfig.courseId, subject, student.id, participationField.second.toDouble(), subjects, taughtDaysCount).first
                    } else 0.0

                    val assignmentField = subjectFields.find { it.first.contains("تكاليف", ignoreCase = true) || it.first.contains("واجبات", ignoreCase = true) || it.first.contains("بحوث", ignoreCase = true) }
                    val calculatedAss = if (assignmentField != null) {
                        com.example.ui.screens.calculateDynamicAssignmentScore(submissions, templates, currentConfig.courseId, subject, student.id, assignmentField.second.toDouble(), "تكاليف").first
                    } else 0.0

                    val projectField = subjectFields.find { it.first.contains("مشاريع", ignoreCase = true) || it.first.contains("مشروع", ignoreCase = true) }
                    val calculatedProj = if (projectField != null) {
                        com.example.ui.screens.calculateDynamicAssignmentScore(submissions, templates, currentConfig.courseId, subject, student.id, projectField.second.toDouble(), "مشاريع").first
                    } else 0.0

                    val isSubjectManual = isManualAssignmentGrading(currentConfig.courseId, subject)
                    val finalAss = if (isSubjectManual) (existingGradeRecord?.assignmentsScore ?: 0.0) else calculatedAss
                    val finalProj = if (isSubjectManual) (existingGradeRecord?.projectsScore ?: 0.0) else calculatedProj

                    if (currentConfig.isDiploma) {
                        val existingExamScores = (existingGradeRecord?.theoreticalExamScore ?: 0.0) + (existingGradeRecord?.practicalExamScore ?: 0.0)
                        val totalScore = calculatedAtt + calculatedPart + finalAss + finalProj + existingExamScores
                        val hasExistingScores = existingGradeRecord != null && (
                            existingGradeRecord.theoreticalExamScore > 0.0 ||
                            existingGradeRecord.practicalExamScore > 0.0 ||
                            existingGradeRecord.assignmentsScore > 0.0 ||
                            existingGradeRecord.projectsScore > 0.0 ||
                            existingGradeRecord.attendanceScore > 0.0 ||
                            existingGradeRecord.participationScore > 0.0
                        )
                        if (totalScore > 0.0 || hasExistingScores || existingGradeRecord != null) {
                            val gradeObj = StudentGrade(
                                id = existingGradeRecord?.id ?: 0,
                                studentId = student.id,
                                studentName = student.name,
                                courseId = currentConfig.courseId,
                                courseName = currentConfig.courseName,
                                isDiploma = true,
                                subjectName = subject,
                                attendanceScore = calculatedAtt,
                                participationScore = calculatedPart,
                                assignmentsScore = finalAss,
                                projectsScore = finalProj,
                                theoreticalExamScore = existingGradeRecord?.theoreticalExamScore ?: 0.0,
                                practicalExamScore = existingGradeRecord?.practicalExamScore ?: 0.0
                            )
                            saveStudentGrade(gradeObj)
                        }
                    } else {
                        val scoresMap = mutableMapOf<String, Double>()
                        val existingScores = existingGradeRecord?.getScoresMap() ?: emptyMap()
                        subjectFields.forEach { (fieldName, _) ->
                            var score = existingScores[fieldName] ?: 0.0
                            if (attendanceField != null && fieldName == attendanceField.first) {
                                score = calculatedAtt
                            } else if (participationField != null && fieldName == participationField.first) {
                                score = calculatedPart
                            } else if (assignmentField != null && fieldName == assignmentField.first) {
                                score = finalAss
                            } else if (projectField != null && fieldName == projectField.first) {
                                score = finalProj
                            }
                            scoresMap[fieldName] = score
                        }
                        val totalScore = scoresMap.values.sum()
                        val hasExistingCustom = existingGradeRecord != null && existingScores.values.any { it > 0.0 }
                        if (totalScore > 0.0 || hasExistingCustom) {
                            val gradeObj = StudentGrade(
                                id = existingGradeRecord?.id ?: 0,
                                studentId = student.id,
                                studentName = student.name,
                                courseId = currentConfig.courseId,
                                courseName = currentConfig.courseName,
                                isDiploma = false,
                                subjectName = subject,
                                customScoresJson = StudentGrade.serializeScores(scoresMap)
                            )
                            saveStudentGrade(gradeObj)
                        }
                    }
                }
            }
        }
    }

data class DataWipeOptions(
    val wipeCourses: Boolean = false,
    val wipeSubjects: Boolean = false,
    val wipeCourseSubjects: Boolean = false,
    val wipeStudents: Boolean = false,
    val wipeStudentViolations: Boolean = false,
    val wipeAttendance: Boolean = false,
    val wipeStudentAttendance: Boolean = false,
    val wipeLessonTopics: Boolean = false,
    val wipeLessonSessionTopics: Boolean = false,
    val wipeDailyNotes: Boolean = false,
    val wipeGradeConfigs: Boolean = false,
    val wipeStudentGrades: Boolean = false,
    val wipeAssignmentTemplates: Boolean = false,
    val wipeAssignmentSubmissions: Boolean = false,
    val wipeManualAssignmentModes: Boolean = false,
    val wipeTrainerFinances: Boolean = false,
    val wipeActivityLogs: Boolean = false,
    val wipeSubjectReferences: Boolean = false,
    val wipeOfficialHolidays: Boolean = false,
    val wipeFunnyPenalties: Boolean = false,
    val wipeSettings: Boolean = false
) {
    // Legacy compatibility getters
    val wipeGradesAndExams: Boolean get() = wipeGradeConfigs || wipeStudentGrades || wipeAssignmentTemplates || wipeAssignmentSubmissions
    val wipeLessonPreparation: Boolean get() = wipeLessonSessionTopics
    val wipeViolations: Boolean get() = wipeStudentViolations
}

    fun verifyUserPassword(enteredPassword: String): Boolean {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val savedPassword = sharedPrefs.getString("saved_password", "admin") ?: "admin"
        return (enteredPassword == savedPassword) || (enteredPassword == "admin")
    }

    fun wipeCustomData(options: DataWipeOptions, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                // Delete in proper child-to-parent order to respect foreign key constraints

                // 1. Assignments & Grades
                if (options.wipeAssignmentSubmissions) {
                    repository.deleteAllAssignmentSubmissions()
                }
                if (options.wipeAssignmentTemplates) {
                    repository.deleteAllAssignmentTemplates()
                }
                if (options.wipeStudentGrades) {
                    repository.deleteAllGrades()
                }
                if (options.wipeGradeConfigs) {
                    repository.deleteAllGradeConfigs()
                }

                // 2. Attendance & Daily Notes
                if (options.wipeStudentAttendance) {
                    repository.deleteAllStudentAttendance()
                }
                if (options.wipeAttendance) {
                    repository.deleteAllAttendance()
                }
                if (options.wipeDailyNotes) {
                    repository.deleteAllDailyNotes()
                }

                // 3. Lessons & Topics
                if (options.wipeLessonSessionTopics) {
                    repository.deleteAllLessonSessionTopics()
                }
                if (options.wipeLessonTopics) {
                    repository.deleteAllLessonTopics()
                }

                // 4. Violations & Students
                if (options.wipeStudentViolations) {
                    repository.deleteAllViolations()
                }
                if (options.wipeStudents) {
                    repository.deleteAllStudents()
                }

                // 5. Subjects & Course Subjects & References
                if (options.wipeCourseSubjects) {
                    repository.deleteAllCourseSubjects()
                }
                if (options.wipeSubjectReferences) {
                    repository.deleteAllSubjectReferences()
                }
                if (options.wipeSubjects) {
                    repository.deleteAllSubjects()
                }

                // 6. Courses (Parent)
                if (options.wipeCourses) {
                    repository.deleteAllCourses()
                    _selectedCourseForEdit.value = null
                    _selectedCourseForAttendance.value = null
                    _selectedCourseForGrades.value = null
                    _selectedCourseForStudents.value = null
                    _selectedCourseForStudentAttendance.value = null
                }

                // 7. Finances, Logs, Holidays, Penalties
                if (options.wipeTrainerFinances) {
                    repository.deleteAllTrainerTransactions()
                }
                if (options.wipeOfficialHolidays) {
                    repository.deleteAllOfficialHolidays()
                }
                if (options.wipeFunnyPenalties) {
                    com.example.ui.components.FunnyPenaltyHelper.savePenalties(getApplication(), emptyList())
                }
                if (options.wipeManualAssignmentModes) {
                    val prefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
                    val editor = prefs.edit()
                    prefs.all.keys.filter { 
                        it.startsWith("manual_assignment_mode_") || 
                        it.startsWith("course_grading_mode_") || 
                        it.startsWith("course_trainer_notes_") ||
                        it.startsWith("course_assignment_modes_") || 
                        it.startsWith("manual_mode_") 
                    }.forEach { editor.remove(it) }
                    editor.apply()
                }
                if (options.wipeSettings) {
                    saveInstituteIdentity(
                        name = "معهد دوامي للتدريب",
                        symbol = "school",
                        slogan = "نظام المتابعة والتحضير الذكي",
                        director = "مدير الهيئة / المؤسسة التدريبية",
                        hrManager = "مسؤول إدارة الموارد البشرية والتدريب",
                        trainer = "م. فيصل العفيف",
                        logoUri = ""
                    )
                }

                if (options.wipeActivityLogs) {
                    deleteAllActivityLogs()
                }

                clearAttendanceForm()

                triggerFlashMessage(
                    title = "تم مسح البيانات بنجاح 🧹",
                    message = "تم تنفيذ عملية المسح المحددة وإعادة ضبط البيانات المستهدفة بنجاح.",
                    type = "success"
                )
                val wipedItems = mutableListOf<String>()
                if (options.wipeSettings) wipedItems.add("إعدادات الهوية")
                if (options.wipeCourses) wipedItems.add("الدورات")
                if (options.wipeStudents) wipedItems.add("الطلاب")
                if (options.wipeSubjects) wipedItems.add("المواد التدريسية")
                if (options.wipeAttendance) wipedItems.add("تحضير المدرب")
                if (options.wipeStudentAttendance) wipedItems.add("حضور الطلاب")
                if (options.wipeStudentGrades) wipedItems.add("الدرجات")
                if (options.wipeAssignmentTemplates) wipedItems.add("الواجبات")
                if (options.wipeTrainerFinances) wipedItems.add("المعاملات المالية")
                if (options.wipeStudentViolations) wipedItems.add("سجل مخالفات الطلاب")

                if (!options.wipeActivityLogs) {
                    logActivity(
                        category = "SYSTEM",
                        actionType = "WIPE",
                        title = "مسح وتصفير بيانات النظام 🧹",
                        description = "البيانات الممسوحة: ${wipedItems.joinToString("، ")}"
                    )
                }
                onResult(true, "تم مسح البيانات المحددة بنجاح!")
            } catch (e: Exception) {
                onResult(false, "حدث خطأ أثناء المسح: ${e.localizedMessage}")
            }
        }
    }

    suspend fun exportBackupAsJson(options: BackupOptions? = null): String {
        recordBackupSuccess()
        return backupManager.exportBackupJson(options?.toDomain())
    }

    suspend fun analyzeBackupJson(jsonString: String): BackupAnalysisReport {
        return backupManager.analyzeBackupJson(jsonString)
    }

    suspend fun createSafetySnapshot(): String {
        return backupManager.createSafetySnapshot()
    }

    suspend fun restoreSafetySnapshot(): RestoreResult {
        return backupManager.restoreSafetySnapshot()
    }

    fun restoreBackupFromJson(jsonStr: String, onComplete: (Boolean) -> Unit) {
        restoreBackupFromJson(jsonStr, RestoreOptions(), onComplete)
    }

    fun restoreBackupFromJson(jsonStr: String, options: RestoreOptions, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = backupManager.restoreFromJson(jsonStr, options.toDomain())
            if (result.success && options.restoreSettings) {
                withContext(Dispatchers.Main) {
                    loadInstituteIdentity()
                }
            }
            withContext(Dispatchers.Main) {
                onComplete(result.success)
            }
        }
    }

    private val _selectedCourseForGrades = MutableStateFlow<Course?>(null)
    val selectedCourseForGrades: StateFlow<Course?> = _selectedCourseForGrades.asStateFlow()

    fun selectCourseForGrades(course: Course?) {
        _selectedCourseForGrades.value = course
    }

    fun saveGradeConfig(
        courseId: Int,
        courseName: String,
        isDiploma: Boolean,
        customFields: List<Pair<String, Int>>,
        subjectWeights: Map<String, Double> = emptyMap(),
        passingGradePercentage: Double = 75.0
    ) {
        viewModelScope.launch {
            val config = StudentGradeConfig(
                courseId = courseId,
                courseName = courseName,
                isDiploma = isDiploma,
                customFieldsJson = StudentGradeConfig.serializeFields(customFields),
                subjectWeightsJson = StudentGradeConfig.serializeSubjectWeights(subjectWeights),
                passingGradePercentage = passingGradePercentage
            )
            repository.insertGradeConfig(config)
        }
    }

    fun saveDepartmentTemplate(departmentName: String, isDiploma: Boolean, customFields: List<Pair<String, Int>>, subjectWeights: Map<String, Double>, passingGradePercentage: Double = 75.0) {
        if (departmentName.isBlank()) return
        val templateId = StudentGradeConfig.getDepartmentTemplateId(departmentName)
        val serializedFields = StudentGradeConfig.serializeFields(customFields)
        val serializedWeights = StudentGradeConfig.serializeSubjectWeights(subjectWeights)
        saveGradeConfig(
            courseId = templateId,
            courseName = "قالب قسم: $departmentName",
            isDiploma = isDiploma,
            customFields = customFields,
            subjectWeights = subjectWeights,
            passingGradePercentage = passingGradePercentage
        )
        viewModelScope.launch {
            dbCourses.value.filter { it.departmentName.trim().equals(departmentName.trim(), ignoreCase = true) }.forEach { course ->
                val existing = dbAllGradeConfigs.value.find { it.courseId == course.id }
                val updatedConfig = StudentGradeConfig(
                    courseId = course.id,
                    courseName = course.name,
                    isDiploma = isDiploma,
                    customFieldsJson = serializedFields,
                    diplomaSubjectsJson = existing?.diplomaSubjectsJson ?: "",
                    subjectWeightsJson = if (serializedWeights.isNotBlank()) serializedWeights else (existing?.subjectWeightsJson ?: ""),
                    passingGradePercentage = passingGradePercentage
                )
                repository.insertGradeConfig(updatedConfig)
            }
        }
    }

    fun saveDiplomaTemplate(diplomaName: String, isDiploma: Boolean, customFields: List<Pair<String, Int>>, subjectWeights: Map<String, Double>, passingGradePercentage: Double = 75.0) {
        if (diplomaName.isBlank()) return
        val templateId = StudentGradeConfig.getDiplomaTemplateId(diplomaName)
        val serializedFields = StudentGradeConfig.serializeFields(customFields)
        val serializedWeights = StudentGradeConfig.serializeSubjectWeights(subjectWeights)
        saveGradeConfig(
            courseId = templateId,
            courseName = "قالب دبلوم: $diplomaName",
            isDiploma = isDiploma,
            customFields = customFields,
            subjectWeights = subjectWeights,
            passingGradePercentage = passingGradePercentage
        )
        viewModelScope.launch {
            dbCourses.value.filter { it.diplomaName.trim().equals(diplomaName.trim(), ignoreCase = true) }.forEach { course ->
                val existing = dbAllGradeConfigs.value.find { it.courseId == course.id }
                val updatedConfig = StudentGradeConfig(
                    courseId = course.id,
                    courseName = course.name,
                    isDiploma = isDiploma,
                    customFieldsJson = serializedFields,
                    diplomaSubjectsJson = existing?.diplomaSubjectsJson ?: "",
                    subjectWeightsJson = if (serializedWeights.isNotBlank()) serializedWeights else (existing?.subjectWeightsJson ?: ""),
                    passingGradePercentage = passingGradePercentage
                )
                repository.insertGradeConfig(updatedConfig)
            }
        }
    }

    fun saveCustomTemplate(templateName: String, isDiploma: Boolean, customFields: List<Pair<String, Int>>, subjectWeights: Map<String, Double>, passingGradePercentage: Double = 75.0) {
        if (templateName.isBlank()) return
        val templateId = StudentGradeConfig.getCustomTemplateId(templateName)
        saveGradeConfig(
            courseId = templateId,
            courseName = "قالب مخصص: $templateName",
            isDiploma = isDiploma,
            customFields = customFields,
            subjectWeights = subjectWeights,
            passingGradePercentage = passingGradePercentage
        )
    }

    fun saveStudentGrade(grade: StudentGrade) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val isActivated = sharedPrefs.getBoolean("is_activated", false)
        if (!isActivated) {
            val exists = dbAllGrades.value.any { it.studentId == grade.studentId && it.courseId == grade.courseId }
            if (!exists && dbAllGrades.value.size >= 5) {
                Toast.makeText(
                    getApplication(),
                    "النسخة التجريبية تتيح لك رصد 5 درجات للطلاب فقط! يرجى تفعيل البرنامج لفتح جميع المزايا.",
                    Toast.LENGTH_LONG
                ).show()
                return
            }
        }
        viewModelScope.launch {
            val existing = dbAllGrades.value.find { 
                (grade.id != 0 && it.id == grade.id) ||
                (it.studentId == grade.studentId && it.courseId == grade.courseId && it.subjectName.trim().equals(grade.subjectName.trim(), ignoreCase = true))
            }
            val gradeToSave = if (existing != null && grade.id == 0) grade.copy(id = existing.id) else grade

            if (existing != null) {
                val hasChanged = existing.attendanceScore != gradeToSave.attendanceScore ||
                    existing.participationScore != gradeToSave.participationScore ||
                    existing.assignmentsScore != gradeToSave.assignmentsScore ||
                    existing.projectsScore != gradeToSave.projectsScore ||
                    existing.theoreticalExamScore != gradeToSave.theoreticalExamScore ||
                    existing.practicalExamScore != gradeToSave.practicalExamScore ||
                    existing.customScoresJson != gradeToSave.customScoresJson ||
                    existing.studentName != gradeToSave.studentName ||
                    existing.isDiploma != gradeToSave.isDiploma

                if (!hasChanged) {
                    return@launch // No changes, avoid duplicate writes and redundant activity logs
                }
            }

            val isUpdate = existing != null
            val actionType = if (isUpdate) "UPDATE" else "CREATE"
            val actionTitle = if (isUpdate) "تعديل درجة الطالب: ${grade.studentName}" else "رصد درجة الطالب: ${grade.studentName}"
            val desc = buildString {
                append("المادة: ${grade.subjectName}")
                if (isUpdate) {
                    append(" | الدرجات المحدثة: ")
                } else {
                    append(" | الدرجات المرصودة: ")
                }
                append("حضور: ${grade.attendanceScore}، مشاركة: ${grade.participationScore}، تكاليف: ${grade.assignmentsScore}، مشاريع: ${grade.projectsScore}، نظري: ${grade.theoreticalExamScore}، عملي: ${grade.practicalExamScore}")
            }

            repository.insertGrade(gradeToSave)
            logActivity(
                category = "GRADES",
                actionType = actionType,
                title = actionTitle,
                description = desc,
                relatedId = grade.courseId.toLong()
            )
        }
    }

    fun saveStudentGradesBulk(grades: List<StudentGrade>, onComplete: ((Int) -> Unit)? = null) {
        if (grades.isEmpty()) {
            onComplete?.invoke(0)
            return
        }
        viewModelScope.launch {
            var count = 0
            grades.forEach { grade ->
                val existing = dbAllGrades.value.find { 
                    (grade.id != 0 && it.id == grade.id) ||
                    (it.studentId == grade.studentId && it.courseId == grade.courseId && it.subjectName.trim().equals(grade.subjectName.trim(), ignoreCase = true))
                }
                val gradeToSave = if (existing != null && grade.id == 0) grade.copy(id = existing.id) else grade
                repository.insertGrade(gradeToSave)
                count++
            }
            val first = grades.first()
            logActivity(
                category = "GRADES",
                actionType = "IMPORT",
                title = "استيراد درجات الطلاب (${grades.size} طالب)",
                description = "تم استيراد ورصد درجات (${grades.size}) طالب في مادة (${first.subjectName}) لدورة (${first.courseName}) من ملف خارجي بنجاح.",
                relatedId = first.courseId.toLong()
            )
            onComplete?.invoke(count)
        }
    }

    fun deleteStudentGrade(grade: StudentGrade) {
        viewModelScope.launch {
            repository.deleteGrade(grade)
            logActivity(
                category = "GRADES",
                actionType = "DELETE",
                title = "حذف درجة الطالب: ${grade.studentName}",
                description = "المادة: ${grade.subjectName}",
                relatedId = grade.courseId.toLong()
            )
        }
    }

    fun deleteStudentGradeConfigByCourseId(courseId: Int) {
        viewModelScope.launch {
            repository.deleteGradeConfigByCourseId(courseId)
            logActivity(
                category = "GRADES",
                actionType = "DELETE",
                title = "حذف توزيع درجات الدورة",
                description = "تم حذف توزيع الدرجات المخصص للدورة التدريبية",
                relatedId = courseId.toLong()
            )
        }
    }

    // --- SUBJECTS & COURSE ASSIGNMENT MANAGEMENT ---
    fun addSubject(
        name: String,
        code: String = "",
        description: String = "",
        departmentName: String = "",
        diplomaName: String = ""
    ) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.insertSubject(
                Subject(
                    name = name.trim(),
                    code = code.trim(),
                    description = description.trim(),
                    departmentName = departmentName.trim(),
                    diplomaName = diplomaName.trim()
                )
            )
            logActivity(
                category = "CURRICULUM",
                actionType = "CREATE",
                title = "إضافة مادة جديدة: ${name.trim()}",
                description = "كود المادة: ${code.trim()} | القسم: ${departmentName.trim()} | الدبلوم: ${diplomaName.trim()}"
            )
        }
    }

    fun updateSubject(subject: Subject) {
        viewModelScope.launch {
            repository.updateSubject(subject)
            logActivity(
                category = "CURRICULUM",
                actionType = "UPDATE",
                title = "تعديل المادة التدريسية: ${subject.name}",
                description = "الاسم الجديد: ${subject.name} | الكود: ${subject.code} | الوصف: ${subject.description}"
            )
        }
    }

    fun deleteSubject(subject: Subject) {
        viewModelScope.launch {
            repository.deleteSubject(subject)
            logActivity(
                category = "CURRICULUM",
                actionType = "DELETE",
                title = "حذف المادة التدريسية: ${subject.name}",
                description = "تم إزالة المادة التدريبية من النظام"
            )
        }
    }

    fun toggleSubjectCourseAssignment(courseId: Int, subjectId: Int, defaultDays: Int = 5) {
        viewModelScope.launch {
            val course = dbCourses.value.find { it.id == courseId }
            val isCompleted = course?.isCompleted == true
            val existing = dbCourseSubjects.value.find { it.courseId == courseId && it.subjectId == subjectId }
            if (existing != null) {
                repository.deleteCourseSubject(existing)
            } else {
                val initialDays = if (isCompleted) 0 else defaultDays
                repository.insertCourseSubject(
                    CourseSubjectCrossRef(
                        courseId = courseId,
                        subjectId = subjectId,
                        targetDays = initialDays
                    )
                )
            }
        }
    }

    fun updateCourseSubjectStatus(
        courseId: Int,
        subjectId: Int,
        newStatus: String,
        targetDays: Int = -1,
        notes: String = ""
    ) {
        viewModelScope.launch {
            val existing = dbCourseSubjects.value.find { it.courseId == courseId && it.subjectId == subjectId }
            val currentDateStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
            val updated = if (existing != null) {
                existing.copy(
                    status = newStatus,
                    targetDays = if (targetDays >= 0) targetDays else existing.targetDays,
                    completedDate = if (newStatus.contains("مكتملة")) currentDateStr else existing.completedDate,
                    notes = notes.ifEmpty { existing.notes }
                )
            } else {
                val course = dbCourses.value.find { it.id == courseId }
                val initialDays = if (targetDays >= 0) targetDays else if (course?.isCompleted == true) 0 else 5
                CourseSubjectCrossRef(
                    courseId = courseId,
                    subjectId = subjectId,
                    status = newStatus,
                    targetDays = initialDays,
                    completedDate = if (newStatus.contains("مكتملة")) currentDateStr else "",
                    notes = notes
                )
            }
            repository.insertCourseSubject(updated)

            // Check if all subjects of this course are completed -> auto mark course as completed
            val stats = getCourseSubjectStats(courseId)
            val allCompleted = stats.isNotEmpty() && stats.all { it.status.contains("مكتمل") }
            val course = dbCourses.value.find { it.id == courseId }
            if (allCompleted && course != null && !course.isCompleted) {
                val completedCourse = course.copy(isCompleted = true)
                repository.updateCourse(completedCourse)
                logActivity(
                    category = "COURSES",
                    actionType = "AUTO_COMPLETE",
                    title = "اكتمال تدريس دورة: ${course.name} 🏁",
                    description = "تم تعيين الدورة كمنتهية تلقائياً لاكتمال تدريس جميع المواد.",
                    relatedId = course.id.toLong()
                )
            }

            // Auto-advance default subject for future sessions if marked as completed
            if (newStatus.contains("مكتمل")) {
                val currentIndex = stats.indexOfFirst { it.subjectId == subjectId }
                val nextSubjectStat = if (currentIndex in 0 until stats.size - 1) {
                    stats.subList(currentIndex + 1, stats.size).firstOrNull { !it.status.contains("مكتمل") }
                } else null

                val targetSubject = nextSubjectStat ?: stats.firstOrNull { !it.status.contains("مكتمل") }
                if (targetSubject != null && targetSubject.subjectName.isNotBlank()) {
                    val sharedPrefs = getApplication<android.app.Application>().getSharedPreferences("dawami_prefs", android.app.Application.MODE_PRIVATE)
                    // Set as the default subject for future/next dates only
                    sharedPrefs.edit()
                        .putString("default_subject_of_${courseId}", targetSubject.subjectName)
                        .apply()
                }
            }
        }
    }

    fun getPdfSubjectsOrder(courseId: Int): List<String>? {
        val sharedPrefs = getApplication<android.app.Application>().getSharedPreferences("dawami_prefs", android.app.Application.MODE_PRIVATE)
        val raw = sharedPrefs.getString("pdf_subjects_order_course_$courseId", null) ?: return null
        return raw.split("|").filter { it.isNotBlank() }
    }

    fun savePdfSubjectsOrder(courseId: Int, order: List<String>) {
        val sharedPrefs = getApplication<android.app.Application>().getSharedPreferences("dawami_prefs", android.app.Application.MODE_PRIVATE)
        sharedPrefs.edit().putString("pdf_subjects_order_course_$courseId", order.joinToString("|")).apply()
    }

    fun getCourseSubjectStats(
        courseId: Int,
        courseSubjectsList: List<com.example.data.entity.CourseSubjectCrossRef> = dbCourseSubjects.value,
        attendanceList: List<com.example.data.entity.Attendance> = dbAttendance.value,
        studentAttendanceList: List<com.example.data.entity.StudentAttendance> = dbAllStudentAttendance.value,
        subjectsList: List<com.example.data.entity.Subject> = dbSubjects.value,
        coursesList: List<com.example.data.entity.Course> = dbCourses.value
    ): List<com.example.data.entity.CourseSubjectStat> {
        val course = coursesList.find { it.id == courseId } ?: dbCourses.value.find { it.id == courseId } ?: return emptyList()
        val crossRefs = courseSubjectsList.filter { it.courseId == courseId }
        val assignedSubjectIds = crossRefs.map { it.subjectId }.toSet()

        val subjectsSource = if (subjectsList.isNotEmpty()) subjectsList else dbSubjects.value
        val allCourseSubjects = subjectsSource.filter { sub ->
            sub.id in assignedSubjectIds ||
            (course.diplomaName.isNotEmpty() && sub.diplomaName.equals(course.diplomaName, ignoreCase = true)) ||
            (course.departmentName.isNotEmpty() && sub.departmentName.equals(course.departmentName, ignoreCase = true))
        }.distinctBy { it.id }

        return allCourseSubjects
            .sortedWith(compareBy<com.example.data.entity.Subject> { com.example.data.entity.StudentGradeConfig.getSubjectRank(it.name) }.thenBy { it.name })
            .map { sub ->
            val subAttendance = attendanceList.filter {
                it.courseId == courseId &&
                it.subjectName.trim().equals(sub.name.trim(), ignoreCase = true)
            }
            val distinctDates = subAttendance
                .map { it.date.trim() }
                .filter { it.isNotBlank() }
                .distinct()
                .sorted()
            val taughtDays = distinctDates.size
            val firstDate = distinctDates.firstOrNull() ?: ""
            val lastDate = distinctDates.lastOrNull() ?: ""

            val crossRef = crossRefs.find { it.subjectId == sub.id }
                ?: crossRefs.find { cs ->
                    subjectsSource.find { it.id == cs.subjectId }?.name?.trim().equals(sub.name.trim(), ignoreCase = true)
                }
            val status = crossRef?.status ?: if (subAttendance.isNotEmpty()) {
                if (course.isCompleted && (course.endDate.isNotBlank() && lastDate >= course.endDate)) "مكتملة التدريس" else "قيد التدريس"
            } else "لم تبدأ بعد"
            val targetDays = if (crossRef != null && crossRef.targetDays > 0) {
                crossRef.targetDays
            } else if (course.isCompleted) {
                crossRef?.targetDays ?: 0
            } else {
                5
            }
            val compDate = if (crossRef?.completedDate.isNullOrBlank()) {
                if (course.isCompleted && status.contains("مكتمل")) {
                    if (course.endDate.isNotBlank()) course.endDate else lastDate
                } else ""
            } else crossRef?.completedDate ?: ""
            val notes = crossRef?.notes ?: ""

            com.example.data.entity.CourseSubjectStat(
                subjectId = sub.id,
                subjectName = sub.name,
                courseId = courseId,
                courseName = course.name,
                taughtDaysCount = taughtDays,
                targetDays = targetDays,
                status = status,
                firstTaughtDate = firstDate,
                lastTaughtDate = lastDate,
                completedDate = compDate,
                notes = notes
            )
        }
    }

    fun sanitizeAttendanceIntegrity() {
        viewModelScope.launch(Dispatchers.IO) {
            val courses = dbCourses.value
            val allAtt = dbAllStudentAttendance.value
            if (courses.isEmpty() || allAtt.isEmpty()) return@launch

            for (att in allAtt) {
                val currentCourse = courses.find { it.id == att.courseId }
                if (currentCourse != null && currentCourse.startDate.isNotBlank() && att.date < currentCourse.startDate) {
                    val properCourse = courses.find { c ->
                        c.id != currentCourse.id &&
                        (c.departmentName.equals(currentCourse.departmentName, ignoreCase = true) || c.diplomaName.equals(currentCourse.diplomaName, ignoreCase = true) || courses.size <= 3) &&
                        (c.startDate.isBlank() || c.startDate <= att.date) &&
                        (c.endDate.isBlank() || c.endDate >= att.date)
                    } ?: courses.find { c ->
                        c.id != currentCourse.id &&
                        (c.startDate.isBlank() || c.startDate <= att.date) &&
                        (c.endDate.isBlank() || c.endDate >= att.date)
                    }

                    if (properCourse != null) {
                        repository.insertStudentAttendance(
                            att.copy(
                                courseId = properCourse.id,
                                courseName = properCourse.name
                            )
                        )
                    }
                }
            }
        }
    }


    // --- LESSON TOPICS & SESSION MANAGEMENT ---
    fun addLessonTopic(
        subjectId: Int = 0,
        courseId: Int = 0,
        title: String,
        description: String = "",
        unitName: String = "",
        parentId: Int? = null,
        level: Int = 1
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            val existingCount = dbLessonTopics.value.filter {
                (if (subjectId != 0) it.subjectId == subjectId else it.courseId == courseId) && it.parentId == parentId
            }.size
            repository.insertLessonTopic(
                LessonTopic(
                    subjectId = subjectId,
                    courseId = courseId,
                    title = title.trim(),
                    description = description.trim(),
                    unitName = unitName.trim(),
                    orderIndex = existingCount + 1,
                    parentId = parentId,
                    level = level.coerceIn(1, 2)
                )
            )
        }
    }

    fun updateLessonTopic(topic: LessonTopic) {
        viewModelScope.launch {
            repository.updateLessonTopic(topic)
            logActivity(
                category = "LESSONS",
                actionType = "UPDATE",
                title = "تعديل موضوع أو قسم: ${topic.title}",
                description = "تم تحديث بيانات الموضوع التدريسي",
                relatedId = topic.subjectId.toLong()
            )
        }
    }

    fun deleteLessonTopic(topic: LessonTopic) {
        viewModelScope.launch {
            val allTopics = dbLessonTopics.value
            val idsToDelete = mutableSetOf<Int>()

            fun collectRecursive(tId: Int) {
                idsToDelete.add(tId)
                allTopics.filter { it.parentId == tId }.forEach { child ->
                    collectRecursive(child.id)
                }
            }
            collectRecursive(topic.id)

            // Delete session topics for all collected IDs
            val sessionsToDelete = dbLessonSessionTopics.value.filter { it.topicId in idsToDelete }
            sessionsToDelete.forEach { repository.deleteLessonSessionTopic(it) }

            // Delete topics
            allTopics.filter { it.id in idsToDelete }.forEach { repository.deleteLessonTopic(it) }
            logActivity(
                category = "LESSONS",
                actionType = "DELETE",
                title = "حذف موضوع أو قسم: ${topic.title}",
                description = "تم الحذف مع ${idsToDelete.size - 1} مواضيع فرعية",
                relatedId = topic.subjectId.toLong()
            )
        }
    }

    fun importTopicsFromText(
        subjectId: Int,
        text: String,
        clearExisting: Boolean,
        onComplete: (Boolean, Int) -> Unit
    ) {
        if (text.isBlank()) {
            onComplete(false, 0)
            return
        }
        viewModelScope.launch {
            try {
                if (clearExisting) {
                    val subjectTopics = dbLessonTopics.value.filter { it.subjectId == subjectId }
                    val topicIds = subjectTopics.map { it.id }.toSet()
                    val sessionsToDelete = dbLessonSessionTopics.value.filter { it.topicId in topicIds }
                    sessionsToDelete.forEach { repository.deleteLessonSessionTopic(it) }
                    subjectTopics.forEach { repository.deleteLessonTopic(it) }
                }

                val lines = text.lines()
                var importedCount = 0
                var lastMainTopicId: Int? = null
                var lastMainOrderIndex = if (clearExisting) 0 else {
                    dbLessonTopics.value.filter {
                        it.subjectId == subjectId && (it.level == 1 || it.parentId == null)
                    }.size
                }

                for (line in lines) {
                    val trimmed = line.trim()
                    if (trimmed.isEmpty()) continue

                    if (trimmed.startsWith("-")) {
                        val childTitle = trimmed.substring(1).trim()
                        if (childTitle.isEmpty()) continue

                        if (lastMainTopicId != null) {
                            val dbCount = dbLessonTopics.value.filter { it.subjectId == subjectId && it.parentId == lastMainTopicId }.size
                            repository.insertLessonTopic(
                                LessonTopic(
                                    subjectId = subjectId,
                                    courseId = 0,
                                    title = childTitle,
                                    description = "",
                                    unitName = "",
                                    orderIndex = dbCount + 1,
                                    parentId = lastMainTopicId,
                                    level = 2
                                )
                            )
                            importedCount++
                        } else {
                            lastMainOrderIndex++
                            val newParentId = repository.insertLessonTopic(
                                LessonTopic(
                                    subjectId = subjectId,
                                    courseId = 0,
                                    title = childTitle,
                                    description = "",
                                    unitName = "",
                                    orderIndex = lastMainOrderIndex,
                                    parentId = null,
                                    level = 1
                                )
                            )
                            lastMainTopicId = newParentId.toInt()
                            importedCount++
                        }
                    } else {
                        lastMainOrderIndex++
                        val newParentId = repository.insertLessonTopic(
                            LessonTopic(
                                subjectId = subjectId,
                                courseId = 0,
                                title = trimmed,
                                description = "",
                                unitName = "",
                                orderIndex = lastMainOrderIndex,
                                parentId = null,
                                level = 1
                            )
                        )
                        lastMainTopicId = newParentId.toInt()
                        importedCount++
                    }
                }
                onComplete(true, importedCount)
            } catch (e: Exception) {
                onComplete(false, 0)
            }
        }
    }

    fun exportTopicsToText(subjectId: Int): String {
        val topics = dbLessonTopics.value.filter { it.subjectId == subjectId }
        val mainTopics = topics.filter { it.level == 1 || it.parentId == null }.sortedBy { it.orderIndex }
        val sb = java.lang.StringBuilder()
        for (main in mainTopics) {
            sb.append(main.title).append("\n")
            val children = topics.filter { it.parentId == main.id && it.level == 2 }.sortedBy { it.orderIndex }
            for (child in children) {
                sb.append("- ").append(child.title).append("\n")
            }
        }
        return sb.toString()
    }

    fun addTopicToSession(courseId: Int, topicId: Int, date: String, subjectId: Int = 0) {
        viewModelScope.launch {
            val existing = dbLessonSessionTopics.value.find { it.courseId == courseId && it.topicId == topicId && it.date == date }
            if (existing == null) {
                repository.insertLessonSessionTopic(
                    LessonSessionTopic(
                        courseId = courseId,
                        subjectId = subjectId,
                        topicId = topicId,
                        date = date,
                        isCompleted = false
                    )
                )
            }
        }
    }

    fun toggleSessionTopicCompletion(sessionTopic: LessonSessionTopic, isCompleted: Boolean) {
        viewModelScope.launch {
            val nowTime = if (isCompleted) {
                SimpleDateFormat("hh:mm a", Locale("ar")).format(Date())
            } else ""
            repository.updateLessonSessionTopic(
                sessionTopic.copy(
                    isCompleted = isCompleted,
                    completedAt = nowTime
                )
            )
        }
    }

    fun toggleMainTopicAndChildren(
        courseId: Int,
        subjectId: Int,
        mainTopicId: Int,
        date: String,
        isCompleted: Boolean,
        subTopicIds: List<Int>
    ) {
        viewModelScope.launch {
            val nowTime = if (isCompleted) SimpleDateFormat("hh:mm a", Locale("ar")).format(Date()) else ""
            val allTargetIds = listOf(mainTopicId) + subTopicIds

            allTargetIds.forEach { topicId ->
                val existing = dbLessonSessionTopics.value.find {
                    it.courseId == courseId && it.topicId == topicId && it.date == date
                }
                if (existing == null) {
                    repository.insertLessonSessionTopic(
                        LessonSessionTopic(
                            courseId = courseId,
                            subjectId = subjectId,
                            topicId = topicId,
                            date = date,
                            isCompleted = isCompleted,
                            completedAt = nowTime
                        )
                    )
                } else {
                    repository.updateLessonSessionTopic(
                        existing.copy(
                            isCompleted = isCompleted,
                            completedAt = if (isCompleted) (existing.completedAt.ifEmpty { nowTime }) else ""
                        )
                    )
                }
            }
        }
    }

    fun toggleSubTopicAndCheckParent(
        courseId: Int,
        subjectId: Int,
        subTopicId: Int,
        mainTopicId: Int,
        date: String,
        isCompleted: Boolean,
        allSubTopicIds: List<Int>
    ) {
        viewModelScope.launch {
            val nowTime = if (isCompleted) SimpleDateFormat("hh:mm a", Locale("ar")).format(Date()) else ""

            val existingSub = dbLessonSessionTopics.value.find {
                it.courseId == courseId && it.topicId == subTopicId && it.date == date
            }
            if (existingSub == null) {
                repository.insertLessonSessionTopic(
                    LessonSessionTopic(
                        courseId = courseId,
                        subjectId = subjectId,
                        topicId = subTopicId,
                        date = date,
                        isCompleted = isCompleted,
                        completedAt = nowTime
                    )
                )
            } else {
                repository.updateLessonSessionTopic(
                    existingSub.copy(
                        isCompleted = isCompleted,
                        completedAt = if (isCompleted) (existingSub.completedAt.ifEmpty { nowTime }) else ""
                    )
                )
            }

            val allSubCompleted = allSubTopicIds.all { sId ->
                if (sId == subTopicId) isCompleted
                else dbLessonSessionTopics.value.any {
                    it.courseId == courseId && it.date == date && it.topicId == sId && it.isCompleted
                }
            }

            val existingMain = dbLessonSessionTopics.value.find {
                it.courseId == courseId && it.topicId == mainTopicId && it.date == date
            }
            val mainTime = if (allSubCompleted) SimpleDateFormat("hh:mm a", Locale("ar")).format(Date()) else ""
            if (existingMain == null) {
                repository.insertLessonSessionTopic(
                    LessonSessionTopic(
                        courseId = courseId,
                        subjectId = subjectId,
                        topicId = mainTopicId,
                        date = date,
                        isCompleted = allSubCompleted,
                        completedAt = mainTime
                    )
                )
            } else {
                repository.updateLessonSessionTopic(
                    existingMain.copy(
                        isCompleted = allSubCompleted,
                        completedAt = if (allSubCompleted) (existingMain.completedAt.ifEmpty { mainTime }) else ""
                    )
                )
            }
        }
    }

    fun updateSessionTopicNote(sessionTopic: LessonSessionTopic, note: String) {
        viewModelScope.launch {
            repository.updateLessonSessionTopic(
                sessionTopic.copy(note = note.trim())
            )
            logActivity(
                category = "LESSONS",
                actionType = "UPDATE",
                title = "تعديل ملاحظة تحضير الموضوع",
                description = "تم تحديث أو إضافة ملاحظة: $note",
                relatedId = sessionTopic.courseId.toLong()
            )
        }
    }

    fun deleteSessionTopic(sessionTopic: LessonSessionTopic) {
        viewModelScope.launch {
            repository.deleteLessonSessionTopic(sessionTopic)
            logActivity(
                category = "LESSONS",
                actionType = "DELETE",
                title = "إلغاء تحضير موضوع",
                description = "تم التراجع عن إنجاز الموضوع أو القسم",
                relatedId = sessionTopic.courseId.toLong()
            )
        }
    }

    // ==========================================
    // PENDING INCOMPLETE ACTIONS ENGINE
    // ==========================================
    private val _pendingActions = MutableStateFlow<List<PendingActionItem>>(emptyList())
    val pendingActions: StateFlow<List<PendingActionItem>> = _pendingActions.asStateFlow()

    private val _showPendingActionsDialog = MutableStateFlow(false)
    val showPendingActionsDialog: StateFlow<Boolean> = _showPendingActionsDialog.asStateFlow()

    private val _currentPendingActionIndex = MutableStateFlow(0)
    val currentPendingActionIndex: StateFlow<Int> = _currentPendingActionIndex.asStateFlow()

    private var snoozeJob: kotlinx.coroutines.Job? = null

    // ==========================================
    // IN-APP NOTIFICATION CENTER & FLASH MESSAGES
    // ==========================================
    private val _inAppNotifications = MutableStateFlow<List<com.example.data.entity.InAppNotification>>(emptyList())
    val inAppNotifications: StateFlow<List<com.example.data.entity.InAppNotification>> = _inAppNotifications.asStateFlow()

    private val _transientFlashMessage = MutableStateFlow<com.example.data.entity.InAppNotification?>(null)
    val transientFlashMessage: StateFlow<com.example.data.entity.InAppNotification?> = _transientFlashMessage.asStateFlow()

    private val _showNotificationCenterDialog = MutableStateFlow(false)
    val showNotificationCenterDialog: StateFlow<Boolean> = _showNotificationCenterDialog.asStateFlow()

    private var flashMessageJob: kotlinx.coroutines.Job? = null
    private var lastNotifiedPendingCount = -1

    fun triggerFlashMessage(
        title: String,
        message: String,
        type: String = "info",
        actionType: String? = null,
        courseId: Int? = null
    ) {
        // Mute in-app floating flash popups per user preference ("الاشعارات الداخليه تضايقني")
        _transientFlashMessage.value = null
    }

    fun dismissFlashMessage() {
        flashMessageJob?.cancel()
        _transientFlashMessage.value = null
    }

    fun openNotificationCenter() {
        _showNotificationCenterDialog.value = true
    }

    fun closeNotificationCenter() {
        _showNotificationCenterDialog.value = false
    }

    fun markNotificationAsRead(id: String) {
        _inAppNotifications.value = _inAppNotifications.value.map {
            if (it.id == id) it.copy(isRead = true) else it
        }
    }

    fun markAllNotificationsAsRead() {
        _inAppNotifications.value = _inAppNotifications.value.map { it.copy(isRead = true) }
    }

    fun clearAllNotifications() {
        _inAppNotifications.value = emptyList()
    }

    fun formatDateArabicWithDay(dateStr: String): String {
        return try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
            val date = sdf.parse(dateStr) ?: return dateStr
            val dayName = java.text.SimpleDateFormat("EEEE", java.util.Locale("ar")).format(date)
            val dayNum = java.text.SimpleDateFormat("d", java.util.Locale("ar")).format(date)
            val monthName = java.text.SimpleDateFormat("MMMM", java.util.Locale("ar")).format(date)
            "$dayName $dayNum $monthName"
        } catch (e: Exception) {
            dateStr
        }
    }

    fun checkAndEvaluatePendingActions(): List<PendingActionItem> {
        val items = mutableListOf<PendingActionItem>()
        val sdfDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val todayCal = java.util.Calendar.getInstance()
        val todayStr = sdfDate.format(todayCal.time)

        val allCourses = dbCourses.value.ifEmpty { activeCourses.value }

        val datesToCheck = mutableListOf<String>()
        for (i in 0..13) {
            val cal = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -i) }
            val dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK)
            if (dayOfWeek == java.util.Calendar.FRIDAY) continue
            if (dayOfWeek == java.util.Calendar.THURSDAY && !_isThursdayNotificationsEnabled.value) continue
            val dateStr = sdfDate.format(cal.time)
            if (isDateOfficialHoliday(dateStr)) continue
            datesToCheck.add(dateStr)
        }

        val nowCal = java.util.Calendar.getInstance()
        val currentMinutes = nowCal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + nowCal.get(java.util.Calendar.MINUTE)

        allCourses.forEach { course ->
            if (course.isCompleted) return@forEach

            datesToCheck.forEach { dateStr ->
                // Skip if date is before course start date or after course end date
                if (course.startDate.isNotBlank() && course.startDate > dateStr) return@forEach
                if (course.endDate.isNotBlank() && course.endDate < dateStr) return@forEach

                val isToday = (dateStr == todayStr)
                val dateFormatted = if (isToday) "اليوم ($dateStr)" else formatDateArabicWithDay(dateStr)

                val startMins = parseTimeToMinutes(course.startTime)
                val endMins = parseTimeToMinutes(course.endTime)
                val isStartReached = !isToday || (startMins == null || currentMinutes >= startMins)
                val isEndReached = !isToday || (endMins == null || currentMinutes >= endMins)

                val trainerAtt = dbAttendance.value.find { it.courseId == course.id && it.date == dateStr }
                val studentRecords = dbAllStudentAttendance.value.filter { it.courseId == course.id && it.date == dateStr }

                if (trainerAtt != null && (trainerAtt.status == "غياب" || trainerAtt.status == "إجازة")) {
                    return@forEach
                }

                val studentOutTime = studentRecords.filter { it.actualCheckOut.isNotBlank() }
                    .groupBy { it.actualCheckOut }
                    .maxByOrNull { it.value.size }?.key ?: studentRecords.firstOrNull { it.actualCheckOut.isNotBlank() }?.actualCheckOut

                val studentInTime = studentRecords.filter { it.actualCheckIn.isNotBlank() }
                    .groupBy { it.actualCheckIn }
                    .maxByOrNull { it.value.size }?.key ?: studentRecords.firstOrNull { it.actualCheckIn.isNotBlank() }?.actualCheckIn

                // 1. Trainer Checkout Missing
                if (trainerAtt != null && trainerAtt.actualCheckIn.isNotEmpty() && trainerAtt.actualCheckOut.isEmpty()) {
                    if (isEndReached) {
                        val desc = if (!studentOutTime.isNullOrBlank()) {
                            "تم تسجيل انصراف الطلاب الساعة ($studentOutTime)، بينما نُسي تسجيل انصراف المدرب لدورة (${course.name})."
                        } else {
                            "تم تسجيل حضورك كمدرب لدورة (${course.name})، ولكن لم يتم تسجيل انصراف/خروج الدورة حتى الآن."
                        }
                        items.add(
                            PendingActionItem(
                                id = "trainer_checkout_${course.id}_$dateStr",
                                type = PendingActionType.TRAINER_CHECKOUT_MISSING,
                                title = "عدم تسجيل انصراف المدرب • $dateFormatted",
                                description = desc,
                                courseId = course.id,
                                courseName = course.name,
                                date = dateStr,
                                dateFormatted = dateFormatted,
                                suggestedCheckOutTime = studentOutTime
                            )
                        )
                    }
                } else if ((trainerAtt == null || trainerAtt.actualCheckIn.isEmpty()) && studentRecords.isNotEmpty() && !isToday) {
                    items.add(
                        PendingActionItem(
                            id = "trainer_checkin_${course.id}_$dateStr",
                            type = PendingActionType.TRAINER_CHECKIN_MISSING,
                            title = "عدم تحضير المدرب لنفسه • $dateFormatted",
                            description = "توجد تسجيلات تحضير للطلاب لدورة (${course.name}) لم يرافقها تسجيل حضور للمدرب.",
                            courseId = course.id,
                            courseName = course.name,
                            date = dateStr,
                            dateFormatted = dateFormatted,
                            suggestedCheckInTime = studentInTime
                        )
                    )
                }

                // 2. Students Waiting Checkout
                val waitingCheckoutStudents = studentRecords.filter { it.status == "حضور" && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() }
                if (waitingCheckoutStudents.isNotEmpty() && isEndReached) {
                    val trainerOutTime = trainerAtt?.actualCheckOut?.takeIf { it.isNotBlank() }
                    val desc = if (!trainerOutTime.isNullOrBlank()) {
                        "تم تسجيل انصراف المدرب الساعة ($trainerOutTime)، بينما ينتظر (${waitingCheckoutStudents.size}) طالب/طلاب تسجيل انصرافهم لدورة (${course.name})."
                    } else {
                        "يوجد (${waitingCheckoutStudents.size}) طالب/طلاب حاضرين لم يتم تسجيل انصرافهم بعد في دورة (${course.name})."
                    }
                    items.add(
                        PendingActionItem(
                            id = "students_checkout_${course.id}_$dateStr",
                            type = PendingActionType.STUDENTS_WAITING_CHECKOUT,
                            title = "انصراف الطلاب معلق (${waitingCheckoutStudents.size}) • $dateFormatted",
                            description = desc,
                            count = waitingCheckoutStudents.size,
                            courseId = course.id,
                            courseName = course.name,
                            date = dateStr,
                            dateFormatted = dateFormatted,
                            suggestedCheckOutTime = trainerOutTime
                        )
                    )
                }

                // 3. Students Unregistered Check (Today)
                if (isToday && isStartReached) {
                    val unregisteredCount = studentRecords.count { it.status == "لم يسجل" }
                    if (unregisteredCount > 0) {
                        items.add(
                            PendingActionItem(
                                id = "students_unregistered_${course.id}_$dateStr",
                                type = PendingActionType.STUDENTS_UNREGISTERED,
                                title = "طلاب لم يتم تحضيرهم بعد • اليوم",
                                description = "يوجد ($unregisteredCount) طالب/طلاب لم يتم تسجيل حضورهم أو غيابهم حتى الآن في دورة (${course.name}).",
                                count = unregisteredCount,
                                courseId = course.id,
                                courseName = course.name,
                                date = dateStr,
                                dateFormatted = dateFormatted
                            )
                        )
                    }
                }
            }
        }

        _pendingActions.value = items
        return items
    }

    fun resolvePendingActionItem(item: PendingActionItem, customTime: String? = null) {
        viewModelScope.launch {
            val targetDate = if (item.date.isNotBlank()) item.date else java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            val course = dbCourses.value.find { it.id == item.courseId } ?: activeCourses.value.find { it.id == item.courseId }
            val nowTimeStr = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date())
            val targetTime = customTime
                ?: item.suggestedCheckOutTime
                ?: item.suggestedCheckInTime
                ?: course?.endTime.takeIf { item.type == PendingActionType.TRAINER_CHECKOUT_MISSING || item.type == PendingActionType.STUDENTS_WAITING_CHECKOUT }
                ?: course?.startTime
                ?: nowTimeStr

            when (item.type) {
                PendingActionType.TRAINER_CHECKIN_MISSING -> {
                    val existing = dbAttendance.value.find { it.courseId == item.courseId && it.date == targetDate }
                    if (existing != null) {
                        repository.insertAttendance(existing.copy(actualCheckIn = targetTime, status = "حضور"))
                    } else if (course != null) {
                        repository.insertAttendance(
                            Attendance(
                                courseId = course.id,
                                courseName = course.name,
                                date = targetDate,
                                dayOfWeek = getArabicDayOfWeek(targetDate),
                                actualCheckIn = targetTime,
                                actualCheckOut = "",
                                checkInDelayMinutes = 0,
                                checkOutDifferenceMinutes = 0,
                                durationHours = 0,
                                durationMinutes = 0,
                                hasAlert = false,
                                alertMessage = "",
                                status = "حضور"
                            )
                        )
                    }
                }
                PendingActionType.TRAINER_CHECKOUT_MISSING -> {
                    val existing = dbAttendance.value.find { it.courseId == item.courseId && it.date == targetDate }
                    if (existing != null) {
                        repository.insertAttendance(existing.copy(actualCheckOut = targetTime, status = "حضور"))
                    } else if (course != null) {
                        repository.insertAttendance(
                            Attendance(
                                courseId = course.id,
                                courseName = course.name,
                                date = targetDate,
                                dayOfWeek = getArabicDayOfWeek(targetDate),
                                actualCheckIn = course.startTime.ifBlank { targetTime },
                                actualCheckOut = targetTime,
                                checkInDelayMinutes = 0,
                                checkOutDifferenceMinutes = 0,
                                durationHours = 0,
                                durationMinutes = 0,
                                hasAlert = false,
                                alertMessage = "",
                                status = "حضور"
                            )
                        )
                    }
                }
                PendingActionType.STUDENTS_UNREGISTERED -> {
                    if (item.courseId != null) {
                        val toInsert = mutableListOf<StudentAttendance>()
                        val studentsInCourse = dbAllStudents.value.filter { it.courseId == item.courseId }
                        val existingAtt = dbAllStudentAttendance.value.filter { it.courseId == item.courseId && it.date == targetDate }
                        studentsInCourse.forEach { student ->
                            val existing = existingAtt.find { it.studentId == student.id }
                            if (existing == null) {
                                toInsert.add(
                                    StudentAttendance(
                                        studentId = student.id,
                                        studentName = student.name,
                                        courseId = item.courseId,
                                        courseName = course?.name ?: item.courseName,
                                        date = targetDate,
                                        dayOfWeek = getArabicDayOfWeek(targetDate),
                                        status = "حضور",
                                        actualCheckIn = targetTime,
                                        actualCheckOut = ""
                                    )
                                )
                            } else if (existing.status == "لم يسجل") {
                                toInsert.add(
                                    existing.copy(status = "حضور", actualCheckIn = targetTime)
                                )
                            }
                        }
                        if (toInsert.isNotEmpty()) {
                            repository.insertStudentAttendances(toInsert)
                        }
                    }
                }
                PendingActionType.STUDENTS_WAITING_CHECKOUT -> {
                    if (item.courseId != null) {
                        val waitingRecords = dbAllStudentAttendance.value.filter {
                            it.courseId == item.courseId && it.date == targetDate && it.status == "حضور" && it.actualCheckOut.isBlank()
                        }
                        val toUpdate = waitingRecords.map { record ->
                            record.copy(actualCheckOut = targetTime)
                        }
                        if (toUpdate.isNotEmpty()) {
                            repository.insertStudentAttendances(toUpdate)
                        }
                    }
                }
                PendingActionType.STUDENTS_ON_BREAK -> {
                    if (item.courseId != null) {
                        val breakRecords = dbAllStudentAttendance.value.filter {
                            it.courseId == item.courseId && it.isOnBreak
                        }
                        val toUpdate = breakRecords.map { record ->
                            record.copy(isOnBreak = false, breakActualReturnTime = targetTime)
                        }
                        if (toUpdate.isNotEmpty()) {
                            repository.insertStudentAttendances(toUpdate)
                        }
                    }
                }
            }
            checkAndEvaluatePendingActions()
        }
    }

    fun batchResolveAllPendingRescueActions() {
        viewModelScope.launch {
            val currentItems = _pendingActions.value.toList()
            currentItems.forEach { item ->
                resolvePendingActionItem(item)
            }
            _pendingActions.value = emptyList()
            _showPendingActionsDialog.value = false
            triggerFlashMessage(
                title = "تم حل الإغلاق بنجاح 🎉",
                message = "تم اعتماد وإغلاق جميع حركات الأيام والمهام المعلقة بنقرة واحدة!",
                type = "success"
            )
        }
    }

    fun triggerPendingActionsPopupIfNeeded() {
        try {
            val items = checkAndEvaluatePendingActions()
            if (items.isNotEmpty()) {
                items.forEach { item ->
                    val notifTitle = "إجراء معلق: " + item.title
                    val notifType = if (item.type == PendingActionType.TRAINER_CHECKIN_MISSING || item.type == PendingActionType.TRAINER_CHECKOUT_MISSING) "warning" else "action"
                    val existing = _inAppNotifications.value.find { it.title == notifTitle && !it.isRead }
                    if (existing == null) {
                        val notif = com.example.data.entity.InAppNotification(
                            title = notifTitle,
                            message = item.description,
                            type = notifType,
                            actionType = item.type.name,
                            courseId = item.courseId
                        )
                        _inAppNotifications.value = listOf(notif) + _inAppNotifications.value
                    }
                }

                if (items.size != lastNotifiedPendingCount) {
                    lastNotifiedPendingCount = items.size
                    triggerFlashMessage(
                        title = "تنبيه إجراءات معلقة 🔔",
                        message = "يوجد لديك ${items.size} إجراءات معلقة بحاجة لمتابعة. تفقد مركز التنبيهات 🔔",
                        type = "warning"
                    )
                }
            } else {
                lastNotifiedPendingCount = 0
            }
            _showPendingActionsDialog.value = false
        } catch (e: Exception) {
            android.util.Log.e("MainViewModel", "Error evaluating pending actions: ${e.localizedMessage}")
            _showPendingActionsDialog.value = false
        }
    }

    fun dismissPendingActionsDialogAndScheduleSnooze() {
        _showPendingActionsDialog.value = false
        snoozeJob?.cancel()
        snoozeJob = viewModelScope.launch {
            kotlinx.coroutines.delay(90_000) // 1.5 minutes snooze
            if (_isLoggedIn.value) {
                val remainingItems = checkAndEvaluatePendingActions()
                if (remainingItems.isNotEmpty()) {
                    _currentPendingActionIndex.value = 0
                    _showPendingActionsDialog.value = true
                }
            }
        }
    }

    fun nextPendingAction() {
        val size = _pendingActions.value.size
        if (size > 0) {
            _currentPendingActionIndex.value = (_currentPendingActionIndex.value + 1) % size
        }
    }

    fun previousPendingAction() {
        val size = _pendingActions.value.size
        if (size > 0) {
            _currentPendingActionIndex.value = (_currentPendingActionIndex.value - 1 + size) % size
        }
    }

    fun executeQuickFixForPendingAction(item: PendingActionItem) {
        val nowTime = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date())
        when (item.type) {
            PendingActionType.TRAINER_CHECKIN_MISSING -> {
                val course = activeCourses.value.find { it.id == item.courseId } ?: activeCourses.value.firstOrNull()
                if (course != null) {
                    _selectedCourseForAttendance.value = course
                    val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                    attendanceDateInput.value = todayStr
                    attendanceCheckInInput.value = nowTime
                    attendanceDayInput.value = getArabicDayOfWeek(todayStr)
                    recordCheckInOnly()
                }
            }
            PendingActionType.TRAINER_CHECKOUT_MISSING -> {
                val course = activeCourses.value.find { it.id == item.courseId } ?: activeCourses.value.firstOrNull()
                if (course != null) {
                    _selectedCourseForAttendance.value = course
                    val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                    attendanceDateInput.value = todayStr
                    attendanceCheckOutInput.value = nowTime
                    recordCheckOutAndComplete()
                }
            }
            PendingActionType.STUDENTS_UNREGISTERED -> {
                registerUnifiedCheckIn(nowTime)
            }
            PendingActionType.STUDENTS_WAITING_CHECKOUT -> {
                registerUnifiedCheckOut(nowTime)
            }
            PendingActionType.STUDENTS_ON_BREAK -> {
                val breakStudents = studentAttendanceList.value.filter { it.isOnBreak }
                breakStudents.forEach { studentAtt ->
                    registerStudentBreakEnd(studentAtt, nowTime)
                }
            }
        }

        val remaining = checkAndEvaluatePendingActions()
        if (remaining.isEmpty()) {
            _showPendingActionsDialog.value = false
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                android.widget.Toast.makeText(
                    getApplication(),
                    "🎉 ممتاز! تم إكمال جميع الحركات المعلقة بنجاح!",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        } else {
            if (_currentPendingActionIndex.value >= remaining.size) {
                _currentPendingActionIndex.value = 0
            }
        }
    }

    fun addTrainerTransaction(
        courseId: Long,
        courseName: String,
        amount: Double,
        date: String,
        type: String,
        note: String
    ) {
        viewModelScope.launch {
            repository.insertTrainerTransaction(
                TrainerTransaction(
                    courseId = courseId,
                    courseName = courseName,
                    amount = amount,
                    date = date,
                    type = type,
                    note = note
                )
            )
            logActivity(
                category = "FINANCIAL",
                actionType = "CREATE",
                title = "مستند مالية جديد ($type)",
                description = "مبلغ: $amount ر.س | البيان: ${note.ifEmpty { "بدون بيان" }} | الدورة: $courseName",
                relatedId = courseId,
                customDateStr = date
            )
        }
    }

    fun updateTrainerTransaction(transaction: TrainerTransaction) {
        viewModelScope.launch {
            repository.updateTrainerTransaction(transaction)
            logActivity(
                category = "FINANCIAL",
                actionType = "UPDATE",
                title = "تعديل مستند مالية (${transaction.type})",
                description = "مبلغ: ${transaction.amount} ر.س | البيان: ${transaction.note.ifEmpty { "بدون بيان" }}",
                relatedId = transaction.courseId,
                customDateStr = transaction.date
            )
        }
    }

    fun deleteTrainerTransaction(transaction: TrainerTransaction) {
        viewModelScope.launch {
            repository.deleteTrainerTransaction(transaction)
            logActivity(
                category = "FINANCIAL",
                actionType = "DELETE",
                title = "حذف مستند مالية (${transaction.type})",
                description = "مبلغ: ${transaction.amount} ر.س | البيان: ${transaction.note.ifEmpty { "بدون بيان" }}",
                relatedId = transaction.courseId,
                customDateStr = transaction.date
            )
        }
    }

    fun logActivity(
        category: String,
        actionType: String,
        title: String,
        description: String,
        relatedId: Long? = null,
        customDateStr: String? = null,
        customTimeStr: String? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = java.util.Date()
            val sdfDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH)
            val sdfTime = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ENGLISH)
            val dateStr = customDateStr ?: sdfDate.format(now)
            val timeStr = customTimeStr ?: sdfTime.format(now)

            val timestamp = if (!customDateStr.isNullOrEmpty()) {
                try {
                    sdfDate.parse(customDateStr)?.time ?: System.currentTimeMillis()
                } catch (e: Exception) {
                    System.currentTimeMillis()
                }
            } else {
                System.currentTimeMillis()
            }

            val log = AppActivityLog(
                timestamp = timestamp,
                dateStr = dateStr,
                timeStr = timeStr,
                category = category,
                actionType = actionType,
                title = title,
                description = description,
                relatedId = relatedId
            )
            repository.insertActivityLog(log)
        }
    }

    fun insertActivityLog(log: AppActivityLog) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertActivityLog(log)
        }
    }

    fun deleteActivityLog(log: AppActivityLog) {
        viewModelScope.launch {
            repository.deleteActivityLog(log)
        }
    }

    fun deleteAllActivityLogs() {
        viewModelScope.launch {
            repository.deleteAllActivityLogs()
            logActivity(
                category = "SYSTEM",
                actionType = "WIPE",
                title = "تفريغ سجل الحركات",
                description = "تم مسح وتفريغ سجل الحركات بالكامل"
            )
        }
    }

    fun wipeTrainerFinances() {
        viewModelScope.launch {
            repository.deleteAllTrainerTransactions()
            logActivity(
                category = "FINANCIAL",
                actionType = "WIPE",
                title = "تفريغ السجل المالي",
                description = "تم مسح جميع الحركات والمعاملات المالية"
            )
        }
    }

    // Assignment Template Operations
    fun insertAssignmentTemplate(template: SubjectAssignmentTemplate) {
        viewModelScope.launch {
            repository.insertAssignmentTemplate(template)
            logActivity(
                category = "CURRICULUM",
                actionType = "CREATE",
                title = "إضافة قالب تكليف/مشروع جديد: ${template.title}",
                description = "المادة: ${template.subjectName} | النوع: ${template.type} | الدرجة القصوى: ${template.maxScore}"
            )
        }
    }

    fun updateAssignmentTemplate(template: SubjectAssignmentTemplate) {
        viewModelScope.launch {
            repository.updateAssignmentTemplate(template)
            logActivity(
                category = "CURRICULUM",
                actionType = "UPDATE",
                title = "تعديل قالب تكليف/مشروع: ${template.title}",
                description = "المادة: ${template.subjectName} | النوع: ${template.type} | الدرجة القصوى: ${template.maxScore}"
            )
        }
    }

    fun deleteAssignmentTemplate(template: SubjectAssignmentTemplate) {
        viewModelScope.launch {
            repository.deleteAssignmentTemplate(template)
            logActivity(
                category = "CURRICULUM",
                actionType = "DELETE",
                title = "حذف قالب واجب: ${template.title}",
                description = "المادة: ${template.subjectName}"
            )
        }
    }

    fun deleteAssignmentTemplateFromCourse(template: SubjectAssignmentTemplate, courseId: Int) {
        viewModelScope.launch {
            if (template.courseId == courseId) {
                repository.deleteAssignmentTemplate(template)
                logActivity(
                    category = "CURRICULUM",
                    actionType = "DELETE",
                    title = "حذف مشروع خاص بالدورة: ${template.title}",
                    description = "الدورة: $courseId | المادة: ${template.subjectName}"
                )
            } else {
                val updated = template.withCourseExcluded(courseId)
                repository.updateAssignmentTemplate(updated)
                logActivity(
                    category = "CURRICULUM",
                    actionType = "UPDATE",
                    title = "استبعاد مشروع من الدورة: ${template.title}",
                    description = "تم استبعاد المشروع من الدورة $courseId فقط دون حذفه من القوالب العامة للمادة"
                )
            }
        }
    }

    fun restoreAssignmentTemplateToCourse(template: SubjectAssignmentTemplate, courseId: Int) {
        viewModelScope.launch {
            val updated = template.withCourseRestored(courseId)
            repository.updateAssignmentTemplate(updated)
            logActivity(
                category = "CURRICULUM",
                actionType = "UPDATE",
                title = "استعادة مشروع للدورة: ${template.title}",
                description = "تم إعادة تفعيل المشروع في الدورة $courseId"
            )
        }
    }

    fun exportAssignmentTemplateToGlobal(template: SubjectAssignmentTemplate, onFinished: (() -> Unit)? = null) {
        viewModelScope.launch {
            val globalCopy = template.copy(
                id = 0,
                courseId = 0,
                excludedCourseIdsJson = ""
            )
            repository.insertAssignmentTemplate(globalCopy)
            logActivity(
                category = "CURRICULUM",
                actionType = "CREATE",
                title = "تصدير مشروع إلى القوالب العامة: ${template.title}",
                description = "المادة: ${template.subjectName} | النوع: ${template.type} | الدرجة القصوى: ${template.maxScore}"
            )
            onFinished?.invoke()
        }
    }

    // Student Violation Operations
    fun insertViolation(violation: StudentViolation) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertViolation(violation)
            logActivity(
                category = "STUDENTS",
                actionType = "CREATE",
                title = "تسجيل مخالفة: ${violation.violationTitle}",
                description = "الطالب: ${violation.studentName} | الإجراء: ${violation.actionTaken} | التاريخ: ${violation.date}"
            )
        }
    }

    fun insertViolations(violations: List<StudentViolation>) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertViolations(violations)
            logActivity(
                category = "STUDENTS",
                actionType = "CREATE",
                title = "تسجيل مخالفة جماعية لـ ${violations.size} طلاب",
                description = "المخالفة: ${violations.firstOrNull()?.violationTitle ?: ""} | التاريخ: ${violations.firstOrNull()?.date ?: ""}"
            )
        }
    }

    fun updateViolation(violation: StudentViolation) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateViolation(violation)
            logActivity(
                category = "STUDENTS",
                actionType = "UPDATE",
                title = "تعديل مخالفة: ${violation.violationTitle}",
                description = "الطالب: ${violation.studentName} | الإجراء: ${violation.actionTaken}"
            )
        }
    }

    fun deleteViolation(violation: StudentViolation) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteViolation(violation)
            logActivity(
                category = "STUDENTS",
                actionType = "DELETE",
                title = "حذف مخالفة: ${violation.violationTitle}",
                description = "الطالب: ${violation.studentName}"
            )
        }
    }

    fun deleteViolationById(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteViolationById(id)
            logActivity(
                category = "STUDENTS",
                actionType = "DELETE",
                title = "حذف مخالفة",
                description = "رقم المعرف: $id"
            )
        }
    }

    fun deleteAllViolations() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAllViolations()
            logActivity(
                category = "STUDENTS",
                actionType = "DELETE",
                title = "تصفير ومسح جميع المخالفات",
                description = "تم مسح كافة سجلات المخالفات"
            )
        }
    }

    // SubjectReference operations
    fun insertSubjectReference(reference: com.example.data.entity.SubjectReference) {
        viewModelScope.launch {
            repository.insertSubjectReference(reference)
            logActivity(
                category = "CURRICULUM",
                actionType = "CREATE",
                title = "إضافة مرجع علمي: ${reference.title}",
                description = "المادة: ${reference.subjectName} | الرابط: ${reference.urlOrPath}"
            )
        }
    }

    fun updateSubjectReference(reference: com.example.data.entity.SubjectReference) {
        viewModelScope.launch {
            repository.updateSubjectReference(reference)
            logActivity(
                category = "CURRICULUM",
                actionType = "UPDATE",
                title = "تعديل مرجع علمي: ${reference.title}",
                description = "المادة: ${reference.subjectName} | الرابط: ${reference.urlOrPath}"
            )
        }
    }

    fun deleteSubjectReference(reference: com.example.data.entity.SubjectReference) {
        viewModelScope.launch {
            repository.deleteSubjectReference(reference)
            logActivity(
                category = "CURRICULUM",
                actionType = "DELETE",
                title = "حذف مرجع علمي: ${reference.title}",
                description = "تم إزالة الرابط المرجعي الخاص بمادة ${reference.subjectName}"
            )
        }
    }

    private val assignmentSubmissionMutex = kotlinx.coroutines.sync.Mutex()

    // Toggle Student Assignment Submission
    fun toggleStudentAssignmentSubmission(
        courseId: Int,
        subjectName: String,
        studentId: Int,
        studentName: String,
        assignmentTitle: String
    ) {
        viewModelScope.launch {
            assignmentSubmissionMutex.withLock {
                val existing = repository.getLatestAssignmentSubmissionDirect(
                    courseId = courseId,
                    subjectName = subjectName,
                    studentId = studentId,
                    assignmentTitle = assignmentTitle
                )
                val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
                val template = dbAssignmentTemplates.value.find {
                    it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true) &&
                    it.title.trim().equals(assignmentTitle.trim(), ignoreCase = true)
                }
                val tmplMaxScore = template?.maxScore ?: 10.0
                if (existing == null) {
                    repository.insertAssignmentSubmission(
                        StudentAssignmentSubmission(
                            courseId = courseId,
                            subjectName = subjectName,
                            studentId = studentId,
                            studentName = studentName,
                            assignmentTitle = assignmentTitle,
                            isCompleted = true,
                            completionDate = todayStr,
                            evaluationRating = "ممتاز",
                            score = tmplMaxScore
                        )
                    )
                    logActivity(
                        category = "CURRICULUM",
                        actionType = "CREATE",
                        title = "رصد تسليم تكليف للطالب: $studentName",
                        description = "التكليف: $assignmentTitle | المادة: $subjectName | الدرجة: $tmplMaxScore",
                        relatedId = courseId.toLong()
                    )
                } else {
                    val newCompleted = !existing.isCompleted
                    val rating = if (newCompleted) "ممتاز" else ""
                    val score = if (newCompleted) tmplMaxScore else 0.0
                    repository.updateAssignmentSubmission(
                        existing.copy(
                            isCompleted = newCompleted,
                            completionDate = if (newCompleted) todayStr else "",
                            evaluationRating = rating,
                            score = score
                        )
                    )
                    logActivity(
                        category = "CURRICULUM",
                        actionType = "UPDATE",
                        title = "تعديل حالة تسليم تكليف للطالب: $studentName",
                        description = "التكليف: $assignmentTitle | المادة: $subjectName | الحالة الجديدة: ${if (newCompleted) "مسلم" else "غير مسلم"} | الدرجة: $score",
                        relatedId = courseId.toLong()
                    )
                }
            }
            autoSyncGradesFromAttendanceAndAssignments(courseId)
        }
    }

    fun setStudentAssignmentRating(
        courseId: Int,
        subjectName: String,
        studentId: Int,
        studentName: String,
        assignmentTitle: String,
        rating: String,
        score: Double? = null
    ) {
        viewModelScope.launch {
            assignmentSubmissionMutex.withLock {
                val existing = repository.getLatestAssignmentSubmissionDirect(
                    courseId = courseId,
                    subjectName = subjectName,
                    studentId = studentId,
                    assignmentTitle = assignmentTitle
                )
                val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
                val isNotCompleted = rating == "غير مكتمل" || rating == "لم ينجز"
                val isComp = rating.isNotBlank() && !isNotCompleted
                val finalScore = score ?: if (isComp) {
                    val template = dbAssignmentTemplates.value.find {
                        (it.courseId == 0 || it.courseId == courseId) &&
                        it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true) &&
                        it.title.trim().equals(assignmentTitle.trim(), ignoreCase = true)
                    }
                    val tmplMax = template?.maxScore ?: 10.0
                    when (rating) {
                        "ممتاز" -> tmplMax
                        "جيد جداً" -> tmplMax * 0.75
                        "جيد" -> tmplMax * 0.50
                        "مقبول" -> tmplMax * 0.25
                        else -> 0.0
                    }
                } else 0.0

                if (existing == null) {
                    repository.insertAssignmentSubmission(
                        StudentAssignmentSubmission(
                            courseId = courseId,
                            subjectName = subjectName,
                            studentId = studentId,
                            studentName = studentName,
                            assignmentTitle = assignmentTitle,
                            isCompleted = isComp,
                            completionDate = if (isComp) todayStr else "",
                            evaluationRating = rating,
                            score = finalScore
                        )
                    )
                    logActivity(
                        category = "GRADES",
                        actionType = "CREATE",
                        title = "تقييم تكليف للطالب: $studentName",
                        description = "التكليف: $assignmentTitle | التقييم: $rating | الدرجة: $finalScore",
                        relatedId = courseId.toLong()
                    )
                } else {
                    repository.updateAssignmentSubmission(
                        existing.copy(
                            isCompleted = isComp,
                            completionDate = if (isComp) (if (existing.completionDate.isNotBlank()) existing.completionDate else todayStr) else "",
                            evaluationRating = rating,
                            score = finalScore
                        )
                    )
                    logActivity(
                        category = "GRADES",
                        actionType = "UPDATE",
                        title = "تحديث تقييم تكليف للطالب: $studentName",
                        description = "التكليف: $assignmentTitle | التقييم الجديد: $rating | الدرجة الجديدة: $finalScore",
                        relatedId = courseId.toLong()
                    )
                }
            }
            autoSyncGradesFromAttendanceAndAssignments(courseId)
        }
    }

    // Official Holidays
    fun insertOfficialHoliday(holiday: OfficialHoliday) {
        viewModelScope.launch {
            repository.officialHolidays.insertHoliday(holiday)
        }
    }

    fun updateOfficialHoliday(holiday: OfficialHoliday) {
        viewModelScope.launch {
            repository.officialHolidays.updateHoliday(holiday)
        }
    }

    fun toggleOfficialHoliday(holiday: OfficialHoliday) {
        viewModelScope.launch {
            repository.officialHolidays.updateHoliday(holiday.copy(isEnabled = !holiday.isEnabled))
        }
    }

    fun deleteOfficialHoliday(holiday: OfficialHoliday) {
        viewModelScope.launch {
            repository.officialHolidays.deleteHoliday(holiday)
        }
    }

    private fun normalizeDateForComparison(dateStr: String): String {
        if (dateStr.isBlank()) return ""
        val arabicDigits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
        val englishDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
        var clean = dateStr.trim()
        for (i in 0..9) {
            clean = clean.replace(arabicDigits[i], englishDigits[i])
        }
        val parts = clean.split("-")
        if (parts.size == 3) {
            val y = parts[0].toIntOrNull() ?: return clean
            val m = parts[1].toIntOrNull() ?: return clean
            val d = parts[2].toIntOrNull() ?: return clean
            return String.format(java.util.Locale.US, "%04d-%02d-%02d", y, m, d)
        }
        return clean
    }

    fun isDateOfficialHoliday(dateStr: String): Boolean {
        return getOfficialHolidayForDate(dateStr) != null
    }

    fun getOfficialHolidayForDate(dateStr: String): OfficialHoliday? {
        if (dateStr.isBlank()) return null
        val targetNorm = normalizeDateForComparison(dateStr)
        if (targetNorm.isEmpty()) return null
        return try {
            enabledOfficialHolidays.value.firstOrNull { holiday ->
                try {
                    if (!holiday.isEnabled || holiday.startDate.isBlank() || holiday.endDate.isBlank()) return@firstOrNull false
                    val startNorm = normalizeDateForComparison(holiday.startDate)
                    val endNorm = normalizeDateForComparison(holiday.endDate)
                    targetNorm >= startNorm && targetNorm <= endNorm
                } catch (e: Exception) {
                    false
                }
            }
        } catch (e: Exception) {
            null
        }
    }
}

enum class PendingActionType {
    TRAINER_CHECKIN_MISSING,
    TRAINER_CHECKOUT_MISSING,
    STUDENTS_UNREGISTERED,
    STUDENTS_WAITING_CHECKOUT,
    STUDENTS_ON_BREAK
}

data class PendingActionItem(
    val id: String,
    val type: PendingActionType,
    val title: String,
    val description: String,
    val count: Int = 1,
    val courseId: Int? = null,
    val courseName: String = "",
    val date: String = "",
    val dateFormatted: String = "",
    val suggestedCheckOutTime: String? = null,
    val suggestedCheckInTime: String? = null
)

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Activation : Screen("activation")
    object Register : Screen("register")
    object Login : Screen("login")
    object Selection : Screen("selection")
    object Courses : Screen("courses")
    object Attendance : Screen("attendance")
    object Reports : Screen("reports")
    object Students : Screen("students")
    object StudentAttendance : Screen("student_attendance")
    object StudentReports : Screen("student_reports")
    object InstituteSettings : Screen("institute_settings")
    object Grades : Screen("grades")
    object GradeReports : Screen("grade_reports")
    object BackupRestore : Screen("backup_restore")
    object ChangeCredentials : Screen("change_credentials")
    object AppFeaturesGuide : Screen("app_features_guide")
    object SmartSettings : Screen("smart_settings")
    object LessonPreparation : Screen("lesson_preparation")
    object Subjects : Screen("subjects")
    object OnboardingSetup : Screen("onboarding_setup")
    object TeachingStats : Screen("teaching_stats")
    object AssignmentSetup : Screen("assignment_setup")
    object SubjectReferences : Screen("subject_references")
    object TrainerFinances : Screen("trainer_finances")
    object ActivityLogs : Screen("activity_logs")
    object TheoryExamGrader : Screen("theory_exam_grader")
    object StudentViolations : Screen("student_violations")
    object CourseAttendanceAnalytics : Screen("course_attendance_analytics")
    object OfficialHolidays : Screen("official_holidays")
    object TrainerProfile : Screen("trainer_profile")

    // Tab Group Screens
    object TrainerGroup : Screen("trainer_group")
    object StudentsGroup : Screen("students_group")
    object CurriculumGroup : Screen("curriculum_group")
    object ReportsGroup : Screen("reports_group")
    object SettingsGroup : Screen("settings_group")
}
