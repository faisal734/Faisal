package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.CourseDao
import com.example.data.dao.AttendanceDao
import com.example.data.dao.StudentDao
import com.example.data.dao.StudentAttendanceDao
import com.example.data.dao.DailyCourseNoteDao
import com.example.data.dao.StudentGradeConfigDao
import com.example.data.dao.StudentGradeDao
import com.example.data.dao.LessonTopicDao
import com.example.data.dao.LessonSessionTopicDao
import com.example.data.dao.SubjectDao
import com.example.data.dao.TrainerTransactionDao
import com.example.data.entity.Course
import com.example.data.entity.Attendance
import com.example.data.entity.Student
import com.example.data.entity.StudentAttendance
import com.example.data.entity.DailyCourseNote
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentGradeConfig
import com.example.data.entity.LessonTopic
import com.example.data.entity.LessonSessionTopic
import com.example.data.entity.Subject
import com.example.data.entity.CourseSubjectCrossRef
import com.example.data.entity.TrainerTransaction

import com.example.data.dao.SubjectAssignmentTemplateDao
import com.example.data.dao.StudentAssignmentSubmissionDao
import com.example.data.dao.SubjectReferenceDao
import com.example.data.dao.AppActivityLogDao
import com.example.data.dao.StudentViolationDao
import com.example.data.dao.OfficialHolidayDao
import com.example.data.entity.SubjectAssignmentTemplate
import com.example.data.entity.StudentAssignmentSubmission
import com.example.data.entity.SubjectReference
import com.example.data.entity.AppActivityLog
import com.example.data.entity.StudentViolation
import com.example.data.entity.OfficialHoliday

@Database(
    entities = [
        Course::class,
        Attendance::class,
        Student::class,
        StudentAttendance::class,
        DailyCourseNote::class,
        StudentGrade::class,
        StudentGradeConfig::class,
        LessonTopic::class,
        LessonSessionTopic::class,
        Subject::class,
        CourseSubjectCrossRef::class,
        TrainerTransaction::class,
        SubjectAssignmentTemplate::class,
        StudentAssignmentSubmission::class,
        SubjectReference::class,
        AppActivityLog::class,
        StudentViolation::class,
        OfficialHoliday::class
    ],
    version = 30,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun courseDao(): CourseDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun studentDao(): StudentDao
    abstract fun studentAttendanceDao(): StudentAttendanceDao
    abstract fun dailyCourseNoteDao(): DailyCourseNoteDao
    abstract fun studentGradeConfigDao(): StudentGradeConfigDao
    abstract fun studentGradeDao(): StudentGradeDao
    abstract fun lessonTopicDao(): LessonTopicDao
    abstract fun lessonSessionTopicDao(): LessonSessionTopicDao
    abstract fun subjectDao(): SubjectDao
    abstract fun trainerTransactionDao(): TrainerTransactionDao
    abstract fun subjectAssignmentTemplateDao(): SubjectAssignmentTemplateDao
    abstract fun studentAssignmentSubmissionDao(): StudentAssignmentSubmissionDao
    abstract fun subjectReferenceDao(): SubjectReferenceDao
    abstract fun appActivityLogDao(): AppActivityLogDao
    abstract fun studentViolationDao(): StudentViolationDao
    abstract fun officialHolidayDao(): OfficialHolidayDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_24_25 = object : Migration(24, 25) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE courses ADD COLUMN isCompleted INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_25_26 = object : Migration(25, 26) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE students ADD COLUMN statusChangeDate TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_26_27 = object : Migration(26, 27) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE student_grade_configs ADD COLUMN passingGradePercentage REAL NOT NULL DEFAULT 75.0")
            }
        }

        val MIGRATION_27_28 = object : Migration(27, 28) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS official_holidays (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, startDate TEXT NOT NULL, endDate TEXT NOT NULL, isEnabled INTEGER NOT NULL DEFAULT 1, notes TEXT NOT NULL DEFAULT '')")
            }
        }

        val MIGRATION_28_29 = object : Migration(28, 29) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE subject_assignment_templates ADD COLUMN courseId INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE subject_assignment_templates ADD COLUMN excludedCourseIdsJson TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_29_30 = object : Migration(29, 30) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE attendance_records ADD COLUMN isExamDay INTEGER NOT NULL DEFAULT 0")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "dawami_database"
                )
                .addMigrations(MIGRATION_24_25, MIGRATION_25_26, MIGRATION_26_27, MIGRATION_27_28, MIGRATION_28_29, MIGRATION_29_30)
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
