package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "official_holidays")
data class OfficialHoliday(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val startDate: String,
    val endDate: String,
    val isEnabled: Boolean = true,
    val notes: String = ""
)
