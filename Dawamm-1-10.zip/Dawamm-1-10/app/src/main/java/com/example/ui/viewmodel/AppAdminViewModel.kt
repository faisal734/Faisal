package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.entity.AppActivityLog
import com.example.data.entity.TrainerTransaction
import com.example.data.repository.AppAdminRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * AppAdminViewModel: المسؤول الحصري عن العمليات الإدارية،
 * وسجلات نشاط النظام (AppActivityLog)، والعمليات المالية والعهد للمدرب (TrainerTransaction).
 */
class AppAdminViewModel(
    application: Application,
    private val appAdminRepository: AppAdminRepository = run {
        val database = AppDatabase.getDatabase(application)
        AppAdminRepository(
            database.trainerTransactionDao(),
            database.appActivityLogDao()
        )
    }
) : AndroidViewModel(application) {

    // --- تدفقات البيانات الشاملة (State Flows) ---
    val allTrainerTransactions: StateFlow<List<TrainerTransaction>> = appAdminRepository.allTrainerTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allActivityLogs: StateFlow<List<AppActivityLog>> = appAdminRepository.allActivityLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- العمليات المالية للمدرب (Trainer Transactions) ---
    fun addTrainerTransaction(
        courseId: Long,
        courseName: String,
        amount: Double,
        date: String,
        type: String,
        note: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            appAdminRepository.insertTrainerTransaction(
                TrainerTransaction(
                    courseId = courseId,
                    courseName = courseName,
                    amount = amount,
                    date = date,
                    type = type,
                    note = note
                )
            )
            logActivity(
                category = "FINANCIAL",
                actionType = "CREATE",
                title = "مستند مالية جديد ($type)",
                description = "مبلغ: $amount ر.س | البيان: ${note.ifEmpty { "بدون بيان" }} | الدورة: $courseName",
                relatedId = courseId,
                customDateStr = date
            )
        }
    }

    fun insertTrainerTransaction(tx: TrainerTransaction, onInserted: ((Long) -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = appAdminRepository.insertTrainerTransaction(tx)
            onInserted?.invoke(id)
        }
    }

    fun updateTrainerTransaction(tx: TrainerTransaction) {
        viewModelScope.launch(Dispatchers.IO) {
            appAdminRepository.updateTrainerTransaction(tx)
            logActivity(
                category = "FINANCIAL",
                actionType = "UPDATE",
                title = "تعديل مستند مالية (${tx.type})",
                description = "مبلغ: ${tx.amount} ر.س | البيان: ${tx.note.ifEmpty { "بدون بيان" }}",
                relatedId = tx.courseId,
                customDateStr = tx.date
            )
        }
    }

    fun deleteTrainerTransaction(tx: TrainerTransaction) {
        viewModelScope.launch(Dispatchers.IO) {
            appAdminRepository.deleteTrainerTransaction(tx)
            logActivity(
                category = "FINANCIAL",
                actionType = "DELETE",
                title = "حذف مستند مالية (${tx.type})",
                description = "مبلغ: ${tx.amount} ر.س | البيان: ${tx.note.ifEmpty { "بدون بيان" }}",
                relatedId = tx.courseId,
                customDateStr = tx.date
            )
        }
    }

    fun deleteAllTrainerTransactions() {
        viewModelScope.launch(Dispatchers.IO) {
            appAdminRepository.deleteAllTrainerTransactions()
        }
    }

    fun wipeTrainerFinances() {
        viewModelScope.launch(Dispatchers.IO) {
            appAdminRepository.deleteAllTrainerTransactions()
            logActivity(
                category = "FINANCIAL",
                actionType = "WIPE",
                title = "تفريغ السجل المالي",
                description = "تم مسح جميع الحركات والمعاملات المالية"
            )
        }
    }

    // --- سجلات النشاط والحركات (Activity Logs) ---
    fun logActivity(
        category: String,
        actionType: String,
        title: String,
        description: String,
        relatedId: Long? = null,
        customDateStr: String? = null,
        customTimeStr: String? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = Date()
            val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
            val sdfTime = SimpleDateFormat("HH:mm:ss", Locale.ENGLISH)
            val dateStr = customDateStr ?: sdfDate.format(now)
            val timeStr = customTimeStr ?: sdfTime.format(now)

            val timestamp = if (!customDateStr.isNullOrEmpty()) {
                try {
                    sdfDate.parse(customDateStr)?.time ?: System.currentTimeMillis()
                } catch (e: Exception) {
                    System.currentTimeMillis()
                }
            } else {
                System.currentTimeMillis()
            }

            val log = AppActivityLog(
                timestamp = timestamp,
                dateStr = dateStr,
                timeStr = timeStr,
                category = category,
                actionType = actionType,
                title = title,
                description = description,
                relatedId = relatedId
            )
            appAdminRepository.insertActivityLog(log)
        }
    }

    fun insertActivityLog(log: AppActivityLog) {
        viewModelScope.launch(Dispatchers.IO) {
            appAdminRepository.insertActivityLog(log)
        }
    }

    fun deleteActivityLog(log: AppActivityLog) {
        viewModelScope.launch(Dispatchers.IO) {
            appAdminRepository.deleteActivityLog(log)
        }
    }

    fun deleteAllActivityLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            appAdminRepository.deleteAllActivityLogs()
        }
    }
}
