package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.Attendance
import com.example.data.entity.Course
import com.example.data.entity.Subject
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------- REPORTS SCREEN (التقارير والبحث المتقدم) ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: MainViewModel,
    attendanceViewModel: AttendanceViewModel? = null,
    courseViewModel: CourseViewModel? = null,
    showMainLayout: Boolean = true
) {
    LaunchedEffect(Unit) {
        viewModel.updateReportFilter()
    }

    val dbAttendance by (attendanceViewModel?.allAttendance ?: viewModel.dbAttendance).collectAsState()
    val dbCourses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val showCompletedCourses by viewModel.showCompletedCoursesInDropdowns.collectAsState()
    val groupedReports by viewModel.groupedReports.collectAsState()
    val reportGroupingMode by viewModel.reportGroupingMode.collectAsState()
    val dbAllStudentAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()
    var expandedGroups by remember { mutableStateOf(setOf<String>()) }

    val courseFilter by viewModel.selectedCourseReportFilter.collectAsState()
    val subjectFilter by viewModel.selectedSubjectReportFilter.collectAsState()
    val dbSubjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()
    val dateFromFilter by viewModel.reportDateFromFilter.collectAsState()
    val dateToFilter by viewModel.reportDateToFilter.collectAsState()
    val courseStatusFilter by viewModel.selectedCourseStatusReportFilter.collectAsState()
    val statusFilter by viewModel.selectedStatusReportFilter.collectAsState()

    val context = LocalContext.current
    var isFiltersExpanded by remember { mutableStateOf(true) }
    var isFilterDropdownExpanded by remember { mutableStateOf(false) }
    var isSubjectFilterDropdownExpanded by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val pdfTeacherLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf"),
    ) { uri ->
        if (uri != null) {
            val recordsToExport = groupedReports.values.flatten()
            if (recordsToExport.isEmpty()) {
                Toast.makeText(context, "لا توجد سجلات لتصديرها! ❌", Toast.LENGTH_SHORT).show()
            } else {
                coroutineScope.launch(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                            com.example.ui.pdf.PdfReportHelper.exportTeacherReportsToPdf(
                                viewModel = viewModel,
                                reports = recordsToExport,
                                outputStream = outputStream
                            )
                        }
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "تم تصدير وحفظ تقرير المعلمين بصيغة PDF بنجاح! 📄💾", Toast.LENGTH_LONG).show()
                        }
                        viewModel.logActivity(
                            category = "SYSTEM",
                            actionType = "CREATE",
                            title = "تصدير تقرير المعلمين PDF 📄",
                            description = "تم تصدير وحفظ تقرير دوام المعلمين والمدربين كملف PDF بنجاح"
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "فشل تصدير ملف PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
    }

    MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->
        val flattenedTeacherItems = remember(groupedReports, expandedGroups) {
            buildList {
                groupedReports.forEach { (groupTitle, attendanceList) ->
                    val isExpanded = expandedGroups.contains(groupTitle)
                    add(GroupHeader(groupTitle, attendanceList.size, isExpanded))
                    if (isExpanded) {
                        addAll(attendanceList)
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            // Institute Official Header
            item {
                InstituteReportHeader(viewModel, "تقارير المدرب")
            }

            // Advanced Filters Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isFiltersExpanded = !isFiltersExpanded }
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.FilterList, contentDescription = null, tint = DawamiNavy)
                                Text("فلترة وتقارير البحث المتقدم", color = DawamiNavy, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Icon(
                                imageVector = if (isFiltersExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "طي وتوسيع",
                                tint = DawamiNavy
                            )
                        }

                        AnimatedVisibility(
                            visible = isFiltersExpanded,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Filter by Course Dropdown
                        ExposedDropdownMenuBox(
                            expanded = isFilterDropdownExpanded,
                            onExpandedChange = { isFilterDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = courseFilter,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("فلترة حسب الدورة التدريبية") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isFilterDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = isFilterDropdownExpanded,
                                onDismissRequest = { isFilterDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                            )
                                            Icon(
                                                imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = null,
                                                tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.toggleShowCompletedCoursesInDropdowns()
                                    }
                                )
                                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                                DropdownMenuItem(
                                    text = { Text("الكل (عرض جميع الدورات)") },
                                    onClick = {
                                        viewModel.updateReportFilter("الكل", dateFromFilter, dateToFilter, statusFilter = viewModel.selectedStatusReportFilter.value, courseStatusFilter = viewModel.selectedCourseStatusReportFilter.value, subjectFilter = subjectFilter)
                                        isFilterDropdownExpanded = false
                                    }
                                )
                                val displayedCourses = if (showCompletedCourses) dbCourses else dbCourses.filter { !it.isCompleted }
                                displayedCourses.forEach { course ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = if (course.isCompleted) "${course.name} (منتهية 🔒)" else course.name,
                                                color = if (course.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                            )
                                        },
                                        onClick = {
                                            viewModel.updateReportFilter(course.name, dateFromFilter, dateToFilter, statusFilter = viewModel.selectedStatusReportFilter.value, courseStatusFilter = viewModel.selectedCourseStatusReportFilter.value, subjectFilter = subjectFilter)
                                            isFilterDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Filter by Subject Dropdown
                        ExposedDropdownMenuBox(
                            expanded = isSubjectFilterDropdownExpanded,
                            onExpandedChange = { isSubjectFilterDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = subjectFilter,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("فلترة حسب المادة التدريبية 📖") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSubjectFilterDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = isSubjectFilterDropdownExpanded,
                                onDismissRequest = { isSubjectFilterDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("الكل (جميع المواد)") },
                                    onClick = {
                                        viewModel.updateReportFilter(courseFilter, dateFromFilter, dateToFilter, viewModel.selectedStatusReportFilter.value, viewModel.selectedCourseStatusReportFilter.value, "الكل")
                                        isSubjectFilterDropdownExpanded = false
                                    }
                                )
                                dbSubjects.forEach { subj ->
                                    DropdownMenuItem(
                                        text = { Text(subj.name) },
                                        onClick = {
                                            viewModel.updateReportFilter(courseFilter, dateFromFilter, dateToFilter, viewModel.selectedStatusReportFilter.value, viewModel.selectedCourseStatusReportFilter.value, subj.name)
                                            isSubjectFilterDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Date Ranges
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            com.example.ui.components.InlineExpandableDatePicker(
                                selectedDate = dateFromFilter,
                                onDateSelected = { viewModel.updateReportFilter(courseFilter, it, dateToFilter) },
                                label = "من تاريخ",
                                modifier = Modifier.weight(1f)
                            )

                            com.example.ui.components.InlineExpandableDatePicker(
                                selectedDate = dateToFilter,
                                onDateSelected = { viewModel.updateReportFilter(courseFilter, dateFromFilter, it) },
                                label = "إلى تاريخ",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Filter by Status (Custom Chips)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("فلترة حسب الحالة:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("الكل", "حضور", "غياب", "إجازة").forEach { statusOpt ->
                                    val isSelected = statusFilter == statusOpt
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                viewModel.updateReportFilter(courseFilter, dateFromFilter, dateToFilter, statusOpt)
                                            },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) DawamiTeal else Color(0xFFF1F5F9)
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, if (isSelected) DawamiTeal else Color(0xFFE2E8F0))
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = statusOpt,
                                                color = if (isSelected) Color.White else Color(0xFF475569),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Filter by Course Status (Custom Chips)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("حالة الدورة التدريبية:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("الكل", "نشطة", "منتهية").forEach { csOpt ->
                                    val isSelected = courseStatusFilter == csOpt
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                viewModel.updateReportFilter(courseStatusFilter = csOpt)
                                            },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) DawamiTeal else Color(0xFFF1F5F9)
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, if (isSelected) DawamiTeal else Color(0xFFE2E8F0))
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = csOpt,
                                                color = if (isSelected) Color.White else Color(0xFF475569),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Grouping Mode Toggle
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("تجميع نتائج التقارير حسب:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("التاريخ", "الدورة").forEach { modeOpt ->
                                    val isSelected = reportGroupingMode == modeOpt
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { viewModel.setReportGroupingMode(modeOpt) },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) DawamiNavy else Color(0xFFF1F5F9)
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, if (isSelected) DawamiNavy else Color(0xFFE2E8F0))
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = if (modeOpt == "التاريخ") "📅 حسب التاريخ" else "📚 حسب الدورة",
                                                color = if (isSelected) Color.White else Color(0xFF475569),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Clear filters button
                        if (courseFilter != "الكل" || subjectFilter != "الكل" || dateFromFilter.isNotEmpty() || dateToFilter.isNotEmpty() || statusFilter != "الكل" || courseStatusFilter != "الكل") {
                            OutlinedButton(
                                onClick = { viewModel.updateReportFilter("الكل", "", "", "الكل", "الكل", "الكل") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تصفية وإلغاء الفلاتر")
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Button(
                            onClick = {
                                val recordsToExport = groupedReports.values.flatten()
                                if (recordsToExport.isEmpty()) {
                                    Toast.makeText(context, "لا توجد سجلات لتصديرها! ❌", Toast.LENGTH_SHORT).show()
                                } else {
                                    val fileName = "dawami_teachers_report_${System.currentTimeMillis() / 1000}.pdf"
                                    if (viewModel.trainerBaseDirUri.value.isNotEmpty()) {
                                        coroutineScope.launch(Dispatchers.IO) {
                                            val success = viewModel.savePdfReportToReportsFolder(context, fileName) { outputStream ->
                                                com.example.ui.pdf.PdfReportHelper.exportTeacherReportsToPdf(
                                                    viewModel = viewModel,
                                                    reports = recordsToExport,
                                                    outputStream = outputStream
                                                )
                                            }
                                            withContext(Dispatchers.Main) {
                                                if (success) {
                                                    Toast.makeText(context, "تم حفظ تقرير المعلمين تلقائياً في مجلد Reports بنجاح! 📄⚡", Toast.LENGTH_LONG).show()
                                                    viewModel.logActivity(
                                                        category = "SYSTEM",
                                                        actionType = "CREATE",
                                                        title = "تصدير تقرير المعلمين PDF 📄",
                                                        description = "تم تصدير وحفظ تقرير دوام المعلمين والمدربين في مجلد Reports"
                                                    )
                                                } else {
                                                    pdfTeacherLauncher.launch(fileName)
                                                }
                                            }
                                        }
                                    } else {
                                        pdfTeacherLauncher.launch(fileName)
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تصدير التقرير كملف PDF 📄", fontWeight = FontWeight.Bold)
                        }
                            }
                        }
                    }
                }
            }

            // Report Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val filteredCount = groupedReports.values.sumOf { it.size }
                    Text(
                        text = "إحصائية السجلات حسب الفلترة المحددة",
                        color = DawamiNavy,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Badge(containerColor = DawamiGold) {
                        Text("${filteredCount} سجل", color = Color.White, modifier = Modifier.padding(2.dp))
                    }
                }
            }

            if (courseFilter.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = DawamiGold.copy(alpha = 0.08f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "الرجاء اختيار الدورة التدريبية أو 'الكل' من الأعلى لعرض تقارير الحضور 📋",
                            color = DawamiNavy,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp)
                        )
                    }
                }
            } else if (groupedReports.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Outlined.ContentPasteOff, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "لا توجد حركات حضور مسجلة تطابق خيارات الفلترة المحددة.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(flattenedTeacherItems, key = { item ->
                    when (item) {
                        is GroupHeader -> "teacher_header_${item.title}"
                        is Attendance -> "teacher_record_${item.id}"
                        else -> item.hashCode()
                    }
                }) { item ->
                    when (item) {
                        is GroupHeader -> {
                            val isGroupExpanded = item.isExpanded
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp)
                                    .clickable {
                                        expandedGroups = if (isGroupExpanded) {
                                            expandedGroups - item.title
                                        } else {
                                            expandedGroups + item.title
                                        }
                                    },
                                colors = CardDefaults.cardColors(containerColor = DawamiNavy.copy(alpha = 0.06f)),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isGroupExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = null,
                                            tint = DawamiNavy,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Text(
                                            text = item.title,
                                            color = DawamiNavy,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Badge(containerColor = DawamiGold) {
                                        Text("${item.size} حركات", color = Color.White, modifier = Modifier.padding(2.dp))
                                    }
                                }
                            }
                        }
                        is Attendance -> {
                            val record = item
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    // Date and Day of Week Row
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CalendarToday,
                                                contentDescription = null,
                                                tint = DawamiNavy,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = "التاريخ: ${record.date} (${record.dayOfWeek})",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = DawamiNavy
                                            )
                                        }
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            StatusBadge(status = record.status)
                                            if (record.isExamDay) {
                                                Surface(
                                                    color = Color(0xFFFEF3C7),
                                                    shape = RoundedCornerShape(4.dp),
                                                    border = BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.5f))
                                                ) {
                                                    Text(
                                                        text = "📝 امتحان",
                                                        fontSize = 8.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFFB45309),
                                                        maxLines = 1,
                                                        softWrap = false,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    val resolvedSubjectName = if (record.subjectName.isNotEmpty()) {
                                        record.subjectName
                                    } else {
                                        dbAllStudentAttendance.firstOrNull { studentAtt ->
                                            studentAtt.courseId == record.courseId && studentAtt.date == record.date && studentAtt.subjectName.isNotEmpty()
                                        }?.subjectName ?: ""
                                    }

                                    if (record.courseName.isNotEmpty() || resolvedSubjectName.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            if (record.courseName.isNotEmpty()) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Class,
                                                        contentDescription = null,
                                                        tint = DawamiNavy,
                                                        modifier = Modifier.size(13.dp)
                                                    )
                                                    Text(
                                                        text = "الدورة: ${record.courseName}",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = DawamiNavy
                                                    )
                                                }
                                            }
                                            if (resolvedSubjectName.isNotEmpty()) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.MenuBook,
                                                        contentDescription = null,
                                                        tint = DawamiTeal,
                                                        modifier = Modifier.size(13.dp)
                                                    )
                                                    Text(
                                                        text = "المادة: $resolvedSubjectName",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = DawamiTeal
                                                    )
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                    }

                                    Divider(color = Color(0xFFF1F5F9).copy(alpha = 0.8f), modifier = Modifier.padding(bottom = 8.dp))

                                    if (record.status == "حضور") {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text("التوقيت الفعلي للدوام", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                val checkOutValText = if (record.actualCheckOut.isEmpty()) "(بانتظار الخروج... ⏳)" else formatTimeTo12HourArabic(record.actualCheckOut)
                                                Text("من ${formatTimeTo12HourArabic(record.actualCheckIn)} إلى $checkOutValText", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (record.actualCheckOut.isEmpty()) Color(0xFFC2410C) else DawamiNavy)
                                            }

                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("مدة التواجد", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                val presenceDurationText = if (record.actualCheckOut.isEmpty()) "قيد الانتظار" else "${record.durationHours} ساعة و ${record.durationMinutes} دقيقة"
                                                Text(presenceDurationText, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (record.actualCheckOut.isEmpty()) Color(0xFFC2410C) else DawamiTeal)
                                            }
                                        }
                                    } else {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (record.status == "غياب") "❌ غياب المدرب عن هذه الدورة" else "🌴 إجازة مبررة للمدرب",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (record.status == "غياب") Color(0xFFEF4444) else Color(0xFFB45309)
                                            )
                                        }
                                    }

                                    // Delay & Status Badges
                                    if (record.status == "حضور") {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            val inDelay = record.checkInDelayMinutes
                                            val inStatusText = if (inDelay > 0) "تأخير دخول ($inDelay د)" else "حضور مثالي"
                                            val inColor = if (inDelay > 0) Color(0xFFEF4444) else DawamiTeal
                                            val inBgColor = if (inDelay > 0) Color(0xFFFEF2F2) else DawamiTeal.copy(alpha = 0.08f)

                                            Surface(
                                                color = inBgColor,
                                                shape = RoundedCornerShape(8.dp),
                                                border = BorderStroke(1.dp, inColor.copy(alpha = 0.3f))
                                            ) {
                                                Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Icon(if (inDelay > 0) Icons.Default.Warning else Icons.Default.CheckCircle, contentDescription = null, tint = inColor, modifier = Modifier.size(12.dp))
                                                    Text(inStatusText, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = inColor)
                                                }
                                            }

                                            val outStatusText = if (record.actualCheckOut.isEmpty()) {
                                                "بانتظار الخروج... ⏳"
                                            } else {
                                                val outDiff = record.checkOutDifferenceMinutes
                                                if (outDiff < 0) "انصراف مبكر (${-outDiff} د)" else if (outDiff > 0) "انصراف متأخر ($outDiff د)" else "انصراف مثالي"
                                            }
                                            val outColor = if (record.actualCheckOut.isEmpty()) Color(0xFFC2410C) else {
                                                val outDiff = record.checkOutDifferenceMinutes
                                                if (outDiff < 0) Color(0xFFD97706) else if (outDiff > 0) DawamiNavy else DawamiTeal
                                            }
                                            val outBgColor = if (record.actualCheckOut.isEmpty()) Color(0xFFFFF7ED) else {
                                                val outDiff = record.checkOutDifferenceMinutes
                                                if (outDiff < 0) Color(0xFFFFFBEB) else if (outDiff > 0) DawamiNavy.copy(alpha = 0.08f) else DawamiTeal.copy(alpha = 0.08f)
                                            }

                                            Surface(
                                                color = outBgColor,
                                                shape = RoundedCornerShape(8.dp),
                                                border = BorderStroke(1.dp, outColor.copy(alpha = 0.3f))
                                            ) {
                                                Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Icon(
                                                        imageVector = if (record.actualCheckOut.isEmpty()) Icons.Default.Schedule else if (record.checkOutDifferenceMinutes < 0) Icons.Default.Warning else Icons.Default.CheckCircle,
                                                        contentDescription = null,
                                                        tint = outColor,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                    Text(outStatusText, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = outColor)
                                                }
                                            }
                                        }
                                    }

                                    if (record.note.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text("📝 ملاحظة الحركة اليومية للأستاذ:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                            Text(record.note, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

