package com.example.notification

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.data.entity.Course
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

object NotificationHelper {

    @SuppressLint("ScheduleExactAlarm")
    fun scheduleCourseReminders(
        context: Context,
        course: Course,
        trainerMins: Int,
        studentCheckInMins: Int,
        studentCheckOutMins: Int
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val sharedPrefs = context.getSharedPreferences("dawami_prefs", Context.MODE_PRIVATE)

        // Cancel existing first to make sure there are no duplicates
        cancelCourseReminders(context, course.id)

        // Check if course is ended or completed; if so, do not schedule any reminder alarms
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val isCourseEnded = course.isCompleted || (course.endDate.isNotBlank() && course.endDate < todayStr)
        if (isCourseEnded) {
            return
        }

        val baseCode = course.id * 30

        // 1. Pre-Course Reminders (Smart Sequential 15m, 10m, 5m OR Choice of 15m / 10m / 5m)
        val isPrecourseSmart = sharedPrefs.getBoolean("is_precourse_smart_repeating", true)
        val precourseChoice = sharedPrefs.getInt("precourse_single_mins", trainerMins)
        val isPrecourseEnabled = sharedPrefs.getBoolean("is_trainer_start_reminder_enabled", true)
        if (isPrecourseEnabled) {
            if (isPrecourseSmart) {
                scheduleAlarm(
                    context, alarmManager, course.id, baseCode + 0, course.name, course.startTime, 15,
                    "trainer_start_15m", "الاستعداد للمحاضرة ⏰", "الرجاء الاستعداد للدورة، باقي من الوقت 15 دقيقة"
                )
                scheduleAlarm(
                    context, alarmManager, course.id, baseCode + 1, course.name, course.startTime, 10,
                    "trainer_start_10m", "الاستعداد للمحاضرة ⏰", "الرجاء الاستعداد للدورة، باقي من الوقت 10 دقائق"
                )
                scheduleAlarm(
                    context, alarmManager, course.id, baseCode + 2, course.name, course.startTime, 5,
                    "trainer_start_5m", "الاستعداد للمحاضرة ⏰", "الرجاء الاستعداد للدورة، باقي من الوقت 5 دقائق"
                )
            } else {
                when (precourseChoice) {
                    15 -> scheduleAlarm(context, alarmManager, course.id, baseCode + 0, course.name, course.startTime, 15, "trainer_start_15m", "الاستعداد للمحاضرة ⏰", "الرجاء الاستعداد للدورة، باقي من الوقت 15 دقيقة")
                    10 -> scheduleAlarm(context, alarmManager, course.id, baseCode + 1, course.name, course.startTime, 10, "trainer_start_10m", "الاستعداد للمحاضرة ⏰", "الرجاء الاستعداد للدورة، باقي من الوقت 10 دقائق")
                    5  -> scheduleAlarm(context, alarmManager, course.id, baseCode + 2, course.name, course.startTime, 5, "trainer_start_5m", "الاستعداد للمحاضرة ⏰", "الرجاء الاستعداد للدورة، باقي من الوقت 5 دقائق")
                    else -> scheduleAlarm(context, alarmManager, course.id, baseCode + 0, course.name, course.startTime, precourseChoice, "trainer_start", "الاستعداد للمحاضرة ⏰", "الرجاء الاستعداد للدورة، باقي من الوقت $precourseChoice دقائق")
                }
            }
        }

        // 2. Trainer Check-In + Sequential Reminders if unrecorded (5m, 10m, 30m, 1h)
        scheduleAlarm(
            context, alarmManager, course.id, baseCode + 3, course.name, course.startTime, 0,
            "trainer_checkin", "حافظة الدوام 📥", "الرجاء تحضير نفسك في حافظة الدوام"
        )
        val isUnrecordedRemindersEnabled = sharedPrefs.getBoolean("is_unrecorded_reminders_enabled", true)
        if (isUnrecordedRemindersEnabled) {
            scheduleAlarm(context, alarmManager, course.id, baseCode + 4, course.name, course.startTime, -5, "trainer_checkin_5m", "تذكير تحضير المدرب 📥", "تذكير: لم يتم تسجيل تحضيرك بعد 5 دقائق، الرجاء تحضير نفسك في حافظة الدوام")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 5, course.name, course.startTime, -10, "trainer_checkin_10m", "تذكير تحضير المدرب 📥", "تذكير: لم يتم تسجيل تحضيرك بعد 10 دقائق، الرجاء تحضير نفسك في حافظة الدوام")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 6, course.name, course.startTime, -30, "trainer_checkin_30m", "تذكير تحضير المدرب 📥", "تذكير: مضت 30 دقيقة ولم يتم تسجيل تحضير المدرب")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 7, course.name, course.startTime, -60, "trainer_checkin_60m", "تذكير تحضير المدرب 📥", "تذكير متأخر: مضت ساعة كاملة ولم يتم تسجيل تحضير المدرب")
        }

        // 3. Student Check-In + Sequential Reminders if unrecorded (5m, 10m, 30m, 1h)
        scheduleAlarm(
            context, alarmManager, course.id, baseCode + 10, course.name, course.startTime, -1,
            "student_checkin", "تحضير الطلاب 📝📥", "بدأت المحاضرة الرجاء تحضير الطلاب"
        )
        if (isUnrecordedRemindersEnabled) {
            scheduleAlarm(context, alarmManager, course.id, baseCode + 11, course.name, course.startTime, -6, "student_checkin_5m", "تذكير تحضير الطلاب 📝", "تذكير: مضت 5 دقائق ولم يتم تحضير جميع الطلاب")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 12, course.name, course.startTime, -11, "student_checkin_10m", "تذكير تحضير الطلاب 📝", "تذكير: مضت 10 دقائق ولم يتم تحضير جميع الطلاب")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 13, course.name, course.startTime, -31, "student_checkin_30m", "تذكير تحضير الطلاب 📝", "تذكير: مضت 30 دقيقة ولم يتم اكتمال تحضير الطلاب")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 14, course.name, course.startTime, -61, "student_checkin_60m", "تذكير تحضير الطلاب 📝", "تذكير متأخر: مضت ساعة كاملة ولم يتم اكتمال تحضير الطلاب")
        }

        // 4. Trainer Check-Out + Sequential Reminders if unrecorded (5m, 10m, 30m, 1h)
        scheduleAlarm(
            context, alarmManager, course.id, baseCode + 20, course.name, course.endTime, 0,
            "trainer_checkout", "انصراف الأستاذ 📤", "انتهى وقت المحاضرة الرجاء تسجيل انصرافك"
        )
        if (isUnrecordedRemindersEnabled) {
            scheduleAlarm(context, alarmManager, course.id, baseCode + 21, course.name, course.endTime, -5, "trainer_checkout_5m", "تذكير انصراف المدرب 📤", "تذكير: مضت 5 دقائق ولم يتم تسجيل انصراف المدرب")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 22, course.name, course.endTime, -10, "trainer_checkout_10m", "تذكير انصراف المدرب 📤", "تذكير: مضت 10 دقائق ولم يتم تسجيل انصراف المدرب")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 23, course.name, course.endTime, -30, "trainer_checkout_30m", "تذكير انصراف المدرب 📤", "تذكير: مضت 30 دقيقة ولم يتم تسجيل انصراف المدرب")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 24, course.name, course.endTime, -60, "trainer_checkout_60m", "تذكير انصراف المدرب 📤", "تذكير متأخر: مضت ساعة كاملة ولم يتم تسجيل انصراف المدرب")
        }

        // 5. Student Check-Out + Sequential Reminders if unrecorded (5m, 10m, 30m, 1h)
        val studentCheckOutDelay = if (studentCheckOutMins > 0) studentCheckOutMins else 3
        scheduleAlarm(
            context, alarmManager, course.id, baseCode + 25, course.name, course.endTime, -studentCheckOutDelay,
            "student_checkout", "انصراف الطلاب 📝📤", "حان وقت انصراف الطلاب"
        )
        if (isUnrecordedRemindersEnabled) {
            scheduleAlarm(context, alarmManager, course.id, baseCode + 26, course.name, course.endTime, -(studentCheckOutDelay + 5), "student_checkout_5m", "تذكير انصراف الطلاب 📝", "تذكير: مضت 5 دقائق ولم يتم تسجيل انصراف جميع الطلاب")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 27, course.name, course.endTime, -(studentCheckOutDelay + 10), "student_checkout_10m", "تذكير انصراف الطلاب 📝", "تذكير: مضت 10 دقائق ولم يتم تسجيل انصراف جميع الطلاب")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 28, course.name, course.endTime, -(studentCheckOutDelay + 30), "student_checkout_30m", "تذكير انصراف الطلاب 📝", "تذكير: مضت 30 دقيقة ولم يتم تسجيل انصراف جميع الطلاب")
            scheduleAlarm(context, alarmManager, course.id, baseCode + 29, course.name, course.endTime, -(studentCheckOutDelay + 60), "student_checkout_60m", "تذكير انصراف الطلاب 📝", "تذكير متأخر: مضت ساعة كاملة ولم يتم تسجيل انصراف جميع الطلاب")
        }
    }

    fun cancelCourseReminders(context: Context, courseId: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        // Cancel all potential AlarmManager codes across all base code multipliers (30, 20, 5)
        for (i in 0..35) {
            cancelAlarm(context, alarmManager, courseId * 30 + i)
            cancelAlarm(context, alarmManager, courseId * 20 + i)
            cancelAlarm(context, alarmManager, courseId * 5 + i)
        }
        
        // Cancel WorkManager tasks
        try {
            val workManager = WorkManager.getInstance(context)
            workManager.cancelUniqueWork("${courseId}_trainer_start")
            workManager.cancelUniqueWork("${courseId}_trainer_checkin")
            workManager.cancelUniqueWork("${courseId}_student_checkin")
            workManager.cancelUniqueWork("${courseId}_trainer_checkout")
            workManager.cancelUniqueWork("${courseId}_student_checkout")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @SuppressLint("ScheduleExactAlarm")
    private fun scheduleAlarm(
        context: Context,
        alarmManager: AlarmManager,
        courseId: Int,
        requestCode: Int,
        courseName: String,
        timeStr: String, // HH:mm
        minutesBefore: Int,
        type: String,
        title: String,
        message: String
    ) {
        val triggerMillis: Long = try {
            val arabic = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
            var cleanTime = timeStr.trim()
            for (i in arabic.indices) {
                cleanTime = cleanTime.replace(arabic[i], ('0' + i))
            }
            val parts = cleanTime.split(":")
            if (parts.size < 2) return
            val hour = parts[0].filter { it.isDigit() }.toIntOrNull() ?: return
            val minute = parts[1].filter { it.isDigit() }.toIntOrNull() ?: return

            val triggerCal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.MINUTE, -minutesBefore)
            }

            // If the time already passed for today, schedule it for tomorrow
            if (triggerCal.timeInMillis <= System.currentTimeMillis()) {
                triggerCal.add(Calendar.DAY_OF_YEAR, 1)
            }
            triggerCal.timeInMillis
        } catch (e: Exception) {
            return
        }

        try {
            // Intent to fire the alarm in NotificationReceiver
            val intent = Intent(context, NotificationReceiver::class.java).apply {
                putExtra("course_id", courseId)
                putExtra("course_name", courseName)
                putExtra("type", type)
                putExtra("title", title)
                putExtra("message", message)
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Intent to launch MainActivity when clicking the clock icon in system status bar
            val showIntent = Intent(context, com.example.MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val showPendingIntent = PendingIntent.getActivity(
                context,
                requestCode + 500000,
                showIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Top Priority: AlarmClockInfo (System Alarm Clock - Guaranteed to fire even in Doze Mode / Deep Sleep)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerMillis, showPendingIntent)
                alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
            }
        } catch (se: SecurityException) {
            // Fallback gracefully if exact alarm scheduling is restricted
            try {
                val intent = Intent(context, NotificationReceiver::class.java).apply {
                    putExtra("course_id", courseId)
                    putExtra("course_name", courseName)
                    putExtra("type", type)
                    putExtra("title", title)
                    putExtra("message", message)
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.set(
                        AlarmManager.RTC_WAKEUP,
                        triggerMillis,
                        pendingIntent
                    )
                }
            } catch (e2: Exception) {
                try {
                    val intent = Intent(context, NotificationReceiver::class.java).apply {
                        putExtra("course_id", courseId)
                        putExtra("course_name", courseName)
                        putExtra("type", type)
                        putExtra("title", title)
                        putExtra("message", message)
                    }
                    val pendingIntent = PendingIntent.getBroadcast(
                        context,
                        requestCode,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerMillis,
                            pendingIntent
                        )
                    } else {
                        alarmManager.set(
                            AlarmManager.RTC_WAKEUP,
                            triggerMillis,
                            pendingIntent
                        )
                    }
                } catch (e3: Exception) {
                    e3.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun cancelAlarm(context: Context, alarmManager: AlarmManager, requestCode: Int) {
        val intent = Intent(context, NotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
        val showIntent = Intent(context, com.example.MainActivity::class.java)
        val showPendingIntent = PendingIntent.getActivity(
            context,
            requestCode + 500000,
            showIntent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        showPendingIntent?.cancel()
    }

    fun scheduleAllActiveCourseReminders(context: Context) {
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val db = com.example.data.database.AppDatabase.getDatabase(context)
                val sharedPrefs = context.getSharedPreferences("dawami_prefs", Context.MODE_PRIVATE)
                val isSmartEnabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
                if (!isSmartEnabled) return@launch

                val trainerMins = sharedPrefs.getInt("trainer_reminder_minutes", 15)
                val checkInMins = sharedPrefs.getInt("student_check_in_reminder_minutes", 10)
                val checkOutMins = sharedPrefs.getInt("student_check_out_reminder_minutes", 10)

                val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                val courses = db.courseDao().getAllCoursesSync()
                courses.filter { !it.isCompleted && (it.endDate.isBlank() || it.endDate >= todayStr) }.forEach { course ->
                    scheduleCourseReminders(context, course, trainerMins, checkInMins, checkOutMins)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
