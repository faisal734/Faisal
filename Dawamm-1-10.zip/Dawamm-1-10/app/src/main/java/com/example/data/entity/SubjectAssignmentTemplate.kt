package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subject_assignment_templates")
data class SubjectAssignmentTemplate(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectName: String,
    val title: String,
    val description: String = "",
    val type: String = "مشروع عملي", // "مشروع عملي" or "بحث نظري"
    val maxScore: Double = 10.0,
    val displayOrder: Int = 0,
    val attachmentPath: String = "",
    val attachmentName: String = "",
    val courseId: Int = 0, // 0 = Global Master template for the subject, > 0 = Course specific
    val excludedCourseIdsJson: String = "" // Comma-separated list of course IDs that excluded this template
) {
    fun isExcludedForCourse(targetCourseId: Int): Boolean {
        if (targetCourseId <= 0) return false
        if (courseId > 0 && courseId != targetCourseId) return true
        if (excludedCourseIdsJson.isBlank()) return false
        return excludedCourseIdsJson.split(",").mapNotNull { it.trim().toIntOrNull() }.contains(targetCourseId)
    }

    fun isApplicableForCourse(targetCourseId: Int): Boolean {
        if (targetCourseId <= 0) return courseId == 0
        if (courseId > 0) return courseId == targetCourseId
        return !isExcludedForCourse(targetCourseId)
    }

    fun withCourseExcluded(targetCourseId: Int): SubjectAssignmentTemplate {
        val currentIds = excludedCourseIdsJson.split(",").mapNotNull { it.trim().toIntOrNull() }.toMutableSet()
        currentIds.add(targetCourseId)
        return copy(excludedCourseIdsJson = currentIds.joinToString(","))
    }

    fun withCourseRestored(targetCourseId: Int): SubjectAssignmentTemplate {
        val currentIds = excludedCourseIdsJson.split(",").mapNotNull { it.trim().toIntOrNull() }.toMutableSet()
        currentIds.remove(targetCourseId)
        return copy(excludedCourseIdsJson = currentIds.joinToString(","))
    }
}
