package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Palette derived from the Dawami Emblem & Logo - Vibrant Modern Palette
var DawamiNavy = Color(0xFF0D7A68) // Vibrant Emerald Teal Primary
var DawamiGold = Color(0xFFF59E0B) // Radiant Amber Accent
var DawamiTeal = Color(0xFF06B6D4) // Electric Cyan Teal Secondary

val Navy80 = Color(0xFF2DD4BF) // Mint Cyan 400
val Gold80 = Color(0xFFFCD34D) // Amber 300
val Teal80 = Color(0xFF67E8F9) // Cyan 300

// Refined Light Palette
val LightBackground = Color(0xFFF8FAFC) // Crisp Slate Soft Mint Tint Background
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOutline = Color(0xFFE2E8F0)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)

// Refined Dark Palette
val DarkBackground = Color(0xFF0B131E) // Deep Modern Dark Slate
val DarkSurface = Color(0xFF152232) // Elevated Dark Surface Card
val DarkSurfaceVariant = Color(0xFF1E2E42) // Secondary Dark Surface
val DarkOutline = Color(0xFF2B3E56) // Subtle Dark Border
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)




