package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_course_notes")
data class DailyCourseNote(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val courseId: Int,
    val date: String, // format: "yyyy-MM-dd"
    val note: String
)
