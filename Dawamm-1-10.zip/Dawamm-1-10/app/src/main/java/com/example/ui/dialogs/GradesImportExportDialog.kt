package com.example.ui.dialogs

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentGradeConfig
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.GradingViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.utils.AudioPlayerHelper
import com.example.utils.GradeImportResult
import com.example.utils.GradeTemplateType
import com.example.utils.GradesExcelHelper
import com.example.utils.ParsedGradeRow
import java.util.Locale
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GradesImportExportDialog(
    course: Course,
    allCourseStudents: List<Student>,
    config: StudentGradeConfig?,
    existingGrades: List<StudentGrade>,
    currentSelectedSubject: String,
    viewModel: MainViewModel,
    gradingViewModel: GradingViewModel? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(0) } // 0: Export Template, 1: Import Grades

    // --- State for Export Tab ---
    var selectedExportType by remember { mutableStateOf(GradeTemplateType.DETAILED_ITEMS) }
    val subjectsList = remember(config, currentSelectedSubject) {
        val rawSubjects = if (config?.isDiploma == true) {
            config.getDiplomaSubjects()
        } else if (config != null) {
            val cFields = StudentGradeConfig.deserializeFields(config.customFieldsJson)
            val subs = cFields.map { it.first.substringBefore("_") }.distinct()
            if (subs.isNotEmpty()) subs else listOf("المقرر العام")
        } else {
            listOf(currentSelectedSubject.ifBlank { "المقرر العام" })
        }
        val list = mutableListOf<String>()
        list.add(GradesExcelHelper.ALL_SUBJECTS_HORIZONTAL)
        list.addAll(rawSubjects)
        list.distinct()
    }
    var selectedSubjectForExport by remember { 
        mutableStateOf(GradesExcelHelper.ALL_SUBJECTS_HORIZONTAL) 
    }
    var isSubjectDropdownExpanded by remember { mutableStateOf(false) }

    // --- State for Import Tab ---
    var importResult by remember { mutableStateOf<GradeImportResult?>(null) }
    var selectedImportFileUri by remember { mutableStateOf<Uri?>(null) }
    var isImportingInProgress by remember { mutableStateOf(false) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImportFileUri = uri
            val allSubjs = subjectsList.filter { it != GradesExcelHelper.ALL_SUBJECTS_HORIZONTAL }
            val res = GradesExcelHelper.parseGradesFile(
                context = context,
                fileUri = uri,
                courseId = course.id,
                defaultSubjectName = if (selectedSubjectForExport == GradesExcelHelper.ALL_SUBJECTS_HORIZONTAL) (allSubjs.firstOrNull() ?: "المقرر العام") else selectedSubjectForExport,
                courseStudents = allCourseStudents,
                config = config,
                courseSubjects = allSubjs
            )
            importResult = res
            if (res.isSuccess) {
                Toast.makeText(context, "تمت قراءة الملف بنجاح! تم التعرف على (${res.matchedCount}) طالب جاهز للاستيراد 📄✅", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, res.errorOrWarningMessage ?: "فشل قراءة الملف", Toast.LENGTH_LONG).show()
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding(),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Dialog Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onDismiss) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع",
                                tint = DawamiNavy
                            )
                        }
                        Surface(
                            color = DawamiNavy.copy(alpha = 0.1f),
                            shape = CircleShape,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.TableView, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(20.dp))
                            }
                        }
                        Column {
                            Text(
                                text = "تصدير واستيراد الدرجات من Excel / CSV",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp,
                                color = DawamiNavy
                            )
                            Text(
                                text = "دورة: ${course.name} (${allCourseStudents.size} طالب)",
                                fontSize = 11.5.sp,
                                color = Color.Gray
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.Gray)
                    }
                }

                // Top Mode Tabs (Export Template vs Import Grades)
                TabRow(
                    selectedTabIndex = activeTab,
                    containerColor = DawamiNavy.copy(alpha = 0.06f),
                    contentColor = DawamiNavy,
                    indicator = {},
                    divider = {},
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .padding(2.dp)
                ) {
                    Tab(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (activeTab == 0) DawamiNavy else Color.Transparent)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.FileDownload,
                                contentDescription = null,
                                tint = if (activeTab == 0) Color.White else DawamiNavy,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "1. تصدير النموذج المعتمد 📤",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = if (activeTab == 0) Color.White else DawamiNavy
                            )
                        }
                    }

                    Tab(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (activeTab == 1) DawamiNavy else Color.Transparent)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.FileUpload,
                                contentDescription = null,
                                tint = if (activeTab == 1) Color.White else DawamiNavy,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "2. استيراد ورصد الدرجات 📥",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = if (activeTab == 1) Color.White else DawamiNavy
                            )
                        }
                    }
                }

                // Tab Contents
                Box(modifier = Modifier.weight(1f)) {
                    if (activeTab == 0) {
                        // ================= TAB 1: EXPORT TEMPLATE =================
                        ExportTemplateContent(
                            course = course,
                            students = allCourseStudents,
                            config = config,
                            existingGrades = existingGrades,
                            subjectsList = subjectsList,
                            selectedSubject = selectedSubjectForExport,
                            selectedExportType = selectedExportType,
                            isSubjectDropdownExpanded = isSubjectDropdownExpanded,
                            onSubjectSelected = { selectedSubjectForExport = it },
                            onToggleDropdown = { isSubjectDropdownExpanded = it },
                            onExportTypeChanged = { selectedExportType = it },
                            onExportClick = { type ->
                                val allSubjs = subjectsList.filter { it != GradesExcelHelper.ALL_SUBJECTS_HORIZONTAL }
                                val file = GradesExcelHelper.generateAndExportTemplate(
                                    context = context,
                                    course = course,
                                    subjectName = selectedSubjectForExport,
                                    allSubjects = allSubjs,
                                    students = allCourseStudents,
                                    config = config,
                                    existingGrades = existingGrades,
                                    templateType = type,
                                    trainerBaseDirUri = viewModel.trainerBaseDirUri.value
                                )
                                if (file != null) {
                                    Toast.makeText(context, "تم حفظ وتصدير الكشف بنجاح في مجلد التقارير (Reports)! 📄💾", Toast.LENGTH_LONG).show()
                                    GradesExcelHelper.shareTemplateFile(context, file, course.name, selectedSubjectForExport)
                                } else {
                                    Toast.makeText(context, "حدث خطأ أثناء تصدير الملف ❌", Toast.LENGTH_LONG).show()
                                }
                            }
                        )
                    } else {
                        // ================= TAB 2: IMPORT GRADES =================
                        ImportGradesContent(
                            course = course,
                            config = config,
                            existingGrades = existingGrades,
                            defaultSubject = selectedSubjectForExport,
                            importResult = importResult,
                            selectedFileUri = selectedImportFileUri,
                            isImportingInProgress = isImportingInProgress,
                            viewModel = viewModel,
                            onPickFileClick = {
                                filePickerLauncher.launch(
                                    arrayOf(
                                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                        "application/vnd.ms-excel",
                                        "application/x-excel",
                                        "text/comma-separated-values",
                                        "text/csv",
                                        "text/tab-separated-values",
                                        "text/plain",
                                        "*/*"
                                    )
                                )
                            },
                            onCommitGrades = { parsedRows ->
                                isImportingInProgress = true
                                val gradeEntities = GradesExcelHelper.convertParsedRowsToStudentGrades(
                                    parsedRows = parsedRows,
                                    course = course,
                                    defaultSubject = selectedSubjectForExport,
                                    existingGrades = existingGrades
                                )

                                if (gradeEntities.isEmpty()) {
                                    Toast.makeText(context, "لا توجد درجات مطابقة صالحة للحفظ! ⚠️", Toast.LENGTH_LONG).show()
                                    isImportingInProgress = false
                                    return@ImportGradesContent
                                }

                                val newCourseMode = if (importResult?.detectedType == GradeTemplateType.DIRECT_FINAL) "MANUAL_FINAL" else "MANUAL_BREAKDOWN"
                                viewModel.setCourseGradingMode(course.id, newCourseMode)
                                gradingViewModel?.setCourseGradingMode(course.id, newCourseMode)

                                if (gradingViewModel != null) {
                                    gradingViewModel.saveStudentGradesBulk(gradeEntities) { count ->
                                        isImportingInProgress = false
                                        val gender = viewModel.voiceGender.value
                                        AudioPlayerHelper.playAudioOrSpeak(context, null, "تم استيراد ورصد درجات الطلاب بنجاح", gender)
                                        Toast.makeText(context, "تم استيراد واعتماد درجات ($count) طالب بنجاح! 🎉💾", Toast.LENGTH_LONG).show()
                                        onDismiss()
                                    }
                                } else {
                                    viewModel.saveStudentGradesBulk(gradeEntities) { count ->
                                        isImportingInProgress = false
                                        val gender = viewModel.voiceGender.value
                                        AudioPlayerHelper.playAudioOrSpeak(context, null, "تم استيراد ورصد درجات الطلاب بنجاح", gender)
                                        Toast.makeText(context, "تم استيراد واعتماد درجات ($count) طالب بنجاح! 🎉💾", Toast.LENGTH_LONG).show()
                                        onDismiss()
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

// --- Composable: Export Template Content ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExportTemplateContent(
    course: Course,
    students: List<Student>,
    config: StudentGradeConfig?,
    existingGrades: List<StudentGrade>,
    subjectsList: List<String>,
    selectedSubject: String,
    selectedExportType: GradeTemplateType,
    isSubjectDropdownExpanded: Boolean,
    onSubjectSelected: (String) -> Unit,
    onToggleDropdown: (Boolean) -> Unit,
    onExportTypeChanged: (GradeTemplateType) -> Unit,
    onExportClick: (GradeTemplateType) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Step 1: Info Guide & Reports Folder
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DawamiTeal.copy(alpha = 0.08f)),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(20.dp))
                        Text(
                            text = "مجلد الحفظ والتصدير: مجلد التقارير (Reports) 📁",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = DawamiNavy
                        )
                    }
                    Text(
                        text = "يتم تصدير وحفظ ملفات إكسل المعتمدة (.xlsx) مباشرة بتنسيق الجداول والألوان والاتجاه العربي، داخل مجلد التقارير (Reports).",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 15.sp
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = DawamiGold.copy(alpha = 0.15f),
                        border = BorderStroke(0.5.dp, DawamiGold.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "💡 ميزة الأعمدة العريضة: تجمع مواد الدورة جنباً إلى جنب في نفس الورقة مع احتساب المجموع والمعدل العام.",
                            fontSize = 9.5.sp,
                            color = DawamiNavy,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Step 2: Choose Subject
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "اختر المادة المراد تصدير كشفها:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp,
                        color = DawamiNavy
                    )
                    ExposedDropdownMenuBox(
                        expanded = isSubjectDropdownExpanded,
                        onExpandedChange = { onToggleDropdown(it) }
                    ) {
                        OutlinedTextField(
                            value = selectedSubject,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSubjectDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                            textStyle = TextStyle(fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        )
                        ExposedDropdownMenu(
                            expanded = isSubjectDropdownExpanded,
                            onDismissRequest = { onToggleDropdown(false) }
                        ) {
                            subjectsList.forEach { sub ->
                                DropdownMenuItem(
                                    text = { Text(sub, fontSize = 11.sp) },
                                    onClick = {
                                        onSubjectSelected(sub)
                                        onToggleDropdown(false)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Step 3: Choose Template Type (Detailed vs Direct Final)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "اختر نمط الرصد المطلوب في النموذج:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.5.sp,
                    color = DawamiNavy
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Option 1: Detailed Items
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onExportTypeChanged(GradeTemplateType.DETAILED_ITEMS) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedExportType == GradeTemplateType.DETAILED_ITEMS) DawamiNavy.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(
                            1.5.dp,
                            if (selectedExportType == GradeTemplateType.DETAILED_ITEMS) DawamiNavy else Color(0xFFCBD5E1)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("📋 رصد تفصيلي بالبنود", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = DawamiNavy)
                                RadioButton(
                                    selected = selectedExportType == GradeTemplateType.DETAILED_ITEMS,
                                    onClick = { onExportTypeChanged(GradeTemplateType.DETAILED_ITEMS) },
                                    colors = RadioButtonDefaults.colors(selectedColor = DawamiNavy)
                                )
                            }
                            Text(
                                text = if (config?.isDiploma == true) "حضور (5)، مشاركة (5)، واجبات (10)، مشاريع (20)، نظري (20)، عملي (40)" else "أعمدة مفصلة لبنود التقييم المعتمدة للمادة",
                                fontSize = 9.5.sp,
                                color = Color.Gray,
                                lineHeight = 14.sp
                            )
                        }
                    }

                    // Option 2: Direct Final Total
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onExportTypeChanged(GradeTemplateType.DIRECT_FINAL) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedExportType == GradeTemplateType.DIRECT_FINAL) DawamiTeal.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(
                            1.5.dp,
                            if (selectedExportType == GradeTemplateType.DIRECT_FINAL) DawamiTeal else Color(0xFFCBD5E1)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🎯 رصد نهائي مباشر", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = DawamiTeal)
                                RadioButton(
                                    selected = selectedExportType == GradeTemplateType.DIRECT_FINAL,
                                    onClick = { onExportTypeChanged(GradeTemplateType.DIRECT_FINAL) },
                                    colors = RadioButtonDefaults.colors(selectedColor = DawamiTeal)
                                )
                            }
                            Text(
                                text = "عمود واحد للدرجة النهائية من 100 مع احتساب التقدير والملاحظات مباشرة",
                                fontSize = 9.5.sp,
                                color = Color.Gray,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Step 4: Export Action Button
        item {
            Button(
                onClick = { onExportClick(selectedExportType) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "تصدير وفتح النموذج في Excel / وتطبيقات الجداول 📤",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

// --- Helper: Format Score cleanly ---
private fun fmtScore(v: Double): String {
    return if (v % 1.0 == 0.0) v.toInt().toString() else String.format(Locale.US, "%.1f", v)
}

// --- Composable: Import Grades Content & Interactive Preview ---
@Composable
private fun ImportGradesContent(
    course: Course,
    config: StudentGradeConfig?,
    existingGrades: List<StudentGrade>,
    defaultSubject: String,
    importResult: GradeImportResult?,
    selectedFileUri: Uri?,
    isImportingInProgress: Boolean,
    viewModel: MainViewModel,
    onPickFileClick: () -> Unit,
    onCommitGrades: (List<ParsedGradeRow>) -> Unit
) {
    var editableRows by remember(importResult) {
        mutableStateOf(importResult?.parsedRows?.map { it.copy() } ?: emptyList())
    }

    var autoExcludeUntakenSubjects by remember { mutableStateOf(true) }
    var pendingRowsForTransition by remember { mutableStateOf<List<ParsedGradeRow>?>(null) }
    var transitionInfoToConfirm by remember { mutableStateOf<GradingModeTransitionInfo?>(null) }

    val courseGradingModes by viewModel.courseGradingModes.collectAsState()
    val configuredModeStr = courseGradingModes[course.id] ?: viewModel.getCourseGradingMode(course.id)

    val currentCourseGradingMode = remember(existingGrades, configuredModeStr) {
        when (configuredModeStr) {
            "MANUAL_FINAL" -> CourseGradingMode.MANUAL_FINAL
            "MANUAL_BREAKDOWN" -> CourseGradingMode.MANUAL_DETAILED
            "AUTO" -> CourseGradingMode.AUTO_CALCULATED
            else -> when {
                existingGrades.any { it.isManualFinalGrading() } -> CourseGradingMode.MANUAL_FINAL
                existingGrades.any { it.isManualGrading() } -> CourseGradingMode.MANUAL_DETAILED
                else -> CourseGradingMode.AUTO_CALCULATED
            }
        }
    }

    val importedTargetMode = remember(importResult?.detectedType) {
        if (importResult?.detectedType == GradeTemplateType.DIRECT_FINAL) {
            CourseGradingMode.MANUAL_FINAL
        } else {
            CourseGradingMode.MANUAL_DETAILED
        }
    }

    // Identify subjects that have NEVER been graded in this course AND have all-zero scores in the imported file
    val untakenSubjectNames = remember(editableRows, existingGrades) {
        val subjectGroups = editableRows.groupBy { it.subjectName.trim() }
        subjectGroups.keys.filter { subName ->
            val hasExistingGrades = existingGrades.any {
                it.subjectName.trim().equals(subName, ignoreCase = true) && it.getTotalScore() > 0.0
            }
            val hasFileGrades = subjectGroups[subName]?.any { it.calculateTotal() > 0.0 } ?: false
            !hasExistingGrades && !hasFileGrades
        }.toSet()
    }

    val excludedUntakenIndices = remember(editableRows, untakenSubjectNames, autoExcludeUntakenSubjects) {
        if (!autoExcludeUntakenSubjects) emptySet()
        else editableRows.indices.filter { untakenSubjectNames.contains(editableRows[it].subjectName.trim()) }.toSet()
    }

    // Set of selected row indices (0 .. editableRows.size - 1)
    var selectedRowIndices by remember(editableRows.size, excludedUntakenIndices) {
        mutableStateOf(
            editableRows.indices.filter { 
                editableRows[it].isMatchedStudent && !excludedUntakenIndices.contains(it) 
            }.toSet()
        )
    }

    // Filter Tab: 0 = الكل, 1 = المعدلة والجديدة, 2 = المحددة للاعتماد, 3 = المستبعدة تلقائياً
    var filterTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    fun getRowExisting(r: ParsedGradeRow): StudentGrade? {
        return existingGrades.find {
            it.studentId == r.studentId &&
            (it.subjectName.trim().equals(r.subjectName.trim(), ignoreCase = true) ||
             (r.subjectName.isBlank() && it.subjectName.isBlank()))
        }
    }

    fun isRowChangedOrNew(r: ParsedGradeRow): Boolean {
        if (!r.isMatchedStudent) return false
        val eg = getRowExisting(r)
        val prevTotal = if (eg != null && eg.getTotalScore() > 0.0) eg.getTotalScore() else null
        val curTotal = r.calculateTotal()
        if (prevTotal == null) return curTotal > 0.0
        return abs(curTotal - prevTotal) > 0.01
    }

    val changedOrNewIndices = remember(editableRows, existingGrades) {
        editableRows.indices.filter { isRowChangedOrNew(editableRows[it]) }.toSet()
    }

    val displayedIndices = remember(filterTab, editableRows, selectedRowIndices, changedOrNewIndices, excludedUntakenIndices, searchQuery) {
        val base = when (filterTab) {
            1 -> editableRows.indices.filter { changedOrNewIndices.contains(it) }
            2 -> editableRows.indices.filter { selectedRowIndices.contains(it) }
            3 -> editableRows.indices.filter { excludedUntakenIndices.contains(it) }
            else -> editableRows.indices.toList()
        }
        if (searchQuery.isBlank()) {
            base
        } else {
            val q = searchQuery.trim().lowercase()
            base.filter { idx ->
                val r = editableRows[idx]
                r.studentName.lowercase().contains(q) ||
                r.subjectName.lowercase().contains(q) ||
                (r.studentId > 0 && r.studentId.toString().contains(q))
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // File Pick Area
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onPickFileClick() },
            colors = CardDefaults.cardColors(
                containerColor = if (selectedFileUri != null) Color(0xFFF0FDF4) else DawamiNavy.copy(alpha = 0.04f)
            ),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(
                1.2.dp,
                if (selectedFileUri != null) Color(0xFF10B981) else DawamiNavy.copy(alpha = 0.2f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (selectedFileUri != null) Color(0xFF10B981).copy(alpha = 0.15f) else DawamiNavy.copy(alpha = 0.1f),
                        shape = CircleShape,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (selectedFileUri != null) Icons.Default.CheckCircle else Icons.Default.FileUpload,
                                contentDescription = null,
                                tint = if (selectedFileUri != null) Color(0xFF10B981) else DawamiNavy,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f, fill = false)) {
                        Text(
                            text = if (selectedFileUri != null) "تم اختيار وقراءة الملف بنجاح ✓" else "اضغط هنا لاختيار ملف الدرجات (Excel .xlsx)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = if (selectedFileUri != null) Color(0xFF166534) else DawamiNavy,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (importResult != null) "نمط الرصد: ${if (importResult.detectedType == GradeTemplateType.DIRECT_FINAL) "رصد نهائي مباشر 🎯" else "رصد تفصيلي بالبنود 📋"}" else "يدعم ملفات إكسل (.xlsx) المعتمدة وكذلك ملفات الجداول الجاهزة",
                            fontSize = 10.sp,
                            color = Color.Gray,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Button(
                    onClick = onPickFileClick,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (selectedFileUri != null) Color(0xFF10B981) else DawamiNavy),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = if (selectedFileUri != null) "تغيير الملف" else "اختيار ملف",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }

        // Preview & Summary Section
        if (importResult != null) {
            val passingPercentage = config?.getPassingPercentage() ?: 75.0
            val matchedStudentsCount = remember(editableRows) {
                editableRows.filter { it.isMatchedStudent && it.studentId > 0 }.map { it.studentId }.distinct().size
            }

            // Cross-Course Import Prohibition & Mismatch Error Banner
            if (importResult.isCourseMismatch || !importResult.isSuccess) {
                Surface(
                    color = Color(0xFFFEF2F2),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.5.dp, Color(0xFFEF4444)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = Color(0xFFFEE2E2),
                            shape = CircleShape,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Block,
                                    contentDescription = null,
                                    tint = Color(0xFFDC2626),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🚫 تم حظر الاستيراد: ملف يخص دورة أخرى!",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = Color(0xFF991B1B)
                            )
                            Text(
                                text = importResult.errorOrWarningMessage ?: "هذا الملف مخصص لدورة أخرى، ولا يُسمح باستيراده إلى هذه الدورة نهائياً حفاظاً على سلامة البيانات ومنع تداخل السجلات.",
                                fontSize = 10.5.sp,
                                color = Color(0xFF7F1D1D),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            // Safety Banner for Auto-Excluded Untaken Subjects
            if (untakenSubjectNames.isNotEmpty()) {
                Surface(
                    color = if (autoExcludeUntakenSubjects) Color(0xFFF0FDF4) else Color(0xFFFFFBEB),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (autoExcludeUntakenSubjects) Color(0xFF86EFAC) else Color(0xFFFDE68A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (autoExcludeUntakenSubjects) Icons.Default.Shield else Icons.Default.Info,
                                contentDescription = null,
                                tint = if (autoExcludeUntakenSubjects) Color(0xFF16A34A) else Color(0xFFD97706),
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = if (autoExcludeUntakenSubjects) 
                                        "تم استبعاد ${untakenSubjectNames.size} مواد غير مأخوذة تلقائياً (أصفار) 🛡️" 
                                    else 
                                        "تنبيه: يوجد ${untakenSubjectNames.size} مواد لم ترصد مسبقاً (جميع درجاتها أصفار)",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (autoExcludeUntakenSubjects) Color(0xFF15803D) else Color(0xFFB45309)
                                )
                                Text(
                                    text = "المواد: ${untakenSubjectNames.joinToString("، ")}",
                                    fontSize = 9.sp,
                                    color = Color.Gray,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.clickable {
                                val next = !autoExcludeUntakenSubjects
                                autoExcludeUntakenSubjects = next
                                if (next) {
                                    selectedRowIndices = selectedRowIndices - excludedUntakenIndices
                                } else {
                                    val untakenIndices = editableRows.indices.filter { untakenSubjectNames.contains(editableRows[it].subjectName.trim()) && editableRows[it].isMatchedStudent }.toSet()
                                    selectedRowIndices = selectedRowIndices + untakenIndices
                                }
                            }
                        ) {
                            Checkbox(
                                checked = autoExcludeUntakenSubjects,
                                onCheckedChange = { next ->
                                    autoExcludeUntakenSubjects = next
                                    if (next) {
                                        selectedRowIndices = selectedRowIndices - excludedUntakenIndices
                                    } else {
                                        val untakenIndices = editableRows.indices.filter { untakenSubjectNames.contains(editableRows[it].subjectName.trim()) && editableRows[it].isMatchedStudent }.toSet()
                                        selectedRowIndices = selectedRowIndices + untakenIndices
                                    }
                                },
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "استبعاد تلقائي",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy
                            )
                        }
                    }
                }
            }

            // Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    color = Color(0xFFECFDF5),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFA7F3D0))
                ) {
                    Column(
                        modifier = Modifier.padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("الطلاب المطابقون", fontSize = 9.sp, color = Color(0xFF065F46))
                        Text(
                            text = "$matchedStudentsCount طالب",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF047857)
                        )
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    color = Color(0xFFEFF6FF),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFBFDBFE))
                ) {
                    Column(
                        modifier = Modifier.padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("معدلة أو جديدة", fontSize = 9.sp, color = Color(0xFF1E40AF))
                        Text(
                            text = "${changedOrNewIndices.size} سجل",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF1D4ED8)
                        )
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    color = DawamiNavy.copy(alpha = 0.05f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.15f))
                ) {
                    Column(
                        modifier = Modifier.padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("إجمالي السجلات", fontSize = 9.sp, color = DawamiNavy)
                        Text(
                            text = "${editableRows.size} درجة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = DawamiNavy
                        )
                    }
                }
            }

            // Selection Controls & Quick Select Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val targetSelectableIndices = if (autoExcludeUntakenSubjects) {
                        editableRows.indices.filter { editableRows[it].isMatchedStudent && !excludedUntakenIndices.contains(it) }.toSet()
                    } else {
                        editableRows.indices.filter { editableRows[it].isMatchedStudent }.toSet()
                    }
                    val isAllSelected = targetSelectableIndices.isNotEmpty() && targetSelectableIndices.all { selectedRowIndices.contains(it) }

                    Surface(
                        color = if (isAllSelected) DawamiNavy else Color(0xFFF1F5F9),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(0.8.dp, if (isAllSelected) DawamiNavy else Color(0xFFCBD5E1)),
                        modifier = Modifier.clickable {
                            selectedRowIndices = if (isAllSelected) {
                                emptySet()
                            } else {
                                targetSelectableIndices
                            }
                        }
                    ) {
                        Text(
                            text = if (isAllSelected) "إلغاء الكل" else "تحديد الكل",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isAllSelected) Color.White else DawamiNavy,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                        )
                    }

                    Surface(
                        color = Color(0xFFEFF6FF),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(0.8.dp, Color(0xFF93C5FD)),
                        modifier = Modifier.clickable {
                            selectedRowIndices = changedOrNewIndices
                        }
                    ) {
                        Text(
                            text = "⚡ المعدلة والجديدة فقط (${changedOrNewIndices.size})",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1D4ED8),
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                        )
                    }
                }

                Text(
                    text = "المحدد: ${selectedRowIndices.size} من ${editableRows.size}",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedRowIndices.isNotEmpty()) DawamiNavy else Color.Gray
                )
            }

            // Filter Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val filterTabList = if (untakenSubjectNames.isNotEmpty()) {
                    listOf(
                        "الكل (${editableRows.size})",
                        "المعدلة (${changedOrNewIndices.size})",
                        "المحددة (${selectedRowIndices.size})",
                        "المستبعدة (${excludedUntakenIndices.size})"
                    )
                } else {
                    listOf(
                        "الكل (${editableRows.size})",
                        "المعدلة والجديدة (${changedOrNewIndices.size})",
                        "المحددة للاعتماد (${selectedRowIndices.size})"
                    )
                }

                filterTabList.forEachIndexed { tabIdx, title ->
                    Surface(
                        color = if (filterTab == tabIdx) DawamiNavy.copy(alpha = 0.12f) else Color.Transparent,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, if (filterTab == tabIdx) DawamiNavy else Color(0xFFE2E8F0)),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { filterTab = tabIdx }
                    ) {
                        Text(
                            text = title,
                            fontSize = 8.5.sp,
                            fontWeight = if (filterTab == tabIdx) FontWeight.Bold else FontWeight.Normal,
                            color = if (filterTab == tabIdx) DawamiNavy else Color.Gray,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 4.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Search Input Row (By Student or Subject or ID)
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                placeholder = {
                    Text(
                        text = "🔍 ابحث باسم الطالب أو اسم المادة أو ID...",
                        fontSize = 10.5.sp,
                        color = Color.Gray
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = DawamiNavy,
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "مسح البحث",
                                tint = Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = DawamiNavy,
                    unfocusedBorderColor = Color(0xFFCBD5E1),
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color(0xFFF8FAFC)
                ),
                textStyle = TextStyle(fontSize = 11.5.sp, color = DawamiNavy)
            )

            if (searchQuery.isNotBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "نتائج البحث: ${displayedIndices.size} سجل مطابق",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiTeal
                    )
                    Text(
                        text = "مسح البحث ✕",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Red,
                        modifier = Modifier.clickable { searchQuery = "" }
                    )
                }
            }

            // Preview Table of Students and Grades
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFFF8FAFC), RoundedCornerShape(10.dp))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                    .padding(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(displayedIndices) { realIndex ->
                    val rowItem = editableRows[realIndex]
                    val isSelected = selectedRowIndices.contains(realIndex)
                    val existingGrade = getRowExisting(rowItem)

                    GradePreviewRowCard(
                        index = realIndex + 1,
                        row = rowItem,
                        existingGrade = existingGrade,
                        isSelected = isSelected,
                        passingPercentage = passingPercentage,
                        onToggleSelect = {
                            selectedRowIndices = if (selectedRowIndices.contains(realIndex)) {
                                selectedRowIndices - realIndex
                            } else {
                                selectedRowIndices + realIndex
                            }
                        },
                        onUpdateScore = { updated ->
                            editableRows = editableRows.mapIndexed { idx, it ->
                                if (idx == realIndex) updated else it
                            }
                        }
                    )
                }
            }

            // Bottom Commit Button (Commits only selected rows)
            val isBlocked = importResult?.isCourseMismatch == true || importResult?.isSuccess == false
            val selectedRows = if (isBlocked) emptyList() else editableRows.filterIndexed { index, row ->
                selectedRowIndices.contains(index) && row.isMatchedStudent
            }
            val selectedStudentsCount = selectedRows.filter { it.studentId > 0 }.map { it.studentId }.distinct().size

            Button(
                onClick = {
                    val transitionInfo = getModeTransitionInfo(currentCourseGradingMode, importedTargetMode)
                    if (transitionInfo != null) {
                        pendingRowsForTransition = selectedRows
                        transitionInfoToConfirm = transitionInfo
                    } else {
                        onCommitGrades(selectedRows)
                    }
                },
                enabled = !isImportingInProgress && !isBlocked && selectedRows.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isBlocked) Color(0xFFEF4444) else Color(0xFF10B981),
                    disabledContainerColor = if (isBlocked) Color(0xFFFCA5A5) else Color(0xFFCBD5E1)
                )
            ) {
                if (isImportingInProgress) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                } else if (isBlocked) {
                    Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "🚫 لا يمكن اعتماد الدرجات: الملف لا يخص هذه الدورة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                } else {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (selectedRows.isNotEmpty()) {
                            "اعتماد وحفظ الدرجات المحددة (${selectedRows.size} درجة لـ $selectedStudentsCount طالب) ✓"
                        } else {
                            "حدد الدرجات المراد اعتمادها أولاً"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            // Mode Transition Confirmation Dialog (If grading mode differs)
            if (transitionInfoToConfirm != null && pendingRowsForTransition != null) {
                val selRows = pendingRowsForTransition!!
                val studsCount = selRows.filter { it.studentId > 0 }.map { it.studentId }.distinct().size
                GradingModeTransitionConfirmationDialog(
                    transitionInfo = transitionInfoToConfirm!!,
                    selectedRowsCount = selRows.size,
                    studentsCount = studsCount,
                    onConfirm = {
                        val rows = pendingRowsForTransition!!
                        transitionInfoToConfirm = null
                        pendingRowsForTransition = null
                        onCommitGrades(rows)
                    },
                    onDismiss = {
                        transitionInfoToConfirm = null
                        pendingRowsForTransition = null
                    }
                )
            }
        } else {
            // Empty placeholder before picking a file
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(54.dp))
                    Text("اختر ملف الإكسل أو CSV لعرض درجات الطلاب واعتمادها", fontSize = 11.5.sp, color = Color.Gray)
                }
            }
        }
    }
}

// --- Composable: Student Grade Preview Row Card ---
@Composable
private fun GradePreviewRowCard(
    index: Int,
    row: ParsedGradeRow,
    existingGrade: StudentGrade?,
    isSelected: Boolean,
    passingPercentage: Double,
    onToggleSelect: () -> Unit,
    onUpdateScore: (ParsedGradeRow) -> Unit
) {
    val total = row.calculateTotal()
    val isPassed = total >= passingPercentage
    val badgeBgColor = if (isPassed) Color(0xFFECFDF5) else Color(0xFFFEF2F2)
    val badgeBorderColor = if (isPassed) Color(0xFF10B981) else Color(0xFFEF4444)
    val badgeTextColor = if (isPassed) Color(0xFF047857) else Color(0xFFB91C1C)

    val prevTotal = if (existingGrade != null && existingGrade.getTotalScore() > 0.0) existingGrade.getTotalScore() else null
    val totalDiff = if (prevTotal != null) total - prevTotal else null

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (!row.isMatchedStudent) Color(0xFFFFF1F2) else if (isSelected) Color.White else Color(0xFFF8FAFC)
        ),
        border = BorderStroke(
            if (isSelected) 1.2.dp else 1.dp,
            if (!row.isMatchedStudent) Color(0xFFFECDD3) else if (isSelected) DawamiNavy.copy(alpha = 0.35f) else Color(0xFFE2E8F0)
        )
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Row 1: Student info (Checkbox, Index, Name, ID) and Total Score Comparison Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggleSelect() },
                        enabled = row.isMatchedStudent,
                        colors = CheckboxDefaults.colors(
                            checkedColor = DawamiNavy,
                            checkmarkColor = Color.White
                        ),
                        modifier = Modifier.size(24.dp)
                    )

                    Text(
                        text = "#$index",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Text(
                        text = row.studentName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (row.isMatchedStudent) DawamiNavy else Color.Red,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (row.studentId > 0) {
                        Surface(
                            color = Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(0.5.dp, Color(0xFFCBD5E1))
                        ) {
                            Text(
                                text = "ID: ${row.studentId}",
                                fontSize = 9.5.sp,
                                color = Color.DarkGray,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                // Total score comparison badge
                Surface(
                    color = badgeBgColor,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, badgeBorderColor)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (prevTotal != null && abs(totalDiff ?: 0.0) > 0.01) {
                            Text(
                                text = "${fmtScore(prevTotal)} ➔",
                                fontSize = 9.5.sp,
                                color = Color.Gray,
                                style = TextStyle(textDecoration = TextDecoration.LineThrough)
                            )
                            Text(
                                text = fmtScore(total),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = badgeTextColor
                            )
                            Text(
                                text = if ((totalDiff ?: 0.0) > 0) "(+${fmtScore(totalDiff!!)} ▲)" else "(${fmtScore(totalDiff!!)} ▼)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = if ((totalDiff ?: 0.0) > 0) Color(0xFF16A34A) else Color(0xFFDC2626)
                            )
                        } else if (prevTotal == null) {
                            Text(
                                text = "المجموع: ${fmtScore(total)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = badgeTextColor
                            )
                            Text(
                                text = "✨ جديد",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2563EB)
                            )
                        } else {
                            Text(
                                text = "المجموع: ${fmtScore(total)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = badgeTextColor
                            )
                            Text(
                                text = "✓ مطابق",
                                fontSize = 8.5.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            // Row 2: Subject Tag & Unmatched Warning Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (row.subjectName.isNotBlank()) {
                    Surface(
                        color = DawamiTeal.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "📚 ${row.subjectName}",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = DawamiTeal,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (!row.isMatchedStudent || !row.warningMessage.isNullOrBlank()) {
                    Surface(
                        color = Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(0.5.dp, Color(0xFFFCA5A5))
                    ) {
                        Text(
                            text = row.warningMessage ?: "❌ غير مسجل في هذه الدورة",
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB91C1C),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Row 3: Column Cells Comparison
            if (row.isDiploma && !row.isDirectFinal) {
                val prevAtt = if (existingGrade != null && existingGrade.getTotalScore() > 0.0) existingGrade.attendanceScore else null
                val prevPart = if (existingGrade != null && existingGrade.getTotalScore() > 0.0) existingGrade.participationScore else null
                val prevAssign = if (existingGrade != null && existingGrade.getTotalScore() > 0.0) existingGrade.assignmentsScore else null
                val prevProj = if (existingGrade != null && existingGrade.getTotalScore() > 0.0) existingGrade.projectsScore else null
                val prevTheo = if (existingGrade != null && existingGrade.getTotalScore() > 0.0) existingGrade.theoreticalExamScore else null
                val prevPrac = if (existingGrade != null && existingGrade.getTotalScore() > 0.0) existingGrade.practicalExamScore else null

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    GradeComparisonCell(
                        title = "حضور",
                        maxScore = 5,
                        prevScore = prevAtt,
                        newScore = row.attendanceScore,
                        onScoreChange = { num -> onUpdateScore(row.copy(attendanceScore = num)) }
                    )
                    GradeComparisonCell(
                        title = "مشاركة",
                        maxScore = 5,
                        prevScore = prevPart,
                        newScore = row.participationScore,
                        onScoreChange = { num -> onUpdateScore(row.copy(participationScore = num)) }
                    )
                    GradeComparisonCell(
                        title = "تكاليف",
                        maxScore = 10,
                        prevScore = prevAssign,
                        newScore = row.assignmentsScore,
                        onScoreChange = { num -> onUpdateScore(row.copy(assignmentsScore = num)) }
                    )
                    GradeComparisonCell(
                        title = "مشاريع",
                        maxScore = 20,
                        prevScore = prevProj,
                        newScore = row.projectsScore,
                        onScoreChange = { num -> onUpdateScore(row.copy(projectsScore = num)) }
                    )
                    GradeComparisonCell(
                        title = "نظري",
                        maxScore = 20,
                        prevScore = prevTheo,
                        newScore = row.theoreticalExamScore,
                        onScoreChange = { num -> onUpdateScore(row.copy(theoreticalExamScore = num)) }
                    )
                    GradeComparisonCell(
                        title = "عملي",
                        maxScore = 40,
                        prevScore = prevPrac,
                        newScore = row.practicalExamScore,
                        onScoreChange = { num -> onUpdateScore(row.copy(practicalExamScore = num)) }
                    )
                }
            } else {
                // Direct final comparison cell
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("الدرجة النهائية المباشرة:", fontSize = 10.5.sp, color = Color.Gray)
                    GradeComparisonCell(
                        title = "الدرجة النهائية",
                        maxScore = 100,
                        prevScore = prevTotal,
                        newScore = row.finalScore,
                        width = 110,
                        onScoreChange = { num -> onUpdateScore(row.copy(finalScore = num)) }
                    )
                }
            }

            if (row.note.isNotBlank()) {
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "📝 ملاحظة: ${row.note}",
                        fontSize = 9.5.sp,
                        color = Color(0xFF92400E),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            if (!row.isMatchedStudent) {
                Text(
                    text = "⚠️ لم يتم العثور على هذا الطالب ضمن المسجلين بالدورة وسيتم تجاوزه عند الحفظ.",
                    fontSize = 9.5.sp,
                    color = Color(0xFFB91C1C)
                )
            }
        }
    }
}

// --- Composable: Vertical Column Comparison Cell for Grade Items ---
@Composable
private fun GradeComparisonCell(
    title: String,
    maxScore: Int,
    prevScore: Double?,
    newScore: Double,
    width: Int = 74,
    onScoreChange: (Double) -> Unit
) {
    val diff = if (prevScore != null) newScore - prevScore else null
    val isIncreased = diff != null && diff > 0.01
    val isDecreased = diff != null && diff < -0.01
    val isNew = prevScore == null || (prevScore == 0.0 && newScore > 0.0)

    val cellBg = when {
        isIncreased -> Color(0xFFF0FDF4)
        isDecreased -> Color(0xFFFEF2F2)
        isNew -> Color(0xFFEFF6FF)
        else -> Color(0xFFF8FAFC)
    }
    val cellBorder = when {
        isIncreased -> Color(0xFF86EFAC)
        isDecreased -> Color(0xFFFECACA)
        isNew -> Color(0xFFBFDBFE)
        else -> Color(0xFFE2E8F0)
    }
    val accentColor = when {
        isIncreased -> Color(0xFF16A34A)
        isDecreased -> Color(0xFFDC2626)
        isNew -> Color(0xFF2563EB)
        else -> Color(0xFF334155)
    }

    Surface(
        modifier = Modifier.width(width.dp),
        shape = RoundedCornerShape(8.dp),
        color = cellBg,
        border = BorderStroke(1.dp, cellBorder)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            // Header: Title and Max score
            Text(
                text = "$title ($maxScore)",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = DawamiNavy,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            HorizontalDivider(color = cellBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

            // Previous Score (Read-only reference)
            if (prevScore != null && prevScore > 0.0) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text("السابقة:", fontSize = 7.5.sp, color = Color.Gray)
                    Text(
                        text = fmtScore(prevScore),
                        fontSize = 8.5.sp,
                        color = Color.Gray,
                        style = if (isIncreased || isDecreased) TextStyle(textDecoration = TextDecoration.LineThrough) else TextStyle.Default
                    )
                }
            } else {
                Text("السابقة: -", fontSize = 7.5.sp, color = Color.LightGray)
            }

            // New Editable Score
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp)
                    .background(Color.White, RoundedCornerShape(5.dp))
                    .border(0.8.dp, accentColor.copy(alpha = 0.6f), RoundedCornerShape(5.dp))
                    .padding(horizontal = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                BasicTextField(
                    value = if (newScore > 0) fmtScore(newScore) else "",
                    onValueChange = { input ->
                        val parsed = input.filter { it.isDigit() || it == '.' }.toDoubleOrNull() ?: 0.0
                        onScoreChange(parsed.coerceIn(0.0, maxScore.toDouble()))
                    },
                    textStyle = TextStyle(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = accentColor,
                        textAlign = TextAlign.Center
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    cursorBrush = SolidColor(accentColor)
                )
            }

            // Visual Diff Indicator
            when {
                isIncreased -> {
                    Text(
                        text = "▲ +${fmtScore(diff!!)}",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF16A34A)
                    )
                }
                isDecreased -> {
                    Text(
                        text = "▼ ${fmtScore(diff!!)}",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFDC2626)
                    )
                }
                isNew -> {
                    Text(
                        text = "✨ جديد",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2563EB)
                    )
                }
                else -> {
                    Text(
                        text = "✓ مطابق",
                        fontSize = 7.5.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

// --- Enum: Course Grading Modes ---
private enum class CourseGradingMode {
    AUTO_CALCULATED,    // 🤖 رصد آلي (محسوب من التحضير والتكاليف)
    MANUAL_DETAILED,    // ✍️ رصد يدوي تفصيلي (بالبنود)
    MANUAL_FINAL        // 🎯 رصد نهائي يدوي مباشر (من 100)
}

// --- Data Class: Transition Info & Consequence Matrix ---
private data class GradingModeTransitionInfo(
    val currentMode: CourseGradingMode,
    val targetMode: CourseGradingMode,
    val title: String,
    val currentLabel: String,
    val targetLabel: String,
    val consequences: List<String>,
    val confirmButtonText: String
)

// --- Helper: Get Mode Transition Information & Risk Warnings ---
private fun getModeTransitionInfo(current: CourseGradingMode, target: CourseGradingMode): GradingModeTransitionInfo? {
    if (current == target) return null
    return when (current to target) {
        CourseGradingMode.AUTO_CALCULATED to CourseGradingMode.MANUAL_DETAILED -> {
            GradingModeTransitionInfo(
                currentMode = current,
                targetMode = target,
                title = "تأكيد تحويل نمط الدورة إلى رصد يدوي تفصيلي",
                currentLabel = "🤖 رصد آلي (محسوب من التحضير)",
                targetLabel = "✍️ رصد يدوي تفصيلي بالبنود",
                consequences = listOf(
                    "⚠️ سيتوقف الحساب التلقائي لدرجات الحضور والمشاركات من شاشات التحضير اليومي.",
                    "📌 سيتم تثبيت درجات البنود المستوردة من ملف Excel (حضور، تكاليف، مشاريع، نظري، عملي) كدرجات يدوية ثابتة.",
                    "🔄 يمكنك إعادة تفعيل الرصد الآلي لاحقاً من شاشة الدرجات في أي وقت."
                ),
                confirmButtonText = "موافق، تحويل إلى رصد تفصيلي واعتماد الدرجات"
            )
        }
        CourseGradingMode.AUTO_CALCULATED to CourseGradingMode.MANUAL_FINAL -> {
            GradingModeTransitionInfo(
                currentMode = current,
                targetMode = target,
                title = "تحذير: تحويل نمط الدورة إلى رصد نهائي مباشر",
                currentLabel = "🤖 رصد آلي (محسوب من التحضير)",
                targetLabel = "🎯 رصد نهائي يدوي مباشر (من 100)",
                consequences = listOf(
                    "⚠️ سيتوقف الحساب التلقائي لكافة درجات الحضور والتكاليف والمشاركات.",
                    "📌 سيتم إلغاء تقسيم البنود التفصيلية والاعتماد على الدرجة الإجمالية المباشرة لكل طالب.",
                    "🛡️ ستظهر درجات الطلاب كنتيجة نهائية مباشرة معتمدة في كشوفات الدورة والتقارير."
                ),
                confirmButtonText = "موافق، تحويل إلى رصد نهائي مباشر واعتماد الدرجات"
            )
        }
        CourseGradingMode.MANUAL_DETAILED to CourseGradingMode.MANUAL_FINAL -> {
            GradingModeTransitionInfo(
                currentMode = current,
                targetMode = target,
                title = "تأكيد تحويل نمط الدورة إلى رصد نهائي مباشر",
                currentLabel = "✍️ رصد يدوي تفصيلي بالبنود",
                targetLabel = "🎯 رصد نهائي يدوي مباشر (من 100)",
                consequences = listOf(
                    "⚠️ سيتم تجاوز التقسيم التفصيلي للبنود السابقة (حضور، تكاليف، مشاريع، اختبارات).",
                    "📌 ستصبح درجة الطالب في النظام معتمدة على الدرجة الإجمالية المباشرة الواردة في الملف فقط."
                ),
                confirmButtonText = "موافق، تحويل إلى رصد نهائي مباشر واعتماد الدرجات"
            )
        }
        CourseGradingMode.MANUAL_FINAL to CourseGradingMode.MANUAL_DETAILED -> {
            GradingModeTransitionInfo(
                currentMode = current,
                targetMode = target,
                title = "تأكيد تحويل نمط الدورة إلى رصد تفصيلي بالبنود",
                currentLabel = "🎯 رصد نهائي يدوي مباشر",
                targetLabel = "✍️ رصد يدوي تفصيلي بالبنود",
                consequences = listOf(
                    "ℹ️ سيتم تفعيل تقسيم البنود وتوزيع درجات الطلاب على (حضور، مشاركة، تكاليف، مشاريع، نظري، عملي).",
                    "📌 سيتم استبدال الدرجة النهائية المباشرة بتفصيل البنود المستوردة من الملف."
                ),
                confirmButtonText = "موافق، تحويل إلى رصد تفصيلي واعتماد الدرجات"
            )
        }
        CourseGradingMode.MANUAL_DETAILED to CourseGradingMode.AUTO_CALCULATED -> {
            GradingModeTransitionInfo(
                currentMode = current,
                targetMode = target,
                title = "تأكيد تحويل نمط الدورة إلى رصد آلي",
                currentLabel = "✍️ رصد يدوي تفصيلي بالبنود",
                targetLabel = "🤖 رصد آلي (محسوب من التحضير والتكاليف)",
                consequences = listOf(
                    "⚠️ سيتم استبدال الدرجات اليدوية الثابتة بالحساب الآلي التلقائي من سجلات التحضير والتكاليف.",
                    "📌 ستنعكس نسب الحضور والمشاركات والواجبات المرصودة في النظام مباشرة في كشف الدرجات.",
                    "🔄 يمكنك العودة للرصد اليدوي في أي وقت."
                ),
                confirmButtonText = "موافق، تحويل إلى رصد آلي واعتماد الدرجات"
            )
        }
        CourseGradingMode.MANUAL_FINAL to CourseGradingMode.AUTO_CALCULATED -> {
            GradingModeTransitionInfo(
                currentMode = current,
                targetMode = target,
                title = "تأكيد تحويل نمط الدورة إلى رصد آلي",
                currentLabel = "🎯 رصد نهائي يدوي مباشر (من 100)",
                targetLabel = "🤖 رصد آلي (محسوب من التحضير والتكاليف)",
                consequences = listOf(
                    "⚠️ سيتم إلغاء اعتماد الدرجة النهائية المباشرة والعودة لاحتساب درجات الحضور والتكاليف والمشاريع آلياً.",
                    "📌 سيتم إعادة توزيع الدرجات وفق بنود المادة المعتمدة في النظام."
                ),
                confirmButtonText = "موافق، تحويل إلى رصد آلي واعتماد الدرجات"
            )
        }
        else -> null
    }
}

// --- Composable: Mode Transition Confirmation Dialog with Risk Assessment ---
@Composable
private fun GradingModeTransitionConfirmationDialog(
    transitionInfo: GradingModeTransitionInfo,
    selectedRowsCount: Int,
    studentsCount: Int,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = CircleShape,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Text(
                    text = transitionInfo.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DawamiNavy
                )
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Mode Transition visual banner
                Surface(
                    color = Color(0xFFF8FAFC),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("النمط الحالي للدورة", fontSize = 9.sp, color = Color.Gray)
                            Text(transitionInfo.currentLabel, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        }
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFF3B82F6),
                            modifier = Modifier.size(18.dp)
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("النمط الجديد المعتمد", fontSize = 9.sp, color = Color.Gray)
                            Text(transitionInfo.targetLabel, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF15803D))
                        }
                    }
                }

                Text(
                    text = "بيان المخاطر والآثار المترتبة على التحويل:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color(0xFF991B1B)
                )

                Surface(
                    color = Color(0xFFFEF2F2),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFFECACA)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        transitionInfo.consequences.forEach { consequence ->
                            Text(
                                text = consequence,
                                fontSize = 10.sp,
                                color = Color(0xFF7F1D1D),
                                lineHeight = 14.sp
                            )
                        }
                    }
                }

                Text(
                    text = "سيتم اعتماد درجات ($selectedRowsCount درجة لـ $studentsCount طالب) وتطبيق النمط الجديد فوراً.",
                    fontSize = 9.5.sp,
                    color = Color.Gray
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF047857)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(transitionInfo.confirmButtonText, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("إلغاء التراجع", fontSize = 10.5.sp, color = Color.DarkGray)
            }
        }
    )
}
