package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalThemePreset = staticCompositionLocalOf {
    ThemePresetsCatalog.presets.first()
}

@Composable
fun MyApplicationTheme(
    presetId: Int = 1,
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val preset = ThemePresetsCatalog.getById(presetId)

    // Synchronize global brand tokens with the active preset
    DawamiNavy = preset.primary
    DawamiGold = preset.secondary
    DawamiTeal = preset.tertiary

    val colorScheme = preset.toColorScheme()

    CompositionLocalProvider(LocalThemePreset provides preset) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

