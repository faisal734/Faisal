package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.components.DawamiBottomNavigationBar
import com.example.ui.theme.DawamiNavy
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun InstituteSettingsScreen(viewModel: MainViewModel, showMainLayout: Boolean = true) {
    val context = LocalContext.current
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val notifications by viewModel.inAppNotifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    var instituteNameInput by remember { mutableStateOf(viewModel.instituteName.value) }
    var instituteSloganInput by remember { mutableStateOf(viewModel.instituteSlogan.value) }
    var directorNameInput by remember { mutableStateOf(viewModel.directorName.value) }
    var hrManagerNameInput by remember { mutableStateOf(viewModel.hrManagerName.value) }
    var trainerNameInput by remember { mutableStateOf(viewModel.trainerNameConfig.value) }

    if (showMainLayout) {
        BackHandler {
            viewModel.navigateBack()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (showMainLayout) {
            Scaffold(
                topBar = {
                    AppHeader(
                        title = "إعدادات المعهد والتوقيعات 🏫✍️",
                        username = "",
                        onHomeClick = { viewModel.navigateTo(Screen.Selection) },
                        onBackClick = { viewModel.navigateBack() },
                        isDark = isDarkTheme,
                        onToggleTheme = { viewModel.toggleTheme() },
                        unreadNotificationCount = unreadCount,
                        onNotificationClick = { viewModel.openNotificationCenter() }
                    )
                },
                bottomBar = {
                    DawamiBottomNavigationBar(viewModel = viewModel)
                }
            ) { innerPadding ->
                InstituteSettingsContent(
                    viewModel = viewModel,
                    innerPadding = innerPadding,
                    instituteNameInput = instituteNameInput,
                    onInstituteNameChange = { instituteNameInput = it },
                    instituteSloganInput = instituteSloganInput,
                    onInstituteSloganChange = { instituteSloganInput = it },
                    directorNameInput = directorNameInput,
                    onDirectorNameChange = { directorNameInput = it },
                    hrManagerNameInput = hrManagerNameInput,
                    onHrManagerNameChange = { hrManagerNameInput = it },
                    trainerNameInput = trainerNameInput,
                    onTrainerNameChange = { trainerNameInput = it }
                )
            }
        } else {
            InstituteSettingsContent(
                viewModel = viewModel,
                innerPadding = PaddingValues(0.dp),
                instituteNameInput = instituteNameInput,
                onInstituteNameChange = { instituteNameInput = it },
                instituteSloganInput = instituteSloganInput,
                onInstituteSloganChange = { instituteSloganInput = it },
                directorNameInput = directorNameInput,
                onDirectorNameChange = { directorNameInput = it },
                hrManagerNameInput = hrManagerNameInput,
                onHrManagerNameChange = { hrManagerNameInput = it },
                trainerNameInput = trainerNameInput,
                onTrainerNameChange = { trainerNameInput = it }
            )
        }
    }
}

@Composable
private fun InstituteSettingsContent(
    viewModel: MainViewModel,
    innerPadding: PaddingValues,
    instituteNameInput: String,
    onInstituteNameChange: (String) -> Unit,
    instituteSloganInput: String,
    onInstituteSloganChange: (String) -> Unit,
    directorNameInput: String,
    onDirectorNameChange: (String) -> Unit,
    hrManagerNameInput: String,
    onHrManagerNameChange: (String) -> Unit,
    trainerNameInput: String,
    onTrainerNameChange: (String) -> Unit
) {
    val context = LocalContext.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .background(MaterialTheme.colorScheme.background)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
                // Academic Structure Management Shortcut Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "إدارة الهيكل الأكاديمي (الأقسام والدبلومات والمواد) 📂🎓",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = DawamiNavy
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "إضافة وتعديل وحذف الأقسام، الدبلومات، والمواد المقررة بسهولة",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { viewModel.navigateTo(Screen.OnboardingSetup) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Category, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إدارة الهيكل ⚙️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "بيانات المعهد والترويسة الرسمية 🏫",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = DawamiNavy
                            )

                            // Logo Picker
                            val logoLauncher = rememberLauncherForActivityResult(
                                contract = ActivityResultContracts.PickVisualMedia()
                            ) { uri: Uri? ->
                                uri?.let {
                                    val path = viewModel.copyUriToInternalStorage(context, it)
                                    viewModel.instituteLogoUri.value = if (path.isNotEmpty()) path else it.toString()
                                }
                            }
                            
                            val logoUri = viewModel.instituteLogoUri.collectAsState().value

                            Box(
                                modifier = Modifier
                                    .size(100.dp)
                                    .clip(CircleShape)
                                    .background(Color.LightGray)
                                    .clickable { logoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (logoUri.isNotEmpty()) {
                                    AsyncImage(
                                        model = logoUri,
                                        contentDescription = "Institute Logo",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(Icons.Default.AddAPhoto, contentDescription = "Add Logo")
                                }
                            }

                            OutlinedTextField(
                                value = instituteNameInput,
                                onValueChange = onInstituteNameChange,
                                label = { Text("اسم المعهد / الكلية / المركز", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            OutlinedTextField(
                                value = instituteSloganInput,
                                onValueChange = onInstituteSloganChange,
                                label = { Text("الشعار اللفظي / الوصف الأكاديمي", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Divider(modifier = Modifier.padding(vertical = 4.dp))

                            Text(
                                text = "أسماء المسئولين والتوقيعات بالتقارير ✍️",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = DawamiNavy
                            )

                            OutlinedTextField(
                                value = directorNameInput,
                                onValueChange = onDirectorNameChange,
                                label = { Text("اسم عميد / مدير المعهد", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            OutlinedTextField(
                                value = hrManagerNameInput,
                                onValueChange = onHrManagerNameChange,
                                label = { Text("اسم مسئول شؤون الطلاب / الموارد", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            OutlinedTextField(
                                value = trainerNameInput,
                                onValueChange = onTrainerNameChange,
                                label = { Text("اسم المدرب / الأستاذ المعتمد", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(
                                onClick = {
                                    viewModel.saveInstituteIdentity(
                                        name = instituteNameInput.trim(),
                                        symbol = "school",
                                        slogan = instituteSloganInput.trim(),
                                        director = directorNameInput.trim(),
                                        hrManager = hrManagerNameInput.trim(),
                                        trainer = trainerNameInput.trim(),
                                        logoUri = viewModel.instituteLogoUri.value
                                    )
                                    Toast.makeText(context, "تم حفظ إعدادات المعهد والتوقيعات بنجاح! 💾✅", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("حفظ البيانات والتحديث 💾", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(48.dp))
                }
            }
}
