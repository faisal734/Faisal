package com.example.workers

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.MainActivity
import com.example.R
import com.example.data.database.AppDatabase
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AttendanceAlertWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            checkAbsentStudents()
            Result.success()
        } catch (e: Exception) {
            Log.e("AttendanceAlertWorker", "Error in worker: ${e.message}", e)
            Result.retry()
        }
    }

    private suspend fun checkAbsentStudents() {
        val database = AppDatabase.getDatabase(context)
        val courseDao = database.courseDao()
        val studentAttendanceDao = database.studentAttendanceDao()
        val prefs = context.getSharedPreferences("AttendanceAlertPrefs", Context.MODE_PRIVATE)

        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Calendar.getInstance().time)
        val currentTimeMillis = System.currentTimeMillis()

        val allCourses = courseDao.getAllCoursesSync()
        
        for (course in allCourses) {
            if (course.startTime.isEmpty()) continue
            if (course.isCompleted || (course.endDate.isNotBlank() && course.endDate < currentDate)) continue
            
            // Check if alert already sent today for this course
            val alertKey = "alert_sent_${course.id}_$currentDate"
            if (prefs.getBoolean(alertKey, false)) {
                continue
            }

            // Parse course start time
            val cal = Calendar.getInstance()
            val timeParts = course.startTime.split(":")
            if (timeParts.size != 2) continue
            
            val courseHour = timeParts[0].trim().toIntOrNull() ?: continue
            val courseMinute = timeParts[1].trim().toIntOrNull() ?: continue
            
            cal.set(Calendar.HOUR_OF_DAY, courseHour)
            cal.set(Calendar.MINUTE, courseMinute)
            cal.set(Calendar.SECOND, 0)
            
            val courseStartTimeMillis = cal.timeInMillis
            val oneHourInMillis = 60 * 60 * 1000L
            
            // If 1 hour has passed since course start time
            if (currentTimeMillis >= courseStartTimeMillis + oneHourInMillis) {
                // Get all student attendances for today for this course
                val todayAttendances = studentAttendanceDao.getStudentAttendanceByCourseAndDateSync(course.id, currentDate)
                
                // If there are no students, skip
                if (todayAttendances.isEmpty()) {
                    continue
                }
                
                val absentStudents = todayAttendances.filter { 
                    it.actualCheckIn.isEmpty() && (it.status == "غياب" || it.status == "لم يحضر" || it.status == "حضور" /* hasn't checked in */)
                }

                if (absentStudents.isNotEmpty()) {
                    val absentCount = absentStudents.size
                    val totalCount = todayAttendances.size
                    
                    val title = "تنبيه غياب: ${course.name}"
                    val message = "لم يسجل $absentCount طالب من أصل $totalCount حضورهم بعد مرور ساعة من بداية الدوام."
                    
                    sendNotification(course.id, title, message)
                    
                    // Mark as sent
                    prefs.edit().putBoolean(alertKey, true).apply()
                } else {
                    // Everyone is present or no absentees to alert, mark as sent
                    prefs.edit().putBoolean(alertKey, true).apply()
                }
            }
        }
    }

    private fun sendNotification(courseId: Int, title: String, message: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "attendance_alerts"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "تنبيهات الغياب",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيهات تلقائية للطلاب الغائبين بعد ساعة من بدء الدوام"
                setBypassDnd(true)
                val audioAttributes = android.media.AudioAttributes.Builder()
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                    .build()
                setSound(android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM), audioAttributes)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        
        val pendingIntent = PendingIntent.getActivity(
            context,
            courseId,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, channelId)
            // Use standard alert icon, or launcher icon
            .setSmallIcon(android.R.drawable.ic_dialog_alert) 
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(courseId, notification)
    }
}
