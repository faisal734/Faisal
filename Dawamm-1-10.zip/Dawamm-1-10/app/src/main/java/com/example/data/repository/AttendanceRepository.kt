package com.example.data.repository

import com.example.data.dao.AttendanceDao
import com.example.data.dao.StudentAttendanceDao
import com.example.data.dao.LessonTopicDao
import com.example.data.dao.LessonSessionTopicDao
import com.example.data.dao.DailyCourseNoteDao
import com.example.data.entity.Attendance
import com.example.data.entity.StudentAttendance
import com.example.data.entity.LessonTopic
import com.example.data.entity.LessonSessionTopic
import com.example.data.entity.DailyCourseNote
import kotlinx.coroutines.flow.Flow

/**
 * AttendanceRepository: مسؤول عن عمليات وسجلات حضور وانصراف المدرب، وحضور وغياب وتأخيرات الطلاب،
 * والخطة التدريسية ومواضيع الجلسات، والملاحظات اليومية.
 */
class AttendanceRepository(
    private val attendanceDao: AttendanceDao,
    private val studentAttendanceDao: StudentAttendanceDao,
    private val lessonTopicDao: LessonTopicDao,
    private val lessonSessionTopicDao: LessonSessionTopicDao,
    private val dailyCourseNoteDao: DailyCourseNoteDao
) {
    val allAttendance: Flow<List<Attendance>> = attendanceDao.getAllAttendance()
    val allStudentAttendance: Flow<List<StudentAttendance>> = studentAttendanceDao.getAllStudentAttendance()
    val allLessonTopics: Flow<List<LessonTopic>> = lessonTopicDao.getAllTopics()
    val allLessonSessionTopics: Flow<List<LessonSessionTopic>> = lessonSessionTopicDao.getAllSessionTopics()
    val allDailyNotes: Flow<List<DailyCourseNote>> = dailyCourseNoteDao.getAllDailyNotes()

    // Trainer Attendance
    fun getAttendanceByCourse(courseId: Int): Flow<List<Attendance>> = attendanceDao.getAttendanceByCourse(courseId)
    suspend fun getAttendanceByCourseAndDateSync(courseId: Int, date: String): Attendance? = attendanceDao.getAttendanceByCourseAndDateSync(courseId, date)
    suspend fun insertAttendance(attendance: Attendance): Long = attendanceDao.insertAttendance(attendance)
    suspend fun updateAttendance(attendance: Attendance) = attendanceDao.updateAttendance(attendance)
    suspend fun deleteAttendance(attendance: Attendance) = attendanceDao.deleteAttendance(attendance)
    suspend fun deleteAttendanceByCourseId(courseId: Int) = attendanceDao.deleteByCourseId(courseId)
    suspend fun updateCourseNameInAttendance(courseId: Int, newName: String) = attendanceDao.updateCourseName(courseId, newName)
    suspend fun updateSubjectNameInAttendance(oldName: String, newName: String) = attendanceDao.updateSubjectName(oldName, newName)
    suspend fun deleteAllAttendance() = attendanceDao.deleteAllAttendance()

    // Student Attendance
    fun getStudentAttendanceByCourse(courseId: Int): Flow<List<StudentAttendance>> = studentAttendanceDao.getStudentAttendanceByCourse(courseId)
    fun getStudentAttendanceByCourseAndDate(courseId: Int, date: String): Flow<List<StudentAttendance>> = studentAttendanceDao.getStudentAttendanceByCourseAndDate(courseId, date)
    suspend fun getStudentAttendanceByCourseAndDateSync(courseId: Int, date: String): List<StudentAttendance> = studentAttendanceDao.getStudentAttendanceByCourseAndDateSync(courseId, date)
    suspend fun insertStudentAttendance(attendance: StudentAttendance): Long = studentAttendanceDao.insertStudentAttendance(attendance)
    suspend fun insertStudentAttendances(attendances: List<StudentAttendance>) = studentAttendanceDao.insertStudentAttendances(attendances)
    suspend fun updateStudentAttendance(attendance: StudentAttendance) = studentAttendanceDao.updateStudentAttendance(attendance)
    suspend fun updateStudentAttendances(attendances: List<StudentAttendance>) = studentAttendanceDao.updateStudentAttendances(attendances)
    suspend fun deleteStudentAttendance(attendance: StudentAttendance) = studentAttendanceDao.deleteStudentAttendance(attendance)
    suspend fun deleteStudentAttendances(attendances: List<StudentAttendance>) = studentAttendanceDao.deleteStudentAttendances(attendances)
    suspend fun deleteStudentAttendanceByCourseId(courseId: Int) = studentAttendanceDao.deleteStudentAttendanceByCourseId(courseId)
    suspend fun deleteStudentAttendanceByStudentId(studentId: Int) = studentAttendanceDao.deleteStudentAttendanceByStudentId(studentId)
    suspend fun updateStudentAttendanceName(studentId: Int, newName: String) = studentAttendanceDao.updateStudentAttendanceName(studentId, newName)
    suspend fun updateCourseNameInStudentAttendance(courseId: Int, newName: String) = studentAttendanceDao.updateCourseName(courseId, newName)
    suspend fun updateSubjectNameInStudentAttendance(oldName: String, newName: String) = studentAttendanceDao.updateSubjectName(oldName, newName)
    suspend fun transferStudentAttendance(studentId: Int, newCourseId: Int, newCourseName: String) = studentAttendanceDao.transferStudentAttendance(studentId, newCourseId, newCourseName)
    suspend fun deleteAllStudentAttendance() = studentAttendanceDao.deleteAllStudentAttendance()

    // Lesson Topics & Sessions
    fun getTopicsForCourse(courseId: Int): Flow<List<LessonTopic>> = lessonTopicDao.getTopicsForCourse(courseId)
    suspend fun insertLessonTopic(topic: LessonTopic): Long = lessonTopicDao.insertTopic(topic)
    suspend fun updateLessonTopic(topic: LessonTopic) = lessonTopicDao.updateTopic(topic)
    suspend fun deleteLessonTopic(topic: LessonTopic) = lessonTopicDao.deleteTopic(topic)
    suspend fun deleteTopicsByCourseId(courseId: Int) = lessonTopicDao.deleteTopicsByCourseId(courseId)
    suspend fun deleteAllLessonTopics() = lessonTopicDao.deleteAllTopics()

    fun getSessionTopics(courseId: Int, date: String): Flow<List<LessonSessionTopic>> = lessonSessionTopicDao.getSessionTopics(courseId, date)
    fun getAllSessionTopicsForCourse(courseId: Int): Flow<List<LessonSessionTopic>> = lessonSessionTopicDao.getAllSessionTopicsForCourse(courseId)
    suspend fun getSessionTopicsSync(courseId: Int, date: String): List<LessonSessionTopic> = lessonSessionTopicDao.getSessionTopicsSync(courseId, date)
    suspend fun insertSessionTopic(sessionTopic: LessonSessionTopic): Long = lessonSessionTopicDao.insertSessionTopic(sessionTopic)
    suspend fun updateSessionTopic(sessionTopic: LessonSessionTopic) = lessonSessionTopicDao.updateSessionTopic(sessionTopic)
    suspend fun deleteSessionTopic(sessionTopic: LessonSessionTopic) = lessonSessionTopicDao.deleteSessionTopic(sessionTopic)
    suspend fun deleteSessionTopicsByCourseId(courseId: Int) = lessonSessionTopicDao.deleteSessionTopicsByCourseId(courseId)
    suspend fun deleteAllLessonSessionTopics() = lessonSessionTopicDao.deleteAllSessionTopics()

    // Daily Notes
    fun getDailyNoteForCourseAndDate(courseId: Int, date: String): Flow<DailyCourseNote?> = dailyCourseNoteDao.getDailyNoteForCourseAndDate(courseId, date)
    suspend fun getDailyNoteForCourseAndDateSync(courseId: Int, date: String): DailyCourseNote? = dailyCourseNoteDao.getDailyNoteForCourseAndDateSync(courseId, date)
    suspend fun insertDailyNote(dailyNote: DailyCourseNote): Long = dailyCourseNoteDao.insertDailyNote(dailyNote)
    suspend fun updateDailyNote(dailyNote: DailyCourseNote) = dailyCourseNoteDao.updateDailyNote(dailyNote)
    suspend fun deleteDailyNote(dailyNote: DailyCourseNote) = dailyCourseNoteDao.deleteDailyNote(dailyNote)
    suspend fun deleteDailyNotesByCourseId(courseId: Int) = dailyCourseNoteDao.deleteDailyNotesByCourseId(courseId)
    suspend fun deleteAllDailyNotes() = dailyCourseNoteDao.deleteAllDailyNotes()
}
