package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.LessonTopic
import com.example.data.entity.LessonSessionTopic
import kotlinx.coroutines.flow.Flow

@Dao
interface LessonTopicDao {
    @Query("SELECT * FROM lesson_topics ORDER BY orderIndex ASC, id ASC")
    fun getAllTopics(): Flow<List<LessonTopic>>

    @Query("SELECT * FROM lesson_topics WHERE courseId = :courseId ORDER BY orderIndex ASC, id ASC")
    fun getTopicsForCourse(courseId: Int): Flow<List<LessonTopic>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopic(topic: LessonTopic): Long

    @Update
    suspend fun updateTopic(topic: LessonTopic)

    @Delete
    suspend fun deleteTopic(topic: LessonTopic)

    @Query("DELETE FROM lesson_topics WHERE courseId = :courseId")
    suspend fun deleteTopicsByCourseId(courseId: Int)

    @Query("DELETE FROM lesson_topics")
    suspend fun deleteAllTopics()
}

@Dao
interface LessonSessionTopicDao {
    @Query("SELECT * FROM lesson_session_topics ORDER BY date DESC, id ASC")
    fun getAllSessionTopics(): Flow<List<LessonSessionTopic>>

    @Query("SELECT * FROM lesson_session_topics WHERE courseId = :courseId AND date = :date")
    fun getSessionTopics(courseId: Int, date: String): Flow<List<LessonSessionTopic>>

    @Query("SELECT * FROM lesson_session_topics WHERE courseId = :courseId")
    fun getAllSessionTopicsForCourse(courseId: Int): Flow<List<LessonSessionTopic>>

    @Query("SELECT * FROM lesson_session_topics WHERE courseId = :courseId AND date = :date")
    suspend fun getSessionTopicsSync(courseId: Int, date: String): List<LessonSessionTopic>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionTopic(sessionTopic: LessonSessionTopic): Long

    @Update
    suspend fun updateSessionTopic(sessionTopic: LessonSessionTopic)

    @Delete
    suspend fun deleteSessionTopic(sessionTopic: LessonSessionTopic)

    @Query("DELETE FROM lesson_session_topics WHERE courseId = :courseId")
    suspend fun deleteSessionTopicsByCourseId(courseId: Int)

    @Query("DELETE FROM lesson_session_topics")
    suspend fun deleteAllSessionTopics()
}
