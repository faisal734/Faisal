package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trainer_transactions")
data class TrainerTransaction(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val courseId: Long = 0,
    val courseName: String = "",
    val amount: Double = 0.0,
    val date: String = "",
    val type: String = "لكم", // "لكم" (مستحق / له) or "عليكم" (مسحوبات / عليه)
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
