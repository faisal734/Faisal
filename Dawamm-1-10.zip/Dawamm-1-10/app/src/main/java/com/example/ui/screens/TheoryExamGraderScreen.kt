package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentGradeConfig
import com.example.ui.theme.*
import com.example.ui.viewmodel.GradingViewModel
import com.example.ui.viewmodel.MainViewModel

data class GradedStudentItem(
    val gradeRecordId: Int,
    val studentId: Int,
    val courseId: Int = 0,
    val name: String,
    val subjectName: String,
    val courseName: String,
    val department: String,
    val diploma: String,
    val theoryGrade: Double,
    val practicalGrade: Double = 0.0,
    val hasPracticalGrade: Boolean = false,
    val totalQuestions: Int = 20,
    val correctAnswers: Int = 0,
    val incorrectAnswers: Int = 0,
    val note: String = "",
    val dateOfRecording: String = ""
)

@Composable
fun StudentGradeCard(
    student: GradedStudentItem,
    isDark: Boolean = false,
    isLocked: Boolean = false,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    val context = LocalContext.current
    val cardBg = if (isDark) DarkSurface else Color.White
    val borderClr = if (isDark) DarkOutline else Color(0xFFE2E8F0)
    val textPrimary = if (isDark) DarkOnSurface else DawamiNavy
    val textSecondary = if (isDark) DarkOnSurfaceVariant else Color(0xFF64748B)
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(2.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = BorderStroke(1.dp, borderClr),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = DawamiTeal.copy(alpha = 0.15f),
                        shape = CircleShape,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(14.dp))
                        }
                    }
                    Text(
                        text = student.name,
                        style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                        color = textPrimary,
                        maxLines = 1
                    )
                }
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onShare, modifier = Modifier.size(22.dp)) {
                        Icon(Icons.Default.Share, contentDescription = "مشاركة", tint = if (isDark) DawamiGold else DawamiNavy, modifier = Modifier.size(14.dp))
                    }
                    IconButton(
                        onClick = {
                            if (isLocked) {
                                Toast.makeText(context, "سجلات هذه الدورة منتهية ومحمية 🔒. اضغط على 'فتح القفل 🔓' بالأعلى للتعديل.", Toast.LENGTH_SHORT).show()
                            } else {
                                onEdit()
                            }
                        },
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = if (isLocked) Icons.Default.Lock else Icons.Default.Edit,
                            contentDescription = if (isLocked) "سجل مقفل (دورة منتهية)" else "تعديل",
                            tint = if (isLocked) (if (isDark) Color.Gray else Color(0xFF64748B)) else DawamiTeal,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    IconButton(
                        onClick = {
                            if (isLocked) {
                                Toast.makeText(context, "لا يمكن حذف درجات دورة منتهية أثناء تفعيل وضع الحماية 🔒", Toast.LENGTH_SHORT).show()
                            } else {
                                onDelete()
                            }
                        },
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "حذف",
                            tint = if (isLocked) (if (isDark) Color.DarkGray else Color.LightGray) else Color.Red.copy(alpha = 0.8f),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                if (student.note.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (isDark) Color(0xFF334155).copy(alpha = 0.5f) else Color(0xFFF1F5F9),
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 5.dp, vertical = 3.dp)
                    ) {
                        Icon(
                            Icons.Default.StickyNote2,
                            contentDescription = null,
                            tint = DawamiGold,
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = student.note,
                            fontSize = 8.5.sp,
                            color = textPrimary,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 11.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.School, contentDescription = null, tint = if (isDark) DawamiGold else DawamiNavy, modifier = Modifier.size(10.dp).padding(top = 2.dp))
                    Text(
                        text = "${student.courseName} | ${student.subjectName}",
                        fontSize = 8.5.sp,
                        color = textSecondary,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 11.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (student.dateOfRecording.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = DawamiTeal,
                            modifier = Modifier.size(10.dp)
                        )
                        Text(
                            text = "تاريخ الرصد: ${student.dateOfRecording}",
                            fontSize = 8.5.sp,
                            color = DawamiTeal,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp), thickness = 0.5.dp, color = borderClr)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("النظري:", fontSize = 9.sp, color = textSecondary)
                        Text(
                            if (student.theoryGrade % 1.0 == 0.0) student.theoryGrade.toInt().toString() else student.theoryGrade.toString(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = DawamiTeal
                        )
                    }
                    if (student.hasPracticalGrade || student.practicalGrade > 0.0) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("العملي:", fontSize = 9.sp, color = textSecondary)
                            Text(
                                if (student.practicalGrade % 1.0 == 0.0) student.practicalGrade.toInt().toString() else student.practicalGrade.toString(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiGold
                            )
                        }
                    }
                }
                
                Surface(
                    color = DawamiNavy,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    val total = student.theoryGrade + student.practicalGrade
                    Text(
                        text = "المجموع: ${if (total % 1.0 == 0.0) total.toInt().toString() else total}",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TheoryExamGraderScreen(
    viewModel: MainViewModel,
    gradingViewModel: GradingViewModel? = null,
    showMainLayout: Boolean = true
) {
    val context = LocalContext.current
    val isDark by viewModel.isDarkTheme.collectAsState()
    
    val courses by viewModel.dbCourses.collectAsState()
    val allStudents by viewModel.dbAllStudents.collectAsState()
    val dbAllGrades by (gradingViewModel?.allGrades ?: viewModel.dbAllGrades).collectAsState()
    val gradeConfigs by (gradingViewModel?.allGradeConfigs ?: viewModel.dbAllGradeConfigs).collectAsState()
    val allSubjects by viewModel.dbSubjects.collectAsState()
    val courseGradingModes by viewModel.courseGradingModes.collectAsState()
    val dbAttendance by viewModel.dbAttendance.collectAsState()
    val dbAllStudentAttendance by viewModel.dbAllStudentAttendance.collectAsState()
    
    // Direct Course Selection
    var selectedCourse by remember { mutableStateOf(courses.firstOrNull()) }
    
    val isCourseEnded = remember(selectedCourse) {
        if (selectedCourse == null) false
        else {
            val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            val isPastEndDate = selectedCourse!!.endDate.isNotBlank() && todayStr > selectedCourse!!.endDate
            val isCompleted = selectedCourse!!.isCompleted
            isCompleted || isPastEndDate
        }
    }
    var isEditUnlockedForEndedCourse by remember(selectedCourse?.id) { mutableStateOf(false) }
    var showUnlockConfirmDialog by remember { mutableStateOf(false) }
    val isLockedForEditing = isCourseEnded && !isEditUnlockedForEndedCourse
    
    LaunchedEffect(courses) {
        if (selectedCourse == null || !courses.any { it.id == selectedCourse?.id }) {
            selectedCourse = courses.firstOrNull()
        }
    }
    
    val selectedDepartment = selectedCourse?.departmentName ?: ""
    val selectedDiploma = selectedCourse?.diplomaName ?: ""

    // Available subjects for selected course
    val courseSubjects = remember(selectedCourse, gradeConfigs, allSubjects) {
        val crs = selectedCourse
        if (crs == null) {
            StudentGradeConfig.DEFAULT_DIPLOMA_SUBJECTS
        } else {
            val templateId = StudentGradeConfig.getDiplomaTemplateId(crs.diplomaName)
            val deptTemplateId = StudentGradeConfig.getDepartmentTemplateId(crs.departmentName)
            val config = gradeConfigs.find { it.courseId == crs.id }
                ?: gradeConfigs.find { it.courseId == templateId }
                ?: gradeConfigs.find { it.courseId == deptTemplateId }
            
            if (config != null && !config.isDiploma) {
                val customFields = StudentGradeConfig.deserializeFields(config.customFieldsJson)
                val customSubjs = customFields.map { it.first.substringBefore("_") }.distinct()
                if (customSubjs.isNotEmpty()) customSubjs else listOf(crs.name)
            } else if (config != null && config.isDiploma) {
                config.getDiplomaSubjects()
            } else {
                val matching = allSubjects.filter { 
                    it.departmentName == crs.departmentName && it.diplomaName == crs.diplomaName 
                }.map { it.name }.distinct()
                if (matching.isNotEmpty()) matching else StudentGradeConfig.DEFAULT_DIPLOMA_SUBJECTS
            }
        }
    }
    
    var selectedSubject by remember { mutableStateOf(courseSubjects.firstOrNull() ?: "") }
    
    LaunchedEffect(courseSubjects) {
        if (!courseSubjects.contains(selectedSubject)) {
            selectedSubject = courseSubjects.firstOrNull() ?: ""
        }
    }
    
    val studentsInCourse = remember(selectedCourse, allStudents) { 
        allStudents.filter { student ->
            student.courseId == selectedCourse?.id && (student.status == "مستمر" || student.status.isEmpty())
        } 
    }

    // Identify student IDs who already have recorded grades for this subject
    val gradedStudentIdsForSubject = remember(dbAllGrades, selectedCourse, selectedSubject, studentsInCourse) {
        if (selectedCourse == null || selectedSubject.isEmpty()) emptySet()
        else {
            val courseStudentIds = studentsInCourse.map { it.id }.toSet()
            dbAllGrades.filter { grade ->
                (grade.courseId == selectedCourse?.id || grade.studentId in courseStudentIds) &&
                grade.subjectName == selectedSubject &&
                (grade.customScoresJson.contains("__theory_recorded__") ||
                 grade.theoreticalExamScore > 0.0 || 
                 grade.practicalExamScore > 0.0 ||
                 grade.getGradeNote().isNotEmpty() ||
                 (!grade.isDiploma && StudentGrade.deserializeScores(grade.customScoresJson).any { 
                     it.key.contains("نظري") || it.key.contains("عملي") || it.key.contains("اختبار") 
                 }))
            }.map { it.studentId }.toSet()
        }
    }

    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()
    
    var isEditMode by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<GradedStudentItem?>(null) }
    
    val ungradedStudents = remember(studentsInCourse, gradedStudentIdsForSubject) {
        studentsInCourse.filter { it.id !in gradedStudentIdsForSubject }
    }

    var selectedStudentId by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(ungradedStudents, selectedCourse, selectedSubject) {
        if (isEditMode) return@LaunchedEffect
        if (selectedStudentId == null || (!ungradedStudents.any { it.id == selectedStudentId } && !studentsInCourse.any { it.id == selectedStudentId })) {
            selectedStudentId = ungradedStudents.firstOrNull()?.id
        }
    }

    val currentStudent = remember(allStudents, selectedStudentId) {
        allStudents.find { it.id == selectedStudentId }
    }
    
    val todayFormatted = remember {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        sdf.format(java.util.Date())
    }
    var date by remember { mutableStateOf(todayFormatted) }
    var totalQuestions by remember { mutableStateOf("20") }
    var correctAnswers by remember { mutableStateOf("") }
    var incorrectAnswers by remember { mutableStateOf("") }
    var studentNote by remember { mutableStateOf("") }
    
    var gradingMode by remember { mutableStateOf("auto") } // "auto" or "manual"
    var enablePracticalGrade by remember { mutableStateOf(false) }
    var manualTheoryGrade by remember { mutableStateOf("") }
    var manualPracticalGrade by remember { mutableStateOf("") }
    var itemToDelete by remember { mutableStateOf<GradedStudentItem?>(null) }
    var itemToShare by remember { mutableStateOf<GradedStudentItem?>(null) }
    var showCourseShareDialog by remember { mutableStateOf(false) }
    
    val templateId = StudentGradeConfig.getDiplomaTemplateId(selectedCourse?.diplomaName ?: "")
    val deptTemplateId = StudentGradeConfig.getDepartmentTemplateId(selectedCourse?.departmentName ?: "")
    val dipConfig = gradeConfigs.find { it.courseId == templateId }
    val deptConfig = gradeConfigs.find { it.courseId == deptTemplateId }
    val courseConfig = gradeConfigs.find { it.courseId == selectedCourse?.id }
    val config = courseConfig ?: dipConfig ?: deptConfig
        
    val maxTheoryGrade = remember(dipConfig, deptConfig, courseConfig, selectedSubject) {
        val activeConfig = courseConfig ?: dipConfig ?: deptConfig
        if (activeConfig == null) 20
        else {
            val fields = StudentGradeConfig.deserializeFields(activeConfig.customFieldsJson)
            val specific = if (selectedSubject.isNotEmpty()) fields.find { it.first.startsWith("${selectedSubject}_") && it.first.contains("نظري") }?.second else null
            val plain = fields.find { it.first.contains("نظري") && !it.first.contains("_") }?.second
            val any = fields.find { it.first.contains("نظري") }?.second
            specific ?: plain ?: any ?: 20
        }
    }
    
    val maxPracticalGrade = remember(dipConfig, deptConfig, courseConfig, selectedSubject) {
        val activeConfig = courseConfig ?: dipConfig ?: deptConfig
        if (activeConfig == null) 40
        else {
            val fields = StudentGradeConfig.deserializeFields(activeConfig.customFieldsJson)
            val specific = if (selectedSubject.isNotEmpty()) fields.find { it.first.startsWith("${selectedSubject}_") && it.first.contains("عملي") }?.second else null
            val plain = fields.find { it.first.contains("عملي") && !it.first.contains("_") }?.second
            val any = fields.find { it.first.contains("عملي") }?.second
            specific ?: plain ?: any ?: 40
        }
    }
    
    val correct = correctAnswers.toIntOrNull() ?: 0
    val total = totalQuestions.toIntOrNull() ?: 1
    val calculatedTheoryGrade = (correct.toDouble() / total.toDouble() * maxTheoryGrade.toDouble()).let {
        if (it % 1.0 == 0.0) it.toInt().toString() else String.format(java.util.Locale.US, "%.1f", it)
    }

    // Color definitions for clean contrast
    val cardBg = if (isDark) DarkSurface else Color.White
    val cardBorder = if (isDark) DarkOutline else Color(0xFFE2E8F0)
    val textPrimary = if (isDark) DarkOnSurface else DawamiNavy
    val textSecondary = if (isDark) DarkOnSurfaceVariant else Color(0xFF64748B)

    // Compact Field Colors
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = textPrimary,
        unfocusedTextColor = textPrimary,
        focusedLabelColor = DawamiTeal,
        unfocusedLabelColor = textSecondary,
        focusedBorderColor = DawamiTeal,
        unfocusedBorderColor = if (isDark) DarkOutline else Color(0xFFCBD5E1),
        focusedLeadingIconColor = DawamiTeal,
        unfocusedLeadingIconColor = textSecondary,
        focusedTrailingIconColor = DawamiTeal,
        unfocusedTrailingIconColor = textSecondary,
        focusedContainerColor = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC),
        unfocusedContainerColor = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC)
    )

    // Transform DB grades into viewable list of graded students
    val gradedStudentsList = remember(
        dbAllGrades, courses, allStudents, selectedCourse, selectedSubject, studentsInCourse,
        dbAttendance, dbAllStudentAttendance
    ) {
        if (selectedCourse == null) emptyList()
        else {
            val currentCourseStudentIds = studentsInCourse.map { it.id }.toSet()
            val targetCourseId = selectedCourse?.id ?: 0
            val examDateInAttendance = dbAttendance.find {
                it.courseId == targetCourseId && it.isExamDay
            }?.date?.takeIf { it.isNotBlank() }

            dbAllGrades.filter { grade ->
                val matchesCourseOrStudentInCourse = grade.courseId == selectedCourse?.id || grade.studentId in currentCourseStudentIds
                val matchesSubject = selectedSubject.isEmpty() || grade.subjectName == selectedSubject

                val isGraded = grade.customScoresJson.contains("__theory_recorded__") ||
                    grade.theoreticalExamScore > 0.0 || 
                    grade.practicalExamScore > 0.0 ||
                    grade.getGradeNote().isNotEmpty() ||
                    (!grade.isDiploma && StudentGrade.deserializeScores(grade.customScoresJson).any { 
                        it.key.contains("نظري") || it.key.contains("عملي") || it.key.contains("اختبار") 
                    })
                
                val st = allStudents.find { it.id == grade.studentId }
                val isStudentInCurrentCourse = st?.courseId == selectedCourse?.id
                val isStudentActive = st == null || st.status == "مستمر" || st.status.isEmpty()

                matchesCourseOrStudentInCourse && isStudentInCurrentCourse && matchesSubject && isGraded && isStudentActive
            }.distinctBy { "${it.studentId}_${it.subjectName}" }
            .mapNotNull { grade ->
                val st = allStudents.find { it.id == grade.studentId }
                val crs = selectedCourse ?: courses.find { it.id == grade.courseId }
                
                val scoresMap = StudentGrade.deserializeScores(grade.customScoresJson)
                val theoryVal = if (grade.isDiploma) grade.theoreticalExamScore
                else {
                    scoresMap.entries.find { it.key.contains("نظري") || it.key.contains("اختبار") }?.value ?: 0.0
                }

                val practicalVal = if (grade.isDiploma) grade.practicalExamScore
                else {
                    scoresMap.entries.find { it.key.contains("عملي") }?.value ?: 0.0
                }

                val hasPractical = scoresMap.keys.any { it.contains("عملي") } || (grade.isDiploma && grade.practicalExamScore > 0.0)
                
                var recDate = grade.customScoresJson.split("|")
                    .find { it.startsWith("__theory_date__:") }
                    ?.substringAfter("__theory_date__:")
                    ?.trim() ?: ""

                if (recDate.isBlank()) {
                    recDate = examDateInAttendance ?: ""
                }
                if (recDate.isBlank()) {
                    recDate = dbAllStudentAttendance.filter {
                        it.studentId == grade.studentId &&
                        it.courseId == (selectedCourse?.id ?: grade.courseId) &&
                        (it.subjectName.trim().equals(selectedSubject.trim(), ignoreCase = true) ||
                         it.subjectName.contains(selectedSubject) ||
                         selectedSubject.contains(it.subjectName))
                    }.map { it.date }.maxOrNull() ?: ""
                }
                if (recDate.isBlank()) {
                    recDate = dbAllStudentAttendance.filter {
                        it.courseId == (selectedCourse?.id ?: grade.courseId) &&
                        (it.subjectName.trim().equals(selectedSubject.trim(), ignoreCase = true) ||
                         it.subjectName.contains(selectedSubject) ||
                         selectedSubject.contains(it.subjectName))
                    }.map { it.date }.maxOrNull() ?: ""
                }

                GradedStudentItem(
                    gradeRecordId = grade.id,
                    studentId = grade.studentId,
                    courseId = selectedCourse?.id ?: grade.courseId,
                    name = grade.studentName,
                    subjectName = grade.subjectName,
                    courseName = selectedCourse?.name ?: crs?.name ?: grade.courseName,
                    department = selectedCourse?.departmentName ?: crs?.departmentName ?: "",
                    diploma = selectedCourse?.diplomaName ?: crs?.diplomaName ?: "",
                    theoryGrade = theoryVal,
                    practicalGrade = practicalVal,
                    hasPracticalGrade = hasPractical,
                    note = grade.getGradeNote(),
                    dateOfRecording = recDate
                )
            }.reversed()
        }
    }

    // Locked date check: Look across all graded students for the actual recorded date
    val lockedDateValue = remember(gradedStudentsList) {
        gradedStudentsList.map { it.dateOfRecording }.firstOrNull { it.isNotBlank() }
    }
    val isDateLocked = remember(gradedStudentsList, lockedDateValue) {
        !lockedDateValue.isNullOrBlank()
    }

    LaunchedEffect(lockedDateValue) {
        if (!lockedDateValue.isNullOrBlank()) {
            date = lockedDateValue
        }
    }

    val innerContent: @Composable (PaddingValues) -> Unit = { innerPadding ->
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = if (isDark) DarkBackground else Color(0xFFF8FAFC)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(scrollState)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
            // Compact Header Bar
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DawamiNavy),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = Color.White.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.FactCheck, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                        Text("رصد الاختبار النظري والعملي", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    if (showMainLayout) {
                        IconButton(
                            onClick = { viewModel.navigateBack() },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f))
                                .size(26.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "رجوع",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        
            val courseGradingMode = selectedCourse?.let { courseGradingModes[it.id] ?: viewModel.getCourseGradingMode(it.id) } ?: "AUTO"
            val isCourseManualFinal = courseGradingMode == "MANUAL_FINAL"

            if (isCourseManualFinal) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF1E293B) else Color(0xFFFFFBEB)),
                    border = BorderStroke(1.dp, Color(0xFFFDE68A))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFF59E0B).copy(alpha = 0.15f),
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(28.dp))
                            }
                        }
                        Text(
                            text = "رصد الاختبار معطّل لهذه الدورة 🔒",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (isDark) Color(0xFFFBBF24) else Color(0xFF92400E)
                        )
                        Text(
                            text = "تم اعتماد (الرصد اليدوي النهائي) لدرجات دورة \"${selectedCourse?.name}\" من شاشة رصد الدرجات.\nيتم اعتماد الدرجة المرصودة يدوياً نهائياً كمرجع رسمي وحيد وتجاهل شاشة رصد الاختبارات لمنع تعارض الدرجات المعتمدة.",
                            fontSize = 11.5.sp,
                            color = if (isDark) Color(0xFFFDE68A) else Color(0xFFB45309),
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                        Button(
                            onClick = { viewModel.setSelectedGradesTabIndex(0) },
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("الانتقال إلى شاشة رصد الدرجات 📝", fontSize = 11.sp, color = Color.White)
                        }
                    }
                }
            } else {
            // Main Input Compact Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = BorderStroke(1.dp, cardBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    
                    if (isEditMode && editingItem != null) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFFF59E0B).copy(alpha = 0.12f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(16.dp))
                                    Column {
                                        Text(
                                            text = "وضع التعديل: جاري تعديل درجات (${editingItem?.name})",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFB45309)
                                        )
                                        Text(
                                            text = "الدورة: ${editingItem?.courseName} | المادة: ${editingItem?.subjectName}",
                                            fontSize = 9.5.sp,
                                            color = Color(0xFF92400E)
                                        )
                                    }
                                }
                                TextButton(
                                    onClick = {
                                        isEditMode = false
                                        editingItem = null
                                        correctAnswers = ""
                                        incorrectAnswers = ""
                                        manualTheoryGrade = ""
                                        manualPracticalGrade = ""
                                        studentNote = ""
                                        enablePracticalGrade = false
                                        selectedStudentId = ungradedStudents.firstOrNull()?.id
                                    },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("إلغاء ✕", color = Color(0xFFDC2626), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    if (isCourseEnded) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            color = if (isLockedForEditing) (if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC)) else (if (isDark) Color(0xFF451A03).copy(alpha = 0.5f) else Color(0xFFFFFBEB)),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (isLockedForEditing) (if (isDark) DarkOutline else Color(0xFFCBD5E1)) else Color(0xFFF59E0B))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = if (isLockedForEditing) Icons.Default.Lock else Icons.Default.LockOpen,
                                        contentDescription = null,
                                        tint = if (isLockedForEditing) (if (isDark) Color(0xFF94A3B8) else Color(0xFF475569)) else Color(0xFFD97706),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Column {
                                        Text(
                                            text = if (isLockedForEditing) "دورة منتهية رسمياً (وضع الأرشيف والحماية 🔒)" else "وضع التعديل الاستثنائي مفعّل ⚠️",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isLockedForEditing) textPrimary else Color(0xFFD97706)
                                        )
                                        val endDateTxt = selectedCourse?.endDate?.ifBlank { "تاريخ سابق" } ?: "تاريخ سابق"
                                        Text(
                                            text = if (isLockedForEditing) "انتهت بتاريخ ($endDateTxt). الدرجات محمية للقراءة فقط." else "يمكنك الآن تعديل ورصد الدرجات.",
                                            fontSize = 9.sp,
                                            color = textSecondary
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        if (isLockedForEditing) {
                                            showUnlockConfirmDialog = true
                                        } else {
                                            isEditUnlockedForEndedCourse = false
                                            Toast.makeText(context, "تمت إعادة قفل وحماية سجلات الاختبارات بنجاح 🔒", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isLockedForEditing) DawamiNavy else Color(0xFFD97706)
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isLockedForEditing) Icons.Default.LockOpen else Icons.Default.Lock,
                                        contentDescription = null,
                                        modifier = Modifier.size(12.dp),
                                        tint = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isLockedForEditing) "فتح القفل 🔓" else "إعادة القفل 🔒",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }

                    Text(
                        "تحديد الدورة والمادة والطالب:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp,
                        color = textPrimary
                    )

                    // Row 1: Course & Subject
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Course Dropdown
                        var isCourseExpanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.weight(1f)) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isCourseExpanded = true }
                                    .border(1.dp, if (isDark) DarkOutline else Color(0xFFCBD5E1), RoundedCornerShape(10.dp)),
                                color = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                                    Text("الدورة", fontSize = 9.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = selectedCourse?.name ?: "اختر الدورة",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = textPrimary,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = textSecondary)
                                    }
                                }
                            }
                            DropdownMenu(
                                expanded = isCourseExpanded,
                                onDismissRequest = { isCourseExpanded = false }
                            ) {
                                courses.forEach { crs ->
                                    DropdownMenuItem(
                                        text = { 
                                            Column {
                                                Text(crs.name, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                                if (crs.diplomaName.isNotBlank() || crs.departmentName.isNotBlank()) {
                                                    Text(
                                                        listOf(crs.departmentName, crs.diplomaName).filter { it.isNotBlank() }.joinToString(" • "),
                                                        fontSize = 8.5.sp,
                                                        color = textSecondary
                                                    )
                                                }
                                            }
                                        },
                                        onClick = {
                                            selectedCourse = crs
                                            isCourseExpanded = false
                                            selectedStudentId = null
                                        }
                                    )
                                }
                            }
                        }

                        // Subject Dropdown
                        var isSubjectExpanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.weight(1f)) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isSubjectExpanded = true }
                                    .border(1.dp, if (isDark) DarkOutline else Color(0xFFCBD5E1), RoundedCornerShape(10.dp)),
                                color = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                                    Text("المادة", fontSize = 9.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = selectedSubject.ifEmpty { "اختر المادة" },
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = textPrimary,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = textSecondary)
                                    }
                                }
                            }
                            DropdownMenu(
                                expanded = isSubjectExpanded,
                                onDismissRequest = { isSubjectExpanded = false }
                            ) {
                                courseSubjects.forEach { subj ->
                                    DropdownMenuItem(
                                        text = { Text(subj, fontSize = 10.5.sp) },
                                        onClick = {
                                            selectedSubject = subj
                                            isSubjectExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Row 2: Student Dropdown & Date
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Student Dropdown
                        var isStudentExpanded by remember { mutableStateOf(false) }
                        val studentLabelText = when {
                            currentStudent != null -> currentStudent.name
                            ungradedStudents.isEmpty() && studentsInCourse.isNotEmpty() -> "تم رصد جميع الطلاب 🎉"
                            else -> "لا يوجد طلاب"
                        }

                        Box(modifier = Modifier.weight(1.1f)) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isStudentExpanded = true }
                                    .border(1.dp, if (isDark) DarkOutline else Color(0xFFCBD5E1), RoundedCornerShape(10.dp)),
                                color = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                                    Text("الطالب الحالي", fontSize = 9.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = studentLabelText,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (ungradedStudents.isEmpty() && currentStudent == null) DawamiGold else DawamiTeal,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = textSecondary)
                                    }
                                }
                            }
                            DropdownMenu(
                                expanded = isStudentExpanded,
                                onDismissRequest = { isStudentExpanded = false }
                            ) {
                                if (ungradedStudents.isEmpty() && studentsInCourse.isNotEmpty()) {
                                    DropdownMenuItem(
                                        text = { Text("🎉 تم رصد درجات جميع الطلاب في هذه الدورة", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiTeal) },
                                        onClick = { isStudentExpanded = false }
                                    )
                                    HorizontalDivider(thickness = 0.5.dp)
                                } else {
                                    ungradedStudents.forEach { st ->
                                        DropdownMenuItem(
                                            text = { Text("📋 ${st.name}", fontSize = 10.5.sp) },
                                            onClick = {
                                                selectedStudentId = st.id
                                                isStudentExpanded = false
                                            }
                                        )
                                    }
                                }

                                if (studentsInCourse.any { it.id in gradedStudentIdsForSubject }) {
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp), thickness = 0.5.dp)
                                    Text("طلاب تم رصد درجاتهم (للتعديل):", fontSize = 9.sp, color = textSecondary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                                    studentsInCourse.filter { it.id in gradedStudentIdsForSubject }.forEach { st ->
                                        DropdownMenuItem(
                                            text = { Text("✅ ${st.name}", fontSize = 10.sp, color = textSecondary) },
                                            onClick = {
                                                selectedStudentId = st.id
                                                isStudentExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Date (Locked after first recording for the course/subject to prevent duplicate/split records)
                        if (isDateLocked) {
                            Surface(
                                modifier = Modifier
                                    .weight(0.9f)
                                    .fillMaxWidth()
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp)),
                                color = if (isDark) DarkSurface.copy(alpha = 0.5f) else Color(0xFFF1F5F9),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 5.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("التاريخ (مُثبّت)", fontWeight = FontWeight.Bold, fontSize = 9.sp, color = textSecondary, maxLines = 1)
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = "مُثبّت",
                                            tint = DawamiGold,
                                            modifier = Modifier.size(11.dp)
                                        )
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DateRange,
                                            contentDescription = null,
                                            tint = DawamiNavy.copy(alpha = 0.6f),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = date,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = textPrimary.copy(alpha = 0.8f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        } else {
                            com.example.ui.components.InlineExpandableDatePicker(
                                selectedDate = date,
                                onDateSelected = { date = it },
                                label = "التاريخ",
                                modifier = Modifier.weight(0.9f)
                            )
                        }
                    }

                    // Row 3: Note Field
                    OutlinedTextField(
                        value = studentNote,
                        onValueChange = { studentNote = it },
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 10.5.sp, fontWeight = FontWeight.Medium),
                        placeholder = { Text("إضافة ملاحظة حول الطالب أو الاختبار (اختياري)...", fontSize = 9.5.sp, color = textSecondary) },
                        label = { Text("الملاحظة", fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = {
                            Icon(Icons.Default.StickyNote2, contentDescription = null, tint = DawamiGold, modifier = Modifier.size(16.dp))
                        },
                        trailingIcon = {
                            if (studentNote.isNotEmpty()) {
                                IconButton(onClick = { studentNote = "" }, modifier = Modifier.size(20.dp)) {
                                    Icon(Icons.Default.Clear, contentDescription = "مسح", tint = textSecondary, modifier = Modifier.size(14.dp))
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = fieldColors
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp), thickness = 0.5.dp, color = cardBorder)
                    
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "بيانات الدرجات:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = textPrimary
                        )
                        Row(
                            modifier = Modifier
                                .background(if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9), RoundedCornerShape(6.dp))
                                .padding(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(if (gradingMode == "auto") DawamiTeal else Color.Transparent)
                                    .clickable { gradingMode = "auto" }
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text("تصحيح آلي", fontSize = 9.5.sp, color = if (gradingMode == "auto") Color.White else textSecondary, fontWeight = FontWeight.Bold)
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(if (gradingMode == "manual") DawamiTeal else Color.Transparent)
                                    .clickable { gradingMode = "manual" }
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text("رصد يدوي", fontSize = 9.5.sp, color = if (gradingMode == "manual") Color.White else textSecondary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (gradingMode == "auto") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { enablePracticalGrade = !enablePracticalGrade }
                                .padding(vertical = 1.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = enablePracticalGrade,
                                onCheckedChange = { enablePracticalGrade = it },
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة درجة العملي", fontSize = 10.sp, color = textPrimary)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = totalQuestions,
                                onValueChange = { totalQuestions = it },
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 10.5.sp, fontWeight = FontWeight.Medium),
                                label = { Text("الأسئلة", fontSize = 8.5.sp, maxLines = 1, softWrap = false) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = fieldColors,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )

                            OutlinedTextField(
                                value = correctAnswers,
                                onValueChange = { 
                                    var text = it.filter { c -> c.isDigit() }
                                    var c = text.toIntOrNull() ?: 0
                                    val t = totalQuestions.toIntOrNull() ?: 0
                                    if (c > t) {
                                        c = t
                                        text = t.toString()
                                    }
                                    correctAnswers = text
                                    if (t > 0) incorrectAnswers = (t - c).coerceAtLeast(0).toString()
                                },
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiTeal),
                                label = { Text("صحيحة", fontSize = 8.5.sp, maxLines = 1, softWrap = false) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = DawamiTeal,
                                    unfocusedTextColor = DawamiTeal,
                                    focusedBorderColor = DawamiTeal,
                                    unfocusedBorderColor = if (isDark) DarkOutline else Color(0xFFCBD5E1),
                                    focusedContainerColor = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC),
                                    unfocusedContainerColor = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC)
                                )
                            )

                            OutlinedTextField(
                                value = incorrectAnswers,
                                onValueChange = { incorrectAnswers = it.filter { c -> c.isDigit() } },
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 10.5.sp, fontWeight = FontWeight.Medium, color = Color.Red),
                                label = { Text("خاطئة", fontSize = 8.5.sp, maxLines = 1, softWrap = false) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.Red,
                                    unfocusedTextColor = Color.Red,
                                    focusedBorderColor = Color.Red,
                                    unfocusedBorderColor = if (isDark) DarkOutline else Color(0xFFCBD5E1),
                                    focusedContainerColor = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC),
                                    unfocusedContainerColor = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC)
                                )
                            )

                            OutlinedTextField(
                                value = calculatedTheoryGrade,
                                onValueChange = {},
                                readOnly = true,
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = textPrimary),
                                label = { Text("نظري ($maxTheoryGrade)", fontSize = 8.5.sp, maxLines = 1, softWrap = false) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = textPrimary,
                                    unfocusedTextColor = textPrimary,
                                    focusedBorderColor = DawamiTeal,
                                    unfocusedBorderColor = if (isDark) DarkOutline else Color(0xFFCBD5E1),
                                    focusedContainerColor = DawamiTeal.copy(alpha = 0.15f),
                                    unfocusedContainerColor = DawamiTeal.copy(alpha = 0.15f)
                                )
                            )
                        }
                        
                        if (enablePracticalGrade) {
                            OutlinedTextField(
                                value = manualPracticalGrade,
                                onValueChange = { 
                                    manualPracticalGrade = it.filter { c -> c.isDigit() || c == '.' }
                                    val v = manualPracticalGrade.toDoubleOrNull() ?: 0.0
                                    if (v > maxPracticalGrade) manualPracticalGrade = maxPracticalGrade.toString()
                                },
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 10.5.sp, fontWeight = FontWeight.Medium),
                                label = { Text("درجة الاختبار العملي (من $maxPracticalGrade)", fontSize = 9.5.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = fieldColors,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        }
                    } else {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = manualTheoryGrade,
                                onValueChange = { 
                                    manualTheoryGrade = it.filter { c -> c.isDigit() || c == '.' }
                                    val v = manualTheoryGrade.toDoubleOrNull() ?: 0.0
                                    if (v > maxTheoryGrade) manualTheoryGrade = maxTheoryGrade.toString()
                                },
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 11.5.sp, fontWeight = FontWeight.Bold),
                                label = { Text("درجة النظري (من $maxTheoryGrade)", fontSize = 9.5.sp) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = fieldColors,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                            OutlinedTextField(
                                value = manualPracticalGrade,
                                onValueChange = { 
                                    manualPracticalGrade = it.filter { c -> c.isDigit() || c == '.' }
                                    val v = manualPracticalGrade.toDoubleOrNull() ?: 0.0
                                    if (v > maxPracticalGrade) manualPracticalGrade = maxPracticalGrade.toString()
                                },
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 11.5.sp, fontWeight = FontWeight.Bold),
                                label = { Text("درجة العملي (من $maxPracticalGrade)", fontSize = 9.5.sp) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = fieldColors,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        }
                    }
                    
                    // Submit Button
                    Button(
                        onClick = {
                            if (isLockedForEditing) {
                                Toast.makeText(context, "سجلات هذه الدورة منتهية ومحمية 🔒. يرجى فتح قفل التعديل أولاً من الشريط بالأعلى.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val student = currentStudent
                            val course = selectedCourse
                            val subject = selectedSubject
                            
                            if (student == null || course == null) {
                                Toast.makeText(context, "الرجاء اختيار الدورة والطالب أولاً", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (subject.isEmpty()) {
                                Toast.makeText(context, "الرجاء اختيار المادة", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            
                            val finalTheoryNumeric = if (gradingMode == "auto") {
                                if (correctAnswers.isEmpty()) {
                                    Toast.makeText(context, "الرجاء إدخال عدد الإجابات الصحيحة", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                calculatedTheoryGrade.toDoubleOrNull() ?: 0.0
                            } else {
                                if (manualTheoryGrade.isEmpty() && manualPracticalGrade.isEmpty()) {
                                    Toast.makeText(context, "الرجاء إدخال درجة واحدة على الأقل", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                manualTheoryGrade.toDoubleOrNull() ?: 0.0
                            }
                            
                            val finalPracticalNumeric = manualPracticalGrade.toDoubleOrNull() ?: 0.0
                            val updatePractical = (gradingMode == "auto" && enablePracticalGrade) || (gradingMode == "manual" && manualPracticalGrade.isNotEmpty())
                            
                            // Find existing grade record in DB for this student + course + subject (or previous course if moved)
                            val existingGradeRecord = if (isEditMode && editingItem != null) {
                                dbAllGrades.find { it.id == editingItem?.gradeRecordId }
                                    ?: dbAllGrades.find { it.studentId == student.id && it.courseId == course.id && it.subjectName == subject }
                                    ?: dbAllGrades.find { it.studentId == student.id && it.subjectName == subject }
                            } else {
                                dbAllGrades.find { 
                                    it.studentId == student.id && it.courseId == course.id && it.subjectName == subject 
                                } ?: dbAllGrades.find {
                                    it.studentId == student.id && it.subjectName == subject
                                }
                            }
                            
                            val isDiploma = config?.isDiploma ?: true
                            val effectiveDate = if (isDateLocked && !lockedDateValue.isNullOrBlank()) lockedDateValue else date
                            
                            val gradeToSave = if (existingGradeRecord != null) {
                                val existingDate = existingGradeRecord.customScoresJson.split("|")
                                    .find { it.startsWith("__theory_date__:") }
                                    ?.substringAfter("__theory_date__:") ?: ""
                                val dateForRecord = if (existingDate.isNotBlank()) existingDate else effectiveDate

                                if (isDiploma) {
                                    val currentScores = StudentGrade.deserializeScores(existingGradeRecord.customScoresJson).toMutableMap()
                                    currentScores["__theory_recorded__"] = 1.0
                                    val practicalKey = currentScores.keys.find { it.contains("عملي") } ?: "اختبار عملي"
                                    if (updatePractical) {
                                        currentScores[practicalKey] = finalPracticalNumeric
                                    }
                                    val practicalVal = if (updatePractical) finalPracticalNumeric else existingGradeRecord.practicalExamScore
                                    val serialized = StudentGrade.serializeScores(currentScores)
                                    val withNote = StudentGrade.withNote(serialized, studentNote)
                                    val withDate = if (dateForRecord.isNotBlank()) {
                                        withNote.split("|").filter { it.isNotEmpty() && !it.startsWith("__theory_date__:") }
                                            .plus("__theory_date__:$dateForRecord")
                                            .joinToString("|")
                                    } else withNote

                                    existingGradeRecord.copy(
                                        courseId = course.id,
                                        courseName = course.name,
                                        theoreticalExamScore = finalTheoryNumeric,
                                        practicalExamScore = practicalVal,
                                        customScoresJson = withDate
                                    )
                                } else {
                                    val currentScores = StudentGrade.deserializeScores(existingGradeRecord.customScoresJson).toMutableMap()
                                    currentScores["__theory_recorded__"] = 1.0
                                    val theoryKey = currentScores.keys.find { it.contains("نظري") || it.contains("اختبار") } ?: "اختبار نظري"
                                    val practicalKey = currentScores.keys.find { it.contains("عملي") } ?: "اختبار عملي"
                                    currentScores[theoryKey] = finalTheoryNumeric
                                    if (updatePractical) {
                                        currentScores[practicalKey] = finalPracticalNumeric
                                    }
                                    val serialized = StudentGrade.serializeScores(currentScores)
                                    val withNote = StudentGrade.withNote(serialized, studentNote)
                                    val withDate = if (dateForRecord.isNotBlank()) {
                                        withNote.split("|").filter { it.isNotEmpty() && !it.startsWith("__theory_date__:") }
                                            .plus("__theory_date__:$dateForRecord")
                                            .joinToString("|")
                                    } else withNote

                                    existingGradeRecord.copy(
                                        courseId = course.id,
                                        courseName = course.name,
                                        customScoresJson = withDate
                                    )
                                }
                            } else {
                                val dateForRecord = effectiveDate
                                if (isDiploma) {
                                    val currentScores = mutableMapOf<String, Double>()
                                    currentScores["__theory_recorded__"] = 1.0
                                    if (updatePractical) {
                                        currentScores["اختبار عملي"] = finalPracticalNumeric
                                    }
                                    val serialized = StudentGrade.serializeScores(currentScores)
                                    val withNote = StudentGrade.withNote(serialized, studentNote)
                                    val withDate = if (dateForRecord.isNotBlank()) {
                                        withNote.split("|").filter { it.isNotEmpty() && !it.startsWith("__theory_date__:") }
                                            .plus("__theory_date__:$dateForRecord")
                                            .joinToString("|")
                                    } else withNote

                                    StudentGrade(
                                        studentId = student.id,
                                        studentName = student.name,
                                        courseId = course.id,
                                        courseName = course.name,
                                        isDiploma = true,
                                        subjectName = subject,
                                        theoreticalExamScore = finalTheoryNumeric,
                                        practicalExamScore = if (updatePractical) finalPracticalNumeric else 0.0,
                                        customScoresJson = withDate
                                    )
                                } else {
                                    val currentScores = mutableMapOf<String, Double>()
                                    currentScores["__theory_recorded__"] = 1.0
                                    currentScores["اختبار نظري"] = finalTheoryNumeric
                                    if (updatePractical) {
                                        currentScores["اختبار عملي"] = finalPracticalNumeric
                                    }
                                    val serialized = StudentGrade.serializeScores(currentScores)
                                    val withNote = StudentGrade.withNote(serialized, studentNote)
                                    val withDate = if (dateForRecord.isNotBlank()) {
                                        withNote.split("|").filter { it.isNotEmpty() && !it.startsWith("__theory_date__:") }
                                            .plus("__theory_date__:$dateForRecord")
                                            .joinToString("|")
                                    } else withNote

                                    StudentGrade(
                                        studentId = student.id,
                                        studentName = student.name,
                                        courseId = course.id,
                                        courseName = course.name,
                                        isDiploma = false,
                                        subjectName = subject,
                                        customScoresJson = withDate
                                    )
                                }
                            }
                            
                            // Save directly to DB via ViewModel
                            if (gradingViewModel != null) {
                                gradingViewModel.saveStudentGrade(gradeToSave)
                            } else {
                                viewModel.saveStudentGrade(gradeToSave)
                            }
                            
                            // Clear inputs
                            correctAnswers = ""
                            incorrectAnswers = ""
                            manualTheoryGrade = ""
                            manualPracticalGrade = ""
                            studentNote = ""

                            if (isEditMode) {
                                Toast.makeText(
                                    context,
                                    "تم تحديث درجات الطالب ${student.name} بنجاح! 📝✅",
                                    Toast.LENGTH_SHORT
                                ).show()
                                isEditMode = false
                                editingItem = null
                                val remainingUngraded = ungradedStudents.filter { it.id != student.id }
                                selectedStudentId = remainingUngraded.firstOrNull()?.id
                            } else {
                                val remainingUngraded = ungradedStudents.filter { it.id != student.id }
                                if (remainingUngraded.isNotEmpty()) {
                                    selectedStudentId = remainingUngraded.first().id
                                    Toast.makeText(
                                        context,
                                        "تم رصد الدرجة للطالب ${student.name} بنجاح! 📝✨",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    selectedStudentId = null
                                    Toast.makeText(context, "🎉 تم رصد درجات جميع طلاب هذه الدورة بنجاح!", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isEditMode) Color(0xFFD97706) else DawamiNavy
                        )
                    ) {
                        Icon(if (isEditMode) Icons.Default.Edit else Icons.Default.Save, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            if (isEditMode) "تحديث وحفظ تعديل درجة الطالب 💾" else if (ungradedStudents.isEmpty() && currentStudent == null) "تم رصد جميع طلاب الدورة 🎉" else "حفظ وترحيل درجة الطالب التالي",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }

            // Recent Graded Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (selectedSubject.isNotEmpty()) "الدرجات المرصودة لمادة (${selectedSubject})" else "الطلاب الذين تم رصد درجاتهم مؤخراً",
                    fontWeight = FontWeight.Bold,
                    color = textPrimary,
                    fontSize = 11.sp
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (gradedStudentsList.isNotEmpty()) {
                        Button(
                            onClick = { showCourseShareDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "مشاركة نتائج الدورة", tint = Color.White, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مشاركة نتائج الدورة 📤", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("${gradedStudentsList.size} طالب", color = textSecondary, fontSize = 11.sp)
                }
            }

            if (gradedStudentsList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .background(cardBg, RoundedCornerShape(12.dp))
                        .clip(RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (selectedSubject.isNotEmpty()) "لم يتم رصد أي درجات لمادة (${selectedSubject}) بعد." else "لم يتم رصد أي درجات بعد.",
                        color = textSecondary,
                        fontSize = 11.5.sp
                    )
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    gradedStudentsList.chunked(2).forEach { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            pair.forEach { item ->
                                Box(modifier = Modifier.weight(1f)) {
                                    StudentGradeCard(
                                        student = item,
                                        isDark = isDark,
                                        isLocked = isLockedForEditing,
                                        onEdit = {
                                            val studentCourse = courses.find { it.id == item.courseId }
                                                ?: courses.find { it.name == item.courseName }
                                            if (studentCourse != null) {
                                                selectedCourse = studentCourse
                                            }
                                            selectedSubject = item.subjectName
                                            selectedStudentId = item.studentId
                                            isEditMode = true
                                            editingItem = item
                                            studentNote = item.note
                                            if (item.dateOfRecording.isNotBlank()) {
                                                date = item.dateOfRecording
                                            }
                                            
                                            val gradeVal = item.theoryGrade
                                            manualTheoryGrade = if (gradeVal % 1.0 == 0.0) gradeVal.toInt().toString() else gradeVal.toString()
                                            totalQuestions = "20"
                                            correctAnswers = manualTheoryGrade
                                            val t = 20
                                            val c = gradeVal.toInt()
                                            incorrectAnswers = (t - c).coerceAtLeast(0).toString()
                                            
                                            if (item.hasPracticalGrade || item.practicalGrade > 0.0) {
                                                enablePracticalGrade = true
                                                manualPracticalGrade = if (item.practicalGrade % 1.0 == 0.0) item.practicalGrade.toInt().toString() else item.practicalGrade.toString()
                                            } else {
                                                enablePracticalGrade = false
                                                manualPracticalGrade = ""
                                            }
                                            
                                            Toast.makeText(context, "تم تحميل بيانات الطالب للتعديل 📝", Toast.LENGTH_SHORT).show()
                                            coroutineScope.launch {
                                                scrollState.animateScrollTo(0)
                                            }
                                        },
                                        onDelete = {
                                            itemToDelete = item
                                        },
                                        onShare = {
                                            itemToShare = item
                                        }
                                    )
                                }
                            }
                            if (pair.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
            }
            
            if (itemToShare != null) {
                val student = itemToShare!!
                val stPhone = allStudents.find { it.id == student.studentId }?.phoneNumber ?: ""
                val instName = viewModel.instituteName.collectAsState().value.ifBlank { "معهد دوامي للتدريب" }

                val totalGrade = student.theoryGrade + student.practicalGrade
                val formattedTheory = if (student.theoryGrade % 1.0 == 0.0) student.theoryGrade.toInt().toString() else student.theoryGrade.toString()
                val formattedPractical = if (student.practicalGrade % 1.0 == 0.0) student.practicalGrade.toInt().toString() else student.practicalGrade.toString()
                val formattedTotal = if (totalGrade % 1.0 == 0.0) totalGrade.toInt().toString() else totalGrade.toString()

                val shareText = buildString {
                    appendLine("نتيجة الاختبار - $instName 📝")
                    appendLine()
                    appendLine("👤 الطالب/ـة: ${student.name}")
                    if (student.courseName.isNotBlank()) {
                        appendLine("📚 الدورة: ${student.courseName}")
                    }
                    if (student.subjectName.isNotBlank()) {
                        appendLine("📖 المادة: ${student.subjectName}")
                    }
                    appendLine()
                    appendLine("📊 تفاصيل الدرجات:")
                    appendLine("• الاختبار النظري: $formattedTheory")
                    if (student.hasPracticalGrade || student.practicalGrade > 0.0) {
                        appendLine("• الاختبار العملي: $formattedPractical")
                    }
                    appendLine("• المجموع الكلي: $formattedTotal")
                    if (student.note.isNotBlank()) {
                        appendLine("📝 ملاحظة: ${student.note}")
                    }
                    appendLine()
                    val c = selectedCourse
                    if (!c?.trainerName.isNullOrBlank()) {
                        appendLine("المدرب المعتمد: ${c?.trainerName}")
                    }
                    if (!c?.departmentName.isNullOrBlank()) {
                        appendLine("القسم: ${c?.departmentName}")
                    }
                    appendLine("المعهد: $instName ✨")
                }

                AlertDialog(
                    onDismissRequest = { itemToShare = null },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = if (isDark) DawamiGold else DawamiNavy)
                            Text("مشاركة درجة الطالب 📤", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = textPrimary)
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = "اختر طريقة المشاركة لنتيجة الطالب (${student.name}):",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            
                            Surface(
                                color = DawamiNavy.copy(alpha = 0.05f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.15f))
                            ) {
                                Text(
                                    text = shareText,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }

                            // 1. WhatsApp Normal
                            Button(
                                onClick = {
                                    val msg = shareText
                                    val phone = stPhone
                                    itemToShare = null
                                    shareToWhatsAppPkg(context, phone, msg, isBusiness = false)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("💬", fontSize = 14.sp)
                                    Text("واتساب (WhatsApp العادي)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                }
                            }

                            // 2. WhatsApp Business
                            Button(
                                onClick = {
                                    val msg = shareText
                                    val phone = stPhone
                                    itemToShare = null
                                    shareToWhatsAppPkg(context, phone, msg, isBusiness = true)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("💼", fontSize = 14.sp)
                                    Text("واتساب أعمال (WhatsApp Business)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                }
                            }

                            // 3. General Share
                            Button(
                                onClick = {
                                    val msg = shareText
                                    itemToShare = null
                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, msg)
                                    }
                                    val shareIntent = Intent.createChooser(sendIntent, "مشاركة درجة الطالب عبر")
                                    context.startActivity(shareIntent)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Text("مشاركة عامة (تطبيقات أخرى) 🔗", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton(onClick = { itemToShare = null }) {
                            Text("إلغاء", color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                    },
                    shape = RoundedCornerShape(18.dp),
                    containerColor = if (isDark) DarkSurface else Color.White
                )
            }

            if (showCourseShareDialog && gradedStudentsList.isNotEmpty()) {
                val courseTitle = selectedCourse?.name ?: gradedStudentsList.firstOrNull()?.courseName ?: ""
                val subjectTitle = selectedSubject.ifEmpty { gradedStudentsList.firstOrNull()?.subjectName ?: "" }
                val deptTitle = selectedCourse?.departmentName ?: gradedStudentsList.firstOrNull()?.department ?: ""
                val trainerTitle = selectedCourse?.trainerName ?: ""
                val recordDate = lockedDateValue ?: date
                val totalStudentsCount = gradedStudentsList.size

                val totalScores = gradedStudentsList.map { it.theoryGrade + (if (it.hasPracticalGrade) it.practicalGrade else 0.0) }
                val maxScore = totalScores.maxOrNull() ?: 0.0
                val minScore = totalScores.minOrNull() ?: 0.0
                val formatNum: (Double) -> String = { num -> if (num % 1.0 == 0.0) num.toInt().toString() else "%.1f".format(java.util.Locale.US, num) }

                val courseShareText = buildString {
                    appendLine("📊 *كشف نتائج الاختبار النظري للدورة*")
                    appendLine("━━━━━━━━━━━━━━━━━━━")
                    if (courseTitle.isNotBlank()) appendLine("📚 *الدورة:* $courseTitle")
                    if (subjectTitle.isNotBlank()) appendLine("📖 *المادة:* $subjectTitle")
                    if (deptTitle.isNotBlank()) appendLine("🏢 *القسم:* $deptTitle")
                    if (trainerTitle.isNotBlank()) appendLine("👨‍🏫 *المدرب:* $trainerTitle")
                    if (recordDate.isNotBlank()) appendLine("📅 *تاريخ الرصد:* $recordDate")
                    appendLine("━━━━━━━━━━━━━━━━━━━")
                    appendLine("📈 *الملخص العام:*")
                    appendLine("• إجمالي الطلاب المرصودين: $totalStudentsCount")
                    appendLine("• أعلى مجموع: ${formatNum(maxScore)}")
                    appendLine("• أدنى مجموع: ${formatNum(minScore)}")
                    appendLine("━━━━━━━━━━━━━━━━━━━")
                    appendLine("📋 *قائمة درجات الطلاب:*")
                    gradedStudentsList.forEachIndexed { index, item ->
                        val itemTotal = item.theoryGrade + (if (item.hasPracticalGrade) item.practicalGrade else 0.0)
                        appendLine("\n${index + 1}. *${item.name}*")
                        appendLine("   - النظري: ${formatNum(item.theoryGrade)}")
                        if (item.hasPracticalGrade || item.practicalGrade > 0.0) {
                            appendLine("   - العملي: ${formatNum(item.practicalGrade)}")
                        }
                        appendLine("   - المجموع: ${formatNum(itemTotal)}")
                        if (item.note.isNotBlank()) {
                            appendLine("   - ملاحظة: ${item.note}")
                        }
                    }
                    appendLine("\n━━━━━━━━━━━━━━━━━━━")
                    appendLine("✨ تم التصدير عبر نظام دوامي")
                }

                AlertDialog(
                    onDismissRequest = { showCourseShareDialog = false },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = DawamiNavy)
                            Text(
                                "مشاركة نتائج الدورة 📤",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp,
                                color = textPrimary
                            )
                        }
                    },
                    text = {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                "اختر وسيلة المشاركة لإرسال كشف درجات الطلاب لمادة ($subjectTitle) لدورة ($courseTitle):",
                                fontSize = 11.5.sp,
                                color = textSecondary
                            )

                            // Preview Box
                            Surface(
                                color = if (isDark) DarkBackground else Color(0xFFF1F5F9),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("معاينة نص الرسالة:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                        Text("${gradedStudentsList.size} طالب", fontSize = 9.5.sp, color = textSecondary)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        courseShareText,
                                        fontSize = 9.5.sp,
                                        lineHeight = 14.sp,
                                        color = textPrimary,
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // 1. WhatsApp Normal
                            Button(
                                onClick = {
                                    showCourseShareDialog = false
                                    shareToWhatsAppPkg(context, "", courseShareText, isBusiness = false)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("💬", fontSize = 14.sp)
                                    Text("واتساب (WhatsApp العادي)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                }
                            }

                            // 2. WhatsApp Business
                            Button(
                                onClick = {
                                    showCourseShareDialog = false
                                    shareToWhatsAppPkg(context, "", courseShareText, isBusiness = true)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("💼", fontSize = 14.sp)
                                    Text("واتساب أعمال (WhatsApp Business)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                }
                            }

                            // 3. General Share
                            Button(
                                onClick = {
                                    showCourseShareDialog = false
                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, courseShareText)
                                    }
                                    val shareIntent = Intent.createChooser(sendIntent, "مشاركة نتائج الدورة عبر")
                                    context.startActivity(shareIntent)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Text("مشاركة عامة (تطبيقات أخرى) 🔗", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton(onClick = { showCourseShareDialog = false }) {
                            Text("إلغاء", color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                    },
                    shape = RoundedCornerShape(18.dp),
                    containerColor = if (isDark) DarkSurface else Color.White
                )
            }

            if (itemToDelete != null) {
                AlertDialog(
                    onDismissRequest = { itemToDelete = null },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626))
                            Text(
                                text = "تأكيد حذف رصد درجة الطالب ⚠️",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = textPrimary
                            )
                        }
                    },
                    text = {
                        Text(
                            text = "هل أنت تأكد من رغبتك في إلغاء وحذف رصد درجة الطالب:\n\"${itemToDelete?.name}\"؟",
                            fontSize = 12.5.sp,
                            color = textSecondary
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val item = itemToDelete
                                itemToDelete = null
                                if (item != null) {
                                    val recordToReset = dbAllGrades.find { it.id == item.gradeRecordId }
                                    if (recordToReset != null) {
                                        if (gradingViewModel != null) {
                                            gradingViewModel.deleteGrade(recordToReset)
                                        } else {
                                            viewModel.deleteStudentGrade(recordToReset)
                                        }
                                        Toast.makeText(context, "تم إلغاء رصد درجة الطالب بنجاح", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                        ) {
                            Text("حذف", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        OutlinedButton(onClick = { itemToDelete = null }) {
                            Text("إلغاء", color = if (isDark) DarkOnSurface else DawamiNavy)
                        }
                    },
                    shape = RoundedCornerShape(18.dp),
                    containerColor = if (isDark) DarkSurface else Color.White
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
} // end of innerContent

    if (showMainLayout) {
        MainLayout(viewModel = viewModel, showScaffold = showMainLayout) { innerPadding ->
            innerContent.invoke(innerPadding)
        }
    } else {
        innerContent.invoke(PaddingValues(0.dp))
    }

    if (showUnlockConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showUnlockConfirmDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.WarningAmber, contentDescription = null, tint = Color(0xFFD97706))
                    Text("تأكيد فتح قفل التعديل 🔓", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Text(
                    text = "تنبيه: هذه الدورة (${selectedCourse?.name ?: ""}) مكتملة ومنتهية رسمياً.\n\n" +
                            "السجلات محفوظة حالياً في وضع الحماية والأرشيف لمنع أي تغيير غير مقصود.\n\n" +
                            "هل تريد فتح قفل التعديل لتعديل أو رصد درجات الاختبارات؟",
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUnlockConfirmDialog = false
                        isEditUnlockedForEndedCourse = true
                        Toast.makeText(context, "تم فتح قفل التعديل بنجاح 🔓. يمكنك الآن تعديل ورصد الدرجات.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("نعم، فتح قفل التعديل 🔓", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showUnlockConfirmDialog = false }
                ) {
                    Text("إلغاء")
                }
            }
        )
    }
}

private fun shareToWhatsAppPkg(context: Context, phoneNumber: String, message: String, isBusiness: Boolean) {
    val cleanNumber = phoneNumber.replace(Regex("[^0-9]"), "").removePrefix("00")
    val formattedPhone = if (cleanNumber.length == 9 && (cleanNumber.startsWith("77") || cleanNumber.startsWith("73") || cleanNumber.startsWith("71") || cleanNumber.startsWith("70") || cleanNumber.startsWith("78"))) {
        "967$cleanNumber"
    } else {
        cleanNumber
    }
    
    val pkg = if (isBusiness) "com.whatsapp.w4b" else "com.whatsapp"
    val encodedMsg = Uri.encode(message)
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = if (formattedPhone.isNotBlank()) {
                Uri.parse("https://api.whatsapp.com/send?phone=$formattedPhone&text=$encodedMsg")
            } else {
                Uri.parse("https://api.whatsapp.com/send?text=$encodedMsg")
            }
            setPackage(pkg)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                setPackage(pkg)
            }
            context.startActivity(intent)
        } catch (ex: Exception) {
            val appName = if (isBusiness) "واتساب أعمال" else "واتساب"
            Toast.makeText(context, "تطبيق $appName غير مثبت على هذا الجهاز", Toast.LENGTH_SHORT).show()
        }
    }
}
