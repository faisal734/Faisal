package com.example.ui.pdf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import com.example.data.entity.Attendance
import com.example.data.entity.StudentAttendance
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentGradeConfig
import com.example.data.entity.TrainerTransaction
import com.example.data.entity.AppActivityLog
import com.example.data.entity.CourseSubjectStat
import com.example.ui.viewmodel.MainViewModel
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatFinanceAmountNoDecimals(amount: Double): String {
    val formatter = java.text.DecimalFormat("#,##0", java.text.DecimalFormatSymbols(java.util.Locale.US))
    return formatter.format(kotlin.math.round(amount))
}


private fun String.toEnglishNumbers(): String {
    val arabicDigits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
    val englishDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    var result = this
    for (i in 0..9) {
        result = result.replace(arabicDigits[i], englishDigits[i])
    }
    return result
}

class PdfReportHelper {

    data class PdfColumn(
        val text: String,
        val width: Float,
        val align: Layout.Alignment = Layout.Alignment.ALIGN_CENTER,
        val color: Int = Color.BLACK,
        val textSize: Float = 8.5f,
        val isBold: Boolean = false
    )

    companion object {
        private const val PAGE_WIDTH = 595  // A4 size in points
        private const val PAGE_HEIGHT = 842 // A4 size in points
        private const val MARGIN = 30f
        private const val PRINT_WIDTH = PAGE_WIDTH - MARGIN * 2 // 535f
        private const val FOOTER_Y = 810f
        private const val MAX_CONTENT_Y = 790f

        // Theme colors (Matching Dawami professional palette)
        private val COLOR_PRIMARY = Color.parseColor("#0F172A") // Dawami Navy
        private val COLOR_SECONDARY = Color.parseColor("#0F766E") // Dawami Teal
        private val COLOR_ACCENT = Color.parseColor("#D97706") // Dawami Gold/Amber
        private val COLOR_BG_LIGHT = Color.parseColor("#F8FAFC")
        private val COLOR_BORDER = Color.parseColor("#E2E8F0")
        private val COLOR_TEXT_MUTED = Color.parseColor("#64748B")

        /**
         * Exports Teacher Attendance reports to a PDF document.
         */
        fun exportTeacherReportsToPdf(
            viewModel: MainViewModel,
            reports: List<Attendance>,
            outputStream: OutputStream
        ) {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()

            val instName = viewModel.instituteName.value
            val instSlogan = viewModel.instituteSlogan.value
            val directorName = viewModel.directorName.value
            val hrManagerName = viewModel.hrManagerName.value
            val trainerName = viewModel.trainerNameConfig.value.ifEmpty { viewModel.loggedInUser.value.ifEmpty { "م. فيصل العفيف" } }
            val logoUri = viewModel.instituteLogoUri.value

            val sdfDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val generationDateStr = sdfDate.format(Date())

            val filterCourse = viewModel.selectedCourseReportFilter.value
            val filterDateFrom = viewModel.reportDateFromFilter.value
            val filterDateTo = viewModel.reportDateToFilter.value
            val filterStatus = viewModel.selectedStatusReportFilter.value

            var pageNumber = 1
            var currentPage = pdfDocument.startPage(pageInfo)
            var canvas = currentPage.canvas

            var currentY = MARGIN

            // Draw official header on the first page
            drawOfficialHeader(canvas, instName, instSlogan, logoUri)
            currentY += 80f // move below official header

            // Draw report details/metadata
            currentY = drawTeacherReportMetadata(
                canvas = canvas, 
                startY = currentY, 
                courseFilter = filterCourse, 
                dateFrom = filterDateFrom, 
                dateTo = filterDateTo, 
                statusFilter = filterStatus, 
                genDate = generationDateStr,
                recordCount = reports.size,
                trainerName = trainerName
            )

            // Define columns for Teacher Attendance Table
            // Total width must equal PRINT_WIDTH (535)
            val columnWidths = listOf(120f, 45f, 45f, 50f, 50f, 75f, 150f)
            val tableHeaders = listOf(
                "الدورة التدريبية",
                "اليوم",
                "الحالة",
                "الحضور",
                "الانصراف",
                "التواجد",
                "الملاحظات والتنبيهات"
            )

            // Draw Table Header
            val headerHeight = 28f
            drawTableHeader(canvas, currentY, tableHeaders, columnWidths)
            currentY += headerHeight

            // Draw Table Rows
            reports.forEach { record ->
                val rowHeight = calculateTeacherRowHeight(record, columnWidths)
                
                // Pagination check
                if (currentY + rowHeight > MAX_CONTENT_Y) {
                    drawFooter(canvas, pageNumber)
                    pdfDocument.finishPage(currentPage)
                    
                    pageNumber++
                    currentPage = pdfDocument.startPage(pageInfo)
                    canvas = currentPage.canvas
                    currentY = MARGIN
                    
                    // On sub-pages, draw a compact top bar and header
                    currentY = drawCompactSubPageHeader(canvas, currentY, "تقرير حضور المدربين المكمل")
                    drawTableHeader(canvas, currentY, tableHeaders, columnWidths)
                    currentY += headerHeight
                }

                drawTeacherRow(canvas, currentY, record, columnWidths, rowHeight)
                currentY += rowHeight
            }

            // Draw Official Footer / Signatures
            val signatureHeight = 70f
            if (currentY + signatureHeight > MAX_CONTENT_Y) {
                drawFooter(canvas, pageNumber)
                pdfDocument.finishPage(currentPage)
                
                pageNumber++
                currentPage = pdfDocument.startPage(pageInfo)
                canvas = currentPage.canvas
                currentY = MARGIN
                currentY = drawCompactSubPageHeader(canvas, currentY, "مستند التوقيع والاعتماد")
            }

            drawSignatures(canvas, currentY, directorName, hrManagerName)
            
            // Draw final footer and close
            drawFooter(canvas, pageNumber)
            pdfDocument.finishPage(currentPage)

            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
        }

        /**
         * Exports Student Attendance reports to a PDF document.
         */
        fun exportStudentReportsToPdf(
            viewModel: MainViewModel,
            reports: List<StudentAttendance>,
            outputStream: OutputStream,
            groupingMode: String = "الدورة"
        ) {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()

            val instName = viewModel.instituteName.value
            val instSlogan = viewModel.instituteSlogan.value
            val directorName = viewModel.directorName.value
            val hrManagerName = viewModel.hrManagerName.value
            val logoUri = viewModel.instituteLogoUri.value

            val sdfDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val generationDateStr = sdfDate.format(Date())

            val filterCourse = viewModel.selectedStudentCourseReportFilter.value
            val filterDateFrom = viewModel.studentReportDateFromFilter.value
            val filterDateTo = viewModel.studentReportDateToFilter.value
            val filterStatus = viewModel.selectedStudentStatusReportFilter.value
            val searchName = viewModel.studentReportNameQuery.value

            var pageNumber = 1
            var currentPage = pdfDocument.startPage(pageInfo)
            var canvas = currentPage.canvas

            var currentY = MARGIN

            // Draw official header on first page
            drawOfficialHeader(canvas, instName, instSlogan, logoUri)
            currentY += 80f

            // Draw report metadata
            currentY = drawStudentReportMetadata(
                canvas,
                currentY,
                filterCourse,
                filterDateFrom,
                filterDateTo,
                filterStatus,
                searchName,
                generationDateStr,
                reports.size
            )

            val examCourseDates = viewModel.dbAttendance.value
                .filter { it.isExamDay }
                .map { "${it.courseId}_${it.date}" }
                .toSet()

            fun getSubjectAndExamInfo(record: StudentAttendance): Pair<String, Boolean> {
                val isExam = ("${record.courseId}_${record.date}" in examCourseDates) ||
                        record.subjectName.contains("امتحان") ||
                        record.subjectName.contains("اختبار") ||
                        record.courseDailyNote.contains("امتحان") ||
                        record.courseDailyNote.contains("اختبار")

                val baseSubject = if (record.subjectName.isNotBlank()) record.subjectName.trim() else record.courseName.trim()
                val text = if (isExam) {
                    if (baseSubject.contains("امتحان") || baseSubject.contains("اختبار")) {
                        baseSubject
                    } else {
                        "$baseSubject (امتحان)"
                    }
                } else {
                    baseSubject
                }
                return Pair(text, isExam)
            }

            // Define columns for Student Attendance Table (Total print width = 535)
            val columnWidths = listOf(95f, 85f, 65f, 40f, 40f, 40f, 90f, 80f)
            val tableHeaders = listOf(
                "اسم الطالب",
                "المادة الدراسية",
                "التاريخ واليوم",
                "الحالة",
                "الحضور",
                "الانصراف",
                "ملاحظة الحركة اليومية",
                "الملاحظة الخاصة"
            )

            val headerHeight = 28f
            val groupedData: Map<String, List<StudentAttendance>> = when (groupingMode) {
                "المادة" -> reports.groupBy { if (it.subjectName.isNotBlank()) it.subjectName.trim() else "بدون مادة" }
                "التاريخ" -> reports.groupBy { it.date }
                "الدورة" -> reports.groupBy { it.courseName.ifEmpty { "الدورة التدريبية" } }
                else -> mapOf("" to reports)
            }

            val isGrouped = groupingMode == "المادة" || groupingMode == "التاريخ" || (groupingMode == "الدورة" && groupedData.size > 1)

            if (!isGrouped) {
                drawTableHeader(canvas, currentY, tableHeaders, columnWidths)
                currentY += headerHeight
            }

            groupedData.forEach { (groupKey, groupRecords) ->
                if (isGrouped) {
                    val groupBannerHeight = 22f
                    if (currentY + groupBannerHeight + headerHeight + 35f > MAX_CONTENT_Y) {
                        drawFooter(canvas, pageNumber)
                        pdfDocument.finishPage(currentPage)

                        pageNumber++
                        currentPage = pdfDocument.startPage(pageInfo)
                        canvas = currentPage.canvas
                        currentY = MARGIN

                        currentY = drawCompactSubPageHeader(canvas, currentY, "تقرير حضور وغياب الطلاب (تابع)")
                    }

                    val (groupTitle, groupSubTitle) = when (groupingMode) {
                        "المادة" -> Pair(
                            "📚 المادة: $groupKey",
                            "عدد السجلات: ${groupRecords.size} (حضور: ${groupRecords.count { it.status == "حضور" }} | غياب: ${groupRecords.count { it.status == "غياب" }})"
                        )
                        "التاريخ" -> {
                            val dayName = groupRecords.firstOrNull()?.dayOfWeek ?: ""
                            val hasExam = groupRecords.any { getSubjectAndExamInfo(it).second }
                            Pair(
                                "📅 التاريخ: $groupKey ($dayName)" + if (hasExam) "  📝 [يوم امتحان مخصص]" else "",
                                "عدد الطلاب: ${groupRecords.size} طالب"
                            )
                        }
                        else -> Pair(
                            "📦 الدورة: $groupKey",
                            "عدد السجلات: ${groupRecords.size}"
                        )
                    }

                    currentY = drawGroupSectionHeader(canvas, currentY, groupTitle, groupSubTitle)
                    drawTableHeader(canvas, currentY, tableHeaders, columnWidths)
                    currentY += headerHeight
                }

                groupRecords.forEach { record ->
                    val (subjectWithExam, isExam) = getSubjectAndExamInfo(record)
                    val rowHeight = calculateStudentRowHeight(record, columnWidths, subjectWithExam)

                    // Pagination check
                    if (currentY + rowHeight > MAX_CONTENT_Y) {
                        drawFooter(canvas, pageNumber)
                        pdfDocument.finishPage(currentPage)

                        pageNumber++
                        currentPage = pdfDocument.startPage(pageInfo)
                        canvas = currentPage.canvas
                        currentY = MARGIN

                        // Compact header on sub-pages
                        currentY = drawCompactSubPageHeader(canvas, currentY, "تقرير حضور الطلاب المكمل")
                        drawTableHeader(canvas, currentY, tableHeaders, columnWidths)
                        currentY += headerHeight
                    }

                    drawStudentRow(canvas, currentY, record, columnWidths, rowHeight, subjectWithExam, isExam)
                    currentY += rowHeight
                }

                if (isGrouped) {
                    currentY += 8f
                }
            }

            // Draw Signatures at the end
            val signatureHeight = 70f
            if (currentY + signatureHeight > MAX_CONTENT_Y) {
                drawFooter(canvas, pageNumber)
                pdfDocument.finishPage(currentPage)

                pageNumber++
                currentPage = pdfDocument.startPage(pageInfo)
                canvas = currentPage.canvas
                currentY = MARGIN
                currentY = drawCompactSubPageHeader(canvas, currentY, "مستند التوقيع والاعتماد")
            }

            drawSignatures(canvas, currentY, directorName, hrManagerName)

            // Final page footer
            drawFooter(canvas, pageNumber)
            pdfDocument.finishPage(currentPage)

            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
        }

        // --- DRAWING UTILITIES ---

        private fun drawOfficialHeader(canvas: Canvas, name: String, slogan: String, logoUri: String) {
            val cleanName = name.toEnglishNumbers()
            val cleanSlogan = slogan.toEnglishNumbers()

            // Header card background
            val headerPaint = Paint().apply {
                color = COLOR_PRIMARY
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, MARGIN, PAGE_WIDTH - MARGIN, MARGIN + 64f, headerPaint)

            // Gold bottom accent bar
            val goldPaint = Paint().apply {
                color = COLOR_ACCENT
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, MARGIN + 60f, PAGE_WIDTH - MARGIN, MARGIN + 64f, goldPaint)

            val logoX = PAGE_WIDTH - MARGIN - 32f
            val logoY = MARGIN + 30f

            var logoDrawn = false
            if (logoUri.isNotEmpty()) {
                try {
                    val file = java.io.File(logoUri)
                    if (file.exists()) {
                        val bitmap = android.graphics.BitmapFactory.decodeFile(file.absolutePath)
                        if (bitmap != null) {
                            val targetSize = 36f
                            val srcRect = android.graphics.Rect(0, 0, bitmap.width, bitmap.height)
                            val destRect = android.graphics.RectF(
                                logoX - targetSize / 2f,
                                logoY - targetSize / 2f,
                                logoX + targetSize / 2f,
                                logoY + targetSize / 2f
                            )
                            canvas.drawBitmap(bitmap, srcRect, destRect, Paint(Paint.FILTER_BITMAP_FLAG).apply { isAntiAlias = true })
                            logoDrawn = true
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            if (!logoDrawn) {
                // Draw logo symbol background circle (on the right)
                val circlePaint = Paint().apply {
                    color = Color.parseColor("#334155")
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                canvas.drawCircle(logoX, logoY, 18f, circlePaint)

                // Draw a tiny decorative star inside circle to act as logo
                val starPaint = Paint().apply {
                    color = COLOR_ACCENT
                    textSize = 14f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.CENTER
                    isAntiAlias = true
                }
                canvas.drawText("★", logoX, logoY + 5f, starPaint)
            }

            // Draw Name (aligned Right, RTL)
            val namePaint = TextPaint().apply {
                color = Color.WHITE
                textSize = 13.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val textRight = logoX - 25f
            val textLeft = MARGIN + 95f
            val maxTextWidth = (textRight - textLeft).toInt().coerceAtLeast(100)

            val titleLayout = StaticLayout.Builder.obtain(cleanName, 0, cleanName.length, namePaint, maxTextWidth)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .build()

            canvas.save()
            canvas.translate(textLeft, MARGIN + 12f)
            titleLayout.draw(canvas)
            canvas.restore()

            // Draw Slogan if present
            if (cleanSlogan.isNotEmpty()) {
                val sloganPaint = TextPaint().apply {
                    color = Color.parseColor("#CBD5E1")
                    textSize = 9f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    isAntiAlias = true
                }
                val sloganLayout = StaticLayout.Builder.obtain(cleanSlogan, 0, cleanSlogan.length, sloganPaint, maxTextWidth)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .build()

                canvas.save()
                canvas.translate(textLeft, MARGIN + 35f)
                sloganLayout.draw(canvas)
                canvas.restore()
            }

            // Draw "Official Report" tag on the left
            val tagBgPaint = Paint().apply {
                color = Color.parseColor("#1E293B")
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN + 12f, MARGIN + 16f, MARGIN + 86f, MARGIN + 44f, tagBgPaint)

            val tagPaint = Paint().apply {
                color = COLOR_ACCENT
                textSize = 8.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("تقرير معتمد", MARGIN + 49f, MARGIN + 33f, tagPaint)
        }

        private fun drawTeacherReportMetadata(
            canvas: Canvas,
            startY: Float,
            courseFilter: String,
            dateFrom: String,
            dateTo: String,
            statusFilter: String,
            genDate: String,
            recordCount: Int,
            trainerName: String
        ): Float {
            var currentY = startY + 12f

            // Document Main Title
            val titlePaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 15f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val title = "تقرير حضور وانصراف السادة المدربين"
            val titleLayout = StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, PRINT_WIDTH.toInt())
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .build()

            canvas.save()
            canvas.translate(MARGIN, currentY)
            titleLayout.draw(canvas)
            canvas.restore()

            currentY += titleLayout.height + 14f

            // Gray border container for metadata
            val boxPaint = Paint().apply {
                color = COLOR_BG_LIGHT
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + 50f, boxPaint)

            val borderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + 50f, borderPaint)

            // Draw Metadata Fields inside Box
            val fieldPaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 8.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                isAntiAlias = true
            }

            val rightX = PAGE_WIDTH - MARGIN - 12f
            val centerX = PAGE_WIDTH / 2f
            val leftX = MARGIN + 12f

            val y1 = currentY + 20f
            val y2 = currentY + 38f

            // Line 1
            // Right: Trainer
            fieldPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("المدرب: $trainerName".toEnglishNumbers(), rightX, y1, fieldPaint)

            // Center: Course
            fieldPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("الدورة: $courseFilter".toEnglishNumbers(), centerX, y1, fieldPaint)

            // Left: Status
            fieldPaint.textAlign = Paint.Align.LEFT
            canvas.drawText("الحالة: $statusFilter".toEnglishNumbers(), leftX, y1, fieldPaint)

            // Line 2
            val dateRangeStr = if (dateFrom.isNotEmpty() && dateTo.isNotEmpty()) "من $dateFrom إلى $dateTo" else "كامل المدة"
            // Right: Period
            fieldPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("الفترة: $dateRangeStr".toEnglishNumbers(), rightX, y2, fieldPaint)

            // Center: Date of Generation
            fieldPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("التاريخ: $genDate".toEnglishNumbers(), centerX, y2, fieldPaint)

            // Left: Record Count
            fieldPaint.textAlign = Paint.Align.LEFT
            canvas.drawText("الإجمالي: $recordCount سجلات".toEnglishNumbers(), leftX, y2, fieldPaint)

            return currentY + 50f + 16f
        }

        private fun drawStudentReportMetadata(
            canvas: Canvas,
            startY: Float,
            courseFilter: String,
            dateFrom: String,
            dateTo: String,
            statusFilter: String,
            searchName: String,
            genDate: String,
            recordCount: Int
        ): Float {
            var currentY = startY + 12f

            // Document Main Title
            val titlePaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 15f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val title = "تقرير حضور وغياب الطلاب"
            val titleLayout = StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, PRINT_WIDTH.toInt())
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .build()

            canvas.save()
            canvas.translate(MARGIN, currentY)
            titleLayout.draw(canvas)
            canvas.restore()

            currentY += titleLayout.height + 14f

            // Gray border container for metadata
            val boxPaint = Paint().apply {
                color = COLOR_BG_LIGHT
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + 50f, boxPaint)

            val borderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + 50f, borderPaint)

            // Draw Metadata Fields inside Box
            val fieldPaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 8.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                isAntiAlias = true
            }

            val rightX = PAGE_WIDTH - MARGIN - 12f
            val centerX = PAGE_WIDTH / 2f
            val leftX = MARGIN + 12f

            val y1 = currentY + 20f
            val y2 = currentY + 38f

            // Line 1
            // Right: Course
            fieldPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("الدورة: $courseFilter".toEnglishNumbers(), rightX, y1, fieldPaint)

            // Center: Status
            fieldPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("الحالة: $statusFilter".toEnglishNumbers(), centerX, y1, fieldPaint)

            // Left: Search
            val searchPart = if (searchName.isNotEmpty()) "البحث: $searchName" else "البحث: الكل"
            fieldPaint.textAlign = Paint.Align.LEFT
            canvas.drawText(searchPart.toEnglishNumbers(), leftX, y1, fieldPaint)

            // Line 2
            val dateRangeStr = if (dateFrom.isNotEmpty() && dateTo.isNotEmpty()) "من $dateFrom إلى $dateTo" else "كامل المدة"
            // Right: Period
            fieldPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("الفترة: $dateRangeStr".toEnglishNumbers(), rightX, y2, fieldPaint)

            // Center: Date of Generation
            fieldPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("التاريخ: $genDate".toEnglishNumbers(), centerX, y2, fieldPaint)

            // Left: Record Count
            fieldPaint.textAlign = Paint.Align.LEFT
            canvas.drawText("الإجمالي: $recordCount سجلات".toEnglishNumbers(), leftX, y2, fieldPaint)

            return currentY + 50f + 16f
        }

        private fun drawTableHeader(
            canvas: Canvas,
            startY: Float,
            headers: List<String>,
            widths: List<Float>
        ) {
            val rectPaint = Paint().apply {
                color = COLOR_PRIMARY
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, startY, PAGE_WIDTH - MARGIN, startY + 28f, rectPaint)

            val borderPaint = Paint().apply {
                color = COLOR_PRIMARY
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(MARGIN, startY, PAGE_WIDTH - MARGIN, startY + 28f, borderPaint)

            var currentX = PAGE_WIDTH - MARGIN

            val textPaint = TextPaint().apply {
                color = Color.WHITE
                textSize = 8.2f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            headers.forEachIndexed { index, headerText ->
                val w = widths[index]
                currentX -= w

                val layout = StaticLayout.Builder.obtain(headerText, 0, headerText.length, textPaint, (w - 6).toInt())
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .build()

                val textY = startY + (28f - layout.height) / 2f
                canvas.save()
                canvas.translate(currentX + 3, textY)
                layout.draw(canvas)
                canvas.restore()

                // Border separator
                if (currentX > MARGIN) {
                    val sepPaint = Paint().apply {
                        color = Color.parseColor("#475569")
                        strokeWidth = 0.5f
                    }
                    canvas.drawLine(currentX, startY, currentX, startY + 28f, sepPaint)
                }
            }
        }

        private fun drawTeacherRow(
            canvas: Canvas,
            startY: Float,
            record: Attendance,
            widths: List<Float>,
            rowHeight: Float
        ) {
            val bgPaint = Paint().apply {
                color = if (record.id % 2 == 0) COLOR_BG_LIGHT else Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, startY, PAGE_WIDTH - MARGIN, startY + rowHeight, bgPaint)

            val borderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }
            canvas.drawRect(MARGIN, startY, PAGE_WIDTH - MARGIN, startY + rowHeight, borderPaint)

            // Define the row contents
            val checkInStr = if (record.status == "حضور") record.actualCheckIn else "-"
            val checkOutStr = if (record.status == "حضور") record.actualCheckOut else "-"
            val durationStr = if (record.status == "حضور") "${record.durationHours}س و ${record.durationMinutes}د" else "-"
            val notesStr = if (record.hasAlert) record.alertMessage else record.note

            val columns = listOf(
                PdfColumn("${record.courseName}\n${record.date}", widths[0], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, isBold = true),
                PdfColumn(record.dayOfWeek, widths[1], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY),
                PdfColumn(
                    record.status, widths[2], Layout.Alignment.ALIGN_CENTER,
                    when (record.status) {
                        "حضور" -> COLOR_SECONDARY
                        "غياب" -> Color.parseColor("#EF4444")
                        else -> COLOR_ACCENT
                    }, isBold = true
                ),
                PdfColumn(checkInStr, widths[3], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY),
                PdfColumn(checkOutStr, widths[4], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY),
                PdfColumn(durationStr, widths[5], Layout.Alignment.ALIGN_CENTER, COLOR_SECONDARY),
                PdfColumn(notesStr.ifEmpty { "سجل سليم" }, widths[6], Layout.Alignment.ALIGN_CENTER, if (record.hasAlert) Color.parseColor("#EF4444") else COLOR_TEXT_MUTED, textSize = 7.5f)
            )

            drawColumns(canvas, startY, columns, rowHeight)
        }

        private fun drawGroupSectionHeader(
            canvas: Canvas,
            startY: Float,
            title: String,
            subTitle: String = ""
        ): Float {
            val barHeight = 22f
            val bgPaint = Paint().apply {
                color = Color.parseColor("#1E293B")
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, startY, PAGE_WIDTH - MARGIN, startY + barHeight, bgPaint)

            val goldPaint = Paint().apply {
                color = COLOR_ACCENT
                style = Paint.Style.FILL
            }
            canvas.drawRect(PAGE_WIDTH - MARGIN - 4f, startY, PAGE_WIDTH - MARGIN, startY + barHeight, goldPaint)

            val textPaint = TextPaint().apply {
                color = Color.WHITE
                textSize = 9f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(title.toEnglishNumbers(), PAGE_WIDTH - MARGIN - 12f, startY + 14.5f, textPaint)

            if (subTitle.isNotEmpty()) {
                val subPaint = TextPaint().apply {
                    color = Color.parseColor("#E2E8F0")
                    textSize = 8f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    isAntiAlias = true
                    textAlign = Paint.Align.LEFT
                }
                canvas.drawText(subTitle.toEnglishNumbers(), MARGIN + 10f, startY + 14.5f, subPaint)
            }

            return startY + barHeight + 4f
        }

        private fun drawStudentRow(
            canvas: Canvas,
            startY: Float,
            record: StudentAttendance,
            widths: List<Float>,
            rowHeight: Float,
            subjectWithExam: String = "",
            isExam: Boolean = false
        ) {
            val bgPaint = Paint().apply {
                color = if (record.id % 2 == 0) COLOR_BG_LIGHT else Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, startY, PAGE_WIDTH - MARGIN, startY + rowHeight, bgPaint)

            val borderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }
            canvas.drawRect(MARGIN, startY, PAGE_WIDTH - MARGIN, startY + rowHeight, borderPaint)

            val checkInStr = if (record.status == "حضور" && record.actualCheckIn.isNotEmpty()) record.actualCheckIn else "-"
            val checkOutStr = if (record.status == "حضور" && record.actualCheckOut.isNotEmpty()) record.actualCheckOut else "-"
            
            val dailyNoteStr = record.courseDailyNote.ifEmpty { "-" }
            val studentNoteStr = record.studentNote.ifEmpty { "-" }

            val subjText = if (subjectWithExam.isNotEmpty()) subjectWithExam else if (record.subjectName.isNotEmpty()) record.subjectName else record.courseName

            val columns = listOf(
                PdfColumn(record.studentName, widths[0], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, isBold = true, textSize = 8f),
                PdfColumn(
                    subjText,
                    widths[1],
                    Layout.Alignment.ALIGN_CENTER,
                    if (isExam) Color.parseColor("#B45309") else COLOR_PRIMARY,
                    isBold = isExam,
                    textSize = 8f
                ),
                PdfColumn("${record.date}\n${record.dayOfWeek}", widths[2], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, textSize = 7.5f),
                PdfColumn(
                    record.status, widths[3], Layout.Alignment.ALIGN_CENTER,
                    when (record.status) {
                        "حضور" -> COLOR_SECONDARY
                        "غياب" -> Color.parseColor("#EF4444")
                        else -> COLOR_ACCENT
                    }, isBold = true, textSize = 8f
                ),
                PdfColumn(checkInStr, widths[4], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, textSize = 8f),
                PdfColumn(checkOutStr, widths[5], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, textSize = 8f),
                PdfColumn(dailyNoteStr, widths[6], Layout.Alignment.ALIGN_CENTER, COLOR_TEXT_MUTED, textSize = 7.5f),
                PdfColumn(studentNoteStr, widths[7], Layout.Alignment.ALIGN_CENTER, COLOR_TEXT_MUTED, textSize = 7.5f)
            )

            drawColumns(canvas, startY, columns, rowHeight)
        }

        private fun drawColumns(
            canvas: Canvas,
            startY: Float,
            columns: List<PdfColumn>,
            rowHeight: Float
        ) {
            var currentX = PAGE_WIDTH - MARGIN
            val borderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }

            columns.forEach { col ->
                currentX -= col.width

                val textPaint = TextPaint().apply {
                    color = col.color
                    textSize = col.textSize
                    typeface = if (col.isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                    isAntiAlias = true
                }

                // Draw text with padding
                val padding = 4f
                val wLayout = (col.width - padding * 2).toInt().coerceAtLeast(10)
                val cleanText = col.text.toEnglishNumbers()
                val layout = StaticLayout.Builder.obtain(cleanText, 0, cleanText.length, textPaint, wLayout)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(col.align)
                    .build()

                val offsetY = (rowHeight - layout.height) / 2f
                canvas.save()
                canvas.translate(currentX + padding, startY + offsetY.coerceAtLeast(2f))
                layout.draw(canvas)
                canvas.restore()

                // Draw vertical grid line
                if (currentX > MARGIN) {
                    canvas.drawLine(currentX, startY, currentX, startY + rowHeight, borderPaint)
                }
            }
        }

        private fun calculateTeacherRowHeight(record: Attendance, widths: List<Float>): Float {
            val p1 = TextPaint().apply { textSize = 8.5f; typeface = Typeface.DEFAULT_BOLD }
            val l1 = StaticLayout.Builder.obtain("${record.courseName}\n${record.date}", 0, record.courseName.length + 11, p1, (widths[0] - 8).toInt().coerceAtLeast(10)).build()

            val notesStr = if (record.hasAlert) record.alertMessage else record.note
            val p2 = TextPaint().apply { textSize = 7.5f }
            val l2 = StaticLayout.Builder.obtain(notesStr.ifEmpty { "سجل سليم" }, 0, notesStr.ifEmpty { "سجل سليم" }.length, p2, (widths[6] - 8).toInt().coerceAtLeast(10)).build()

            val maxHeight = Math.max(l1.height, l2.height)
            return (maxHeight + 12f).coerceAtLeast(32f)
        }

        private fun calculateStudentRowHeight(
            record: StudentAttendance,
            widths: List<Float>,
            subjectWithExam: String = ""
        ): Float {
            val p1 = TextPaint().apply { textSize = 8f; typeface = Typeface.DEFAULT_BOLD }
            val l1 = StaticLayout.Builder.obtain(record.studentName, 0, record.studentName.length, p1, (widths[0] - 8).toInt().coerceAtLeast(10)).build()

            val subjText = if (subjectWithExam.isNotEmpty()) subjectWithExam else if (record.subjectName.isNotEmpty()) record.subjectName else record.courseName
            val p2 = TextPaint().apply { textSize = 8f }
            val l2 = StaticLayout.Builder.obtain(subjText, 0, subjText.length, p2, (widths[1] - 8).toInt().coerceAtLeast(10)).build()

            val dailyNoteStr = record.courseDailyNote.ifEmpty { "-" }
            val p3 = TextPaint().apply { textSize = 7.5f }
            val l3 = StaticLayout.Builder.obtain(dailyNoteStr, 0, dailyNoteStr.length, p3, (widths[6] - 8).toInt().coerceAtLeast(10)).build()

            val studentNoteStr = record.studentNote.ifEmpty { "-" }
            val p4 = TextPaint().apply { textSize = 7.5f }
            val l4 = StaticLayout.Builder.obtain(studentNoteStr, 0, studentNoteStr.length, p4, (widths[7] - 8).toInt().coerceAtLeast(10)).build()

            val maxHeight = Math.max(Math.max(l1.height, l2.height), Math.max(l3.height, l4.height))
            return (maxHeight + 12f).coerceAtLeast(32f)
        }

        private fun drawCompactSubPageHeader(canvas: Canvas, startY: Float, pageTitle: String): Float {
            val compactHeaderPaint = Paint().apply {
                color = COLOR_PRIMARY
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, startY, PAGE_WIDTH - MARGIN, startY + 20f, compactHeaderPaint)

            val textPaint = TextPaint().apply {
                color = Color.WHITE
                textSize = 8.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val cleanTitle = pageTitle.toEnglishNumbers()
            val layout = StaticLayout.Builder.obtain(cleanTitle, 0, cleanTitle.length, textPaint, PRINT_WIDTH.toInt() - 20)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .build()

            canvas.save()
            canvas.translate(MARGIN + 10f, startY + (20f - layout.height) / 2f)
            layout.draw(canvas)
            canvas.restore()

            return startY + 20f + 10f
        }

        private fun drawSignatures(canvas: Canvas, startY: Float, directorName: String, hrManagerName: String) {
            val sectionY = startY + 24f

            // Separator Line
            val linePaint = Paint().apply {
                color = COLOR_BORDER
                strokeWidth = 1f
            }
            canvas.drawLine(MARGIN, sectionY, PAGE_WIDTH - MARGIN, sectionY, linePaint)

            // Text paints
            val textPaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            // Right signature (HR)
            val hrText = "مسؤول إدارة الموارد البشرية والتدريب\nالاسم: $hrManagerName\n\nتوقيع واعتماد: ................................"
            val cleanHr = hrText.toEnglishNumbers()
            val hrLayout = StaticLayout.Builder.obtain(cleanHr, 0, cleanHr.length, textPaint, 220)
                .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
                .build()

            canvas.save()
            canvas.translate(PAGE_WIDTH - MARGIN - 230f, sectionY + 16f)
            hrLayout.draw(canvas)
            canvas.restore()

            // Left signature (Director)
            val directorText = "مدير الهيئة / المؤسسة التدريبية\nالاسم: $directorName\n\nخاتم وتوقيع المدير: ................................"
            val cleanDirector = directorText.toEnglishNumbers()
            val directorLayout = StaticLayout.Builder.obtain(cleanDirector, 0, cleanDirector.length, textPaint, 220)
                .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
                .build()

            canvas.save()
            canvas.translate(MARGIN + 10f, sectionY + 16f)
            directorLayout.draw(canvas)
            canvas.restore()
        }

        private fun drawTrainerSignatureOnly(canvas: Canvas, startY: Float, trainerName: String) {
            val sectionY = startY + 24f

            // Separator Line
            val linePaint = Paint().apply {
                color = COLOR_BORDER
                strokeWidth = 1f
            }
            canvas.drawLine(MARGIN, sectionY, PAGE_WIDTH - MARGIN, sectionY, linePaint)

            // Text paint
            val textPaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            // Trainer signature (RTL)
            val trainerText = "مدرب الدورة المعتمد\nالاسم: $trainerName\n\nتوقيع واعتماد المدرب: ................................"
            val cleanTrainer = trainerText.toEnglishNumbers()
            val trainerLayout = StaticLayout.Builder.obtain(cleanTrainer, 0, cleanTrainer.length, textPaint, 260)
                .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
                .build()

            canvas.save()
            canvas.translate(PAGE_WIDTH - MARGIN - 270f, sectionY + 16f)
            trainerLayout.draw(canvas)
            canvas.restore()
        }

        private fun drawFooter(canvas: Canvas, pageNum: Int) {
            // Draw horizontal divider line above footer
            val linePaint = Paint().apply {
                color = COLOR_BORDER
                strokeWidth = 0.5f
            }
            canvas.drawLine(MARGIN, FOOTER_Y, PAGE_WIDTH - MARGIN, FOOTER_Y, linePaint)

            val footerPaint = TextPaint().apply {
                color = COLOR_TEXT_MUTED
                textSize = 8f
                isAntiAlias = true
            }

            val footerLeft = "برنامج دوامي لإدارة الحضور والغياب الذكي © 2026 | برمجة م: فيصل العفيف"
            val cleanLeft = footerLeft.toEnglishNumbers()
            val leftLayout = StaticLayout.Builder.obtain(cleanLeft, 0, cleanLeft.length, footerPaint, 350)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .build()

            canvas.save()
            canvas.translate(MARGIN, FOOTER_Y + 5f)
            leftLayout.draw(canvas)
            canvas.restore()

            val footerRight = "صفحة $pageNum"
            val cleanRight = footerRight.toEnglishNumbers()
            val rightLayout = StaticLayout.Builder.obtain(cleanRight, 0, cleanRight.length, footerPaint, 100)
                .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
                .build()

            canvas.save()
            canvas.translate(PAGE_WIDTH - MARGIN - 100f, FOOTER_Y + 5f)
            rightLayout.draw(canvas)
            canvas.restore()
        }

        /**
         * Exports detailed student grades for a specific course to a PDF document.
         * @param useWeighted if true, calculates and displays scores according to subject weights.
         *                    if false, displays scores as recorded (out of the configured subject max, e.g. 100).
         */
        fun exportCourseGradesToPdf(
            viewModel: MainViewModel,
            course: Course,
            config: StudentGradeConfig,
            students: List<Student>,
            grades: List<StudentGrade>,
            outputStream: OutputStream,
            useWeighted: Boolean = false
        ) {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()

            val instName = viewModel.instituteName.value
            val instSlogan = viewModel.instituteSlogan.value
            val trainerName = viewModel.trainerNameConfig.value.ifBlank {
                course.trainerName.ifBlank { "مدرب الدورة" }
            }
            val logoUri = viewModel.instituteLogoUri.value

            val sdfDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val generationDateStr = sdfDate.format(Date())

            var pageNum = 1
            var currentPage = pdfDocument.startPage(pageInfo)
            var canvas = currentPage.canvas

            var currentY = MARGIN

            // Draw official header on first page
            drawOfficialHeader(canvas, instName, instSlogan, logoUri)
            currentY += 80f

            // Title
            val titlePaint = Paint().apply {
                color = COLOR_PRIMARY
                textSize = 14f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("تقرير كشف درجات دورة: ${course.name}", (PAGE_WIDTH / 2).toFloat(), currentY, titlePaint)
            currentY += 20f

            // Metadata info
            val infoPaint = Paint().apply {
                color = Color.parseColor("#1E293B")
                textSize = 8.5f
                isAntiAlias = true
                textAlign = Paint.Align.RIGHT
            }
            val infoPaintLeft = Paint().apply {
                color = Color.parseColor("#1E293B")
                textSize = 8.5f
                isAntiAlias = true
                textAlign = Paint.Align.LEFT
            }

            val passingPct = config.getPassingPercentage()
            val passingPctStr = if (passingPct % 1.0 == 0.0) passingPct.toInt().toString() else String.format(Locale.US, "%.1f", passingPct)
            val modeTitle = if (useWeighted) "حسب الموزون العام (أوزان المواد)" else "حسب تهيئة المواد (الدرجة العظمى)"
            canvas.drawText("تاريخ التصدير: $generationDateStr", PAGE_WIDTH - MARGIN, currentY, infoPaint)
            canvas.drawText("التهيئة: ${if (config.isDiploma) "دبلوم حاسوب (7 مواد)" else "دورة مخصصة"} | النمط: $modeTitle | نسبة النجاح: $passingPctStr%", MARGIN, currentY, infoPaintLeft)
            currentY += 22f

            // Draw Table Headers
            val configFields = StudentGradeConfig.deserializeFields(config.customFieldsJson)
            val rawSubjectsList = if (config.isDiploma) {
                config.getDiplomaSubjects()
            } else {
                configFields.map { it.first.substringBefore("_") }.distinct()
            }
            val savedPdfOrder = viewModel.getPdfSubjectsOrder(course.id)
            val subjectsList = if (!savedPdfOrder.isNullOrEmpty()) {
                val ordered = savedPdfOrder.filter { savedName ->
                    rawSubjectsList.any { it.trim().equals(savedName.trim(), ignoreCase = true) }
                }
                val remaining = rawSubjectsList.filter { rawName ->
                    !ordered.any { it.trim().equals(rawName.trim(), ignoreCase = true) }
                }
                ordered + remaining
            } else {
                StudentGradeConfig.sortSubjectsList(rawSubjectsList)
            }

            val numSubjects = subjectsList.size.coerceAtMost(7)

            // Setup subject metadata for columns
            val subjectWeights = config.getSubjectWeights()
            val defaultWeight = if (subjectsList.isNotEmpty()) 100.0 / subjectsList.size else 0.0

            class GradeColInfo(
                val subjectName: String,
                val maxScore: Double,
                val weight: Double,
                val subtitle: String
            )

            val colsInfo = subjectsList.take(numSubjects).map { subName ->
                val w = subjectWeights[subName]
                    ?: subjectWeights.entries.find { it.key.trim().equals(subName.trim(), ignoreCase = true) }?.value
                    ?: defaultWeight

                val maxScore = if (config.isDiploma) {
                    100.0
                } else {
                    val fieldsForSub = configFields.filter { it.first.startsWith("${subName}_") || it.first == subName }
                    val sumMax = fieldsForSub.sumOf { it.second }.toDouble()
                    if (sumMax > 0.0) sumMax else 100.0
                }

                val subtitle = if (useWeighted) {
                    val wStr = if (w % 1.0 == 0.0) w.toInt().toString() else String.format(Locale.US, "%.1f", w)
                    "($wStr)"
                } else {
                    val mStr = if (maxScore % 1.0 == 0.0) maxScore.toInt().toString() else String.format(Locale.US, "%.1f", maxScore)
                    "($mStr)"
                }

                GradeColInfo(subName, maxScore, w, subtitle)
            }

            val totalMaxAllSubjects = colsInfo.sumOf { it.maxScore }
            val totalWeightsSum = colsInfo.sumOf { it.weight }

            val sumWidth = 38f
            val avgWidth = 38f
            val availableWidthForSubjects = 325f
            val subjectWidth = availableWidthForSubjects / numSubjects.coerceAtLeast(1)
            val studentNameWidth = PRINT_WIDTH - (subjectWidth * numSubjects) - sumWidth - avgWidth
            val headerHeight = 42f

            // Header Background & Border paints
            val headerBgPaint = Paint().apply {
                color = COLOR_PRIMARY
                style = Paint.Style.FILL
            }
            val borderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }

            val headerSubPaint = TextPaint().apply {
                color = Color.WHITE
                textSize = 6.8f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val headerNamePaint = TextPaint().apply {
                color = Color.WHITE
                textSize = 8.0f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            fun drawTableHeaderBlock(atY: Float) {
                canvas.drawRect(MARGIN, atY, PAGE_WIDTH - MARGIN, atY + headerHeight, headerBgPaint)
                var cx = PAGE_WIDTH - MARGIN

                // 1. Student Name Header
                canvas.drawRect(cx - studentNameWidth, atY, cx, atY + headerHeight, borderPaint)
                val nameLayout = StaticLayout.Builder.obtain("اسم الطالب ثلاثي", 0, "اسم الطالب ثلاثي".length, headerNamePaint, (studentNameWidth - 8).toInt().coerceAtLeast(10))
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .build()
                canvas.save()
                canvas.translate(cx - studentNameWidth + 4f, atY + (headerHeight - nameLayout.height) / 2f)
                nameLayout.draw(canvas)
                canvas.restore()
                cx -= studentNameWidth

                // 2. Subject Headers (Full name + subtitle, wrapped)
                for (info in colsInfo) {
                    canvas.drawRect(cx - subjectWidth, atY, cx, atY + headerHeight, borderPaint)
                    val headerText = "${info.subjectName}\n${info.subtitle}"
                    val subLayout = StaticLayout.Builder.obtain(headerText, 0, headerText.length, headerSubPaint, (subjectWidth - 4).toInt().coerceAtLeast(10))
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setAlignment(Layout.Alignment.ALIGN_CENTER)
                        .build()
                    canvas.save()
                    canvas.translate(cx - subjectWidth + 2f, atY + (headerHeight - subLayout.height) / 2f)
                    subLayout.draw(canvas)
                    canvas.restore()
                    cx -= subjectWidth
                }

                // 3. Sum Header
                canvas.drawRect(cx - sumWidth, atY, cx, atY + headerHeight, borderPaint)
                val sumMaxLabel = if (useWeighted) {
                    val s = if (totalWeightsSum % 1.0 == 0.0) totalWeightsSum.toInt().toString() else String.format(Locale.US, "%.1f", totalWeightsSum)
                    "($s)"
                } else {
                    "(${totalMaxAllSubjects.toInt()})"
                }
                val sumHeaderText = "المجموع\n$sumMaxLabel"
                val sumLayout = StaticLayout.Builder.obtain(sumHeaderText, 0, sumHeaderText.length, headerSubPaint, (sumWidth - 2).toInt().coerceAtLeast(10))
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .build()
                canvas.save()
                canvas.translate(cx - sumWidth + 1f, atY + (headerHeight - sumLayout.height) / 2f)
                sumLayout.draw(canvas)
                canvas.restore()
                cx -= sumWidth

                // 4. Average Header
                canvas.drawRect(cx - avgWidth, atY, cx, atY + headerHeight, borderPaint)
                val avgHeaderText = if (useWeighted) "المعدل\nالموزون" else "المعدل\nالعام %"
                val avgLayout = StaticLayout.Builder.obtain(avgHeaderText, 0, avgHeaderText.length, headerSubPaint, (avgWidth - 2).toInt().coerceAtLeast(10))
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .build()
                canvas.save()
                canvas.translate(cx - avgWidth + 1f, atY + (headerHeight - avgLayout.height) / 2f)
                avgLayout.draw(canvas)
                canvas.restore()
                cx -= avgWidth
            }

            // Draw header on first page
            drawTableHeaderBlock(currentY)
            currentY += headerHeight

            // Paints for rows
            val rowNamePaint = TextPaint().apply {
                color = Color.parseColor("#0F172A")
                textSize = 8f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val textCenterPaint = Paint().apply {
                color = Color.parseColor("#0F172A")
                textSize = 8f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
            }
            val textCenterBoldPaint = Paint().apply {
                color = COLOR_PRIMARY
                textSize = 8f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            val rowBgPaintAlt = Paint().apply {
                color = COLOR_BG_LIGHT
                style = Paint.Style.FILL
            }

            // Sort students descending by GPA / Total Score
            data class EvaluatedCourseStudent(
                val student: Student,
                val hasGrades: Boolean,
                val avgPct: Double,
                val totalScore: Double
            )

            val sortedStudents = students.map { student ->
                var totalSumRaw = 0.0
                var totalSumWeighted = 0.0
                var validCount = 0
                var evaluatedWeightsSum = 0.0

                for (info in colsInfo) {
                    val gradeObj = grades.find {
                        it.studentId == student.id &&
                        it.subjectName.trim().equals(info.subjectName.trim(), ignoreCase = true)
                    }

                    val scoreVal = gradeObj?.getTotalScore()
                    if (scoreVal != null) {
                        validCount++
                        totalSumRaw += scoreVal
                        val weightedVal = (scoreVal / info.maxScore) * info.weight
                        totalSumWeighted += weightedVal
                        evaluatedWeightsSum += info.weight
                    }
                }

                val hasGrades = validCount > 0
                val avgPct = if (hasGrades) {
                    if (useWeighted) {
                        if (evaluatedWeightsSum > 0.0) (totalSumWeighted / evaluatedWeightsSum) * 100.0 else 0.0
                    } else {
                        if (totalMaxAllSubjects > 0.0) (totalSumRaw / totalMaxAllSubjects) * 100.0 else 0.0
                    }
                } else {
                    -1.0
                }
                val totalScore = if (useWeighted) totalSumWeighted else totalSumRaw

                EvaluatedCourseStudent(student, hasGrades, avgPct, totalScore)
            }.sortedWith(
                compareByDescending<EvaluatedCourseStudent> { it.hasGrades }
                    .thenByDescending { it.avgPct }
                    .thenByDescending { it.totalScore }
                    .thenBy { it.student.name }
            ).map { it.student }

            val rowHeight = 22f

            sortedStudents.forEachIndexed { idx, student ->
                if (currentY + rowHeight > MAX_CONTENT_Y - 40f) {
                    drawFooter(canvas, pageNum)
                    pdfDocument.finishPage(currentPage)
                    pageNum++
                    currentPage = pdfDocument.startPage(pageInfo)
                    canvas = currentPage.canvas
                    currentY = MARGIN
                    drawOfficialHeader(canvas, instName, instSlogan, logoUri)
                    currentY += 80f

                    // Redraw Table Headers on new page
                    drawTableHeaderBlock(currentY)
                    currentY += headerHeight
                }

                if (idx % 2 == 1) {
                    canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, rowBgPaintAlt)
                }

                var cx = PAGE_WIDTH - MARGIN

                // 1. Draw Student Name
                canvas.drawRect(cx - studentNameWidth, currentY, cx, currentY + rowHeight, borderPaint)
                val stNameLayout = StaticLayout.Builder.obtain(student.name, 0, student.name.length, rowNamePaint, (studentNameWidth - 8).toInt().coerceAtLeast(10))
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .build()
                canvas.save()
                canvas.translate(cx - studentNameWidth + 4f, currentY + (rowHeight - stNameLayout.height) / 2f)
                stNameLayout.draw(canvas)
                canvas.restore()
                cx -= studentNameWidth

                // 2. Draw Subject Scores
                var totalSumRaw = 0.0
                var totalSumWeighted = 0.0
                var validCount = 0
                var evaluatedWeightsSum = 0.0

                for (info in colsInfo) {
                    val gradeObj = grades.find {
                        it.studentId == student.id &&
                        it.subjectName.trim().equals(info.subjectName.trim(), ignoreCase = true)
                    }

                    val scoreVal = gradeObj?.getTotalScore()
                    val displayScoreStr = if (scoreVal != null) {
                        validCount++
                        totalSumRaw += scoreVal
                        val weightedVal = (scoreVal / info.maxScore) * info.weight
                        totalSumWeighted += weightedVal
                        evaluatedWeightsSum += info.weight

                        if (useWeighted) {
                            if (weightedVal % 1.0 == 0.0) weightedVal.toInt().toString() else String.format(Locale.US, "%.1f", weightedVal)
                        } else {
                            if (scoreVal % 1.0 == 0.0) scoreVal.toInt().toString() else String.format(Locale.US, "%.1f", scoreVal)
                        }
                    } else {
                        "-"
                    }

                    canvas.drawRect(cx - subjectWidth, currentY, cx, currentY + rowHeight, borderPaint)
                    canvas.drawText(displayScoreStr, cx - (subjectWidth / 2), currentY + 14f, textCenterPaint)
                    cx -= subjectWidth
                }

                // 3. Draw Sum
                val displaySumStr = if (validCount > 0) {
                    if (useWeighted) {
                        if (totalSumWeighted % 1.0 == 0.0) totalSumWeighted.toInt().toString() else String.format(Locale.US, "%.1f", totalSumWeighted)
                    } else {
                        if (totalSumRaw % 1.0 == 0.0) totalSumRaw.toInt().toString() else String.format(Locale.US, "%.1f", totalSumRaw)
                    }
                } else {
                    "-"
                }
                canvas.drawRect(cx - sumWidth, currentY, cx, currentY + rowHeight, borderPaint)
                canvas.drawText(displaySumStr, cx - (sumWidth / 2), currentY + 14f, textCenterBoldPaint)
                cx -= sumWidth

                // 4. Draw Average
                val displayAvgStr = if (validCount > 0) {
                    val avgPct = if (useWeighted) {
                        if (evaluatedWeightsSum > 0.0) (totalSumWeighted / evaluatedWeightsSum) * 100.0 else 0.0
                    } else {
                        if (totalMaxAllSubjects > 0.0) (totalSumRaw / totalMaxAllSubjects) * 100.0 else 0.0
                    }
                    if (avgPct % 1.0 == 0.0) "${avgPct.toInt()}%" else String.format(Locale.US, "%.1f%%", avgPct)
                } else {
                    "-"
                }
                canvas.drawRect(cx - avgWidth, currentY, cx, currentY + rowHeight, borderPaint)
                canvas.drawText(displayAvgStr, cx - (avgWidth / 2), currentY + 14f, textCenterBoldPaint)

                currentY += rowHeight
            }

            // Draw student subject notes if any exist
            val studentNotesList = mutableListOf<Triple<String, String, String>>()
            sortedStudents.forEach { student ->
                subjectsList.forEach { subName ->
                    val g = grades.find { it.studentId == student.id && it.subjectName.trim().equals(subName.trim(), ignoreCase = true) }
                    val note = g?.getGradeNote()
                    if (!note.isNullOrBlank()) {
                        studentNotesList.add(Triple(student.name, subName, note))
                    }
                }
            }

            if (studentNotesList.isNotEmpty()) {
                currentY += 15f
                if (currentY > MAX_CONTENT_Y - 60f) {
                    drawFooter(canvas, pageNum)
                    pdfDocument.finishPage(currentPage)
                    pageNum++
                    currentPage = pdfDocument.startPage(pageInfo)
                    canvas = currentPage.canvas
                    currentY = MARGIN + 40f
                }

                val notesTitlePaint = Paint().apply {
                    color = COLOR_PRIMARY
                    textSize = 9.5f
                    isAntiAlias = true
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.RIGHT
                }
                canvas.drawText("📝 ملاحظات وتوصيات المواد للطلاب:", PAGE_WIDTH - MARGIN, currentY, notesTitlePaint)
                currentY += 14f

                val noteItemPaint = TextPaint().apply {
                    color = Color.parseColor("#334155")
                    textSize = 8.0f
                    isAntiAlias = true
                }

                studentNotesList.forEach { (studentName, subName, noteText) ->
                    val noteLine = "• $studentName ($subName): $noteText"
                    val noteLayout = StaticLayout.Builder.obtain(noteLine, 0, noteLine.length, noteItemPaint, (PRINT_WIDTH - 20f).toInt().coerceAtLeast(10))
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                        .build()

                    if (currentY + noteLayout.height > MAX_CONTENT_Y - 30f) {
                        drawFooter(canvas, pageNum)
                        pdfDocument.finishPage(currentPage)
                        pageNum++
                        currentPage = pdfDocument.startPage(pageInfo)
                        canvas = currentPage.canvas
                        currentY = MARGIN + 40f
                    }

                    canvas.save()
                    canvas.translate(MARGIN + 10f, currentY)
                    noteLayout.draw(canvas)
                    canvas.restore()
                    currentY += noteLayout.height + 4f
                }
            }

            currentY += 30f
            if (currentY > MAX_CONTENT_Y - 60f) {
                drawFooter(canvas, pageNum)
                pdfDocument.finishPage(currentPage)
                pageNum++
                currentPage = pdfDocument.startPage(pageInfo)
                canvas = currentPage.canvas
                currentY = MARGIN + 40f
            }

            drawTrainerSignatureOnly(canvas, currentY, trainerName)

            drawFooter(canvas, pageNum)
            pdfDocument.finishPage(currentPage)

            try {
                pdfDocument.writeTo(outputStream)
            } finally {
                pdfDocument.close()
            }
        }

        /**
         * Exports Trainer Finances to a PDF report.
         */
        fun exportTrainerFinancesToPdf(
            viewModel: MainViewModel,
            transactions: List<TrainerTransaction>,
            outputStream: OutputStream
        ) {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()

            val instName = viewModel.instituteName.value
            val instSlogan = viewModel.instituteSlogan.value
            val directorName = viewModel.directorName.value
            val hrManagerName = viewModel.hrManagerName.value
            val trainerName = viewModel.trainerNameConfig.value.ifEmpty { viewModel.loggedInUser.value.ifEmpty { "المدرب" } }
            val logoUri = viewModel.instituteLogoUri.value

            val sdfDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val generationDateStr = sdfDate.format(Date())

            val sortedChronological = transactions.sortedWith(compareBy<TrainerTransaction> { it.date }.thenBy { it.id })

            val runningBalanceMap = mutableMapOf<Long, Double>()
            var bal = 0.0
            for (tx in sortedChronological) {
                if (tx.type == "لكم") {
                    bal += tx.amount
                } else {
                    bal -= tx.amount
                }
                runningBalanceMap[tx.id] = bal
            }

            val totalLakum = sortedChronological.filter { it.type == "لكم" }.sumOf { it.amount }
            val totalAlaykum = sortedChronological.filter { it.type == "عليكم" }.sumOf { it.amount }
            val netBalance = totalLakum - totalAlaykum

            var pageNumber = 1
            var currentPage = pdfDocument.startPage(pageInfo)
            var canvas = currentPage.canvas

            var currentY = MARGIN

            // Draw official header on the first page
            drawOfficialHeader(canvas, instName, instSlogan, logoUri)
            currentY += 80f

            // Draw report details/metadata
            currentY = drawTrainerFinancesMetadata(
                canvas = canvas, 
                startY = currentY, 
                trainerName = trainerName,
                totalLakum = totalLakum,
                totalAlaykum = totalAlaykum,
                netBalance = netBalance,
                genDate = generationDateStr,
                recordCount = sortedChronological.size
            )

            // Define columns for Trainer Finances Table
            // Total width must equal PRINT_WIDTH (535)
            // Columns: الدورة (110), التاريخ (75), نوع العملية (80), المبلغ (75), الرصيد (75), ملاحظة (120)
            val columnWidths = listOf(110f, 75f, 80f, 75f, 75f, 120f)
            val tableHeaders = listOf(
                "الدورة التدريبية",
                "التاريخ",
                "نوع العملية",
                "المبلغ",
                "الرصيد",
                "الملاحظة"
            )

            // Draw Table Header
            val headerHeight = 28f
            drawTableHeader(canvas, currentY, tableHeaders, columnWidths)
            currentY += headerHeight

            // Draw Table Rows
            sortedChronological.forEach { record ->
                val currentRunningBal = runningBalanceMap[record.id] ?: 0.0
                val rowHeight = calculateTrainerFinanceRowHeight(record, columnWidths)
                
                // Pagination check
                if (currentY + rowHeight > MAX_CONTENT_Y) {
                    drawFooter(canvas, pageNumber)
                    pdfDocument.finishPage(currentPage)
                    
                    pageNumber++
                    currentPage = pdfDocument.startPage(pageInfo)
                    canvas = currentPage.canvas
                    currentY = MARGIN
                    
                    // On sub-pages, draw a compact top bar and header
                    currentY = drawCompactSubPageHeader(canvas, currentY, "كشف الحركات المالية للمدرب - مكمل")
                    drawTableHeader(canvas, currentY, tableHeaders, columnWidths)
                    currentY += headerHeight
                }

                drawTrainerFinanceRow(canvas, currentY, record, currentRunningBal, columnWidths, rowHeight)
                currentY += rowHeight
            }

            // Draw Official Footer / Signatures
            val signatureHeight = 70f
            if (currentY + signatureHeight > MAX_CONTENT_Y) {
                drawFooter(canvas, pageNumber)
                pdfDocument.finishPage(currentPage)
                
                pageNumber++
                currentPage = pdfDocument.startPage(pageInfo)
                canvas = currentPage.canvas
                currentY = MARGIN
                currentY = drawCompactSubPageHeader(canvas, currentY, "مستند التوقيع والاعتماد للتقرير المالي")
            }

            drawSignatures(canvas, currentY, directorName, hrManagerName)
            
            // Draw final footer and close
            drawFooter(canvas, pageNumber)
            pdfDocument.finishPage(currentPage)

            try {
                pdfDocument.writeTo(outputStream)
            } finally {
                pdfDocument.close()
            }
        }

        private fun drawTrainerFinancesMetadata(
            canvas: Canvas,
            startY: Float,
            trainerName: String,
            totalLakum: Double,
            totalAlaykum: Double,
            netBalance: Double,
            genDate: String,
            recordCount: Int
        ): Float {
            var currentY = startY + 12f

            // Document Main Title
            val titlePaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val title = "كشف الحركات المالية والمسحوبات للمدرب"
            val titleLayout = StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, PRINT_WIDTH.toInt())
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .build()

            canvas.save()
            canvas.translate(MARGIN, currentY)
            titleLayout.draw(canvas)
            canvas.restore()

            currentY += titleLayout.height + 14f

            // Gray border container for metadata
            val boxPaint = Paint().apply {
                color = COLOR_BG_LIGHT
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + 65f, boxPaint)

            val borderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + 65f, borderPaint)

            // Draw Metadata Fields inside Box
            val fieldPaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 8.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                isAntiAlias = true
            }

            val rightX = PAGE_WIDTH - MARGIN - 12f
            val centerX = PAGE_WIDTH / 2f
            val leftX = MARGIN + 12f

            val y1 = currentY + 18f
            val y2 = currentY + 36f
            val y3 = currentY + 54f

            // Line 1: المدرب / تاريخ التصدير / عدد الحركات
            fieldPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("المدرب: $trainerName".toEnglishNumbers(), rightX, y1, fieldPaint)

            fieldPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("تاريخ التصدير: $genDate".toEnglishNumbers(), centerX, y1, fieldPaint)

            fieldPaint.textAlign = Paint.Align.LEFT
            canvas.drawText("عدد الحركات: $recordCount حركة".toEnglishNumbers(), leftX, y1, fieldPaint)

            // Line 2: مستحقات لكم / مسحوبات عليكم / الرصيد الصافي
            val lakumText = "مستحقات لكم (+): ${formatFinanceAmountNoDecimals(totalLakum)} ر.ي"
            val alaykumText = "مسحوبات عليكم (-): ${formatFinanceAmountNoDecimals(totalAlaykum)} ر.ي"
            val netText = "الرصيد الصافي: ${formatFinanceAmountNoDecimals(netBalance)} ر.ي"

            fieldPaint.textAlign = Paint.Align.RIGHT
            val lakumPaint = TextPaint(fieldPaint).apply { color = Color.parseColor("#047857"); typeface = Typeface.DEFAULT_BOLD }
            canvas.drawText(lakumText.toEnglishNumbers(), rightX, y2, lakumPaint)

            fieldPaint.textAlign = Paint.Align.CENTER
            val alaykumPaint = TextPaint(fieldPaint).apply { color = Color.parseColor("#B91C1C"); typeface = Typeface.DEFAULT_BOLD }
            canvas.drawText(alaykumText.toEnglishNumbers(), centerX, y2, alaykumPaint)

            fieldPaint.textAlign = Paint.Align.LEFT
            val netColor = if (netBalance >= 0) Color.parseColor("#047857") else Color.parseColor("#B91C1C")
            val netPaint = TextPaint(fieldPaint).apply { color = netColor; typeface = Typeface.DEFAULT_BOLD }
            canvas.drawText(netText.toEnglishNumbers(), leftX, y2, netPaint)

            // Line 3: Currency note
            fieldPaint.textAlign = Paint.Align.CENTER
            val notePaint = TextPaint(fieldPaint).apply { color = COLOR_TEXT_MUTED; textSize = 7.5f }
            canvas.drawText("ملاحظة: جميع المبالغ المذكورة أعلاه مقومة بـ الريال اليمني (ر.ي)".toEnglishNumbers(), centerX, y3, notePaint)

            return currentY + 65f + 16f
        }

        private fun calculateTrainerFinanceRowHeight(record: TrainerTransaction, widths: List<Float>): Float {
            val p1 = TextPaint().apply { textSize = 8.5f; typeface = Typeface.DEFAULT_BOLD }
            val l1 = StaticLayout.Builder.obtain(record.courseName, 0, record.courseName.length, p1, (widths[0] - 8).toInt().coerceAtLeast(10)).build()

            val p2 = TextPaint().apply { textSize = 8f }
            val noteStr = record.note.ifEmpty { "بدون ملاحظة" }
            val l2 = StaticLayout.Builder.obtain(noteStr, 0, noteStr.length, p2, (widths[5] - 8).toInt().coerceAtLeast(10)).build()

            val maxHeight = Math.max(l1.height, l2.height)
            return (maxHeight + 12f).coerceAtLeast(32f)
        }

        private fun drawTrainerFinanceRow(
            canvas: Canvas,
            startY: Float,
            record: TrainerTransaction,
            currentRunningBal: Double,
            widths: List<Float>,
            rowHeight: Float
        ) {
            val bgPaint = Paint().apply {
                color = if (record.id % 2L == 0L) COLOR_BG_LIGHT else Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, startY, PAGE_WIDTH - MARGIN, startY + rowHeight, bgPaint)

            val borderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }
            canvas.drawRect(MARGIN, startY, PAGE_WIDTH - MARGIN, startY + rowHeight, borderPaint)

            val typeText = if (record.type == "لكم") "مستحق (لكم)" else "مسحوبات (عليكم)"
            val typeColor = if (record.type == "لكم") Color.parseColor("#047857") else Color.parseColor("#B91C1C")

            val amountText = "${if (record.type == "لكم") "+" else "-"}${formatFinanceAmountNoDecimals(record.amount)} ر.ي"
            val amountColor = if (record.type == "لكم") Color.parseColor("#047857") else Color.parseColor("#B91C1C")

            val balText = "${formatFinanceAmountNoDecimals(currentRunningBal)} ر.ي"
            val balColor = if (currentRunningBal >= 0) Color.parseColor("#047857") else Color.parseColor("#B91C1C")

            val columns = listOf(
                PdfColumn(record.courseName, widths[0], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, isBold = true),
                PdfColumn(record.date, widths[1], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY),
                PdfColumn(typeText, widths[2], Layout.Alignment.ALIGN_CENTER, typeColor, isBold = true),
                PdfColumn(amountText, widths[3], Layout.Alignment.ALIGN_CENTER, amountColor, isBold = true),
                PdfColumn(balText, widths[4], Layout.Alignment.ALIGN_CENTER, balColor, isBold = true),
                PdfColumn(record.note.ifEmpty { "-" }, widths[5], Layout.Alignment.ALIGN_CENTER, COLOR_TEXT_MUTED)
            )

            drawColumns(canvas, startY, columns, rowHeight)
        }

        fun exportActivityLogsToPdf(
            viewModel: MainViewModel,
            logs: List<AppActivityLog>,
            outputStream: OutputStream
        ) {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()

            val instName = viewModel.instituteName.value
            val instSlogan = viewModel.instituteSlogan.value
            val logoUri = viewModel.instituteLogoUri.value

            val sdfDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val generationDateStr = sdfDate.format(Date())

            val sortedLogs = logs.sortedByDescending { it.timestamp }

            var pageNumber = 1
            var page = pdfDocument.startPage(pageInfo)
            var canvas = page.canvas

            // Draw official top header
            drawOfficialHeader(canvas, instName, instSlogan, logoUri)

            var currentY = 100f

            // Report title text
            val titlePaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("سجل الحركات الأكاديمية والأنشطة الشامل", PAGE_WIDTH / 2f, currentY, titlePaint)
            currentY += 16f

            val subtitlePaint = TextPaint().apply {
                color = COLOR_TEXT_MUTED
                textSize = 9f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("تقرير المراجعة وتوثيق العمليات بالنظام - تاريخ التصدير: $generationDateStr".toEnglishNumbers(), PAGE_WIDTH / 2f, currentY, subtitlePaint)
            currentY += 16f

            // Stats summary card
            val totalCount = sortedLogs.size
            val createCount = sortedLogs.count { it.actionType == "CREATE" }
            val updateCount = sortedLogs.count { it.actionType == "UPDATE" }
            val deleteCount = sortedLogs.count { it.actionType == "DELETE" }

            val cardHeight = 28f
            val cardPaint = Paint().apply {
                color = COLOR_BG_LIGHT
                style = Paint.Style.FILL
            }
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + cardHeight, cardPaint)

            val borderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + cardHeight, borderPaint)

            val statsColumns = listOf(
                PdfColumn("إجمالي الحركات: $totalCount", 130f, Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, isBold = true),
                PdfColumn("إضافة: $createCount", 110f, Layout.Alignment.ALIGN_CENTER, Color.parseColor("#047857"), isBold = true),
                PdfColumn("تعديل: $updateCount", 110f, Layout.Alignment.ALIGN_CENTER, Color.parseColor("#1D4ED8"), isBold = true),
                PdfColumn("حذف: $deleteCount", 110f, Layout.Alignment.ALIGN_CENTER, Color.parseColor("#B91C1C"), isBold = true)
            )
            drawColumns(canvas, currentY + 6f, statsColumns, cardHeight - 12f)

            currentY += cardHeight + 14f

            // Table Header
            val colWidths = listOf(105f, 70f, 70f, 140f, 150f) // Total 535f = PRINT_WIDTH
            val headers = listOf("التاريخ والوقت", "الفئة", "نوع الإجراء", "العنوان", "التفاصيل والبيان")
            drawTableHeader(canvas, currentY, headers, colWidths)
            val headerHeight = 28f
            currentY += headerHeight

            for (log in sortedLogs) {
                val rowHeight = 26f
                if (currentY + rowHeight > PAGE_HEIGHT - MARGIN - 40f) {
                    drawFooter(canvas, pageNumber)
                    pdfDocument.finishPage(page)

                    pageNumber++
                    val newPageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                    page = pdfDocument.startPage(newPageInfo)
                    canvas = page.canvas

                    drawOfficialHeader(canvas, instName, instSlogan, logoUri)
                    currentY = 100f

                    canvas.drawText("سجل الحركات الأكاديمية والأنشطة الشامل (تابع)", PAGE_WIDTH / 2f, currentY, titlePaint)
                    currentY += 24f

                    drawTableHeader(canvas, currentY, headers, colWidths)
                    currentY += headerHeight
                }

                val rowBg = Paint().apply {
                    color = Color.WHITE
                    style = Paint.Style.FILL
                }
                canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, rowBg)
                canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, borderPaint)

                val catText = when (log.category) {
                    "FINANCIAL" -> "مالية"
                    "ATTENDANCE" -> "حضور"
                    "GRADES" -> "درجات"
                    "COURSES" -> "دورات"
                    "STUDENTS" -> "طلاب"
                    else -> "نظام"
                }

                val actionText = when (log.actionType) {
                    "CREATE" -> "إضافة"
                    "UPDATE" -> "تعديل"
                    "DELETE" -> "حذف"
                    "RECORD" -> "رصد"
                    else -> log.actionType
                }

                val actionColor = when (log.actionType) {
                    "CREATE" -> Color.parseColor("#047857")
                    "UPDATE" -> Color.parseColor("#1D4ED8")
                    "DELETE" -> Color.parseColor("#B91C1C")
                    else -> Color.parseColor("#6B21A8")
                }

                val dateTimeText = "${log.dateStr} ${log.timeStr}"

                val cols = listOf(
                    PdfColumn(dateTimeText, colWidths[0], Layout.Alignment.ALIGN_CENTER, COLOR_TEXT_MUTED),
                    PdfColumn(catText, colWidths[1], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, isBold = true),
                    PdfColumn(actionText, colWidths[2], Layout.Alignment.ALIGN_CENTER, actionColor, isBold = true),
                    PdfColumn(log.title, colWidths[3], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, isBold = true),
                    PdfColumn(log.description.ifEmpty { "-" }, colWidths[4], Layout.Alignment.ALIGN_CENTER, COLOR_TEXT_MUTED)
                )

                drawColumns(canvas, currentY + 4f, cols, rowHeight - 8f)
                currentY += rowHeight
            }

            drawFooter(canvas, pageNumber)
            pdfDocument.finishPage(page)

            try {
                pdfDocument.writeTo(outputStream)
            } finally {
                pdfDocument.close()
            }
        }

        /**
         * Exports Comprehensive Final Course & Teaching Progress Report to PDF.
         */
        fun exportCourseFinalReportToPdf(
            viewModel: MainViewModel,
            course: Course,
            stats: List<CourseSubjectStat>,
            students: List<Student>,
            grades: List<StudentGrade> = emptyList(),
            attendanceList: List<StudentAttendance> = emptyList(),
            outputStream: OutputStream,
            trainerNotes: String = ""
        ) {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()

            val instName = viewModel.instituteName.value
            val instSlogan = viewModel.instituteSlogan.value
            val logoUri = viewModel.instituteLogoUri.value

            val sdfDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val generationDateStr = sdfDate.format(Date())

            var pageNumber = 1
            var page = pdfDocument.startPage(pageInfo)
            var canvas = page.canvas

            var currentY = MARGIN

            // Draw official header
            drawOfficialHeader(canvas, instName, instSlogan, logoUri)
            currentY += 80f

            // Title
            val titlePaint = Paint().apply {
                color = COLOR_PRIMARY
                textSize = 13f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("التقرير الختامي الشامل للدورة التدريبية والطلاب", (PAGE_WIDTH / 2).toFloat(), currentY, titlePaint)
            currentY += 18f

            // Metadata info bar
            val infoPaint = Paint().apply {
                color = COLOR_TEXT_MUTED
                textSize = 8.5f
                isAntiAlias = true
                textAlign = Paint.Align.RIGHT
            }
            val infoPaintLeft = Paint().apply {
                color = COLOR_TEXT_MUTED
                textSize = 8.5f
                isAntiAlias = true
                textAlign = Paint.Align.LEFT
            }
            canvas.drawText("تاريخ الإصدار: $generationDateStr", PAGE_WIDTH - MARGIN, currentY, infoPaint)
            canvas.drawText("حالة الدورة: ${if (course.isCompleted) "منتهية 🏁" else "مستمرة 🟢"}", MARGIN, currentY, infoPaintLeft)
            currentY += 14f

            // Course Info Summary Box
            val boxBgPaint = Paint().apply {
                color = Color.parseColor("#F8FAFC")
                style = Paint.Style.FILL
            }
            val boxBorderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }

            val metaPaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 8.5f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val metaNormalPaint = TextPaint().apply {
                color = Color.parseColor("#1E293B")
                textSize = 8.2f
                isAntiAlias = true
            }

            val trainerDaysCount = viewModel.dbAttendance.value.count { it.courseId == course.id && it.status == "حضور" }
            val subjectsTaughtDaysSum = stats.sumOf { it.taughtDaysCount }
            val executedDaysCount = if (trainerDaysCount > 0) {
                trainerDaysCount
            } else if (subjectsTaughtDaysSum > 0) {
                subjectsTaughtDaysSum
            } else {
                try {
                    val startParts = course.startDate.split("-")
                    val endParts = course.endDate.split("-")
                    if (startParts.size == 3 && endParts.size == 3) {
                        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                        val d1 = sdf.parse(course.startDate)
                        val d2 = sdf.parse(course.endDate)
                        if (d1 != null && d2 != null) {
                            ((d2.time - d1.time) / (1000 * 60 * 60 * 24)).toInt() + 1
                        } else 0
                    } else 0
                } catch (e: Exception) { 0 }
            }

            val trainerName = viewModel.trainerNameConfig.value.ifBlank {
                course.trainerName.ifBlank { "م. فيصل العفيف" }
            }
            val row1 = "اسم الدورة: ${course.name}   |   المدرب: $trainerName   |   القسم/الدبلوم: ${listOfNotNull(course.departmentName.ifEmpty { null }, course.diplomaName.ifEmpty { null }).joinToString(" - ").ifEmpty { "عام" }}"
            val row2 = "تاريخ البداية: ${course.startDate.ifEmpty { "-" }}   |   تاريخ النهاية: ${course.endDate.ifEmpty { "-" }}   |   المدة المنفذة: $executedDaysCount يوم تدريبي"
            val sortedStats = stats.sortedWith(compareBy<CourseSubjectStat> { StudentGradeConfig.getSubjectRank(it.subjectName) }.thenBy { it.subjectName })
            val completedSubjects = sortedStats.count { it.status == "مكتملة التدريس" || it.status == "مكتملة بالكامل" }
            val progressPct = if (sortedStats.isNotEmpty()) (completedSubjects * 100) / sortedStats.size else 0
            val row3 = "إجمالي المواد: ${sortedStats.size}   |   المكتملة: $completedSubjects   |   نسبة إنجاز الخطة: $progressPct%   |   الطلاب المسجلين: ${students.size} طالب"

            val layout1 = StaticLayout.Builder.obtain(row1.toEnglishNumbers(), 0, row1.length, metaPaint, (PRINT_WIDTH - 24).toInt())
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
            val layout2 = StaticLayout.Builder.obtain(row2.toEnglishNumbers(), 0, row2.length, metaNormalPaint, (PRINT_WIDTH - 24).toInt())
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
            val layout3 = StaticLayout.Builder.obtain(row3.toEnglishNumbers(), 0, row3.length, metaNormalPaint, (PRINT_WIDTH - 24).toInt())
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

            val boxContentHeight = layout1.height + layout2.height + layout3.height + 24f
            val boxHeight = boxContentHeight.coerceAtLeast(56f)

            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + boxHeight, boxBgPaint)
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + boxHeight, boxBorderPaint)

            canvas.save()
            canvas.translate(MARGIN + 12f, currentY + 7f)
            layout1.draw(canvas)
            canvas.translate(0f, layout1.height + 5f)
            layout2.draw(canvas)
            canvas.translate(0f, layout2.height + 5f)
            layout3.draw(canvas)
            canvas.restore()

            currentY += boxHeight + 14f

            // Section 1: Table of Subjects with Pass Statistics (RTL)
            val config = viewModel.dbAllGradeConfigs.value.find { it.courseId == course.id }
            val passingPercentage = config?.getPassingPercentage() ?: 75.0
            val activeStudents = students.filter { it.status == "مستمر" || (it.status != "توقيف قيد" && it.status != "موقوف" && it.status != "موقف" && it.status != "منسحب" && it.status != "منقطع" && it.status != "محذوف") }
            val activeStudentIds = activeStudents.map { it.id }.toSet()

            val colWidths = listOf(215f, 65f, 105f, 75f, 75f) // Total = 535f = PRINT_WIDTH
            val headers = listOf("اسم المادة الدراسية", "المنفذ", "حالة التدريس", "الناجحين", "نسبة النجاح")
            drawTableHeader(canvas, currentY, headers, colWidths)
            currentY += 28f

            val borderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 0.5f
            }

            val subjectMeasurePaint = TextPaint().apply {
                textSize = 8.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            for (stat in sortedStats) {
                val cleanSub = stat.subjectName.toEnglishNumbers()
                val subL = StaticLayout.Builder.obtain(cleanSub, 0, cleanSub.length, subjectMeasurePaint, (colWidths[0] - 12).toInt().coerceAtLeast(10))
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

                val rowHeight = (subL.height + 12f).coerceAtLeast(24f)

                if (currentY + rowHeight > FOOTER_Y - 90f) {
                    drawFooter(canvas, pageNumber)
                    pdfDocument.finishPage(page)
                    pageNumber++
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    currentY = MARGIN
                    currentY = drawCompactSubPageHeader(canvas, currentY, "التقرير الختامي لدورة: ${course.name}")
                    drawTableHeader(canvas, currentY, headers, colWidths)
                    currentY += 28f
                }

                val rowBg = Paint().apply {
                    color = if (stat.status.contains("مكتملة")) Color.parseColor("#F0FDF4") else Color.WHITE
                    style = Paint.Style.FILL
                }
                canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, rowBg)
                canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, borderPaint)

                val statusColor = when {
                    stat.status.contains("مكتملة") -> Color.parseColor("#15803D")
                    stat.status.contains("انتظار") || stat.status.contains("مؤجلة") -> Color.parseColor("#B45309")
                    else -> COLOR_PRIMARY
                }

                // Compute subject pass statistics
                val subPassThreshold = config?.getPassingPercentage() ?: passingPercentage
                val studentsWithGradeInSub = grades.filter {
                    it.studentId in activeStudentIds &&
                    it.subjectName.trim().equals(stat.subjectName.trim(), ignoreCase = true)
                }
                val passedCount = studentsWithGradeInSub.count { g ->
                    val score = g.getTotalScore()
                    // If it's a diploma subject, the score is out of 100.
                    // We compare it directly with the passing percentage (e.g. 75.0)
                    val note = g.getGradeNote()
                    val isFailedByNote = note.contains("راسب") || note.contains("بدون") || note.contains("لم يُرصد") || note.contains("غير مكتمل") || note.contains("غائب")
                    score >= subPassThreshold && !isFailedByNote
                }
                val totalExamined = if (activeStudents.isNotEmpty()) activeStudents.size else studentsWithGradeInSub.size
                val passRatePct = if (totalExamined > 0) ((passedCount * 100.0) / totalExamined) else 0.0
                val passRateStr = if (totalExamined == 0) "-" else if (passRatePct % 1.0 == 0.0) "${passRatePct.toInt()}%" else String.format(Locale.US, "%.1f%%", passRatePct)
                val passCountStr = if (totalExamined == 0) "-" else "$passedCount من $totalExamined"

                val passColor = when {
                    totalExamined == 0 -> COLOR_TEXT_MUTED
                    passRatePct >= 85.0 -> Color.parseColor("#15803D")
                    passRatePct >= 70.0 -> Color.parseColor("#B45309")
                    else -> Color.parseColor("#DC2626")
                }

                val cols = listOf(
                    PdfColumn(stat.subjectName, colWidths[0], Layout.Alignment.ALIGN_NORMAL, COLOR_PRIMARY, isBold = true),
                    PdfColumn("${stat.taughtDaysCount} يوم", colWidths[1], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, isBold = true),
                    PdfColumn(stat.status, colWidths[2], Layout.Alignment.ALIGN_CENTER, statusColor, isBold = true),
                    PdfColumn(passCountStr, colWidths[3], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY),
                    PdfColumn(passRateStr, colWidths[4], Layout.Alignment.ALIGN_CENTER, passColor, isBold = true)
                )

                drawColumns(canvas, currentY, cols, rowHeight)
                currentY += rowHeight
            }

            // Section 2: Students Evaluation, Attendance Commitment & Subject Grades (RTL)
            val inactiveStudents = students.filter { !activeStudents.contains(it) }

            if (activeStudents.isNotEmpty()) {
                currentY += 15f

                if (currentY + 60f > FOOTER_Y - 90f) {
                    drawFooter(canvas, pageNumber)
                    pdfDocument.finishPage(page)
                    pageNumber++
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    currentY = MARGIN
                    currentY = drawCompactSubPageHeader(canvas, currentY, "التقرير الختامي لدورة: ${course.name}")
                }

                val sectionHeaderPaint = Paint().apply {
                    color = COLOR_PRIMARY
                    textSize = 10.5f
                    isAntiAlias = true
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.RIGHT
                }
                canvas.drawText("👥 كشف نتائج وتقييم الطلاب المستمرين ونسبة الالتزام:", PAGE_WIDTH - MARGIN, currentY, sectionHeaderPaint)
                currentY += 12f

                val studentColWidths = listOf(28f, 130f, 55f, 55f, 67f, 200f) // Total = 535f = PRINT_WIDTH
                val studentHeaders = listOf("م", "اسم الطالب", "نسبة الالتزام", "المعدل العام", "الحالة", "ملاحظات المواد")
                drawTableHeader(canvas, currentY, studentHeaders, studentColWidths)
                currentY += 28f

                // Subject weights calculation if configured
                val subjectWeights = config?.getSubjectWeights() ?: emptyMap()
                val hasWeights = subjectWeights.isNotEmpty()
                val allCourseSubNames = sortedStats.map { it.subjectName }.filter { it.isNotBlank() }.distinct()

                data class StudentEvaluationItem(
                    val student: Student,
                    val attendanceRate: Int,
                    val gpa: Double,
                    val fmtGpa: String,
                    val isPassing: Boolean,
                    val hasGrades: Boolean,
                    val statusText: String,
                    val statusColor: Int,
                    val notesSummary: String
                )

                val evaluatedStudents = activeStudents.map { st ->
                    val stAtt = attendanceList.filter { it.studentId == st.id }
                    val totalSessions = stAtt.size
                    val presentCount = stAtt.count { it.status == "حضور" }
                    val attRate = if (totalSessions > 0) ((presentCount.toFloat() / totalSessions.toFloat()) * 100).toInt() else 100

                    val stGrades = grades.filter { it.studentId == st.id }
                        .sortedWith(compareBy<StudentGrade> { StudentGradeConfig.getSubjectRank(it.subjectName) }.thenBy { it.subjectName })

                    val gpa = if (stGrades.isEmpty()) {
                        0.0
                    } else if (hasWeights && allCourseSubNames.isNotEmpty()) {
                        var weightedTotal = 0.0
                        var weightSum = 0.0
                        allCourseSubNames.forEach { subName ->
                            val w = subjectWeights[subName] ?: (100.0 / allCourseSubNames.size.coerceAtLeast(1))
                            val gr = stGrades.find { it.subjectName.trim().equals(subName.trim(), ignoreCase = true) }
                            val score = gr?.getTotalScore() ?: 0.0
                            weightedTotal += (score / 100.0) * w
                            weightSum += w
                        }
                        if (weightSum > 0.0) (weightedTotal / weightSum) * 100.0 else 0.0
                    } else {
                        stGrades.map { it.getTotalScore() }.average()
                    }

                    val fmtGpa = if (gpa % 1.0 == 0.0) "${gpa.toInt()}%" else String.format(Locale.US, "%.1f%%", gpa)

                    // Passing status based on overall GPA threshold
                    val hasGrades = stGrades.isNotEmpty()
                    val isPassing = hasGrades && gpa >= passingPercentage
                    val statusText = if (!hasGrades) "لم يُرصد" else if (isPassing) "ناجح ✅" else "راسب ⚠️"
                    val statusColor = if (!hasGrades) COLOR_TEXT_MUTED else if (isPassing) Color.parseColor("#15803D") else Color.parseColor("#DC2626")

                    val notesList = stGrades.mapNotNull { g ->
                        val n = g.getGradeNote()
                        if (n.isNotBlank()) "• ${g.subjectName}: $n" else null
                    }
                    val notesSummary = if (notesList.isNotEmpty()) notesList.joinToString("\n") else "-"

                    StudentEvaluationItem(st, attRate, gpa, fmtGpa, isPassing, hasGrades, statusText, statusColor, notesSummary)
                }

                // Sort: Passed students first descending by GPA, then remaining students descending by GPA
                val sortedStudents = evaluatedStudents.sortedWith(
                    compareByDescending<StudentEvaluationItem> { it.isPassing }
                        .thenByDescending { it.gpa }
                        .thenBy { it.student.name }
                )

                val studentNameMeasurePaint = TextPaint().apply {
                    textSize = 8.5f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
                val studentNotesMeasurePaint = TextPaint().apply {
                    textSize = 7.5f
                }

                for ((idx, item) in sortedStudents.withIndex()) {
                    val st = item.student
                    val cleanStName = st.name.toEnglishNumbers()
                    val stNameL = StaticLayout.Builder.obtain(cleanStName, 0, cleanStName.length, studentNameMeasurePaint, (studentColWidths[1] - 12).toInt().coerceAtLeast(10))
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

                    val cleanStNotes = item.notesSummary.toEnglishNumbers()
                    val stNotesL = StaticLayout.Builder.obtain(cleanStNotes, 0, cleanStNotes.length, studentNotesMeasurePaint, (studentColWidths[5] - 12).toInt().coerceAtLeast(10))
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

                    val rowHeight = (maxOf(stNameL.height, stNotesL.height) + 12f).coerceAtLeast(24f)

                    if (currentY + rowHeight > FOOTER_Y - 90f) {
                        drawFooter(canvas, pageNumber)
                        pdfDocument.finishPage(page)
                        pageNumber++
                        page = pdfDocument.startPage(pageInfo)
                        canvas = page.canvas
                        currentY = MARGIN
                        currentY = drawCompactSubPageHeader(canvas, currentY, "نتائج وتقييم الطلاب - دورة: ${course.name}")
                        drawTableHeader(canvas, currentY, studentHeaders, studentColWidths)
                        currentY += 28f
                    }

                    val rowBg = Paint().apply {
                        color = if (idx % 2 == 0) Color.WHITE else Color.parseColor("#F8FAFC")
                        style = Paint.Style.FILL
                    }
                    canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, rowBg)
                    canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, borderPaint)

                    val attColor = when {
                        item.attendanceRate >= 85 -> Color.parseColor("#15803D")
                        item.attendanceRate >= 70 -> Color.parseColor("#B45309")
                        else -> Color.parseColor("#DC2626")
                    }

                    val cols = listOf(
                        PdfColumn("${idx + 1}", studentColWidths[0], Layout.Alignment.ALIGN_CENTER, COLOR_TEXT_MUTED),
                        PdfColumn(st.name, studentColWidths[1], Layout.Alignment.ALIGN_NORMAL, COLOR_PRIMARY, isBold = true),
                        PdfColumn("${item.attendanceRate}%", studentColWidths[2], Layout.Alignment.ALIGN_CENTER, attColor, isBold = true),
                        PdfColumn(if (!item.hasGrades) "-" else item.fmtGpa, studentColWidths[3], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, isBold = true),
                        PdfColumn(item.statusText, studentColWidths[4], Layout.Alignment.ALIGN_CENTER, item.statusColor, isBold = true),
                        PdfColumn(item.notesSummary, studentColWidths[5], Layout.Alignment.ALIGN_NORMAL, COLOR_TEXT_MUTED, textSize = 7.5f)
                    )

                    drawColumns(canvas, currentY, cols, rowHeight)
                    currentY += rowHeight
                }
            }

            // Section 3: Inactive / Withdrawn / Suspended Students (RTL)
            if (inactiveStudents.isNotEmpty()) {
                currentY += 15f

                if (currentY + 60f > FOOTER_Y - 90f) {
                    drawFooter(canvas, pageNumber)
                    pdfDocument.finishPage(page)
                    pageNumber++
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    currentY = MARGIN
                    currentY = drawCompactSubPageHeader(canvas, currentY, "التقرير الختامي لدورة: ${course.name}")
                }

                val inactiveSectionPaint = Paint().apply {
                    color = Color.parseColor("#B91C1C")
                    textSize = 10.5f
                    isAntiAlias = true
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.RIGHT
                }
                canvas.drawText("🚫 كشف الطلاب الموقوفين والمنسحبين وتاريخ التوقف:", PAGE_WIDTH - MARGIN, currentY, inactiveSectionPaint)
                currentY += 12f

                val inactColWidths = listOf(30f, 135f, 75f, 105f, 190f) // Total = 535f = PRINT_WIDTH
                val inactHeaders = listOf("م", "اسم الطالب", "حالة القيد", "تاريخ التوقف", "المواد والدرجات المسجلة")
                drawTableHeader(canvas, currentY, inactHeaders, inactColWidths)
                currentY += 28f

                val inactNameMeasurePaint = TextPaint().apply {
                    textSize = 8.5f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
                val inactGradesMeasurePaint = TextPaint().apply {
                    textSize = 8.0f
                }

                for ((idx, st) in inactiveStudents.withIndex()) {
                    val latestPresence = attendanceList.filter { it.studentId == st.id && it.status == "حضور" }.maxByOrNull { it.date }?.date
                    val stopDate = if (st.statusChangeDate.isNotBlank()) st.statusChangeDate else (latestPresence ?: attendanceList.filter { it.studentId == st.id }.maxByOrNull { it.date }?.date ?: "غير مسجل")

                    val stGrades = grades.filter { it.studentId == st.id && it.getTotalScore() > 0.0 }
                        .sortedWith(compareBy<StudentGrade> { StudentGradeConfig.getSubjectRank(it.subjectName) }.thenBy { it.subjectName })
                    val gradesSummary = if (stGrades.isNotEmpty()) {
                        stGrades.joinToString("\n") { "• ${it.subjectName}: ${it.getTotalScore()}" }
                    } else {
                        "لا توجد درجات مرصودة"
                    }

                    val cleanInactName = st.name.toEnglishNumbers()
                    val inactNameL = StaticLayout.Builder.obtain(cleanInactName, 0, cleanInactName.length, inactNameMeasurePaint, (inactColWidths[1] - 12).toInt().coerceAtLeast(10))
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

                    val cleanInactGrades = gradesSummary.toEnglishNumbers()
                    val inactGradesL = StaticLayout.Builder.obtain(cleanInactGrades, 0, cleanInactGrades.length, inactGradesMeasurePaint, (inactColWidths[4] - 12).toInt().coerceAtLeast(10))
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

                    val rowHeight = (maxOf(inactNameL.height, inactGradesL.height) + 12f).coerceAtLeast(24f)

                    if (currentY + rowHeight > FOOTER_Y - 90f) {
                        drawFooter(canvas, pageNumber)
                        pdfDocument.finishPage(page)
                        pageNumber++
                        page = pdfDocument.startPage(pageInfo)
                        canvas = page.canvas
                        currentY = MARGIN
                        currentY = drawCompactSubPageHeader(canvas, currentY, "الطلاب الموقوفون والمنسحبون - دورة: ${course.name}")
                        drawTableHeader(canvas, currentY, inactHeaders, inactColWidths)
                        currentY += 28f
                    }

                    val rowBg = Paint().apply {
                        color = if (idx % 2 == 0) Color.WHITE else Color.parseColor("#FEF2F2")
                        style = Paint.Style.FILL
                    }
                    canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, rowBg)
                    canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, borderPaint)

                    val cols = listOf(
                        PdfColumn("${idx + 1}", inactColWidths[0], Layout.Alignment.ALIGN_CENTER, COLOR_TEXT_MUTED),
                        PdfColumn(st.name, inactColWidths[1], Layout.Alignment.ALIGN_NORMAL, COLOR_PRIMARY, isBold = true),
                        PdfColumn(st.status, inactColWidths[2], Layout.Alignment.ALIGN_CENTER, Color.parseColor("#DC2626"), isBold = true),
                        PdfColumn(stopDate, inactColWidths[3], Layout.Alignment.ALIGN_CENTER, Color.parseColor("#B91C1C"), isBold = true),
                        PdfColumn(gradesSummary, inactColWidths[4], Layout.Alignment.ALIGN_NORMAL, COLOR_PRIMARY, textSize = 8.0f)
                    )

                    drawColumns(canvas, currentY, cols, rowHeight)
                    currentY += rowHeight
                }
            }

            // Trainer Notes Box if available
            if (trainerNotes.isNotBlank()) {
                val notesTextPaint = TextPaint().apply {
                    color = COLOR_PRIMARY
                    textSize = 8.5f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    isAntiAlias = true
                }
                val notesHeaderPaint = TextPaint().apply {
                    color = COLOR_PRIMARY
                    textSize = 9.5f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    isAntiAlias = true
                }

                val contentWidth = (PRINT_WIDTH - 24f).toInt()
                val cleanNotes = trainerNotes.trim().toEnglishNumbers()
                val notesLayout = StaticLayout.Builder.obtain(cleanNotes, 0, cleanNotes.length, notesTextPaint, contentWidth)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .build()

                val boxHeight = notesLayout.height + 34f
                if (currentY + boxHeight + 15f > FOOTER_Y) {
                    drawFooter(canvas, pageNumber)
                    pdfDocument.finishPage(page)
                    pageNumber++
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    currentY = MARGIN
                    currentY = drawCompactSubPageHeader(canvas, currentY, "التقرير الختامي لدورة: ${course.name}")
                }

                currentY += 10f
                val boxRect = android.graphics.RectF(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + boxHeight)
                val boxBg = Paint().apply {
                    color = Color.parseColor("#F8FAFC")
                    style = Paint.Style.FILL
                }
                val boxBorder = Paint().apply {
                    color = COLOR_BORDER
                    style = Paint.Style.STROKE
                    strokeWidth = 1f
                }
                canvas.drawRoundRect(boxRect, 6f, 6f, boxBg)
                canvas.drawRoundRect(boxRect, 6f, 6f, boxBorder)

                val headerTitle = "📝 ملاحظات وتوجيهات مدرب الدورة:".toEnglishNumbers()
                val headerLayout = StaticLayout.Builder.obtain(headerTitle, 0, headerTitle.length, notesHeaderPaint, contentWidth)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .build()

                canvas.save()
                canvas.translate(MARGIN + 12f, currentY + 8f)
                headerLayout.draw(canvas)
                canvas.restore()

                canvas.save()
                canvas.translate(MARGIN + 12f, currentY + 24f)
                notesLayout.draw(canvas)
                canvas.restore()

                currentY += boxHeight + 6f
            }

            // Signatures block - Trainer Signature Only (RTL)
            if (currentY + 80f > FOOTER_Y) {
                drawFooter(canvas, pageNumber)
                pdfDocument.finishPage(page)
                pageNumber++
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas
                currentY = MARGIN
                currentY = drawCompactSubPageHeader(canvas, currentY, "التقرير الختامي لدورة: ${course.name}")
            }

            val linePaint = Paint().apply {
                color = COLOR_BORDER
                strokeWidth = 1f
            }
            canvas.drawLine(MARGIN, currentY + 15f, PAGE_WIDTH - MARGIN, currentY + 15f, linePaint)

            val textPaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val trainerText = "مدرب الدورة\nالاسم: $trainerName\n\nتوقيع واعتماد المدرب: ................................"
            val cleanTrainer = trainerText.toEnglishNumbers()
            val trainerLayout = StaticLayout.Builder.obtain(cleanTrainer, 0, cleanTrainer.length, textPaint, 240)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .build()

            canvas.save()
            canvas.translate(PAGE_WIDTH - MARGIN - 240f, currentY + 28f)
            trainerLayout.draw(canvas)
            canvas.restore()

            drawFooter(canvas, pageNumber)
            pdfDocument.finishPage(page)

            try {
                pdfDocument.writeTo(outputStream)
            } finally {
                pdfDocument.close()
            }
        }

        /**
         * Exports Single Subject Report (Completion & Grades) to PDF.
         */
        fun exportSingleSubjectReportToPdf(
            viewModel: MainViewModel,
            course: Course,
            stat: CourseSubjectStat,
            students: List<Student>,
            grades: List<StudentGrade>,
            attendanceList: List<StudentAttendance> = emptyList(),
            attendanceSessions: List<Attendance> = emptyList(),
            outputStream: OutputStream
        ) {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()

            val instName = viewModel.instituteName.value
            val instSlogan = viewModel.instituteSlogan.value
            val logoUri = viewModel.instituteLogoUri.value

            val sdfDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            val generationDateStr = sdfDate.format(Date())

            var pageNumber = 1
            var page = pdfDocument.startPage(pageInfo)
            var canvas = page.canvas

            var currentY = MARGIN

            // Draw official header
            drawOfficialHeader(canvas, instName, instSlogan, logoUri)
            currentY += 80f

            // Title
            val titlePaint = Paint().apply {
                color = COLOR_PRIMARY
                textSize = 13f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("تقرير إنجاز ونتائج المادة الدراسية", (PAGE_WIDTH / 2).toFloat(), currentY, titlePaint)
            currentY += 18f

            // Info bar
            val infoPaint = Paint().apply {
                color = COLOR_TEXT_MUTED
                textSize = 8.5f
                isAntiAlias = true
                textAlign = Paint.Align.RIGHT
            }
            val infoPaintLeft = Paint().apply {
                color = COLOR_TEXT_MUTED
                textSize = 8.5f
                isAntiAlias = true
                textAlign = Paint.Align.LEFT
            }
            canvas.drawText("تاريخ الإصدار: $generationDateStr", PAGE_WIDTH - MARGIN, currentY, infoPaint)
            canvas.drawText("حالة المادة: ${stat.status}", MARGIN, currentY, infoPaintLeft)
            currentY += 14f

            // Box for Subject Metadata
            val boxBgPaint = Paint().apply {
                color = Color.parseColor("#F8FAFC")
                style = Paint.Style.FILL
            }
            val boxBorderPaint = Paint().apply {
                color = COLOR_BORDER
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            val metaPaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 8.5f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val metaNormalPaint = TextPaint().apply {
                color = Color.parseColor("#1E293B")
                textSize = 8.2f
                isAntiAlias = true
            }

            val config = viewModel.dbAllGradeConfigs.value.find { it.courseId == course.id }
            val passingPercentage = config?.getPassingPercentage() ?: 75.0
            val subjectWeights = config?.getSubjectWeights() ?: emptyMap()
            val subjectWeight = subjectWeights[stat.subjectName]
                ?: subjectWeights.entries.find { it.key.trim().equals(stat.subjectName.trim(), ignoreCase = true) }?.value
                ?: 0.0
            val maxSubjectScore = if (subjectWeight > 0.0) subjectWeight else 100.0
            val fmtMaxScore = if (maxSubjectScore % 1.0 == 0.0) "${maxSubjectScore.toInt()}" else String.format(Locale.US, "%.1f", maxSubjectScore)

            val subPassThreshold = if (subjectWeight > 0.0) {
                (passingPercentage / 100.0) * subjectWeight
            } else {
                passingPercentage
            }
            val fmtPassThreshold = if (subPassThreshold % 1.0 == 0.0) "${subPassThreshold.toInt()}" else String.format(Locale.US, "%.1f", subPassThreshold)

            val trainerName = viewModel.trainerNameConfig.value.ifBlank {
                course.trainerName.ifBlank { "م. فيصل العفيف" }
            }
            val row1 = "اسم الدورة: ${course.name}   |   المادة الدراسية: ${stat.subjectName}   |   مدرب المادة: $trainerName"
            val row2 = "تاريخ البداية: ${stat.firstTaughtDate.ifEmpty { "-" }}   |   تاريخ النهاية: ${stat.lastTaughtDate.ifEmpty { "-" }}   |   أيام التدريس المنفذة: ${stat.taughtDaysCount} يوم"
            val row3 = if (subjectWeight > 0.0) {
                "درجة المادة حسب التهيئة: $fmtMaxScore   |   حد النجاح: $fmtPassThreshold   |   نسبة النجاح المقررة: ${if (passingPercentage % 1.0 == 0.0) passingPercentage.toInt().toString() else String.format(Locale.US, "%.1f", passingPercentage)}%"
            } else {
                "حد النجاح: ${fmtPassThreshold}%   |   نسبة النجاح المقررة: ${if (passingPercentage % 1.0 == 0.0) passingPercentage.toInt().toString() else String.format(Locale.US, "%.1f", passingPercentage)}%"
            }

            val layout1 = StaticLayout.Builder.obtain(row1.toEnglishNumbers(), 0, row1.length, metaPaint, (PRINT_WIDTH - 24).toInt())
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
            val layout2 = StaticLayout.Builder.obtain(row2.toEnglishNumbers(), 0, row2.length, metaNormalPaint, (PRINT_WIDTH - 24).toInt())
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
            val layout3 = StaticLayout.Builder.obtain(row3.toEnglishNumbers(), 0, row3.length, metaNormalPaint, (PRINT_WIDTH - 24).toInt())
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

            val boxContentHeight = layout1.height + layout2.height + layout3.height + 24f
            val boxHeight = boxContentHeight.coerceAtLeast(56f)

            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + boxHeight, boxBgPaint)
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + boxHeight, boxBorderPaint)

            canvas.save()
            canvas.translate(MARGIN + 12f, currentY + 7f)
            layout1.draw(canvas)
            canvas.translate(0f, layout1.height + 5f)
            layout2.draw(canvas)
            canvas.translate(0f, layout2.height + 5f)
            layout3.draw(canvas)
            canvas.restore()

            currentY += boxHeight + 14f

            // Subject Attendance Sessions Filtering
            val subDates = attendanceSessions.filter {
                it.courseId == course.id &&
                it.subjectName.trim().equals(stat.subjectName.trim(), ignoreCase = true)
            }.map { it.date.trim() }.filter { it.isNotBlank() }.distinct().sorted()

            fun getStudentSubAttendanceRate(studentId: Int): Int {
                if (subDates.isNotEmpty()) {
                    val presentCount = attendanceList.count {
                        it.studentId == studentId && it.date in subDates && it.status == "حضور"
                    }
                    return ((presentCount * 100) / subDates.size).coerceIn(0, 100)
                } else {
                    val stAtt = attendanceList.filter { it.studentId == studentId }
                    val presentCount = stAtt.count { it.status == "حضور" }
                    return if (stAtt.isNotEmpty()) ((presentCount * 100) / stAtt.size).coerceIn(0, 100) else 100
                }
            }

            val activeStudents = students.filter { it.status == "مستمر" || (it.status != "توقيف قيد" && it.status != "موقوف" && it.status != "موقف" && it.status != "منسحب" && it.status != "منقطع" && it.status != "محذوف") }
            val inactiveStudents = students.filter { !activeStudents.contains(it) }

            val subjectGrades = grades.filter {
                it.courseId == course.id &&
                it.subjectName.trim().equals(stat.subjectName.trim(), ignoreCase = true)
            }

            // Student evaluation items
            data class SingleSubStudentEvaluation(
                val student: Student,
                val attendanceRate: Int,
                val rawScore: Double,
                val fmtRawScore: String,
                val weightedScore: Double,
                val fmtWeightedScore: String,
                val isPassing: Boolean,
                val hasGrade: Boolean,
                val statusText: String,
                val statusColor: Int,
                val note: String
            )

            val evaluatedActive = activeStudents.map { st ->
                val gr = subjectGrades.find { it.studentId == st.id }
                val rawScore = gr?.getTotalScore() ?: 0.0
                val hasGrade = gr != null && rawScore > 0.0
                val note = gr?.getGradeNote() ?: ""
                val isFailedByNote = note.contains("راسب") || note.contains("بدون") || note.contains("لم يُرصد") || note.contains("غير مكتمل")
                val isPassing = hasGrade && (rawScore >= passingPercentage) && !isFailedByNote
                val attRate = getStudentSubAttendanceRate(st.id)

                val weightedScore = if (subjectWeight > 0.0) (rawScore / 100.0) * subjectWeight else rawScore
                val fmtWeightedScore = if (!hasGrade) "-" else if (weightedScore % 1.0 == 0.0) "${weightedScore.toInt()}" else String.format(Locale.US, "%.1f", weightedScore)
                val fmtRawScore = if (!hasGrade) "-" else if (rawScore % 1.0 == 0.0) "${rawScore.toInt()}" else String.format(Locale.US, "%.1f", rawScore)

                val statusText = if (!hasGrade) "لم يُرصد" else if (isPassing) "ناجح ✅" else "راسب ⚠️"
                val statusColor = if (!hasGrade) COLOR_TEXT_MUTED else if (isPassing) Color.parseColor("#15803D") else Color.parseColor("#DC2626")

                SingleSubStudentEvaluation(
                    student = st,
                    attendanceRate = attRate,
                    rawScore = rawScore,
                    fmtRawScore = fmtRawScore,
                    weightedScore = weightedScore,
                    fmtWeightedScore = fmtWeightedScore,
                    isPassing = isPassing,
                    hasGrade = hasGrade,
                    statusText = statusText,
                    statusColor = statusColor,
                    note = note
                )
            }

            // Summary stats for subject
            val passedCount = evaluatedActive.count { it.isPassing }
            val totalExamined = evaluatedActive.count { it.hasGrade }
            val totalActive = evaluatedActive.size
            val passRatePct = if (totalActive > 0) ((passedCount * 100.0) / totalActive) else 0.0
            val passRateFormatted = if (totalActive == 0) "0%" else if (passRatePct % 1.0 == 0.0) "${passRatePct.toInt()}%" else String.format(Locale.US, "%.1f%%", passRatePct)

            // Section Header: Summary
            val sectionHeaderPaint = Paint().apply {
                color = COLOR_PRIMARY
                textSize = 10.5f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText("📊 ملخص نتائج المادة والنسب المئوية:", PAGE_WIDTH - MARGIN, currentY, sectionHeaderPaint)
            currentY += 12f

            val summaryText = "إجمالي المستمرين: $totalActive طالب   |   المختبرين: $totalExamined   |   الناجحين: $passedCount   |   الراسبين/المعلقين: ${totalActive - passedCount}   |   نسبة النجاح: $passRateFormatted"
            val summaryLayout = StaticLayout.Builder.obtain(summaryText.toEnglishNumbers(), 0, summaryText.length, metaPaint, (PRINT_WIDTH - 24).toInt())
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + summaryLayout.height + 14f, boxBgPaint)
            canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + summaryLayout.height + 14f, boxBorderPaint)

            canvas.save()
            canvas.translate(MARGIN + 12f, currentY + 7f)
            summaryLayout.draw(canvas)
            canvas.restore()

            currentY += summaryLayout.height + 22f

            // Section Header: Table of Students
            canvas.drawText("👥 كشف نتائج وتقييم الطلاب المتقدمين للمادة:", PAGE_WIDTH - MARGIN, currentY, sectionHeaderPaint)
            currentY += 12f

            val colWeightHeader = if (subjectWeight > 0.0) "الدرجة من\n($fmtMaxScore)" else "الدرجة\nالمحتسبة"
            val colRawHeader = "إجمالي درجات\nالمادة من 100"
            val studentColWidths = listOf(22f, 120f, 68f, 75f, 50f, 55f, 145f) // Total = 535f = PRINT_WIDTH
            val studentHeaders = listOf("م", "اسم الطالب", colWeightHeader, colRawHeader, "التزام المادة", "الحالة", "ملاحظات وتفاصيل المادة")
            drawTableHeader(canvas, currentY, studentHeaders, studentColWidths)
            currentY += 28f

            val sortedStudents = evaluatedActive.sortedWith(
                compareByDescending<SingleSubStudentEvaluation> { it.isPassing }
                    .thenByDescending { it.rawScore }
                    .thenBy { it.student.name }
            )

            val studentNameMeasurePaint = TextPaint().apply {
                textSize = 8.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val studentNotesMeasurePaint = TextPaint().apply {
                textSize = 7.5f
            }

            for ((idx, item) in sortedStudents.withIndex()) {
                val st = item.student
                val cleanStName = st.name.toEnglishNumbers()
                val stNameL = StaticLayout.Builder.obtain(cleanStName, 0, cleanStName.length, studentNameMeasurePaint, (studentColWidths[1] - 10).toInt().coerceAtLeast(10))
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

                val cleanStNotes = (if (item.note.isNotBlank()) item.note else "-").toEnglishNumbers()
                val stNotesL = StaticLayout.Builder.obtain(cleanStNotes, 0, cleanStNotes.length, studentNotesMeasurePaint, (studentColWidths[6] - 10).toInt().coerceAtLeast(10))
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

                val rowHeight = (maxOf(stNameL.height, stNotesL.height) + 12f).coerceAtLeast(24f)

                if (currentY + rowHeight > FOOTER_Y - 90f) {
                    drawFooter(canvas, pageNumber)
                    pdfDocument.finishPage(page)
                    pageNumber++
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    currentY = MARGIN
                    currentY = drawCompactSubPageHeader(canvas, currentY, "تقرير مادة: ${stat.subjectName} - دورة: ${course.name}")
                    drawTableHeader(canvas, currentY, studentHeaders, studentColWidths)
                    currentY += 28f
                }

                val rowBg = Paint().apply {
                    color = if (idx % 2 == 0) Color.parseColor("#FAFAFA") else Color.WHITE
                    style = Paint.Style.FILL
                }
                canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, rowBg)
                canvas.drawRect(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + rowHeight, boxBorderPaint)

                val cols = listOf(
                    PdfColumn((idx + 1).toString(), studentColWidths[0], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY),
                    PdfColumn(st.name, studentColWidths[1], Layout.Alignment.ALIGN_NORMAL, COLOR_PRIMARY, isBold = true),
                    PdfColumn(item.fmtWeightedScore, studentColWidths[2], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY, isBold = true),
                    PdfColumn(item.fmtRawScore, studentColWidths[3], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY),
                    PdfColumn("${item.attendanceRate}%", studentColWidths[4], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY),
                    PdfColumn(item.statusText, studentColWidths[5], Layout.Alignment.ALIGN_CENTER, item.statusColor, isBold = true),
                    PdfColumn(if (item.note.isNotBlank()) item.note else "-", studentColWidths[6], Layout.Alignment.ALIGN_NORMAL, COLOR_TEXT_MUTED)
                )

                drawColumns(canvas, currentY, cols, rowHeight)
                currentY += rowHeight
            }

            // Suspended/Withdrawn Section if any
            if (inactiveStudents.isNotEmpty()) {
                currentY += 15f
                if (currentY + 60f > FOOTER_Y - 90f) {
                    drawFooter(canvas, pageNumber)
                    pdfDocument.finishPage(page)
                    pageNumber++
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    currentY = MARGIN
                    currentY = drawCompactSubPageHeader(canvas, currentY, "تقرير مادة: ${stat.subjectName} - دورة: ${course.name}")
                }

                canvas.drawText("🚫 كشف الطلاب الموقوفين والمنسحبين:", PAGE_WIDTH - MARGIN, currentY, sectionHeaderPaint)
                currentY += 12f

                val inactiveColWidths = listOf(28f, 180f, 120f, 207f)
                val inactiveHeaders = listOf("م", "اسم الطالب", "حالة القيد", "تاريخ وقرار التوقف")
                drawTableHeader(canvas, currentY, inactiveHeaders, inactiveColWidths)
                currentY += 28f

                for ((idx, st) in inactiveStudents.withIndex()) {
                    val rowHeight = 24f
                    if (currentY + rowHeight > FOOTER_Y - 90f) {
                        drawFooter(canvas, pageNumber)
                        pdfDocument.finishPage(page)
                        pageNumber++
                        page = pdfDocument.startPage(pageInfo)
                        canvas = page.canvas
                        currentY = MARGIN
                        currentY = drawCompactSubPageHeader(canvas, currentY, "تقرير مادة: ${stat.subjectName} - دورة: ${course.name}")
                        drawTableHeader(canvas, currentY, inactiveHeaders, inactiveColWidths)
                        currentY += 28f
                    }

                    val cols = listOf(
                        PdfColumn((idx + 1).toString(), inactiveColWidths[0], Layout.Alignment.ALIGN_CENTER, COLOR_PRIMARY),
                        PdfColumn(st.name, inactiveColWidths[1], Layout.Alignment.ALIGN_NORMAL, COLOR_PRIMARY, isBold = true),
                        PdfColumn(st.status, inactiveColWidths[2], Layout.Alignment.ALIGN_CENTER, Color.parseColor("#DC2626")),
                        PdfColumn(st.statusChangeDate.ifEmpty { "غير محدد" }, inactiveColWidths[3], Layout.Alignment.ALIGN_CENTER, COLOR_TEXT_MUTED)
                    )

                    drawColumns(canvas, currentY, cols, rowHeight)
                    currentY += rowHeight
                }
            }

            // Signature block
            if (currentY + 70f > FOOTER_Y - 30f) {
                drawFooter(canvas, pageNumber)
                pdfDocument.finishPage(page)
                pageNumber++
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas
                currentY = MARGIN
                currentY = drawCompactSubPageHeader(canvas, currentY, "تقرير مادة: ${stat.subjectName} - دورة: ${course.name}")
            }

            val linePaint = Paint().apply {
                color = COLOR_BORDER
                strokeWidth = 1f
            }
            canvas.drawLine(MARGIN, currentY + 15f, PAGE_WIDTH - MARGIN, currentY + 15f, linePaint)

            val textPaint = TextPaint().apply {
                color = COLOR_PRIMARY
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val trainerText = "مدرب المادة والدورة\nالاسم: $trainerName\n\nتوقيع واعتماد المدرب: ................................"
            val cleanTrainer = trainerText.toEnglishNumbers()
            val trainerLayout = StaticLayout.Builder.obtain(cleanTrainer, 0, cleanTrainer.length, textPaint, 240)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .build()

            canvas.save()
            canvas.translate(PAGE_WIDTH - MARGIN - 240f, currentY + 28f)
            trainerLayout.draw(canvas)
            canvas.restore()

            drawFooter(canvas, pageNumber)
            pdfDocument.finishPage(page)

            try {
                pdfDocument.writeTo(outputStream)
            } finally {
                pdfDocument.close()
            }
        }
    }
}
