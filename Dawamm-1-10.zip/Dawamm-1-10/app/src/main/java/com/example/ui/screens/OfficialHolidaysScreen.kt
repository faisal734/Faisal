package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.OfficialHoliday
import com.example.ui.components.AppHeader
import com.example.ui.components.DawamiBottomNavigationBar
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfficialHolidaysScreen(
    viewModel: MainViewModel,
    showMainLayout: Boolean = true
) {
    val context = LocalContext.current
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val notifications by viewModel.inAppNotifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    val holidays by viewModel.allOfficialHolidays.collectAsState()

    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingHoliday by remember { mutableStateOf<OfficialHoliday?>(null) }
    var holidayToDelete by remember { mutableStateOf<OfficialHoliday?>(null) }

    if (showMainLayout) {
        BackHandler {
            viewModel.navigateBack()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (showMainLayout) {
            Scaffold(
                topBar = {
                    AppHeader(
                        title = "الإجازات الرسمية والعطلات 🌴",
                        username = "",
                        onHomeClick = { viewModel.navigateTo(Screen.Selection) },
                        onBackClick = { viewModel.navigateBack() },
                        isDark = isDarkTheme,
                        onToggleTheme = { viewModel.toggleTheme() },
                        unreadNotificationCount = unreadCount,
                        onNotificationClick = { viewModel.openNotificationCenter() }
                    )
                },
                bottomBar = {
                    DawamiBottomNavigationBar(viewModel = viewModel)
                },
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = {
                            editingHoliday = null
                            showAddEditDialog = true
                        },
                        containerColor = DawamiGold,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "إضافة إجازة")
                    }
                }
            ) { innerPadding ->
                OfficialHolidaysContent(
                    modifier = Modifier.padding(innerPadding),
                    holidays = holidays,
                    onAddClick = {
                        editingHoliday = null
                        showAddEditDialog = true
                    },
                    onEditClick = {
                        editingHoliday = it
                        showAddEditDialog = true
                    },
                    onToggleClick = { viewModel.toggleOfficialHoliday(it) },
                    onDeleteClick = { holidayToDelete = it }
                )
            }
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
                OfficialHolidaysContent(
                    modifier = Modifier.fillMaxSize(),
                    holidays = holidays,
                    onAddClick = {
                        editingHoliday = null
                        showAddEditDialog = true
                    },
                    onEditClick = {
                        editingHoliday = it
                        showAddEditDialog = true
                    },
                    onToggleClick = { viewModel.toggleOfficialHoliday(it) },
                    onDeleteClick = { holidayToDelete = it }
                )
            }
        }

        // Add / Edit Dialog
        if (showAddEditDialog) {
            AddEditHolidayDialog(
                holiday = editingHoliday,
                onDismiss = { showAddEditDialog = false },
                onSave = { savedHoliday ->
                    if (editingHoliday == null) {
                        viewModel.insertOfficialHoliday(savedHoliday)
                        Toast.makeText(context, "تمت إضافة الإجازة الرسمية بنجاح 🌴", Toast.LENGTH_SHORT).show()
                    } else {
                        viewModel.updateOfficialHoliday(savedHoliday)
                        Toast.makeText(context, "تم تعديل الإجازة بنجاح ✏️", Toast.LENGTH_SHORT).show()
                    }
                    showAddEditDialog = false
                }
            )
        }

        // Delete Confirmation Dialog
        holidayToDelete?.let { holiday ->
            AlertDialog(
                onDismissRequest = { holidayToDelete = null },
                icon = {
                    Icon(
                        Icons.Default.DeleteForever,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        "تأكيد حذف الإجازة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Text(
                        "هل أنت متأكد من حذف إجازة «${holiday.name}»؟\nلن يتم استثناء هذا التاريخ بعد الآن كإجازة رسمية.",
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteOfficialHoliday(holiday)
                            Toast.makeText(context, "تم حذف الإجازة بنجاح 🗑️", Toast.LENGTH_SHORT).show()
                            holidayToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("حذف نهائي", color = Color.White)
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { holidayToDelete = null }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@Composable
fun OfficialHolidaysContent(
    modifier: Modifier = Modifier,
    holidays: List<OfficialHoliday>,
    onAddClick: () -> Unit,
    onEditClick: (OfficialHoliday) -> Unit,
    onToggleClick: (OfficialHoliday) -> Unit,
    onDeleteClick: (OfficialHoliday) -> Unit
) {
    val enabledHolidaysCount = holidays.count { it.isEnabled }
    val totalHolidayDays = holidays.filter { it.isEnabled }.sumOf { calculateDaysCount(it.startDate, it.endDate) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Summary Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DawamiNavy),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "نظام الإجازات الرسمية والعطلات",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                "تعامل الإجازات كأيام غير تدريبية (مثل عطلة نهاية الأسبوع)",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 12.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(DawamiGold.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🌴", fontSize = 22.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "$enabledHolidaysCount / ${holidays.size}",
                                color = DawamiGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "الإجازات المفعلة",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 11.sp
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "$totalHolidayDays",
                                color = Color(0xFF34D399), // Emerald
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "إجمالي الأيام المعطلة",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "سجل الإجازات المسجلة (${holidays.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                FilledTonalButton(
                    onClick = onAddClick,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إضافة إجازة", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        if (holidays.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🌴", fontSize = 40.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "لا توجد إجازات رسمية مسجلة بعد",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "أضف الأعياد والعطلات الرسمية لتطبيق استثنائها من الحضور والتنبيهات تلقائياً.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(holidays, key = { it.id }) { holiday ->
                HolidayCardItem(
                    holiday = holiday,
                    onEdit = { onEditClick(holiday) },
                    onToggle = { onToggleClick(holiday) },
                    onDelete = { onDeleteClick(holiday) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
fun HolidayCardItem(
    holiday: OfficialHoliday,
    onEdit: () -> Unit,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val daysCount = calculateDaysCount(holiday.startDate, holiday.endDate)
    val isSingleDay = holiday.startDate == holiday.endDate

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (holiday.isEnabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        border = BorderStroke(
            1.dp,
            if (holiday.isEnabled) DawamiTeal.copy(alpha = 0.4f) else Color.LightGray.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (holiday.isEnabled) 2.dp else 0.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (holiday.isEnabled) DawamiTeal.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (isSingleDay) "📆" else "🗓️", fontSize = 20.sp)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = holiday.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (holiday.isEnabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (holiday.isEnabled) "مفعلة 🟢" else "معطلة ⚪",
                            fontSize = 11.5.sp,
                            color = if (holiday.isEnabled) Color(0xFF059669) else Color.Gray,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Switch(
                    checked = holiday.isEnabled,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = DawamiTeal,
                        uncheckedThumbColor = Color.LightGray,
                        uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            // Dates & Duration
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    if (isSingleDay) {
                        Text(
                            text = "📅 التاريخ: ${holiday.startDate}",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Text(
                            text = "📅 من: ${holiday.startDate}  ←  إلى: ${holiday.endDate}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (holiday.isEnabled) DawamiGold.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = if (daysCount == 1) "يوم واحد" else "$daysCount أيام",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (holiday.isEnabled) DawamiGold else Color.Gray
                    )
                }
            }

            if (holiday.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "📝 ${holiday.notes}",
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = "تعديل الإجازة",
                        tint = DawamiNavy,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        Icons.Default.DeleteOutline,
                        contentDescription = "حذف الإجازة",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AddEditHolidayDialog(
    holiday: OfficialHoliday?,
    onDismiss: () -> Unit,
    onSave: (OfficialHoliday) -> Unit
) {
    val context = LocalContext.current
    val isEdit = holiday != null
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())

    var name by remember { mutableStateOf(holiday?.name ?: "") }
    var isSingleDay by remember { mutableStateOf(holiday?.let { it.startDate == it.endDate } ?: true) }
    var startDate by remember { mutableStateOf(holiday?.startDate ?: today) }
    var endDate by remember { mutableStateOf(holiday?.endDate ?: today) }
    var isEnabled by remember { mutableStateOf(holiday?.isEnabled ?: true) }
    var notes by remember { mutableStateOf(holiday?.notes ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun openDatePicker(currentDateStr: String, onSelect: (String) -> Unit) {
        val cal = Calendar.getInstance()
        try {
            val parts = currentDateStr.split("-")
            if (parts.size == 3) {
                val y = parts[0].toInt()
                val m = parts[1].toInt() - 1
                val d = parts[2].toInt()
                cal.set(y, m, d)
            }
        } catch (_: Exception) {}

        android.app.DatePickerDialog(
            context,
            com.example.R.style.CustomDatePickerDialogTheme,
            { _, year, month, dayOfMonth ->
                val formattedMonth = String.format(Locale.US, "%02d", month + 1)
                val formattedDay = String.format(Locale.US, "%02d", dayOfMonth)
                onSelect("$year-$formattedMonth-$formattedDay")
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (isEdit) "تعديل الإجازة الرسمية ✏️" else "إضافة إجازة رسمية جديدة 🌴",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Holiday Name
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorMessage = null
                    },
                    label = { Text("اسم الإجازة / المناسبة *") },
                    placeholder = { Text("مثلاً: عيد الفطر المبارك") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )

                // Single Day vs Period selector
                Text("نوع الإجازة:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = isSingleDay,
                        onClick = {
                            isSingleDay = true
                            endDate = startDate
                        },
                        label = { Text("يوم واحد 📆") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = !isSingleDay,
                        onClick = { isSingleDay = false },
                        label = { Text("عدة أيام 🗓️") },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Date Fields
                if (isSingleDay) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = startDate,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("تاريخ الإجازة (YYYY-MM-DD) *") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            leadingIcon = {
                                Icon(
                                    Icons.Default.CalendarToday,
                                    contentDescription = "اختيار التاريخ",
                                    tint = DawamiNavy
                                )
                            }
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    openDatePicker(startDate) { picked ->
                                        startDate = picked
                                        endDate = picked
                                        errorMessage = null
                                    }
                                }
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedTextField(
                                value = startDate,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("من *") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.CalendarToday,
                                        contentDescription = "اختيار تاريخ البداية",
                                        tint = DawamiNavy
                                    )
                                }
                            )
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        openDatePicker(startDate) { picked ->
                                            startDate = picked
                                            errorMessage = null
                                        }
                                    }
                            )
                        }
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedTextField(
                                value = endDate,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("إلى *") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.CalendarToday,
                                        contentDescription = "اختيار تاريخ النهاية",
                                        tint = DawamiNavy
                                    )
                                }
                            )
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        openDatePicker(endDate) { picked ->
                                            endDate = picked
                                            errorMessage = null
                                        }
                                    }
                            )
                        }
                    }
                }

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات (اختياري)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = false,
                    maxLines = 2,
                    shape = RoundedCornerShape(10.dp)
                )

                // Enabled Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تفعيل الإجازة فوراً", fontSize = 13.sp)
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { isEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = DawamiTeal
                        )
                    )
                }

                // Error message
                errorMessage?.let {
                    Text(
                        text = "⚠️ $it",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMessage = "يرجى كتابة اسم الإجازة."
                        return@Button
                    }
                    if (!isValidDateFormat(startDate) || (!isSingleDay && !isValidDateFormat(endDate))) {
                        errorMessage = "يرجى كتابة التاريخ بالصيغة الصحيحة (YYYY-MM-DD)."
                        return@Button
                    }
                    if (!isSingleDay && startDate > endDate) {
                        errorMessage = "تاريخ البداية لا يمكن أن يكون بعد تاريخ النهاية."
                        return@Button
                    }

                    val finalEndDate = if (isSingleDay) startDate else endDate
                    val newOrUpdated = holiday?.copy(
                        name = name.trim(),
                        startDate = startDate.trim(),
                        endDate = finalEndDate.trim(),
                        isEnabled = isEnabled,
                        notes = notes.trim()
                    ) ?: OfficialHoliday(
                        name = name.trim(),
                        startDate = startDate.trim(),
                        endDate = finalEndDate.trim(),
                        isEnabled = isEnabled,
                        notes = notes.trim()
                    )

                    onSave(newOrUpdated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
            ) {
                Text("حفظ", color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

fun calculateDaysCount(startDateStr: String, endDateStr: String): Int {
    if (startDateStr == endDateStr) return 1
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
        val d1 = sdf.parse(startDateStr)
        val d2 = sdf.parse(endDateStr)
        if (d1 != null && d2 != null) {
            val diffMs = Math.abs(d2.time - d1.time)
            (TimeUnit.DAYS.convert(diffMs, TimeUnit.MILLISECONDS) + 1).toInt()
        } else {
            1
        }
    } catch (e: Exception) {
        1
    }
}

fun isValidDateFormat(dateStr: String): Boolean {
    if (dateStr.length != 10) return false
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
        sdf.isLenient = false
        sdf.parse(dateStr)
        true
    } catch (e: Exception) {
        false
    }
}
