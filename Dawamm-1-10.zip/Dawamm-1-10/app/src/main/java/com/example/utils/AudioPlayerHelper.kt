package com.example.utils

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Log
import com.example.R
import java.util.Locale

/**
 * AudioPlayerHelper: Centralized helper for playing raw audio files (WAV/MP3 from res/raw)
 * or falling back to Arabic Text-To-Speech (TTS) if raw audio files are empty/missing.
 */
object AudioPlayerHelper {
    private var mediaPlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private var pendingTextToSpeak: Pair<String, String>? = null

    fun getRawResourceId(context: Context, rawName: String?): Int {
        if (rawName.isNullOrBlank()) return 0

        val directId = when (rawName) {
            "precourse_15min", "trainer_start_15m", "trainer_start_15min", "trainer_start" -> R.raw.precourse_15min
            "precourse_10min", "trainer_start_10m", "trainer_start_10min" -> R.raw.precourse_10min
            "precourse_5min", "trainer_start_5m", "trainer_start_5min" -> R.raw.precourse_5min
            "trainer_checkin_prompt", "smart_checkup_prompt", "trainer_checkin", "trainer_checkin_5m", "trainer_checkin_10m", "trainer_checkin_30m", "trainer_checkin_60m" -> R.raw.trainer_checkin_prompt
            "student_checkin_prompt", "student_checkin", "student_checkin_5m", "student_checkin_10m", "student_checkin_30m", "student_checkin_60m" -> R.raw.student_checkin_prompt
            "trainer_checkout_prompt", "trainer_checkout", "trainer_checkout_5m", "trainer_checkout_10m", "trainer_checkout_30m", "trainer_checkout_60m" -> R.raw.trainer_checkout_prompt
            "student_checkout_prompt", "student_checkout", "student_checkout_5m", "student_checkout_10m", "student_checkout_30m", "student_checkout_60m" -> R.raw.student_checkout_prompt
            "trainer_checkin_success" -> R.raw.trainer_checkin_success
            "student_checkin_success" -> R.raw.student_checkin_success
            "trainer_checkout_success" -> R.raw.trainer_checkout_success
            "student_checkout_success" -> R.raw.student_checkout_success
            else -> 0
        }
        if (directId != 0) return directId

        val idByNamespace = context.resources.getIdentifier(rawName, "raw", "com.example")
        if (idByNamespace != 0) return idByNamespace

        return context.resources.getIdentifier(rawName, "raw", context.packageName)
    }

    fun playAudioOrSpeak(
        context: Context,
        rawName: String?,
        fallbackText: String,
        voiceGender: String = "female"
    ) {
        stopAudio()
        val appContext = context.applicationContext

        if (!rawName.isNullOrEmpty()) {
            try {
                val resId = getRawResourceId(appContext, rawName)
                if (resId != 0) {
                    val afd = appContext.resources.openRawResourceFd(resId)
                    if (afd != null && afd.length > 100L) { // File must contain real audio data (> 100 bytes)
                        val mp = MediaPlayer().apply {
                            setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ALARM)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build()
                            )
                        }
                        mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                        afd.close()
                        mp.prepare()
                        mp.start()
                        mp.setOnCompletionListener {
                            it.release()
                            if (mediaPlayer == it) mediaPlayer = null
                        }
                        mediaPlayer = mp
                        return
                    } else {
                        afd?.close()
                    }
                }
            } catch (e: Exception) {
                Log.e("AudioPlayerHelper", "Failed to play raw audio resource: $rawName", e)
            }
        }

        // Fallback to Arabic TTS if raw audio file is absent or empty
        speakText(appContext, fallbackText, voiceGender)
    }

    fun speakText(context: Context, text: String, voiceGender: String = "female") {
        if (text.isBlank()) return
        stopAudio()

        val appContext = context.applicationContext
        Handler(Looper.getMainLooper()).post {
            if (tts == null) {
                tts = TextToSpeech(appContext) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        isTtsInitialized = true
                        tts?.language = Locale("ar")
                        pendingTextToSpeak?.let { (t, g) ->
                            performSpeak(t, g)
                            pendingTextToSpeak = null
                        }
                    }
                }
                pendingTextToSpeak = text to voiceGender
            } else if (isTtsInitialized) {
                performSpeak(text, voiceGender)
            } else {
                pendingTextToSpeak = text to voiceGender
            }
        }
    }

    private fun performSpeak(text: String, voiceGender: String) {
        try {
            tts?.language = Locale("ar")
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            tts?.setAudioAttributes(audioAttributes)

            if (tts?.voices != null) {
                val arVoices = tts?.voices?.filter { it.locale.language == "ar" } ?: emptyList()
                if (arVoices.isNotEmpty()) {
                    val selectedVoice = if (voiceGender == "male") {
                        arVoices.find { it.name.contains("male", ignoreCase = true) || it.name.contains("masculine", ignoreCase = true) } ?: arVoices.first()
                    } else {
                        arVoices.find { it.name.contains("female", ignoreCase = true) || it.name.contains("feminine", ignoreCase = true) } ?: arVoices.first()
                    }
                    tts?.voice = selectedVoice
                }
            }
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
                putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_ALARM)
            }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "DAWAMI_AUDIO_ALARM_${System.currentTimeMillis()}")
        } catch (e: Exception) {
            Log.e("AudioPlayerHelper", "TTS speak error", e)
        }
    }

    fun stopAudio() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            mediaPlayer = null
        }
        try {
            tts?.stop()
        } catch (e: Exception) {
            // Ignore
        }
    }
}
