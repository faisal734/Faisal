package com.example.data.dao

import androidx.room.*
import com.example.data.entity.AppActivityLog
import kotlinx.coroutines.flow.Flow

@Dao
interface AppActivityLogDao {
    @Query("SELECT * FROM app_activity_logs ORDER BY timestamp DESC, id DESC")
    fun getAllLogs(): Flow<List<AppActivityLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AppActivityLog): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(logs: List<AppActivityLog>)

    @Delete
    suspend fun deleteLog(log: AppActivityLog)

    @Query("DELETE FROM app_activity_logs")
    suspend fun deleteAllLogs()
}
