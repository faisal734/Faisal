package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.components.DawamiBottomNavigationBar
import com.example.ui.theme.DawamiNavy
import com.example.ui.viewmodel.AppAdminViewModel
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.GradingViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.StudentViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupRestoreScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    gradingViewModel: GradingViewModel? = null,
    adminViewModel: AppAdminViewModel? = null,
    showMainLayout: Boolean = true
) {
    val context = LocalContext.current
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val notifications by viewModel.inAppNotifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    // State counts for real-time impact analysis (21 items)
    val dbCourses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val dbStudents by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val dbSubjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()
    val dbCourseSubjects by viewModel.dbCourseSubjects.collectAsState()
    val dbTopics by (attendanceViewModel?.allLessonTopics ?: viewModel.dbLessonTopics).collectAsState()
    val dbStudentAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()
    val dbInstructorAttendance by (attendanceViewModel?.allAttendance ?: viewModel.dbAttendance).collectAsState()
    val dbGrades by (gradingViewModel?.allGrades ?: viewModel.dbAllGrades).collectAsState()
    val dbAssignments by (gradingViewModel?.allAssignmentTemplates ?: viewModel.dbAssignmentTemplates).collectAsState()
    val dbAssignmentSubmissions by (gradingViewModel?.allAssignmentSubmissions ?: viewModel.dbAssignmentSubmissions).collectAsState()
    val dbPrepSessions by (attendanceViewModel?.allLessonSessionTopics ?: viewModel.dbLessonSessionTopics).collectAsState()
    val dbTransactions by (adminViewModel?.allTrainerTransactions ?: viewModel.dbTrainerTransactions).collectAsState()
    val dbReferences by (courseViewModel?.allSubjectReferences ?: viewModel.dbSubjectReferences).collectAsState()
    val dbStudentViolations by (studentViewModel?.allViolations ?: viewModel.dbStudentViolations).collectAsState()
    val dbGradeConfigs by (gradingViewModel?.allGradeConfigs ?: viewModel.dbAllGradeConfigs).collectAsState()
    val dbDailyNotes by (attendanceViewModel?.allDailyNotes ?: viewModel.dbAllDailyNotes).collectAsState()
    val dbOfficialHolidays by viewModel.allOfficialHolidays.collectAsState()
    val dbActivityLogs by viewModel.dbActivityLogs.collectAsState()
    var showWipeDialog by remember { mutableStateOf(false) }
    var showCreateBackupDialog by remember { mutableStateOf(false) }
    var showSubfolderPickerModal by remember { mutableStateOf(false) }
    var exportBackupOptions by remember { mutableStateOf<MainViewModel.BackupOptions?>(null) }

    val dbManualAssignmentModesCount = remember(context, showCreateBackupDialog, showWipeDialog) { 
        viewModel.getManualAssignmentModesCount(context) 
    }

    val trainerBaseDirUri by viewModel.trainerBaseDirUri.collectAsState()
    val trainerBaseDirName by viewModel.trainerBaseDirName.collectAsState()

    val openRootFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                val folderName = getFolderFriendlyName(context, uri) ?: "مجلد Dawami الرئيسي"
                viewModel.saveTrainerBaseDir(uri.toString(), folderName)
                Toast.makeText(context, "تم تحديد وتهيئة مجلد Dawami والمجلدات الفرعية بنجاح! 📁", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                e.printStackTrace()
                val folderName = getFolderFriendlyName(context, uri) ?: "مجلد Dawami الرئيسي"
                viewModel.saveTrainerBaseDir(uri.toString(), folderName)
            }
        }
    }

    val coroutineScope = rememberCoroutineScope()

    val createBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val jsonString = viewModel.exportBackupAsJson(exportBackupOptions)
                    withContext(Dispatchers.Main) {
                        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                            outputStream.write(jsonString.toByteArray(Charsets.UTF_8))
                        }
                        viewModel.recordBackupSuccess()
                        Toast.makeText(context, "تم إنشاء النسخة الاحتياطية وتصديرها بنجاح! 💾", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "فشل تصدير الملف: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    var showRestoreConfirmDialog by remember { mutableStateOf(false) }
    var selectedBackupInfo by remember { mutableStateOf<BackupFileInfo?>(null) }

    val restoreBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                var fileName = "backup.json"
                var fileSize = 0L
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIndex != -1) fileName = cursor.getString(nameIndex) ?: "backup.json"
                        if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                    }
                }
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    val jsonString = inputStream.bufferedReader().readText()
                    selectedBackupInfo = parseBackupJsonInfo(fileName, fileSize, jsonString)
                    showRestoreConfirmDialog = true
                }
            } catch (e: Exception) {
                Toast.makeText(context, "خطأ في قراءة ملف الاستعادة: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    if (showMainLayout) {
        BackHandler {
            viewModel.navigateTo(Screen.Selection)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                if (showMainLayout) {
                    AppHeader(
                        title = "النسخ الاحتياطي وإدارة البيانات 💾🗑️",
                        username = "",
                        onHomeClick = { viewModel.navigateTo(Screen.Selection) },
                        isDark = isDarkTheme,
                        onToggleTheme = { viewModel.toggleTheme() },
                        unreadNotificationCount = unreadCount,
                        onNotificationClick = { viewModel.openNotificationCenter() }
                    )
                }
            },
            bottomBar = {
                if (showMainLayout) {
                    DawamiBottomNavigationBar(viewModel = viewModel)
                }
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Section 0: Dawami Folder Structure Initialization & Smart Routing
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = DawamiNavy)
                                Text(
                                    text = "إدارة مجلد Dwam والهيكلة التلقائية 📁",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = DawamiNavy
                                )
                            }

                            Text(
                                text = if (trainerBaseDirUri.isEmpty()) {
                                    "لم يتم تحديد المجلد الرئيسي بعد. اضغط أدناه لاختيار وتأكيد مجلد 'Dwam' لتنظيم النسخ الاحتياطية، المراجع، المرفقات، والتقارير تلقائياً."
                                } else {
                                    "المجلد الرئيسي الحالي: $trainerBaseDirName ✅\nتم التحقق من ربط المجلدات الفرعية (Backups, references, Assignments, Reports, Topics, projects) بنجاح."
                                },
                                fontSize = 11.5.sp,
                                color = if (trainerBaseDirUri.isEmpty()) Color.Gray else Color(0xFF16A34A),
                                lineHeight = 16.sp
                            )

                            // Subfolders status preview
                            val displayFolderName = if (trainerBaseDirName.isNotEmpty()) trainerBaseDirName else "Dwam"
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text("📁 $displayFolderName (المجلد الرئيسي)", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = DawamiNavy)
                                Text("  📂 Backups (ملفات النسخ الاحتياطي .json) ⭐", fontSize = 10.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                                Text("  📂 references (المراجع والكتب)", fontSize = 10.sp, color = Color.Gray)
                                Text("  📂 Assignments (مرفقات الواجبات والمشاريع)", fontSize = 10.sp, color = Color.Gray)
                                Text("  📂 Reports (تقارير Excel و PDF)", fontSize = 10.sp, color = Color.Gray)
                                Text("  📂 Topics (مواضيع المناهج)", fontSize = 10.sp, color = Color.Gray)
                                Text("  📂 projects (المشاريع والأنشطة)", fontSize = 10.sp, color = Color.Gray)
                            }

                            Button(
                                onClick = { openRootFolderLauncher.launch(null) },
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (trainerBaseDirUri.isEmpty()) "اختيار وتأكيد مجلد Dwam 📁" else "تغيير وإعادة تهيئة المجلد 🔄", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            }

                            if (trainerBaseDirUri.isNotEmpty()) {
                                Button(
                                    onClick = {
                                        showCreateBackupDialog = true
                                    },
                                    modifier = Modifier.fillMaxWidth().height(40.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("إنشاء ونسخ احتياطي مباشر لمجلد Backups ⚡", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                }
                            }
                        }
                    }
                }

                // Section 1: Backup & Restore
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.CloudSync, contentDescription = null, tint = DawamiNavy)
                                Text(
                                    text = "حفظ واسترجاع بيانات النظام 📦",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = DawamiNavy
                                )
                            }

                            Text(
                                text = "يمكنك إنشاء وتصدير كافة بيانات النظام الـ 21 (شاملة أو مخصصة) في ملف JSON معبر وتأمينها داخل مجلد Backups المخصص أو نقلها لجهاز آخر.",
                                fontSize = 11.5.sp,
                                color = Color.Gray
                            )

                            Button(
                                onClick = {
                                    showCreateBackupDialog = true
                                },
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إنشاء نسخة احتياطية وتصديرها (شاملة / مخصصة) 💾", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            }

                            Divider(modifier = Modifier.padding(vertical = 2.dp))

                            Button(
                                onClick = {
                                    if (trainerBaseDirUri.isNotEmpty()) {
                                        val subfolderFiles = viewModel.getBackupFilesFromSubfolder(context)
                                        if (subfolderFiles.isNotEmpty()) {
                                            showSubfolderPickerModal = true
                                        } else {
                                            restoreBackupLauncher.launch(arrayOf("application/json", "*/*"))
                                        }
                                    } else {
                                        restoreBackupLauncher.launch(arrayOf("application/json", "*/*"))
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("استعادة نسخة احتياطية من مجلد Backups / الجهاز 🔄", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            }
                        }
                    }
                }

                // Section 2: Unified Data Wipe & Selective Reset
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDarkTheme) Color(0xFF1E1B18) else Color(0xFFFEF2F2)
                        ),
                        border = BorderStroke(1.dp, Color(0xFFFECACA))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color(0xFFDC2626))
                                Text(
                                    text = "إدارة وتصفير بيانات النظام ⚠️🗑️",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = Color(0xFFDC2626)
                                )
                            }

                            Text(
                                text = "تتيح لك هذه الأداة مسح بيانات محددة من التطبيق (مسح كامل، مسح بدون التهيئة، أو مسح السجلات التشغيلية فقط) مع استعراض شامل للبيانات المتأثرة والتأكيد بكلمة السر.",
                                fontSize = 11.5.sp,
                                color = if (isDarkTheme) Color.LightGray else Color(0xFF7F1D1D),
                                lineHeight = 16.sp
                            )

                            Button(
                                onClick = { showWipeDialog = true },
                                modifier = Modifier.fillMaxWidth().height(44.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تحديد ومسح بيانات النظام ⚙️🗑️", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(48.dp))
                }
            }
        }

        if (showSubfolderPickerModal) {
            val backupFiles = viewModel.getBackupFilesFromSubfolder(context)
            SelectBackupFromSubfolderDialog(
                backupFiles = backupFiles,
                onSelectFile = { subfile ->
                    showSubfolderPickerModal = false
                    try {
                        context.contentResolver.openInputStream(subfile.uri)?.use { inputStream ->
                            val jsonString = inputStream.bufferedReader().readText()
                            selectedBackupInfo = parseBackupJsonInfo(subfile.name, subfile.size, jsonString)
                            showRestoreConfirmDialog = true
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "خطأ في قراءة ملف النسخة: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                },
                onBrowseExternal = {
                    showSubfolderPickerModal = false
                    restoreBackupLauncher.launch(arrayOf("application/json", "*/*"))
                },
                onDismiss = { showSubfolderPickerModal = false },
                isDarkTheme = isDarkTheme
            )
        }

        if (showCreateBackupDialog) {
            CreateBackupDialog(
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                coursesCount = dbCourses.size,
                subjectsCount = dbSubjects.size,
                courseSubjectsCount = dbCourseSubjects.size,
                studentsCount = dbStudents.size,
                studentViolationsCount = dbStudentViolations.size,
                attendanceCount = dbInstructorAttendance.size,
                studentAttendanceCount = dbStudentAttendance.size,
                lessonTopicsCount = dbTopics.size,
                lessonSessionTopicsCount = dbPrepSessions.size,
                dailyNotesCount = dbDailyNotes.size,
                gradeConfigsCount = dbGradeConfigs.size,
                studentGradesCount = dbGrades.size,
                assignmentTemplatesCount = dbAssignments.size,
                assignmentSubmissionsCount = dbAssignmentSubmissions.size,
                manualAssignmentModesCount = dbManualAssignmentModesCount,
                trainerTransactionsCount = dbTransactions.size,
                activityLogsCount = dbActivityLogs.size,
                subjectReferencesCount = dbReferences.size,
                officialHolidaysCount = dbOfficialHolidays.size,
                funnyPenaltiesCount = com.example.ui.components.FunnyPenaltyHelper.getPenalties(context).size,
                onDismiss = { showCreateBackupDialog = false },
                onExportWithLauncher = { options, suggestedFileName ->
                    exportBackupOptions = options
                    createBackupLauncher.launch(suggestedFileName)
                },
                onExportToSubfolder = { options, fileName ->
                    coroutineScope.launch(Dispatchers.IO) {
                        val success = viewModel.createBackupInSubfolder(context, options, fileName)
                        withContext(Dispatchers.Main) {
                            if (success) {
                                Toast.makeText(context, "تم حفظ النسخة الاحتياطية ($fileName) تلقائياً في مجلد Backups بنجاح! 💾⚡", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "فشل الحفظ التلقائي في المجلد، يرجى محاولة التصدير لملف خارجي", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            )
        }

        if (showWipeDialog) {
            SelectiveDataWipeDialog(
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                coursesCount = dbCourses.size,
                subjectsCount = dbSubjects.size,
                courseSubjectsCount = dbCourseSubjects.size,
                studentsCount = dbStudents.size,
                studentViolationsCount = dbStudentViolations.size,
                attendanceCount = dbInstructorAttendance.size,
                studentAttendanceCount = dbStudentAttendance.size,
                lessonTopicsCount = dbTopics.size,
                lessonSessionTopicsCount = dbPrepSessions.size,
                dailyNotesCount = dbDailyNotes.size,
                gradeConfigsCount = dbGradeConfigs.size,
                studentGradesCount = dbGrades.size,
                assignmentTemplatesCount = dbAssignments.size,
                assignmentSubmissionsCount = dbAssignmentSubmissions.size,
                manualAssignmentModesCount = dbManualAssignmentModesCount,
                transactionsCount = dbTransactions.size,
                activityLogsCount = dbActivityLogs.size,
                subjectReferencesCount = dbReferences.size,
                officialHolidaysCount = dbOfficialHolidays.size,
                funnyPenaltiesCount = com.example.ui.components.FunnyPenaltyHelper.getPenalties(context).size,
                onDismiss = { showWipeDialog = false }
            )
        }

        if (showRestoreConfirmDialog && selectedBackupInfo != null) {
            RestoreConfirmationDialog(
                backupInfo = selectedBackupInfo!!,
                isDarkTheme = isDarkTheme,
                onDismiss = { showRestoreConfirmDialog = false },
                onFullRestore = {
                    showRestoreConfirmDialog = false
                    viewModel.restoreBackupFromJson(selectedBackupInfo!!.rawJsonString) { success ->
                        if (success) {
                            Toast.makeText(context, "تم استعادة النسخة الاحتياطية وتحديث النظام بنجاح! 🔄⚡", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "فشلت استعادة البيانات من الملف ❌", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                onSelectiveRestore = { options ->
                    showRestoreConfirmDialog = false
                    viewModel.restoreBackupFromJson(selectedBackupInfo!!.rawJsonString, options) { success ->
                        if (success) {
                            Toast.makeText(context, "تم استعادة البيانات المحددة بنجاح! 🔄⚡", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "فشلت استعادة البيانات من الملف ❌", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }
    }
}

data class BackupFileInfo(
    val fileName: String,
    val fileSize: Long,
    val timestamp: Long,
    val version: Int,
    val coursesCount: Int = 0,
    val subjectsCount: Int = 0,
    val courseSubjectsCount: Int = 0,
    val studentsCount: Int = 0,
    val studentViolationsCount: Int = 0,
    val attendanceCount: Int = 0,
    val studentAttendanceCount: Int = 0,
    val lessonTopicsCount: Int = 0,
    val lessonSessionTopicsCount: Int = 0,
    val dailyNotesCount: Int = 0,
    val gradeConfigsCount: Int = 0,
    val studentGradesCount: Int = 0,
    val assignmentTemplatesCount: Int = 0,
    val assignmentSubmissionsCount: Int = 0,
    val trainerTransactionsCount: Int = 0,
    val activityLogsCount: Int = 0,
    val subjectReferencesCount: Int = 0,
    val officialHolidaysCount: Int = 0,
    val hasSettings: Boolean = false,
    val funnyPenaltiesCount: Int = 0,
    val manualAssignmentModesCount: Int = 0,
    val rawJsonString: String
) {
    val totalRecordsCount: Int get() =
        coursesCount + subjectsCount + courseSubjectsCount + studentsCount + studentViolationsCount +
        attendanceCount + studentAttendanceCount + lessonTopicsCount + lessonSessionTopicsCount + dailyNotesCount +
        gradeConfigsCount + studentGradesCount + assignmentTemplatesCount + assignmentSubmissionsCount +
        trainerTransactionsCount + activityLogsCount + subjectReferencesCount + officialHolidaysCount +
        (if (hasSettings) 12 else 0) + funnyPenaltiesCount + manualAssignmentModesCount
}

fun parseBackupJsonInfo(fileName: String, fileSize: Long, jsonString: String): BackupFileInfo {
    val root = org.json.JSONObject(jsonString)
    val version = root.optInt("backup_version", 0)
    val timestamp = root.optLong("timestamp", System.currentTimeMillis())

    val coursesCount = root.optJSONArray("courses")?.length() ?: 0
    val subjectsCount = root.optJSONArray("subjects")?.length() ?: 0
    val courseSubjectsCount = root.optJSONArray("course_subjects")?.length() ?: 0
    val studentsCount = root.optJSONArray("students")?.length() ?: 0
    val studentViolationsCount = root.optJSONArray("student_violations")?.length() ?: 0
    val attendanceCount = root.optJSONArray("attendance")?.length() ?: 0
    val studentAttendanceCount = root.optJSONArray("student_attendance")?.length() ?: 0
    val lessonTopicsCount = root.optJSONArray("lesson_topics")?.length() ?: 0
    val lessonSessionTopicsCount = root.optJSONArray("lesson_session_topics")?.length() ?: 0
    val dailyNotesCount = root.optJSONArray("daily_notes")?.length() ?: 0
    val gradeConfigsCount = root.optJSONArray("grade_configs")?.length() ?: 0
    val studentGradesCount = root.optJSONArray("student_grades")?.length() ?: 0
    val assignmentTemplatesCount = root.optJSONArray("assignment_templates")?.length() ?: 0
    val assignmentSubmissionsCount = root.optJSONArray("assignment_submissions")?.length() ?: 0
    val trainerTransactionsCount = root.optJSONArray("trainer_transactions")?.length() ?: 0
    val activityLogsCount = root.optJSONArray("activity_logs")?.length() ?: 0
    val subjectReferencesCount = root.optJSONArray("subject_references")?.length() ?: 0
    val officialHolidaysCount = root.optJSONArray("official_holidays")?.length() ?: 0
    val funnyPenaltiesCount = root.optJSONArray("funny_penalties")?.length() ?: 0
    val manualAssignmentModesCount = root.optJSONObject("manual_assignment_modes")?.length() ?: (root.optJSONArray("manual_assignment_modes")?.length() ?: 0)
    val hasSettings = root.has("settings")

    return BackupFileInfo(
        fileName = fileName,
        fileSize = if (fileSize > 0) fileSize else jsonString.length.toLong(),
        timestamp = timestamp,
        version = version,
        coursesCount = coursesCount,
        subjectsCount = subjectsCount,
        courseSubjectsCount = courseSubjectsCount,
        studentsCount = studentsCount,
        studentViolationsCount = studentViolationsCount,
        attendanceCount = attendanceCount,
        studentAttendanceCount = studentAttendanceCount,
        lessonTopicsCount = lessonTopicsCount,
        lessonSessionTopicsCount = lessonSessionTopicsCount,
        dailyNotesCount = dailyNotesCount,
        gradeConfigsCount = gradeConfigsCount,
        studentGradesCount = studentGradesCount,
        assignmentTemplatesCount = assignmentTemplatesCount,
        assignmentSubmissionsCount = assignmentSubmissionsCount,
        trainerTransactionsCount = trainerTransactionsCount,
        activityLogsCount = activityLogsCount,
        subjectReferencesCount = subjectReferencesCount,
        officialHolidaysCount = officialHolidaysCount,
        hasSettings = hasSettings,
        funnyPenaltiesCount = funnyPenaltiesCount,
        manualAssignmentModesCount = manualAssignmentModesCount,
        rawJsonString = jsonString
    )
}

@Composable
private fun SelectBackupFromSubfolderDialog(
    backupFiles: List<MainViewModel.SubfolderBackupFile>,
    onSelectFile: (MainViewModel.SubfolderBackupFile) -> Unit,
    onBrowseExternal: () -> Unit,
    onDismiss: () -> Unit,
    isDarkTheme: Boolean
) {
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale("ar")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.FolderZip,
                    contentDescription = null,
                    tint = DawamiNavy,
                    modifier = Modifier.size(24.dp)
                )
                Column {
                    Text(
                        text = "اختر نسخة من مجلد Backups المخصص 📂",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp,
                        color = if (isDarkTheme) Color.White else DawamiNavy
                    )
                    Text(
                        text = "عُثر على (${backupFiles.size}) نسخة احتياطية محفوظة داخل المجلد",
                        fontSize = 10.5.sp,
                        color = Color.Gray
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                backupFiles.forEach { file ->
                    val formattedDate = try { dateFormat.format(Date(file.lastModified)) } catch (e: Exception) { "" }
                    val kb = file.size / 1024.0
                    val formattedSize = if (kb > 1024) String.format(Locale.US, "%.2f MB", kb / 1024.0) else String.format(Locale.US, "%.1f KB", kb)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectFile(file) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(22.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = file.name,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) Color.White else DawamiNavy,
                                    maxLines = 1
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("📅 $formattedDate", fontSize = 9.5.sp, color = Color.Gray)
                                    Text("📦 $formattedSize", fontSize = 9.5.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                                }
                            }
                            Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = Color.Gray)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onDismiss()
                    onBrowseExternal()
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("تصفح واختيار ملف آخر من الجهاز 📥", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء ✖️", fontSize = 11.5.sp, color = Color.Gray)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun RestoreConfirmationDialog(
    backupInfo: BackupFileInfo,
    isDarkTheme: Boolean,
    onDismiss: () -> Unit,
    onFullRestore: () -> Unit,
    onSelectiveRestore: (MainViewModel.RestoreOptions) -> Unit
) {
    var isLimitedMode by remember { mutableStateOf(false) }

    // 21 Restore Checkbox States
    var restoreCourses by remember { mutableStateOf(true) }
    var restoreSubjects by remember { mutableStateOf(true) }
    var restoreCourseSubjects by remember { mutableStateOf(true) }
    var restoreStudents by remember { mutableStateOf(true) }
    var restoreStudentViolations by remember { mutableStateOf(true) }
    var restoreAttendance by remember { mutableStateOf(true) }
    var restoreStudentAttendance by remember { mutableStateOf(true) }
    var restoreLessonTopics by remember { mutableStateOf(true) }
    var restoreLessonSessionTopics by remember { mutableStateOf(true) }
    var restoreDailyNotes by remember { mutableStateOf(true) }
    var restoreGradeConfigs by remember { mutableStateOf(true) }
    var restoreStudentGrades by remember { mutableStateOf(true) }
    var restoreAssignmentTemplates by remember { mutableStateOf(true) }
    var restoreAssignmentSubmissions by remember { mutableStateOf(true) }
    var restoreManualAssignmentModes by remember { mutableStateOf(true) }
    var restoreTrainerTransactions by remember { mutableStateOf(true) }
    var restoreActivityLogs by remember { mutableStateOf(true) }
    var restoreSubjectReferences by remember { mutableStateOf(true) }
    var restoreOfficialHolidays by remember { mutableStateOf(true) }
    var restoreFunnyPenalties by remember { mutableStateOf(true) }
    var restoreSettings by remember { mutableStateOf(true) }

    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd - HH:mm:ss", Locale("ar")) }
    val formattedDate = remember(backupInfo.timestamp) {
        try { dateFormat.format(Date(backupInfo.timestamp)) } catch (e: Exception) { "تاريخ غير معروف" }
    }
    val formattedSize = remember(backupInfo.fileSize) {
        val kb = backupInfo.fileSize / 1024.0
        if (kb > 1024) String.format(Locale.US, "%.2f MB", kb / 1024.0)
        else String.format(Locale.US, "%.1f KB", kb)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(
                    imageVector = Icons.Default.Restore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(26.dp)
                )
                Column {
                    Text(
                        text = "تأكيد استعادة النسخة الاحتياطية",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDarkTheme) Color.White else DawamiNavy
                    )
                    Text(
                        text = backupInfo.fileName,
                        fontSize = 10.5.sp,
                        color = Color.Gray
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "📅 تاريخ النسخة: $formattedDate", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = "📦 حجم الملف: $formattedSize", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = "🔖 رقم الإصدار: v${backupInfo.version}", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                // Mode Toggle Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = { isLimitedMode = false },
                        modifier = Modifier.weight(1f).height(38.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isLimitedMode) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.2f),
                            contentColor = if (!isLimitedMode) Color.White else Color.Gray
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = "استعادة كلية 🔄", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { isLimitedMode = true },
                        modifier = Modifier.weight(1f).height(38.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isLimitedMode) DawamiNavy else Color.Gray.copy(alpha = 0.2f),
                            contentColor = if (isLimitedMode) Color.White else Color.Gray
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = "استعادة محدودة ⚙️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Text(
                    text = if (!isLimitedMode) "📊 محتويات النسخة الشاملة (21 قطاعاً كاملاً):" else "اختر البيانات المراد استعادتها بالتفصيل (21 قطاعاً):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                // Render all 21 Items using the Unified Details List
                Unified21BackupDetailsList(
                    isCustomMode = isLimitedMode,
                    isDarkTheme = isDarkTheme,
                    coursesCount = backupInfo.coursesCount,
                    subjectsCount = backupInfo.subjectsCount,
                    courseSubjectsCount = backupInfo.courseSubjectsCount,
                    studentsCount = backupInfo.studentsCount,
                    studentViolationsCount = backupInfo.studentViolationsCount,
                    attendanceCount = backupInfo.attendanceCount,
                    studentAttendanceCount = backupInfo.studentAttendanceCount,
                    lessonTopicsCount = backupInfo.lessonTopicsCount,
                    lessonSessionTopicsCount = backupInfo.lessonSessionTopicsCount,
                    dailyNotesCount = backupInfo.dailyNotesCount,
                    gradeConfigsCount = backupInfo.gradeConfigsCount,
                    studentGradesCount = backupInfo.studentGradesCount,
                    assignmentTemplatesCount = backupInfo.assignmentTemplatesCount,
                    assignmentSubmissionsCount = backupInfo.assignmentSubmissionsCount,
                    manualModesCount = backupInfo.manualAssignmentModesCount,
                    trainerTransactionsCount = backupInfo.trainerTransactionsCount,
                    activityLogsCount = backupInfo.activityLogsCount,
                    subjectReferencesCount = backupInfo.subjectReferencesCount,
                    officialHolidaysCount = backupInfo.officialHolidaysCount,
                    funnyPenaltiesCount = backupInfo.funnyPenaltiesCount,
                    settingsCount = if (backupInfo.hasSettings) 12 else 0,
                    // Checkbox states & setters
                    restoreCourses = restoreCourses, onToggleCourses = { restoreCourses = it },
                    restoreSubjects = restoreSubjects, onToggleSubjects = { restoreSubjects = it },
                    restoreCourseSubjects = restoreCourseSubjects, onToggleCourseSubjects = { restoreCourseSubjects = it },
                    restoreStudents = restoreStudents, onToggleStudents = { restoreStudents = it },
                    restoreStudentViolations = restoreStudentViolations, onToggleStudentViolations = { restoreStudentViolations = it },
                    restoreAttendance = restoreAttendance, onToggleAttendance = { restoreAttendance = it },
                    restoreStudentAttendance = restoreStudentAttendance, onToggleStudentAttendance = { restoreStudentAttendance = it },
                    restoreLessonTopics = restoreLessonTopics, onToggleLessonTopics = { restoreLessonTopics = it },
                    restoreLessonSessionTopics = restoreLessonSessionTopics, onToggleLessonSessionTopics = { restoreLessonSessionTopics = it },
                    restoreDailyNotes = restoreDailyNotes, onToggleDailyNotes = { restoreDailyNotes = it },
                    restoreGradeConfigs = restoreGradeConfigs, onToggleGradeConfigs = { restoreGradeConfigs = it },
                    restoreStudentGrades = restoreStudentGrades, onToggleStudentGrades = { restoreStudentGrades = it },
                    restoreAssignmentTemplates = restoreAssignmentTemplates, onToggleAssignmentTemplates = { restoreAssignmentTemplates = it },
                    restoreAssignmentSubmissions = restoreAssignmentSubmissions, onToggleAssignmentSubmissions = { restoreAssignmentSubmissions = it },
                    restoreManualModes = restoreManualAssignmentModes, onToggleManualModes = { restoreManualAssignmentModes = it },
                    restoreTrainerTransactions = restoreTrainerTransactions, onToggleTrainerTransactions = { restoreTrainerTransactions = it },
                    restoreActivityLogs = restoreActivityLogs, onToggleActivityLogs = { restoreActivityLogs = it },
                    restoreSubjectReferences = restoreSubjectReferences, onToggleSubjectReferences = { restoreSubjectReferences = it },
                    restoreOfficialHolidays = restoreOfficialHolidays, onToggleOfficialHolidays = { restoreOfficialHolidays = it },
                    restoreFunnyPenalties = restoreFunnyPenalties, onToggleFunnyPenalties = { restoreFunnyPenalties = it },
                    restoreSettings = restoreSettings, onToggleSettings = { restoreSettings = it }
                )

                if (!isLimitedMode) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                        border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تنبيه: الاستعادة الكلية ستستعيد كافة البيانات والملفات وسجلات النظام (${backupInfo.totalRecordsCount} سجل) وتحديث النظام بالكامل.",
                                fontSize = 10.5.sp,
                                color = Color(0xFFB45309),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isLimitedMode) {
                        onSelectiveRestore(
                            MainViewModel.RestoreOptions(
                                restoreCourses = restoreCourses,
                                restoreSubjects = restoreSubjects,
                                restoreCourseSubjects = restoreCourseSubjects,
                                restoreStudents = restoreStudents,
                                restoreAttendance = restoreAttendance,
                                restoreStudentAttendance = restoreStudentAttendance,
                                restoreDailyNotes = restoreDailyNotes,
                                restoreLessonTopics = restoreLessonTopics,
                                restoreLessonSessionTopics = restoreLessonSessionTopics,
                                restoreGradeConfigs = restoreGradeConfigs,
                                restoreGrades = restoreStudentGrades,
                                restoreAssignmentTemplates = restoreAssignmentTemplates,
                                restoreAssignmentSubmissions = restoreAssignmentSubmissions,
                                restoreTrainerTransactions = restoreTrainerTransactions,
                                restoreSubjectReferences = restoreSubjectReferences,
                                restoreActivityLogs = restoreActivityLogs,
                                restoreStudentViolations = restoreStudentViolations,
                                restoreOfficialHolidays = restoreOfficialHolidays,
                                restoreSettings = restoreSettings,
                                restoreFunnyPenalties = restoreFunnyPenalties,
                                restoreManualAssignmentModes = restoreManualAssignmentModes
                            )
                        )
                    } else {
                        onFullRestore()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(42.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.RestorePage, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isLimitedMode) "بدء الاستعادة المحدودة ⚙️" else "بدء الاستعادة الكلية الشاملة 🔄",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "إلغاء ✖️", fontSize = 11.5.sp, color = Color.Gray)
            }
        },
        shape = RoundedCornerShape(16.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )
}

@Composable
private fun CreateBackupDialog(
    viewModel: MainViewModel,
    isDarkTheme: Boolean,
    coursesCount: Int,
    subjectsCount: Int,
    courseSubjectsCount: Int,
    studentsCount: Int,
    studentViolationsCount: Int,
    attendanceCount: Int,
    studentAttendanceCount: Int,
    lessonTopicsCount: Int,
    lessonSessionTopicsCount: Int,
    dailyNotesCount: Int,
    gradeConfigsCount: Int,
    studentGradesCount: Int,
    assignmentTemplatesCount: Int,
    assignmentSubmissionsCount: Int,
    manualAssignmentModesCount: Int,
    trainerTransactionsCount: Int,
    activityLogsCount: Int,
    subjectReferencesCount: Int,
    officialHolidaysCount: Int,
    funnyPenaltiesCount: Int,
    onDismiss: () -> Unit,
    onExportWithLauncher: (MainViewModel.BackupOptions?, String) -> Unit,
    onExportToSubfolder: (MainViewModel.BackupOptions?, String) -> Unit
) {
    var isCustomMode by remember { mutableStateOf(false) }

    // 21 Creation Checkbox States
    var includeCourses by remember { mutableStateOf(true) }
    var includeSubjects by remember { mutableStateOf(true) }
    var includeCourseSubjects by remember { mutableStateOf(true) }
    var includeStudents by remember { mutableStateOf(true) }
    var includeStudentViolations by remember { mutableStateOf(true) }
    var includeAttendance by remember { mutableStateOf(true) }
    var includeStudentAttendance by remember { mutableStateOf(true) }
    var includeLessonTopics by remember { mutableStateOf(true) }
    var includeLessonSessionTopics by remember { mutableStateOf(true) }
    var includeDailyNotes by remember { mutableStateOf(true) }
    var includeGradeConfigs by remember { mutableStateOf(true) }
    var includeStudentGrades by remember { mutableStateOf(true) }
    var includeAssignmentTemplates by remember { mutableStateOf(true) }
    var includeAssignmentSubmissions by remember { mutableStateOf(true) }
    var includeManualAssignmentModes by remember { mutableStateOf(true) }
    var includeTrainerTransactions by remember { mutableStateOf(true) }
    var includeActivityLogs by remember { mutableStateOf(true) }
    var includeSubjectReferences by remember { mutableStateOf(true) }
    var includeOfficialHolidays by remember { mutableStateOf(true) }
    var includeFunnyPenalties by remember { mutableStateOf(true) }
    var includeSettings by remember { mutableStateOf(true) }

    val options = remember(
        isCustomMode, includeCourses, includeSubjects, includeCourseSubjects, includeStudents, includeStudentViolations,
        includeAttendance, includeStudentAttendance, includeLessonTopics, includeLessonSessionTopics, includeDailyNotes,
        includeGradeConfigs, includeStudentGrades, includeAssignmentTemplates, includeAssignmentSubmissions, includeManualAssignmentModes,
        includeTrainerTransactions, includeActivityLogs, includeSubjectReferences, includeOfficialHolidays, includeFunnyPenalties, includeSettings
    ) {
        if (!isCustomMode) null
        else MainViewModel.BackupOptions(
            includeCourses = includeCourses,
            includeSubjects = includeSubjects,
            includeCourseSubjects = includeCourseSubjects,
            includeStudents = includeStudents,
            includeStudentViolations = includeStudentViolations,
            includeAttendance = includeAttendance,
            includeStudentAttendance = includeStudentAttendance,
            includeLessonTopics = includeLessonTopics,
            includeLessonSessionTopics = includeLessonSessionTopics,
            includeDailyNotes = includeDailyNotes,
            includeGradeConfigs = includeGradeConfigs,
            includeStudentGrades = includeStudentGrades,
            includeAssignmentTemplates = includeAssignmentTemplates,
            includeAssignmentSubmissions = includeAssignmentSubmissions,
            includeManualAssignmentModes = includeManualAssignmentModes,
            includeTrainerTransactions = includeTrainerTransactions,
            includeActivityLogs = includeActivityLogs,
            includeSubjectReferences = includeSubjectReferences,
            includeOfficialHolidays = includeOfficialHolidays,
            includeFunnyPenalties = includeFunnyPenalties,
            includeSettings = includeSettings
        )
    }

    val defaultFileName = remember(options, isCustomMode) {
        viewModel.generateBackupFileName(options, !isCustomMode)
    }

    var customFileNameText by remember(defaultFileName) { mutableStateOf(defaultFileName) }
    val trainerBaseDirUri by viewModel.trainerBaseDirUri.collectAsState()

    val totalSelectedRecords = remember(
        isCustomMode, includeCourses, includeSubjects, includeCourseSubjects, includeStudents, includeStudentViolations,
        includeAttendance, includeStudentAttendance, includeLessonTopics, includeLessonSessionTopics, includeDailyNotes,
        includeGradeConfigs, includeStudentGrades, includeAssignmentTemplates, includeAssignmentSubmissions, includeManualAssignmentModes,
        includeTrainerTransactions, includeActivityLogs, includeSubjectReferences, includeOfficialHolidays, includeFunnyPenalties, includeSettings,
        coursesCount, subjectsCount, courseSubjectsCount, studentsCount, studentViolationsCount,
        attendanceCount, studentAttendanceCount, lessonTopicsCount, lessonSessionTopicsCount, dailyNotesCount,
        gradeConfigsCount, studentGradesCount, assignmentTemplatesCount, assignmentSubmissionsCount, manualAssignmentModesCount,
        trainerTransactionsCount, activityLogsCount, subjectReferencesCount, officialHolidaysCount, funnyPenaltiesCount
    ) {
        if (!isCustomMode) {
            coursesCount + subjectsCount + courseSubjectsCount + studentsCount + studentViolationsCount +
            attendanceCount + studentAttendanceCount + lessonTopicsCount + lessonSessionTopicsCount + dailyNotesCount +
            gradeConfigsCount + studentGradesCount + assignmentTemplatesCount + assignmentSubmissionsCount + manualAssignmentModesCount +
            trainerTransactionsCount + activityLogsCount + subjectReferencesCount + officialHolidaysCount + funnyPenaltiesCount + 12
        } else {
            var count = 0
            if (includeCourses) count += coursesCount
            if (includeSubjects) count += subjectsCount
            if (includeCourseSubjects) count += courseSubjectsCount
            if (includeStudents) count += studentsCount
            if (includeStudentViolations) count += studentViolationsCount
            if (includeAttendance) count += attendanceCount
            if (includeStudentAttendance) count += studentAttendanceCount
            if (includeLessonTopics) count += lessonTopicsCount
            if (includeLessonSessionTopics) count += lessonSessionTopicsCount
            if (includeDailyNotes) count += dailyNotesCount
            if (includeGradeConfigs) count += gradeConfigsCount
            if (includeStudentGrades) count += studentGradesCount
            if (includeAssignmentTemplates) count += assignmentTemplatesCount
            if (includeAssignmentSubmissions) count += assignmentSubmissionsCount
            if (includeManualAssignmentModes) count += manualAssignmentModesCount
            if (includeTrainerTransactions) count += trainerTransactionsCount
            if (includeActivityLogs) count += activityLogsCount
            if (includeSubjectReferences) count += subjectReferencesCount
            if (includeOfficialHolidays) count += officialHolidaysCount
            if (includeFunnyPenalties) count += funnyPenaltiesCount
            if (includeSettings) count += 12
            count
        }
    }

    val estimatedSizeKb = remember(totalSelectedRecords) {
        val size = (totalSelectedRecords * 0.18).coerceAtLeast(1.2)
        if (size > 1024) String.format(Locale.US, "%.2f MB", size / 1024.0)
        else String.format(Locale.US, "%.1f KB", size)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CloudUpload,
                    contentDescription = null,
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(26.dp)
                )
                Column {
                    Text(
                        text = "خيارات النسخ الاحتياطي الذكي 💾",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = if (isDarkTheme) Color.White else DawamiNavy
                    )
                    Text(
                        text = "اختر نوع النسخة ومعاينة إحصائيات الـ 21 قطاعاً",
                        fontSize = 10.5.sp,
                        color = Color.Gray
                    )
                }
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "اختر نوع النسخة الاحتياطية المراد إنشاؤها:",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDarkTheme) Color.White else DawamiNavy
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = { isCustomMode = false },
                                    modifier = Modifier.weight(1f).height(38.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (!isCustomMode) Color(0xFF10B981) else Color.Gray.copy(alpha = 0.2f),
                                        contentColor = if (!isCustomMode) Color.White else Color.Gray
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("نسخة شاملة (كاملة) 📦", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { isCustomMode = true },
                                    modifier = Modifier.weight(1f).height(38.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isCustomMode) DawamiNavy else Color.Gray.copy(alpha = 0.2f),
                                        contentColor = if (isCustomMode) Color.White else Color.Gray
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("نسخة مخصصة ⚙️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = if (!isCustomMode) "📊 إحصائيات النسخة الشاملة (21 قطاعاً بالكامل):" else "حدد القطاعات المراد تضمينها في النسخة الاحتياطية (21 قطاعاً):",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDarkTheme) Color.White else DawamiNavy
                    )
                }

                item {
                    Unified21BackupDetailsList(
                        isCustomMode = isCustomMode,
                        isDarkTheme = isDarkTheme,
                        coursesCount = coursesCount,
                        subjectsCount = subjectsCount,
                        courseSubjectsCount = courseSubjectsCount,
                        studentsCount = studentsCount,
                        studentViolationsCount = studentViolationsCount,
                        attendanceCount = attendanceCount,
                        studentAttendanceCount = studentAttendanceCount,
                        lessonTopicsCount = lessonTopicsCount,
                        lessonSessionTopicsCount = lessonSessionTopicsCount,
                        dailyNotesCount = dailyNotesCount,
                        gradeConfigsCount = gradeConfigsCount,
                        studentGradesCount = studentGradesCount,
                        assignmentTemplatesCount = assignmentTemplatesCount,
                        assignmentSubmissionsCount = assignmentSubmissionsCount,
                        manualModesCount = manualAssignmentModesCount,
                        trainerTransactionsCount = trainerTransactionsCount,
                        activityLogsCount = activityLogsCount,
                        subjectReferencesCount = subjectReferencesCount,
                        officialHolidaysCount = officialHolidaysCount,
                        funnyPenaltiesCount = funnyPenaltiesCount,
                        settingsCount = 12,
                        // Checkbox states & setters
                        restoreCourses = includeCourses, onToggleCourses = { includeCourses = it },
                        restoreSubjects = includeSubjects, onToggleSubjects = { includeSubjects = it },
                        restoreCourseSubjects = includeCourseSubjects, onToggleCourseSubjects = { includeCourseSubjects = it },
                        restoreStudents = includeStudents, onToggleStudents = { includeStudents = it },
                        restoreStudentViolations = includeStudentViolations, onToggleStudentViolations = { includeStudentViolations = it },
                        restoreAttendance = includeAttendance, onToggleAttendance = { includeAttendance = it },
                        restoreStudentAttendance = includeStudentAttendance, onToggleStudentAttendance = { includeStudentAttendance = it },
                        restoreLessonTopics = includeLessonTopics, onToggleLessonTopics = { includeLessonTopics = it },
                        restoreLessonSessionTopics = includeLessonSessionTopics, onToggleLessonSessionTopics = { includeLessonSessionTopics = it },
                        restoreDailyNotes = includeDailyNotes, onToggleDailyNotes = { includeDailyNotes = it },
                        restoreGradeConfigs = includeGradeConfigs, onToggleGradeConfigs = { includeGradeConfigs = it },
                        restoreStudentGrades = includeStudentGrades, onToggleStudentGrades = { includeStudentGrades = it },
                        restoreAssignmentTemplates = includeAssignmentTemplates, onToggleAssignmentTemplates = { includeAssignmentTemplates = it },
                        restoreAssignmentSubmissions = includeAssignmentSubmissions, onToggleAssignmentSubmissions = { includeAssignmentSubmissions = it },
                        restoreManualModes = includeManualAssignmentModes, onToggleManualModes = { includeManualAssignmentModes = it },
                        restoreTrainerTransactions = includeTrainerTransactions, onToggleTrainerTransactions = { includeTrainerTransactions = it },
                        restoreActivityLogs = includeActivityLogs, onToggleActivityLogs = { includeActivityLogs = it },
                        restoreSubjectReferences = includeSubjectReferences, onToggleSubjectReferences = { includeSubjectReferences = it },
                        restoreOfficialHolidays = includeOfficialHolidays, onToggleOfficialHolidays = { includeOfficialHolidays = it },
                        restoreFunnyPenalties = includeFunnyPenalties, onToggleFunnyPenalties = { includeFunnyPenalties = it },
                        restoreSettings = includeSettings, onToggleSettings = { includeSettings = it }
                    )
                }

                item { Divider() }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "🏷️ اسم ملف النسخة الاحتياطية:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDarkTheme) Color.White else DawamiNavy
                        )
                        OutlinedTextField(
                            value = customFileNameText,
                            onValueChange = { customFileNameText = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }

                item {
                    Surface(
                        color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📊 المحدد للتصدير: $totalSelectedRecords سجل",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy
                            )
                            Text(
                                text = "الحجم التقديري: $estimatedSizeKb",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF10B981)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (trainerBaseDirUri.isNotEmpty()) {
                    Button(
                        onClick = {
                            onExportToSubfolder(options, customFileNameText)
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ تلقائي داخل مجلد Backups ⚡", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = {
                        onExportWithLauncher(options, customFileNameText)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ وتصدير لملف خارجي (تحديد المسار) 📥", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء ✖️", fontSize = 11.5.sp, color = Color.Gray)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun Unified21BackupDetailsList(
    isCustomMode: Boolean,
    isDarkTheme: Boolean,
    coursesCount: Int,
    subjectsCount: Int,
    courseSubjectsCount: Int,
    studentsCount: Int,
    studentViolationsCount: Int,
    attendanceCount: Int,
    studentAttendanceCount: Int,
    lessonTopicsCount: Int,
    lessonSessionTopicsCount: Int,
    dailyNotesCount: Int,
    gradeConfigsCount: Int,
    studentGradesCount: Int,
    assignmentTemplatesCount: Int,
    assignmentSubmissionsCount: Int,
    manualModesCount: Int,
    trainerTransactionsCount: Int,
    activityLogsCount: Int,
    subjectReferencesCount: Int,
    officialHolidaysCount: Int,
    funnyPenaltiesCount: Int,
    settingsCount: Int,
    // Toggle values & callbacks
    restoreCourses: Boolean = true, onToggleCourses: ((Boolean) -> Unit)? = null,
    restoreSubjects: Boolean = true, onToggleSubjects: ((Boolean) -> Unit)? = null,
    restoreCourseSubjects: Boolean = true, onToggleCourseSubjects: ((Boolean) -> Unit)? = null,
    restoreStudents: Boolean = true, onToggleStudents: ((Boolean) -> Unit)? = null,
    restoreStudentViolations: Boolean = true, onToggleStudentViolations: ((Boolean) -> Unit)? = null,
    restoreAttendance: Boolean = true, onToggleAttendance: ((Boolean) -> Unit)? = null,
    restoreStudentAttendance: Boolean = true, onToggleStudentAttendance: ((Boolean) -> Unit)? = null,
    restoreLessonTopics: Boolean = true, onToggleLessonTopics: ((Boolean) -> Unit)? = null,
    restoreLessonSessionTopics: Boolean = true, onToggleLessonSessionTopics: ((Boolean) -> Unit)? = null,
    restoreDailyNotes: Boolean = true, onToggleDailyNotes: ((Boolean) -> Unit)? = null,
    restoreGradeConfigs: Boolean = true, onToggleGradeConfigs: ((Boolean) -> Unit)? = null,
    restoreStudentGrades: Boolean = true, onToggleStudentGrades: ((Boolean) -> Unit)? = null,
    restoreAssignmentTemplates: Boolean = true, onToggleAssignmentTemplates: ((Boolean) -> Unit)? = null,
    restoreAssignmentSubmissions: Boolean = true, onToggleAssignmentSubmissions: ((Boolean) -> Unit)? = null,
    restoreManualModes: Boolean = true, onToggleManualModes: ((Boolean) -> Unit)? = null,
    restoreTrainerTransactions: Boolean = true, onToggleTrainerTransactions: ((Boolean) -> Unit)? = null,
    restoreActivityLogs: Boolean = true, onToggleActivityLogs: ((Boolean) -> Unit)? = null,
    restoreSubjectReferences: Boolean = true, onToggleSubjectReferences: ((Boolean) -> Unit)? = null,
    restoreOfficialHolidays: Boolean = true, onToggleOfficialHolidays: ((Boolean) -> Unit)? = null,
    restoreFunnyPenalties: Boolean = true, onToggleFunnyPenalties: ((Boolean) -> Unit)? = null,
    restoreSettings: Boolean = true, onToggleSettings: ((Boolean) -> Unit)? = null
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Group 1: 📚 التعليم والدورات التدريبية
        BackupGroupSection("📚 التعليم والدورات التدريبية", isDarkTheme) {
            UnifiedDetailItemRow("الدورات التدريبية", "جدول الدورات الأساسية (courses)", "$coursesCount دورة", restoreCourses, onToggleCourses, isCustomMode)
            UnifiedDetailItemRow("المواد الدراسية", "جدول المواد ومسمياتها (subjects)", "$subjectsCount مادة", restoreSubjects, onToggleSubjects, isCustomMode)
            UnifiedDetailItemRow("ربط المواد بالدورات", "استعادة ربط المواد بالدورات (course_subjects)", "$courseSubjectsCount ربط", restoreCourseSubjects, onToggleCourseSubjects, isCustomMode)
        }

        // Group 2: 👥 الطلاب وشؤون الطلاب
        BackupGroupSection("👥 الطلاب وشؤون الطلاب", isDarkTheme) {
            UnifiedDetailItemRow("بيانات وأسماء الطلاب", "استعادة قوائم ملفات الطلاب (students)", "$studentsCount طالب", restoreStudents, onToggleStudents, isCustomMode)
            UnifiedDetailItemRow("مخالفات الطلاب والانضباط", "سجلات المخالفات والإجراءات (student_violations)", "$studentViolationsCount مخالفة", restoreStudentViolations, onToggleStudentViolations, isCustomMode)
        }

        // Group 3: 📅 الحضور والتحضير اليومي
        BackupGroupSection("📅 الحضور والتحضير اليومي", isDarkTheme) {
            UnifiedDetailItemRow("تحضير المدرسين والمدربين", "سجلات الحضور العام واليومي (attendance)", "$attendanceCount سجل", restoreAttendance, onToggleAttendance, isCustomMode)
            UnifiedDetailItemRow("حضور وغياب الطلاب التفصيلي", "سجلات حضور الطلاب التفصيلية (student_attendance)", "$studentAttendanceCount سجل", restoreStudentAttendance, onToggleStudentAttendance, isCustomMode)
            UnifiedDetailItemRow("مواضيع التحضير المنهجي", "جدول مواضيع المناهج (lesson_topics)", "$lessonTopicsCount موضوع", restoreLessonTopics, onToggleLessonTopics, isCustomMode)
            UnifiedDetailItemRow("سجلات الحصص والدروس اليومية", "سجلات مواضيع الدروس اليومية (lesson_session_topics)", "$lessonSessionTopicsCount حصة", restoreLessonSessionTopics, onToggleLessonSessionTopics, isCustomMode)
            UnifiedDetailItemRow("الملاحظات اليومية للدورات", "جدول الملاحظات والتعليقات اليومية (daily_notes)", "$dailyNotesCount ملاحظة", restoreDailyNotes, onToggleDailyNotes, isCustomMode)
        }

        // Group 4: 🎓 الدرجات والتكاليف والتقييم
        BackupGroupSection("🎓 الدرجات والتكاليف والتقييم", isDarkTheme) {
            UnifiedDetailItemRow("تهيئة وتوزيع درجات المواد", "توزيع درجات المواد والتقييمات (grade_configs)", "$gradeConfigsCount قالب", restoreGradeConfigs, onToggleGradeConfigs, isCustomMode)
            UnifiedDetailItemRow("درجات وتقييمات الطلاب", "سجلات درجات الطلاب في المواد (student_grades)", "$studentGradesCount درجة", restoreStudentGrades, onToggleStudentGrades, isCustomMode)
            UnifiedDetailItemRow("قوالب الواجبات والتكاليف", "قوالب وواجبات المواد الدراسية (assignment_templates)", "$assignmentTemplatesCount قالب", restoreAssignmentTemplates, onToggleAssignmentTemplates, isCustomMode)
            UnifiedDetailItemRow("تسليمات ودرجات التكاليف", "تسليمات ودرجات تكاليف الطلاب (assignment_submissions)", "$assignmentSubmissionsCount تسليم", restoreAssignmentSubmissions, onToggleAssignmentSubmissions, isCustomMode)
            UnifiedDetailItemRow("أنماط وقوالب التكليفات المخصصة", "إعدادات وأنماط التكليفات للمدرب (manual_assignment_modes)", "$manualModesCount نمط", restoreManualModes, onToggleManualModes, isCustomMode)
        }

        // Group 5: 💰 المالية، المراجع، ونظام المعهد
        BackupGroupSection("💰 المالية والمراجع وإعدادات النظام", isDarkTheme) {
            UnifiedDetailItemRow("المعاملات والمسحوبات المالية", "الإيرادات والمصروفات وحسابات المدربين (trainer_transactions)", "$trainerTransactionsCount معاملة", restoreTrainerTransactions, onToggleTrainerTransactions, isCustomMode)
            UnifiedDetailItemRow("سجل نشاط وتتبع العمليات", "سجلات تتبع الأنشطة والعمليات (activity_logs)", "$activityLogsCount حركة", restoreActivityLogs, onToggleActivityLogs, isCustomMode)
            UnifiedDetailItemRow("المصادر والمراجع الدراسية", "روابط ومرفقات المراجع للكتب والمواد (subject_references)", "$subjectReferencesCount مرجع", restoreSubjectReferences, onToggleSubjectReferences, isCustomMode)
            UnifiedDetailItemRow("الإجازات والعطلات الرسمية", "جدول العطلات والمواسم الرسمية بالتقويم (official_holidays)", "$officialHolidaysCount إجازة", restoreOfficialHolidays, onToggleOfficialHolidays, isCustomMode)
            UnifiedDetailItemRow("قائمة العقوبات الفكاهية والترفيهية", "العقوبات الفكاهية المعروضة في شؤون الطلاب (funny_penalties)", "$funnyPenaltiesCount عقوبة", restoreFunnyPenalties, onToggleFunnyPenalties, isCustomMode)
            UnifiedDetailItemRow("إعدادات المعهد والهوية البصرية", "اسم المعهد، الشعارات، الهوية، والقسم (settings)", if (settingsCount > 0) "12 إعداد مفعل" else "غير متاح", restoreSettings, onToggleSettings, isCustomMode)
        }
    }
}

@Composable
private fun BackupGroupSection(
    title: String,
    isDarkTheme: Boolean,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isDarkTheme) Color(0xFF0F172A) else Color(0xFFF8FAFC)
        ),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            content()
        }
    }
}

@Composable
private fun UnifiedDetailItemRow(
    title: String,
    subtitle: String,
    countText: String,
    checked: Boolean,
    onToggle: ((Boolean) -> Unit)?,
    isCustomMode: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .then(
                if (isCustomMode && onToggle != null) Modifier.clickable { onToggle(!checked) }
                else Modifier
            )
            .padding(vertical = 3.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isCustomMode && checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = countText,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
            Text(
                text = subtitle,
                fontSize = 9.sp,
                color = Color.Gray
            )
        }

        if (isCustomMode && onToggle != null) {
            Checkbox(
                checked = checked,
                onCheckedChange = onToggle,
                colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
            )
        }
    }
}

@Composable
private fun SelectiveDataWipeDialog(
    viewModel: MainViewModel,
    isDarkTheme: Boolean,
    coursesCount: Int,
    subjectsCount: Int,
    courseSubjectsCount: Int,
    studentsCount: Int,
    studentViolationsCount: Int,
    attendanceCount: Int,
    studentAttendanceCount: Int,
    lessonTopicsCount: Int,
    lessonSessionTopicsCount: Int,
    dailyNotesCount: Int,
    gradeConfigsCount: Int,
    studentGradesCount: Int,
    assignmentTemplatesCount: Int,
    assignmentSubmissionsCount: Int,
    manualAssignmentModesCount: Int,
    transactionsCount: Int,
    activityLogsCount: Int,
    subjectReferencesCount: Int,
    officialHolidaysCount: Int,
    funnyPenaltiesCount: Int,
    onDismiss: () -> Unit
) {
    var isCustomMode by remember { mutableStateOf(false) }

    // 21 Wipe Checkbox States (Default to true for Comprehensive Wipe mode)
    var wipeCourses by remember { mutableStateOf(true) }
    var wipeSubjects by remember { mutableStateOf(true) }
    var wipeCourseSubjects by remember { mutableStateOf(true) }
    var wipeStudents by remember { mutableStateOf(true) }
    var wipeStudentViolations by remember { mutableStateOf(true) }
    var wipeAttendance by remember { mutableStateOf(true) }
    var wipeStudentAttendance by remember { mutableStateOf(true) }
    var wipeLessonTopics by remember { mutableStateOf(true) }
    var wipeLessonSessionTopics by remember { mutableStateOf(true) }
    var wipeDailyNotes by remember { mutableStateOf(true) }
    var wipeGradeConfigs by remember { mutableStateOf(true) }
    var wipeStudentGrades by remember { mutableStateOf(true) }
    var wipeAssignmentTemplates by remember { mutableStateOf(true) }
    var wipeAssignmentSubmissions by remember { mutableStateOf(true) }
    var wipeManualAssignmentModes by remember { mutableStateOf(true) }
    var wipeFinances by remember { mutableStateOf(true) }
    var wipeActivityLogs by remember { mutableStateOf(true) }
    var wipeSubjectReferences by remember { mutableStateOf(true) }
    var wipeOfficialHolidays by remember { mutableStateOf(true) }
    var wipeFunnyPenalties by remember { mutableStateOf(true) }
    var wipeSettings by remember { mutableStateOf(true) }

    var enteredPassword by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current

    val totalSelectedWipeRecords = remember(
        isCustomMode, wipeCourses, wipeSubjects, wipeCourseSubjects, wipeStudents, wipeStudentViolations,
        wipeAttendance, wipeStudentAttendance, wipeLessonTopics, wipeLessonSessionTopics, wipeDailyNotes,
        wipeGradeConfigs, wipeStudentGrades, wipeAssignmentTemplates, wipeAssignmentSubmissions, wipeManualAssignmentModes,
        wipeFinances, wipeActivityLogs, wipeSubjectReferences, wipeOfficialHolidays, wipeFunnyPenalties, wipeSettings,
        coursesCount, subjectsCount, courseSubjectsCount, studentsCount, studentViolationsCount,
        attendanceCount, studentAttendanceCount, lessonTopicsCount, lessonSessionTopicsCount, dailyNotesCount,
        gradeConfigsCount, studentGradesCount, assignmentTemplatesCount, assignmentSubmissionsCount, manualAssignmentModesCount,
        transactionsCount, activityLogsCount, subjectReferencesCount, officialHolidaysCount, funnyPenaltiesCount
    ) {
        if (!isCustomMode) {
            coursesCount + subjectsCount + courseSubjectsCount + studentsCount + studentViolationsCount +
            attendanceCount + studentAttendanceCount + lessonTopicsCount + lessonSessionTopicsCount + dailyNotesCount +
            gradeConfigsCount + studentGradesCount + assignmentTemplatesCount + assignmentSubmissionsCount + manualAssignmentModesCount +
            transactionsCount + activityLogsCount + subjectReferencesCount + officialHolidaysCount + funnyPenaltiesCount + 12
        } else {
            var count = 0
            if (wipeCourses) count += coursesCount
            if (wipeSubjects) count += subjectsCount
            if (wipeCourseSubjects) count += courseSubjectsCount
            if (wipeStudents) count += studentsCount
            if (wipeStudentViolations) count += studentViolationsCount
            if (wipeAttendance) count += attendanceCount
            if (wipeStudentAttendance) count += studentAttendanceCount
            if (wipeLessonTopics) count += lessonTopicsCount
            if (wipeLessonSessionTopics) count += lessonSessionTopicsCount
            if (wipeDailyNotes) count += dailyNotesCount
            if (wipeGradeConfigs) count += gradeConfigsCount
            if (wipeStudentGrades) count += studentGradesCount
            if (wipeAssignmentTemplates) count += assignmentTemplatesCount
            if (wipeAssignmentSubmissions) count += assignmentSubmissionsCount
            if (wipeManualAssignmentModes) count += manualAssignmentModesCount
            if (wipeFinances) count += transactionsCount
            if (wipeActivityLogs) count += activityLogsCount
            if (wipeSubjectReferences) count += subjectReferencesCount
            if (wipeOfficialHolidays) count += officialHolidaysCount
            if (wipeFunnyPenalties) count += funnyPenaltiesCount
            if (wipeSettings) count += 12
            count
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CleaningServices,
                    contentDescription = null,
                    tint = Color(0xFFDC2626),
                    modifier = Modifier.size(26.dp)
                )
                Column {
                    Text(
                        text = "مسح وإعادة ضبط بيانات النظام ⚠️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFFDC2626)
                    )
                    Text(
                        text = "اختر نوع نمط المسح ومعاينة إحصائيات الـ 21 قطاعاً",
                        fontSize = 10.5.sp,
                        color = Color.Gray
                    )
                }
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Section 1: Mode Toggle Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFFEF2F2)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFFECACA))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "اختر نوع المسح المراد تطبيقه على النظام:",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDarkTheme) Color.White else DawamiNavy
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = {
                                        isCustomMode = false
                                        wipeCourses = true; wipeSubjects = true; wipeCourseSubjects = true
                                        wipeStudents = true; wipeStudentViolations = true
                                        wipeAttendance = true; wipeStudentAttendance = true; wipeLessonTopics = true; wipeLessonSessionTopics = true; wipeDailyNotes = true
                                        wipeGradeConfigs = true; wipeStudentGrades = true; wipeAssignmentTemplates = true; wipeAssignmentSubmissions = true; wipeManualAssignmentModes = true
                                        wipeFinances = true; wipeActivityLogs = true; wipeSubjectReferences = true; wipeOfficialHolidays = true; wipeFunnyPenalties = true; wipeSettings = true
                                    },
                                    modifier = Modifier.weight(1f).height(38.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (!isCustomMode) Color(0xFFDC2626) else Color.Gray.copy(alpha = 0.2f),
                                        contentColor = if (!isCustomMode) Color.White else Color.Gray
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("مسح كلي شامل 💥", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { isCustomMode = true },
                                    modifier = Modifier.weight(1f).height(38.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isCustomMode) DawamiNavy else Color.Gray.copy(alpha = 0.2f),
                                        contentColor = if (isCustomMode) Color.White else Color.Gray
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("مسح مخصص ⚙️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Section 2: Quick Presets (Available in Custom Mode)
                if (isCustomMode) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "خيارات الاختيار السريع (أنماط التصفير):",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDarkTheme) Color.White else DawamiNavy
                            )

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                item {
                                    OutlinedButton(
                                        onClick = {
                                            wipeCourses = true; wipeSubjects = true; wipeCourseSubjects = true
                                            wipeStudents = true; wipeStudentViolations = true
                                            wipeAttendance = true; wipeStudentAttendance = true; wipeLessonTopics = true; wipeLessonSessionTopics = true; wipeDailyNotes = true
                                            wipeGradeConfigs = true; wipeStudentGrades = true; wipeAssignmentTemplates = true; wipeAssignmentSubmissions = true; wipeManualAssignmentModes = true
                                            wipeFinances = true; wipeActivityLogs = true; wipeSubjectReferences = true; wipeOfficialHolidays = true; wipeFunnyPenalties = true; wipeSettings = true
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, Color(0xFFDC2626)),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        modifier = Modifier.defaultMinSize(minHeight = 32.dp)
                                    ) {
                                        Text("💥 تحديد الكل (21 قطاعاً)", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                                    }
                                }

                                item {
                                    OutlinedButton(
                                        onClick = {
                                            wipeCourses = true; wipeSubjects = true; wipeCourseSubjects = true
                                            wipeStudents = true; wipeStudentViolations = true
                                            wipeAttendance = true; wipeStudentAttendance = true; wipeLessonTopics = true; wipeLessonSessionTopics = true; wipeDailyNotes = true
                                            wipeGradeConfigs = true; wipeStudentGrades = true; wipeAssignmentTemplates = true; wipeAssignmentSubmissions = true; wipeManualAssignmentModes = true
                                            wipeFinances = true; wipeActivityLogs = true; wipeSubjectReferences = true; wipeOfficialHolidays = true; wipeFunnyPenalties = true
                                            wipeSettings = false
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, Color(0xFFD97706)),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        modifier = Modifier.defaultMinSize(minHeight = 32.dp)
                                    ) {
                                        Text("🏫 تصفير بدون تهيئة المعهد", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                                    }
                                }

                                item {
                                    OutlinedButton(
                                        onClick = {
                                            wipeCourses = false; wipeSubjects = false; wipeCourseSubjects = false
                                            wipeStudents = false; wipeStudentViolations = true
                                            wipeAttendance = true; wipeStudentAttendance = true; wipeLessonTopics = false; wipeLessonSessionTopics = true; wipeDailyNotes = true
                                            wipeGradeConfigs = true; wipeStudentGrades = true; wipeAssignmentTemplates = true; wipeAssignmentSubmissions = true; wipeManualAssignmentModes = false
                                            wipeFinances = true; wipeActivityLogs = false; wipeSubjectReferences = false; wipeOfficialHolidays = false; wipeFunnyPenalties = false
                                            wipeSettings = false
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, Color(0xFF2563EB)),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        modifier = Modifier.defaultMinSize(minHeight = 32.dp)
                                    ) {
                                        Text("🧹 سجلات تشغيلية فقط", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB))
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 3: Records Summary Banner
                item {
                    Surface(
                        color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFFEF2F2),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFFECACA))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📊 إجمالي السجلات المستهدفة للمسح: $totalSelectedWipeRecords سجل",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFDC2626)
                            )
                            Surface(
                                color = Color(0xFFDC2626).copy(alpha = 0.12f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (!isCustomMode) "مسح كلي شامل" else "مسح مخصص",
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFDC2626)
                                )
                            }
                        }
                    }
                }

                // Section 4: Sector Categories Checklist
                item {
                    Text(
                        text = if (!isCustomMode) "📊 قائمة القطاعات المستهدفة بالمسح الشامل (21 قطاعاً):" else "حدد البيانات المراد مسحها بالتفصيل (21 قطاعاً):",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDarkTheme) Color.White else DawamiNavy
                    )
                }

                item {
                    Unified21BackupDetailsList(
                        isCustomMode = isCustomMode,
                        isDarkTheme = isDarkTheme,
                        coursesCount = coursesCount,
                        subjectsCount = subjectsCount,
                        courseSubjectsCount = courseSubjectsCount,
                        studentsCount = studentsCount,
                        studentViolationsCount = studentViolationsCount,
                        attendanceCount = attendanceCount,
                        studentAttendanceCount = studentAttendanceCount,
                        lessonTopicsCount = lessonTopicsCount,
                        lessonSessionTopicsCount = lessonSessionTopicsCount,
                        dailyNotesCount = dailyNotesCount,
                        gradeConfigsCount = gradeConfigsCount,
                        studentGradesCount = studentGradesCount,
                        assignmentTemplatesCount = assignmentTemplatesCount,
                        assignmentSubmissionsCount = assignmentSubmissionsCount,
                        manualModesCount = manualAssignmentModesCount,
                        trainerTransactionsCount = transactionsCount,
                        activityLogsCount = activityLogsCount,
                        subjectReferencesCount = subjectReferencesCount,
                        officialHolidaysCount = officialHolidaysCount,
                        funnyPenaltiesCount = funnyPenaltiesCount,
                        settingsCount = 12,
                        // Checkbox states & setters
                        restoreCourses = wipeCourses, onToggleCourses = { wipeCourses = it },
                        restoreSubjects = wipeSubjects, onToggleSubjects = { wipeSubjects = it },
                        restoreCourseSubjects = wipeCourseSubjects, onToggleCourseSubjects = { wipeCourseSubjects = it },
                        restoreStudents = wipeStudents, onToggleStudents = { wipeStudents = it },
                        restoreStudentViolations = wipeStudentViolations, onToggleStudentViolations = { wipeStudentViolations = it },
                        restoreAttendance = wipeAttendance, onToggleAttendance = { wipeAttendance = it },
                        restoreStudentAttendance = wipeStudentAttendance, onToggleStudentAttendance = { wipeStudentAttendance = it },
                        restoreLessonTopics = wipeLessonTopics, onToggleLessonTopics = { wipeLessonTopics = it },
                        restoreLessonSessionTopics = wipeLessonSessionTopics, onToggleLessonSessionTopics = { wipeLessonSessionTopics = it },
                        restoreDailyNotes = wipeDailyNotes, onToggleDailyNotes = { wipeDailyNotes = it },
                        restoreGradeConfigs = wipeGradeConfigs, onToggleGradeConfigs = { wipeGradeConfigs = it },
                        restoreStudentGrades = wipeStudentGrades, onToggleStudentGrades = { wipeStudentGrades = it },
                        restoreAssignmentTemplates = wipeAssignmentTemplates, onToggleAssignmentTemplates = { wipeAssignmentTemplates = it },
                        restoreAssignmentSubmissions = wipeAssignmentSubmissions, onToggleAssignmentSubmissions = { wipeAssignmentSubmissions = it },
                        restoreManualModes = wipeManualAssignmentModes, onToggleManualModes = { wipeManualAssignmentModes = it },
                        restoreTrainerTransactions = wipeFinances, onToggleTrainerTransactions = { wipeFinances = it },
                        restoreActivityLogs = wipeActivityLogs, onToggleActivityLogs = { wipeActivityLogs = it },
                        restoreSubjectReferences = wipeSubjectReferences, onToggleSubjectReferences = { wipeSubjectReferences = it },
                        restoreOfficialHolidays = wipeOfficialHolidays, onToggleOfficialHolidays = { wipeOfficialHolidays = it },
                        restoreFunnyPenalties = wipeFunnyPenalties, onToggleFunnyPenalties = { wipeFunnyPenalties = it },
                        restoreSettings = wipeSettings, onToggleSettings = { wipeSettings = it }
                    )
                }

                item { Divider() }

                // Section 5: Password Confirmation
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "🔐 أدخل كلمة سر حسابك للتأكيد وتنفيذ المسح:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626)
                        )

                        OutlinedTextField(
                            value = enteredPassword,
                            onValueChange = {
                                enteredPassword = it
                                passwordError = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            isError = passwordError != null,
                            shape = RoundedCornerShape(8.dp)
                        )

                        if (passwordError != null) {
                            Text(
                                text = passwordError!!,
                                fontSize = 10.sp,
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            val hasSelection = !isCustomMode || wipeSettings || wipeCourses || wipeSubjects || wipeCourseSubjects || wipeStudents || wipeStudentViolations ||
                    wipeAttendance || wipeStudentAttendance || wipeLessonTopics || wipeLessonSessionTopics || wipeDailyNotes ||
                    wipeGradeConfigs || wipeStudentGrades || wipeAssignmentTemplates || wipeAssignmentSubmissions || wipeManualAssignmentModes ||
                    wipeFinances || wipeActivityLogs || wipeSubjectReferences || wipeOfficialHolidays || wipeFunnyPenalties

            Button(
                onClick = {
                    if (enteredPassword.isBlank()) {
                        passwordError = "يرجى إدخال كلمة سر الحساب للتأكيد"
                        return@Button
                    }
                    if (!viewModel.verifyUserPassword(enteredPassword)) {
                        passwordError = "كلمة السر غير صحيحة! يرجى التأكد وإعادة المحاولة."
                        return@Button
                    }

                    val options = if (!isCustomMode) {
                        MainViewModel.DataWipeOptions(
                            wipeCourses = true,
                            wipeSubjects = true,
                            wipeCourseSubjects = true,
                            wipeStudents = true,
                            wipeStudentViolations = true,
                            wipeAttendance = true,
                            wipeStudentAttendance = true,
                            wipeLessonTopics = true,
                            wipeLessonSessionTopics = true,
                            wipeDailyNotes = true,
                            wipeGradeConfigs = true,
                            wipeStudentGrades = true,
                            wipeAssignmentTemplates = true,
                            wipeAssignmentSubmissions = true,
                            wipeManualAssignmentModes = true,
                            wipeTrainerFinances = true,
                            wipeActivityLogs = true,
                            wipeSubjectReferences = true,
                            wipeOfficialHolidays = true,
                            wipeFunnyPenalties = true,
                            wipeSettings = true
                        )
                    } else {
                        MainViewModel.DataWipeOptions(
                            wipeCourses = wipeCourses,
                            wipeSubjects = wipeSubjects,
                            wipeCourseSubjects = wipeCourseSubjects,
                            wipeStudents = wipeStudents,
                            wipeStudentViolations = wipeStudentViolations,
                            wipeAttendance = wipeAttendance,
                            wipeStudentAttendance = wipeStudentAttendance,
                            wipeLessonTopics = wipeLessonTopics,
                            wipeLessonSessionTopics = wipeLessonSessionTopics,
                            wipeDailyNotes = wipeDailyNotes,
                            wipeGradeConfigs = wipeGradeConfigs,
                            wipeStudentGrades = wipeStudentGrades,
                            wipeAssignmentTemplates = wipeAssignmentTemplates,
                            wipeAssignmentSubmissions = wipeAssignmentSubmissions,
                            wipeManualAssignmentModes = wipeManualAssignmentModes,
                            wipeTrainerFinances = wipeFinances,
                            wipeActivityLogs = wipeActivityLogs,
                            wipeSubjectReferences = wipeSubjectReferences,
                            wipeOfficialHolidays = wipeOfficialHolidays,
                            wipeFunnyPenalties = wipeFunnyPenalties,
                            wipeSettings = wipeSettings
                        )
                    }

                    viewModel.wipeCustomData(options) { success, msg ->
                        if (success) {
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            onDismiss()
                        } else {
                            passwordError = msg
                        }
                    }
                },
                enabled = hasSelection,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("تأكيد وتنفيذ المسح 🗑️", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء ✖️", fontSize = 11.5.sp, color = Color.Gray)
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun WipeCheckboxRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (checked) Color(0xFFDC2626) else Color.Unspecified
            )
            Text(
                text = subtitle,
                fontSize = 9.5.sp,
                color = Color.Gray
            )
        }

        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(checkedColor = Color(0xFFDC2626))
        )
    }
}
