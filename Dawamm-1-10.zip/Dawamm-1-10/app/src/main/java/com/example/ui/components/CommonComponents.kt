package com.example.ui.components

import coil.compose.AsyncImage
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import com.example.data.entity.InAppNotification
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import android.widget.Toast
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.TaskAlt
import com.example.data.entity.Course
import com.example.data.entity.Subject
import com.example.data.entity.CourseSubjectStat
import com.example.data.entity.CourseSubjectCrossRef
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import androidx.compose.material.icons.filled.ExitToApp
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.sin

// Native Picker Helpers
fun showDatePicker(context: Context, onDateSelected: (String) -> Unit) {
    val calendar = Calendar.getInstance()
    DatePickerDialog(
        context,
        com.example.R.style.CustomDatePickerDialogTheme,
        { _, year, month, dayOfMonth ->
            val formattedMonth = String.format("%02d", month + 1)
            val formattedDay = String.format("%02d", dayOfMonth)
            onDateSelected("$year-$formattedMonth-$formattedDay")
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    ).show()
}

fun showTimePicker(context: Context, onTimeSelected: (String) -> Unit) {
    val calendar = Calendar.getInstance()
    TimePickerDialog(
        context,
        com.example.R.style.CustomTimePickerDialogTheme,
        { _, hourOfDay, minute ->
            val formattedHour = String.format("%02d", hourOfDay)
            val formattedMinute = String.format("%02d", minute)
            onTimeSelected("$formattedHour:$formattedMinute")
        },
        calendar.get(Calendar.HOUR_OF_DAY),
        calendar.get(Calendar.MINUTE),
        false
    ).show()
}

fun formatTimeTo12HourArabic(timeStr: String): String {
    if (timeStr.isEmpty()) return ""
    return try {
        var cleanTime = timeStr.trim()
        cleanTime = cleanTime.replace("صباحاً", "ص").replace("مساءً", "م")
        if (cleanTime.contains("ص") || cleanTime.contains("م")) {
            return cleanTime
        }
        val parts = cleanTime.split(":")
        if (parts.size >= 2) {
            val hour24 = parts[0].toIntOrNull() ?: return cleanTime
            val minutePart = parts[1].split(" ")[0]
            val minute = minutePart.toIntOrNull() ?: return cleanTime
            val period = if (hour24 >= 12) "م" else "ص"
            val hour12 = when {
                hour24 == 0 -> 12
                hour24 > 12 -> hour24 - 12
                else -> hour24
            }
            val formattedHour = String.format("%02d", hour12)
            val formattedMinute = String.format("%02d", minute)
            "$formattedHour:$formattedMinute $period"
        } else {
            cleanTime
        }
    } catch (e: Exception) {
        timeStr
    }
}

// Custom-drawn, beautiful vectors logo replicating the attached clock & gear emblem.
@Composable
fun DawamiLogo(
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    opacity: Float = 1.0f
) {
    Image(
        painter = painterResource(id = com.example.R.drawable.app_icon_new_1789091045526),
        contentDescription = "Dawami Logo",
        modifier = modifier
            .size(size)
            .alpha(opacity)
            .clip(RoundedCornerShape(8.dp))
    )
}

// Mandatory Application Footer appearing on all screens
@Composable
fun AppFooter() {
    // Moved developer credit to header per user request, so footer is empty
    Spacer(modifier = Modifier.height(1.dp))
}

// Unified Top bar that supports localization and logo aesthetics
val LocalDrawerOpener = staticCompositionLocalOf<(() -> Unit)?> { null }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppHeader(
    title: String,
    username: String = "",
    onLogoutClick: (() -> Unit)? = null,
    onHomeClick: (() -> Unit)? = null,
    onBackClick: (() -> Unit)? = null,
    isDark: Boolean = false,
    onToggleTheme: (() -> Unit)? = null,
    unreadNotificationCount: Int = 0,
    onNotificationClick: (() -> Unit)? = null,
    isMainScreen: Boolean = false,
    logoUri: String = "",
    onMenuClick: (() -> Unit)? = null
) {
    val isDarkTheme = isDark
    val context = LocalContext.current
    var showExitDialog by remember { mutableStateOf(false) }

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = {
                Text(
                    text = "تأكيد إغلاق البرنامج 🚪",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDarkTheme) Color.White else DawamiNavy
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في إغلاق تطبيق دوامي وإنهاء الجلسة الحالية؟",
                    fontSize = 14.sp,
                    color = if (isDarkTheme) Color(0xFFE2E8F0) else Color(0xFF334155)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExitDialog = false
                        (context as? android.app.Activity)?.finish()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("نعم، إغلاق", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showExitDialog = false }
                ) {
                    Text("إلغاء", color = if (isDarkTheme) Color(0xFF94A3B8) else Color(0xFF64748B))
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = if (isDarkTheme) DarkSurface else Color.White
        )
    }

    Surface(
        color = if (isDarkTheme) DarkSurface else Color.White.copy(alpha = 0.95f),
        tonalElevation = 0.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Right Side: Drawer Menu Button, branding logo & name
            val drawerOpener = LocalDrawerOpener.current
            val actualMenuClick = onMenuClick ?: drawerOpener

            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Drawer Menu Toggle Button (☰)
                if (actualMenuClick != null) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                color = if (isDarkTheme) Color(0xFF1E293B) else DawamiNavy.copy(alpha = 0.08f)
                            )
                            .border(
                                width = 1.dp,
                                color = if (isDarkTheme) Color(0xFF334155) else DawamiNavy.copy(alpha = 0.2f),
                                shape = CircleShape
                            )
                            .clickable { actualMenuClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "القائمة الجانبية للتنقل",
                            tint = if (isDarkTheme) DawamiGold else DawamiNavy,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                if (logoUri.isNotEmpty()) {
                    AsyncImage(
                        model = logoUri,
                        contentDescription = "شعار المعهد",
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(6.dp)),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                        error = painterResource(id = com.example.R.drawable.app_icon_new_1789091045526)
                    )
                } else {
                    DawamiLogo(size = 32.dp, opacity = 1.0f)
                }
                Column(modifier = Modifier.weight(1f)) {
                    if (isMainScreen) {
                        // Title: Program name
                        Text(
                            text = "نظام الحضور الذكي",
                            color = if (isDarkTheme) Color.White else Color(0xFF0F172A), // Slate 900
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        // Subtitle: Developer name
                        Text(
                            text = "برمجة م: فيصل العفيف 🌹",
                            color = if (isDarkTheme) Color(0xFF38BDF8) else Color(0xFF0369A1), // Sky 400 / Sky 700
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        // Title: Interface name
                        Text(
                            text = title,
                            color = if (isDarkTheme) Color.White else Color(0xFF0F172A), // Slate 900
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        // Subtitle: Developer name directly (Replaces "نظام الحضور الذكي")
                        Text(
                            text = "برمجة م: فيصل العفيف 🌹",
                            color = if (isDarkTheme) Color(0xFF38BDF8) else Color(0xFF0369A1), // Sky 400 / Sky 700
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Left Side: Action buttons (user chip, theme, home/exit)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                    // Trainer / User Name Chip (Visible ONLY on main screen)
                    if (isMainScreen && username.isNotEmpty()) {
                        Surface(
                            color = if (isDarkTheme) DawamiGold.copy(alpha = 0.15f) else DawamiNavy.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(20.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isDarkTheme) DawamiGold.copy(alpha = 0.4f) else DawamiNavy.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = if (isDarkTheme) Gold80 else DawamiNavy,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = username,
                                    color = if (isDarkTheme) Gold80 else DawamiNavy,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    // Task Bar Button ("شريط المهام اليومية")
                    if (onNotificationClick != null) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isDarkTheme) Color(0xFF334155) else Color(0xFFCBD5E1),
                                    shape = CircleShape
                                )
                                .clickable(onClick = onNotificationClick),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FactCheck,
                                contentDescription = "شريط المهام اليومية",
                                tint = if (unreadNotificationCount > 0) DawamiGold else if (isDarkTheme) Color.White else Color(0xFF475569),
                                modifier = Modifier.size(18.dp)
                            )
                            if (unreadNotificationCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .offset(x = 2.dp, y = (-2).dp)
                                        .size(15.dp)
                                        .background(Color(0xFFF59E0B), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (unreadNotificationCount > 9) "9+" else unreadNotificationCount.toString(),
                                        color = Color.White,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Theme Toggle Button
                    if (onToggleTheme != null) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isDarkTheme) Color(0xFF334155) else Color(0xFFCBD5E1),
                                    shape = CircleShape
                                )
                                .clickable(onClick = onToggleTheme),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Brightness4,
                                contentDescription = "🎨 الثيمات",
                                tint = if (isDarkTheme) DawamiGold else Color(0xFF475569),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Back Button (Visible on sub-screens)
                    if (!isMainScreen) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    color = if (isDarkTheme) Color(0xFF1E293B) else DawamiNavy.copy(alpha = 0.08f)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isDarkTheme) Color(0xFF334155) else DawamiNavy.copy(alpha = 0.2f),
                                    shape = CircleShape
                                )
                                .clickable { onBackClick?.invoke() ?: onHomeClick?.invoke() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع",
                                tint = if (isDarkTheme) Color.White else DawamiNavy,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Home Button (Visible ONLY on sub-screens)
                    if (!isMainScreen) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    color = if (isDarkTheme) Color(0xFF1E293B) else DawamiNavy.copy(alpha = 0.08f)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isDarkTheme) Color(0xFF334155) else DawamiNavy.copy(alpha = 0.2f),
                                    shape = CircleShape
                                )
                                .clickable { onHomeClick?.invoke() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "الرئيسية",
                                tint = if (isDarkTheme) Color.White else DawamiNavy,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Exit App Button (Visible ONLY on main screen)
                    if (isMainScreen) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    color = if (isDarkTheme) Color(0xFF451A1A) else Color(0xFFFEF2F2)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isDarkTheme) Color(0xFF7F1D1D) else Color(0xFFFCA5A5),
                                    shape = CircleShape
                                )
                                .clickable { showExitDialog = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ExitToApp,
                                contentDescription = "إغلاق البرنامج",
                                tint = if (isDarkTheme) Color(0xFFF87171) else Color(0xFFDC2626),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val preset = com.example.ui.theme.LocalThemePreset.current
    val isDark = preset.isDark
    val isNoShow = status == "لم يحضر" || status.isEmpty()
    val (bgColor, textColor, dotColor) = if (isDark) {
        when (status) {
            "حضور" -> Triple(Color(0xFF064E3B).copy(alpha = 0.5f), Color(0xFF34D399), Color(0xFF10B981))
            "غياب", "لم يحضر" -> Triple(Color(0xFF7F1D1D).copy(alpha = 0.5f), Color(0xFFF87171), Color(0xFFEF4444))
            "إجازة" -> Triple(Color(0xFF78350F).copy(alpha = 0.5f), Color(0xFFFBBF24), Color(0xFFF59E0B))
            "مستأذن" -> Triple(Color(0xFF0C4A6E).copy(alpha = 0.5f), Color(0xFF38BDF8), Color(0xFF0EA5E9))
            "متأخر" -> Triple(Color(0xFF7C2D12).copy(alpha = 0.5f), Color(0xFFFB923C), Color(0xFFF97316))
            else -> Triple(Color(0xFF1E293B), Color(0xFF94A3B8), Color(0xFF64748B))
        }
    } else {
        when (status) {
            "حضور" -> Triple(Color(0xFFDCFCE7), Color(0xFF15803D), Color(0xFF16A34A))
            "غياب", "لم يحضر" -> Triple(Color(0xFFFEE2E2), Color(0xFFDC2626), Color(0xFFDC2626))
            "إجازة" -> Triple(Color(0xFFFEF3C7), Color(0xFFB45309), Color(0xFFD97706))
            "مستأذن" -> Triple(Color(0xFFE0F2FE), Color(0xFF0369A1), Color(0xFF0284C7))
            "متأخر" -> Triple(Color(0xFFFFEDD5), Color(0xFFC2410C), Color(0xFFEA580C))
            else -> Triple(Color(0xFFF1F5F9), Color(0xFF334155), Color(0xFF64748B))
        }
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(0.8.dp, dotColor.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = if (isNoShow) 6.dp else 8.dp,
                vertical = 2.5.dp
            ),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            if (!isNoShow) {
                Text(
                    text = status,
                    color = textColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModernDatePickerDialog(
    onDateSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val datePickerState = rememberDatePickerState()
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    val selectedDateMillis = datePickerState.selectedDateMillis
                    if (selectedDateMillis != null) {
                        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                        val dateStr = sdf.format(java.util.Date(selectedDateMillis))
                        onDateSelected(dateStr)
                    }
                    onDismiss()
                }
            ) {
                Text("تأكيد ✔️", fontWeight = FontWeight.Bold, color = DawamiNavy)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء ❌", color = Color.Gray)
            }
        },
        colors = DatePickerDefaults.colors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        DatePicker(
            state = datePickerState,
            title = {
                Text(
                    text = "اختر التاريخ 📅",
                    modifier = Modifier.padding(start = 24.dp, top = 16.dp),
                    fontWeight = FontWeight.Bold,
                    color = DawamiNavy,
                    fontSize = 16.sp
                )
            },
            headline = {
                Text(
                    text = "تحديد اليوم للدوام",
                    modifier = Modifier.padding(start = 24.dp, bottom = 8.dp),
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            },
            showModeToggle = true,
            colors = DatePickerDefaults.colors()
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModernTimePickerDialog(
    onTimeSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val timePickerState = rememberTimePickerState(is24Hour = false)
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    val formattedHour = String.format("%02d", timePickerState.hour)
                    val formattedMinute = String.format("%02d", timePickerState.minute)
                    onTimeSelected("$formattedHour:$formattedMinute")
                    onDismiss()
                }
            ) {
                Text("تأكيد ✔️", fontWeight = FontWeight.Bold, color = DawamiNavy)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء ❌", color = Color.Gray)
            }
        },
        title = {
            Text("اختر الوقت ⏰", fontWeight = FontWeight.Bold, color = DawamiNavy, fontSize = 16.sp)
        },
        text = {
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                TimePicker(
                    state = timePickerState,
                    colors = TimePickerDefaults.colors(
                        clockDialColor = Color(0xFFF1F5F9),
                        clockDialSelectedContentColor = Color.White,
                        clockDialUnselectedContentColor = DawamiNavy,
                        selectorColor = DawamiTeal,
                        periodSelectorBorderColor = DawamiNavy,
                        periodSelectorSelectedContainerColor = DawamiTeal.copy(alpha = 0.15f),
                        periodSelectorSelectedContentColor = DawamiNavy,
                        periodSelectorUnselectedContainerColor = Color.White,
                        periodSelectorUnselectedContentColor = Color.Gray,
                        timeSelectorSelectedContainerColor = DawamiTeal.copy(alpha = 0.15f),
                        timeSelectorSelectedContentColor = DawamiNavy,
                        timeSelectorUnselectedContainerColor = Color(0xFFF1F5F9),
                        timeSelectorUnselectedContentColor = Color.Gray
                    )
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(28.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeveloperContactDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val phoneNumber = "967775379042"
    val message = "مرحباً م. فيصل العفيف، أود الاستفسار بخصوص تطبيق دوامي المطور لإدارة الدوام والدرجات 🌸"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = DawamiTeal.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("👨‍💻", fontSize = 28.sp)
                    }
                }
                Text(
                    text = "التواصل مع مطور التطبيق",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = DawamiNavy,
                    textAlign = TextAlign.Center
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "اختر الوسيلة المفضلة لديك للتواصل مباشرة مع المهندس فيصل العفيف:",
                    fontSize = 13.sp,
                    color = Color.DarkGray,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
        },
        confirmButton = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. WhatsApp Normal
                Button(
                    onClick = {
                        onDismiss()
                        try {
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                data = android.net.Uri.parse("https://api.whatsapp.com/send?phone=$phoneNumber&text=" + android.net.Uri.encode(message))
                                setPackage("com.whatsapp")
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                    data = android.net.Uri.parse("https://wa.me/$phoneNumber?text=" + android.net.Uri.encode(message))
                                }
                                context.startActivity(intent)
                            } catch (ex: Exception) {
                                android.widget.Toast.makeText(context, "تطبيق واتساب غير مثبت", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("💬", fontSize = 16.sp)
                        Text("واتساب العادي (WhatsApp)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                // 2. WhatsApp Business
                Button(
                    onClick = {
                        onDismiss()
                        try {
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                data = android.net.Uri.parse("https://api.whatsapp.com/send?phone=$phoneNumber&text=" + android.net.Uri.encode(message))
                                setPackage("com.whatsapp.w4b")
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "تطبيق واتساب أعمال غير مثبت", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("💼", fontSize = 16.sp)
                        Text("واتساب أعمال (Business)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                // 3. Phone Call
                Button(
                    onClick = {
                        onDismiss()
                        try {
                            val intent = android.content.Intent(android.content.Intent.ACTION_DIAL).apply {
                                data = android.net.Uri.parse("tel:$phoneNumber")
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "لا يمكن إجراء الاتصال من هذا الجهاز", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("📞", fontSize = 16.sp)
                        Text("اتصال هاتفي مباشر (Call)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                // 4. Cancel
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color.Gray.copy(alpha = 0.5f))
                ) {
                    Text("إلغاء ❌", color = Color.DarkGray, fontSize = 13.sp)
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(24.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InlineExpandableDatePicker(
    selectedDate: String,
    onDateSelected: (String) -> Unit,
    label: String = "اختر التاريخ",
    modifier: Modifier = Modifier
) {
    var showDialog by remember { mutableStateOf(false) }
    val displayValue = if (selectedDate.isEmpty()) "لم يتم التحديد" else selectedDate

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable { showDialog = true }
            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp)),
        color = Color.Transparent,
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 5.dp)
        ) {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 9.sp, color = DawamiNavy, maxLines = 1)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.DateRange,
                    contentDescription = "اختر التاريخ",
                    tint = DawamiGold,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = displayValue,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = DawamiNavy,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }

    if (showDialog) {
        val datePickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedDateMillis = datePickerState.selectedDateMillis
                        if (selectedDateMillis != null) {
                            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                            val dateStr = sdf.format(java.util.Date(selectedDateMillis))
                            onDateSelected(dateStr)
                        }
                        showDialog = false
                    }
                ) {
                    Text("تأكيد", color = DawamiNavy, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("إلغاء", color = Color.Gray)
                }
            },
            colors = DatePickerDefaults.colors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            DatePicker(
                state = datePickerState,
                showModeToggle = false,
                title = null,
                headline = null,
                colors = DatePickerDefaults.colors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    selectedDayContainerColor = DawamiNavy,
                    selectedDayContentColor = Color.White,
                    todayContentColor = DawamiTeal,
                    todayDateBorderColor = DawamiTeal
                )
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InlineExpandableTimePicker(
    selectedTime: String,
    label: String,
    onTimeSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    var showDialog by remember { mutableStateOf(false) }
    val displayValue = if (selectedTime.isEmpty()) "لم يتم التحديد" else formatTimeTo12HourArabic(selectedTime)

    Box(
        modifier = modifier.clickable(enabled = enabled) { showDialog = true }
    ) {
        OutlinedTextField(
            value = displayValue,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, fontWeight = FontWeight.Bold, fontSize = 11.sp) },
            trailingIcon = {
                IconButton(onClick = { showDialog = true }, enabled = enabled) {
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = "اختر الوقت",
                        tint = if (enabled) DawamiGold else Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            textStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (enabled) DawamiNavy else Color.Gray),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = DawamiNavy,
                unfocusedBorderColor = Color(0xFFCBD5E1),
                focusedTextColor = DawamiNavy,
                unfocusedTextColor = DawamiNavy,
                disabledBorderColor = Color(0xFFE2E8F0),
                disabledLabelColor = Color.Gray,
                disabledTextColor = Color.Gray
            ),
            enabled = enabled
        )
    }

    if (showDialog) {
        val initialHour = if (selectedTime.isNotEmpty() && selectedTime.contains(":")) selectedTime.split(":")[0].toIntOrNull() ?: 8 else 8
        val initialMinute = if (selectedTime.isNotEmpty() && selectedTime.contains(":")) selectedTime.split(":")[1].toIntOrNull() ?: 0 else 0
        val timePickerState = rememberTimePickerState(
            initialHour = initialHour,
            initialMinute = initialMinute,
            is24Hour = false
        )

        AlertDialog(
            onDismissRequest = { showDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val formattedHour = String.format("%02d", timePickerState.hour)
                        val formattedMinute = String.format("%02d", timePickerState.minute)
                        onTimeSelected("$formattedHour:$formattedMinute")
                        showDialog = false
                    }
                ) {
                    Text("تأكيد", color = DawamiNavy, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("إلغاء", color = Color.Gray)
                }
            },
            title = {
                Text(
                    text = "اختر الوقت ⏰",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = DawamiNavy,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    TimePicker(
                        state = timePickerState,
                        colors = TimePickerDefaults.colors(
                            clockDialColor = Color(0xFFF1F5F9),
                            clockDialSelectedContentColor = Color.White,
                            clockDialUnselectedContentColor = DawamiNavy,
                            selectorColor = DawamiTeal,
                            periodSelectorBorderColor = DawamiNavy,
                            periodSelectorSelectedContainerColor = DawamiTeal.copy(alpha = 0.15f),
                            periodSelectorSelectedContentColor = DawamiNavy,
                            periodSelectorUnselectedContainerColor = Color.White,
                            periodSelectorUnselectedContentColor = Color.Gray,
                            timeSelectorSelectedContainerColor = DawamiTeal.copy(alpha = 0.15f),
                            timeSelectorSelectedContentColor = DawamiNavy,
                            timeSelectorUnselectedContainerColor = Color(0xFFF1F5F9),
                            timeSelectorUnselectedContentColor = Color.Gray
                        )
                    )
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

// Transient Flash Message Bar ("الرسالة الخاطفة")
@Composable
fun TransientFlashMessageBar(
    notification: com.example.data.entity.InAppNotification,
    onDismiss: () -> Unit,
    onOpenCenter: () -> Unit,
    isDark: Boolean = false
) {
    val bgColor = when (notification.type) {
        "warning" -> if (isDark) Color(0xFF854D0E) else Color(0xFFFEF3C7)
        "action" -> if (isDark) Color(0xFF1E3A8A) else Color(0xFFEFF6FF)
        "success" -> if (isDark) Color(0xFF065F46) else Color(0xFFD1FAE5)
        else -> if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9)
    }
    val borderColor = when (notification.type) {
        "warning" -> Color(0xFFF59E0B)
        "action" -> Color(0xFF3B82F6)
        "success" -> Color(0xFF10B981)
        else -> if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
    }
    val textColor = when (notification.type) {
        "warning" -> if (isDark) Color(0xFFFEF08A) else Color(0xFF78350F)
        "action" -> if (isDark) Color(0xFFBFDBFE) else Color(0xFF1E3A8A)
        "success" -> if (isDark) Color(0xFFA7F3D0) else Color(0xFF064E3B)
        else -> if (isDark) Color.White else Color(0xFF0F172A)
    }

    AnimatedVisibility(
        visible = true,
        enter = androidx.compose.animation.fadeIn() + androidx.compose.animation.slideInVertically(initialOffsetY = { -it }),
        exit = androidx.compose.animation.fadeOut() + androidx.compose.animation.slideOutVertically(targetOffsetY = { -it })
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .clickable { onOpenCenter() },
            shape = RoundedCornerShape(14.dp),
            color = bgColor,
            border = BorderStroke(1.dp, borderColor),
            shadowElevation = 6.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = borderColor.copy(alpha = 0.2f),
                    shape = CircleShape,
                    modifier = Modifier.size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = when (notification.type) {
                                "warning" -> "⚠️"
                                "action" -> "📝"
                                "success" -> "✅"
                                else -> "🔔"
                            },
                            fontSize = 13.sp
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = notification.title,
                        color = textColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = notification.message,
                        color = textColor.copy(alpha = 0.85f),
                        fontSize = 10.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = textColor,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

// Daily Tasks Floating Dialog ("المهام اليومية للدورات النشطة")
private data class DailyTaskItem(
    val id: String,
    val courseId: Int,
    val courseName: String,
    val title: String,
    val isCompleted: Boolean,
    val completionDetails: String,
    val targetScreen: Screen
)

@Composable
fun NotificationCenterDialog(
    viewModel: MainViewModel,
    isDark: Boolean = false
) {
    val showDialog by viewModel.showNotificationCenterDialog.collectAsState()
    val pendingActions by viewModel.pendingActions.collectAsState()
    val courses by viewModel.dbCourses.collectAsState()
    val attendance by viewModel.dbAttendance.collectAsState()
    val studentAttendance by viewModel.dbAllStudentAttendance.collectAsState()
    val isThursdayEnabled by viewModel.isThursdayNotificationsEnabled.collectAsState()
    val officialHolidays by viewModel.enabledOfficialHolidays.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(showDialog) {
        if (showDialog) {
            viewModel.checkAndEvaluatePendingActions()
        }
    }

    if (!showDialog) return

    val todayCalendar = remember { java.util.Calendar.getInstance() }
    val todayStr = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH).format(todayCalendar.time) }

    var selectedDateMillis by remember { mutableStateOf(System.currentTimeMillis()) }

    val selectedCalendar = remember(selectedDateMillis) {
        java.util.Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
    }

    val dateFormat = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH) }
    val selectedDateStr = remember(selectedDateMillis) { dateFormat.format(selectedCalendar.time) }

    val dayNameFormat = remember { java.text.SimpleDateFormat("EEEE", java.util.Locale("ar")) }
    val dayName = remember(selectedDateMillis) { dayNameFormat.format(selectedCalendar.time) }

    val holidayForSelectedDate = remember(selectedDateStr, officialHolidays) {
        officialHolidays.firstOrNull { h ->
            try {
                h.isEnabled && h.startDate.isNotBlank() && h.endDate.isNotBlank() &&
                selectedDateStr >= h.startDate && selectedDateStr <= h.endDate
            } catch (e: Exception) {
                false
            }
        }
    }

    // Filter active courses (endDate is empty or endDate >= selectedDateStr)
    val activeCourses = remember(courses, selectedDateStr) {
        courses.filter { course ->
            (course.startDate.isBlank() || course.startDate <= selectedDateStr) &&
            (course.endDate.isBlank() || course.endDate >= selectedDateStr)
        }
    }

    // State to track expanded course IDs for collapse & expand functionality
    var expandedCourseIds by remember(activeCourses) {
        mutableStateOf(activeCourses.map { it.id }.toSet())
    }

    val tasksList = remember(activeCourses, attendance, studentAttendance, selectedDateStr, selectedDateMillis, isThursdayEnabled, holidayForSelectedDate) {
        val list = mutableListOf<DailyTaskItem>()
        
        // Day of week rules
        val dayOfWeek = selectedCalendar.get(java.util.Calendar.DAY_OF_WEEK)
        val isFriday = (dayOfWeek == java.util.Calendar.FRIDAY)
        val isThursday = (dayOfWeek == java.util.Calendar.THURSDAY)
        
        // Thursday, Friday, and Official Holidays rules
        if (isFriday || (isThursday && !isThursdayEnabled) || holidayForSelectedDate != null) {
            return@remember emptyList<DailyTaskItem>()
        }

        activeCourses.forEach { course ->
            val trainerRecord = attendance.find { it.courseId == course.id && it.date == selectedDateStr }
            
            // Skip tasks for this course if trainer is absent or on leave
            if (trainerRecord != null && (trainerRecord.status == "غياب" || trainerRecord.status == "إجازة")) {
                return@forEach
            }

            val studentRecords = studentAttendance.filter { it.courseId == course.id && it.date == selectedDateStr }

            // 1. Trainer Check-in
            val trainerInDone = trainerRecord != null && trainerRecord.actualCheckIn.isNotBlank()
            list.add(
                DailyTaskItem(
                    id = "trainer_in_${course.id}",
                    courseId = course.id,
                    courseName = course.name,
                    title = "تسجيل حضور للمدرب (${course.name})",
                    isCompleted = trainerInDone,
                    completionDetails = if (trainerInDone) "تم تسجيل الدخول الساعة ${trainerRecord?.actualCheckIn}" else "بانتظار تسجيل الحضور",
                    targetScreen = Screen.Attendance
                )
            )

            // 2. Student Check-in
            val studentsInDone = studentRecords.any { it.actualCheckIn.isNotBlank() || it.status in listOf("حضور", "غياب", "إجازة") }
            list.add(
                DailyTaskItem(
                    id = "students_in_${course.id}",
                    courseId = course.id,
                    courseName = course.name,
                    title = "تسجيل حضور طلاب (${course.name})",
                    isCompleted = studentsInDone,
                    completionDetails = if (studentsInDone) "تم رصد تحضير الطلاب بنجاح" else "بانتظار رصد تحضير الطلاب",
                    targetScreen = Screen.StudentAttendance
                )
            )

            // 3. Trainer Check-out
            val trainerOutDone = trainerRecord != null && trainerRecord.actualCheckOut.isNotBlank()
            list.add(
                DailyTaskItem(
                    id = "trainer_out_${course.id}",
                    courseId = course.id,
                    courseName = course.name,
                    title = "تسجيل انصراف للمدرب (${course.name})",
                    isCompleted = trainerOutDone,
                    completionDetails = if (trainerOutDone) "تم تسجيل الانصراف الساعة ${trainerRecord?.actualCheckOut}" else "بانتظار تسجيل الانصراف",
                    targetScreen = Screen.Attendance
                )
            )

            // 4. Student Check-out
            val studentsOutDone = studentRecords.any { it.actualCheckOut.isNotBlank() }
            list.add(
                DailyTaskItem(
                    id = "students_out_${course.id}",
                    courseId = course.id,
                    courseName = course.name,
                    title = "تسجيل انصراف الطلاب (${course.name})",
                    isCompleted = studentsOutDone,
                    completionDetails = if (studentsOutDone) "تم رصد انصراف الطلاب بنجاح" else "بانتظار رصد انصراف الطلاب",
                    targetScreen = Screen.StudentAttendance
                )
            )
        }
        list
    }

    val completedCount = tasksList.count { it.isCompleted }
    val totalCount = tasksList.size
    val progressFraction = if (totalCount > 0) completedCount.toFloat() / totalCount.toFloat() else 1f

    androidx.compose.ui.window.Dialog(
        onDismissRequest = { viewModel.closeNotificationCenter() }
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(),
                shape = RoundedCornerShape(22.dp),
                color = if (isDark) DarkSurface else Color.White,
                tonalElevation = 8.dp,
                border = BorderStroke(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                color = DawamiNavy.copy(alpha = 0.12f),
                                shape = CircleShape,
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.FactCheck,
                                        contentDescription = null,
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = "شريط المهام اليومية للدورات النشطة ⏱️",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color.White else DawamiNavy
                                )
                                Text(
                                    text = "المنجز $completedCount من $totalCount • $selectedDateStr",
                                    fontSize = 11.sp,
                                    color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                                )
                            }
                        }

                        IconButton(
                            onClick = { viewModel.closeNotificationCenter() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                            )
                        }
                    }

                    // Smart Rescue Bar Banner (شريط الإنقاذ المباشر)
                    SmartRescueBanner(viewModel = viewModel, isDark = isDark)

                    // Date Navigation Bar
                    Surface(
                        color = if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Previous Day Button (اليوم السابق - right arrow in RTL layout)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        val cal = java.util.Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                                        cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
                                        selectedDateMillis = cal.timeInMillis
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowRight,
                                    contentDescription = "اليوم السابق",
                                    tint = DawamiTeal,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text("السابق", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                            }

                            // Current Date Display (Clickable to pick date)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        showDatePicker(context) { dateStr ->
                                            try {
                                                val parsed = dateFormat.parse(dateStr)
                                                if (parsed != null) {
                                                    selectedDateMillis = parsed.time
                                                }
                                            } catch (e: Exception) {
                                                // Ignore format error
                                            }
                                        }
                                    }
                                    .padding(horizontal = 6.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = "اختر التاريخ",
                                    tint = if (isDark) DawamiGold else DawamiNavy,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "$dayName $selectedDateStr",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color.White else DawamiNavy
                                )
                                if (selectedDateStr == todayStr) {
                                    Surface(
                                        color = DawamiTeal.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "اليوم",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiTeal,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                } else {
                                    Surface(
                                        color = DawamiGold.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.clickable {
                                            selectedDateMillis = System.currentTimeMillis()
                                        }
                                    ) {
                                        Text(
                                            text = "العودة لليوم ↺",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDark) DawamiGold else Color(0xFFB45309),
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }

                            // Next Day Button (اليوم التالي - left arrow in RTL layout)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        val cal = java.util.Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                                        cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                                        selectedDateMillis = cal.timeInMillis
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text("التالي", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowLeft,
                                    contentDescription = "اليوم التالي",
                                    tint = DawamiTeal,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Progress Bar
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        LinearProgressIndicator(
                            progress = progressFraction,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (progressFraction == 1f) Color(0xFF10B981) else DawamiGold,
                            trackColor = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)
                        )
                    }

                    // Expand / Collapse Action Controls
                    if (activeCourses.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "قائمة الدورات والمهام:",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(
                                    onClick = { expandedCourseIds = activeCourses.map { it.id }.toSet() },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Text("توسيع الكل 🔽", fontSize = 10.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)
                                }
                                TextButton(
                                    onClick = { expandedCourseIds = emptySet() },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Text("طي الكل 🔼", fontSize = 10.sp, color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B))
                                }
                            }
                        }
                    }

                    Divider(color = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))

                    if (activeCourses.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("🎓", fontSize = 32.sp)
                                Text(
                                    text = "لا توجد دورات نشطة في هذا التاريخ",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                                )
                                Text(
                                    text = "يتم إدراج مهام الدورات النشطة تلقائياً حسب تاريخ البدء والانتهاء",
                                    fontSize = 11.sp,
                                    color = if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
                                )
                            }
                        }
                    } else if (tasksList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("🏖️", fontSize = 32.sp)
                                
                                val dayOfWeek = selectedCalendar.get(java.util.Calendar.DAY_OF_WEEK)
                                val isFriday = (dayOfWeek == java.util.Calendar.FRIDAY)
                                val isThursday = (dayOfWeek == java.util.Calendar.THURSDAY)
                                
                                val reasonText = when {
                                    holidayForSelectedDate != null -> "لا توجد مهام رصد حركة لهذا اليوم (${holidayForSelectedDate.name}) - إجازة رسمية معتمدة 🌴"
                                    isFriday -> "لا توجد مهام رصد حركة يوم الجمعة (عطلة نهاية الأسبوع) 🌴"
                                    isThursday && !isThursdayEnabled -> "لا توجد مهام رصد حركة يوم الخميس (تم تعطيل تنبيهات يوم الخميس من الإعدادات) 📅"
                                    else -> "لا توجد مهام رصد حركة لهذا اليوم بسبب تسجيل غياب أو إجازة للمدربين 📝"
                                }
                                
                                Text(
                                    text = "المهام اليومية غير مطلوبة لهذا اليوم",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color.White else DawamiNavy,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Text(
                                    text = reasonText,
                                    fontSize = 11.sp,
                                    color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            activeCourses.forEach { course ->
                                val isExpanded = expandedCourseIds.contains(course.id)
                                val courseTasks = tasksList.filter { it.courseId == course.id }
                                val courseCompletedCount = courseTasks.count { it.isCompleted }
                                val courseTotalCount = courseTasks.size

                                item(key = "course_header_${course.id}") {
                                    Surface(
                                        color = if (isDark) {
                                            if (isExpanded) Color(0xFF1E293B) else Color(0xFF0F172A)
                                        } else {
                                            if (isExpanded) DawamiNavy.copy(alpha = 0.08f) else Color(0xFFF8FAFC)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(
                                            1.dp,
                                            if (isExpanded) DawamiTeal.copy(alpha = 0.5f) else if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                expandedCourseIds = if (isExpanded) {
                                                    expandedCourseIds - course.id
                                                } else {
                                                    expandedCourseIds + course.id
                                                }
                                            }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                                    contentDescription = if (isExpanded) "طي" else "توسيع",
                                                    tint = DawamiTeal,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Text(
                                                    text = "🎓 ${course.name}",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isDark) Color.White else DawamiNavy,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Surface(
                                                    color = if (courseCompletedCount == courseTotalCount && courseTotalCount > 0) {
                                                        Color(0xFF10B981).copy(alpha = 0.2f)
                                                    } else {
                                                        DawamiGold.copy(alpha = 0.2f)
                                                    },
                                                    shape = RoundedCornerShape(6.dp)
                                                ) {
                                                    Text(
                                                        text = "$courseCompletedCount / $courseTotalCount منجزة",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (courseCompletedCount == courseTotalCount && courseTotalCount > 0) {
                                                            Color(0xFF059669)
                                                        } else {
                                                            Color(0xFFD97706)
                                                        },
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                if (isExpanded) {
                                    items(courseTasks, key = { it.id }) { task ->
                                        DailyTaskRowItem(
                                            task = task,
                                            onTaskClick = {
                                                val targetCourse = activeCourses.find { it.id == task.courseId }
                                                if (targetCourse != null) {
                                                    if (task.id.startsWith("trainer_")) {
                                                        viewModel.selectCourseForAttendance(targetCourse)
                                                        viewModel.setAttendanceDate(selectedDateStr)
                                                        if (task.id.startsWith("trainer_out")) {
                                                            val studentOutTime = viewModel.getStudentCheckOutTimeForDate(targetCourse.id, selectedDateStr)
                                                            if (!studentOutTime.isNullOrBlank()) {
                                                                viewModel.attendanceCheckOutInput.value = studentOutTime
                                                                viewModel.onAttendanceTimeChanged()
                                                            }
                                                        } else if (task.id.startsWith("trainer_in")) {
                                                            val studentInTime = viewModel.getStudentCheckInTimeForDate(targetCourse.id, selectedDateStr)
                                                            if (!studentInTime.isNullOrBlank()) {
                                                                viewModel.attendanceCheckInInput.value = studentInTime
                                                                viewModel.onAttendanceTimeChanged()
                                                            }
                                                        }
                                                        viewModel.closeNotificationCenter()
                                                        viewModel.navigateTo(Screen.Attendance)
                                                    } else {
                                                        viewModel.selectCourseForStudentAttendance(targetCourse)
                                                        viewModel.selectCourseForStudents(targetCourse)
                                                        viewModel.setStudentAttendanceDate(selectedDateStr)
                                                        if (task.id.startsWith("students_out")) {
                                                            val trainerOutTime = viewModel.getTrainerCheckOutTimeForDate(targetCourse.id, selectedDateStr)
                                                            if (!trainerOutTime.isNullOrBlank()) {
                                                                viewModel.studentCheckOutTimeInput.value = trainerOutTime
                                                            }
                                                        } else if (task.id.startsWith("students_in")) {
                                                            val trainerInTime = viewModel.getTrainerCheckInTimeForDate(targetCourse.id, selectedDateStr)
                                                            if (!trainerInTime.isNullOrBlank()) {
                                                                viewModel.studentCheckInTimeInput.value = trainerInTime
                                                            }
                                                        }
                                                        viewModel.closeNotificationCenter()
                                                        viewModel.openStudentsGroup(0)
                                                    }
                                                } else {
                                                    viewModel.closeNotificationCenter()
                                                    viewModel.navigateTo(task.targetScreen)
                                                }
                                            },
                                            isDark = isDark
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { viewModel.closeNotificationCenter() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إغلاق", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun DailyTaskRowItem(
    task: DailyTaskItem,
    onTaskClick: () -> Unit,
    isDark: Boolean = false
) {
    val isDone = task.isCompleted
    val bg = if (isDone) {
        if (isDark) Color(0xFF064E3B).copy(alpha = 0.3f) else Color(0xFFECFDF5)
    } else {
        if (isDark) Color(0xFF1E293B) else Color(0xFFFFFBEB)
    }
    val borderColor = if (isDone) {
        Color(0xFF10B981).copy(alpha = 0.5f)
    } else {
        Color(0xFFF59E0B).copy(alpha = 0.5f)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onTaskClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = if (isDone) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFFF59E0B).copy(alpha = 0.2f),
                shape = CircleShape,
                modifier = Modifier.size(30.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = if (isDone) "✅" else "⏳",
                        fontSize = 13.sp
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDone) {
                        if (isDark) Color(0xFFA7F3D0) else Color(0xFF065F46)
                    } else {
                        if (isDark) Color.White else Color(0xFF92400E)
                    }
                )
                Text(
                    text = task.completionDetails,
                    fontSize = 10.5.sp,
                    color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                )
            }

            if (isDone) {
                Surface(
                    color = Color(0xFF10B981).copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "منجزة 👍",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF059669),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            } else {
                FilledTonalButton(
                    onClick = onTaskClick,
                    modifier = Modifier.height(28.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("إنجاز 👈", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun NotificationCardItem(
    notification: com.example.data.entity.InAppNotification,
    onReadClick: () -> Unit,
    onActionClick: () -> Unit,
    isDark: Boolean = false
) {
    val isRead = notification.isRead
    val cardBg = if (isRead) {
        if (isDark) Color(0xFF1E293B).copy(alpha = 0.5f) else Color(0xFFF8FAFC)
    } else {
        if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                if (!isRead) onReadClick()
            },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = BorderStroke(
            1.dp,
            if (!isRead) DawamiGold.copy(alpha = 0.5f) else (if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = when (notification.type) {
                    "warning" -> Color(0xFFEF4444).copy(alpha = 0.15f)
                    "action" -> DawamiNavy.copy(alpha = 0.12f)
                    "success" -> Color(0xFF10B981).copy(alpha = 0.15f)
                    else -> DawamiGold.copy(alpha = 0.15f)
                },
                shape = CircleShape,
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = when (notification.type) {
                            "warning" -> "⚠️"
                            "action" -> "📝"
                            "success" -> "✅"
                            else -> "🔔"
                        },
                        fontSize = 14.sp
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = notification.title,
                        fontSize = 12.sp,
                        fontWeight = if (!isRead) FontWeight.Bold else FontWeight.Medium,
                        color = if (isDark) Color.White else Color(0xFF0F172A)
                    )
                    if (!isRead) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(Color(0xFFE11D48), CircleShape)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = notification.message,
                    fontSize = 10.5.sp,
                    color = if (isDark) Color(0xFF94A3B8) else Color(0xFF475569),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (notification.actionType != null) {
                FilledTonalButton(
                    onClick = onActionClick,
                    modifier = Modifier.height(30.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("انتقال 👈", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

object FunnyPenaltyHelper {
    val defaultPenalties = listOf(
        "🧃 إحضار كرتون عصير عالي الجودة للزملاء في القاعة",
        "📜 إلقاء قصيدة مدح وثناء صريحة في أستاذ المادة أمام الجميع",
        "🍩 إحضار طبق دونات أو حلويات طازجة لمشاركتها مع الفصل",
        "🧮 حل 5 مسائل إضافية على السبورة ومناقشتها بصوت عالٍ",
        "🧽 مسح وتنظيف وتنسيق السبورة بعناية للأسبوع القادم",
        "☕ إحضار دلة قهوة عربية ومعمول فاخر لجميع الطلاب والمدرب",
        "👨‍🏫 شرح الدرس القادم لمدة 5 دقائق كاملة أمام زملائه بكل ثقة",
        "⏱️ الوقوف لمدة دقيقة كاملة احتراماً لزملائه الحاضرين في الوقت",
        "📄 توزيع الأوراق والأنشطة والكتب على جميع الطلاب لمدة أسبوع",
        "🎤 تقديم اعتذار رسمي وخطابي حماسي ومضحك للدفعة بأكملها",
        "🍰 إحضار طبق حلا بيتوت أو كيك يشاركه مع زملائه الطلاب",
        "🎙️ قراءة فقرة من المادة بصوت جهوري وبأسلوب مذيع الأخبار",
        "🖊️ شراء علبة أقلام سبورة جديدة وألوان متنوعة للقسم",
        "🪑 ترتيب وترقيم طاولات وكراسي القاعة قبل بداية الحصة القادمة"
    )

    fun getPenalties(context: android.content.Context? = null): List<String> {
        if (context == null) return defaultPenalties
        val prefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
        val jsonStr = prefs.getString("custom_funny_penalties", null)
        if (jsonStr.isNullOrEmpty()) return defaultPenalties
        return try {
            val jsonArray = org.json.JSONArray(jsonStr)
            val list = mutableListOf<String>()
            for (i in 0 until jsonArray.length()) {
                list.add(jsonArray.getString(i))
            }
            if (list.isEmpty()) defaultPenalties else list
        } catch (e: Exception) {
            defaultPenalties
        }
    }

    fun savePenalties(context: android.content.Context, penalties: List<String>) {
        val prefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
        val jsonArray = org.json.JSONArray()
        penalties.forEach { jsonArray.put(it) }
        prefs.edit().putString("custom_funny_penalties", jsonArray.toString()).apply()
    }

    fun addPenalty(context: android.content.Context, penalty: String): List<String> {
        val trimmed = penalty.trim()
        if (trimmed.isEmpty()) return getPenalties(context)
        val current = getPenalties(context).toMutableList()
        current.add(0, trimmed)
        savePenalties(context, current)
        return current
    }

    fun updatePenalty(context: android.content.Context, index: Int, newText: String): List<String> {
        val trimmed = newText.trim()
        if (trimmed.isEmpty()) return getPenalties(context)
        val current = getPenalties(context).toMutableList()
        if (index in current.indices) {
            current[index] = trimmed
            savePenalties(context, current)
        }
        return current
    }

    fun deletePenalty(context: android.content.Context, index: Int): List<String> {
        val current = getPenalties(context).toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            savePenalties(context, current)
        }
        return current
    }

    fun resetToDefault(context: android.content.Context): List<String> {
        val prefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
        prefs.edit().remove("custom_funny_penalties").apply()
        return defaultPenalties
    }

    fun getRandomPenalty(context: android.content.Context? = null): String {
        val list = getPenalties(context)
        return if (list.isNotEmpty()) list.random() else defaultPenalties.random()
    }
}

@Composable
fun FunnyPenaltyManagerDialog(
    onDismiss: () -> Unit,
    viewModel: com.example.ui.viewmodel.MainViewModel? = null
) {
    val context = LocalContext.current
    var penalties by remember { mutableStateOf(FunnyPenaltyHelper.getPenalties(context)) }
    var newPenaltyText by remember { mutableStateOf("") }
    var editingIndex by remember { mutableStateOf<Int?>(null) }
    var editingText by remember { mutableStateOf("") }

    if (editingIndex != null) {
        val idx = editingIndex!!
        val originalText = penalties.getOrNull(idx) ?: ""
        AlertDialog(
            onDismissRequest = { editingIndex = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = DawamiNavy)
                    Text(
                        text = "تعديل العقوبة الفكاهية ✏️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("قم بتعديل نص العقوبة الفكاهية:", fontSize = 10.5.sp, color = Color.Gray)
                    OutlinedTextField(
                        value = editingText,
                        onValueChange = { editingText = it },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(fontSize = 11.5.sp),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editingText.isNotBlank()) {
                            penalties = FunnyPenaltyHelper.updatePenalty(context, idx, editingText)
                            viewModel?.logActivity(
                                category = "SYSTEM",
                                actionType = "UPDATE",
                                title = "تعديل عقوبة فكاهية 🎭",
                                description = "السابقة: $originalText | الجديدة: $editingText"
                            )
                            editingIndex = null
                            Toast.makeText(context, "تم حفظ التعديل بنجاح 💾", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("حفظ التعديل 💾", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 11.sp)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { editingIndex = null },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("إلغاء", fontSize = 11.sp)
                }
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("🎭", fontSize = 20.sp)
                Text(
                    text = "إدارة وتخصيص قائمة العقوبات الفكاهية",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = DawamiNavy
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 440.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "يمكنك إضافة عقوبات جديدة، أو تعديل وحذف العقوبات الحالية بكل سهولة:",
                    fontSize = 10.5.sp,
                    color = Color.Gray
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newPenaltyText,
                        onValueChange = { newPenaltyText = it },
                        placeholder = { Text("اكتب عقوبة فكاهية جديدة...", fontSize = 10.sp) },
                        modifier = Modifier.weight(1f),
                        textStyle = TextStyle(fontSize = 11.sp),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Button(
                        onClick = {
                            if (newPenaltyText.isNotBlank()) {
                                penalties = FunnyPenaltyHelper.addPenalty(context, newPenaltyText)
                                viewModel?.logActivity(
                                    category = "SYSTEM",
                                    actionType = "CREATE",
                                    title = "إضافة عقوبة فكاهية جديدة 🎭",
                                    description = "العقوبة: $newPenaltyText"
                                )
                                newPenaltyText = ""
                                Toast.makeText(context, "تمت إضافة العقوبة الفكاهية ➕", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("إضافة ➕", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                Divider(color = Color.LightGray.copy(alpha = 0.3f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "القائمة المعتمدة (${penalties.size} عقوبة):",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )

                    TextButton(
                        onClick = {
                            penalties = FunnyPenaltyHelper.resetToDefault(context)
                            viewModel?.logActivity(
                                category = "SYSTEM",
                                actionType = "WIPE",
                                title = "إعادة ضبط العقوبات الفكاهية 🔄",
                                description = "تمت إعادة تعيين جميع العقوبات الفكاهية إلى القائمة الافتراضية"
                            )
                            Toast.makeText(context, "تمت إعادة الضبط للوضع الافتراضي 🔄", Toast.LENGTH_SHORT).show()
                        },
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("إعادة الضبط 🔄", fontSize = 10.sp, color = DawamiTeal)
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(penalties) { index, penalty ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)),
                            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = penalty,
                                    fontSize = 11.sp,
                                    modifier = Modifier.weight(1f),
                                    color = Color.DarkGray
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    IconButton(
                                        onClick = {
                                            editingIndex = index
                                            editingText = penalty
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "تعديل",
                                            tint = DawamiNavy,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            val deletedText = penalties.getOrNull(index) ?: ""
                                            penalties = FunnyPenaltyHelper.deletePenalty(context, index)
                                            viewModel?.logActivity(
                                                category = "SYSTEM",
                                                actionType = "DELETE",
                                                title = "حذف عقوبة فكاهية 🎭",
                                                description = "العقوبة المحذوفة: $deletedText"
                                            )
                                            Toast.makeText(context, "تم حذف العقوبة 🗑️", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "حذف",
                                            tint = Color.Red.copy(alpha = 0.7f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("تم 🎯", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 11.sp)
            }
        }
    )
}

@Composable
fun FunnyPenaltyDialog(
    studentName: String,
    onDismiss: () -> Unit,
    onApplyPenalty: (String) -> Unit
) {
    val context = LocalContext.current
    var currentPenalty by remember { mutableStateOf(FunnyPenaltyHelper.getRandomPenalty(context)) }
    var showManager by remember { mutableStateOf(false) }

    if (showManager) {
        FunnyPenaltyManagerDialog(
            onDismiss = {
                showManager = false
                currentPenalty = FunnyPenaltyHelper.getRandomPenalty(context)
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("🎭", fontSize = 20.sp)
                Text(
                    text = "عقوبة فكاهية عشوائية",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = DawamiNavy
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    color = DawamiNavy.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "الطالب المخالف: $studentName",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp,
                        color = DawamiNavy,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFF59E0B))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "العقوبة الفكاهية المقترحة: 🎲",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB45309)
                        )
                        Text(
                            text = currentPenalty,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF78350F),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(
                        onClick = { currentPenalty = FunnyPenaltyHelper.getRandomPenalty(context) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, DawamiTeal)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("سحب عقوبة أخرى 🎲", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                    }

                    OutlinedButton(
                        onClick = { showManager = true },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, DawamiNavy)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إدارة ⚙️", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onApplyPenalty(currentPenalty)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("تطبيق وإضافة للملاحظة 📝", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 11.sp)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("إلغاء", fontSize = 11.sp)
            }
        }
    )
}

@Composable
fun SmartRescueBanner(
    viewModel: com.example.ui.viewmodel.MainViewModel,
    isDark: Boolean = false,
    modifier: Modifier = Modifier
) {
    val pendingActions by viewModel.pendingActions.collectAsState()
    var isExpanded by remember { mutableStateOf(false) }

    if (pendingActions.isEmpty()) return

    Surface(
        color = if (isDark) Color(0xFF451A03) else Color(0xFFFEF3C7),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFFF59E0B)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = null,
                        tint = Color(0xFFD97706),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "🚨 شريط الإنقاذ: (${pendingActions.size}) حركات معلقة!",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color(0xFFFDE68A) else Color(0xFF92400E)
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color(0xFFD97706),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable { viewModel.batchResolveAllPendingRescueActions() }
                    ) {
                        Text(
                            text = "⚡ حل الكل بنقرة واحدة",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }

                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "عرض التفاصيل",
                            tint = Color(0xFFD97706)
                        )
                    }
                }
            }

            Text(
                text = "توجد حركات انصراف أو تحضير غير مكتملة عبر الأيام. انقر للتفاصيل أو حل الكل بنقرة واحدة.",
                fontSize = 10.5.sp,
                color = if (isDark) Color(0xFFFEF3C7) else Color(0xFF78350F)
            )

            if (isExpanded) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    pendingActions.take(5).forEach { item ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDark) Color(0xFF1E293B) else Color.White
                            ),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.title,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color.White else DawamiNavy,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = item.courseName,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiTeal
                                    )
                                }
                                Text(
                                    text = item.description,
                                    fontSize = 10.sp,
                                    color = if (isDark) Color(0xFFCBD5E1) else Color(0xFF475569)
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (!item.suggestedCheckOutTime.isNullOrBlank()) {
                                        Surface(
                                            color = DawamiNavy,
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.clickable {
                                                viewModel.resolvePendingActionItem(item, item.suggestedCheckOutTime)
                                            }
                                        ) {
                                            Text(
                                                text = "🎓 اعتماد وقت الطلاب (${item.suggestedCheckOutTime})",
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.5.dp)
                                            )
                                        }
                                    } else if (!item.suggestedCheckInTime.isNullOrBlank()) {
                                        Surface(
                                            color = DawamiNavy,
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.clickable {
                                                viewModel.resolvePendingActionItem(item, item.suggestedCheckInTime)
                                            }
                                        ) {
                                            Text(
                                                text = "🎓 اعتماد وقت الحضور (${item.suggestedCheckInTime})",
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.5.dp)
                                            )
                                        }
                                    }

                                    Surface(
                                        color = DawamiTeal,
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.clickable {
                                            viewModel.resolvePendingActionItem(item, null)
                                        }
                                    ) {
                                        Text(
                                            text = "⏱️ التوقيت الرسمي",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.5.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GranularResetDialog(
    title: String = "خيارات إعادة التعيين 🔄",
    subtitle: String = "حدد نوع العملية المراد تنفيذها بدقة:",
    onDismiss: () -> Unit,
    onResetAttendanceOnly: () -> Unit,
    onResetDepartureOnly: () -> Unit,
    onResetAll: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = Color(0xFFEF4444).copy(alpha = 0.15f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.padding(6.dp).size(22.dp)
                    )
                }
                Column {
                    Text(
                        text = title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Option 1: Reset Attendance Only
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onResetAttendanceOnly() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    border = BorderStroke(1.dp, Color(0xFF86EFAC))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = Color(0xFF16A34A),
                            shape = CircleShape,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AccessTime,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "إعادة تعيين الحضور فقط 🟢",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D)
                            )
                            Text(
                                text = "مسح وقت وتأخير الحضور مع إبقاء الانصراف والتقييمات",
                                fontSize = 10.sp,
                                color = Color(0xFF166534)
                            )
                        }
                    }
                }

                // Option 2: Reset Departure Only
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onResetDepartureOnly() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                    border = BorderStroke(1.dp, Color(0xFF93C5FD))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = Color(0xFF2563EB),
                            shape = CircleShape,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.ExitToApp,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "إعادة تعيين الانصراف فقط 🔵",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1D4ED8)
                            )
                            Text(
                                text = "مسح وقت وفارق الانصراف مع إبقاء الحضور والتقييمات",
                                fontSize = 10.sp,
                                color = Color(0xFF1E40AF)
                            )
                        }
                    }
                }

                // Option 3: Reset All
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onResetAll() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    border = BorderStroke(1.dp, Color(0xFFFCA5A5))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = Color(0xFFDC2626),
                            shape = CircleShape,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "إعادة تعيين الكل بالكامل 🔴",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB91C1C)
                            )
                            Text(
                                text = "تصفير وحذف سجل التحضير كاملاً (حضور وانصراف)",
                                fontSize = 10.sp,
                                color = Color(0xFF991B1B)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء ❌", color = Color.Gray, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        },
        shape = RoundedCornerShape(16.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )
}

/**
 * شريط التنقل العصري الموحد بين الأيام (Modern Day Navigator)
 * مصمم لتسهيل التنقل بين التواريخ المسجلة والعودة السريعة لليوم الحالي.
 */
@Composable
fun ModernDayNavigator(
    currentDate: String,
    todayDate: String,
    recordedDates: List<String>,
    onDateSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    currentDayName: String = "",
    enabled: Boolean = true,
    courseEndDate: String? = null
) {
    val context = LocalContext.current
    val prevDate = remember(recordedDates, currentDate) {
        recordedDates.lastOrNull { it < currentDate }
    }
    val nextDate = remember(recordedDates, currentDate, courseEndDate, todayDate) {
        recordedDates.firstOrNull { 
            it > currentDate && 
            it <= todayDate && 
            (courseEndDate.isNullOrEmpty() || it <= courseEndDate)
        }
    }

    val isPrevEnabled = enabled && prevDate != null
    val isNextEnabled = enabled && nextDate != null
    val isToday = currentDate == todayDate

    val resolvedDayName = remember(currentDate, currentDayName) {
        if (currentDayName.isNotEmpty()) currentDayName
        else {
            try {
                val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                val d = sdf.parse(currentDate)
                if (d != null) {
                    java.text.SimpleDateFormat("EEEE", java.util.Locale("ar")).format(d)
                } else ""
            } catch (_: Exception) {
                ""
            }
        }
    }

    val hasRecords = remember(recordedDates, currentDate) {
        recordedDates.contains(currentDate)
    }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, if (isToday) DawamiTeal.copy(alpha = 0.35f) else DawamiNavy.copy(alpha = 0.18f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Previous Day Button (اليوم السابق ➡️)
            Surface(
                onClick = {
                    if (prevDate != null) onDateSelected(prevDate)
                },
                enabled = isPrevEnabled,
                shape = RoundedCornerShape(10.dp),
                color = if (isPrevEnabled) DawamiNavy.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                border = BorderStroke(
                    1.dp,
                    if (isPrevEnabled) DawamiNavy.copy(alpha = 0.25f) else Color.Transparent
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "اليوم السابق",
                        tint = if (isPrevEnabled) DawamiNavy else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "السابق",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPrevEnabled) DawamiNavy else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            // Center Active Day Hub (مركز اليوم النشط)
            Surface(
                onClick = {
                    if (enabled) {
                        showDatePicker(context) { chosenDate ->
                            onDateSelected(chosenDate)
                        }
                    }
                },
                shape = RoundedCornerShape(10.dp),
                color = when {
                    isToday -> DawamiTeal.copy(alpha = 0.12f)
                    hasRecords -> DawamiNavy.copy(alpha = 0.07f)
                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                },
                border = BorderStroke(
                    1.dp,
                    when {
                        isToday -> DawamiTeal.copy(alpha = 0.5f)
                        hasRecords -> DawamiNavy.copy(alpha = 0.25f)
                        else -> Color(0xFFCBD5E1)
                    }
                ),
                modifier = Modifier
                    .weight(1.8f)
                    .height(42.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        Icon(
                            imageVector = if (isToday) Icons.Default.DateRange else Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = if (isToday) DawamiTeal else DawamiNavy,
                            modifier = Modifier.size(15.dp)
                        )
                        Column(
                            verticalArrangement = Arrangement.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = resolvedDayName.ifEmpty { "اليوم" },
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 11.5.sp,
                                    color = if (isToday) DawamiTeal else DawamiNavy,
                                    maxLines = 1
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = when {
                                        isToday -> DawamiTeal
                                        hasRecords -> Color(0xFF059669)
                                        else -> Color.Gray.copy(alpha = 0.6f)
                                    }
                                ) {
                                    Text(
                                        text = when {
                                            isToday -> "اليوم"
                                            hasRecords -> "مسجل ✓"
                                            else -> "سجل"
                                        },
                                        color = Color.White,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Text(
                                text = currentDate,
                                fontSize = 9.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }

                    // Fast Jump to Today button if viewing past date
                    if (!isToday && enabled) {
                        Surface(
                            onClick = {
                                onDateSelected(todayDate)
                            },
                            shape = RoundedCornerShape(6.dp),
                            color = DawamiTeal,
                            modifier = Modifier.padding(start = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = "⚡ اليوم",
                                    fontSize = 9.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // Next Day Button (اليوم التالي ⬅️)
            Surface(
                onClick = {
                    if (nextDate != null) onDateSelected(nextDate)
                },
                enabled = isNextEnabled,
                shape = RoundedCornerShape(10.dp),
                color = if (isNextEnabled) DawamiNavy.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                border = BorderStroke(
                    1.dp,
                    if (isNextEnabled) DawamiNavy.copy(alpha = 0.25f) else Color.Transparent
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "التالي",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isNextEnabled) DawamiNavy else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f),
                        maxLines = 1,
                        softWrap = false
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "اليوم التالي",
                        tint = if (isNextEnabled) DawamiNavy else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubjectSelectionBottomSheet(
    currentCourse: Course,
    allSubjects: List<Subject>,
    courseSubjectStats: List<CourseSubjectStat>,
    courseCrossRefs: List<CourseSubjectCrossRef>,
    selectedSubjectName: String,
    onSelectSubject: (Subject) -> Unit,
    onDismiss: () -> Unit
) {
    val currentCourseId = currentCourse.id
    val courseSubjectIds = remember(courseCrossRefs) { courseCrossRefs.map { it.subjectId }.toSet() }

    val rawSubjectsToSelect = remember(currentCourse, allSubjects, courseSubjectIds) {
        allSubjects.filter { sub ->
            sub.id in courseSubjectIds ||
            (currentCourse.diplomaName.isNotEmpty() && sub.diplomaName.equals(currentCourse.diplomaName, ignoreCase = true))
        }.sortedWith(compareBy<com.example.data.entity.Subject> { com.example.data.entity.StudentGradeConfig.getSubjectRank(it.name) }.thenBy { it.name })
    }

    val activeSubjectsToSelect = remember(rawSubjectsToSelect, courseSubjectStats, courseCrossRefs) {
        rawSubjectsToSelect.filter { sub ->
            val ref = courseCrossRefs.find { it.subjectId == sub.id }
            val stat = courseSubjectStats.find { it.subjectId == sub.id || it.subjectName.trim().equals(sub.name.trim(), ignoreCase = true) }
            val status = stat?.status ?: ref?.status ?: "قيد التدريس"
            !(status == "مكتملة التدريس" || status == "مكتملة بالكامل" || status == "في انتظار الاختبار" || status.contains("مكتمل"))
        }
    }

    var showCompletedSubjects by remember { mutableStateOf(false) }
    val sheetCompletedCount = remember(rawSubjectsToSelect, activeSubjectsToSelect) {
        (rawSubjectsToSelect.size - activeSubjectsToSelect.size).coerceAtLeast(0)
    }

    val listToDisplay = if (showCompletedSubjects || activeSubjectsToSelect.isEmpty()) rawSubjectsToSelect else activeSubjectsToSelect

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 32.dp)
        ) {
            // Top Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = DawamiTeal.copy(alpha = 0.12f),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = DawamiTeal,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            text = "اختر المادة التدريسية",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = DawamiNavy
                        )
                        Text(
                            text = "دورة: ${currentCourse.name}",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Filter Bar inside BottomSheet
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        showCompletedSubjects = !showCompletedSubjects
                    }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Checkbox(
                            checked = showCompletedSubjects,
                            onCheckedChange = { showCompletedSubjects = it },
                            colors = CheckboxDefaults.colors(checkedColor = DawamiNavy),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = if (sheetCompletedCount > 0) "إظهار المواد المكتملة 🏁 ($sheetCompletedCount)" else "إظهار المواد المكتملة 🏁",
                            fontSize = 11.sp,
                            fontWeight = if (showCompletedSubjects) FontWeight.Bold else FontWeight.Normal,
                            color = if (showCompletedSubjects) DawamiNavy else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "${listToDisplay.size} مادة متاحة",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiTeal
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (listToDisplay.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد مواد متاحة حالياً للعرض",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                // List of Subjects
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(listToDisplay) { subject ->
                        val ref = courseCrossRefs.find { it.subjectId == subject.id }
                        val stat = courseSubjectStats.find { it.subjectId == subject.id || it.subjectName.trim().equals(subject.name.trim(), ignoreCase = true) }
                        val isCompleted = stat?.status?.contains("مكتمل") == true || ref?.status == "مكتملة التدريس" || ref?.status == "مكتملة بالكامل" || ref?.status == "في انتظار الاختبار"
                        val taughtDays = stat?.taughtDaysCount ?: 0
                        val targetDays = if ((stat?.targetDays ?: 0) > 0) stat!!.targetDays else if ((ref?.targetDays ?: 0) > 0) ref!!.targetDays else 5
                        val isSelected = subject.name.trim().equals(selectedSubjectName.trim(), ignoreCase = true)
                        val isLinked = subject.id in courseSubjectIds ||
                                (currentCourse.diplomaName.isNotEmpty() && subject.diplomaName.equals(currentCourse.diplomaName, ignoreCase = true))

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectSubject(subject)
                                },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    isSelected -> DawamiTeal.copy(alpha = 0.12f)
                                    isCompleted -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                    else -> MaterialTheme.colorScheme.surface
                                }
                            ),
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = when {
                                    isSelected -> DawamiTeal
                                    isCompleted -> Color(0xFF10B981).copy(alpha = 0.35f)
                                    else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                }
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = when {
                                                isSelected -> Icons.Default.CheckCircle
                                                isCompleted -> Icons.Default.TaskAlt
                                                else -> Icons.Default.MenuBook
                                            },
                                            contentDescription = null,
                                            tint = when {
                                                isSelected -> DawamiTeal
                                                isCompleted -> Color(0xFF059669)
                                                else -> DawamiNavy
                                            },
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Text(
                                            text = subject.name,
                                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (isSelected) {
                                            Surface(
                                                color = DawamiTeal,
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    "المحددة حالياً",
                                                    color = Color.White,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        if (isLinked) {
                                            Surface(
                                                color = DawamiNavy.copy(alpha = 0.10f),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    "مرتبطة بالدورة",
                                                    color = DawamiNavy,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                val statusText = when {
                                    isCompleted -> "✓ مكتملة التدريس (تم تدريس: $taughtDays يوم)"
                                    targetDays > 0 -> "🟢 قيد التدريس • الأيام المنجزة: $taughtDays من $targetDays • المتبقي: ${kotlin.math.max(0, targetDays - taughtDays)} أيام"
                                    taughtDays > 0 -> "🟢 قيد التدريس • الأيام المنجزة: $taughtDays يوم"
                                    else -> "⚪ لم تبدأ بعد • الخطة المجدولة: ${if (targetDays > 0) "$targetDays أيام" else "غير محددة"}"
                                }
                                Text(
                                    text = statusText,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (isCompleted) Color(0xFF059669) else DawamiTeal
                                )

                                if (targetDays > 0) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    val progressFraction = (taughtDays.toFloat() / targetDays.toFloat()).coerceIn(0f, 1f)
                                    LinearProgressIndicator(
                                        progress = progressFraction,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(4.dp)
                                            .clip(RoundedCornerShape(2.dp)),
                                        color = if (isCompleted) Color(0xFF059669) else DawamiTeal,
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


