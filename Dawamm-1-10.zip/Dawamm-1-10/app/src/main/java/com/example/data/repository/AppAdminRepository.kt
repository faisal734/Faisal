package com.example.data.repository

import com.example.data.dao.TrainerTransactionDao
import com.example.data.dao.AppActivityLogDao
import com.example.data.entity.TrainerTransaction
import com.example.data.entity.AppActivityLog
import kotlinx.coroutines.flow.Flow

/**
 * AppAdminRepository: مسؤول عن العمليات الإدارية وسجلات النظام وسجلات العهد والمالية للمدرب.
 */
class AppAdminRepository(
    private val trainerTransactionDao: TrainerTransactionDao,
    private val appActivityLogDao: AppActivityLogDao
) {
    val allTrainerTransactions: Flow<List<TrainerTransaction>> = trainerTransactionDao.getAllTransactions()
    val allActivityLogs: Flow<List<AppActivityLog>> = appActivityLogDao.getAllLogs()

    // Trainer Transactions
    suspend fun insertTrainerTransaction(tx: TrainerTransaction): Long = trainerTransactionDao.insertTransaction(tx)
    suspend fun updateTrainerTransaction(tx: TrainerTransaction) = trainerTransactionDao.updateTransaction(tx)
    suspend fun deleteTrainerTransaction(tx: TrainerTransaction) = trainerTransactionDao.deleteTransaction(tx)
    suspend fun deleteAllTrainerTransactions() = trainerTransactionDao.deleteAll()

    // Activity Logs
    suspend fun insertActivityLog(log: AppActivityLog): Long = appActivityLogDao.insertLog(log)
    suspend fun insertActivityLogs(logs: List<AppActivityLog>) = appActivityLogDao.insertLogs(logs)
    suspend fun deleteActivityLog(log: AppActivityLog) = appActivityLogDao.deleteLog(log)
    suspend fun deleteAllActivityLogs() = appActivityLogDao.deleteAllLogs()
}
