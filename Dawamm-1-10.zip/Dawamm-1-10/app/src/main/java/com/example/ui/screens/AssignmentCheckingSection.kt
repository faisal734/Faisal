package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentAssignmentSubmission
import com.example.data.entity.SubjectAssignmentTemplate
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

private fun fmtScore(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else String.format(java.util.Locale.US, "%.1f", v)

private fun getTaskType(title: String, type: String = ""): String {
    if (type.isNotBlank()) {
        if (type.contains("مشروع") || type.contains("عملي")) return "مشروع عملي"
        if (type.contains("بحث") || type.contains("نظري") || type.contains("واجب") || type.contains("تكليف")) return "بحث نظري"
        return type
    }
    return when {
        title.contains("مشروع") || title.contains("عملي") -> "مشروع عملي"
        else -> "بحث نظري"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignmentCheckingSection(
    viewModel: MainViewModel,
    isDarkTheme: Boolean,
    courses: List<Course>,
    allStudents: List<Student>,
    assignmentTemplates: List<SubjectAssignmentTemplate>,
    assignmentSubmissions: List<StudentAssignmentSubmission>,
    courseViewModel: CourseViewModel? = null
) {
    val subjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()
    val showCompletedCourses by viewModel.showCompletedCoursesInDropdowns.collectAsState()
    val courseGradingModes by viewModel.courseGradingModes.collectAsState()
    
    val allDiplomas = remember(courses) { courses.map { it.diplomaName }.distinct().filter { it.isNotBlank() } }
    var selectedDiplomaForCheck by remember { mutableStateOf(allDiplomas.firstOrNull() ?: "") }
    
    LaunchedEffect(allDiplomas) {
        if (!allDiplomas.contains(selectedDiplomaForCheck)) {
            selectedDiplomaForCheck = allDiplomas.firstOrNull() ?: ""
        }
    }
    
    val filteredCourses = remember(selectedDiplomaForCheck, courses, showCompletedCourses) { 
        courses.filter { 
            val diplomaMatch = it.diplomaName == selectedDiplomaForCheck 
            val completedMatch = showCompletedCourses || !it.isCompleted
            diplomaMatch && completedMatch
        } 
    }
    var selectedCourseForCheck by remember { mutableStateOf<Course?>(filteredCourses.firstOrNull()) }
    
    LaunchedEffect(filteredCourses) {
        if (!filteredCourses.any { it.id == selectedCourseForCheck?.id }) {
            selectedCourseForCheck = filteredCourses.firstOrNull()
        }
    }
    
    val filteredSubjects = remember(selectedDiplomaForCheck, subjects) { subjects.filter { it.diplomaName == selectedDiplomaForCheck } } 
    var selectedSubjectForCheck by remember { mutableStateOf<String?>(filteredSubjects.firstOrNull()?.name) }
    
    LaunchedEffect(filteredSubjects) {
        if (!filteredSubjects.map { it.name }.contains(selectedSubjectForCheck)) {
            selectedSubjectForCheck = filteredSubjects.firstOrNull()?.name
        }
    }
    
    val activeCourseStudents = remember(selectedCourseForCheck, allStudents) { 
        selectedCourseForCheck?.let { course -> allStudents.filter { it.courseId == course.id } } ?: emptyList()
    }
    var selectedStudentForCheck by remember { mutableStateOf<Student?>(null) }
    
    val expandedStudents = remember { mutableStateMapOf<Int, Boolean>() }
    val context = LocalContext.current

    val trainerBaseDirUri by viewModel.trainerBaseDirUri.collectAsState()
    var projectSearchQuery by remember { mutableStateOf("") }
    var tempAttachmentPath by remember { mutableStateOf("") }
    var tempAttachmentName by remember { mutableStateOf("") }

    val selectAttachmentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val copied = handleFileSelection(context, uri, isReference = false, baseDirUriString = trainerBaseDirUri)
            if (copied != null) {
                tempAttachmentPath = copied.first
                tempAttachmentName = copied.second
                Toast.makeText(context, "تم إرفاق الملف بنجاح! 📎", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "فشل نسخ الملف، يرجى المحاولة مرة أخرى.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    var showManageCourseProjectsDialog by remember { mutableStateOf(false) }
    var showAddCourseProjectDialog by remember { mutableStateOf(false) }
    var templateToExcludeOrDelete by remember { mutableStateOf<SubjectAssignmentTemplate?>(null) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else Color.White),
        border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "رصد وتسجيل مشاريع وتكليفات الطلاب:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDarkTheme) Color.White else DawamiNavy,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { 
                    selectedCourseForCheck?.let { 
                        viewModel.autoSyncGradesFromAttendanceAndAssignments(it.id)
                    }
                }) {
                    Icon(Icons.Default.Sync, contentDescription = "مزامنة الدرجات تلقائياً")
                }
            }

            // Dropdowns
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Diploma
                    var isDiplomaExpanded by remember { mutableStateOf(false) }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الدبلوم:", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.White else DawamiNavy)
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { isDiplomaExpanded = true }
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedDiplomaForCheck.ifEmpty { "اختر الدبلوم" }, fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                            DropdownMenu(expanded = isDiplomaExpanded, onDismissRequest = { isDiplomaExpanded = false }) {
                                allDiplomas.forEach { dip ->
                                    DropdownMenuItem(text = { Text(dip, fontSize = 11.sp) }, onClick = {
                                        selectedDiplomaForCheck = dip
                                        isDiplomaExpanded = false
                                        val newCourses = courses.filter { it.diplomaName == dip }
                                        selectedCourseForCheck = newCourses.firstOrNull()
                                    })
                                }
                            }
                        }
                    }

                    // Course
                    var isCourseExpanded by remember { mutableStateOf(false) }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الدورة:", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.White else DawamiNavy)
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { isCourseExpanded = true }
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedCourseForCheck?.name ?: "اختر الدورة", fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                            DropdownMenu(expanded = isCourseExpanded, onDismissRequest = { isCourseExpanded = false }) {
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                            )
                                            Icon(
                                                imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = null,
                                                tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.toggleShowCompletedCoursesInDropdowns()
                                    }
                                )
                                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                                filteredCourses.forEach { crs ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = if (crs.isCompleted) "${crs.name} (منتهية 🔒)" else crs.name,
                                                fontSize = 11.sp,
                                                color = if (crs.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                            )
                                        },
                                        onClick = {
                                            selectedCourseForCheck = crs
                                            isCourseExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Subject
                    var isSubjectExpanded by remember { mutableStateOf(false) }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("المادة:", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.White else DawamiNavy)
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { isSubjectExpanded = true }
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedSubjectForCheck ?: "اختر المادة", fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                            DropdownMenu(expanded = isSubjectExpanded, onDismissRequest = { isSubjectExpanded = false }) {
                                filteredSubjects.forEach { subj ->
                                    DropdownMenuItem(text = { Text(subj.name, fontSize = 11.sp) }, onClick = {
                                        selectedSubjectForCheck = subj.name
                                        isSubjectExpanded = false
                                    })
                                }
                            }
                        }
                    }

                    // Student
                    var isStudentExpanded by remember { mutableStateOf(false) }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الطالب:", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.White else DawamiNavy)
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { isStudentExpanded = true }
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedStudentForCheck?.name ?: "اختر الطالب", fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                            DropdownMenu(expanded = isStudentExpanded, onDismissRequest = { isStudentExpanded = false }) {
                                activeCourseStudents.forEach { student ->
                                    DropdownMenuItem(text = { Text(student.name, fontSize = 11.sp) }, onClick = {
                                        selectedStudentForCheck = student
                                        isStudentExpanded = false
                                    })
                                }
                            }
                        }
                    }
                }
            }

            val activeCourse = selectedCourseForCheck
            val activeSubjectName = selectedSubjectForCheck ?: ""

            val allGradeConfigs by viewModel.dbAllGradeConfigs.collectAsState()
            val currentGradeConfig = remember(allGradeConfigs, activeCourse) {
                activeCourse?.let { crs -> allGradeConfigs.find { it.courseId == crs.id } }
            }

            val (maxAssignmentScore, maxProjectScore) = remember(currentGradeConfig, activeSubjectName) {
                if (currentGradeConfig != null && activeSubjectName.isNotBlank()) {
                    val allConfigFields = com.example.data.entity.StudentGradeConfig.deserializeFields(currentGradeConfig.customFieldsJson ?: "")
                    val subjectFields = if (currentGradeConfig.isDiploma) {
                        val specific = allConfigFields.filter { it.first.startsWith("${activeSubjectName}_") }
                            .map { Pair(it.first.substringAfter("${activeSubjectName}_"), it.second) }
                        if (specific.isNotEmpty()) {
                            specific
                        } else {
                            val plain = allConfigFields.filter { !it.first.contains("_") }
                            if (plain.isNotEmpty()) plain else listOf(
                                Pair("حضور", 5), Pair("مشاركة", 5), Pair("تكاليف", 10), Pair("مشاريع", 20), Pair("اختبار نظري", 20), Pair("اختبار عملي", 40)
                            )
                        }
                    } else {
                        allConfigFields.filter { it.first.startsWith("${activeSubjectName}_") }
                            .map { Pair(it.first.substringAfter("${activeSubjectName}_"), it.second) }
                    }
                    val assScore = (subjectFields.find { it.first.contains("تكاليف", ignoreCase = true) || it.first.contains("واجبات", ignoreCase = true) || it.first.contains("بحوث", ignoreCase = true) }?.second ?: 10).toDouble()
                    val projScore = (subjectFields.find { it.first.contains("مشاريع", ignoreCase = true) || it.first.contains("مشروع", ignoreCase = true) }?.second ?: 20).toDouble()
                    Pair(assScore, projScore)
                } else {
                    Pair(10.0, 20.0)
                }
            }

            val activeCourseStudents = if (activeCourse != null) {
                if (selectedStudentForCheck != null) {
                    listOf(selectedStudentForCheck!!)
                } else {
                    activeCourseStudents
                }
            } else emptyList()

            val templatesForSubject = remember(assignmentTemplates, activeSubjectName, activeCourse) {
                assignmentTemplates.filter {
                    it.subjectName.trim().equals(activeSubjectName.trim(), ignoreCase = true) &&
                    (activeCourse == null || it.isApplicableForCourse(activeCourse.id))
                }
            }

            val excludedTemplatesForSubject = remember(assignmentTemplates, activeSubjectName, activeCourse) {
                if (activeCourse != null) {
                    assignmentTemplates.filter {
                        it.subjectName.trim().equals(activeSubjectName.trim(), ignoreCase = true) &&
                        it.isExcludedForCourse(activeCourse.id)
                    }
                } else emptyList()
            }

            val courseGradingMode = activeCourse?.let { courseGradingModes[it.id] ?: viewModel.getCourseGradingMode(it.id) } ?: "AUTO"
            val isCourseManualFinal = courseGradingMode == "MANUAL_FINAL"

            if (activeCourse == null) {
                Text("الرجاء اختيار دورة نشطة لعرض قائمة الطلاب ورصد درجاتهم.", fontSize = 11.5.sp, color = Color.Gray)
            } else if (isCourseManualFinal) {
                Surface(
                    color = Color(0xFFFFFBEB),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFF59E0B).copy(alpha = 0.15f),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(24.dp))
                            }
                        }
                        Text(
                            text = "رصد المشاريع والواجبات معطّل لهذه الدورة 🔒",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF92400E)
                        )
                        Text(
                            text = "تم اعتماد (الرصد اليدوي النهائي) لدورة \"${activeCourse.name}\" في شاشة كشف الدرجات.\nلا تظهر المشاريع هنا، حيث تم اعتماد الدرجة المرصودة يدوياً نهائياً كمرجع رسمي وحيد وتجاهل شاشات الرصد الأخرى منعاً للتعارض.",
                            fontSize = 11.5.sp,
                            color = Color(0xFFB45309),
                            textAlign = TextAlign.Center,
                            lineHeight = 17.sp
                        )
                        Button(
                            onClick = { viewModel.setSelectedGradesTabIndex(0) },
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("الانتقال إلى شاشة رصد الدرجات 📝", fontSize = 11.sp, color = Color.White)
                        }
                    }
                }
            } else {
                // Course Projects Toolbar & Search
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Surface(
                        color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(0.8.dp, DawamiTeal.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Assignment, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "مشاريع الدورة (${templatesForSubject.size}):",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) Color.White else DawamiNavy
                                )
                                if (excludedTemplatesForSubject.isNotEmpty()) {
                                    Surface(
                                        color = Color(0xFFEF4444).copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "مستبعد: ${excludedTemplatesForSubject.size}",
                                            fontSize = 9.sp,
                                            color = Color(0xFFDC2626),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(
                                    onClick = {
                                        tempAttachmentPath = ""
                                        tempAttachmentName = ""
                                        showAddCourseProjectDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("إضافة للدورة ➕", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { showManageCourseProjectsDialog = true },
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(12.dp), tint = DawamiTeal)
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("إدارة وحذف ⚙️", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                }
                            }
                        }
                    }

                    // Search Bar for Projects and Students
                    OutlinedTextField(
                        value = projectSearchQuery,
                        onValueChange = { projectSearchQuery = it },
                        placeholder = { Text("بحث في مشاريع وتكليفات الدورة أو أسماء الطلاب... 🔍", fontSize = 10.5.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(16.dp)) },
                        trailingIcon = {
                            if (projectSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { projectSearchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Clear, contentDescription = "مسح البحث", modifier = Modifier.size(14.dp))
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        textStyle = TextStyle(fontSize = 11.sp)
                    )
                }

                if (templatesForSubject.isEmpty()) {
                    Surface(
                        color = DawamiGold.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "⚠️ لا توجد مشاريع أو واجبات مهيأة لمادة ($activeSubjectName) في دورة (${activeCourse.name}).\nيمكنك إضافة مشروع خاص بهذه الدورة مباشرة من الزر أعلاه، أو استعادة مشروع مستبعد.",
                                fontSize = 11.sp,
                                color = Color(0xFFB45309),
                                lineHeight = 16.sp
                            )
                        }
                    }
                } else {
                // Students expandable list with search filtering
                val filteredStudentsList = remember(activeCourseStudents, projectSearchQuery, templatesForSubject) {
                    if (projectSearchQuery.isBlank()) activeCourseStudents
                    else {
                        val q = projectSearchQuery.trim().lowercase()
                        val matchingTemplates = templatesForSubject.filter { it.title.lowercase().contains(q) || it.description.lowercase().contains(q) }
                        if (matchingTemplates.isNotEmpty()) {
                            activeCourseStudents // Show all students if a project matched so user can grade it
                        } else {
                            activeCourseStudents.filter { it.name.lowercase().contains(q) }
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    filteredStudentsList.forEach { student ->
                        val studentSubmissions = assignmentSubmissions.filter {
                            it.courseId == activeCourse.id &&
                            it.subjectName.trim().equals(activeSubjectName.trim(), ignoreCase = true) &&
                            it.studentId == student.id
                        }
                        val completedTitles = studentSubmissions.filter { it.isCompleted }.map { it.assignmentTitle.trim().lowercase() }
                        val completedCount = templatesForSubject.count { completedTitles.contains(it.title.trim().lowercase()) }
                        val totalCount = templatesForSubject.size

                        val dbAllGrades by viewModel.dbAllGrades.collectAsState()
                        val studentGradeRecord = dbAllGrades.find {
                            it.studentId == student.id &&
                            it.courseId == activeCourse.id &&
                            (it.subjectName.trim().equals(activeSubjectName.trim(), ignoreCase = true) || it.subjectName.isEmpty())
                        }

                        val calcResearch = calculateDynamicAssignmentScore(
                            allSubmissions = assignmentSubmissions,
                            allTemplates = templatesForSubject,
                            courseId = activeCourse.id,
                            subjectName = activeSubjectName,
                            studentId = student.id,
                            maxAssignmentScore = maxAssignmentScore,
                            categoryFilter = "تكاليف"
                        ).first

                        val calcProject = calculateDynamicAssignmentScore(
                            allSubmissions = assignmentSubmissions,
                            allTemplates = templatesForSubject,
                            courseId = activeCourse.id,
                            subjectName = activeSubjectName,
                            studentId = student.id,
                            maxAssignmentScore = maxProjectScore,
                            categoryFilter = "مشاريع"
                        ).first

                        val courseMode = courseGradingModes[activeCourse.id] ?: viewModel.getCourseGradingMode(activeCourse.id)
                        val isStudentManual = studentGradeRecord?.isManualGrading() == true && courseMode != "AUTO"
                        val researchEarned = if (isStudentManual) Math.round(studentGradeRecord?.assignmentsScore ?: 0.0).toInt() else Math.round(calcResearch).toInt()
                        val projectEarned = if (isStudentManual) Math.round(studentGradeRecord?.projectsScore ?: 0.0).toInt() else Math.round(calcProject).toInt()
                        val totalScoreMax = (maxAssignmentScore + maxProjectScore).toInt()
                        val totalEarned = researchEarned + projectEarned

                        val progressRatio = if (isStudentManual) {
                            if (totalScoreMax > 0) (totalEarned.toFloat() / totalScoreMax.toFloat()).coerceIn(0f, 1f) else 1f
                        } else {
                            if (totalCount > 0) completedCount.toFloat() / totalCount.toFloat() else 0f
                        }
                        val isFullyCompleted = if (isStudentManual) totalEarned >= totalScoreMax && totalScoreMax > 0 else (completedCount == totalCount && totalCount > 0)

                        val isExpanded = expandedStudents[student.id] ?: false

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isFullyCompleted) Color(0xFF86EFAC) else (if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                            )
                        ) {
                            Column {
                                // Header (Collapsed view)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { expandedStudents[student.id] = !isExpanded }
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        // Mini student avatar
                                        Surface(
                                            color = if (isFullyCompleted) Color(0xFFDCFCE7) else DawamiNavy.copy(alpha = 0.1f),
                                            shape = CircleShape,
                                            modifier = Modifier.size(34.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = student.name.take(1),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = if (isFullyCompleted) Color(0xFF15803D) else DawamiNavy
                                                )
                                            }
                                        }

                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) {
                                            // Row 1: Student Name + "✍️ رصد يدوي" Badge in SAME ROW
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = student.name,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isDarkTheme) Color.White else DawamiNavy,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f, fill = false)
                                                )
                                                if (isStudentManual) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        color = Color(0xFFFEF3C7),
                                                        shape = RoundedCornerShape(4.dp),
                                                        border = BorderStroke(0.5.dp, Color(0xFFF59E0B))
                                                    ) {
                                                        Text(
                                                            text = "✍️ رصد يدوي",
                                                            fontSize = 8.5.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFFB45309),
                                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            if (isStudentManual) {
                                                Surface(
                                                    color = DawamiGold.copy(alpha = 0.12f),
                                                    shape = RoundedCornerShape(6.dp),
                                                    border = BorderStroke(0.5.dp, DawamiGold.copy(alpha = 0.4f)),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "تكاليف: $researchEarned/${maxAssignmentScore.toInt()} | مشاريع: $projectEarned/${maxProjectScore.toInt()}",
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFFB45309)
                                                        )
                                                        Text(
                                                            text = "المجموع: $totalEarned/$totalScoreMax",
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFFB45309)
                                                        )
                                                    }
                                                }
                                            } else {
                                                Text(
                                                    text = "تم رصد $completedCount من $totalCount",
                                                    fontSize = 10.5.sp,
                                                    color = Color.Gray
                                                )
                                                Surface(
                                                    color = DawamiTeal.copy(alpha = 0.12f),
                                                    shape = RoundedCornerShape(6.dp),
                                                    border = BorderStroke(0.5.dp, DawamiTeal.copy(alpha = 0.4f)),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "تكاليف: $researchEarned/${maxAssignmentScore.toInt()} | مشاريع: $projectEarned/${maxProjectScore.toInt()}",
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = DawamiTeal
                                                        )
                                                        Text(
                                                            text = "المجموع: $totalEarned/$totalScoreMax",
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = DawamiTeal
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Surface(
                                            color = if (isFullyCompleted) Color(0xFF16A34A) else DawamiNavy.copy(alpha = 0.12f),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text(
                                                text = "${(progressRatio * 100).toInt()}%",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isFullyCompleted) Color.White else DawamiNavy,
                                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                            )
                                        }

                                        Icon(
                                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = null,
                                            tint = Color.Gray,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                // Progress indicator
                                LinearProgressIndicator(
                                    progress = { progressRatio },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp),
                                    color = if (isFullyCompleted) Color(0xFF16A34A) else (if (isStudentManual) Color(0xFFD97706) else DawamiNavy),
                                    trackColor = if (isDarkTheme) Color(0xFF334155) else Color(0xFFF1F5F9)
                                )

                                // Expanded view
                                AnimatedVisibility(
                                    visible = isExpanded,
                                    enter = expandVertically() + fadeIn(),
                                    exit = shrinkVertically() + fadeOut()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(if (isDarkTheme) Color(0xFF0F172A) else Color(0xFFF8FAFC))
                                            .padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "قائمة مشاريع وتكليفات الطالب ورصد التقييمات:",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Gray
                                        )

                                            templatesForSubject.forEach { tmpl ->
                                                val sub = studentSubmissions.filter {
                                                    it.assignmentTitle.trim().equals(tmpl.title.trim(), ignoreCase = true)
                                                }.maxByOrNull { it.id }
                                                val isChecked = sub != null && sub.isCompleted
                                                val currentRating = sub?.evaluationRating ?: ""

                                                val taskType = getTaskType(tmpl.title, tmpl.type)
                                                val taskColor = when (taskType) {
                                                    "مشروع عملي" -> Color(0xFF8B5CF6)
                                                    else -> Color(0xFFD97706)
                                                }

                                                Card(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    shape = RoundedCornerShape(10.dp),
                                                    colors = CardDefaults.cardColors(
                                                        containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                                                    ),
                                                    border = BorderStroke(
                                                        1.dp,
                                                        if (isChecked) taskColor.copy(alpha = 0.4f) else (if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                                                    )
                                                ) {
                                                    Column(
                                                        modifier = Modifier.padding(10.dp),
                                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Row(
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                                modifier = Modifier
                                                                    .weight(1f)
                                                                    .clickable {
                                                                        viewModel.toggleStudentAssignmentSubmission(
                                                                            courseId = activeCourse.id,
                                                                            subjectName = activeSubjectName,
                                                                            studentId = student.id,
                                                                            studentName = student.name,
                                                                            assignmentTitle = tmpl.title
                                                                        )
                                                                    }
                                                            ) {
                                                                Icon(
                                                                    imageVector = if (isChecked) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                                                    contentDescription = null,
                                                                    modifier = Modifier.size(20.dp),
                                                                    tint = if (isChecked) taskColor else Color.Gray
                                                                )
                                                                Column {
                                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                                        Text(
                                                                            text = tmpl.title,
                                                                            fontSize = 11.sp,
                                                                            fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Medium,
                                                                            color = if (isChecked) taskColor else (if (isDarkTheme) Color.White else Color.DarkGray),
                                                                            modifier = Modifier.weight(1f, fill = false)
                                                                        )
                                                                        Surface(
                                                                            color = taskColor.copy(alpha = 0.12f),
                                                                            shape = RoundedCornerShape(4.dp)
                                                                        ) {
                                                                            Text(
                                                                                text = if (taskType == "مشروع عملي") "مشروع عملي 💻" else "بحث نظري 🔍",
                                                                                fontSize = 8.sp,
                                                                                fontWeight = FontWeight.Bold,
                                                                                color = taskColor,
                                                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                                            )
                                                                        }
                                                                    }
                                                                    if (tmpl.description.isNotEmpty()) {
                                                                        Text(
                                                                            text = tmpl.description,
                                                                            fontSize = 10.sp,
                                                                            color = Color.Gray
                                                                        )
                                                                    }
                                                                }
                                                            }

                                                            Row(
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                            ) {
                                                                Surface(
                                                                    color = taskColor.copy(alpha = 0.12f),
                                                                    shape = RoundedCornerShape(6.dp),
                                                                    border = BorderStroke(1.dp, taskColor.copy(alpha = 0.5f))
                                                                ) {
                                                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) {
                                                                        val effectiveScore = sub?.score ?: if (isChecked && currentRating.isNotEmpty()) {
                                                                            when (currentRating) {
                                                                                "ممتاز" -> tmpl.maxScore
                                                                                "جيد جداً" -> tmpl.maxScore * 0.75
                                                                                "جيد" -> tmpl.maxScore * 0.50
                                                                                "مقبول" -> tmpl.maxScore * 0.25
                                                                                else -> 0.0
                                                                            }
                                                                        } else 0.0

                                                                        var localScoreStr by remember(effectiveScore) {
                                                                            mutableStateOf(fmtScore(effectiveScore))
                                                                        }
                                                                        LaunchedEffect(effectiveScore) {
                                                                            localScoreStr = fmtScore(effectiveScore)
                                                                        }
                                                                        BasicTextField(
                                                                            value = localScoreStr,
                                                                            onValueChange = { newValue ->
                                                                                localScoreStr = newValue.filter { it.isDigit() || it == '.' }
                                                                                val parsed = localScoreStr.toDoubleOrNull()
                                                                                if (parsed != null && parsed <= tmpl.maxScore) {
                                                                                    viewModel.setStudentAssignmentRating(
                                                                                        courseId = activeCourse.id,
                                                                                        subjectName = activeSubjectName,
                                                                                        studentId = student.id,
                                                                                        studentName = student.name,
                                                                                        assignmentTitle = tmpl.title,
                                                                                        rating = if (parsed == 0.0) "غير مكتمل" else currentRating.ifEmpty { "مخصص" },
                                                                                        score = parsed
                                                                                    )
                                                                                }
                                                                            },
                                                                            textStyle = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = taskColor, textAlign = TextAlign.Center),
                                                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                                            modifier = Modifier.width(32.dp)
                                                                        )
                                                                        Text(
                                                                            text = " / ${tmpl.maxScore.toInt()}",
                                                                            fontSize = 9.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                            color = taskColor
                                                                        )
                                                                    }
                                                                }

                                                                if (currentRating.isNotEmpty()) {
                                                                    Surface(
                                                                        color = when (currentRating) {
                                                                            "ممتاز" -> Color(0xFF16A34A)
                                                                            "جيد جداً" -> Color(0xFF0284C7)
                                                                            "جيد" -> Color(0xFFD97706)
                                                                            "مقبول" -> Color(0xFF64748B)
                                                                            else -> Color(0xFFDC2626)
                                                                        },
                                                                        shape = RoundedCornerShape(8.dp)
                                                                    ) {
                                                                        Text(
                                                                            text = if (currentRating == "غير مكتمل") "لم ينجز" else currentRating,
                                                                            fontSize = 8.5.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                            color = Color.White,
                                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                                        )
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        // Rating Selector Buttons
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            val ratingOptions = listOf(
                                                                "ممتاز" to "⭐ ممتاز",
                                                                "جيد جداً" to "👍 ج.جيد",
                                                                "جيد" to "👌 جيد",
                                                                "مقبول" to "🤏 مقبول",
                                                                "غير مكتمل" to "❌ لم ينجز"
                                                            )

                                                            ratingOptions.forEach { (ratingKey, ratingLabel) ->
                                                                val isSelectedRating = when (ratingKey) {
                                                                    "غير مكتمل", "لم ينجز" -> (currentRating == "غير مكتمل" || currentRating == "لم ينجز")
                                                                    else -> currentRating == ratingKey
                                                                }
                                                                Surface(
                                                                    onClick = {
                                                                        val autoScore = when(ratingKey) {
                                                                            "ممتاز" -> tmpl.maxScore
                                                                            "جيد جداً" -> tmpl.maxScore * 0.75
                                                                            "جيد" -> tmpl.maxScore * 0.50
                                                                            "مقبول" -> tmpl.maxScore * 0.25
                                                                            else -> 0.0
                                                                        }
                                                                        viewModel.setStudentAssignmentRating(
                                                                            courseId = activeCourse.id,
                                                                            subjectName = activeSubjectName,
                                                                            studentId = student.id,
                                                                            studentName = student.name,
                                                                            assignmentTitle = tmpl.title,
                                                                            rating = if (isSelectedRating) "" else ratingKey,
                                                                            score = if (isSelectedRating) 0.0 else autoScore
                                                                        )
                                                                    },
                                                                    modifier = Modifier.weight(1f),
                                                                    shape = RoundedCornerShape(6.dp),
                                                                    color = if (isSelectedRating) {
                                                                        when (ratingKey) {
                                                                            "ممتاز" -> Color(0xFF16A34A)
                                                                            "جيد جداً" -> Color(0xFF0284C7)
                                                                            "جيد" -> Color(0xFFD97706)
                                                                            "مقبول" -> Color(0xFF64748B)
                                                                            else -> Color(0xFFDC2626)
                                                                        }
                                                                    } else (if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)).copy(alpha = 0.5f)
                                                                ) {
                                                                    Text(
                                                                        text = ratingLabel,
                                                                        fontSize = 8.sp,
                                                                        fontWeight = if (isSelectedRating) FontWeight.Bold else FontWeight.Normal,
                                                                        color = if (isSelectedRating) Color.White else (if (isDarkTheme) Color.LightGray else Color.DarkGray),
                                                                        textAlign = TextAlign.Center,
                                                                        modifier = Modifier.padding(vertical = 6.dp)
                                                                    )
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- Dialogs for Course Project Management ---
    val currentSelectedCourse = selectedCourseForCheck
    val currentSelectedSubject = selectedSubjectForCheck ?: ""

    // 1. Confirm Delete / Exclude Dialog
    if (templateToExcludeOrDelete != null && currentSelectedCourse != null) {
        val tmpl = templateToExcludeOrDelete!!
        val crs = currentSelectedCourse
        val isSpecific = tmpl.courseId == crs.id

        AlertDialog(
            onDismissRequest = { templateToExcludeOrDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626)) },
            title = {
                Text(
                    text = if (isSpecific) "حذف مشروع خاص بالدورة 🗑️" else "استبعاد مشروع من هذه الدورة 🚫",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "المشروع: ${tmpl.title} (${tmpl.type})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = DawamiNavy
                    )
                    Text(
                        text = if (isSpecific) {
                            "هل أنت متأكد من حذف هذا المشروع الخاص بدورة \"${crs.name}\" نهائياً؟"
                        } else {
                            "هل أنت متأكد من استبعاد هذا المشروع من دورة \"${crs.name}\" فقط؟\n\nلن يتأثر القالب العام للمادة، ولن تتأثر أي دورة أخرى (سواء سابقة أو منتهية أو جديدة)."
                        },
                        fontSize = 11.5.sp,
                        color = if (isDarkTheme) Color.LightGray else Color.DarkGray
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAssignmentTemplateFromCourse(tmpl, crs.id)
                        templateToExcludeOrDelete = null
                        Toast.makeText(context, if (isSpecific) "تم حذف المشروع من الدورة بنجاح 👍" else "تم استبعاد المشروع من هذه الدورة بنجاح 👍", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(if (isSpecific) "حذف نهائي" else "استبعاد من هذه الدورة", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { templateToExcludeOrDelete = null }) {
                    Text("إلغاء", color = DawamiNavy)
                }
            }
        )
    }

    // 2. Manage Course Projects Dialog
    if (showManageCourseProjectsDialog && currentSelectedCourse != null) {
        val crs = currentSelectedCourse
        var manageSearchQuery by remember { mutableStateOf("") }
        val activeProjList = remember(assignmentTemplates, currentSelectedSubject, crs, manageSearchQuery) {
            val list = assignmentTemplates.filter {
                it.subjectName.trim().equals(currentSelectedSubject.trim(), ignoreCase = true) &&
                it.isApplicableForCourse(crs.id)
            }
            if (manageSearchQuery.isBlank()) list
            else list.filter { it.title.contains(manageSearchQuery.trim(), ignoreCase = true) || it.description.contains(manageSearchQuery.trim(), ignoreCase = true) }
        }
        val excludedProjList = remember(assignmentTemplates, currentSelectedSubject, crs, manageSearchQuery) {
            val list = assignmentTemplates.filter {
                it.subjectName.trim().equals(currentSelectedSubject.trim(), ignoreCase = true) &&
                it.isExcludedForCourse(crs.id)
            }
            if (manageSearchQuery.isBlank()) list
            else list.filter { it.title.contains(manageSearchQuery.trim(), ignoreCase = true) }
        }

        AlertDialog(
            onDismissRequest = { showManageCourseProjectsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = DawamiNavy)
                    Text("إدارة مشاريع دورة (${crs.name})", fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "المادة: $currentSelectedSubject | إجمالي المشاريع المعتمدة: ${activeProjList.size}",
                        fontSize = 10.5.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold
                    )

                    // Search inside manage dialog
                    OutlinedTextField(
                        value = manageSearchQuery,
                        onValueChange = { manageSearchQuery = it },
                        placeholder = { Text("بحث في المشاريع... 🔍", fontSize = 10.5.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(16.dp)) },
                        trailingIcon = {
                            if (manageSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { manageSearchQuery = "" }, modifier = Modifier.size(20.dp)) {
                                    Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(14.dp))
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(44.dp),
                        textStyle = TextStyle(fontSize = 11.sp)
                    )

                    if (activeProjList.isEmpty() && excludedProjList.isEmpty()) {
                        Text("لا توجد مشاريع مسجلة لهذه المادة بعد.", fontSize = 11.sp, color = Color.Gray)
                    }

                    // Active Projects Section
                    if (activeProjList.isNotEmpty()) {
                        Text("المشاريع والتكليفات المعتمدة للدورة:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        activeProjList.forEach { proj ->
                            val isSpecific = proj.courseId == crs.id
                            Surface(
                                color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(0.5.dp, Color.LightGray),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(proj.title, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Surface(
                                                color = if (isSpecific) Color(0xFF8B5CF6).copy(alpha = 0.15f) else DawamiTeal.copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = if (isSpecific) "خاص بالدورة 📌" else "قالب عام 🌐",
                                                    fontSize = 8.5.sp,
                                                    color = if (isSpecific) Color(0xFF8B5CF6) else DawamiTeal,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("${proj.type} | الدرجة: ${proj.maxScore.toInt()}", fontSize = 9.sp, color = Color.Gray)
                                            if (proj.attachmentPath.isNotBlank()) {
                                                Surface(
                                                    color = DawamiTeal.copy(alpha = 0.1f),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "📎 مرفق: ${proj.attachmentName.ifEmpty { "ملف" }}",
                                                        fontSize = 8.sp,
                                                        color = DawamiTeal,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        if (isSpecific) {
                                            // Export to Global Bank Button
                                            IconButton(
                                                onClick = {
                                                    viewModel.exportAssignmentTemplateToGlobal(proj) {
                                                        Toast.makeText(context, "تم تصدير المشروع إلى القوالب العامة للمادة بنجاح! 🌐", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Default.CloudUpload, contentDescription = "تصدير للقوالب العامة", tint = DawamiTeal, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                        // Exclude / Delete Button
                                        IconButton(
                                            onClick = {
                                                templateToExcludeOrDelete = proj
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف أو استبعاد", tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Excluded Projects Section
                    if (excludedProjList.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("مشاريع تم استبعادها من هذه الدورة:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                        excludedProjList.forEach { proj ->
                            Surface(
                                color = Color(0xFFFEF2F2),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(0.5.dp, Color(0xFFFCA5A5)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(proj.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                                        Text("${proj.type} (مستبعد من هذه الدورة فقط)", fontSize = 8.5.sp, color = Color(0xFFB91C1C))
                                    }
                                    Button(
                                        onClick = {
                                            viewModel.restoreAssignmentTemplateToCourse(proj, crs.id)
                                            Toast.makeText(context, "تمت استعادة المشروع للدورة بنجاح 👍", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(24.dp)
                                    ) {
                                        Text("استعادة ↩️", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showManageCourseProjectsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("إغلاق", color = Color.White)
                }
            }
        )
    }

    // 3. Add Project for Course Dialog
    if (showAddCourseProjectDialog && currentSelectedCourse != null) {
        var newTitle by remember { mutableStateOf("") }
        var newDesc by remember { mutableStateOf("") }
        var newScore by remember { mutableStateOf("10") }
        var newType by remember { mutableStateOf("مشروع عملي") }
        var alsoSaveAsGlobal by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = {
                showAddCourseProjectDialog = false
                tempAttachmentPath = ""
                tempAttachmentName = ""
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.AddCircle, contentDescription = null, tint = DawamiNavy)
                    Text("إضافة مشروع أو بحث للدورة ➕", fontSize = 13.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("الدورة: ${currentSelectedCourse.name} | المادة: $currentSelectedSubject", fontSize = 10.5.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)

                    // Type Selector Chips
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("مشروع عملي" to "💻 مشروع عملي", "بحث نظري" to "🔍 بحث نظري").forEach { (typeKey, label) ->
                            val isSel = newType == typeKey
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { newType = typeKey },
                                color = if (isSel) DawamiNavy else (if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)),
                                border = BorderStroke(1.dp, if (isSel) DawamiNavy else Color.Transparent)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSel) Color.White else Color.DarkGray,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 7.dp)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("عنوان التكليف / المشروع") },
                        placeholder = { Text("مثال: مشروع تصميم قاعدة بيانات") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = newDesc,
                        onValueChange = { newDesc = it },
                        label = { Text("الوصف (اختياري)") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = newScore,
                        onValueChange = { newScore = it },
                        label = { Text("الدرجة المقررة") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    // File Attachment Picker Section
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                        Text("مرفق المشروع / الملف (اختياري):", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                        if (tempAttachmentPath.isNotBlank()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                                    .border(1.dp, DawamiTeal.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AttachFile,
                                        contentDescription = null,
                                        tint = DawamiTeal,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = tempAttachmentName.ifEmpty { "ملف مرفق" },
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        tempAttachmentPath = ""
                                        tempAttachmentName = ""
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "حذف المرفق",
                                        tint = Color.Red,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        } else {
                            Button(
                                onClick = {
                                    selectAttachmentLauncher.launch("*/*")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy.copy(alpha = 0.12f)),
                                elevation = null,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.UploadFile,
                                    contentDescription = null,
                                    tint = DawamiNavy,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("اختر ملف لإرفاقه بالمشروع 📎", fontSize = 10.5.sp, color = DawamiNavy, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Checkbox for also saving as global template
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { alsoSaveAsGlobal = !alsoSaveAsGlobal }
                            .padding(vertical = 4.dp)
                    ) {
                        Checkbox(
                            checked = alsoSaveAsGlobal,
                            onCheckedChange = { alsoSaveAsGlobal = it }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "حفظ كقالب عام للمادة أيضاً (ليظهر في الدورات الأخرى والقادمة) 🌐",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isDarkTheme) Color.White else DawamiNavy
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedScore = newScore.toDoubleOrNull() ?: 10.0
                        if (newTitle.isNotBlank() && currentSelectedSubject.isNotBlank()) {
                            val newTmpl = SubjectAssignmentTemplate(
                                subjectName = currentSelectedSubject,
                                title = newTitle.trim(),
                                description = newDesc.trim(),
                                maxScore = parsedScore,
                                type = newType,
                                attachmentPath = tempAttachmentPath,
                                attachmentName = tempAttachmentName,
                                courseId = if (alsoSaveAsGlobal) 0 else currentSelectedCourse.id
                            )
                            viewModel.insertAssignmentTemplate(newTmpl)
                            showAddCourseProjectDialog = false
                            tempAttachmentPath = ""
                            tempAttachmentName = ""
                            Toast.makeText(context, if (alsoSaveAsGlobal) "تمت إضافة المشروع وحفظه كقالب عام بنجاح 👍" else "تمت إضافة المشروع الخاص بالدورة بنجاح 👍", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "الرجاء إدخال عنوان المشروع", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("إضافة المشروع", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = {
                    showAddCourseProjectDialog = false
                    tempAttachmentPath = ""
                    tempAttachmentName = ""
                }) {
                    Text("إلغاء", color = DawamiNavy)
                }
            }
        )
    }
}