package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subject_references")
data class SubjectReference(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectName: String,
    val department: String = "",
    val diploma: String = "",
    val title: String,
    val type: String, // "كتاب", "صورة", "رابط", "ملف آخر"
    val urlOrPath: String,
    val fileName: String = "",
    val dateAdded: String = ""
)
