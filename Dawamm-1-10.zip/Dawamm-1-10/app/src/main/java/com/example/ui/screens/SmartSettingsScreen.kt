package com.example.ui.screens

import android.widget.Toast
import com.example.utils.AudioPlayerHelper
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.components.DawamiBottomNavigationBar
import com.example.ui.components.FunnyPenaltyManagerDialog
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun SmartSettingsScreen(viewModel: MainViewModel, showMainLayout: Boolean = true) {
    val context = LocalContext.current
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val notifications by viewModel.inAppNotifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    var isNotificationsEnabled by remember { mutableStateOf(viewModel.isSmartNotificationsEnabled.value) }
    var trainerMinsStr by remember { mutableStateOf(viewModel.trainerReminderMinutes.value.toString()) }
    var checkInMinsStr by remember { mutableStateOf(viewModel.studentCheckInReminderMinutes.value.toString()) }
    var checkOutMinsStr by remember { mutableStateOf(viewModel.studentCheckOutReminderMinutes.value.toString()) }
    var selectedSound by remember { mutableStateOf(viewModel.notificationSound.value) }
    var selectedVoiceGender by remember { mutableStateOf(viewModel.voiceGender.value) }

    var isTrainerStartEnabled by remember { mutableStateOf(viewModel.isTrainerStartReminderEnabled.value) }
    var isTrainerCheckInEnabled by remember { mutableStateOf(viewModel.isTrainerCheckInReminderEnabled.value) }
    var isStudentCheckInEnabled by remember { mutableStateOf(viewModel.isStudentCheckInReminderEnabled.value) }
    var isStudentCheckInSuccess by remember { mutableStateOf(viewModel.isStudentCheckInSuccessEnabled.value) }
    var isStudentCheckOutEnabled by remember { mutableStateOf(viewModel.isStudentCheckOutReminderEnabled.value) }
    var isStudentCheckOutSuccess by remember { mutableStateOf(viewModel.isStudentCheckOutSuccessEnabled.value) }
    var isThursdayEnabled by remember { mutableStateOf(viewModel.isThursdayNotificationsEnabled.value) }

    // Section collapse/expand states
    var isPenaltiesExpanded by remember { mutableStateOf(true) }
    var isAlarmsExpanded by remember { mutableStateOf(true) }
    var isThresholdsExpanded by remember { mutableStateOf(false) }
    var isTimingsExpanded by remember { mutableStateOf(false) }
    var isVoicePromptsExpanded by remember { mutableStateOf(false) }

    val customSwitchColors = SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = DawamiTeal,
        uncheckedThumbColor = Color.White,
        uncheckedTrackColor = Color.LightGray,
        uncheckedBorderColor = Color.Transparent
    )

    var trainerStartTextState by remember { mutableStateOf(viewModel.trainerStartReminderText.value) }
    var trainerCheckInTextState by remember { mutableStateOf(viewModel.trainerCheckInPromptText.value) }
    var studentCheckInTextState by remember { mutableStateOf(viewModel.studentCheckInPromptText.value) }
    var studentCheckInRemindTextState by remember { mutableStateOf(viewModel.studentCheckInRemindText.value) }
    var studentCheckInSuccessTextState by remember { mutableStateOf(viewModel.studentCheckInSuccessText.value) }
    var studentCheckOutTextState by remember { mutableStateOf(viewModel.studentCheckOutPromptText.value) }
    var studentCheckOutRemindTextState by remember { mutableStateOf(viewModel.studentCheckOutRemindText.value) }
    var studentCheckOutSuccessTextState by remember { mutableStateOf(viewModel.studentCheckOutSuccessText.value) }

    var showFunnyPenaltyManagerDialog by remember { mutableStateOf(false) }

    if (showFunnyPenaltyManagerDialog) {
        FunnyPenaltyManagerDialog(
            onDismiss = { showFunnyPenaltyManagerDialog = false },
            viewModel = viewModel
        )
    }

    if (showMainLayout) {
        BackHandler {
            viewModel.navigateTo(Screen.Selection)
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    var hasExactAlarmPermission by remember { mutableStateOf(true) }
    var hasDndAccess by remember { mutableStateOf(true) }
    var isIgnoringBattery by remember { mutableStateOf(true) }

    fun checkPermissions() {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        hasExactAlarmPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        hasDndAccess = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            notificationManager.isNotificationPolicyAccessGranted
        } else {
            true
        }

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        isIgnoringBattery = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
        } else {
            true
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val oldExact = hasExactAlarmPermission
                checkPermissions()
                if (!oldExact && hasExactAlarmPermission && isNotificationsEnabled) {
                    viewModel.dbCourses.value.forEach { course ->
                        if (!course.isCompleted) {
                            com.example.notification.NotificationHelper.scheduleCourseReminders(
                                context,
                                course,
                                viewModel.trainerReminderMinutes.value,
                                viewModel.studentCheckInReminderMinutes.value,
                                viewModel.studentCheckOutReminderMinutes.value
                            )
                        }
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                if (showMainLayout) {
                    AppHeader(
                        title = "إعدادات المساعد والمنبهات 🔔🧠",
                        username = "",
                        onHomeClick = { viewModel.navigateTo(Screen.Selection) },
                        isDark = isDarkTheme,
                        onToggleTheme = { viewModel.toggleTheme() },
                        unreadNotificationCount = unreadCount,
                        onNotificationClick = { viewModel.openNotificationCenter() }
                    )
                }
            },
            bottomBar = {
                if (showMainLayout) {
                    DawamiBottomNavigationBar(viewModel = viewModel)
                }
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                contentPadding = PaddingValues(bottom = 70.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 0. Theme Studio Card (36 Themes)
                item {
                    val currentThemeId by viewModel.selectedThemeId.collectAsState()
                    val activePreset = remember(currentThemeId) {
                        com.example.ui.theme.ThemePresetsCatalog.getById(currentThemeId)
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, activePreset.primary.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(activePreset.primary.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Palette,
                                        contentDescription = null,
                                        tint = activePreset.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "استوديو المظاهر المخصصة 🎨",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.5.sp,
                                        color = DawamiNavy
                                    )
                                    Text(
                                        text = "المظهر المعتمد: ${activePreset.name} (${activePreset.category})",
                                        fontSize = 9.5.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                            Button(
                                onClick = { viewModel.openThemeStudio() },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.ColorLens, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تغيير المظهر (36) 🎨", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Official Holidays Quick Access Card
                item {
                    val holidaysList by viewModel.allOfficialHolidays.collectAsState()
                    val activeHolidaysCount = holidaysList.count { it.isEnabled }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateTo(Screen.OfficialHolidays) },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(DawamiTeal.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("🌴", fontSize = 18.sp)
                                }
                                Column {
                                    Text(
                                        text = "الإجازات الرسمية والعطلات 🌴",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.5.sp,
                                        color = DawamiNavy
                                    )
                                    Text(
                                        text = "المسجلة: ${holidaysList.size} إجازة | المفعلة: $activeHolidaysCount",
                                        fontSize = 9.5.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                            Button(
                                onClick = { viewModel.navigateTo(Screen.OfficialHolidays) },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.DateRange, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إدارة الإجازات 🌴", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // 1. Master Notifications Switch Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(modifier = Modifier.padding(10.dp).fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("تفعيل التنبيهات والمنبهات التلقائية 🔔", fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = DawamiNavy)
                                    Text("تشغيل التنبيهات الصوتية والمدرسية مواعيد المحاضرات", fontSize = 10.sp, color = Color.Gray)
                                }
                                Switch(
                                    checked = isNotificationsEnabled,
                                    onCheckedChange = { isNotificationsEnabled = it },
                                    colors = customSwitchColors,
                                    modifier = Modifier.scale(0.85f)
                                )
                            }
                            if (!isNotificationsEnabled) {
                                Text(
                                    text = "⚠️ تم إيقاف جميع التنبيهات بالكامل بناءً على إعدادك. قم بتفعيلها أولاً للتعديل.",
                                    color = Color.Red,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Permission Card: Exact Alarm
                if (isNotificationsEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasExactAlarmPermission) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF5F5)),
                            border = BorderStroke(1.dp, Color(0xFFFEB2B2))
                        ) {
                            Column(modifier = Modifier.padding(10.dp).fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "⚠️ تنبيه متأخر! صلاحية المنبه الدقيق معطلة",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp,
                                            color = Color(0xFFC53030)
                                        )
                                        Text(
                                            text = "يرجى منح صلاحية جدولة المنبهات الدقيقة لضمان وصول التنبيهات الصوتية وتنبيهات التحضير والانصراف في وقتها الدقيق دون أي تأخير من النظام.",
                                            fontSize = 9.5.sp,
                                            color = Color(0xFF742A2A)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Button(
                                        onClick = {
                                            try {
                                                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                                    data = Uri.parse("package:${context.packageName}")
                                                }
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                try {
                                                    val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                                    context.startActivity(intent)
                                                } catch (e2: Exception) {
                                                    Toast.makeText(context, "تعذر فتح إعدادات المنبه الدقيق", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53E3E)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.Default.Alarm, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("منح الصلاحية ⚙️", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // Permission Card: DND (Do Not Disturb Bypass)
                if (isNotificationsEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !hasDndAccess) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDF5)),
                            border = BorderStroke(1.dp, Color(0xFFFEEBC8))
                        ) {
                            Column(modifier = Modifier.padding(10.dp).fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "🔔 تنبيه! وضع عدم الإزعاج وصامت قد يحجب التنبيهات",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp,
                                            color = Color(0xFFDD6B20)
                                        )
                                        Text(
                                            text = "يرجى منح التطبيق حق الوصول لسياسة الإشعارات (تخطي وضع عدم الإزعاج) لضمان عمل المساعد الصوتي ونطق تنبيهات الدوام والتحضير حتى عندما يكون الهاتف صامتاً.",
                                            fontSize = 9.5.sp,
                                            color = Color(0xFF7B341E)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Button(
                                        onClick = {
                                            try {
                                                val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "تعذر فتح إعدادات تخطي وضع عدم الإزعاج", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDD6B20)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.Default.NotificationImportant, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تفعيل التخطي ⚙️", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // Permission Card: Battery Optimization Exemption
                if (isNotificationsEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !isIgnoringBattery) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                            border = BorderStroke(1.dp, Color(0xFF86EFAC))
                        ) {
                            Column(modifier = Modifier.padding(10.dp).fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "⚡ ضمان عمل المنبه بالخلفية (استثناء موفر الطاقة)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp,
                                            color = Color(0xFF15803D)
                                        )
                                        Text(
                                            text = "يرجى استثناء التطبيق من قيود موفر الطاقة لضمان انطلاق المنبه في الثانية المحددة كمنبه ساعة رسمي حتى عند قفل الشاشة لفترات طويلة.",
                                            fontSize = 9.5.sp,
                                            color = Color(0xFF166534)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Button(
                                        onClick = {
                                            try {
                                                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                                    data = Uri.parse("package:${context.packageName}")
                                                }
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                try {
                                                    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                                    context.startActivity(intent)
                                                } catch (e2: Exception) {
                                                    Toast.makeText(context, "تعذر فتح إعدادات تحسين البطارية", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("استثناء البطارية ⚡", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // 1.5 System Activity Log Access Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "سجل الحركات والأنشطة الشامل للنظام 📋",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = DawamiNavy
                                )
                                Text(
                                    text = "استعراض وتدقيق كافة التغيرات والعمليات الموثقة بالنظام (حضور، درجات، تعديل، حذف، مالية).",
                                    fontSize = 9.5.sp,
                                    color = Color.Gray
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Button(
                                onClick = { viewModel.navigateTo(Screen.ActivityLogs) },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.History, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("فتح السجل 🔍", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // 2. Funny Penalties Manager Card (MOVED TO TOP as requested)
                item {
                    ExpandableSectionCard(
                        title = "🎭 إدارة قائمة العقوبات الفكاهية والجزاءات",
                        isExpanded = isPenaltiesExpanded,
                        onToggleExpand = { isPenaltiesExpanded = !isPenaltiesExpanded },
                        containerColor = if (isDarkTheme) MaterialTheme.colorScheme.surface else Color(0xFFFFFBEB),
                        borderColor = Color(0xFFFDE68A)
                    ) {
                        Text(
                            "تخصيص قائمة العقوبات الفكاهية والجزاءات المقترحة للطلاب الغائبين أو المتأخرين، إضافة عقوبات جديدة، أو حذفها.",
                            fontSize = 10.sp,
                            color = Color.DarkGray
                        )

                        Button(
                            onClick = { showFunnyPenaltyManagerDialog = true },
                            modifier = Modifier.fillMaxWidth().height(36.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFEF3C7)),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("فتح نافذة إدارة العقوبات الفكاهية ⚙️", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF78350F))
                        }
                    }
                }

                // Standalone Thursday Notifications Toggle (Outside of groups, on main screen)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("تفعيل تنبيهات يوم الخميس 📅", fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = DawamiNavy)
                                Text("تشغيل أو إيقاف التنبيهات ليوم الخميس (الجمعة والإجازات الرسمية معطلة آلياً)", fontSize = 9.5.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = isThursdayEnabled,
                                onCheckedChange = {
                                    isThursdayEnabled = it
                                    viewModel.setThursdayNotificationsEnabled(it)
                                },
                                enabled = isNotificationsEnabled,
                                colors = customSwitchColors,
                                modifier = Modifier.scale(0.85f)
                            )
                        }
                    }
                }

                // Group 1: Smart Sequential Attendance Notifications (Trainer & Students)
                item {
                    val sharedPrefs = remember { context.getSharedPreferences("dawami_prefs", Context.MODE_PRIVATE) }
                    
                    ExpandableSectionCard(
                        title = "🔔 1. التنسيق المتتابع للتنبيهات (التسلسل الذكي)",
                        isExpanded = true,
                        onToggleExpand = {}
                    ) {
                        Text("نظام تسلسلي ذكي: لا تظهر تنبيهات الطلاب إلا بعد تسجيل حركة المدرب أولاً وبدون تعقيد.", fontSize = 10.sp, color = Color.Gray)

                        // Trainer notifications switch
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isTrainerCheckInEnabled) DawamiNavy.copy(alpha = 0.08f) else Color.Transparent)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("تفعيل تنبيهات المدرب (حضور وانصراف) 👨‍🏫", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = DawamiNavy)
                                Text("يطلق التنبيه المباشر بالصوت المدمج عند موعد حضور وانصراف المدرب", fontSize = 9.5.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = isTrainerCheckInEnabled,
                                onCheckedChange = {
                                    isTrainerCheckInEnabled = it
                                    sharedPrefs.edit()
                                        .putBoolean("is_trainer_check_in_reminder_enabled", it)
                                        .putBoolean("is_trainer_check_out_reminder_enabled", it)
                                        .apply()
                                },
                                enabled = isNotificationsEnabled,
                                colors = customSwitchColors,
                                modifier = Modifier.scale(0.85f)
                            )
                        }

                        Divider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray.copy(alpha = 0.4f))

                        // Student notifications switch
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isStudentCheckInEnabled) DawamiTeal.copy(alpha = 0.12f) else Color.Transparent)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("تفعيل تنبيهات الطلاب (تعتمد على حركة المدرب) 👥", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = DawamiNavy)
                                Text("تظهر تلقائياً بالصوت المدمج فقط بعد تسجيل حضور أو انصراف المدرب أولاً", fontSize = 9.5.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = isStudentCheckInEnabled,
                                onCheckedChange = {
                                    isStudentCheckInEnabled = it
                                    sharedPrefs.edit()
                                        .putBoolean("is_student_check_in_reminder_enabled", it)
                                        .putBoolean("is_student_check_out_reminder_enabled", it)
                                        .apply()
                                },
                                enabled = isNotificationsEnabled,
                                colors = customSwitchColors,
                                modifier = Modifier.scale(0.85f)
                            )
                        }
                    }
                }

                // Group 2: Pre-Course Readiness Notifications (4 Choices)
                item {
                    val sharedPrefs = remember { context.getSharedPreferences("dawami_prefs", Context.MODE_PRIVATE) }
                    var isPrecourseSmart by remember { mutableStateOf(sharedPrefs.getBoolean("is_precourse_smart_repeating", true)) }
                    var precourseSingleMins by remember { mutableStateOf(sharedPrefs.getInt("precourse_single_mins", 15)) }

                    ExpandableSectionCard(
                        title = "⏰ 2. تنبيه الاستعداد المسبق قبل الحصة",
                        isExpanded = true,
                        onToggleExpand = {}
                    ) {
                        // Master Toggle for Pre-course notifications
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isTrainerStartEnabled) DawamiNavy.copy(alpha = 0.08f) else Color.Transparent)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("تفعيل تنبيه الاستعداد المسبق قبل الحصة ⏰", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = DawamiNavy)
                                Text("يطلق صوتاً مدمجاً لتجهيز القاعة وتنبيه المدرب قبل موعد الدورة", fontSize = 9.5.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = isTrainerStartEnabled,
                                onCheckedChange = {
                                    isTrainerStartEnabled = it
                                    sharedPrefs.edit().putBoolean("is_trainer_start_reminder_enabled", it).apply()
                                    viewModel.rescheduleAllReminders()
                                },
                                enabled = isNotificationsEnabled,
                                colors = customSwitchColors,
                                modifier = Modifier.scale(0.85f)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("اختر نمط التنبيه الصوتي المسبق لتجهيز القاعة بالملفات الصوتية المدمجة:", fontSize = 10.sp, color = Color.Gray)

                        // Option 1: Sequential 15m -> 10m -> 5m
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isPrecourseSmart) DawamiTeal.copy(alpha = 0.15f) else Color.Transparent)
                                .clickable {
                                    isPrecourseSmart = true
                                    isTrainerStartEnabled = true
                                    sharedPrefs.edit()
                                        .putBoolean("is_precourse_smart_repeating", true)
                                        .putBoolean("is_trainer_start_reminder_enabled", true)
                                        .apply()
                                    viewModel.rescheduleAllReminders()
                                    Toast.makeText(context, "تم تفعيل التنبيه التسلسلي قبل 15 و10 و5 دقائق ⚡", Toast.LENGTH_SHORT).show()
                                }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isPrecourseSmart,
                                onClick = {
                                    isPrecourseSmart = true
                                    isTrainerStartEnabled = true
                                    sharedPrefs.edit()
                                        .putBoolean("is_precourse_smart_repeating", true)
                                        .putBoolean("is_trainer_start_reminder_enabled", true)
                                        .apply()
                                    viewModel.rescheduleAllReminders()
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = DawamiTeal)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text("⚡ التذكير التسلسلي المتراتب (قبل 15د، ثم 10د، ثم 5د)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                Text("تنبيه صلب يطلق الصوت المناسب متتابعاً عند الدقيقة 15 و10 و5", fontSize = 9.5.sp, color = Color.Gray)
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray.copy(alpha = 0.4f))

                        // Single options: 15m, 10m, 5m
                        val singleOptions = listOf(
                            15 to "قبل 15 دقيقة من الموعد 🔊 (precourse_15min.wav)",
                            10 to "قبل 10 دقائق من الموعد 🔊 (precourse_10min.wav)",
                            5 to "قبل 5 دقائق من الموعد 🔊 (precourse_5min.wav)"
                        )

                        singleOptions.forEach { (mins, label) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (!isPrecourseSmart && precourseSingleMins == mins) DawamiTeal.copy(alpha = 0.12f) else Color.Transparent)
                                    .clickable {
                                        isPrecourseSmart = false
                                        isTrainerStartEnabled = true
                                        precourseSingleMins = mins
                                        sharedPrefs.edit()
                                            .putBoolean("is_precourse_smart_repeating", false)
                                            .putInt("precourse_single_mins", mins)
                                            .putBoolean("is_trainer_start_reminder_enabled", true)
                                            .apply()
                                        viewModel.rescheduleAllReminders()
                                        AudioPlayerHelper.playAudioOrSpeak(context, "precourse_${mins}min", "الرجاء الاستعداد للدورة باقي من الوقت $mins دقيقة", selectedVoiceGender)
                                        Toast.makeText(context, "تم تحديد التنبيه المسبق: قبل $mins دقيقة 🔊", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    RadioButton(
                                        selected = (!isPrecourseSmart && precourseSingleMins == mins),
                                        onClick = {
                                            isPrecourseSmart = false
                                            isTrainerStartEnabled = true
                                            precourseSingleMins = mins
                                            sharedPrefs.edit()
                                                .putBoolean("is_precourse_smart_repeating", false)
                                                .putInt("precourse_single_mins", mins)
                                                .putBoolean("is_trainer_start_reminder_enabled", true)
                                                .apply()
                                            viewModel.rescheduleAllReminders()
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = DawamiTeal)
                                    )
                                    Text(text = label, fontSize = 10.5.sp, fontWeight = if (!isPrecourseSmart && precourseSingleMins == mins) FontWeight.Bold else FontWeight.Normal, color = DawamiNavy)
                                }
                                IconButton(
                                    onClick = {
                                        AudioPlayerHelper.playAudioOrSpeak(context, "precourse_${mins}min", "الرجاء الاستعداد للدورة باقي من الوقت $mins دقيقة", selectedVoiceGender)
                                        Toast.makeText(context, "استماع للتنبيه الصوتي قبل $mins دقيقة 🔊", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "معاينة", tint = DawamiTeal, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Test button for pre-course alert
                        OutlinedButton(
                            onClick = {
                                AudioPlayerHelper.playAudioOrSpeak(context, "precourse_15min", "الرجاء الاستعداد للدورة، باقي من الوقت 15 دقيقة", selectedVoiceGender)
                                viewModel.sendTestNotification(
                                    title = "الاستعداد للمحاضرة ⏰",
                                    message = "الرجاء الاستعداد للدورة، باقي من الوقت 15 دقيقة",
                                    type = "trainer_start_15m",
                                    voiceGender = selectedVoiceGender
                                )
                                Toast.makeText(context, "تم إطلاق تنبيه تجريبي لما قبل الدورة 🔊", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth().height(36.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, DawamiTeal)
                        ) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("🔔 تجربة تنبيه ما قبل الدورة بالصوت والإشعار الآن", fontSize = 11.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Group 3: Unrecorded Movement Reminders (Single Switch: 5m -> 10m -> 30m -> 1h)
                item {
                    val sharedPrefs = remember { context.getSharedPreferences("dawami_prefs", Context.MODE_PRIVATE) }
                    var isUnrecordedEnabled by remember { mutableStateOf(sharedPrefs.getBoolean("is_unrecorded_reminders_enabled", true)) }

                    ExpandableSectionCard(
                        title = "⏱️ 3. التذكيرات المتتالية عند عدم تسجيل الحركة",
                        isExpanded = true,
                        onToggleExpand = {}
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isUnrecordedEnabled) DawamiGold.copy(alpha = 0.15f) else Color.Transparent)
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("تفعيل التذكيرات للتأخير (في حال عدم تسجيل أي حركة) ⏱️", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = DawamiNavy)
                                Text("عند التفعيل، يتم إعادة التذكير تلقائياً بعد: 5 دقائق ← 10 دقائق ← 30 دقيقة ← 1 ساعة بالصوت المدمج وتتوقف فور تسجيل الحركة آلياً.", fontSize = 9.5.sp, color = Color.DarkGray, lineHeight = 13.sp)
                            }
                            Switch(
                                checked = isUnrecordedEnabled,
                                onCheckedChange = {
                                    isUnrecordedEnabled = it
                                    sharedPrefs.edit().putBoolean("is_unrecorded_reminders_enabled", it).apply()
                                },
                                enabled = isNotificationsEnabled,
                                colors = customSwitchColors,
                                modifier = Modifier.scale(0.85f)
                            )
                        }
                    }
                }

                // Group 4: Integrated Audio Files Showcase & Preview (Always active by default)
                item {
                    ExpandableSectionCard(
                        title = "🔊 4. أصوات التنبيه المدمجة بالبرنامج (تعمل افتراضياً)",
                        isExpanded = true,
                        onToggleExpand = {}
                    ) {
                        Text("الأصوات الصوتية المدمجة بالمشروع مفعلة آلياً لكل نوع حركة لتأكيد التنبيه دون تشتيت:", fontSize = 10.sp, color = Color.Gray)

                        val audioList = listOf(
                            Triple("تحضير المدرب (Prompt)", "trainer_checkin_prompt", "الرجاء تحضير نفسك في حافظة الدوام"),
                            Triple("تأكيد تحضير المدرب (Success)", "trainer_checkin_success", "تم تسجيل حضور المدرب بنجاح"),
                            Triple("تحضير الطلاب (Prompt)", "student_checkin_prompt", "بدأت المحاضرة الرجاء تحضير الطلاب"),
                            Triple("تأكيد تحضير الطلاب (Success)", "student_checkin_success", "لقد تم تحضير الطلاب بنجاح شكرا لك"),
                            Triple("انصراف المدرب (Prompt)", "trainer_checkout_prompt", "انتهى وقت المحاضرة الرجاء تسجيل انصرافك"),
                            Triple("تأكيد انصراف المدرب (Success)", "trainer_checkout_success", "تم تسجيل انصراف المدرب بنجاح"),
                            Triple("انصراف الطلاب (Prompt)", "student_checkout_prompt", "حان وقت انصراف الطلاب"),
                            Triple("تأكيد انصراف الطلاب (Success)", "student_checkout_success", "تم تسجيل انصراف الطلاب بنجاح")
                        )

                        audioList.forEach { (title, rawName, fallbackText) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(title, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, color = DawamiNavy)
                                    Text("الملف الصوتي: $rawName.wav", fontSize = 8.5.sp, color = Color.Gray)
                                }
                                IconButton(
                                    onClick = {
                                        AudioPlayerHelper.playAudioOrSpeak(context, rawName, fallbackText, selectedVoiceGender)
                                        Toast.makeText(context, "معاينة صوت: $title 🔊", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "معاينة", tint = DawamiTeal, modifier = Modifier.size(18.dp))
                                }
                            }
                            HorizontalDivider(color = Color(0xFFF1F5F9))
                        }
                    }
                }

                // Save Button
                item {
                    Button(
                        onClick = {
                            val trainerMins = trainerMinsStr.toIntOrNull() ?: 15
                            val checkInMins = checkInMinsStr.toIntOrNull() ?: 10
                            val checkOutMins = checkOutMinsStr.toIntOrNull()?.takeIf { it > 0 } ?: 3

                            viewModel.updateSmartAssistantSettings(
                                enabled = isNotificationsEnabled,
                                trainerMins = trainerMins,
                                checkInMins = checkInMins,
                                checkOutMins = checkOutMins,
                                sound = selectedSound,
                                isTrainerStartEnabled = isTrainerStartEnabled,
                                isTrainerCheckInEnabled = isTrainerCheckInEnabled,
                                isStudentCheckInEnabled = isStudentCheckInEnabled,
                                isStudentCheckInSuccessEnabled = isStudentCheckInSuccess,
                                isStudentCheckOutEnabled = isStudentCheckOutEnabled,
                                isStudentCheckOutSuccessEnabled = isStudentCheckOutSuccess,
                                isThursdayNotificationsEnabled = isThursdayEnabled,
                                isFridayNotificationsEnabled = false,
                                trainerStartText = trainerStartTextState,
                                trainerCheckInText = trainerCheckInTextState,
                                studentCheckInText = studentCheckInTextState,
                                studentCheckInRemindText = studentCheckInRemindTextState,
                                studentCheckInSuccessText = studentCheckInSuccessTextState,
                                studentCheckOutText = studentCheckOutTextState,
                                studentCheckOutRemindText = studentCheckOutRemindTextState,
                                studentCheckOutSuccessText = studentCheckOutSuccessTextState,
                                voiceGender = selectedVoiceGender
                            )

                            Toast.makeText(context, "تم حفظ إعدادات المنبهات بنجاح! 🔔", Toast.LENGTH_LONG).show()
                        },
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ وتأكيد إعدادات التنبيهات والصوتيات 💾", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpandableSectionCard(
    title: String,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    borderColor: Color = Color(0xFFE2E8F0),
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() }
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = DawamiNavy,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "طي" else "توسيع",
                    tint = DawamiNavy,
                    modifier = Modifier.size(18.dp)
                )
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    content()
                }
            }
        }
    }
}

@Composable
private fun CompactSettingRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean,
    customSwitchColors: SwitchColors
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 10.5.sp,
                color = DawamiNavy
            )
            Text(
                text = description,
                fontSize = 9.5.sp,
                color = Color.Gray
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = customSwitchColors,
            modifier = Modifier.scale(0.8f)
        )
    }
}

@Composable
private fun CompactVoicePromptRow(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    enabled: Boolean,
    onPreview: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        OutlinedTextField(
            enabled = enabled,
            value = value,
            onValueChange = onValueChange,
            label = { Text(label, fontSize = 10.sp) },
            textStyle = TextStyle(fontSize = 10.5.sp),
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(6.dp),
            singleLine = true
        )
        IconButton(
            onClick = onPreview,
            modifier = Modifier.size(36.dp).padding(top = 4.dp)
        ) {
            Icon(Icons.Default.VolumeUp, contentDescription = "معاينة", tint = DawamiNavy, modifier = Modifier.size(18.dp))
        }
    }
}
