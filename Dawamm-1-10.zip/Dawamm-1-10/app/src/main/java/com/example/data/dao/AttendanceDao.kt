package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import com.example.data.entity.Attendance
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records ORDER BY date DESC, actualCheckIn DESC")
    fun getAllAttendance(): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance_records WHERE courseId = :courseId ORDER BY date DESC")
    fun getAttendanceByCourse(courseId: Int): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance_records WHERE courseId = :courseId AND date = :date LIMIT 1")
    suspend fun getAttendanceByCourseAndDateSync(courseId: Int, date: String): Attendance?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(attendance: Attendance): Long

    @Update
    suspend fun updateAttendance(attendance: Attendance)

    @Delete
    suspend fun deleteAttendance(attendance: Attendance)

    @Query("DELETE FROM attendance_records WHERE courseId = :courseId")
    suspend fun deleteByCourseId(courseId: Int)

    @Query("UPDATE attendance_records SET courseName = :newName WHERE courseId = :courseId")
    suspend fun updateCourseName(courseId: Int, newName: String)

    @Query("UPDATE attendance_records SET subjectName = :newName WHERE subjectName = :oldName")
    suspend fun updateSubjectName(oldName: String, newName: String)

    @Query("DELETE FROM attendance_records")
    suspend fun deleteAllAttendance()
}
