package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.Course
import com.example.ui.components.InlineExpandableDatePicker
import com.example.ui.components.InlineExpandableTimePicker
import com.example.ui.components.formatTimeTo12HourArabic
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.ui.viewmodel.Screen

// ---------------- COURSES SCREEN (دوراتي) ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoursesScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    showMainLayout: Boolean = true
) {
    val tempCourses by (courseViewModel?.allCourses ?: viewModel.tempCourses).collectAsState()
    val selectedCourseEdit by viewModel.selectedCourseForEdit.collectAsState()
    val dbAllStudents by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val dbAllStudentAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()
    val dbAttendance by (attendanceViewModel?.allAttendance ?: viewModel.dbAttendance).collectAsState()

    var courseToDelete by remember { mutableStateOf<Course?>(null) }
    var showDeleteCourseConfirmDialog by remember { mutableStateOf(false) }
    var showDeleteCourseWarningDialog by remember { mutableStateOf(false) }
    var showEditCourseConfirmDialog by remember { mutableStateOf(false) }

    var isAddCourseFormExpanded by remember { mutableStateOf(false) }
    var expandedCourseId by remember { mutableStateOf<Int?>(null) }
    var isSortNewestFirst by remember { mutableStateOf(true) }

    val sortedCourses = remember(tempCourses, isSortNewestFirst) {
        if (isSortNewestFirst) {
            tempCourses.sortedWith(compareByDescending<Course> { it.startDate.ifBlank { "0" } }.thenByDescending { it.id })
        } else {
            tempCourses.sortedWith(compareBy<Course> { it.startDate.ifBlank { "9999" } }.thenBy { it.id })
        }
    }

    val courseName by viewModel.courseNameInput.collectAsState()
    val courseStartDate by viewModel.courseStartDateInput.collectAsState()
    val courseEndDate by viewModel.courseEndDateInput.collectAsState()
    val courseStartTime by viewModel.courseStartTimeInput.collectAsState()
    val courseEndTime by viewModel.courseEndTimeInput.collectAsState()
    val courseDepartment by viewModel.courseDepartmentInput.collectAsState()
    val courseDiploma by viewModel.courseDiplomaInput.collectAsState()
    val allSubjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()
    val selectedSubjectIds by viewModel.selectedCourseSubjectsInput.collectAsState()
    val officialHolidays by viewModel.enabledOfficialHolidays.collectAsState()

    var isDeptDropdownExpanded by remember { mutableStateOf(false) }
    var isDiplomaDropdownExpanded by remember { mutableStateOf(false) }

    var defaultDaysText by remember { mutableStateOf("") }
    var includeThursday by remember { mutableStateOf(false) }
    var defaultHoursText by remember { mutableStateOf("") }

    LaunchedEffect(selectedCourseEdit, officialHolidays) {
        if (selectedCourseEdit != null) {
            val c = selectedCourseEdit!!
            val daysNoThur = countTrainingDays(c.startDate, c.endDate, false, officialHolidays)
            defaultDaysText = daysNoThur.toString()
            includeThursday = false
            
            val hrs = countHours(c.startTime, c.endTime)
            defaultHoursText = if (hrs > 0.0) {
                if (hrs % 1.0 == 0.0) hrs.toInt().toString() else hrs.toString()
            } else ""
        } else {
            defaultDaysText = ""
            includeThursday = false
            defaultHoursText = ""
        }
    }

    LaunchedEffect(courseStartDate, defaultDaysText, includeThursday, officialHolidays) {
        val days = defaultDaysText.toIntOrNull() ?: 0
        if (courseStartDate.isNotEmpty() && days > 0) {
            val calcEnd = calculateEndDate(courseStartDate, days, includeThursday, officialHolidays)
            viewModel.courseEndDateInput.value = calcEnd
        }
    }

    LaunchedEffect(courseStartTime, defaultHoursText) {
        val hrs = defaultHoursText.toDoubleOrNull() ?: 0.0
        if (courseStartTime.isNotEmpty() && hrs > 0.0) {
            val calcEnd = calculateEndTime(courseStartTime, hrs)
            viewModel.courseEndTimeInput.value = calcEnd
        }
    }

    val departmentsList = allSubjects.map { it.departmentName }.filter { it.isNotEmpty() }.distinct()
    val diplomasList = allSubjects.filter { courseDepartment.isEmpty() || it.departmentName == courseDepartment }.map { it.diplomaName }.filter { it.isNotEmpty() }.distinct()

    val context = LocalContext.current

    MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->
        if (showEditCourseConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showEditCourseConfirmDialog = false },
                title = {
                    Text(
                        text = "تأكيد تعديل الدورة 🎓",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = DawamiNavy
                    )
                },
                text = {
                    Text(
                        text = "هل أنت متأكد من رغبتك في حفظ التعديلات الجديدة على هذه الدورة؟",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.addOrUpdateCourseTemp()
                            Toast.makeText(context, "تم حفظ تعديلات الدورة بنجاح! ✨", Toast.LENGTH_SHORT).show()
                            showEditCourseConfirmDialog = false
                        }
                    ) {
                        Text("تأكيد وحفظ", color = DawamiNavy, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showEditCourseConfirmDialog = false }
                    ) {
                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                shape = RoundedCornerShape(10.dp),
                containerColor = MaterialTheme.colorScheme.surface
            )
        }
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {

            // Quick Navigation Shortcuts
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                viewModel.openTrainerGroup(1)
                            },
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = DawamiNavy.copy(alpha = 0.08f)),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("⏱️ تحضير المدرب", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        }
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                viewModel.navigateTo(Screen.TrainerFinances)
                            },
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = DawamiTeal.copy(alpha = 0.08f)),
                        border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("💰 المستحقات والسلف", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                        }
                    }
                }
            }

            // Form Card (Collapsible - Collapsed by default)
            val isFormVisible = isAddCourseFormExpanded || selectedCourseEdit != null
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Header Row for Collapse / Expand
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    isAddCourseFormExpanded = !isAddCourseFormExpanded
                                }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (selectedCourseEdit != null) Icons.Default.Edit else Icons.Default.AddCircleOutline,
                                    contentDescription = null,
                                    tint = DawamiNavy,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = if (selectedCourseEdit != null) "تعديل بيانات الدورة" else "إضافة دورة تدريبية جديدة",
                                    color = DawamiNavy,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(
                                onClick = { isAddCourseFormExpanded = !isAddCourseFormExpanded },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = if (isFormVisible) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = if (isFormVisible) "طي" else "توسيع",
                                    tint = DawamiNavy
                                )
                            }
                        }

                        if (isFormVisible) {
                            OutlinedTextField(
                                value = courseName,
                                onValueChange = { viewModel.courseNameInput.value = it },
                                label = { Text("اسم الدورة التدريبية") },
                                placeholder = { Text("مثال: هندسة البرمجيات المتقدمة") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )

                        // Department Dropdown
                        ExposedDropdownMenuBox(
                            expanded = isDeptDropdownExpanded,
                            onExpandedChange = { isDeptDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = courseDepartment.ifEmpty { "اختر القسم التدريبي..." },
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("القسم التدريبي") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDeptDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = isDeptDropdownExpanded,
                                onDismissRequest = { isDeptDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("بدون قسم محدد", color = Color.Gray) },
                                    onClick = {
                                        viewModel.courseDepartmentInput.value = ""
                                        viewModel.courseDiplomaInput.value = ""
                                        isDeptDropdownExpanded = false
                                    }
                                )
                                departmentsList.forEach { dept ->
                                    DropdownMenuItem(
                                        text = { Text(dept, fontWeight = FontWeight.Medium) },
                                        onClick = {
                                            viewModel.courseDepartmentInput.value = dept
                                            viewModel.courseDiplomaInput.value = ""
                                            isDeptDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Diploma Dropdown
                        ExposedDropdownMenuBox(
                            expanded = isDiplomaDropdownExpanded,
                            onExpandedChange = { isDiplomaDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = courseDiploma.ifEmpty { "اختر الدبلوم التدريبي (المواد المرتبطة)..." },
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("الدبلوم المرتبط") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDiplomaDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = isDiplomaDropdownExpanded,
                                onDismissRequest = { isDiplomaDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("بدون دبلوم محدد", color = Color.Gray) },
                                    onClick = {
                                        viewModel.courseDiplomaInput.value = ""
                                        isDiplomaDropdownExpanded = false
                                    }
                                )
                                diplomasList.forEach { diploma ->
                                    DropdownMenuItem(
                                        text = { Text(diploma, fontWeight = FontWeight.Medium) },
                                        onClick = {
                                            viewModel.selectDiplomaForCourseForm(diploma)
                                            isDiplomaDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Start/End Dates
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            InlineExpandableDatePicker(selectedDate = courseStartDate, onDateSelected = { viewModel.courseStartDateInput.value = it }, label = "تاريخ البداية", modifier = Modifier.weight(1f))

                            InlineExpandableDatePicker(selectedDate = courseEndDate, onDateSelected = { viewModel.courseEndDateInput.value = it }, label = "تاريخ النهاية", modifier = Modifier.weight(1f))
                        }

                        if (courseStartDate.isNotEmpty()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = defaultDaysText,
                                    onValueChange = { newValue ->
                                        if (newValue.all { it.isDigit() }) {
                                            defaultDaysText = newValue
                                        }
                                    },
                                    label = { Text("عدد الأيام الافتراضي") },
                                    placeholder = { Text("مثال: 12") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(56.dp)
                                        .background(
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable { includeThursday = !includeThursday }
                                        .padding(horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Checkbox(
                                        checked = includeThursday,
                                        onCheckedChange = { includeThursday = it },
                                        colors = CheckboxDefaults.colors(checkedColor = DawamiNavy)
                                    )
                                    Text(
                                        text = "احتساب يوم الخميس\n(الجمعة مستبعد دائماً)",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiNavy,
                                        lineHeight = 12.sp
                                    )
                                }
                            }
                        }

                        // Start/End Times
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            InlineExpandableTimePicker(selectedTime = courseStartTime, label = "وقت البداية", onTimeSelected = { viewModel.courseStartTimeInput.value = it }, modifier = Modifier.weight(1f))

                            InlineExpandableTimePicker(selectedTime = courseEndTime, label = "وقت النهاية", onTimeSelected = { viewModel.courseEndTimeInput.value = it }, modifier = Modifier.weight(1f))
                        }

                        if (courseStartTime.isNotEmpty()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = defaultHoursText,
                                    onValueChange = { newValue ->
                                        if (newValue.all { it.isDigit() || it == '.' }) {
                                            defaultHoursText = newValue
                                        }
                                    },
                                    label = { Text("عدد الساعات الافتراضي") },
                                    placeholder = { Text("مثال: 4") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(56.dp)
                                        .background(
                                            DawamiNavy.copy(alpha = 0.05f),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = DawamiNavy.copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .padding(horizontal = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "سيتم حساب وقت النهاية تلقائياً ويمكنك تعديله يدوياً.",
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = DawamiNavy,
                                        lineHeight = 12.sp
                                    )
                                }
                            }
                        }

                        // Course Subjects Checklist
                        if (allSubjects.isNotEmpty()) {
                            var isSubjectsExpanded by remember { mutableStateOf(false) }
                            var showAllSubjectsToggle by remember { mutableStateOf(false) }

                            val availableSubjectsForCourse = remember(allSubjects, courseDepartment, courseDiploma, showAllSubjectsToggle) {
                                if (showAllSubjectsToggle) {
                                    allSubjects
                                } else if (courseDiploma.isNotEmpty()) {
                                    val filtered = allSubjects.filter { it.diplomaName.equals(courseDiploma, ignoreCase = true) }
                                    if (filtered.isNotEmpty()) filtered else allSubjects.filter { courseDepartment.isEmpty() || it.departmentName.equals(courseDepartment, ignoreCase = true) }
                                } else if (courseDepartment.isNotEmpty()) {
                                    val filtered = allSubjects.filter { it.departmentName.equals(courseDepartment, ignoreCase = true) }
                                    if (filtered.isNotEmpty()) filtered else allSubjects
                                } else {
                                    allSubjects
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                            ) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    // Header click to toggle collapse/expand
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { isSubjectsExpanded = !isSubjectsExpanded }
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Book,
                                                contentDescription = null,
                                                tint = DawamiNavy,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            val checklistTitle = when {
                                                courseDiploma.isNotEmpty() -> "مواد $courseDiploma"
                                                courseDepartment.isNotEmpty() -> "مواد $courseDepartment"
                                                else -> "تعيين المواد التدريسية المشمولة بالدورة"
                                            }
                                            Text(
                                                text = checklistTitle,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            if (selectedSubjectIds.isNotEmpty()) {
                                                Surface(
                                                    color = DawamiNavy,
                                                    shape = RoundedCornerShape(10.dp)
                                                ) {
                                                    Text(
                                                        text = "${selectedSubjectIds.size}",
                                                        color = Color.White,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = if (isSubjectsExpanded) "طي" else "توسيع",
                                            tint = DawamiNavy,
                                            modifier = Modifier
                                                .size(20.dp)
                                                .rotate(if (isSubjectsExpanded) 180f else 0f)
                                        )
                                    }

                                    AnimatedVisibility(visible = isSubjectsExpanded) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            HorizontalDivider(
                                                color = Color(0xFFE2E8F0),
                                                modifier = Modifier.padding(bottom = 6.dp)
                                            )
                                            if (courseDiploma.isNotEmpty() || courseDepartment.isNotEmpty()) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = if (showAllSubjectsToggle) "معروض: جميع مواد المعهد (${availableSubjectsForCourse.size})" else "معروض: مواد الدبلوم (${availableSubjectsForCourse.size})",
                                                        fontSize = 10.5.sp,
                                                        color = DawamiNavy,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    TextButton(
                                                        onClick = { showAllSubjectsToggle = !showAllSubjectsToggle },
                                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = if (showAllSubjectsToggle) "عرض مواد الدبلوم فقط" else "عرض كافة المواد",
                                                            fontSize = 10.5.sp,
                                                            color = DawamiTeal,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }
                                            availableSubjectsForCourse.forEach { subject ->
                                                val isChecked = selectedSubjectIds.contains(subject.id)
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable { viewModel.toggleSubjectSelectionInForm(subject.id) }
                                                        .padding(vertical = 2.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Checkbox(
                                                        checked = isChecked,
                                                        onCheckedChange = { viewModel.toggleSubjectSelectionInForm(subject.id) },
                                                        colors = CheckboxDefaults.colors(checkedColor = DawamiNavy)
                                                    )
                                                    Text(
                                                        text = subject.name,
                                                        color = MaterialTheme.colorScheme.onSurface,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                    if (subject.diplomaName.isNotEmpty()) {
                                                        Spacer(modifier = Modifier.weight(1f))
                                                        Text(
                                                            text = subject.diplomaName,
                                                            color = Color.Gray,
                                                            fontSize = 9.5.sp
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // CRUD Control Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (courseName.isEmpty() || courseStartDate.isEmpty() || courseEndDate.isEmpty() || courseStartTime.isEmpty() || courseEndTime.isEmpty()) {
                                        Toast.makeText(context, "الرجاء تعبئة كافة الحقول!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        if (selectedCourseEdit != null) {
                                            showEditCourseConfirmDialog = true
                                        } else {
                                            viewModel.addOrUpdateCourseTemp()
                                            Toast.makeText(context, "تم حفظ الدورة التدريبية بنجاح! 🎉", Toast.LENGTH_SHORT).show()
                                            isAddCourseFormExpanded = false
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                modifier = Modifier.weight(1.3f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (selectedCourseEdit != null) "تعديل الدورة" else "حفظ الدورة")
                            }

                            if (selectedCourseEdit != null) {
                                OutlinedButton(
                                    onClick = {
                                        viewModel.clearCourseForm()
                                        isAddCourseFormExpanded = false
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("إلغاء")
                                }
                            }
                        }
                    }
                }
            }
            }

            // Temp Table Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "قائمة الدورات التدريبية المضافة",
                            color = DawamiNavy,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Badge(containerColor = DawamiGold) {
                            Text("${tempCourses.size} دورات", color = Color.White, modifier = Modifier.padding(2.dp))
                        }
                    }

                    // Sort Toggle
                    Surface(
                        onClick = { isSortNewestFirst = !isSortNewestFirst },
                        shape = RoundedCornerShape(8.dp),
                        color = DawamiNavy.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (isSortNewestFirst) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                contentDescription = null,
                                tint = DawamiNavy,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = if (isSortNewestFirst) "الأحدث أولاً" else "الأقدم أولاً",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy
                            )
                        }
                    }
                }
            }

            if (sortedCourses.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(0.6f))
                    ) {
                        Text(
                            text = "لا توجد دورات مدرجة حالياً. قم بإضافة دورة بالأعلى.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        )
                    }
                }
            } else {
                items(sortedCourses, key = { it.id }) { course ->
                    val isExpanded = expandedCourseId == course.id

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (selectedCourseEdit?.id == course.id) DawamiNavy else if (isExpanded) DawamiNavy.copy(alpha = 0.4f) else Color(0xFFE2E8F0)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = if (isExpanded) 2.dp else 1.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Header Row (Always visible and clickable to toggle expand/collapse)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable {
                                        expandedCourseId = if (isExpanded) null else course.id
                                    }
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f, fill = false)
                                ) {
                                    Text(
                                        text = course.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (course.isCompleted) Color(0xFF64748B) else DawamiNavy
                                    )
                                    Surface(
                                        color = if (course.isCompleted) Color(0xFFF1F5F9) else Color(0xFFDCFCE7),
                                        shape = RoundedCornerShape(6.dp),
                                        border = BorderStroke(1.dp, if (course.isCompleted) Color(0xFFCBD5E1) else Color(0xFF86EFAC))
                                    ) {
                                        Text(
                                            text = if (course.isCompleted) "🔒 منتهية" else "🟢 مستمرة",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (course.isCompleted) Color(0xFF475569) else Color(0xFF166534),
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    IconButton(
                                        onClick = {
                                            viewModel.selectCourseForEdit(course)
                                            isAddCourseFormExpanded = true
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = DawamiNavy, modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(
                                        onClick = {
                                            courseToDelete = course
                                            val hasStudents = dbAllStudents.any { it.courseId == course.id }
                                            val hasAttendance = dbAllStudentAttendance.any { it.courseId == course.id } || dbAttendance.any { it.courseId == course.id }
                                            if (hasStudents || hasAttendance) {
                                                showDeleteCourseWarningDialog = true
                                            } else {
                                                showDeleteCourseConfirmDialog = true
                                            }
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    }
                                    Icon(
                                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = if (isExpanded) "طي" else "توسيع",
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(20.dp).padding(start = 2.dp)
                                    )
                                }
                            }

                            if (showDeleteCourseWarningDialog && courseToDelete?.id == course.id) {
                                AlertDialog(
                                    onDismissRequest = { showDeleteCourseWarningDialog = false },
                                    title = {
                                        Text(
                                            text = "لا يمكن حذف الدورة ⚠️",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = DawamiNavy
                                        )
                                    },
                                    text = {
                                        Text(
                                            text = "يمنع حذف أي دورة تدريبية إلا إذا كانت فارغة تماماً. هذه الدورة تحتوي على طلاب مسجلين أو سجلات حضور مسجلة حالياً. يرجى حذف الطلاب وسجلات الحضور أولاً قبل محاولة حذف الدورة.",
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    confirmButton = {
                                        TextButton(
                                            onClick = { showDeleteCourseWarningDialog = false }
                                        ) {
                                            Text("موافق", color = DawamiNavy, fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            }

                            if (showDeleteCourseConfirmDialog && courseToDelete?.id == course.id) {
                                AlertDialog(
                                    onDismissRequest = { showDeleteCourseConfirmDialog = false },
                                    title = {
                                        Text(
                                            text = "تأكيد حذف الدورة 🗑️",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = DawamiNavy
                                        )
                                    },
                                    text = {
                                        Text(
                                            text = "هل أنت متأكد من حذف دورة '${courseToDelete?.name}' بشكل نهائي؟ لا يمكن التراجع عن هذا الإجراء.",
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    confirmButton = {
                                        TextButton(
                                            onClick = {
                                                viewModel.deleteCourseTemp(course)
                                                Toast.makeText(context, "تم حذف الدورة بنجاح!", Toast.LENGTH_SHORT).show()
                                                showDeleteCourseConfirmDialog = false
                                            }
                                        ) {
                                            Text("نعم، احذف", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    dismissButton = {
                                        TextButton(
                                            onClick = { showDeleteCourseConfirmDialog = false }
                                        ) {
                                            Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            }

                            if (isExpanded) {
                                Divider(color = Color.LightGray.copy(0.3f), modifier = Modifier.padding(top = 4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("الفترة الزمنية للتعاقد", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${course.startDate.ifBlank { "غير محددة" }} إلى ${course.endDate.ifBlank { "مستمرة" }}", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("أوقات المحاضرات الرسمية", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${formatTimeTo12HourArabic(course.startTime)} - ${formatTimeTo12HourArabic(course.endTime)}", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = DawamiTeal)
                                    }
                                }

                                Divider(color = Color.LightGray.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 4.dp))

                                // Calculate course days and actual hours from trainer daily records
                                val courseRecords = dbAttendance.filter { it.courseId == course.id }
                                val totalDays = courseRecords.count { it.status == "حضور" }
                                val totalWorkingMinutes = courseRecords.filter { it.status == "حضور" }
                                    .sumOf { (it.durationHours * 60) + it.durationMinutes }
                                val actualHours = totalWorkingMinutes / 60
                                val actualMinutes = totalWorkingMinutes % 60

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("إجمالي أيام الدورة الحالية", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("$totalDays يوم", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("ساعات الدوام الفعلي بالدورة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("$actualHours س و $actualMinutes د", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                    }
                                }

                                Divider(color = Color.LightGray.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 2.dp))

                                // Course completion action button
                                OutlinedButton(
                                    onClick = {
                                        viewModel.toggleCourseCompleted(course)
                                        val msg = if (!course.isCompleted) "تم تعيين الدورة كمنتهية 🏁 وتجميد التحضير لحماية السجلات" else "تمت إعادة تنشيط الدورة كمستمرة 🔄"
                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(32.dp),
                                    shape = RoundedCornerShape(6.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (course.isCompleted) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)
                                    ),
                                    border = BorderStroke(1.dp, if (course.isCompleted) Color(0xFF86EFAC) else Color(0xFFFECACA)),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(
                                        text = if (course.isCompleted) "🔄 إعادة تنشيط الدورة (جعلها مستمرة)" else "🏁 جعل الدورة منتهية",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (course.isCompleted) Color(0xFF15803D) else Color(0xFFDC2626)
                                    )
                                }

                                // Attendance Action Buttons (Frozen if course is completed)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    if (course.isCompleted) {
                                        // Frozen Trainer Attendance Button
                                        OutlinedButton(
                                            onClick = {
                                                Toast.makeText(context, "🔒 هذه الدورة منتهية ومجمدة. لإضافة تحضير، أعد تنشيط الدورة أولاً 🔄", Toast.LENGTH_LONG).show()
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(containerColor = Color(0xFFF1F5F9)),
                                            border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("🔒 تحضير المدرب (مجمّد)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
                                        }

                                        // Frozen Student Attendance Button
                                        OutlinedButton(
                                            onClick = {
                                                Toast.makeText(context, "🔒 هذه الدورة منتهية ومجمدة. لرصد حضور الطلاب، أعد تنشيط الدورة أولاً 🔄", Toast.LENGTH_LONG).show()
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(containerColor = Color(0xFFF1F5F9)),
                                            border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("🔒 حضور الطلاب (مجمّد)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
                                        }
                                    } else {
                                        // Active Trainer Attendance Button
                                        OutlinedButton(
                                            onClick = {
                                                viewModel.selectCourseForAttendance(course)
                                                viewModel.openTrainerGroup(1)
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, DawamiNavy),
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Schedule, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("⏱️ تحضير المدرب", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                        }

                                        // Active Student Attendance Button
                                        OutlinedButton(
                                            onClick = {
                                                viewModel.selectCourseForStudentAttendance(course)
                                                viewModel.openStudentsGroup(0)
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, DawamiTeal),
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Group, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("👨‍🎓 حضور الطلاب", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

