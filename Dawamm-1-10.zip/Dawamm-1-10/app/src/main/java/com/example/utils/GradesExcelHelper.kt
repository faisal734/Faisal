package com.example.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Xml
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentGradeConfig
import org.xmlpull.v1.XmlPullParser
import java.io.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

enum class GradeTemplateType {
    DETAILED_ITEMS, // رصد تفصيلي بالبنود (حضور، مشاركة، واجبات، مشروع، نظري، عملي، مجموع)
    DIRECT_FINAL    // رصد نهائي مباشر (درجة المادة من 100 مباشرة)
}

data class XlsxCell(
    val value: String = "",
    val styleIndex: Int = 0,
    val isNumber: Boolean = false
)

data class ParsedGradeRow(
    val originalRowIndex: Int,
    val studentId: Int,
    val studentName: String,
    val subjectName: String,
    val isDiploma: Boolean,
    var attendanceScore: Double = 0.0,
    var participationScore: Double = 0.0,
    var assignmentsScore: Double = 0.0,
    var projectsScore: Double = 0.0,
    var theoreticalExamScore: Double = 0.0,
    var practicalExamScore: Double = 0.0,
    var customScoresMap: MutableMap<String, Double> = mutableMapOf(),
    var isDirectFinal: Boolean = false,
    var finalScore: Double = 0.0,
    var note: String = "",
    var isMatchedStudent: Boolean = true,
    var matchedStudent: Student? = null,
    var warningMessage: String? = null
) {
    fun calculateTotal(): Double {
        return if (isDirectFinal) {
            finalScore
        } else if (isDiploma) {
            attendanceScore + participationScore + assignmentsScore + projectsScore + theoreticalExamScore + practicalExamScore
        } else {
            customScoresMap.values.sum()
        }
    }

    fun getGradeEstimate(): String {
        val total = calculateTotal()
        return when {
            total >= 90.0 -> "ممتاز"
            total >= 80.0 -> "جيد جداً"
            total >= 70.0 -> "جيد"
            total >= 60.0 -> "مقبول"
            else -> "راسب"
        }
    }
}

data class GradeImportResult(
    val isSuccess: Boolean,
    val totalRows: Int,
    val matchedCount: Int,
    val unmatchedCount: Int,
    val parsedRows: List<ParsedGradeRow>,
    val detectedType: GradeTemplateType,
    val errorOrWarningMessage: String? = null,
    val isCourseMismatch: Boolean = false,
    val detectedCourseId: Long? = null,
    val detectedCourseName: String? = null
)

object GradesExcelHelper {

    const val ALL_SUBJECTS_HORIZONTAL = "جميع المواد (أعمدة أفقية مجمعة 📊)"
    const val XLSX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    // --- مجلد التقارير المعتمد (Reports Directory) ---
    fun getReportsDirectory(context: Context): File {
        val extDir = context.getExternalFilesDir("Reports")
        if (extDir != null) {
            if (!extDir.exists()) extDir.mkdirs()
            return extDir
        }
        val intDir = File(context.filesDir, "Reports")
        if (!intDir.exists()) intDir.mkdirs()
        return intDir
    }

    // --- دوال تحويل أسماء الأعمدة في إكسل ---
    fun colIndexToLetter(colIndex: Int): String {
        var temp = colIndex
        var letter = ""
        while (temp >= 0) {
            letter = ('A'.code + (temp % 26)).toChar() + letter
            temp = (temp / 26) - 1
        }
        return letter
    }

    fun colLetterToIndex(colLetter: String): Int {
        var result = 0
        for (ch in colLetter.uppercase(Locale.US)) {
            if (ch in 'A'..'Z') {
                result = result * 26 + (ch.code - 'A'.code + 1)
            }
        }
        return result - 1
    }

    fun colRefToIndex(cellRef: String): Int {
        val letters = cellRef.takeWhile { it.isLetter() }
        if (letters.isEmpty()) return 0
        return colLetterToIndex(letters)
    }

    fun escapeXml(text: String): String {
        return text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    // --- محرك إنشاء وتصدير ملفات Microsoft Excel (.xlsx) الأصلية ---
    fun writeXlsx(
        outputFile: File,
        sheetName: String,
        rows: List<List<XlsxCell>>,
        colWidths: Map<Int, Double>,
        merges: List<String>,
        courseId: Long = 0L,
        courseName: String = ""
    ) {
        FileOutputStream(outputFile).use { fos ->
            ZipOutputStream(BufferedOutputStream(fos)).use { zip ->
                // 1. [Content_Types].xml
                zip.putNextEntry(ZipEntry("[Content_Types].xml"))
                zip.write(
                    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>""".toByteArray(Charsets.UTF_8)
                )
                zip.closeEntry()

                // 2. _rels/.rels
                zip.putNextEntry(ZipEntry("_rels/.rels"))
                zip.write(
                    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
</Relationships>""".toByteArray(Charsets.UTF_8)
                )
                zip.closeEntry()

                // 2.5 docProps/core.xml
                zip.putNextEntry(ZipEntry("docProps/core.xml"))
                zip.write(
                    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>${escapeXml(courseName)}</dc:title>
  <dc:subject>COURSE_ID:$courseId</dc:subject>
  <cp:keywords>COURSE_ID:$courseId|COURSE_NAME:${escapeXml(courseName)}</cp:keywords>
  <dc:description>Dawami Grade Export File for Course: ${escapeXml(courseName)} (ID: $courseId)</dc:description>
</cp:coreProperties>""".toByteArray(Charsets.UTF_8)
                )
                zip.closeEntry()

                // 3. xl/_rels/workbook.xml.rels
                zip.putNextEntry(ZipEntry("xl/_rels/workbook.xml.rels"))
                zip.write(
                    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>""".toByteArray(Charsets.UTF_8)
                )
                zip.closeEntry()

                // 4. xl/workbook.xml
                zip.putNextEntry(ZipEntry("xl/workbook.xml"))
                zip.write(
                    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="${escapeXml(sheetName)}" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>""".toByteArray(Charsets.UTF_8)
                )
                zip.closeEntry()

                // 5. xl/styles.xml
                zip.putNextEntry(ZipEntry("xl/styles.xml"))
                zip.write(
                    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="3">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="12"/><color rgb="FF1F497D"/><name val="Calibri"/></font>
  </fonts>
  <fills count="5">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFF2F4F7"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFCE4D6"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/></border>
    <border>
      <left style="thin"><color rgb="FFB0B0B0"/></left>
      <right style="thin"><color rgb="FFB0B0B0"/></right>
      <top style="thin"><color rgb="FFB0B0B0"/></top>
      <bottom style="thin"><color rgb="FFB0B0B0"/></bottom>
    </border>
  </borders>
  <cellStyleXfs count="1">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
  </cellStyleXfs>
  <cellXfs count="6">
    <!-- 0: Default -->
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <!-- 1: Header Top Row (Subject merged) bold, light gray/blue fill, centered, bordered -->
    <xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="center" vertical="center" wrapText="1"/>
    </xf>
    <!-- 2: Sub-header Row (حضور، مشاركة...) bold, centered, bordered -->
    <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="center" vertical="center" wrapText="1"/>
    </xf>
    <!-- 3: Data Cell centered, bordered -->
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1">
      <alignment horizontal="center" vertical="center"/>
    </xf>
    <!-- 4: Separator Column Cell (blue fill) -->
    <xf numFmtId="0" fontId="0" fillId="3" borderId="1" xfId="0" applyFill="1" applyBorder="1">
      <alignment horizontal="center" vertical="center"/>
    </xf>
    <!-- 5: Average / Special Highlight Cell (pink fill, bold, centered) -->
    <xf numFmtId="0" fontId="1" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="center" vertical="center"/>
    </xf>
  </cellXfs>
</styleSheet>""".toByteArray(Charsets.UTF_8)
                )
                zip.closeEntry()

                // 6. Build Sheet XML with standard Inline Strings (is/t)
                val sheetXml = StringBuilder()
                sheetXml.append(
                    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetViews>
    <sheetView rightToLeft="1" tabSelected="1" workbookViewId="0"/>
  </sheetViews>
  <sheetFormatPr defaultRowHeight="22"/>
"""
                )

                if (colWidths.isNotEmpty()) {
                    sheetXml.append("  <cols>\n")
                    colWidths.forEach { (colIdx, width) ->
                        val colNum = colIdx + 1
                        sheetXml.append("    <col min=\"$colNum\" max=\"$colNum\" width=\"$width\" customWidth=\"1\"/>\n")
                    }
                    sheetXml.append("  </cols>\n")
                }

                sheetXml.append("  <sheetData>\n")

                rows.forEachIndexed { rIdx, rowCells ->
                    val rowNum = rIdx + 1
                    sheetXml.append("    <row r=\"$rowNum\">\n")
                    rowCells.forEachIndexed { cIdx, cell ->
                        val cellRef = "${colIndexToLetter(cIdx)}$rowNum"
                        val styleAttr = if (cell.styleIndex > 0) " s=\"${cell.styleIndex}\"" else ""
                        if (cell.value.isEmpty()) {
                            if (cell.styleIndex > 0) {
                                sheetXml.append("      <c r=\"$cellRef\"$styleAttr/>\n")
                            }
                        } else if (cell.isNumber) {
                            sheetXml.append("      <c r=\"$cellRef\"$styleAttr><v>${cell.value}</v></c>\n")
                        } else {
                            sheetXml.append("      <c r=\"$cellRef\" t=\"inlineStr\"$styleAttr><is><t xml:space=\"preserve\">${escapeXml(cell.value)}</t></is></c>\n")
                        }
                    }
                    sheetXml.append("    </row>\n")
                }
                sheetXml.append("  </sheetData>\n")

                if (merges.isNotEmpty()) {
                    sheetXml.append("  <mergeCells count=\"${merges.size}\">\n")
                    merges.forEach { m ->
                        sheetXml.append("    <mergeCell ref=\"$m\"/>\n")
                    }
                    sheetXml.append("  </mergeCells>\n")
                }
                sheetXml.append("</worksheet>")

                // 7. Write xl/worksheets/sheet1.xml
                zip.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
                zip.write(sheetXml.toString().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
    }

    // --- توليد وتصدير ملف Excel (.xlsx) القياسي المعتمد ---
    fun generateAndExportTemplate(
        context: Context,
        course: Course,
        subjectName: String,
        allSubjects: List<String> = emptyList(),
        students: List<Student>,
        config: StudentGradeConfig?,
        existingGrades: List<StudentGrade>,
        templateType: GradeTemplateType,
        trainerBaseDirUri: String = ""
    ): File? {
        try {
            val isDiploma = config?.isDiploma ?: true
            val reportsDir = getReportsDirectory(context)
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            val cleanCourseName = course.name.replace("[\\\\/:*?\"<>|]".toRegex(), "_")
            val isAllSubjects = subjectName == ALL_SUBJECTS_HORIZONTAL || subjectName.contains("جميع المواد")
            val cleanSubjectName = if (isAllSubjects) "كافة_المواد" else subjectName.replace("[\\\\/:*?\"<>|]".toRegex(), "_")
            val modeSuffix = if (templateType == GradeTemplateType.DETAILED_ITEMS) "تفصيلي" else "نهائي_مباشر"
            val fileName = "كشف_رصد_${cleanCourseName}_${cleanSubjectName}_${modeSuffix}_$timeStamp.xlsx"
            val file = File(reportsDir, fileName)

            val targetSubjects: List<String> = if (isAllSubjects) {
                if (allSubjects.isNotEmpty()) {
                    allSubjects
                } else if (isDiploma && config != null) {
                    config.getDiplomaSubjects()
                } else if (config != null) {
                    val cFields = StudentGradeConfig.deserializeFields(config.customFieldsJson)
                    val subs = cFields.map { it.first.substringBefore("_") }.distinct()
                    if (subs.isNotEmpty()) subs else listOf("المقرر العام")
                } else {
                    listOf("المقرر العام")
                }
            } else {
                listOf(subjectName)
            }

            val rows = mutableListOf<List<XlsxCell>>()
            val colWidths = mutableMapOf<Int, Double>()
            val merges = mutableListOf<String>()

            colWidths[0] = 10.0 // رقم الطالب
            colWidths[1] = 24.0 // اسم الطالب

            if (templateType == GradeTemplateType.DETAILED_ITEMS) {
                // ====== 1. النموذج التفصيلي المطابق للصورة تماماً ======
                // الصف الأول: رؤوس المواد المدمجة
                val row1 = mutableListOf<XlsxCell>()
                row1.add(XlsxCell("رقم الطالب", styleIndex = 2))
                row1.add(XlsxCell("اسم الطالب", styleIndex = 2))

                // الصف الثاني: البنود التفصيلية
                val row2 = mutableListOf<XlsxCell>()
                row2.add(XlsxCell("رقم الطالب", styleIndex = 2))
                row2.add(XlsxCell("اسم الطالب", styleIndex = 2))

                var currentCol = 2

                targetSubjects.forEach { sub ->
                    val startCol = currentCol
                    // Row 1: Subject Title Cell
                    row1.add(XlsxCell(sub, styleIndex = 1))
                    for (k in 1..6) {
                        row1.add(XlsxCell("", styleIndex = 1))
                    }
                    // Separator Column in Row 1 (blue)
                    row1.add(XlsxCell("", styleIndex = 4))

                    // Row 2: Sub-headers exactly matching the photo
                    row2.add(XlsxCell("حضور 5%", styleIndex = 2))
                    row2.add(XlsxCell("مشاركة 5%", styleIndex = 2))
                    row2.add(XlsxCell("واجبات 10%", styleIndex = 2))
                    row2.add(XlsxCell("المشروع 20%", styleIndex = 2))
                    row2.add(XlsxCell("نظري 20%", styleIndex = 2))
                    row2.add(XlsxCell("عملي 40%", styleIndex = 2))
                    row2.add(XlsxCell("المجموع 100%", styleIndex = 2))
                    // Separator in Row 2 (blue)
                    row2.add(XlsxCell("", styleIndex = 4))

                    // Merge subject title horizontally across the 7 sub-columns: C1:I1
                    val startLetter = colIndexToLetter(startCol)
                    val endLetter = colIndexToLetter(startCol + 6)
                    merges.add("${startLetter}1:${endLetter}1")

                    // Merge separator column vertically across row 1 and row 2
                    val sepLetter = colIndexToLetter(startCol + 7)
                    merges.add("${sepLetter}1:${sepLetter}2")

                    // Column Widths
                    colWidths[startCol + 0] = 9.5
                    colWidths[startCol + 1] = 9.5
                    colWidths[startCol + 2] = 11.0
                    colWidths[startCol + 3] = 12.0
                    colWidths[startCol + 4] = 11.0
                    colWidths[startCol + 5] = 11.0
                    colWidths[startCol + 6] = 13.0
                    colWidths[startCol + 7] = 3.5 // عمود فاصل ملوّن

                    currentCol += 8
                }

                // Final Summary Columns
                val totalColIdx = currentCol
                row1.add(XlsxCell("المجموع النهائي", styleIndex = 2))
                row2.add(XlsxCell("المجموع النهائي", styleIndex = 2))
                merges.add("${colIndexToLetter(totalColIdx)}1:${colIndexToLetter(totalColIdx)}2")
                colWidths[totalColIdx] = 14.0
                currentCol++

                val avgColIdx = currentCol
                row1.add(XlsxCell("المعدل", styleIndex = 5)) // تظليل وردي للمعدل
                row2.add(XlsxCell("المعدل", styleIndex = 5))
                merges.add("${colIndexToLetter(avgColIdx)}1:${colIndexToLetter(avgColIdx)}2")
                colWidths[avgColIdx] = 12.0

                // Vertical merges for Student ID & Name headers
                merges.add("A1:A2")
                merges.add("B1:B2")

                rows.add(row1)
                rows.add(row2)

                // صفوف الطلاب
                students.forEachIndexed { sIdx, student ->
                    val sRow = mutableListOf<XlsxCell>()
                    sRow.add(XlsxCell(student.id.toString(), styleIndex = 3, isNumber = true))
                    sRow.add(XlsxCell(student.name, styleIndex = 3))

                    var totalAllSubjects = 0.0
                    var hasAnyGrade = false

                    targetSubjects.forEach { sub ->
                        val existing = existingGrades.find {
                            it.studentId == student.id &&
                                    (it.subjectName.trim().equals(sub.trim(), ignoreCase = true) || (targetSubjects.size == 1 && it.subjectName.isBlank()))
                        }

                        if (existing != null) {
                            val att = existing.attendanceScore
                            val part = existing.participationScore
                            val ass = existing.assignmentsScore
                            val proj = existing.projectsScore
                            val theo = existing.theoreticalExamScore
                            val pract = existing.practicalExamScore
                            val subjTotal = if (existing.isManualFinalGrading()) existing.getTotalScore() else existing.getDiplomaTotal()

                            sRow.add(XlsxCell(if (att > 0) formatScore(att) else "", styleIndex = 3, isNumber = (att > 0)))
                            sRow.add(XlsxCell(if (part > 0) formatScore(part) else "", styleIndex = 3, isNumber = (part > 0)))
                            sRow.add(XlsxCell(if (ass > 0) formatScore(ass) else "", styleIndex = 3, isNumber = (ass > 0)))
                            sRow.add(XlsxCell(if (proj > 0) formatScore(proj) else "", styleIndex = 3, isNumber = (proj > 0)))
                            sRow.add(XlsxCell(if (theo > 0) formatScore(theo) else "", styleIndex = 3, isNumber = (theo > 0)))
                            sRow.add(XlsxCell(if (pract > 0) formatScore(pract) else "", styleIndex = 3, isNumber = (pract > 0)))
                            sRow.add(XlsxCell(if (subjTotal > 0) formatScore(subjTotal) else "", styleIndex = 2, isNumber = (subjTotal > 0)))
                            // Separator
                            sRow.add(XlsxCell("", styleIndex = 4))

                            if (subjTotal > 0) {
                                totalAllSubjects += subjTotal
                                hasAnyGrade = true
                            }
                        } else {
                            for (k in 0..6) {
                                sRow.add(XlsxCell("", styleIndex = 3))
                            }
                            sRow.add(XlsxCell("", styleIndex = 4)) // فاصل
                        }
                    }

                    if (hasAnyGrade) {
                        sRow.add(XlsxCell(formatScore(totalAllSubjects), styleIndex = 2, isNumber = true))
                        val avg = if (targetSubjects.isNotEmpty()) totalAllSubjects / targetSubjects.size else 0.0
                        sRow.add(XlsxCell(formatScore(avg), styleIndex = 5, isNumber = true))
                    } else {
                        sRow.add(XlsxCell("", styleIndex = 2))
                        sRow.add(XlsxCell("", styleIndex = 5))
                    }

                    rows.add(sRow)
                }
            } else {
                // ====== 2. نموذج الرصد النهائي المباشر ======
                // الصف الأول: رقم الطالب | اسم الطالب | المادة 1 | المادة 2 ... | المجموع | المعدل
                val headerRow = mutableListOf<XlsxCell>()
                headerRow.add(XlsxCell("رقم الطالب", styleIndex = 2))
                headerRow.add(XlsxCell("اسم الطالب", styleIndex = 2))

                var cIdx = 2
                targetSubjects.forEach { sub ->
                    headerRow.add(XlsxCell(sub, styleIndex = 2))
                    colWidths[cIdx] = 18.0
                    cIdx++
                }

                headerRow.add(XlsxCell("المجموع", styleIndex = 2))
                colWidths[cIdx] = 14.0
                cIdx++

                headerRow.add(XlsxCell("المعدل", styleIndex = 5)) // تظليل مميز للمعدل
                colWidths[cIdx] = 12.0

                rows.add(headerRow)

                // صفوف الطلاب للرصد النهائي
                students.forEach { student ->
                    val sRow = mutableListOf<XlsxCell>()
                    sRow.add(XlsxCell(student.id.toString(), styleIndex = 3, isNumber = true))
                    sRow.add(XlsxCell(student.name, styleIndex = 3))

                    var totalAllSubjects = 0.0
                    var hasAnyGrade = false

                    targetSubjects.forEach { sub ->
                        val existing = existingGrades.find {
                            it.studentId == student.id &&
                                    (it.subjectName.trim().equals(sub.trim(), ignoreCase = true) || (targetSubjects.size == 1 && it.subjectName.isBlank()))
                        }
                        if (existing != null && existing.getTotalScore() > 0.0) {
                            val sc = existing.getTotalScore()
                            sRow.add(XlsxCell(formatScore(sc), styleIndex = 3, isNumber = true))
                            totalAllSubjects += sc
                            hasAnyGrade = true
                        } else {
                            sRow.add(XlsxCell("", styleIndex = 3))
                        }
                    }

                    if (hasAnyGrade) {
                        sRow.add(XlsxCell(formatScore(totalAllSubjects), styleIndex = 2, isNumber = true))
                        val avg = if (targetSubjects.isNotEmpty()) totalAllSubjects / targetSubjects.size else 0.0
                        sRow.add(XlsxCell(formatScore(avg), styleIndex = 5, isNumber = true))
                    } else {
                        sRow.add(XlsxCell("", styleIndex = 2))
                        sRow.add(XlsxCell("", styleIndex = 5))
                    }

                    rows.add(sRow)
                }
            }

            // كتابة وحفظ ملف Excel
            writeXlsx(
                outputFile = file,
                sheetName = course.name.take(30),
                rows = rows,
                colWidths = colWidths,
                merges = merges,
                courseId = course.id.toLong(),
                courseName = course.name
            )

            // نسخ اختياري إلى مجلد المدرب الأساسي إذا كان مفعلاً
            if (trainerBaseDirUri.isNotBlank()) {
                copyFileToTrainerBaseDir(context, file, trainerBaseDirUri)
            }

            return file
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    // --- مشاركة وفتح ملف إكسل ---
    fun shareTemplateFile(context: Context, file: File, courseName: String, subjectName: String) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = XLSX_MIME_TYPE
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "كشف رصد درجات - $courseName - $subjectName")
                putExtra(Intent.EXTRA_TEXT, "مرفق كشف رصد درجات معتمد بصيغة Microsoft Excel (.xlsx) لدورة: $courseName")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة وفتح كشف إكسل المعتمد 📤"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun copyFileToTrainerBaseDir(context: Context, sourceFile: File, trainerBaseDirUri: String) {
        if (trainerBaseDirUri.isBlank()) return
        try {
            val baseUri = Uri.parse(trainerBaseDirUri)
            val baseDoc = DocumentFile.fromTreeUri(context, baseUri) ?: return
            var reportsDir = baseDoc.findFile("Reports")
            if (reportsDir == null || !reportsDir.isDirectory) {
                reportsDir = baseDoc.createDirectory("Reports") ?: baseDoc
            }
            val targetFile = reportsDir.createFile(XLSX_MIME_TYPE, sourceFile.name) ?: return
            context.contentResolver.openOutputStream(targetFile.uri)?.use { os ->
                sourceFile.inputStream().use { it.copyTo(os) }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    data class ParsedXlsxData(
        val rows: List<List<String>>,
        val detectedCourseId: Long? = null,
        val detectedCourseName: String? = null
    )

    // --- قراءة ملفات Excel (.xlsx) الأصلية وتحويلها إلى مصفوفة نصوص مع بيانات الدورة الوصفية ---
    fun parseXlsxFromStream(inputStream: InputStream): ParsedXlsxData {
        val zip = ZipInputStream(BufferedInputStream(inputStream))
        var entry = zip.nextEntry
        val sharedStrings = mutableListOf<String>()
        val allEntries = mutableMapOf<String, ByteArray>()

        while (entry != null) {
            val name = entry.name
            if (name == "xl/sharedStrings.xml" || name.startsWith("xl/worksheets/sheet") || name == "docProps/core.xml") {
                allEntries[name] = zip.readBytes()
            }
            zip.closeEntry()
            entry = zip.nextEntry
        }

        var detectedCourseId: Long? = null
        var detectedCourseName: String? = null
        val coreBytes = allEntries["docProps/core.xml"]
        if (coreBytes != null) {
            val coreStr = String(coreBytes, Charsets.UTF_8)
            val matchId = Regex("""COURSE_ID:(\d+)""").find(coreStr)
            if (matchId != null) {
                detectedCourseId = matchId.groupValues[1].toLongOrNull()
            }
            val matchTitle = Regex("""<dc:title>(.*?)</dc:title>""").find(coreStr)
            if (matchTitle != null && matchTitle.groupValues[1].isNotBlank()) {
                detectedCourseName = matchTitle.groupValues[1].trim()
            }
        }

        // 1. قراءة جدول النصوص المشتركة sharedStrings
        val ssBytes = allEntries["xl/sharedStrings.xml"]
        if (ssBytes != null) {
            val parser = Xml.newPullParser()
            parser.setInput(ByteArrayInputStream(ssBytes), "UTF-8")
            var eventType = parser.eventType
            var inText = false
            var currentStr = StringBuilder()
            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        if (parser.name == "t") {
                            inText = true
                        } else if (parser.name == "si") {
                            currentStr = StringBuilder()
                        }
                    }
                    XmlPullParser.TEXT -> {
                        if (inText) {
                            currentStr.append(parser.text)
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if (parser.name == "t") {
                            inText = false
                        } else if (parser.name == "si") {
                            sharedStrings.add(currentStr.toString())
                        }
                    }
                }
                eventType = parser.next()
            }
        }

        // 2. قراءة أول ورقة عمل sheet1.xml
        val sheetKey = allEntries.keys.firstOrNull { it.startsWith("xl/worksheets/sheet") } ?: return ParsedXlsxData(emptyList(), detectedCourseId, detectedCourseName)
        val sheetBytes = allEntries[sheetKey] ?: return ParsedXlsxData(emptyList(), detectedCourseId, detectedCourseName)
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(sheetBytes), "UTF-8")

        val rows = mutableListOf<MutableList<String>>()
        var currentRow = mutableMapOf<Int, String>()
        var currentColIndex = 0
        var cellType = ""
        var inValue = false
        var inInlineText = false
        var cellValue = StringBuilder()

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "row" -> {
                            currentRow = mutableMapOf()
                        }
                        "c" -> {
                            cellValue = StringBuilder()
                            val cellRef = parser.getAttributeValue(null, "r") ?: ""
                            cellType = parser.getAttributeValue(null, "t") ?: ""
                            currentColIndex = colRefToIndex(cellRef)
                        }
                        "v" -> inValue = true
                        "t" -> inInlineText = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inValue || inInlineText) {
                        cellValue.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "v" -> inValue = false
                        "t" -> inInlineText = false
                        "c" -> {
                            val text = when (cellType) {
                                "s" -> {
                                    val sIndex = cellValue.toString().trim().toIntOrNull() ?: -1
                                    if (sIndex in sharedStrings.indices) sharedStrings[sIndex] else ""
                                }
                                else -> cellValue.toString().trim()
                            }
                            currentRow[currentColIndex] = text
                        }
                        "row" -> {
                            if (currentRow.isNotEmpty()) {
                                val maxCol = (currentRow.keys.maxOrNull() ?: -1)
                                val rowList = MutableList(maxCol + 1) { "" }
                                for ((c, v) in currentRow) {
                                    if (c in rowList.indices) rowList[c] = v
                                }
                                rows.add(rowList)
                            }
                        }
                    }
                }
            }
            eventType = parser.next()
        }
        return ParsedXlsxData(rows, detectedCourseId, detectedCourseName)
    }

    // --- قراءة واستيراد ملفات الدرجات الذكي (يدعم Excel .xlsx وكذلك .csv تلقائياً) ---
    fun parseGradesFile(
        context: Context,
        fileUri: Uri,
        courseId: Int,
        defaultSubjectName: String,
        courseStudents: List<Student>,
        config: StudentGradeConfig?,
        courseSubjects: List<String> = emptyList()
    ): GradeImportResult {
        try {
            val rawRows = mutableListOf<List<String>>()
            var detectedCourseId: Long? = null
            var detectedCourseName: String? = null

            // فحص نوع الملف (إكسل مضغوط PK أم نص عادي)
            val isZipExcel = try {
                context.contentResolver.openInputStream(fileUri)?.use { stream ->
                    val head = ByteArray(4)
                    val read = stream.read(head)
                    read == 4 && head[0] == 0x50.toByte() && head[1] == 0x4B.toByte() && head[2] == 0x03.toByte() && head[3] == 0x04.toByte()
                } ?: false
            } catch (_: Exception) {
                false
            }

            if (isZipExcel) {
                context.contentResolver.openInputStream(fileUri)?.use { stream ->
                    val parsedData = parseXlsxFromStream(stream)
                    rawRows.addAll(parsedData.rows)
                    detectedCourseId = parsedData.detectedCourseId
                    detectedCourseName = parsedData.detectedCourseName
                }
            } else {
                // CSV fallback
                context.contentResolver.openInputStream(fileUri)?.use { inputStream ->
                    BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                        var line = reader.readLine()
                        while (line != null) {
                            val trimmed = line.trim()
                            if (trimmed.startsWith("#")) {
                                val matchId = Regex("""COURSE_ID:(\d+)""").find(trimmed)
                                if (matchId != null) detectedCourseId = matchId.groupValues[1].toLongOrNull()
                                val matchName = Regex("""COURSE_NAME:([^|]+)""").find(trimmed)
                                if (matchName != null) detectedCourseName = matchName.groupValues[1].trim()
                            } else if (trimmed.isNotBlank()) {
                                val delimiter = if (trimmed.contains("\t")) "\t" else if (trimmed.contains(";")) ";" else ","
                                val cells = parseCsvLine(trimmed, delimiter).map { it.trim().replace("\"", "") }
                                rawRows.add(cells)
                            }
                            line = reader.readLine()
                        }
                    }
                }
            }

            if (rawRows.isEmpty()) {
                return GradeImportResult(false, 0, 0, 0, emptyList(), GradeTemplateType.DETAILED_ITEMS, "الملف فارغ أو لم يتم التعرف على محتواه")
            }

            val studentMapById = courseStudents.associateBy { it.id }
            val studentGroupByName = courseStudents.groupBy { normalizeArabic(it.name) }
            val isDiploma = config?.isDiploma ?: true

            // دالة المطابقة الصارمة لمنع أي خلط بين الأسماء أو الدورات
            fun resolveStudent(rawId: Int, rawName: String): Pair<Student?, String?> {
                // 1. الأولوية الأولى: المطابقة برقم الطالب التعريفي ID الخاص بالدورة الحالية
                if (rawId > 0 && studentMapById.containsKey(rawId)) {
                    return Pair(studentMapById[rawId], null)
                }
                // 2. الأولوية الثانية: المطابقة بالاسم الكامل المطابق تماماً (بدون بحث جزئي منعاً للخلط بين المتشابهين)
                if (rawName.isNotBlank()) {
                    val norm = normalizeArabic(rawName)
                    val matches = studentGroupByName[norm] ?: emptyList()
                    return when {
                        matches.size == 1 -> Pair(matches.first(), null)
                        matches.size > 1 -> Pair(null, "⚠️ يوجد أكثر من طالب باسم ($rawName) في هذه الدورة. يلزم توفير رقم الطالب ID للمطابقة الدقيقة.")
                        else -> Pair(null, "❌ غير مسجل في هذه الدورة")
                    }
                }
                return Pair(null, "❌ بيانات الطالب غير محددة")
            }

            // فحص هل هو نموذج تفصيلي مطابق للصورة (الصف 2 يحتوي على حضور ومشاركة وواجبات وعملي)
            val isDetailedMatrix = rawRows.size >= 2 && rawRows.take(3).any { r ->
                r.any { c ->
                    val norm = normalizeArabic(c)
                    norm.contains("حضور") && (norm.contains("مشاركه") || r.any { normalizeArabic(it).contains("مشاركه") })
                }
            }

            if (isDetailedMatrix) {
                // ====== معالجة النموذج التفصيلي ======
                val row0 = rawRows[0]
                val subHeaderRowIndex = if (rawRows[1].any { normalizeArabic(it).contains("حضور") }) 1 else 0
                val rowSub = rawRows[subHeaderRowIndex]

                // التعرف على أعمدة رقم الطالب واسم الطالب
                var idCol = -1
                var nameCol = -1
                rowSub.forEachIndexed { idx, cell ->
                    val n = normalizeArabic(cell)
                    if (n.contains("رقم") && n.contains("طالب")) idCol = idx
                    if (n.contains("اسم") && n.contains("طالب")) nameCol = idx
                }
                if (idCol == -1) idCol = 0
                if (nameCol == -1) nameCol = 1

                // ربط المواد بالأعمدة التفصيلية
                class SubRange(val name: String, var attCol: Int = -1, var partCol: Int = -1, var assignCol: Int = -1, var projCol: Int = -1, var theoCol: Int = -1, var practCol: Int = -1, var totalCol: Int = -1)
                val subRanges = mutableListOf<SubRange>()
                var currentActiveSubName = ""

                for (c in 2 until rowSub.size) {
                    if (c < row0.size && row0[c].isNotBlank()) {
                        val headerNorm = normalizeArabic(row0[c])
                        val isSummary = headerNorm.contains("مجموع") || headerNorm.contains("معدل") || headerNorm.contains("تقدير") || headerNorm.contains("ملاحظ") || headerNorm.contains("نتيجه") || headerNorm.contains("نسبه")
                        if (!isSummary) {
                            currentActiveSubName = row0[c].trim()
                            subRanges.add(SubRange(currentActiveSubName))
                        }
                    }
                    val curSub = subRanges.lastOrNull()
                    if (curSub != null) {
                        val colTitle = normalizeArabic(rowSub.getOrNull(c) ?: "")
                        when {
                            colTitle.contains("حضور") -> curSub.attCol = c
                            colTitle.contains("مشاركه") || colTitle.contains("تفاعل") -> curSub.partCol = c
                            colTitle.contains("واجب") || colTitle.contains("تكاليف") -> curSub.assignCol = c
                            colTitle.contains("مشروع") || colTitle.contains("مشاريع") -> curSub.projCol = c
                            colTitle.contains("نظري") -> curSub.theoCol = c
                            colTitle.contains("عملي") -> curSub.practCol = c
                            colTitle.contains("مجموع") -> curSub.totalCol = c
                        }
                    }
                }

                val noteColIdx = rowSub.indexOfFirst { normalizeArabic(it).contains("ملاحظ") }.let {
                    if (it != -1) it else row0.indexOfFirst { c -> normalizeArabic(c).contains("ملاحظ") }
                }

                val parsedRows = mutableListOf<ParsedGradeRow>()
                val startDataRow = subHeaderRowIndex + 1

                for (rIdx in startDataRow until rawRows.size) {
                    val cells = rawRows[rIdx]
                    if (cells.all { it.isBlank() }) continue

                    val rawId = cells.getOrNull(idCol)?.filter { it.isDigit() }?.toIntOrNull() ?: 0
                    val rawName = cells.getOrNull(nameCol) ?: ""
                    val rawNote = if (noteColIdx != -1) cells.getOrNull(noteColIdx) ?: "" else ""

                    val (matchedStudent, warnMsg) = resolveStudent(rawId, rawName)
                    val finalStudentId = matchedStudent?.id ?: rawId
                    val finalStudentName = matchedStudent?.name ?: rawName.ifBlank { "طالب صف $rIdx" }

                    subRanges.forEach { sr ->
                        val subjectNote = extractSubjectNote(rawNote, sr.name)
                        val rowItem = ParsedGradeRow(
                            originalRowIndex = rIdx,
                            studentId = finalStudentId,
                            studentName = finalStudentName,
                            subjectName = sr.name,
                            isDiploma = isDiploma,
                            isDirectFinal = false,
                            note = subjectNote,
                            isMatchedStudent = (matchedStudent != null),
                            matchedStudent = matchedStudent,
                            warningMessage = warnMsg
                        )
                        rowItem.attendanceScore = parseDoubleOrZero(cells.getOrNull(sr.attCol) ?: "").coerceIn(0.0, 5.0)
                        rowItem.participationScore = parseDoubleOrZero(cells.getOrNull(sr.partCol) ?: "").coerceIn(0.0, 5.0)
                        rowItem.assignmentsScore = parseDoubleOrZero(cells.getOrNull(sr.assignCol) ?: "").coerceIn(0.0, 10.0)
                        rowItem.projectsScore = parseDoubleOrZero(cells.getOrNull(sr.projCol) ?: "").coerceIn(0.0, 20.0)
                        rowItem.theoreticalExamScore = parseDoubleOrZero(cells.getOrNull(sr.theoCol) ?: "").coerceIn(0.0, 20.0)
                        rowItem.practicalExamScore = parseDoubleOrZero(cells.getOrNull(sr.practCol) ?: "").coerceIn(0.0, 40.0)

                        parsedRows.add(rowItem)
                    }
                }

                val matchedCount = parsedRows.count { it.isMatchedStudent }
                val uniqueStudentsInFile = parsedRows.map { it.originalRowIndex }.distinct().size
                val uniqueMatchedCount = parsedRows.filter { it.isMatchedStudent }.map { it.studentId }.distinct().size

                val isCourseMismatch = when {
                    detectedCourseId != null && detectedCourseId != courseId.toLong() -> true
                    uniqueStudentsInFile > 0 && uniqueMatchedCount == 0 -> true
                    else -> false
                }

                val mismatchErrorMsg = when {
                    detectedCourseId != null && detectedCourseId != courseId.toLong() -> {
                        "🚫 تم رفض الاستيراد: هذا الملف مخصص لدورة أخرى (${detectedCourseName ?: "رقم $detectedCourseId"})، ولا يُسمح باستيراده إلى هذه الدورة نهائياً حفاظاً على سلامة البيانات."
                    }
                    uniqueStudentsInFile > 0 && uniqueMatchedCount == 0 -> {
                        "🚫 تم رفض الاستيراد: لا يوجد أي طالب في الملف ينتمي لطلاب هذه الدورة! يُمنع استيراد ملفات الدورات الأخرى نهائياً."
                    }
                    else -> null
                }

                return GradeImportResult(
                    isSuccess = !isCourseMismatch,
                    totalRows = parsedRows.size,
                    matchedCount = matchedCount,
                    unmatchedCount = parsedRows.size - matchedCount,
                    parsedRows = parsedRows,
                    detectedType = GradeTemplateType.DETAILED_ITEMS,
                    errorOrWarningMessage = mismatchErrorMsg,
                    isCourseMismatch = isCourseMismatch,
                    detectedCourseId = detectedCourseId,
                    detectedCourseName = detectedCourseName
                )
            } else {
                // ====== معالجة نموذج الرصد النهائي المباشر ======
                val headerRow = rawRows[0]
                var idCol = -1
                var nameCol = -1
                var noteCol = -1
                val subjectCols = mutableMapOf<String, Int>()

                headerRow.forEachIndexed { idx, cell ->
                    val n = normalizeArabic(cell)
                    when {
                        n.contains("رقم") && n.contains("طالب") -> idCol = idx
                        n.contains("اسم") && n.contains("طالب") -> nameCol = idx
                        n.contains("ملاحظ") -> noteCol = idx
                        !n.contains("مجموع") && !n.contains("معدل") && !n.contains("تقدير") && !n.contains("نتيجه") && !n.contains("نسبه") -> {
                            val cleanName = cell.removePrefix("درجة:").replace("(100)", "").trim()
                            if (cleanName.isNotBlank() && idx != idCol && idx != nameCol) {
                                subjectCols[cleanName] = idx
                            }
                        }
                    }
                }
                if (idCol == -1) idCol = 0
                if (nameCol == -1) nameCol = 1

                val parsedRows = mutableListOf<ParsedGradeRow>()
                for (rIdx in 1 until rawRows.size) {
                    val cells = rawRows[rIdx]
                    if (cells.all { it.isBlank() }) continue

                    val rawId = cells.getOrNull(idCol)?.filter { it.isDigit() }?.toIntOrNull() ?: 0
                    val rawName = cells.getOrNull(nameCol) ?: ""
                    val rawNote = if (noteCol != -1) cells.getOrNull(noteCol) ?: "" else ""

                    val (matchedStudent, warnMsg) = resolveStudent(rawId, rawName)
                    val finalStudentId = matchedStudent?.id ?: rawId
                    val finalStudentName = matchedStudent?.name ?: rawName.ifBlank { "طالب صف $rIdx" }

                    if (subjectCols.isNotEmpty()) {
                        subjectCols.forEach { (subName, cIdx) ->
                            val score = parseDoubleOrZero(cells.getOrNull(cIdx) ?: "").coerceIn(0.0, 100.0)
                            val subjectNote = extractSubjectNote(rawNote, subName)
                            val rowItem = ParsedGradeRow(
                                originalRowIndex = rIdx,
                                studentId = finalStudentId,
                                studentName = finalStudentName,
                                subjectName = subName,
                                isDiploma = isDiploma,
                                isDirectFinal = true,
                                finalScore = score,
                                note = subjectNote,
                                isMatchedStudent = (matchedStudent != null),
                                matchedStudent = matchedStudent,
                                warningMessage = warnMsg
                            )
                            parsedRows.add(rowItem)
                        }
                    } else {
                        // في حال مادة واحدة
                        val score = parseDoubleOrZero(cells.getOrNull(2) ?: "").coerceIn(0.0, 100.0)
                        val rowItem = ParsedGradeRow(
                            originalRowIndex = rIdx,
                            studentId = finalStudentId,
                            studentName = finalStudentName,
                            subjectName = defaultSubjectName,
                            isDiploma = isDiploma,
                            isDirectFinal = true,
                            finalScore = score,
                            note = rawNote.trim(),
                            isMatchedStudent = (matchedStudent != null),
                            matchedStudent = matchedStudent,
                            warningMessage = warnMsg
                        )
                        parsedRows.add(rowItem)
                    }
                }

                val matchedCount = parsedRows.count { it.isMatchedStudent }
                val uniqueStudentsInFile = parsedRows.map { it.originalRowIndex }.distinct().size
                val uniqueMatchedCount = parsedRows.filter { it.isMatchedStudent }.map { it.studentId }.distinct().size

                val isCourseMismatch = when {
                    detectedCourseId != null && detectedCourseId != courseId.toLong() -> true
                    uniqueStudentsInFile > 0 && uniqueMatchedCount == 0 -> true
                    else -> false
                }

                val mismatchErrorMsg = when {
                    detectedCourseId != null && detectedCourseId != courseId.toLong() -> {
                        "🚫 تم رفض الاستيراد: هذا الملف مخصص لدورة أخرى (${detectedCourseName ?: "رقم $detectedCourseId"})، ولا يُسمح باستيراده إلى هذه الدورة نهائياً حفاظاً على سلامة البيانات."
                    }
                    uniqueStudentsInFile > 0 && uniqueMatchedCount == 0 -> {
                        "🚫 تم رفض الاستيراد: لا يوجد أي طالب في الملف ينتمي لطلاب هذه الدورة! يُمنع استيراد ملفات الدورات الأخرى نهائياً."
                    }
                    else -> null
                }

                return GradeImportResult(
                    isSuccess = !isCourseMismatch,
                    totalRows = parsedRows.size,
                    matchedCount = matchedCount,
                    unmatchedCount = parsedRows.size - matchedCount,
                    parsedRows = parsedRows,
                    detectedType = GradeTemplateType.DIRECT_FINAL,
                    errorOrWarningMessage = mismatchErrorMsg,
                    isCourseMismatch = isCourseMismatch,
                    detectedCourseId = detectedCourseId,
                    detectedCourseName = detectedCourseName
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return GradeImportResult(false, 0, 0, 0, emptyList(), GradeTemplateType.DETAILED_ITEMS, "حدث خطأ أثناء معالجة ملف الإكسل: ${e.localizedMessage}")
        }
    }

    // --- تحويل الصفوف المقروءة إلى كيانات StudentGrade للحفظ في قاعدة البيانات ---
    fun convertParsedRowsToStudentGrades(
        parsedRows: List<ParsedGradeRow>,
        course: Course,
        defaultSubject: String,
        existingGrades: List<StudentGrade> = emptyList()
    ): List<StudentGrade> {
        return parsedRows.filter { it.isMatchedStudent && it.studentId > 0 }.map { row ->
            val subj = row.subjectName.ifBlank { defaultSubject }
            val existing = existingGrades.find {
                it.studentId == row.studentId &&
                        (it.subjectName.trim().equals(subj.trim(), ignoreCase = true) || (existingGrades.none { eg -> eg.subjectName.trim().equals(subj.trim(), ignoreCase = true) } && it.subjectName.isBlank()))
            }
            val existingId = existing?.id ?: 0
            val existingNote = existing?.getGradeNote() ?: ""
            val noteToKeep = if (row.note.isNotBlank()) row.note else existingNote

            if (row.isDirectFinal) {
                StudentGrade.createManualFinalGrade(
                    id = existingId,
                    studentId = row.studentId,
                    studentName = row.studentName,
                    courseId = course.id,
                    courseName = course.name,
                    isDiploma = row.isDiploma,
                    subjectName = subj,
                    finalScore = row.finalScore
                ).let {
                    if (noteToKeep.isNotBlank()) {
                        it.copy(customScoresJson = StudentGrade.withNote(it.customScoresJson, noteToKeep))
                    } else it
                }
            } else {
                if (row.isDiploma) {
                    var g = StudentGrade(
                        id = existingId,
                        studentId = row.studentId,
                        studentName = row.studentName,
                        courseId = course.id,
                        courseName = course.name,
                        isDiploma = true,
                        subjectName = subj,
                        attendanceScore = row.attendanceScore,
                        participationScore = row.participationScore,
                        assignmentsScore = row.assignmentsScore,
                        projectsScore = row.projectsScore,
                        theoreticalExamScore = row.theoreticalExamScore,
                        practicalExamScore = row.practicalExamScore,
                        customScoresJson = "__manual__:true"
                    )
                    if (noteToKeep.isNotBlank()) {
                        g = g.copy(customScoresJson = StudentGrade.withNote(g.customScoresJson, noteToKeep))
                    }
                    g
                } else {
                    val scoresStr = StudentGrade.serializeScores(row.customScoresMap)
                    val baseJson = if (scoresStr.isNotBlank()) "$scoresStr|__manual__:true" else "__manual__:true"
                    val finalJson = if (noteToKeep.isNotBlank()) StudentGrade.withNote(baseJson, noteToKeep) else baseJson
                    StudentGrade(
                        id = existingId,
                        studentId = row.studentId,
                        studentName = row.studentName,
                        courseId = course.id,
                        courseName = course.name,
                        isDiploma = false,
                        subjectName = subj,
                        customScoresJson = finalJson
                    )
                }
            }
        }
    }

    private fun parseCsvLine(line: String, delimiter: String): List<String> {
        val result = mutableListOf<String>()
        val sb = java.lang.StringBuilder()
        var inQuotes = false

        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '\"') {
                if (inQuotes && i + 1 < line.length && line[i + 1] == '\"') {
                    sb.append('\"')
                    i++
                } else {
                    inQuotes = !inQuotes
                }
            } else if (!inQuotes && line.startsWith(delimiter, i)) {
                result.add(sb.toString())
                sb.setLength(0)
                i += delimiter.length - 1
            } else {
                sb.append(c)
            }
            i++
        }
        result.add(sb.toString())
        return result
    }

    private fun parseDoubleOrZero(value: String): Double {
        val clean = value.trim().filter { it.isDigit() || it == '.' }
        return clean.toDoubleOrNull() ?: 0.0
    }

    private fun formatScore(score: Double): String {
        return if (score % 1.0 == 0.0) score.toInt().toString() else String.format(Locale.US, "%.1f", score)
    }

    private fun getEstimate(total: Double): String {
        return when {
            total >= 90.0 -> "ممتاز"
            total >= 80.0 -> "جيد جداً"
            total >= 70.0 -> "جيد"
            total >= 60.0 -> "مقبول"
            else -> "راسب"
        }
    }

    fun extractSubjectNote(rawNote: String, subName: String): String {
        if (rawNote.isBlank()) return ""
        val parts = rawNote.split("|")
        val normSub = normalizeArabic(subName)
        for (part in parts) {
            val trimmed = part.trim()
            if (trimmed.contains(":")) {
                val prefix = normalizeArabic(trimmed.substringBefore(":"))
                if (prefix.contains(normSub) || normSub.contains(prefix)) {
                    return trimmed.substringAfter(":").trim()
                }
            }
        }
        if (!rawNote.contains(":") && !rawNote.contains("|")) {
            return rawNote.trim()
        }
        return ""
    }

    fun normalizeArabic(text: String): String {
        if (text.isBlank()) return ""
        return text.trim()
            .replace("[\\u064B-\\u065F\\u0670]".toRegex(), "")
            .replace("أ", "ا")
            .replace("إ", "ا")
            .replace("آ", "ا")
            .replace("ى", "ي")
            .replace("ة", "ه")
            .replace("[\u200B-\u200D\uFEFF]".toRegex(), "")
            .lowercase(Locale.ROOT)
    }
}
