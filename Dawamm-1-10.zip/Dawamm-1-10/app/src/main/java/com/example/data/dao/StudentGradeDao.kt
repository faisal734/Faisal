package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Delete
import com.example.data.entity.StudentGrade
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentGradeDao {
    @Query("SELECT * FROM student_grades ORDER BY studentName ASC")
    fun getAllGrades(): Flow<List<StudentGrade>>

    @Query("SELECT * FROM student_grades WHERE courseId = :courseId ORDER BY studentName ASC")
    fun getGradesByCourse(courseId: Int): Flow<List<StudentGrade>>

    @Query("SELECT * FROM student_grades WHERE studentId = :studentId")
    fun getGradesByStudent(studentId: Int): Flow<List<StudentGrade>>

    @Query("SELECT * FROM student_grades WHERE studentId = :studentId AND subjectName = :subjectName LIMIT 1")
    suspend fun getGradeByStudentAndSubjectSync(studentId: Int, subjectName: String): StudentGrade?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrade(grade: StudentGrade): Long

    @Delete
    suspend fun deleteGrade(grade: StudentGrade)

    @Query("DELETE FROM student_grades WHERE courseId = :courseId")
    suspend fun deleteGradesByCourseId(courseId: Int)

    @Query("DELETE FROM student_grades WHERE studentId = :studentId")
    suspend fun deleteGradesByStudentId(studentId: Int)

    @Query("UPDATE student_grades SET studentName = :newName WHERE studentId = :studentId")
    suspend fun updateStudentGradeName(studentId: Int, newName: String)

    @Query("UPDATE student_grades SET courseName = :newName WHERE courseId = :courseId")
    suspend fun updateCourseName(courseId: Int, newName: String)

    @Query("UPDATE student_grades SET subjectName = :newName WHERE subjectName = :oldName")
    suspend fun updateSubjectName(oldName: String, newName: String)

    @Query("UPDATE student_grades SET courseId = :newCourseId, courseName = :newCourseName WHERE studentId = :studentId")
    suspend fun transferStudentGrades(studentId: Int, newCourseId: Int, newCourseName: String)

    @Query("DELETE FROM student_grades")
    suspend fun deleteAllGrades()
}
