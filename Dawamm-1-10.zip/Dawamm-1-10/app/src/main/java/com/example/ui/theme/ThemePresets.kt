package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

data class ThemePreset(
    val id: Int,
    val name: String,
    val isDark: Boolean,
    val category: String, // "داكن 🌙" أو "فاتح ☀️"
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val primary: Color,
    val onPrimary: Color,
    val secondary: Color,
    val onSecondary: Color = Color.White,
    val tertiary: Color = secondary,
    val outline: Color,
    val onBackground: Color,
    val onSurface: Color,
    val onSurfaceVariant: Color,
    val accentBadge: Color = primary,
    val previewGradient: List<Color> = listOf(primary, secondary)
) {
    fun toColorScheme(): ColorScheme {
        return if (isDark) {
            darkColorScheme(
                primary = primary,
                onPrimary = onPrimary,
                primaryContainer = surfaceVariant,
                onPrimaryContainer = onSurface,
                secondary = secondary,
                onSecondary = onSecondary,
                secondaryContainer = surfaceVariant,
                onSecondaryContainer = onSurface,
                tertiary = tertiary,
                onTertiary = onSecondary,
                tertiaryContainer = surfaceVariant,
                onTertiaryContainer = onSurface,
                background = background,
                onBackground = onBackground,
                surface = surface,
                onSurface = onSurface,
                surfaceVariant = surfaceVariant,
                onSurfaceVariant = onSurfaceVariant,
                outline = outline,
                outlineVariant = outline.copy(alpha = 0.5f),
                error = Color(0xFFF87171),
                onError = Color(0xFF450A0A),
                errorContainer = Color(0xFF7F1D1D),
                onErrorContainer = Color(0xFFFEE2E2)
            )
        } else {
            lightColorScheme(
                primary = primary,
                onPrimary = onPrimary,
                primaryContainer = surfaceVariant,
                onPrimaryContainer = onSurface,
                secondary = secondary,
                onSecondary = onSecondary,
                secondaryContainer = surfaceVariant,
                onSecondaryContainer = onSurface,
                tertiary = tertiary,
                onTertiary = onSecondary,
                tertiaryContainer = surfaceVariant,
                onTertiaryContainer = onSurface,
                background = background,
                onBackground = onBackground,
                surface = surface,
                onSurface = onSurface,
                surfaceVariant = surfaceVariant,
                onSurfaceVariant = onSurfaceVariant,
                outline = outline,
                outlineVariant = outline.copy(alpha = 0.5f),
                error = Color(0xFFDC2626),
                onError = Color.White,
                errorContainer = Color(0xFFFEE2E2),
                onErrorContainer = Color(0xFF7F1D1D)
            )
        }
    }
}

object ThemePresetsCatalog {
    val presets: List<ThemePreset> = listOf(
        ThemePreset(
            id = 1,
            name = "☀️ الفاتح الهادئ",
            isDark = false,
            category = "فاتح ☀️",
            background = Color(0xFFF8FAF2),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFE2E8F0),
            primary = Color(0xFF1E293B),
            onPrimary = Color.White,
            secondary = Color(0xFF64748B),
            outline = Color(0xFFCBD5E1),
            onBackground = Color(0xFF0F172A),
            onSurface = Color(0xFF0F172A),
            onSurfaceVariant = Color(0xFF475569)
        ),
        ThemePreset(
            id = 2,
            name = "🌙 الداكن",
            isDark = true,
            category = "داكن 🌙",
            background = Color(0xFF090D16),
            surface = Color(0xFF111827),
            surfaceVariant = Color(0xFF1F2937),
            primary = Color(0xFF3B82F6),
            onPrimary = Color.White,
            secondary = Color(0xFF60A5FA),
            outline = Color(0xFF374151),
            onBackground = Color(0xFFF3F4F6),
            onSurface = Color(0xFFF9FAFB),
            onSurfaceVariant = Color(0xFF9CA3AF)
        ),
        ThemePreset(
            id = 3,
            name = "✨ التدرجات الحديثة",
            isDark = true,
            category = "داكن 🌙",
            background = Color(0xFF0F172A),
            surface = Color(0xFF1E293B),
            surfaceVariant = Color(0xFF334155),
            primary = Color(0xFFEC4899),
            onPrimary = Color.White,
            secondary = Color(0xFF8B5CF6),
            outline = Color(0xFF475569),
            onBackground = Color(0xFFF8FAFC),
            onSurface = Color(0xFFF8FAFC),
            onSurfaceVariant = Color(0xFFCBD5E1),
            previewGradient = listOf(Color(0xFFEC4899), Color(0xFF8B5CF6), Color(0xFF3B82F6))
        ),
        ThemePreset(
            id = 4,
            name = "⚡ Cyber Motherboard & Neon Pulse",
            isDark = true,
            category = "داكن 🌙",
            background = Color(0xFF050B14),
            surface = Color(0xFF0C1424),
            surfaceVariant = Color(0xFF131F37),
            primary = Color(0xFF00F0FF),
            onPrimary = Color(0xFF031525),
            secondary = Color(0xFF10B981),
            onSecondary = Color(0xFF022C22),
            tertiary = Color(0xFFF59E0B),
            outline = Color(0xFF0E7490),
            onBackground = Color(0xFFE2F8FF),
            onSurface = Color(0xFFE2F8FF),
            onSurfaceVariant = Color(0xFF7DD3FC),
            accentBadge = Color(0xFF00F0FF),
            previewGradient = listOf(Color(0xFF050B14), Color(0xFF0E7490), Color(0xFF00F0FF))
        ),
        ThemePreset(
            id = 5,
            name = "🌌 الفضاء",
            isDark = true,
            category = "داكن 🌙",
            background = Color(0xFF03001E),
            surface = Color(0xFF12002E),
            surfaceVariant = Color(0xFF2E004F),
            primary = Color(0xFFD946EF),
            onPrimary = Color.White,
            secondary = Color(0xFF8B5CF6),
            outline = Color(0xFF4A0E4E),
            onBackground = Color(0xFFFAEAFF),
            onSurface = Color(0xFFFAEAFF),
            onSurfaceVariant = Color(0xFFE8AEFF)
        ),
        ThemePreset(
            id = 6,
            name = "🏢 الشركات",
            isDark = false,
            category = "فاتح ☀️",
            background = Color(0xFFF1F5F9),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFE2E8F0),
            primary = Color(0xFF0F172A),
            onPrimary = Color.White,
            secondary = Color(0xFF2563EB),
            outline = Color(0xFFCBD5E1),
            onBackground = Color(0xFF1E293B),
            onSurface = Color(0xFF1E293B),
            onSurfaceVariant = Color(0xFF64748B)
        ),
        ThemePreset(
            id = 7,
            name = "🩷 الوردي",
            isDark = false,
            category = "فاتح ☀️",
            background = Color(0xFFFFF1F2),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFFFE4E6),
            primary = Color(0xFFDB2777),
            onPrimary = Color.White,
            secondary = Color(0xFFF472B6),
            outline = Color(0xFFFBCFE8),
            onBackground = Color(0xFF4C0519),
            onSurface = Color(0xFF4C0519),
            onSurfaceVariant = Color(0xFFBE185D)
        ),
        ThemePreset(
            id = 8,
            name = "🟦 الكحلي",
            isDark = true,
            category = "داكن 🌙",
            background = Color(0xFF0B132B),
            surface = Color(0xFF1C2541),
            surfaceVariant = Color(0xFF3A506B),
            primary = Color(0xFF48CAE4),
            onPrimary = Color(0xFF0B132B),
            secondary = Color(0xFF00B4D8),
            outline = Color(0xFF1C2541),
            onBackground = Color(0xFFE0F1F4),
            onSurface = Color(0xFFE0F1F4),
            onSurfaceVariant = Color(0xFF90E0EF)
        ),
        ThemePreset(
            id = 9,
            name = "🟣 البنفسجي العصري",
            isDark = true,
            category = "داكن 🌙",
            background = Color(0xFF1E1B4B),
            surface = Color(0xFF312E81),
            surfaceVariant = Color(0xFF4338CA),
            primary = Color(0xFFA5B4FC),
            onPrimary = Color(0xFF1E1B4B),
            secondary = Color(0xFFC7D2FE),
            outline = Color(0xFF3F3D56),
            onBackground = Color(0xFFEEF2FF),
            onSurface = Color(0xFFEEF2FF),
            onSurfaceVariant = Color(0xFFC7D2FE)
        )
    )

    fun getById(id: Int): ThemePreset {
        return presets.find { it.id == id } ?: presets.first()
    }
}
