package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student_assignment_submissions")
data class StudentAssignmentSubmission(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val courseId: Int,
    val subjectName: String,
    val studentId: Int,
    val studentName: String,
    val assignmentTitle: String,
    val isCompleted: Boolean = false,
    val completionDate: String = "",
    val evaluationRating: String = "",
    val score: Double? = null,
    val notes: String = ""
)
