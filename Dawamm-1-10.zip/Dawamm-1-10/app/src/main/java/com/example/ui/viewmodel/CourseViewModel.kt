package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.entity.Course
import com.example.data.entity.CourseSubjectCrossRef
import com.example.data.entity.Subject
import com.example.data.entity.SubjectReference
import com.example.data.repository.CourseRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * CourseViewModel: المسؤول الحصري عن إدارة الدورات التدريبية،
 * والمواد والمقررات الدراسية، وارتباط المواد بالدورات، والمراجع العلمية.
 */
class CourseViewModel(
    application: Application,
    private val courseRepository: CourseRepository = run {
        val database = AppDatabase.getDatabase(application)
        CourseRepository(
            database.courseDao(),
            database.subjectDao(),
            database.subjectReferenceDao()
        )
    }
) : AndroidViewModel(application) {

    // --- تدفقات البيانات الشاملة (State Flows) ---
    val allCourses: StateFlow<List<Course>> = courseRepository.allCourses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSubjects: StateFlow<List<Subject>> = courseRepository.allSubjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCourseSubjects: StateFlow<List<CourseSubjectCrossRef>> = courseRepository.allCourseSubjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSubjectReferences: StateFlow<List<SubjectReference>> = courseRepository.allReferences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // الدورات النشطة (غير المكتملة)
    val activeCourses: StateFlow<List<Course>> = allCourses.map { courses ->
        courses.filter { !it.isCompleted }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- حالة التحديد والنموذج (Form & Selection State) ---
    private val _selectedCourseForEdit = MutableStateFlow<Course?>(null)
    val selectedCourseForEdit: StateFlow<Course?> = _selectedCourseForEdit.asStateFlow()

    val courseNameInput = MutableStateFlow("")
    val courseStartDateInput = MutableStateFlow("")
    val courseEndDateInput = MutableStateFlow("")
    val courseStartTimeInput = MutableStateFlow("")
    val courseEndTimeInput = MutableStateFlow("")
    val courseDepartmentInput = MutableStateFlow("")
    val courseDiplomaInput = MutableStateFlow("")
    val selectedCourseSubjectsInput = MutableStateFlow<Set<Int>>(emptySet())

    fun selectCourseForEdit(course: Course) {
        _selectedCourseForEdit.value = course
        courseNameInput.value = course.name
        courseStartDateInput.value = course.startDate
        courseEndDateInput.value = course.endDate
        courseStartTimeInput.value = course.startTime
        courseEndTimeInput.value = course.endTime
        courseDepartmentInput.value = course.departmentName
        courseDiplomaInput.value = course.diplomaName

        val assigned = allCourseSubjects.value
            .filter { it.courseId == course.id }
            .map { it.subjectId }
            .toSet()
        selectedCourseSubjectsInput.value = assigned
    }

    fun clearCourseForm() {
        _selectedCourseForEdit.value = null
        courseNameInput.value = ""
        courseStartDateInput.value = ""
        courseEndDateInput.value = ""
        courseStartTimeInput.value = ""
        courseEndTimeInput.value = ""
        courseDepartmentInput.value = ""
        courseDiplomaInput.value = ""
        selectedCourseSubjectsInput.value = emptySet()
    }

    fun toggleSubjectSelectionInForm(subjectId: Int) {
        val current = selectedCourseSubjectsInput.value
        if (current.contains(subjectId)) {
            selectedCourseSubjectsInput.value = current - subjectId
        } else {
            selectedCourseSubjectsInput.value = current + subjectId
        }
    }

    private val studentGradeConfigDao = AppDatabase.getDatabase(application).studentGradeConfigDao()

    // --- عمليات الدورات (Course Operations) ---
    fun insertCourse(course: Course, onInserted: ((Long) -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = courseRepository.insertCourse(course)
            val context = getApplication<Application>()
            val sharedPrefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
            val enabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
            if (enabled) {
                val trainerMins = sharedPrefs.getInt("trainer_reminder_minutes", 15)
                val checkInMins = sharedPrefs.getInt("student_check_in_reminder_minutes", 10)
                val checkOutMins = sharedPrefs.getInt("student_check_out_reminder_minutes", 10)
                val savedCourse = course.copy(id = id.toInt())
                com.example.notification.NotificationHelper.scheduleCourseReminders(
                    context, savedCourse, trainerMins, checkInMins, checkOutMins
                )
            }

            // Automatically initialize Grade Config for this new course
            val fieldsJson = if (course.departmentName.contains("حاسب") || course.departmentName.contains("حاسوب")) {
                com.example.data.entity.StudentGradeConfig.serializeFields(
                    listOf(
                        Pair("حضور", 5),
                        Pair("مشاركة", 5),
                        Pair("تكاليف", 10),
                        Pair("مشاريع", 20),
                        Pair("اختبار نظري", 20),
                        Pair("اختبار عملي", 40)
                    )
                )
            } else {
                com.example.data.entity.StudentGradeConfig.serializeFields(
                    listOf(
                        Pair("حضور", 10),
                        Pair("مشاركة", 10),
                        Pair("تكاليف", 20),
                        Pair("اختبار نظري", 30),
                        Pair("اختبار عملي", 30)
                    )
                )
            }
            val config = com.example.data.entity.StudentGradeConfig(
                courseId = id.toInt(),
                courseName = course.name,
                isDiploma = true,
                customFieldsJson = fieldsJson
            )
            studentGradeConfigDao.insertGradeConfig(config)

            onInserted?.invoke(id)
        }
    }

    fun updateCourse(course: Course) {
        viewModelScope.launch(Dispatchers.IO) {
            courseRepository.updateCourse(course)
            val context = getApplication<Application>()
            val sharedPrefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
            val enabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
            if (enabled) {
                val trainerMins = sharedPrefs.getInt("trainer_reminder_minutes", 15)
                val checkInMins = sharedPrefs.getInt("student_check_in_reminder_minutes", 10)
                val checkOutMins = sharedPrefs.getInt("student_check_out_reminder_minutes", 10)
                com.example.notification.NotificationHelper.scheduleCourseReminders(
                    context, course, trainerMins, checkInMins, checkOutMins
                )
            }
        }
    }

    fun deleteCourse(course: Course) {
        viewModelScope.launch(Dispatchers.IO) {
            courseRepository.deleteCourse(course)
            val context = getApplication<Application>()
            com.example.notification.NotificationHelper.cancelCourseReminders(context, course.id)
        }
    }

    // --- Activity Logging Helper ---
    private val appActivityLogDao = AppDatabase.getDatabase(application).appActivityLogDao()

    fun logActivity(
        category: String,
        actionType: String,
        title: String,
        description: String,
        relatedId: Long? = null,
        customDateStr: String? = null,
        customTimeStr: String? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = java.util.Date()
            val sdfDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH)
            val sdfTime = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ENGLISH)
            val dateStr = customDateStr ?: sdfDate.format(now)
            val timeStr = customTimeStr ?: sdfTime.format(now)
            val log = com.example.data.entity.AppActivityLog(
                category = category,
                actionType = actionType,
                title = title,
                description = description,
                dateStr = dateStr,
                timeStr = timeStr,
                relatedId = relatedId
            )
            appActivityLogDao.insertLog(log)
        }
    }

    fun toggleCourseCompleted(course: Course) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = course.copy(isCompleted = !course.isCompleted)
            courseRepository.updateCourse(updated)
            logActivity(
                category = "COURSES",
                actionType = if (updated.isCompleted) "COMPLETE" else "REOPEN",
                title = if (updated.isCompleted) "إنهاء دورة: ${course.name} 🏁" else "إعادة تنشيط دورة: ${course.name} 🔄",
                description = if (updated.isCompleted) "تم تعيين الدورة كمنتهية." else "تمت إعادة تنشيط الدورة كمستمرة.",
                relatedId = course.id.toLong()
            )
            val context = getApplication<Application>()
            if (updated.isCompleted) {
                com.example.notification.NotificationHelper.cancelCourseReminders(context, updated.id)
            } else {
                val sharedPrefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
                val enabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
                if (enabled) {
                    val trainerMins = sharedPrefs.getInt("trainer_reminder_minutes", 15)
                    val checkInMins = sharedPrefs.getInt("student_check_in_reminder_minutes", 10)
                    val checkOutMins = sharedPrefs.getInt("student_check_out_reminder_minutes", 10)
                    com.example.notification.NotificationHelper.scheduleCourseReminders(
                        context, updated, trainerMins, checkInMins, checkOutMins
                    )
                }
            }
        }
    }

    // --- عمليات المواد التدريسية (Subject Operations) ---
    fun insertSubject(subject: Subject, onInserted: ((Long) -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = courseRepository.insertSubject(subject)
            onInserted?.invoke(id)
        }
    }

    fun updateSubject(subject: Subject) {
        viewModelScope.launch(Dispatchers.IO) {
            courseRepository.updateSubject(subject)
            logActivity(
                category = "CURRICULUM",
                actionType = "UPDATE",
                title = "تعديل المادة التدريسية: ${subject.name}",
                description = "الاسم الجديد: ${subject.name} | الكود: ${subject.code} | الوصف: ${subject.description}"
            )
        }
    }

    fun deleteSubject(subject: Subject) {
        viewModelScope.launch(Dispatchers.IO) {
            courseRepository.deleteSubject(subject)
            logActivity(
                category = "CURRICULUM",
                actionType = "DELETE",
                title = "حذف المادة التدريسية: ${subject.name}",
                description = "الكود: ${subject.code}"
            )
        }
    }

    // --- ربط المواد بالدورات (Course Subject CrossRef) ---
    fun insertCourseSubjectCrossRef(crossRef: CourseSubjectCrossRef) {
        viewModelScope.launch(Dispatchers.IO) {
            courseRepository.insertCourseSubject(crossRef)
        }
    }

    fun deleteCourseSubjectCrossRef(crossRef: CourseSubjectCrossRef) {
        viewModelScope.launch(Dispatchers.IO) {
            courseRepository.deleteCourseSubject(crossRef)
        }
    }

    fun toggleSubjectCourseAssignment(courseId: Int, subjectId: Int, defaultDays: Int = 5) {
        viewModelScope.launch(Dispatchers.IO) {
            val existing = allCourseSubjects.value.find { it.courseId == courseId && it.subjectId == subjectId }
            if (existing != null) {
                courseRepository.deleteCourseSubject(existing)
            } else {
                courseRepository.insertCourseSubject(
                    CourseSubjectCrossRef(courseId = courseId, subjectId = subjectId, targetDays = defaultDays)
                )
            }
        }
    }

    // --- المراجع العلمية (Subject References) ---
    fun insertSubjectReference(reference: SubjectReference) {
        viewModelScope.launch(Dispatchers.IO) {
            courseRepository.insertSubjectReference(reference)
            logActivity(
                category = "CURRICULUM",
                actionType = "CREATE",
                title = "إضافة مرجع علمي: ${reference.title}",
                description = "المادة: ${reference.subjectName} | الرابط: ${reference.urlOrPath}"
            )
        }
    }

    fun updateSubjectReference(reference: SubjectReference) {
        viewModelScope.launch(Dispatchers.IO) {
            courseRepository.updateSubjectReference(reference)
            logActivity(
                category = "CURRICULUM",
                actionType = "UPDATE",
                title = "تعديل مرجع علمي: ${reference.title}",
                description = "المادة: ${reference.subjectName} | الرابط: ${reference.urlOrPath}"
            )
        }
    }

    fun deleteSubjectReference(reference: SubjectReference) {
        viewModelScope.launch(Dispatchers.IO) {
            courseRepository.deleteSubjectReference(reference)
            logActivity(
                category = "CURRICULUM",
                actionType = "DELETE",
                title = "حذف مرجع علمي: ${reference.title}",
                description = "المادة: ${reference.subjectName}"
            )
        }
    }
}
