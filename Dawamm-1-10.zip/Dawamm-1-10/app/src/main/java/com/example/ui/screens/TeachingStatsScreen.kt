package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.MainViewModel

@Composable
fun TeachingStatsScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    showMainLayout: Boolean = true
) {
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    
    MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            SubjectTeachingStatsSection(
                viewModel = viewModel,
                courseViewModel = courseViewModel,
                attendanceViewModel = attendanceViewModel,
                isDarkTheme = isDarkTheme
            )
        }
    }
}
