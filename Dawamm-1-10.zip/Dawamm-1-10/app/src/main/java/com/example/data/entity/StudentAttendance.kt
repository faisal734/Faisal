package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student_attendance_records")
data class StudentAttendance(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studentId: Int,
    val studentName: String,
    val courseId: Int,
    val courseName: String,
    val date: String,            // format: "yyyy-MM-dd"
    val dayOfWeek: String,       // Arabic: "الأحد", "الاثنين", ...
    val actualCheckIn: String,   // format: "HH:mm" (empty if absent/leave)
    val actualCheckOut: String,  // format: "HH:mm" (empty if not checked out)
    val checkInDelayMinutes: Int = 0,
    val checkOutDifferenceMinutes: Int = 0, // negative means early checkout, positive means overtime
    val hasAlert: Boolean = false,
    val alertMessage: String = "",
    val status: String = "حضور",  // "حضور" (Present), "غياب" (Absent), "إجازة" (Leave)
    val participationStars: Int = 5, // Daily participation rating (0 to 5 stars)
    val studentNote: String = "", // private note for the student
    val courseDailyNote: String = "", // general daily course note
    val subjectName: String = "", // subject name assigned by teacher
    val hasResearch: Boolean = false, // البحوث
    val hasAssignment: Boolean = false, // الواجبات
    val isOnBreak: Boolean = false,
    val breakStartTime: String = "",
    val breakDurationMinutes: Int = 0,
    val breakActualReturnTime: String = "",
    val breakDelayMinutes: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)
