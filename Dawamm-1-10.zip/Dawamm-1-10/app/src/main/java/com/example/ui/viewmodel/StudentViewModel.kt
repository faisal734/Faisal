package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentViolation
import com.example.data.repository.StudentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * StudentViewModel: المسؤول الحصري عن شؤون الطلاب والمتدربين،
 * تسجيل الطلاب، تعديل بياناتهم، نقلهم بين الدورات، وسجلات المخالفات السلوكية.
 */
class StudentViewModel(
    application: Application,
    private val studentRepository: StudentRepository = run {
        val database = AppDatabase.getDatabase(application)
        StudentRepository(
            database.studentDao(),
            database.studentViolationDao()
        )
    }
) : AndroidViewModel(application) {

    // --- تدفقات البيانات الشاملة (State Flows) ---
    val allStudents: StateFlow<List<Student>> = studentRepository.allStudents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allViolations: StateFlow<List<StudentViolation>> = studentRepository.allViolations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- حالة التحديد والنموذج (Selection & Form State) ---
    private val _selectedCourseForStudents = MutableStateFlow<Course?>(null)
    val selectedCourseForStudents: StateFlow<Course?> = _selectedCourseForStudents.asStateFlow()

    val studentNameInput = MutableStateFlow("")
    val studentPhoneInput = MutableStateFlow("")

    fun selectCourseForStudents(course: Course?) {
        _selectedCourseForStudents.value = course
    }

    // --- Activity Logging Helper ---
    private val appActivityLogDao = AppDatabase.getDatabase(application).appActivityLogDao()

    fun logActivity(
        category: String,
        actionType: String,
        title: String,
        description: String,
        relatedId: Long? = null,
        customDateStr: String? = null,
        customTimeStr: String? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = java.util.Date()
            val sdfDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH)
            val sdfTime = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ENGLISH)
            val dateStr = customDateStr ?: sdfDate.format(now)
            val timeStr = customTimeStr ?: sdfTime.format(now)
            val log = com.example.data.entity.AppActivityLog(
                category = category,
                actionType = actionType,
                title = title,
                description = description,
                dateStr = dateStr,
                timeStr = timeStr,
                relatedId = relatedId
            )
            appActivityLogDao.insertLog(log)
        }
    }

    // --- عمليات إدارة الطلاب (Student Operations) ---
    fun insertStudent(student: Student, onInserted: ((Long) -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = studentRepository.insertStudent(student)
            onInserted?.invoke(id)
        }
    }

    fun updateStudent(student: Student) {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.updateStudent(student)
        }
    }

    fun deleteStudent(student: Student) {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.deleteStudent(student)
            logActivity(
                category = "STUDENTS",
                actionType = "DELETE",
                title = "حذف الطالب: ${student.name}",
                description = "الدورة: ${student.courseName}",
                relatedId = student.courseId.toLong()
            )
        }
    }

    fun updateStudentName(student: Student, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.updateStudent(student.copy(name = newName))
            logActivity(
                category = "STUDENTS",
                actionType = "UPDATE",
                title = "تعديل اسم الطالب: $newName",
                description = "الاسم السابق: ${student.name} | الدورة: ${student.courseName}",
                relatedId = student.courseId.toLong()
            )
        }
    }

    fun updateStudentPhone(student: Student, newPhone: String) {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.updateStudent(student.copy(phoneNumber = newPhone))
            logActivity(
                category = "STUDENTS",
                actionType = "UPDATE",
                title = "تحديث هاتف الطالب: ${student.name}",
                description = "الهاتف الجديد: $newPhone | الدورة: ${student.courseName}",
                relatedId = student.courseId.toLong()
            )
        }
    }

    fun updateStudentDetails(student: Student, newName: String, newPhone: String) {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.updateStudent(student.copy(name = newName, phoneNumber = newPhone))
            logActivity(
                category = "STUDENTS",
                actionType = "UPDATE",
                title = "تعديل بيانات الطالب: $newName",
                description = "الهاتف: $newPhone | الدورة: ${student.courseName}",
                relatedId = student.courseId.toLong()
            )
        }
    }

    fun updateStudentStatus(student: Student, newStatus: String, changeDate: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.updateStudent(student.copy(status = newStatus, statusChangeDate = changeDate))
            logActivity(
                category = "STUDENTS",
                actionType = "UPDATE",
                title = "تحديث حالة الطالب: ${student.name}",
                description = "الحالة الجديدة: $newStatus",
                relatedId = student.courseId.toLong()
            )
        }
    }

    fun transferStudent(studentId: Int, newCourseId: Int, newCourseName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.transferStudent(studentId, newCourseId, newCourseName)
        }
    }

    // --- سجلات المخالفات السلوكية (Student Violations) ---
    fun insertViolation(violation: StudentViolation, onInserted: ((Long) -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = studentRepository.insertViolation(violation)
            logActivity(
                category = "STUDENTS",
                actionType = "CREATE",
                title = "تسجيل مخالفة: ${violation.violationTitle}",
                description = "الطالب: ${violation.studentName} | الإجراء: ${violation.actionTaken} | التاريخ: ${violation.date}"
            )
            onInserted?.invoke(id)
        }
    }

    fun insertViolations(violations: List<StudentViolation>) {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.insertViolations(violations)
            logActivity(
                category = "STUDENTS",
                actionType = "CREATE",
                title = "تسجيل مخالفة جماعية لـ ${violations.size} طلاب",
                description = "المخالفة: ${violations.firstOrNull()?.violationTitle ?: ""} | التاريخ: ${violations.firstOrNull()?.date ?: ""}"
            )
        }
    }

    fun updateViolation(violation: StudentViolation) {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.updateViolation(violation)
            logActivity(
                category = "STUDENTS",
                actionType = "UPDATE",
                title = "تعديل مخالفة: ${violation.violationTitle}",
                description = "الطالب: ${violation.studentName} | الإجراء: ${violation.actionTaken}"
            )
        }
    }

    fun deleteViolation(violation: StudentViolation) {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.deleteViolation(violation)
            logActivity(
                category = "STUDENTS",
                actionType = "DELETE",
                title = "حذف مخالفة: ${violation.violationTitle}",
                description = "الطالب: ${violation.studentName}"
            )
        }
    }

    fun deleteViolationById(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val v = allViolations.value.find { it.id == id }
            studentRepository.deleteViolationById(id)
            logActivity(
                category = "STUDENTS",
                actionType = "DELETE",
                title = "حذف مخالفة: ${v?.violationTitle ?: ""}",
                description = "الطالب: ${v?.studentName ?: ""}"
            )
        }
    }

    fun deleteAllViolations() {
        viewModelScope.launch(Dispatchers.IO) {
            studentRepository.deleteAllViolations()
            logActivity(
                category = "STUDENTS",
                actionType = "DELETE",
                title = "حذف سجل المخالفات بالكامل",
                description = "تم مسح جميع المخالفات المسجلة للطلاب"
            )
        }
    }
}
