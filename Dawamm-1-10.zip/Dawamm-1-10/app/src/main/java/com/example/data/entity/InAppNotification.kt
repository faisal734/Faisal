package com.example.data.entity

import java.util.UUID

data class InAppNotification(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val message: String,
    val type: String = "info", // "warning", "action", "success", "info"
    val timestamp: Long = System.currentTimeMillis(),
    var isRead: Boolean = false,
    val actionType: String? = null,
    val courseId: Int? = null
)
