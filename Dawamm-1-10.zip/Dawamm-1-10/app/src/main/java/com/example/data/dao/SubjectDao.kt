package com.example.data.dao

import androidx.room.*
import com.example.data.entity.Subject
import com.example.data.entity.CourseSubjectCrossRef
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY name ASC")
    fun getAllSubjects(): Flow<List<Subject>>

    @Query("SELECT * FROM subjects WHERE id = :subjectId")
    suspend fun getSubjectById(subjectId: Int): Subject?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: Subject): Long

    @Update
    suspend fun updateSubject(subject: Subject)

    @Delete
    suspend fun deleteSubject(subject: Subject)

    @Query("DELETE FROM subjects")
    suspend fun deleteAllSubjects()

    // Course Subject Cross References
    @Query("SELECT * FROM course_subjects")
    fun getAllCourseSubjects(): Flow<List<CourseSubjectCrossRef>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourseSubject(crossRef: CourseSubjectCrossRef)

    @Delete
    suspend fun deleteCourseSubject(crossRef: CourseSubjectCrossRef)

    @Query("DELETE FROM course_subjects WHERE courseId = :courseId")
    suspend fun deleteSubjectsByCourseId(courseId: Int)

    @Query("DELETE FROM course_subjects WHERE subjectId = :subjectId")
    suspend fun deleteCoursesBySubjectId(subjectId: Int)

    @Query("DELETE FROM course_subjects")
    suspend fun deleteAllCourseSubjects()
}
