package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.entity.Course
import com.example.ui.viewmodel.Screen
import com.example.data.entity.Student
import com.example.data.entity.StudentAttendance
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentGradeConfig
import com.example.data.entity.StudentViolation
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Student360Dialog(
    student: Student,
    viewModel: MainViewModel,
    studentViewModel: StudentViewModel? = null,
    onDismiss: () -> Unit,
    onOpenAttendanceMovement: (Student) -> Unit = {},
    onOpenStatusManagement: (Student) -> Unit = {},
    onOpenEdit: (Student) -> Unit = {}
) {
    val context = LocalContext.current
    val dbCourses by viewModel.dbCourses.collectAsState()
    val allAttendance by viewModel.dbAllStudentAttendance.collectAsState()
    val allGrades by viewModel.dbAllGrades.collectAsState()
    val allGradeConfigs by viewModel.dbAllGradeConfigs.collectAsState()
    val allViolations by (studentViewModel?.allViolations ?: viewModel.dbStudentViolations).collectAsState()
    val dbSubjects by viewModel.dbSubjects.collectAsState()
    val dbTrainerAttendance by viewModel.dbAttendance.collectAsState()

    // Student's specific data
    val studentAttendanceRecords = remember(allAttendance, student.id) {
        allAttendance.filter { it.studentId == student.id }.sortedByDescending { it.date }
    }

    val studentGrades = remember(allGrades, student.id) {
        allGrades.filter { it.studentId == student.id }
    }

    val studentViolationsList = remember(allViolations, student.id) {
        allViolations.filter { it.studentId.toInt() == student.id }.sortedByDescending { it.date }
    }

    val studentCourse = remember(dbCourses, student.courseId) {
        dbCourses.find { it.id == student.courseId }
    }

    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("نظرة عامة", "الحضور", "الدرجات", "المخالفات", "التقارير")

    // State for quick adding violation
    var showAddViolationDialog by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 12.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.background,
            tonalElevation = 6.dp,
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Top Header with Gradient / DawamiNavy
                Surface(
                    color = DawamiNavy,
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        // Top bar inside header: Close button + Actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onDismiss,
                                colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق")
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Status Management Shortcut
                                IconButton(
                                    onClick = { onOpenStatusManagement(student) },
                                    colors = IconButtonDefaults.iconButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.15f),
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Default.ManageAccounts,
                                        contentDescription = "إدارة الحالة",
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                // Edit Shortcut
                                IconButton(
                                    onClick = { onOpenEdit(student) },
                                    colors = IconButtonDefaults.iconButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.15f),
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Edit,
                                        contentDescription = "تعديل البيانات",
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Student Profile Header Info
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Avatar
                            Surface(
                                color = DawamiTeal.copy(alpha = 0.25f),
                                shape = CircleShape,
                                modifier = Modifier.size(54.dp),
                                border = BorderStroke(2.dp, DawamiGold)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = student.name,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    // Status Badge
                                    val effectiveStatus = when {
                                        student.status == "خريج" -> "خريج 🎓"
                                        studentCourse?.isCompleted == true && (student.status == "مستمر" || student.status.isBlank()) -> "خريج 🎓"
                                        else -> student.status
                                    }
                                    val (statusBg, statusFg) = when {
                                        effectiveStatus.contains("خريج") -> Pair(Color(0xFF059669), Color.White)
                                        student.status == "مستمر" -> Pair(Color(0xFF10B981), Color.White)
                                        student.status == "توقيف قيد" -> Pair(Color(0xFFF59E0B), Color.Black)
                                        student.status == "منسحب" -> Pair(Color(0xFFEF4444), Color.White)
                                        else -> Pair(Color(0xFF3B82F6), Color.White)
                                    }

                                    Surface(
                                        color = statusBg,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = effectiveStatus,
                                            color = statusFg,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }

                                    // Course Badge
                                    Surface(
                                        color = Color.White.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = student.courseName.ifBlank { studentCourse?.name ?: "الدورة" },
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }

                        // Phone & Contact Bar
                        if (student.phoneNumber.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                color = Color.White.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Phone,
                                            contentDescription = null,
                                            tint = DawamiGold,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = student.phoneNumber,
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Call Button
                                        FilledTonalIconButton(
                                            onClick = {
                                                try {
                                                    val intent = Intent(Intent.ACTION_DIAL).apply {
                                                        data = Uri.parse("tel:${student.phoneNumber}")
                                                    }
                                                    context.startActivity(intent)
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "تعذر فتح تطبيق الاتصال", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.size(32.dp),
                                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                                containerColor = Color(0xFF10B981),
                                                contentColor = Color.White
                                            )
                                        ) {
                                            Icon(Icons.Default.Call, contentDescription = "اتصال", modifier = Modifier.size(16.dp))
                                        }

                                        // WhatsApp Button
                                        FilledTonalIconButton(
                                            onClick = {
                                                shareStudentViaWhatsApp(
                                                    context = context,
                                                    phone = student.phoneNumber,
                                                    message = "مرحباً يا ${student.name}، نود إعلامك بمستجدات دورة ${student.courseName}."
                                                )
                                            },
                                            modifier = Modifier.size(32.dp),
                                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                                containerColor = Color(0xFF25D366),
                                                contentColor = Color.White
                                            )
                                        ) {
                                            Icon(Icons.Default.Chat, contentDescription = "واتساب", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 5 Tabs Navigation
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = DawamiNavy,
                    edgePadding = 8.dp
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == index) DawamiNavy else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        )
                    }
                }

                Divider(color = Color(0xFFE2E8F0), thickness = 1.dp)

                // Tab Content
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    when (selectedTab) {
                        0 -> StudentOverviewTab(
                            student = student,
                            attendanceList = studentAttendanceRecords,
                            gradesList = studentGrades,
                            violationsList = studentViolationsList,
                            gradeConfigs = allGradeConfigs,
                            onSwitchTab = { selectedTab = it },
                            onOpenAttendanceMovement = { onOpenAttendanceMovement(student) }
                        )
                        1 -> StudentAttendanceTab(
                            attendanceList = studentAttendanceRecords,
                            trainerAttendanceList = dbTrainerAttendance,
                            onOpenAttendanceMovement = { onOpenAttendanceMovement(student) }
                        )
                        2 -> StudentGradesTab(
                            student = student,
                            gradesList = studentGrades,
                            gradeConfigs = allGradeConfigs,
                            onOpenGrades = {
                                studentCourse?.let {
                                    viewModel.selectCourseForGrades(it)
                                    viewModel.setSelectedGradesTabIndex(0)
                                }
                                viewModel.navigateTo(Screen.Grades)
                                onDismiss()
                            }
                        )
                        3 -> StudentViolationsTab(
                            violationsList = studentViolationsList,
                            onAddViolation = { showAddViolationDialog = true },
                            onShareViolation = { v ->
                                val text = buildSingleViolationShareText(v)
                                shareStudentViaWhatsApp(context, student.phoneNumber, text)
                            }
                        )
                        4 -> StudentReportsTab(
                            student = student,
                            attendanceList = studentAttendanceRecords,
                            gradesList = studentGrades,
                            violationsList = studentViolationsList,
                            context = context,
                            isCourseCompleted = studentCourse?.isCompleted == true
                        )
                    }
                }
            }
        }
    }

    // Quick Add Violation Dialog
    if (showAddViolationDialog) {
        QuickAddViolationDialog(
            student = student,
            subjects = dbSubjects.map { it.name }.filter { it.isNotBlank() }.distinct(),
            courseId = student.courseId.toLong(),
            onDismiss = { showAddViolationDialog = false },
            onSave = { violation ->
                if (studentViewModel != null) {
                    studentViewModel.insertViolation(violation)
                } else {
                    viewModel.insertViolation(violation)
                }
                Toast.makeText(context, "تم تسجيل المخالفة للطالب بنجاح 📋", Toast.LENGTH_SHORT).show()
                showAddViolationDialog = false
            }
        )
    }
}

// ==========================================
// 1. OVERVIEW TAB (نظرة عامة)
// ==========================================
@Composable
private fun StudentOverviewTab(
    student: Student,
    attendanceList: List<StudentAttendance>,
    gradesList: List<StudentGrade>,
    violationsList: List<StudentViolation>,
    gradeConfigs: List<StudentGradeConfig>,
    onSwitchTab: (Int) -> Unit,
    onOpenAttendanceMovement: () -> Unit
) {
    val totalSessions = attendanceList.size
    val presentCount = attendanceList.count { it.status == "حضور" }
    val lateCount = attendanceList.count { it.checkInDelayMinutes > 0 }
    val totalDelayMinutes = attendanceList.sumOf { it.checkInDelayMinutes }
    val absentCount = attendanceList.count { it.status == "غياب" }
    val leaveCount = attendanceList.count { it.status == "إجازة" || it.status == "عذر" }
    
    val attendanceRate = if (totalSessions > 0) {
        ((presentCount.toFloat() / totalSessions.toFloat()) * 100).toInt()
    } else {
        100
    }

    val avgStars = if (attendanceList.isNotEmpty()) {
        attendanceList.map { it.participationStars }.average()
    } else {
        5.0
    }

    val totalAssignments = attendanceList.count { it.hasAssignment }
    val totalResearch = attendanceList.count { it.hasResearch }

    // Overall Grade calculation
    val currentCourseGrades = gradesList.filter { it.courseId == student.courseId }
    val totalGradeScore = currentCourseGrades.sumOf { it.getTotalScore() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Attendance & Discipline Highlights Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(20.dp))
                        Text("مؤشرات الانضباط والحضور", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DawamiNavy)
                    }

                    // Attendance rate badge
                    val rateBadgeColor = when {
                        attendanceRate >= 85 -> Color(0xFF10B981)
                        attendanceRate >= 70 -> Color(0xFFF59E0B)
                        else -> Color(0xFFEF4444)
                    }
                    Surface(
                        color = rateBadgeColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, rateBadgeColor)
                    ) {
                        Text(
                            text = "نسبة الحضور: $attendanceRate%",
                            color = rateBadgeColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Metric Grid (2x3)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricCard(
                        title = "حضور",
                        value = "$presentCount",
                        sub = "من أصل $totalSessions جلسة",
                        color = Color(0xFF10B981),
                        icon = Icons.Default.CheckCircle,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "غياب",
                        value = "$absentCount",
                        sub = if (absentCount >= 3) "⚠️ إنذار غياب" else "مقبول",
                        color = if (absentCount >= 3) Color(0xFFEF4444) else Color(0xFF64748B),
                        icon = Icons.Default.Cancel,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricCard(
                        title = "تأخير",
                        value = "$lateCount",
                        sub = "$totalDelayMinutes دقيقة إجمالي",
                        color = if (lateCount > 0) Color(0xFFF59E0B) else Color(0xFF64748B),
                        icon = Icons.Default.Schedule,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "إجازات وأعذار",
                        value = "$leaveCount",
                        sub = "جلسات مبررة",
                        color = Color(0xFF3B82F6),
                        icon = Icons.Default.EventBusy,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricCard(
                        title = "المخالفات",
                        value = "${violationsList.size}",
                        sub = if (violationsList.isNotEmpty()) "سجلات مرصودة" else "سجل نظيف ✨",
                        color = if (violationsList.isNotEmpty()) Color(0xFFDC2626) else Color(0xFF10B981),
                        icon = Icons.Default.WarningAmber,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "تقييم التفاعل",
                        value = String.format(Locale.US, "%.1f ⭐", avgStars),
                        sub = "متوسط النجوم",
                        color = DawamiGold,
                        icon = Icons.Default.Star,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Academic Progress Card (Grades & Submissions)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(20.dp))
                        Text("التحصيل الأكاديمي والدرجات", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DawamiNavy)
                    }

                    TextButton(onClick = { onSwitchTab(2) }) {
                        Text("عرض الكشف", fontSize = 11.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = DawamiNavy.copy(alpha = 0.06f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("المواد المسجلة درجاتها", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${currentCourseGrades.size} مواد",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy
                            )
                        }
                    }

                    Surface(
                        color = DawamiNavy.copy(alpha = 0.06f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("الواجبات والبحوث المنجزة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "$totalAssignments واجب / $totalResearch بحث",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy
                            )
                        }
                    }
                }
            }
        }

        // Quick Action Buttons
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("إجراءات وخدمات سريعة للطالب", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DawamiNavy)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onOpenAttendanceMovement,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DawamiNavy),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.EventNote, contentDescription = null, modifier = Modifier.size(16.dp), tint = DawamiNavy)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حركة الحضور بالمواد", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { onSwitchTab(3) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                        border = BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.5f)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFFDC2626))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إدارة المخالفات", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { onSwitchTab(4) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة التقرير الشامل عبر واتساب", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    sub: String,
    color: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = color.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
                }
            }

            Column {
                Text(text = title, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
                Text(text = sub, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

// ==========================================
// 2. ATTENDANCE TAB (الحضور)
// ==========================================
@Composable
private fun StudentAttendanceTab(
    attendanceList: List<StudentAttendance>,
    trainerAttendanceList: List<com.example.data.entity.Attendance> = emptyList(),
    onOpenAttendanceMovement: () -> Unit
) {
    var filterStatus by remember { mutableStateOf("الكل") }
    var filterSubject by remember { mutableStateOf("الكل") }

    val subjectsList = remember(attendanceList) {
        listOf("الكل") + attendanceList.map { it.subjectName }.filter { it.isNotBlank() }.distinct()
    }

    val filteredList = remember(attendanceList, filterStatus, filterSubject) {
        attendanceList.filter { record ->
            val matchStatus = when (filterStatus) {
                "حضور" -> record.status == "حضور"
                "غياب" -> record.status == "غياب"
                "تأخير" -> record.checkInDelayMinutes > 0
                "إجازة/عذر" -> record.status == "إجازة" || record.status == "عذر"
                else -> true
            }
            val matchSubject = if (filterSubject == "الكل") true else record.subjectName == filterSubject
            matchStatus && matchSubject
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Filter Chips Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val statusChips = listOf("الكل", "حضور", "تأخير", "غياب", "إجازة/عذر")
            items(statusChips) { status ->
                FilterChip(
                    selected = filterStatus == status,
                    onClick = { filterStatus = status },
                    label = { Text(status, fontSize = 11.sp) },
                    shape = RoundedCornerShape(8.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = DawamiNavy,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Records Count & Movement Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "السجلات (${filteredList.size} سجل)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DawamiNavy
            )

            TextButton(
                onClick = onOpenAttendanceMovement,
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Icon(Icons.Default.SyncAlt, contentDescription = null, modifier = Modifier.size(14.dp), tint = DawamiTeal)
                Spacer(modifier = Modifier.width(4.dp))
                Text("حركات الحضور ونقل المواد", fontSize = 11.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.EventBusy, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("لا توجد سجلات حضور مطابقة لهذا الفلتر", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredList, key = { it.id }) { record ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.CalendarToday, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(14.dp))
                                    Text(
                                        text = "${record.date} (${record.dayOfWeek})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = DawamiNavy
                                    )
                                }

                                // Status Badge
                                val (sColor, sBg) = when (record.status) {
                                    "حضور" -> Pair(Color(0xFF10B981), Color(0xFFE6F4EA))
                                    "غياب" -> Pair(Color(0xFFEF4444), Color(0xFFFCE8E6))
                                    "إجازة", "عذر" -> Pair(Color(0xFF3B82F6), Color(0xFFE8F0FE))
                                    else -> Pair(Color(0xFF64748B), Color(0xFFF1F5F9))
                                }
                                Surface(
                                    color = sBg,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = record.status,
                                        color = sColor,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            if (record.subjectName.isNotBlank()) {
                                val isExamDay = trainerAttendanceList.any { it.courseId == record.courseId && it.date == record.date && it.isExamDay }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "المادة: ${record.subjectName}",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (isExamDay) {
                                        Surface(
                                            color = Color(0xFFFEF3C7),
                                            shape = RoundedCornerShape(4.dp),
                                            border = BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.5f))
                                        ) {
                                            Text(
                                                text = "📝 امتحان",
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFB45309),
                                                maxLines = 1,
                                                softWrap = false,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Times & Delays
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (record.actualCheckIn.isNotBlank()) {
                                        Text(
                                            text = "دخول: ${record.actualCheckIn}",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    if (record.actualCheckOut.isNotBlank()) {
                                        Text(
                                            text = "خروج: ${record.actualCheckOut}",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    if (record.checkInDelayMinutes > 0) {
                                        Text(
                                            text = "تأخير: ${record.checkInDelayMinutes} د",
                                            fontSize = 10.sp,
                                            color = Color(0xFFD97706),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                // Stars
                                Row {
                                    repeat(record.participationStars.coerceIn(0, 5)) {
                                        Text("⭐", fontSize = 9.sp)
                                    }
                                }
                            }

                            // Student Note if available
                            if (record.studentNote.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    color = Color(0xFFFEF3C7),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Notes, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(12.dp))
                                        Text(
                                            text = record.studentNote,
                                            fontSize = 10.sp,
                                            color = Color(0xFF92400E)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. GRADES TAB (الدرجات)
// ==========================================
@Composable
private fun StudentGradesTab(
    student: Student,
    gradesList: List<StudentGrade>,
    gradeConfigs: List<StudentGradeConfig>,
    onOpenGrades: () -> Unit = {}
) {
    val currentCourseGrades = remember(gradesList, student.courseId) {
        gradesList.filter { it.courseId == student.courseId }
    }

    val previousCourseGrades = remember(gradesList, student.courseId) {
        gradesList.filter { it.courseId != student.courseId }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Summary Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DawamiNavy),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("كشف درجات الطالب", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "الدورة: ${student.courseName}",
                            color = DawamiGold,
                            fontSize = 11.sp
                        )
                    }

                    val totalEarned = currentCourseGrades.sumOf { it.getTotalScore() }
                    val totalMax = currentCourseGrades.size * 100.0
                    val totalPercent = if (totalMax > 0) ((totalEarned / totalMax) * 100).toInt() else 0

                    Surface(
                        color = Color.White.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "الإجمالي: $totalEarned ($totalPercent%)",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onOpenGrades,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("فتح مركز رصد درجات الدورة ⬅️", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }

        // Current Course Grades
        Text(
            text = "درجات الدورة الحالية (${currentCourseGrades.size} مواد)",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = DawamiNavy
        )

        if (currentCourseGrades.isEmpty()) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لم يتم رصد درجات للطالب في الدورة الحالية حتى الآن.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        } else {
            currentCourseGrades.forEach { grade ->
                GradeCardItem(grade = grade)
            }
        }

        // Previous / Transferred Course Grades (if any)
        if (previousCourseGrades.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "درجات الدورات السابقة / المنقولة (${previousCourseGrades.size})",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0284C7)
            )

            previousCourseGrades.forEach { grade ->
                GradeCardItem(grade = grade, isPreviousCourse = true)
            }
        }
    }
}

@Composable
private fun GradeCardItem(
    grade: StudentGrade,
    isPreviousCourse: Boolean = false
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (isPreviousCourse) Color(0xFFBAE6FD) else Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Default.Bookmark,
                        contentDescription = null,
                        tint = if (isPreviousCourse) Color(0xFF0284C7) else DawamiNavy,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = grade.subjectName.ifBlank { "المادة" },
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    when {
                        grade.isManualFinalGrading() -> {
                            Surface(
                                color = Color(0xFFF3E8FF),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "🎯 رصد نهائي يدوي",
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF7E22CE)
                                )
                            }
                        }
                        grade.isManualGrading() -> {
                            Surface(
                                color = Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "✍️ يدوي (تفصيلي)",
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFB45309)
                                )
                            }
                        }
                        else -> {
                            Surface(
                                color = Color(0xFFECFDF5),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "🤖 آلي (محسوب)",
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF047857)
                                )
                            }
                        }
                    }
                }

                val scoreTotal = grade.getTotalScore()
                val scoreColor = when {
                    scoreTotal >= 90 -> Color(0xFF10B981)
                    scoreTotal >= 75 -> Color(0xFF3B82F6)
                    scoreTotal >= 50 -> Color(0xFFF59E0B)
                    else -> Color(0xFFEF4444)
                }

                Surface(
                    color = scoreColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "$scoreTotal / 100",
                        color = scoreColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            if (isPreviousCourse && grade.courseName.isNotBlank()) {
                Text(
                    text = "منقولة من: ${grade.courseName}",
                    fontSize = 9.sp,
                    color = Color(0xFF0284C7),
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Scores breakdown or Manual Final notification
            if (grade.isManualFinalGrading()) {
                Surface(
                    color = Color(0xFFFAF5FF),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFE9D5FF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("🎯", fontSize = 12.sp)
                        Text(
                            text = "تم اعتماد الدرجة النهائية مباشرة (${grade.getManualFinalScore() ?: grade.getTotalScore()}) بقرار رصد يدوي نهائي مستقل للمادة.",
                            fontSize = 10.5.sp,
                            color = Color(0xFF6B21A8),
                            lineHeight = 15.sp
                        )
                    }
                }
            } else if (grade.isDiploma) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ScoreBadge(label = "حضور", score = grade.attendanceScore, max = 5)
                    ScoreBadge(label = "مشاركة", score = grade.participationScore, max = 5)
                    ScoreBadge(label = "تكاليف", score = grade.assignmentsScore, max = 10)
                    ScoreBadge(label = "مشاريع", score = grade.projectsScore, max = 20)
                    ScoreBadge(label = "نظري", score = grade.theoreticalExamScore, max = 20)
                    ScoreBadge(label = "عملي", score = grade.practicalExamScore, max = 40)
                }
            } else {
                val customScores = grade.getScoresMap()
                if (customScores.isNotEmpty()) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(customScores.entries.toList()) { entry ->
                            ScoreBadge(label = entry.key, score = entry.value, max = null)
                        }
                    }
                }
            }

            // Note if any
            val note = grade.getGradeNote()
            if (note.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "ملاحظة: $note",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// Badge displaying score with label and optional maximum value
@Composable
private fun ScoreBadge(
    label: String,
    score: Double,
    max: Int?
) {
    Surface(
        color = DawamiNavy.copy(alpha = 0.05f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            val scoreText = if (score % 1.0 == 0.0) score.toInt().toString() else score.toString()
            val maxText = if (max != null) "/$max" else ""
            Text(
                text = "$scoreText$maxText",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = DawamiNavy
            )
        }
    }
}

// ==========================================
// 4. VIOLATIONS TAB (المخالفات)
// ==========================================
@Composable
private fun StudentViolationsTab(
    violationsList: List<StudentViolation>,
    onAddViolation: () -> Unit,
    onShareViolation: (StudentViolation) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Header Row + Add Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "سجل المخالفات والتنبيهات (${violationsList.size})",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = DawamiNavy
            )

            Button(
                onClick = onAddViolation,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تسجيل مخالفة", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (violationsList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "السجل نظيف ومثالي! ✨",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF10B981)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "لا توجد أي مخالفات أو تنبيهات مسجلة على هذا الطالب.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(violationsList, key = { it.id }) { v ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = v.violationTitle,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFDC2626),
                                    modifier = Modifier.weight(1f)
                                )

                                IconButton(
                                    onClick = { onShareViolation(v) },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "مشاركة", tint = Color(0xFF25D366), modifier = Modifier.size(16.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "التاريخ: ${v.date} ${v.time}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                if (v.subjectName.isNotBlank()) {
                                    Text(
                                        text = "المادة: ${v.subjectName}",
                                        fontSize = 10.sp,
                                        color = DawamiNavy
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Surface(
                                color = Color(0xFFFEF2F2),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(
                                        text = "الإجراء المتخذ: ${v.actionTaken}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF991B1B)
                                    )
                                    if (v.notes.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "ملاحظات: ${v.notes}",
                                            fontSize = 10.sp,
                                            color = Color(0xFF7F1D1D)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. REPORTS TAB (التقارير والمشاركة)
// ==========================================
@Composable
private fun StudentReportsTab(
    student: Student,
    attendanceList: List<StudentAttendance>,
    gradesList: List<StudentGrade>,
    violationsList: List<StudentViolation>,
    context: Context,
    isCourseCompleted: Boolean = false
) {
    val totalSessions = attendanceList.size
    val presentCount = attendanceList.count { it.status == "حضور" }
    val lateCount = attendanceList.count { it.checkInDelayMinutes > 0 }
    val totalDelayMinutes = attendanceList.sumOf { it.checkInDelayMinutes }
    val absentCount = attendanceList.count { it.status == "غياب" }
    val leaveCount = attendanceList.count { it.status == "إجازة" || it.status == "عذر" }
    
    val attendanceRate = if (totalSessions > 0) {
        ((presentCount.toFloat() / totalSessions.toFloat()) * 100).toInt()
    } else {
        100
    }

    val currentGrades = gradesList.filter { it.courseId == student.courseId }
    val totalEarned = currentGrades.sumOf { it.getTotalScore() }
    val totalMax = currentGrades.size * 100.0
    val totalPercent = if (totalMax > 0) ((totalEarned / totalMax) * 100).toInt() else 0

    // Build the formatted comprehensive text report
    val reportText = remember(student, attendanceList, gradesList, violationsList) {
        val sb = StringBuilder()
        sb.append("📋 *تقرير المتابعة الشامل للطالب* 👤\n")
        sb.append("────────────────────\n")
        sb.append("▪️ *اسم الطالب:* ${student.name}\n")
        sb.append("▪️ *الدورة:* ${student.courseName}\n")
        val effectiveReportStatus = if (student.status == "خريج" || (isCourseCompleted && (student.status == "مستمر" || student.status.isBlank()))) "خريج 🎓" else student.status
        sb.append("▪️ *الحالة:* $effectiveReportStatus\n")
        if (student.phoneNumber.isNotBlank()) {
            sb.append("▪️ *الهاتف:* ${student.phoneNumber}\n")
        }
        sb.append("────────────────────\n")
        sb.append("📊 *ملخص الحضور والانضباط:*\n")
        sb.append("• إجمالي الجلسات: $totalSessions\n")
        sb.append("• أيام الحضور: $presentCount\n")
        sb.append("• أيام الغياب: $absentCount\n")
        sb.append("• مرات التأخير: $lateCount (إجمالي $totalDelayMinutes دقيقة)\n")
        sb.append("• الإجازات والأعذار: $leaveCount\n")
        sb.append("• نسبة الانضباط: $attendanceRate%\n")
        sb.append("────────────────────\n")
        if (currentGrades.isNotEmpty()) {
            sb.append("📝 *كشف الدرجات:*\n")
            currentGrades.forEach { g ->
                sb.append("• ${g.subjectName}: ${g.getTotalScore()} / 100\n")
            }
            sb.append("• *المجموع العام:* $totalEarned / $totalMax ($totalPercent%)\n")
            sb.append("────────────────────\n")
        }
        if (violationsList.isNotEmpty()) {
            sb.append("⚠️ *المخالفات والتنبيهات (${violationsList.size}):*\n")
            violationsList.forEachIndexed { idx, v ->
                sb.append("${idx + 1}. ${v.violationTitle} (${v.date}) - ${v.actionTaken}\n")
            }
            sb.append("────────────────────\n")
        }
        sb.append("💡 *ملاحظة:* تم استخراج هذا التقرير آلياً عبر نظام دوامي الذكي.\n")
        sb.append("مع تمنياتنا للطالب بمزيد من التوفيق والنجاح 🌟")
        sb.toString()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Preview Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "معاينة التقرير الشامل الجاهز للمشاركة",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )

                    IconButton(
                        onClick = {
                            try {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                clipboard?.setPrimaryClip(ClipData.newPlainText("Student 360 Report", reportText))
                                Toast.makeText(context, "تم نسخ التقرير إلى الحافظة بنجاح 📋", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "تعذر نسخ التقرير", Toast.LENGTH_SHORT).show()
                            }
                        }
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "نسخ التقرير", tint = DawamiNavy)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    color = MaterialTheme.colorScheme.background,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = reportText,
                        fontSize = 11.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        // Action Buttons
        Button(
            onClick = {
                shareStudentViaWhatsApp(
                    context = context,
                    phone = student.phoneNumber,
                    message = reportText
                )
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("إرسال التقرير الشامل عبر واتساب 💬", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
            onClick = {
                try {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        putExtra(Intent.EXTRA_TEXT, reportText)
                        type = "text/plain"
                    }
                    val shareIntent = Intent.createChooser(sendIntent, "مشاركة تقرير الطالب عبر")
                    context.startActivity(shareIntent)
                } catch (e: Exception) {
                    Toast.makeText(context, "تعذر فتح قائمة المشاركة", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = DawamiNavy),
            border = BorderStroke(1.dp, DawamiNavy),
            contentPadding = PaddingValues(vertical = 10.dp)
        ) {
            Icon(Icons.Default.Share, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("مشاركة عبر تطبيقات أخرى", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// Quick Add Violation Dialog
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickAddViolationDialog(
    student: Student,
    subjects: List<String>,
    courseId: Long,
    onDismiss: () -> Unit,
    onSave: (StudentViolation) -> Unit
) {
    val todayStr = remember { SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date()) }
    val currentTimeStr = remember { SimpleDateFormat("hh:mm a", Locale("ar")).format(Date()) }

    var selectedViolationTitle by remember { mutableStateOf(PRESET_VIOLATIONS.firstOrNull()?.first ?: "") }
    var selectedViolationType by remember { mutableStateOf(PRESET_VIOLATIONS.firstOrNull()?.second ?: "أجهزة ومعمل") }
    var selectedAction by remember { mutableStateOf(PRESET_ACTIONS.firstOrNull() ?: "") }
    var selectedSubject by remember { mutableStateOf(subjects.firstOrNull() ?: "") }
    var customNotes by remember { mutableStateOf("") }

    var isViolationDropdownExpanded by remember { mutableStateOf(false) }
    var isActionDropdownExpanded by remember { mutableStateOf(false) }
    var isSubjectDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "تسجيل مخالفة جديدة للطالب 📋",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color(0xFFDC2626)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "الطالب: ${student.name}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = DawamiNavy
                )

                // Subject Selector
                if (subjects.isNotEmpty()) {
                    ExposedDropdownMenuBox(
                        expanded = isSubjectDropdownExpanded,
                        onExpandedChange = { isSubjectDropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedSubject.ifBlank { "اختر المادة (اختياري)" },
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("المادة التدريبية") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSubjectDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = isSubjectDropdownExpanded,
                            onDismissRequest = { isSubjectDropdownExpanded = false }
                        ) {
                            subjects.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s, fontSize = 11.sp) },
                                    onClick = {
                                        selectedSubject = s
                                        isSubjectDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Preset Violation Dropdown
                ExposedDropdownMenuBox(
                    expanded = isViolationDropdownExpanded,
                    onExpandedChange = { isViolationDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedViolationTitle,
                        onValueChange = { selectedViolationTitle = it },
                        label = { Text("نوع المخالفة المرصودة") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isViolationDropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = isViolationDropdownExpanded,
                        onDismissRequest = { isViolationDropdownExpanded = false }
                    ) {
                        PRESET_VIOLATIONS.forEach { (vTitle, vType) ->
                            DropdownMenuItem(
                                text = { Text(vTitle, fontSize = 11.sp) },
                                onClick = {
                                    selectedViolationTitle = vTitle
                                    selectedViolationType = vType
                                    isViolationDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Action Taken Dropdown
                ExposedDropdownMenuBox(
                    expanded = isActionDropdownExpanded,
                    onExpandedChange = { isActionDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedAction,
                        onValueChange = { selectedAction = it },
                        label = { Text("الإجراء المتخذ") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isActionDropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = isActionDropdownExpanded,
                        onDismissRequest = { isActionDropdownExpanded = false }
                    ) {
                        PRESET_ACTIONS.forEach { act ->
                            DropdownMenuItem(
                                text = { Text(act, fontSize = 11.sp) },
                                onClick = {
                                    selectedAction = act
                                    isActionDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Custom Notes
                OutlinedTextField(
                    value = customNotes,
                    onValueChange = { customNotes = it },
                    label = { Text("ملاحظات إضافية (اختياري)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedViolationTitle.isNotBlank() && selectedAction.isNotBlank()) {
                        val violation = StudentViolation(
                            courseId = courseId,
                            subjectName = selectedSubject,
                            studentId = student.id.toLong(),
                            studentName = student.name,
                            studentPhone = student.phoneNumber,
                            violationType = selectedViolationType,
                            violationTitle = selectedViolationTitle,
                            actionTaken = selectedAction,
                            date = todayStr,
                            time = currentTimeStr,
                            notes = customNotes
                        )
                        onSave(violation)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("حفظ المخالفة", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    )
}

fun shareStudentViaWhatsApp(context: Context, phone: String, message: String) {
    try {
        var cleanNumber = phone.replace("+", "").replace("-", "").replace(" ", "").trim()
        if (cleanNumber.startsWith("00")) {
            cleanNumber = cleanNumber.substring(2)
        }
        if (!cleanNumber.startsWith("967") && cleanNumber.startsWith("7") && cleanNumber.length == 9) {
            cleanNumber = "967$cleanNumber"
        }

        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            clipboard?.setPrimaryClip(ClipData.newPlainText("Student Message", message))
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val encodedText = URLEncoder.encode(message, "UTF-8")
        val uriStr = if (cleanNumber.isNotBlank()) {
            "https://api.whatsapp.com/send?phone=$cleanNumber&text=$encodedText"
        } else {
            "https://api.whatsapp.com/send?text=$encodedText"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriStr))
        context.startActivity(intent)
        Toast.makeText(context, "تم توجيه الرسالة لواتساب 💬", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                putExtra(Intent.EXTRA_TEXT, message)
                type = "text/plain"
            }
            context.startActivity(Intent.createChooser(sendIntent, "مشاركة عبر"))
        } catch (ex: Exception) {
            Toast.makeText(context, "تعذر فتح تطبيق المشاركة", Toast.LENGTH_SHORT).show()
        }
    }
}
