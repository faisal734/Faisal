package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.data.entity.AppActivityLog
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppAdminViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivityLogsScreen(
    viewModel: MainViewModel,
    adminViewModel: AppAdminViewModel? = null,
    showMainLayout: Boolean = true
) {
    val context = LocalContext.current
    val isDark by viewModel.isDarkTheme.collectAsState()

    val courses by viewModel.dbCourses.collectAsState()
    val activityLogs by (adminViewModel?.allActivityLogs ?: viewModel.dbActivityLogs).collectAsState()
    val transactions by (adminViewModel?.allTrainerTransactions ?: viewModel.dbTrainerTransactions).collectAsState()

    BackHandler {
        viewModel.navigateTo(Screen.Selection)
    }

    val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val todayDate = remember { sdf.format(Date()) }

    // Core Filter States
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("ALL") } // ALL, TODAY, DELETIONS, ATTENDANCE, GRADES, FINANCIAL, CURRICULUM, SYSTEM
    var selectedActionFilter by remember { mutableStateOf("ALL") } // ALL, CREATE, UPDATE, DELETE, RECORD, WIPE
    var selectedDateFilter by remember { mutableStateOf("ALL") } // ALL, TODAY, YESTERDAY, THIS_WEEK, THIS_MONTH
    var selectedCourseFilterId by remember { mutableStateOf<Long?>(null) }

    // UI Dialog States
    var showFilterDialog by remember { mutableStateOf(false) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var logToDelete by remember { mutableStateOf<AppActivityLog?>(null) }
    var selectedLogForDetail by remember { mutableStateOf<AppActivityLog?>(null) }

    val coroutineScope = rememberCoroutineScope()
    // PDF Export launcher
    val pdfActivityLogLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            if (activityLogs.isEmpty()) {
                Toast.makeText(context, "لا توجد حركات في السجل لتصديرها", Toast.LENGTH_SHORT).show()
            } else {
                coroutineScope.launch(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                            com.example.ui.pdf.PdfReportHelper.exportActivityLogsToPdf(
                                viewModel = viewModel,
                                logs = activityLogs,
                                outputStream = outputStream
                            )
                        }
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "تم تصدير تقرير سجل الحركات PDF بنجاح 📄", Toast.LENGTH_LONG).show()
                        }
                        if (adminViewModel != null) {
                            adminViewModel.logActivity(
                                category = "SYSTEM",
                                actionType = "CREATE",
                                title = "تصدير سجل الحركات PDF",
                                description = "تم تصدير وحفظ تقرير سجل الحركات والتدقيق كملف PDF"
                            )
                        } else {
                            viewModel.logActivity(
                                category = "SYSTEM",
                                actionType = "CREATE",
                                title = "تصدير سجل الحركات PDF",
                                description = "تم تصدير وحفظ تقرير سجل الحركات والتدقيق كملف PDF"
                            )
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "فشل تصدير ملف PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
    }

    // Color definitions
    val bgColor = if (isDark) DarkBackground else Color(0xFFF8FAFC)
    val cardBg = if (isDark) DarkSurface else Color.White
    val cardBorder = if (isDark) DarkOutline else Color(0xFFE2E8F0)
    val textPrimary = if (isDark) DarkOnSurface else DawamiNavy
    val textSecondary = if (isDark) DarkOnSurfaceVariant else Color(0xFF64748B)

    // Compute Filtered Logs
    val filteredLogs = remember(
        activityLogs,
        searchQuery,
        selectedCategoryFilter,
        selectedActionFilter,
        selectedDateFilter,
        selectedCourseFilterId
    ) {
        val calendar = Calendar.getInstance()
        val todayStr = sdf.format(calendar.time)

        calendar.add(Calendar.DAY_OF_YEAR, -1)
        val yesterdayStr = sdf.format(calendar.time)

        calendar.time = Date()
        calendar.add(Calendar.DAY_OF_YEAR, -7)
        val weekAgoStr = sdf.format(calendar.time)

        calendar.time = Date()
        calendar.add(Calendar.MONTH, -1)
        val monthAgoStr = sdf.format(calendar.time)

        activityLogs.filter { log ->
            val isDeletion = log.actionType.equals("DELETE", ignoreCase = true) ||
                    log.actionType.equals("WIPE", ignoreCase = true) ||
                    log.title.contains("حذف") ||
                    log.description.contains("حذف") ||
                    log.description.contains("مسح")

            val categoryMatches = when (selectedCategoryFilter) {
                "ALL" -> true
                "TODAY" -> log.dateStr == todayStr
                "DELETIONS" -> isDeletion
                "ATTENDANCE" -> log.category.equals("ATTENDANCE", ignoreCase = true) || log.category.contains("حضور")
                "GRADES" -> log.category.equals("GRADES", ignoreCase = true) || log.category.contains("درجات")
                "FINANCIAL" -> log.category.equals("FINANCIAL", ignoreCase = true) || log.category.contains("مالية")
                "CURRICULUM" -> log.category.equals("CURRICULUM", ignoreCase = true) || log.category.equals("SUBJECTS", ignoreCase = true) || log.category.equals("COURSES", ignoreCase = true) || log.category.contains("مادة") || log.category.contains("دورة")
                "SYSTEM" -> log.category.equals("SYSTEM", ignoreCase = true) || log.category.contains("نظام")
                else -> log.category.equals(selectedCategoryFilter, ignoreCase = true)
            }

            val actionMatches = when (selectedActionFilter) {
                "ALL" -> true
                "DELETE" -> isDeletion
                "CREATE" -> log.actionType.equals("CREATE", ignoreCase = true) || log.actionType.contains("إضافة")
                "UPDATE" -> log.actionType.equals("UPDATE", ignoreCase = true) || log.actionType.contains("تعديل")
                "RECORD" -> log.actionType.equals("RECORD", ignoreCase = true) || log.actionType.contains("رصد")
                "WIPE" -> log.actionType.equals("WIPE", ignoreCase = true) || log.actionType.contains("تفريغ")
                else -> log.actionType.equals(selectedActionFilter, ignoreCase = true)
            }

            val dateMatches = when (selectedDateFilter) {
                "TODAY" -> log.dateStr == todayStr
                "YESTERDAY" -> log.dateStr == yesterdayStr
                "THIS_WEEK" -> log.dateStr >= weekAgoStr
                "THIS_MONTH" -> log.dateStr >= monthAgoStr
                else -> true
            }

            val courseMatches = selectedCourseFilterId == null || log.relatedId == selectedCourseFilterId
            val queryMatches = searchQuery.isBlank() ||
                    log.title.contains(searchQuery, ignoreCase = true) ||
                    log.description.contains(searchQuery, ignoreCase = true) ||
                    log.dateStr.contains(searchQuery, ignoreCase = true) ||
                    log.timeStr.contains(searchQuery, ignoreCase = true)

            categoryMatches && actionMatches && dateMatches && courseMatches && queryMatches
        }.sortedByDescending { it.timestamp }
    }

    // Stats calculations
    val todayCount = remember(activityLogs) { activityLogs.count { it.dateStr == todayDate } }
    val deletionCount = remember(activityLogs) {
        activityLogs.count {
            it.actionType.equals("DELETE", ignoreCase = true) ||
                    it.actionType.equals("WIPE", ignoreCase = true) ||
                    it.title.contains("حذف") ||
                    it.description.contains("حذف")
        }
    }
    val attendanceGradesCount = remember(activityLogs) {
        activityLogs.count {
            it.category.equals("ATTENDANCE", ignoreCase = true) ||
                    it.category.equals("GRADES", ignoreCase = true)
        }
    }

    // Group logs by date
    val groupedLogsByDate = remember(filteredLogs) {
        filteredLogs.groupBy { it.dateStr }
    }

    val activeFiltersCount = (if (selectedCategoryFilter != "ALL") 1 else 0) +
            (if (selectedActionFilter != "ALL") 1 else 0) +
            (if (selectedDateFilter != "ALL") 1 else 0) +
            (if (selectedCourseFilterId != null) 1 else 0) +
            (if (searchQuery.isNotBlank()) 1 else 0)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MainLayout(viewModel = viewModel, showScaffold = showMainLayout) { innerPadding ->
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                color = bgColor
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // 1. Header & Actions
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = cardBg),
                            border = BorderStroke(1.dp, cardBorder)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (isDark) DawamiGold.copy(alpha = 0.15f) else DawamiNavy.copy(alpha = 0.1f),
                                            border = BorderStroke(1.dp, if (isDark) DawamiGold.copy(alpha = 0.5f) else DawamiNavy.copy(alpha = 0.2f))
                                        ) {
                                            Box(modifier = Modifier.padding(8.dp)) {
                                                Icon(
                                                    imageVector = Icons.Default.ManageHistory,
                                                    contentDescription = null,
                                                    tint = if (isDark) DawamiGold else DawamiNavy,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }

                                        Column {
                                            Text(
                                                text = "سجل العمليات والأنشطة",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = textPrimary
                                            )
                                            Text(
                                                text = "توثيق شامل وفوري لكافة حركات النظام",
                                                fontSize = 11.sp,
                                                color = textSecondary
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isDark) DarkSurfaceVariant else Color(0xFFF1F5F9),
                                        border = BorderStroke(1.dp, cardBorder)
                                    ) {
                                        Text(
                                            text = "${activityLogs.size} حركة",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDark) DawamiGold else DawamiNavy,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                HorizontalDivider(color = cardBorder)

                                // Quick Action Buttons
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            if (activityLogs.isEmpty()) {
                                                Toast.makeText(context, "لا توجد حركات في السجل لتصديرها", Toast.LENGTH_SHORT).show()
                                            } else if (viewModel.trainerBaseDirUri.value.isNotEmpty()) {
                                                coroutineScope.launch(Dispatchers.IO) {
                                                    val success = viewModel.savePdfReportToReportsFolder(context, "سجل_الحركات_والتدقيق.pdf") { outputStream ->
                                                        com.example.ui.pdf.PdfReportHelper.exportActivityLogsToPdf(
                                                            viewModel = viewModel,
                                                            logs = activityLogs,
                                                            outputStream = outputStream
                                                        )
                                                    }
                                                    withContext(Dispatchers.Main) {
                                                        if (success) {
                                                            Toast.makeText(context, "تم حفظ تقرير سجل الحركات تلقائياً في مجلد Reports بنجاح! 📄⚡", Toast.LENGTH_LONG).show()
                                                            val logTitle = "تصدير سجل الحركات PDF 📄"
                                                            val logDesc = "تم حفظ تقرير سجل الحركات والتدقيق كملف PDF في مجلد Reports بنجاح"
                                                            if (adminViewModel != null) {
                                                                adminViewModel.logActivity("SYSTEM", "CREATE", logTitle, logDesc)
                                                            } else {
                                                                viewModel.logActivity("SYSTEM", "CREATE", logTitle, logDesc)
                                                            }
                                                        } else {
                                                            pdfActivityLogLauncher.launch("سجل_الحركات_والتدقيق.pdf")
                                                        }
                                                    }
                                                }
                                            } else {
                                                pdfActivityLogLauncher.launch("سجل_الحركات_والتدقيق.pdf")
                                            }
                                        },
                                        modifier = Modifier.weight(1f).height(36.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp)
                                    ) {
                                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تصدير PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            if (filteredLogs.isEmpty()) {
                                                Toast.makeText(context, "لا توجد حركات لمشاركتها", Toast.LENGTH_SHORT).show()
                                            } else {
                                                val shareText = buildString {
                                                    appendLine("📋 تقرير سجل الحركات والتدقيق")
                                                    appendLine("📅 التاريخ: $todayDate")
                                                    appendLine("🔢 عدد الحركات: ${filteredLogs.size}")
                                                    appendLine("----------------------------------------")
                                                    filteredLogs.take(50).forEachIndexed { idx, log ->
                                                        appendLine("${idx + 1}. [${log.dateStr} ${log.timeStr}] [${log.actionType}] [${log.category}]")
                                                        appendLine("   - ${log.title}")
                                                        if (log.description.isNotBlank()) {
                                                            appendLine("   - ${log.description}")
                                                        }
                                                    }
                                                    if (filteredLogs.size > 50) {
                                                        appendLine("... وغيرها (${filteredLogs.size - 50} حركة أخرى)")
                                                    }
                                                }
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(Intent.EXTRA_TEXT, shareText)
                                                    putExtra(Intent.EXTRA_SUBJECT, "سجل الحركات - دوامي")
                                                }
                                                context.startActivity(Intent.createChooser(intent, "مشاركة سجل الحركات"))
                                            }
                                        },
                                        modifier = Modifier.weight(1f).height(36.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, if (isDark) DarkOutline else DawamiTeal),
                                        contentPadding = PaddingValues(horizontal = 8.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, tint = if (isDark) DawamiGold else DawamiNavy, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("مشاركة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                                    }

                                    IconButton(
                                        onClick = { showClearConfirmDialog = true },
                                        modifier = Modifier.size(36.dp),
                                        colors = IconButtonDefaults.iconButtonColors(
                                            containerColor = Color(0xFFDC2626).copy(alpha = 0.12f)
                                        )
                                    ) {
                                        Icon(
                                            Icons.Default.DeleteSweep,
                                            contentDescription = "مسح السجل",
                                            tint = Color(0xFFDC2626),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 2. Compact 4-Metric Strip
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            LogMetricCard(
                                modifier = Modifier.weight(1f),
                                title = "الكل",
                                count = "${activityLogs.size}",
                                icon = Icons.Default.AllInclusive,
                                isSelected = selectedCategoryFilter == "ALL" && selectedDateFilter == "ALL",
                                isDark = isDark,
                                activeColor = DawamiNavy,
                                onClick = {
                                    selectedCategoryFilter = "ALL"
                                    selectedDateFilter = "ALL"
                                }
                            )

                            LogMetricCard(
                                modifier = Modifier.weight(1f),
                                title = "اليوم",
                                count = "$todayCount",
                                icon = Icons.Default.Today,
                                isSelected = selectedCategoryFilter == "TODAY" || selectedDateFilter == "TODAY",
                                isDark = isDark,
                                activeColor = DawamiTeal,
                                onClick = {
                                    selectedCategoryFilter = if (selectedCategoryFilter == "TODAY") "ALL" else "TODAY"
                                }
                            )

                            LogMetricCard(
                                modifier = Modifier.weight(1f),
                                title = "المحذوفات",
                                count = "$deletionCount",
                                icon = Icons.Default.DeleteOutline,
                                isSelected = selectedCategoryFilter == "DELETIONS",
                                isDark = isDark,
                                activeColor = Color(0xFFDC2626),
                                onClick = {
                                    selectedCategoryFilter = if (selectedCategoryFilter == "DELETIONS") "ALL" else "DELETIONS"
                                }
                            )

                            LogMetricCard(
                                modifier = Modifier.weight(1f),
                                title = "حضور ودرجات",
                                count = "$attendanceGradesCount",
                                icon = Icons.Default.School,
                                isSelected = selectedCategoryFilter == "ATTENDANCE" || selectedCategoryFilter == "GRADES",
                                isDark = isDark,
                                activeColor = Color(0xFFD97706),
                                onClick = {
                                    selectedCategoryFilter = if (selectedCategoryFilter == "ATTENDANCE") "ALL" else "ATTENDANCE"
                                }
                            )
                        }
                    }

                    // 3. Clean Search & Filter Pills
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = cardBg),
                            border = BorderStroke(1.dp, cardBorder)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Search bar + Advanced Filter button
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = searchQuery,
                                        onValueChange = { searchQuery = it },
                                        placeholder = { Text("بحث في السجل: اسم، دورة، بيان...", fontSize = 11.5.sp, color = textSecondary) },
                                        leadingIcon = {
                                            Icon(
                                                Icons.Default.Search,
                                                contentDescription = null,
                                                tint = if (isDark) DawamiGold else DawamiNavy,
                                                modifier = Modifier.size(17.dp)
                                            )
                                        },
                                        trailingIcon = {
                                            if (searchQuery.isNotEmpty()) {
                                                IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                                    Icon(Icons.Default.Close, contentDescription = "مسح", modifier = Modifier.size(15.dp))
                                                }
                                            }
                                        },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f).height(46.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = DawamiTeal,
                                            unfocusedBorderColor = if (isDark) DarkOutline else Color(0xFFCBD5E1),
                                            focusedContainerColor = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC),
                                            unfocusedContainerColor = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC)
                                        )
                                    )

                                    FilledTonalButton(
                                        onClick = { showFilterDialog = true },
                                        modifier = Modifier.height(46.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.filledTonalButtonColors(
                                            containerColor = if (activeFiltersCount > 0) DawamiNavy.copy(alpha = 0.2f) else (if (isDark) DarkSurfaceVariant else Color(0xFFF1F5F9))
                                        ),
                                        contentPadding = PaddingValues(horizontal = 10.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Tune,
                                            contentDescription = "تصفية متقدمة",
                                            tint = if (isDark) DawamiGold else DawamiNavy,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        if (activeFiltersCount > 0) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Surface(
                                                shape = CircleShape,
                                                color = DawamiGold,
                                                modifier = Modifier.size(16.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text("$activeFiltersCount", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                                }
                                            }
                                        }
                                    }
                                }

                                // Quick Category Tabs
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    QuickFilterChip(
                                        label = "الكل",
                                        isSelected = selectedCategoryFilter == "ALL",
                                        isDark = isDark,
                                        onClick = { selectedCategoryFilter = "ALL" }
                                    )
                                    QuickFilterChip(
                                        label = "اليوم",
                                        isSelected = selectedCategoryFilter == "TODAY",
                                        isDark = isDark,
                                        onClick = { selectedCategoryFilter = "TODAY" }
                                    )
                                    QuickFilterChip(
                                        label = "المحذوفات 🗑️",
                                        isSelected = selectedCategoryFilter == "DELETIONS",
                                        isDark = isDark,
                                        activeColor = Color(0xFFDC2626),
                                        onClick = { selectedCategoryFilter = "DELETIONS" }
                                    )
                                    QuickFilterChip(
                                        label = "الحضور 👥",
                                        isSelected = selectedCategoryFilter == "ATTENDANCE",
                                        isDark = isDark,
                                        onClick = { selectedCategoryFilter = "ATTENDANCE" }
                                    )
                                    QuickFilterChip(
                                        label = "الدرجات 📝",
                                        isSelected = selectedCategoryFilter == "GRADES",
                                        isDark = isDark,
                                        onClick = { selectedCategoryFilter = "GRADES" }
                                    )
                                    QuickFilterChip(
                                        label = "المالية 💰",
                                        isSelected = selectedCategoryFilter == "FINANCIAL",
                                        isDark = isDark,
                                        onClick = { selectedCategoryFilter = "FINANCIAL" }
                                    )
                                    QuickFilterChip(
                                        label = "الأكاديمي 📚",
                                        isSelected = selectedCategoryFilter == "CURRICULUM",
                                        isDark = isDark,
                                        onClick = { selectedCategoryFilter = "CURRICULUM" }
                                    )
                                    QuickFilterChip(
                                        label = "النظام ⚙️",
                                        isSelected = selectedCategoryFilter == "SYSTEM",
                                        isDark = isDark,
                                        onClick = { selectedCategoryFilter = "SYSTEM" }
                                    )
                                }
                            }
                        }
                    }

                    // 4. Section Title & Reset Filters
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "الجدول الزمني للعمليات (${filteredLogs.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = textPrimary
                            )

                            if (activeFiltersCount > 0) {
                                TextButton(
                                    onClick = {
                                        searchQuery = ""
                                        selectedCategoryFilter = "ALL"
                                        selectedActionFilter = "ALL"
                                        selectedDateFilter = "ALL"
                                        selectedCourseFilterId = null
                                    },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(13.dp), tint = if (isDark) DawamiGold else DawamiNavy)
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("إعادة ضبط الفلاتر", fontSize = 10.5.sp, color = if (isDark) DawamiGold else DawamiNavy, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // 5. Timeline Stream with Daily Grouping
                    if (filteredLogs.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = cardBg),
                                border = BorderStroke(1.dp, cardBorder)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isDark) DarkSurfaceVariant else Color(0xFFF1F5F9),
                                        modifier = Modifier.size(52.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.HistoryToggleOff,
                                                contentDescription = null,
                                                tint = if (isDark) DawamiGold else DawamiNavy,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }
                                    }

                                    Text(
                                        text = if (searchQuery.isNotBlank() || activeFiltersCount > 0)
                                            "لا توجد حركات مطابقة للبحث أو التصفية"
                                        else
                                            "لا توجد أي حركات مسجلة حالياً",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = textPrimary,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "يتم توثيق كافة العمليات (حضور، درجات، تعديل، حذف، وسندات مالية) تلقائياً هنا فور إجرائها.",
                                        fontSize = 11.sp,
                                        color = textSecondary,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    } else {
                        groupedLogsByDate.forEach { (dateStr, logsForDate) ->
                            // Date Group Header
                            item(key = "header_$dateStr") {
                                val displayDate = when (dateStr) {
                                    todayDate -> "اليوم • $dateStr"
                                    else -> dateStr
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (dateStr == todayDate) {
                                        if (isDark) DawamiGold.copy(alpha = 0.15f) else DawamiNavy.copy(alpha = 0.08f)
                                    } else {
                                        if (isDark) DarkSurfaceVariant else Color(0xFFF1F5F9)
                                    },
                                    border = BorderStroke(
                                        1.dp,
                                        if (dateStr == todayDate) {
                                            if (isDark) DawamiGold.copy(alpha = 0.4f) else DawamiNavy.copy(alpha = 0.2f)
                                        } else cardBorder
                                    ),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 5.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CalendarToday,
                                                contentDescription = null,
                                                tint = if (dateStr == todayDate) (if (isDark) DawamiGold else DawamiNavy) else textSecondary,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Text(
                                                text = displayDate,
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (dateStr == todayDate) (if (isDark) DawamiGold else DawamiNavy) else textPrimary
                                            )
                                        }

                                        Text(
                                            text = "${logsForDate.size} حركة",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = textSecondary
                                        )
                                    }
                                }
                            }

                            // Items for Date
                            items(logsForDate, key = { it.id }) { log ->
                                CleanTimelineItem(
                                    log = log,
                                    isDark = isDark,
                                    onClick = { selectedLogForDetail = log },
                                    onDelete = { logToDelete = log }
                                )
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }

    // 6. Advanced Filter Dialog
    if (showFilterDialog) {
        var tempCategory by remember { mutableStateOf(selectedCategoryFilter) }
        var tempAction by remember { mutableStateOf(selectedActionFilter) }
        var tempDate by remember { mutableStateOf(selectedDateFilter) }
        var tempCourseId by remember { mutableStateOf(selectedCourseFilterId) }

        AlertDialog(
            onDismissRequest = { showFilterDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.FilterList, contentDescription = null, tint = if (isDark) DawamiGold else DawamiNavy)
                    Text("تصفية سجل الحركات المتقدمة", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = textPrimary)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Date Filter Range
                    Text("النطاق الزمني:", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = textPrimary)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            "ALL" to "الكل",
                            "TODAY" to "اليوم",
                            "YESTERDAY" to "أمس",
                            "THIS_WEEK" to "هذا الأسبوع",
                            "THIS_MONTH" to "هذا الشهر"
                        ).forEach { (key, label) ->
                            FilterChip(
                                selected = tempDate == key,
                                onClick = { tempDate = key },
                                label = { Text(label, fontSize = 10.5.sp) }
                            )
                        }
                    }

                    HorizontalDivider(color = cardBorder)

                    // Action Type
                    Text("نوع الإجراء:", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = textPrimary)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            "ALL" to "جميع الإجراءات",
                            "CREATE" to "إضافة",
                            "UPDATE" to "تعديل",
                            "DELETE" to "حذف",
                            "RECORD" to "رصد"
                        ).forEach { (key, label) ->
                            FilterChip(
                                selected = tempAction == key,
                                onClick = { tempAction = key },
                                label = { Text(label, fontSize = 10.5.sp) }
                            )
                        }
                    }

                    HorizontalDivider(color = cardBorder)

                    // Course Target
                    Text("تحديد الدورة التدريبية:", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = textPrimary)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        FilterChip(
                            selected = tempCourseId == null,
                            onClick = { tempCourseId = null },
                            label = { Text("جميع الدورات", fontSize = 10.5.sp) }
                        )
                        courses.forEach { c ->
                            FilterChip(
                                selected = tempCourseId == c.id.toLong(),
                                onClick = { tempCourseId = c.id.toLong() },
                                label = { Text(c.name, fontSize = 10.5.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedCategoryFilter = tempCategory
                        selectedActionFilter = tempAction
                        selectedDateFilter = tempDate
                        selectedCourseFilterId = tempCourseId
                        showFilterDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("تطبيق الفلاتر", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showFilterDialog = false }) {
                    Text("إلغاء", color = textSecondary)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = cardBg
        )
    }

    // 7. Clear All Confirmation Dialog
    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.WarningAmber, contentDescription = null, tint = Color(0xFFDC2626))
                    Text("تفريغ ومسح سجل الحركات", fontWeight = FontWeight.Bold, color = Color(0xFFDC2626), fontSize = 14.sp)
                }
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في مسح كافة الحركات من السجل؟ لا يمكن التراجع عن هذه الخطوة بعد التنفيذ.",
                    fontSize = 12.sp,
                    color = textSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (adminViewModel != null) {
                            adminViewModel.deleteAllActivityLogs()
                        } else {
                            viewModel.deleteAllActivityLogs()
                        }
                        Toast.makeText(context, "تم مسح وتفريغ سجل الحركات بنجاح 🧹", Toast.LENGTH_SHORT).show()
                        showClearConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("تأكيد المسح", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmDialog = false }) {
                    Text("إلغاء", color = textSecondary)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = cardBg
        )
    }

    // 8. Delete Single Log Dialog
    if (logToDelete != null) {
        val target = logToDelete!!
        AlertDialog(
            onDismissRequest = { logToDelete = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = Color(0xFFDC2626))
                    Text("حذف حركة من السجل", fontWeight = FontWeight.Bold, color = Color(0xFFDC2626), fontSize = 13.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("هل تريد حذف هذه الحركة المحددة من السجل؟", fontSize = 11.5.sp, color = textSecondary)
                    Text("العنوان: ${target.title}", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = textPrimary)
                    Text("التاريخ: ${target.dateStr} ${target.timeStr}", fontSize = 10.5.sp, color = textSecondary)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (adminViewModel != null) {
                            adminViewModel.deleteActivityLog(target)
                        } else {
                            viewModel.deleteActivityLog(target)
                        }
                        Toast.makeText(context, "تم حذف الحركة من السجل 🗑️", Toast.LENGTH_SHORT).show()
                        logToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("حذف", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { logToDelete = null }) {
                    Text("إلغاء", color = textSecondary)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = cardBg
        )
    }

    // 9. Detailed View Dialog
    if (selectedLogForDetail != null) {
        val log = selectedLogForDetail!!
        AlertDialog(
            onDismissRequest = { selectedLogForDetail = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = if (isDark) DawamiGold else DawamiNavy
                    )
                    Text("تفاصيل الحركة والتوثيق", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = textPrimary)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isDark) DarkSurfaceVariant else Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, cardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = log.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = textPrimary
                            )

                            if (log.description.isNotBlank()) {
                                HorizontalDivider(color = cardBorder)
                                Text(
                                    text = log.description,
                                    fontSize = 11.5.sp,
                                    color = textSecondary
                                )
                            }
                        }
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        DetailRow("التصنيف:", log.category, textSecondary, textPrimary)
                        DetailRow("نوع الإجراء:", log.actionType, textSecondary, DawamiTeal)
                        DetailRow("التاريخ والوقت:", "${log.dateStr} | ${log.timeStr}", textSecondary, textSecondary)
                        if (log.relatedId != null && log.relatedId > 0) {
                            DetailRow("المعرف المرجعي:", "#${log.relatedId}", textSecondary, textSecondary)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("سجل الحركة", "${log.title}\n${log.description}\nالتاريخ: ${log.dateStr} ${log.timeStr}")
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "تم نسخ تفاصيل الحركة 📋", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نسخ التفاصيل", fontSize = 11.sp, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedLogForDetail = null }) {
                    Text("إغلاق", color = textSecondary)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = cardBg
        )
    }
}

@Composable
private fun DetailRow(label: String, value: String, labelColor: Color, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 11.sp, color = labelColor)
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = valueColor)
    }
}

@Composable
private fun LogMetricCard(
    modifier: Modifier = Modifier,
    title: String,
    count: String,
    icon: ImageVector,
    isSelected: Boolean,
    isDark: Boolean,
    activeColor: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) {
            if (isDark) activeColor.copy(alpha = 0.2f) else activeColor.copy(alpha = 0.1f)
        } else {
            if (isDark) DarkSurface else Color.White
        },
        border = BorderStroke(
            if (isSelected) 1.5.dp else 1.dp,
            if (isSelected) activeColor else (if (isDark) DarkOutline else Color(0xFFE2E8F0))
        )
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) activeColor else (if (isDark) DawamiGold else activeColor),
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = count,
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isSelected) activeColor else (if (isDark) DarkOnSurface else activeColor)
            )
            Text(
                text = title,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) activeColor else (if (isDark) DarkOnSurfaceVariant else Color(0xFF64748B)),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun QuickFilterChip(
    label: String,
    isSelected: Boolean,
    isDark: Boolean,
    activeColor: Color? = null,
    onClick: () -> Unit
) {
    val selectedColor = activeColor ?: DawamiNavy
    Surface(
        modifier = Modifier.clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) {
            selectedColor
        } else {
            if (isDark) DarkSurfaceVariant else Color(0xFFF1F5F9)
        },
        border = BorderStroke(
            1.dp,
            if (isSelected) selectedColor else (if (isDark) DarkOutline else Color(0xFFCBD5E1))
        )
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else (if (isDark) DarkOnSurface else Color(0xFF334155)),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun CleanTimelineItem(
    log: AppActivityLog,
    isDark: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val isDeletion = log.actionType.equals("DELETE", ignoreCase = true) ||
            log.actionType.equals("WIPE", ignoreCase = true) ||
            log.title.contains("حذف") ||
            log.description.contains("حذف") ||
            log.description.contains("مسح")

    val (icon, iconColor) = when {
        isDeletion -> Icons.Default.DeleteOutline to Color(0xFFDC2626)
        log.category.equals("ATTENDANCE", ignoreCase = true) || log.category.contains("حضور") -> Icons.Default.CheckCircleOutline to DawamiTeal
        log.category.equals("GRADES", ignoreCase = true) || log.category.contains("درج") -> Icons.Default.FactCheck to Color(0xFF4338CA)
        log.category.equals("FINANCIAL", ignoreCase = true) || log.category.contains("مال") -> Icons.Default.AttachMoney to Color(0xFFD97706)
        log.actionType.equals("UPDATE", ignoreCase = true) || log.actionType.contains("تعديل") -> Icons.Default.EditNote to Color(0xFF0284C7)
        log.actionType.equals("CREATE", ignoreCase = true) || log.actionType.contains("إضافة") -> Icons.Default.AddCircleOutline to Color(0xFF16A34A)
        else -> Icons.Default.History to (if (isDark) DawamiGold else DawamiNavy)
    }

    val cardBg = if (isDark) DarkSurface else Color.White
    val cardBorder = if (isDark) DarkOutline else Color(0xFFE2E8F0)
    val textPrimary = if (isDark) DarkOnSurface else DawamiNavy
    val textSecondary = if (isDark) DarkOnSurfaceVariant else Color(0xFF64748B)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = BorderStroke(1.dp, cardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Action Icon Badge
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = iconColor.copy(alpha = if (isDark) 0.2f else 0.12f),
                border = BorderStroke(1.dp, iconColor.copy(alpha = 0.3f)),
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Text Content
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = log.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    Text(
                        text = log.timeStr,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = textSecondary
                    )
                }

                if (log.description.isNotBlank()) {
                    Text(
                        text = log.description,
                        fontSize = 10.5.sp,
                        color = textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Quick Delete Button
            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(26.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "حذف الحركة",
                    tint = if (isDark) Color(0xFF64748B) else Color(0xFFCBD5E1),
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}
