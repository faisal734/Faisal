package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

private data class DrawerItem(
    val title: String,
    val subtitle: String = "",
    val icon: ImageVector,
    val targetScreen: Screen? = null,
    val customAction: (() -> Unit)? = null,
    val badge: String? = null,
    val badgeColor: Color = DawamiGold
)

private data class DrawerCategory(
    val id: String,
    val title: String,
    val icon: ImageVector,
    val accentColor: Color,
    val items: List<DrawerItem>
)

@Composable
fun DawamiNavigationDrawerContent(
    viewModel: MainViewModel,
    onCloseDrawer: () -> Unit
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val loggedInUser by viewModel.loggedInUser.collectAsState()
    val instituteName by viewModel.instituteName.collectAsState()
    val instituteLogoUri by viewModel.instituteLogoUri.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val dbCourses by viewModel.dbCourses.collectAsState()
    val dbAllStudents by viewModel.dbAllStudents.collectAsState()
    val currentGradesTab by viewModel.selectedGradesTabIndex.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    // Expanded state for each category. Category 1 (Daily) is open by default.
    var expandedCategories by remember {
        mutableStateOf(setOf("daily"))
    }

    val categories = remember(dbCourses.size, dbAllStudents.size) {
        listOf(
            DrawerCategory(
                id = "daily",
                title = "1. العمليات والرصد اليومي ⏱️",
                icon = Icons.Default.Today,
                accentColor = Color(0xFF10B981), // Green
                items = listOf(
                    DrawerItem(
                        title = "الرئيسية (لوحة التحكم)",
                        subtitle = "نظرة عامة والجدول اليومي",
                        icon = Icons.Default.Dashboard,
                        targetScreen = Screen.Selection
                    ),
                    DrawerItem(
                        title = "الرصد السريع الفوري ⚡",
                        subtitle = "المساعد الصوتي والرصد الشامل بلمسة",
                        icon = Icons.Default.Bolt,
                        customAction = { viewModel.openQuickAttendanceAssistant() },
                        badge = "مباشر 🔴",
                        badgeColor = Color(0xFFEF4444)
                    ),
                    DrawerItem(
                        title = "تحضير وانصراف الأستاذ ⏱️",
                        subtitle = "تسجيل الدوام والساعات المنجزة",
                        icon = Icons.Default.AccessTime,
                        targetScreen = Screen.Attendance
                    ),
                    DrawerItem(
                        title = "تحضير وانصراف الطلاب 📝",
                        subtitle = "كشف الحضور والغياب اليومي السريع",
                        icon = Icons.Default.CheckCircle,
                        targetScreen = Screen.StudentAttendance
                    )
                )
            ),
            DrawerCategory(
                id = "courses_students",
                title = "2. الدورات وإدارة المتدربين 👨‍🎓",
                icon = Icons.Default.School,
                accentColor = DawamiTeal,
                items = listOf(
                    DrawerItem(
                        title = "دليل وإدارة الدورات 🏛️",
                        subtitle = "${dbCourses.size} دورات تدريبية نشطة",
                        icon = Icons.Default.Apartment,
                        targetScreen = Screen.Courses,
                        badge = if (dbCourses.isNotEmpty()) "${dbCourses.size}" else null,
                        badgeColor = DawamiNavy
                    ),
                    DrawerItem(
                        title = "سجل وملفات الطلاب الشاملة 👥",
                        subtitle = "${dbAllStudents.size} طالب مسجل بالنظام",
                        icon = Icons.Default.Group,
                        targetScreen = Screen.Students,
                        badge = if (dbAllStudents.isNotEmpty()) "${dbAllStudents.size}" else null,
                        badgeColor = DawamiTeal
                    ),
                    DrawerItem(
                        title = "سجل المخالفات والجزاءات ⚠️",
                        subtitle = "الإنذارات السلوكية وقرارات الحرمان",
                        icon = Icons.Default.Gavel,
                        targetScreen = Screen.StudentViolations
                    )
                )
            ),
            DrawerCategory(
                id = "curriculum",
                title = "3. المناهج والمحتوى التعليمي 📚",
                icon = Icons.Default.MenuBook,
                accentColor = Color(0xFF3B82F6), // Blue
                items = listOf(
                    DrawerItem(
                        title = "المواد والخطط الدراسية 📖",
                        subtitle = "توزيع الساعات والمفردات",
                        icon = Icons.Default.AutoStories,
                        targetScreen = Screen.Subjects
                    ),
                    DrawerItem(
                        title = "دفتر تحضير الدروس والمحاور ✍️",
                        subtitle = "خطة المحاضرة والأنشطة",
                        icon = Icons.Default.EditNote,
                        targetScreen = Screen.LessonPreparation
                    ),
                    DrawerItem(
                        title = "المراجع والمصادر التعليمية 📂",
                        subtitle = "الكتب والروابط الإثرائية",
                        icon = Icons.Default.Bookmark,
                        targetScreen = Screen.SubjectReferences
                    ),
                    DrawerItem(
                        title = "تهيئة التكليفات والمشاريع ⚙️",
                        subtitle = "إنشاء وتحديد درجات الواجبات",
                        icon = Icons.Default.Assignment,
                        targetScreen = Screen.AssignmentSetup
                    )
                )
            ),
            DrawerCategory(
                id = "grades",
                title = "4. الاختبارات والتقييم ورصد الدرجات 🎯",
                icon = Icons.Default.Grade,
                accentColor = Color(0xFFF59E0B), // Amber
                items = listOf(
                    DrawerItem(
                        title = "رصد درجات الطلاب الشامل 📊",
                        subtitle = "الدرجات النهائية والتقييم الشامل",
                        icon = Icons.Default.BarChart,
                        targetScreen = Screen.Grades,
                        customAction = { viewModel.setSelectedGradesTabIndex(0) }
                    ),
                    DrawerItem(
                        title = "رصد ومتابعة تسليمات التكليفات 📋",
                        subtitle = "تقييم أداء الواجبات والمشاريع ورصدها",
                        icon = Icons.Default.FactCheck,
                        targetScreen = Screen.Grades,
                        customAction = { viewModel.setSelectedGradesTabIndex(1) }
                    ),
                    DrawerItem(
                        title = "مصحح الاختبارات النظرية ✍️",
                        subtitle = "رصد درجات الاختبارات التحريرية والنهائية",
                        icon = Icons.Default.ChecklistRtl,
                        targetScreen = Screen.TheoryExamGrader
                    )
                )
            ),
            DrawerCategory(
                id = "reports",
                title = "5. التقارير والإحصائيات والأداء المالي 📈",
                icon = Icons.Default.Assessment,
                accentColor = Color(0xFF8B5CF6), // Purple
                items = listOf(
                    DrawerItem(
                        title = "كشوفات وتقارير الحافظة والطباعة 📑",
                        subtitle = "تقارير الحافظة الشهرية بصيغة PDF",
                        icon = Icons.Default.PictureAsPdf,
                        targetScreen = Screen.Reports
                    ),
                    DrawerItem(
                        title = "إحصائيات الحضور ونسب الإجازات 📈",
                        subtitle = "مؤشرات انضباط القاعات والغياب",
                        icon = Icons.Default.TrendingUp,
                        targetScreen = Screen.CourseAttendanceAnalytics
                    ),
                    DrawerItem(
                        title = "إحصائيات ساعات التدريس ⏱️",
                        subtitle = "ساعات العمل المنجزة والمتبقية",
                        icon = Icons.Default.QueryStats,
                        targetScreen = Screen.TeachingStats
                    ),
                    DrawerItem(
                        title = "كشوفات حضور وغياب الطلاب 📄",
                        subtitle = "تقارير تفصيلية جاهزة للطباعة",
                        icon = Icons.Default.Summarize,
                        targetScreen = Screen.StudentReports
                    ),
                    DrawerItem(
                        title = "كشوفات النتائج والشهادات 📜",
                        subtitle = "الدرجات النهائية المعتمدة وقوائم الأوائل",
                        icon = Icons.Default.WorkspacePremium,
                        targetScreen = Screen.GradeReports
                    ),
                    DrawerItem(
                        title = "تقرير الساعات والمستحقات المالية 💰",
                        subtitle = "احتساب البدلات والرواتب التدريبية",
                        icon = Icons.Default.Payments,
                        targetScreen = Screen.TrainerFinances
                    ),
                    DrawerItem(
                        title = "سجل تدقيق العمليات والحركات 📋",
                        subtitle = "سجل آمن لعمليات الحذف والتعديل",
                        icon = Icons.Default.History,
                        targetScreen = Screen.ActivityLogs
                    )
                )
            ),
            DrawerCategory(
                id = "settings",
                title = "6. مركز النظام والأمان والنسخ الاحتياطي ⚙️",
                icon = Icons.Default.Settings,
                accentColor = Color(0xFF64748B), // Slate
                items = listOf(
                    DrawerItem(
                        title = "إعدادات المنبهات والمساعد الذكي 🔔",
                        subtitle = "تخصيص نبرة الصوت (بنت/ولد) والتنبيهات",
                        icon = Icons.Default.NotificationsActive,
                        targetScreen = Screen.SmartSettings
                    ),
                    DrawerItem(
                        title = "الإجازات الرسمية والعطلات 🌴",
                        subtitle = "إدارة العطلات واستثنائها من الحضور والتقارير",
                        icon = Icons.Default.EventBusy,
                        targetScreen = Screen.OfficialHolidays
                    ),
                    DrawerItem(
                        title = "الملف الشخصي للمدرب 👤",
                        subtitle = "الهوية التدريبية، التوقيع الرقمي، والبيانات الشخصية",
                        icon = Icons.Default.AccountCircle,
                        targetScreen = Screen.TrainerProfile,
                        badge = "جديد ✨",
                        badgeColor = DawamiTeal
                    ),
                    DrawerItem(
                        title = "هوية المعهد والترويسة 🏛️",
                        subtitle = "اسم المعهد والشعار الرسمي للطباعة",
                        icon = Icons.Default.Business,
                        targetScreen = Screen.InstituteSettings
                    ),
                    DrawerItem(
                        title = "مركز النسخ الاحتياطي واستعادة البيانات 💾",
                        subtitle = "تصدير واسترجاع قواعد البيانات بأمان",
                        icon = Icons.Default.Backup,
                        targetScreen = Screen.BackupRestore
                    ),
                    DrawerItem(
                        title = "استوديو المظاهر والألوان 🎨",
                        subtitle = "اختر من بين 36 سمة ومظهراً احترافياً",
                        icon = Icons.Default.Palette,
                        customAction = { viewModel.openThemeStudio() }
                    ),
                    DrawerItem(
                        title = "تغيير بيانات الدخول والأمان 🔐",
                        subtitle = "اسم المستخدم وكلمة المرور",
                        icon = Icons.Default.LockReset,
                        targetScreen = Screen.ChangeCredentials
                    ),
                    DrawerItem(
                        title = "دليل ميزات النظام والتعليمات 💡",
                        subtitle = "مرجع إرشادي مصور للاستخدام",
                        icon = Icons.Default.HelpOutline,
                        targetScreen = Screen.AppFeaturesGuide
                    ),
                    DrawerItem(
                        title = "معالج التهيئة الأكاديمية 🚀",
                        subtitle = "إعداد الدورات والجداول من جديد",
                        icon = Icons.Default.RocketLaunch,
                        targetScreen = Screen.OnboardingSetup
                    )
                )
            )
        )
    }

    // Filter items if searching
    val isSearching = searchQuery.isNotBlank()
    val filteredItems = remember(searchQuery, categories) {
        if (!isSearching) emptyList()
        else {
            val q = searchQuery.trim().lowercase()
            categories.flatMap { it.items }.filter {
                it.title.lowercase().contains(q) || it.subtitle.lowercase().contains(q)
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(
            modifier = Modifier
                .fillMaxHeight()
                .widthIn(max = 330.dp, min = 290.dp),
            color = if (isDarkTheme) Color(0xFF0F172A) else Color(0xFFFAFAFA),
            border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                // --- 1. DRAWER HEADER (ترويسة القائمة الجانبية) ---
                Surface(
                    color = if (isDarkTheme) Color(0xFF1E293B) else Color.White,
                    border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        viewModel.navigateTo(Screen.TrainerProfile)
                                        onCloseDrawer()
                                    }
                            ) {
                                if (instituteLogoUri.isNotEmpty()) {
                                    AsyncImage(
                                        model = instituteLogoUri,
                                        contentDescription = "شعار المعهد",
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(8.dp)),
                                        error = painterResource(id = R.drawable.app_icon_new_1789091045526)
                                    )
                                } else {
                                    DawamiLogo(size = 40.dp)
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = instituteName.ifBlank { "معهد دوامي التعليمي" },
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDarkTheme) Color.White else DawamiNavy,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "المستخدم: $loggedInUser 🌹",
                                        fontSize = 11.sp,
                                        color = if (isDarkTheme) Color(0xFF38BDF8) else DawamiTeal,
                                        maxLines = 1,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // Close Drawer Button
                            IconButton(
                                onClick = onCloseDrawer,
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(if (isDarkTheme) Color(0xFF334155) else Color(0xFFF1F5F9))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق القائمة",
                                    tint = if (isDarkTheme) Color.White else Color(0xFF64748B),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Quick Search Field (حقل البحث السريع)
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            placeholder = {
                                Text(
                                    text = "🔍 ابحث عن أي شاشة أو تقرير...",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = if (isDarkTheme) Color(0xFF0F172A) else Color(0xFFF8FAFC),
                                unfocusedContainerColor = if (isDarkTheme) Color(0xFF0F172A) else Color(0xFFF8FAFC),
                                focusedBorderColor = DawamiNavy,
                                unfocusedBorderColor = if (isDarkTheme) Color(0xFF334155) else Color(0xFFCBD5E1)
                            ),
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "مسح البحث",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            },
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() })
                        )
                    }
                }

                // --- 2. DRAWER BODY (محتوى الشاشات والأقسام) ---
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (isSearching) {
                        // Display search results
                        Text(
                            text = "نتائج البحث (${filteredItems.size}):",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDarkTheme) DawamiGold else DawamiNavy,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )

                        if (filteredItems.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "لم يتم العثور على شاشة مطابقة ⚠️",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            }
                        } else {
                            filteredItems.forEach { item ->
                                val isSelected = when {
                                    item.targetScreen == Screen.Grades && item.title.contains("تسليمات") -> currentScreen == Screen.Grades && currentGradesTab == 1
                                    item.targetScreen == Screen.Grades -> currentScreen == Screen.Grades && currentGradesTab == 0
                                    item.targetScreen != null -> currentScreen == item.targetScreen
                                    else -> false
                                }
                                DrawerItemRow(
                                    item = item,
                                    isSelected = isSelected,
                                    isDark = isDarkTheme,
                                    onClick = {
                                        onCloseDrawer()
                                        item.targetScreen?.let {
                                            viewModel.selectRoleMode("teacher")
                                            viewModel.navigateTo(it)
                                        }
                                        item.customAction?.invoke()
                                    }
                                )
                            }
                        }
                    } else {
                        // Display Accordion Categories
                        categories.forEach { category ->
                            val isExpanded = expandedCategories.contains(category.id)
                            val arrowRotation by animateFloatAsState(
                                targetValue = if (isExpanded) 180f else 0f,
                                label = "arrowRotation"
                            )

                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                color = if (isDarkTheme) Color(0xFF1E293B) else Color.White,
                                border = BorderStroke(
                                    1.dp,
                                    if (isExpanded) category.accentColor.copy(alpha = 0.5f)
                                    else if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)
                                ),
                                shadowElevation = if (isExpanded) 1.dp else 0.dp
                            ) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    // Section Header
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                expandedCategories = if (isExpanded) {
                                                    emptySet()
                                                } else {
                                                    setOf(category.id)
                                                }
                                            }
                                            .padding(horizontal = 10.dp, vertical = 9.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Surface(
                                                color = category.accentColor.copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Icon(
                                                        imageVector = category.icon,
                                                        contentDescription = null,
                                                        tint = category.accentColor,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                            Text(
                                                text = category.title,
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isDarkTheme) Color.White else Color(0xFF0F172A),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowDown,
                                            contentDescription = null,
                                            tint = if (isDarkTheme) Color(0xFF94A3B8) else Color(0xFF64748B),
                                            modifier = Modifier
                                                .size(20.dp)
                                                .rotate(arrowRotation)
                                        )
                                    }

                                    // Section Items (Visible when expanded)
                                    AnimatedVisibility(visible = isExpanded) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 6.dp, vertical = 4.dp),
                                            verticalArrangement = Arrangement.spacedBy(3.dp)
                                        ) {
                                            category.items.forEach { item ->
                                                val isSelected = when {
                                                    item.targetScreen == Screen.Grades && item.title.contains("تسليمات") -> currentScreen == Screen.Grades && currentGradesTab == 1
                                                    item.targetScreen == Screen.Grades -> currentScreen == Screen.Grades && currentGradesTab == 0
                                                    item.targetScreen != null -> currentScreen == item.targetScreen
                                                    else -> false
                                                }
                                                DrawerItemRow(
                                                    item = item,
                                                    isSelected = isSelected,
                                                    isDark = isDarkTheme,
                                                    accentColor = category.accentColor,
                                                    onClick = {
                                                        onCloseDrawer()
                                                        item.targetScreen?.let {
                                                            viewModel.selectRoleMode("teacher")
                                                            viewModel.navigateTo(it)
                                                        }
                                                        item.customAction?.invoke()
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // --- 3. DRAWER FOOTER (تذييل القائمة الجانبية) ---
                Surface(
                    color = if (isDarkTheme) Color(0xFF1E293B) else Color.White,
                    border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Theme Studio Shortcut Button
                            OutlinedButton(
                                onClick = {
                                    onCloseDrawer()
                                    viewModel.openThemeStudio()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.5f)),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Palette,
                                    contentDescription = null,
                                    tint = DawamiGold,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "استوديو الثيمات",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) DawamiGold else DawamiNavy
                                )
                            }

                            // Logout Button
                            Button(
                                onClick = {
                                    onCloseDrawer()
                                    viewModel.logout()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFEF4444).copy(alpha = 0.15f)
                                ),
                                border = BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.3f)),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ExitToApp,
                                    contentDescription = null,
                                    tint = Color(0xFFEF4444),
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "تسجيل خروج",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFEF4444)
                                )
                            }
                        }

                        // App Version & Credits
                        Text(
                            text = "نظام دوامي الذكي v1.0.0 • برمجة م: فيصل العفيف 🌹",
                            fontSize = 8.5.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DrawerItemRow(
    item: DrawerItem,
    isSelected: Boolean,
    isDark: Boolean,
    accentColor: Color = DawamiNavy,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() },
        color = when {
            isSelected -> if (isDark) DawamiNavy.copy(alpha = 0.35f) else DawamiNavy.copy(alpha = 0.12f)
            else -> Color.Transparent
        },
        shape = RoundedCornerShape(8.dp),
        border = if (isSelected) BorderStroke(1.dp, accentColor.copy(alpha = 0.5f)) else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = if (isSelected) accentColor else if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.size(26.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = null,
                        tint = if (isSelected) Color.White else if (isDark) Color(0xFFE2E8F0) else Color(0xFF475569),
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = when {
                        isSelected -> if (isDark) Color.White else DawamiNavy
                        else -> if (isDark) Color(0xFFE2E8F0) else Color(0xFF1E293B)
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (item.subtitle.isNotBlank()) {
                    Text(
                        text = item.subtitle,
                        fontSize = 8.5.sp,
                        color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            item.badge?.let { badgeText ->
                Surface(
                    color = item.badgeColor,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = badgeText,
                        color = Color.White,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }
        }
    }
}
