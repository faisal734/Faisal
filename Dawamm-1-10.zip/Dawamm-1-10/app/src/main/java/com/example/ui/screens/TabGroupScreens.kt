package com.example.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DawamiNavy
import com.example.ui.viewmodel.AppAdminViewModel
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.GradingViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LoopingTabPager(
    selectedTabIndex: Int,
    onTabSelected: (Int) -> Unit,
    tabs: List<String>,
    modifier: Modifier = Modifier,
    content: @Composable (tabIndex: Int) -> Unit
) {
    val actualTabCount = tabs.size
    if (actualTabCount == 0) return

    val pagerState = rememberPagerState(
        initialPage = selectedTabIndex,
        pageCount = { actualTabCount }
    )

    // Sync pagerState -> selectedTabIndex
    LaunchedEffect(pagerState.currentPage) {
        if (pagerState.currentPage != selectedTabIndex) {
            onTabSelected(pagerState.currentPage)
        }
    }

    // Sync selectedTabIndex -> pagerState
    LaunchedEffect(selectedTabIndex) {
        if (pagerState.currentPage != selectedTabIndex) {
            pagerState.animateScrollToPage(selectedTabIndex)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = MaterialTheme.colorScheme.surface,
            edgePadding = 8.dp,
            divider = { HorizontalDivider(color = Color(0xFFE2E8F0)) }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = {
                        onTabSelected(index)
                    },
                    text = {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1
                        )
                    }
                )
            }
        }

        HorizontalPager(
            state = pagerState,
            beyondViewportPageCount = 0,
            modifier = Modifier.fillMaxSize()
        ) { pageIndex ->
            content(pageIndex)
        }
    }
}

@Composable
fun TrainerGroupScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    adminViewModel: AppAdminViewModel? = null
) {
    val selectedTabIndex by viewModel.trainerGroupSelectedTab.collectAsState()
    val tabs = listOf(
        "إدارة الدورات 📦",
        "تحضير المدرب ⏱️",
        "المالية 💰",
        "إحصائيات التدريس وحالة المواد 📊"
    )

    MainLayout(viewModel = viewModel, showScaffold = true) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            LoopingTabPager(
                selectedTabIndex = selectedTabIndex,
                onTabSelected = { viewModel.setTrainerGroupTab(it) },
                tabs = tabs
            ) { index ->
                when (index) {
                    0 -> CoursesScreen(viewModel, courseViewModel, showMainLayout = false)
                    1 -> AttendanceRecordsScreen(viewModel, attendanceViewModel, showMainLayout = false)
                    2 -> TrainerFinancesScreen(viewModel, adminViewModel, showMainLayout = false)
                    3 -> TeachingStatsScreen(viewModel, courseViewModel, attendanceViewModel, showMainLayout = false)
                }
            }
        }
    }
}

@Composable
fun StudentsGroupScreen(
    viewModel: MainViewModel,
    gradingViewModel: GradingViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null
) {
    val selectedTabIndex by viewModel.studentsGroupSelectedTab.collectAsState()
    val tabs = listOf(
        "تحضير الطلاب 📝",
        "إدارة الطلاب 👥",
        "رصد الدرجات 📊",
        "إحصائيات الحضور والطلاب 📈"
    )

    MainLayout(viewModel = viewModel, showScaffold = true) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            LoopingTabPager(
                selectedTabIndex = selectedTabIndex,
                onTabSelected = { viewModel.setStudentsGroupTab(it) },
                tabs = tabs
            ) { index ->
                when (index) {
                    0 -> StudentAttendanceRecordsScreen(viewModel, attendanceViewModel, studentViewModel, showMainLayout = false)
                    1 -> StudentsScreen(viewModel, studentViewModel, showMainLayout = false)
                    2 -> GradesScreen(viewModel, gradingViewModel, showMainLayout = false)
                    3 -> CourseAttendanceAnalyticsScreen(viewModel, attendanceViewModel, studentViewModel, showMainLayout = false)
                }
            }
        }
    }
}

@Composable
fun CurriculumGroupScreen(
    viewModel: MainViewModel,
    gradingViewModel: GradingViewModel? = null,
    courseViewModel: CourseViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    studentViewModel: StudentViewModel? = null
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("المواد والمواضيع 📖", "تحضير الدروس ✍️", "المراجع الإضافية للمواد 📚", "الواجبات والتكليفات 📑", "التصحيح النظري 📝")

    MainLayout(viewModel = viewModel, showScaffold = true) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            LoopingTabPager(
                selectedTabIndex = selectedTabIndex,
                onTabSelected = { selectedTabIndex = it },
                tabs = tabs
            ) { index ->
                when (index) {
                    0 -> SubjectsScreen(viewModel, courseViewModel, showMainLayout = false)
                    1 -> LessonPreparationScreen(viewModel, courseViewModel, attendanceViewModel, showMainLayout = false)
                    2 -> SubjectReferencesScreen(viewModel, courseViewModel, showMainLayout = false)
                    3 -> AssignmentSetupScreen(viewModel, courseViewModel, studentViewModel, gradingViewModel, showMainLayout = false)
                    4 -> TheoryExamGraderScreen(viewModel, gradingViewModel, showMainLayout = false)
                }
            }
        }
    }
}

@Composable
fun ReportsGroupScreen(
    viewModel: MainViewModel,
    gradingViewModel: GradingViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    adminViewModel: AppAdminViewModel? = null,
    courseViewModel: CourseViewModel? = null
) {
    val selectedTabIndex by viewModel.reportsGroupSelectedTab.collectAsState()
    val tabs = listOf(
        "تقارير المدرب 📑",
        "تقارير حضور الطلاب 📄",
        "تقارير درجات الطلاب 📜",
        "إحصائيات التدريس وحالات المواد 📊"
    )

    MainLayout(viewModel = viewModel, showScaffold = true) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            LoopingTabPager(
                selectedTabIndex = selectedTabIndex,
                onTabSelected = { viewModel.setReportsGroupTab(it) },
                tabs = tabs
            ) { index ->
                when (index) {
                    0 -> ReportsScreen(viewModel, attendanceViewModel, courseViewModel, showMainLayout = false)
                    1 -> StudentReportsScreen(viewModel, studentViewModel, courseViewModel, attendanceViewModel, showMainLayout = false)
                    2 -> GradeReportsScreen(viewModel, gradingViewModel, showMainLayout = false)
                    3 -> TeachingStatsScreen(viewModel, courseViewModel, attendanceViewModel, showMainLayout = false)
                }
            }
        }
    }
}

@Composable
fun SettingsGroupScreen(
    viewModel: MainViewModel,
    adminViewModel: AppAdminViewModel? = null,
    courseViewModel: CourseViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    gradingViewModel: GradingViewModel? = null
) {
    val selectedTabIndex by viewModel.settingsGroupSelectedTab.collectAsState()
    val tabs = listOf(
        "هوية المعهد 🏛️",
        "المنبهات والمساعد 🔔",
        "الإجازات الرسمية 🌴",
        "النسخ الاحتياطي 💾",
        "بيانات الأمان 🔐",
        "سجل الحركات 📋",
        "دليل النظام 📖"
    )

    MainLayout(viewModel = viewModel, showScaffold = true) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            LoopingTabPager(
                selectedTabIndex = selectedTabIndex,
                onTabSelected = { viewModel.setSettingsGroupTab(it) },
                tabs = tabs
            ) { index ->
                when (index) {
                    0 -> InstituteSettingsScreen(viewModel, showMainLayout = false)
                    1 -> SmartSettingsScreen(viewModel, showMainLayout = false)
                    2 -> OfficialHolidaysScreen(viewModel, showMainLayout = false)
                    3 -> BackupRestoreScreen(
                        viewModel = viewModel,
                        courseViewModel = courseViewModel,
                        studentViewModel = studentViewModel,
                        attendanceViewModel = attendanceViewModel,
                        gradingViewModel = gradingViewModel,
                        adminViewModel = adminViewModel,
                        showMainLayout = false
                    )
                    4 -> ChangeCredentialsScreen(viewModel, showMainLayout = false)
                    5 -> ActivityLogsScreen(viewModel, adminViewModel, showMainLayout = false)
                    6 -> AppFeaturesGuideScreen(viewModel, showMainLayout = false)
                }
            }
        }
    }
}
