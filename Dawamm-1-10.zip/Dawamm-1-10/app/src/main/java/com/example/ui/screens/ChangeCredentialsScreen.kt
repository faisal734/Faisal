package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.components.DawamiBottomNavigationBar
import com.example.ui.theme.DawamiNavy
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun ChangeCredentialsScreen(viewModel: MainViewModel, showMainLayout: Boolean = true) {
    val context = LocalContext.current
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val notifications by viewModel.inAppNotifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    var newUsername by remember { mutableStateOf(viewModel.loggedInUser.value) }
    var newPassword by remember { mutableStateOf("") }

    if (showMainLayout) {
        BackHandler {
            viewModel.navigateTo(Screen.Selection)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                if (showMainLayout) {
                    AppHeader(
                        title = "تغيير بيانات الدخول والحساب 🔑🔒",
                        username = "",
                        onHomeClick = { viewModel.navigateTo(Screen.Selection) },
                        isDark = isDarkTheme,
                        onToggleTheme = { viewModel.toggleTheme() },
                        unreadNotificationCount = unreadCount,
                        onNotificationClick = { viewModel.openNotificationCenter() }
                    )
                }
            },
            bottomBar = {
                if (showMainLayout) {
                    DawamiBottomNavigationBar(viewModel = viewModel)
                }
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "تعديل اسم المستخدم وكلمة المرور 🔐",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = DawamiNavy
                            )

                            OutlinedTextField(
                                value = newUsername,
                                onValueChange = { newUsername = it },
                                label = { Text("اسم المستخدم الجديد / البريد", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            OutlinedTextField(
                                value = newPassword,
                                onValueChange = { newPassword = it },
                                label = { Text("كلمة المرور الجديدة", fontSize = 11.sp) },
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Button(
                                onClick = {
                                    if (newUsername.isBlank()) {
                                        Toast.makeText(context, "الرجاء إدخال اسم المستخدم", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    val success = viewModel.updateCredentials(
                                        newUsername = newUsername.trim(),
                                        newPassword = newPassword
                                    )
                                    if (success) {
                                        Toast.makeText(context, "تم تحديث اسم المستخدم وكلمة المرور بنجاح! 🔑", Toast.LENGTH_LONG).show()
                                        newPassword = ""
                                    } else {
                                        Toast.makeText(context, "فشل تحديث البيانات، حاول مرة أخرى ❌", Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(42.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.LockReset, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تحديث وتأكيد البيانات 🔑", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            }
                        }
                    }
                }

                item {
                    val isBiometricEnabled by viewModel.isBiometricEnabled.collectAsState()
                    val isBiometricReady = remember { viewModel.isBiometricReady() }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Fingerprint,
                                        contentDescription = null,
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = "تسجيل الدخول ببصمة الإصبع 🔒",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.5.sp,
                                                color = DawamiNavy
                                            )
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = if (isBiometricEnabled) Color(0xFFDCFCE7) else Color(0xFFF1F5F9)
                                            ) {
                                                Text(
                                                    text = if (isBiometricEnabled) "مُفعّل ✅" else "معطّل ⚪",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isBiometricEnabled) Color(0xFF15803D) else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "تفعيل أو إلغاء تفعيل تسجيل الدخول السريع والآمن بالبصمة لجهازك.",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Switch(
                                    checked = isBiometricEnabled,
                                    onCheckedChange = { isEnabled ->
                                        if (isEnabled && !isBiometricReady) {
                                            Toast.makeText(
                                                context,
                                                "جهازك لا يدعم البصمة أو تحتاج لتفعيل البصمة في إعدادات النظام أولاً ⚠️",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        } else {
                                            viewModel.saveBiometricEnabled(isEnabled)
                                            val msg = if (isEnabled) "تم تفعيل تسجيل الدخول بالبصمة بنجاح" else "تم إلغاء تفعيل تسجيل الدخول بالبصمة"
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFF16A34A),
                                        checkedIconColor = Color(0xFF16A34A),
                                        uncheckedThumbColor = Color.White,
                                        uncheckedTrackColor = Color(0xFFCBD5E1)
                                    )
                                )
                            }

                            if (!isBiometricReady) {
                                Surface(
                                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp),
                                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = "ملاحظة: جهازك قد لا يدعم البصمة أو تحتاج إلى تسجيل بصمة في إعدادات النظام أولاً.",
                                            fontSize = 9.5.sp,
                                            color = MaterialTheme.colorScheme.error,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
