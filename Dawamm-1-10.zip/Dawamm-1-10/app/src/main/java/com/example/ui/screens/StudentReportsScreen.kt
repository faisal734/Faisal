package com.example.ui.screens

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.components.formatTimeTo12HourArabic
import com.example.ui.pdf.PdfReportHelper
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentReportsScreen(
    viewModel: MainViewModel,
    studentViewModel: StudentViewModel? = null,
    courseViewModel: CourseViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    showMainLayout: Boolean = true
) {
    val context = LocalContext.current
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val courses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val showCompletedCourses by viewModel.showCompletedCoursesInDropdowns.collectAsState()
    val allStudents by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val studentAttendanceReports by viewModel.studentAttendanceReports.collectAsState()
    val studentGroupedReports by viewModel.studentGroupedReports.collectAsState()
    val studentReportGroupingMode by viewModel.studentReportGroupingMode.collectAsState()
    var expandedGroups by remember(studentGroupedReports) { mutableStateOf(studentGroupedReports.keys.toSet()) }

    val notifications by viewModel.inAppNotifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    val filterCourseName by viewModel.selectedStudentCourseReportFilter.collectAsState()
    val filterStudentQuery by viewModel.studentReportNameQuery.collectAsState()
    val filterSubjectName by viewModel.selectedStudentSubjectReportFilter.collectAsState()
    val dbSubjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()

    val dateFrom by viewModel.studentReportDateFromFilter.collectAsState()
    val dateTo by viewModel.studentReportDateToFilter.collectAsState()
    val statusFilter by viewModel.selectedStudentStatusReportFilter.collectAsState()
    val dbAttendance by viewModel.dbAttendance.collectAsState()

    var isCourseDropdownExpanded by remember { mutableStateOf(false) }
    var isSubjectDropdownExpanded by remember { mutableStateOf(false) }
    var isStudentDropdownExpanded by remember { mutableStateOf(false) }

    var recordToEditInReport by remember { mutableStateOf<com.example.data.entity.StudentAttendance?>(null) }
    var showEditDialogInReport by remember { mutableStateOf(false) }
    var editInputDate by remember { mutableStateOf("") }
    var editInputSubject by remember { mutableStateOf("") }
    var editInputStatus by remember { mutableStateOf("حضور") }
    var editInputCheckIn by remember { mutableStateOf("") }
    var editInputCheckOut by remember { mutableStateOf("") }
    var editInputNote by remember { mutableStateOf("") }
    var isEditSubjectDropdownExpanded by remember { mutableStateOf(false) }

    var recordToDeleteInReport by remember { mutableStateOf<com.example.data.entity.StudentAttendance?>(null) }
    var showDeleteDialogInReport by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            if (studentAttendanceReports.isEmpty()) {
                Toast.makeText(context, "لا توجد سجلات لتصدير التقرير! ❌", Toast.LENGTH_SHORT).show()
            } else {
                coroutineScope.launch(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                            PdfReportHelper.exportStudentReportsToPdf(
                                viewModel = viewModel,
                                reports = studentAttendanceReports,
                                outputStream = outputStream,
                                groupingMode = studentReportGroupingMode
                            )
                        }
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "تم تصدير تقرير حركة الطلاب بصيغة PDF بنجاح! 📄💾", Toast.LENGTH_LONG).show()
                        }
                        viewModel.logActivity(
                            category = "SYSTEM",
                            actionType = "CREATE",
                            title = "تصدير تقرير حركة الطلاب PDF 📄",
                            description = "تم تصدير وحفظ تقرير حركة غياب وحضور الطلاب كملف PDF بنجاح"
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "فشل تصدير ملف PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
    }

    // Summary calculation (memoized to avoid recalculation on unrelated recompositions)
    val totalCount = remember(studentAttendanceReports) { studentAttendanceReports.size }
    val presentCount = remember(studentAttendanceReports) { studentAttendanceReports.count { it.status == "حضور" } }
    val absentCount = remember(studentAttendanceReports) { studentAttendanceReports.count { it.status == "غياب" } }
    val excusedCount = remember(studentAttendanceReports) { studentAttendanceReports.count { it.status == "مستأذن" } }
    val leaveCount = remember(studentAttendanceReports) { studentAttendanceReports.count { it.status == "إجازة" } }
    
    val dbAllStudentAttendance by viewModel.dbAllStudentAttendance.collectAsState()
    val otherCoursesWarning = remember(dbAllStudentAttendance, filterCourseName, filterStudentQuery) {
        if (filterCourseName.isNotEmpty() && filterCourseName != "الكل" && filterStudentQuery.isNotEmpty() && filterStudentQuery != "الكل" && filterStudentQuery != "جميع الطلاب") {
            val allStudentRecords = dbAllStudentAttendance.filter { it.studentName.trim().equals(filterStudentQuery.trim(), ignoreCase = true) }
            val otherCourses = allStudentRecords.map { it.courseName }.distinct().filter { it.trim() != filterCourseName.trim() && it.isNotEmpty() }
            if (otherCourses.isNotEmpty()) {
                otherCourses
            } else null
        } else null
    }

    val selectedCourseObj = remember(courses, filterCourseName) {
        if (filterCourseName.isNotBlank() && filterCourseName != "الكل") {
            courses.find { it.name == filterCourseName }
        } else null
    }

    val displayedCourses = remember(courses, showCompletedCourses) {
        if (showCompletedCourses) courses else courses.filter { !it.isCompleted }
    }

    val availableSubjectsForDropdown = remember(selectedCourseObj, dbSubjects) {
        if (selectedCourseObj != null) {
            val courseDip = selectedCourseObj.diplomaName.trim()
            val courseDept = selectedCourseObj.departmentName.trim()
            val filtered = dbSubjects.filter { subj ->
                (courseDip.isNotEmpty() && subj.diplomaName.trim() == courseDip) ||
                (courseDept.isNotEmpty() && subj.departmentName.trim() == courseDept)
            }
            if (filtered.isNotEmpty()) filtered else dbSubjects
        } else dbSubjects
    }

    val filteredStudentsForDropdown = remember(selectedCourseObj, allStudents) {
        if (selectedCourseObj != null) {
            allStudents.filter { it.courseId == selectedCourseObj.id }
        } else allStudents
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->
            val flattenedStudentItems = remember(studentGroupedReports, expandedGroups) {
                buildList {
                    studentGroupedReports.forEach { (groupTitle, attendanceList) ->
                        val isExpanded = expandedGroups.contains(groupTitle)
                        add(StudentGroupHeader(groupTitle, attendanceList.size, isExpanded))
                        if (isExpanded) {
                            addAll(attendanceList)
                        }
                    }
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(12.dp),
                contentPadding = PaddingValues(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Official Institute Header Card
                item {
                    InstituteReportHeader(viewModel)
                }

                // Filter Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "تصفية واستعلام تقارير الطلاب 🔍",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = DawamiNavy
                            )

                            // Course Filter
                            ExposedDropdownMenuBox(
                                expanded = isCourseDropdownExpanded,
                                onExpandedChange = { isCourseDropdownExpanded = !isCourseDropdownExpanded }
                            ) {
                                OutlinedTextField(
                                    value = filterCourseName.ifEmpty { "جميع الدورات التدريبية" },
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("الدورة التدريبية", fontSize = 11.sp) },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCourseDropdownExpanded) },
                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                ExposedDropdownMenu(
                                    expanded = isCourseDropdownExpanded,
                                    onDismissRequest = { isCourseDropdownExpanded = false },
                                    modifier = Modifier.heightIn(max = 280.dp)
                                ) {
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                                )
                                                Icon(
                                                    imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                    contentDescription = null,
                                                    tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                            }
                                        },
                                        onClick = {
                                            viewModel.toggleShowCompletedCoursesInDropdowns()
                                        }
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                                    DropdownMenuItem(
                                        text = { Text("جميع الدورات التدريبية", fontSize = 11.sp) },
                                        onClick = {
                                            viewModel.setStudentReportCourseFilter("")
                                            isCourseDropdownExpanded = false
                                        }
                                    )
                                    displayedCourses.forEach { course ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = if (course.isCompleted) "${course.name} (منتهية 🔒)" else course.name,
                                                    fontSize = 11.sp,
                                                    color = if (course.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                                )
                                            },
                                            onClick = {
                                                viewModel.setStudentReportCourseFilter(course.name)
                                                isCourseDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Subject Filter
                            ExposedDropdownMenuBox(
                                expanded = isSubjectDropdownExpanded,
                                onExpandedChange = { isSubjectDropdownExpanded = !isSubjectDropdownExpanded }
                            ) {
                                OutlinedTextField(
                                    value = filterSubjectName.ifEmpty { "جميع المواد" },
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("المادة التدريبية", fontSize = 11.sp) },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSubjectDropdownExpanded) },
                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                ExposedDropdownMenu(
                                    expanded = isSubjectDropdownExpanded,
                                    onDismissRequest = { isSubjectDropdownExpanded = false },
                                    modifier = Modifier.heightIn(max = 280.dp)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("جميع المواد", fontSize = 11.sp) },
                                        onClick = {
                                            viewModel.setStudentReportSubjectFilter("الكل")
                                            isSubjectDropdownExpanded = false
                                        }
                                    )
                                    availableSubjectsForDropdown.forEach { subj ->
                                        DropdownMenuItem(
                                            text = { Text(subj.name, fontSize = 11.sp) },
                                            onClick = {
                                                viewModel.setStudentReportSubjectFilter(subj.name)
                                                isSubjectDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Student Filter Query
                            ExposedDropdownMenuBox(
                                expanded = isStudentDropdownExpanded,
                                onExpandedChange = { isStudentDropdownExpanded = !isStudentDropdownExpanded }
                            ) {
                                OutlinedTextField(
                                    value = filterStudentQuery.ifEmpty { "جميع الطلاب" },
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("طالب محدد", fontSize = 11.sp) },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStudentDropdownExpanded) },
                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                ExposedDropdownMenu(
                                    expanded = isStudentDropdownExpanded,
                                    onDismissRequest = { isStudentDropdownExpanded = false },
                                    modifier = Modifier.heightIn(max = 280.dp)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("جميع الطلاب", fontSize = 11.sp) },
                                        onClick = {
                                            viewModel.setStudentReportNameQuery("")
                                            isStudentDropdownExpanded = false
                                        }
                                    )
                                    filteredStudentsForDropdown.forEach { student ->
                                        DropdownMenuItem(
                                            text = { Text(student.name, fontSize = 11.sp) },
                                            onClick = {
                                                viewModel.setStudentReportNameQuery(student.name)
                                                isStudentDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Date Range
                            val calendar = Calendar.getInstance()
                            val dateFromDialog = DatePickerDialog(
                                context,
                                { _, year, month, dayOfMonth ->
                                    val formattedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
                                    viewModel.setStudentReportDateFrom(formattedDate)
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH)
                            )
                            val dateToDialog = DatePickerDialog(
                                context,
                                { _, year, month, dayOfMonth ->
                                    val formattedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
                                    viewModel.setStudentReportDateTo(formattedDate)
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = dateFrom,
                                    onValueChange = { },
                                    readOnly = true,
                                    label = { Text("من تاريخ", fontSize = 10.sp) },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp),
                                    trailingIcon = {
                                        IconButton(onClick = { dateFromDialog.show() }) {
                                            Icon(Icons.Default.CalendarToday, contentDescription = "Select Date From", modifier = Modifier.size(20.dp))
                                        }
                                    }
                                )
                                OutlinedTextField(
                                    value = dateTo,
                                    onValueChange = { },
                                    readOnly = true,
                                    label = { Text("إلى تاريخ", fontSize = 10.sp) },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp),
                                    trailingIcon = {
                                        IconButton(onClick = { dateToDialog.show() }) {
                                            Icon(Icons.Default.CalendarToday, contentDescription = "Select Date To", modifier = Modifier.size(20.dp))
                                        }
                                    }
                                )
                            }

                            // Grouping Mode Toggle
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("تجميع نتائج التقارير حسب:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("التاريخ", "المادة", "الدورة").forEach { modeOpt ->
                                        val isSelected = studentReportGroupingMode == modeOpt
                                        Card(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable { viewModel.setStudentReportGroupingMode(modeOpt) },
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isSelected) DawamiNavy else Color(0xFFF1F5F9)
                                            ),
                                            shape = RoundedCornerShape(10.dp),
                                            border = BorderStroke(1.dp, if (isSelected) DawamiNavy else Color(0xFFE2E8F0))
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = when (modeOpt) {
                                                        "التاريخ" -> "📅 التاريخ"
                                                        "المادة" -> "📚 المادة"
                                                        "الدورة" -> "📦 الدورة"
                                                        else -> modeOpt
                                                    },
                                                    color = if (isSelected) Color.White else Color(0xFF475569),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    if (studentAttendanceReports.isEmpty()) {
                                        Toast.makeText(context, "لا توجد بيانات لتصديرها", Toast.LENGTH_SHORT).show()
                                    } else if (viewModel.trainerBaseDirUri.value.isNotEmpty()) {
                                        coroutineScope.launch(Dispatchers.IO) {
                                            val success = viewModel.savePdfReportToReportsFolder(context, "تقرير_حركة_الطلاب.pdf") { outputStream ->
                                                PdfReportHelper.exportStudentReportsToPdf(
                                                    viewModel = viewModel,
                                                    reports = studentAttendanceReports,
                                                    outputStream = outputStream,
                                                    groupingMode = studentReportGroupingMode
                                                )
                                            }
                                            withContext(Dispatchers.Main) {
                                                if (success) {
                                                    Toast.makeText(context, "تم حفظ تقرير حركة الطلاب تلقائياً في مجلد Reports بنجاح! 📄⚡", Toast.LENGTH_LONG).show()
                                                    viewModel.logActivity(
                                                        category = "SYSTEM",
                                                        actionType = "CREATE",
                                                        title = "تصدير تقرير حركة الطلاب PDF 📄",
                                                        description = "تم تصدير وحفظ تقرير حركة غياب وحضور الطلاب في مجلد Reports"
                                                    )
                                                } else {
                                                    pdfLauncher.launch("تقرير_حركة_الطلاب.pdf")
                                                }
                                            }
                                        }
                                    } else {
                                        pdfLauncher.launch("تقرير_حركة_الطلاب.pdf")
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تصدير التقرير PDF 📄", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Warning for other courses
                if (otherCoursesWarning != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                            border = BorderStroke(1.dp, Color(0xFFFDE68A))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Info, contentDescription = "معلومة", tint = Color(0xFFD97706), modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "هذا الطالب منقول، ولديه سجلات حضور محفوظة ومستقلة في الدورة: (${otherCoursesWarning.joinToString("، ")}). اختر (جميع الدورات) من الأعلى لرؤية تاريخه كاملاً.",
                                    color = Color(0xFF92400E),
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }

                // Stats Header
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = DawamiNavy.copy(alpha = 0.05f))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("السجلات: $totalCount", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = DawamiNavy)
                            Text("🟢 حضور: $presentCount", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = Color(0xFF16A34A))
                            Text("🔴 غياب: $absentCount", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = Color(0xFFDC2626))
                            Text("🔵 مستأذن: $excusedCount", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = Color(0xFF0284C7))
                            Text("🟡 إجازة: $leaveCount", fontWeight = FontWeight.Bold, fontSize = 10.5.sp, color = Color(0xFFD97706))
                        }
                    }
                }

                // Records List
                if (studentAttendanceReports.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("لا توجد سجلات حركة مطابقة لشروط التصفية الحالية.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    items(flattenedStudentItems, key = { item ->
                        when (item) {
                            is StudentGroupHeader -> "student_header_${item.title}"
                            is com.example.data.entity.StudentAttendance -> "student_record_${item.id}"
                            else -> item.hashCode()
                        }
                    }) { item ->
                        when (item) {
                            is StudentGroupHeader -> {
                                val isGroupExpanded = item.isExpanded
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp)
                                        .clickable {
                                            expandedGroups = if (isGroupExpanded) {
                                                expandedGroups - item.title
                                            } else {
                                                expandedGroups + item.title
                                            }
                                        },
                                    colors = CardDefaults.cardColors(containerColor = DawamiNavy.copy(alpha = 0.06f)),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (isGroupExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                contentDescription = null,
                                                tint = DawamiNavy,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Text(
                                                text = item.title,
                                                color = DawamiNavy,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Badge(containerColor = DawamiGold) {
                                            Text("${item.size} سجلات", color = Color.White, modifier = Modifier.padding(2.dp))
                                        }
                                    }
                                }
                            }
                            is com.example.data.entity.StudentAttendance -> {
                                val record = item
                                Card(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Text(record.studentName, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = DawamiNavy)
                                            Text("${record.date} - الدورة: ${record.courseName}", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            if (record.courseDailyNote.isNotEmpty()) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                    modifier = Modifier.padding(top = 2.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.EditNote,
                                                        contentDescription = null,
                                                        tint = DawamiGold,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                    Text("ملاحظة الأستاذ اليومية: ${record.courseDailyNote}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                                }
                                            }
                                            if (record.studentNote.isNotEmpty()) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                    modifier = Modifier.padding(top = 2.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Comment,
                                                        contentDescription = null,
                                                        tint = DawamiNavy,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                    Text("ملاحظة الطالب الفردية: ${record.studentNote}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                                }
                                            }
                                            if (record.subjectName.isNotEmpty()) {
                                                val isExamDay = dbAttendance.any { it.courseId == record.courseId && it.date == record.date && it.isExamDay }
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.MenuBook,
                                                        contentDescription = null,
                                                        tint = DawamiTeal,
                                                        modifier = Modifier.size(11.dp)
                                                    )
                                                    Text("المادة: ${record.subjectName}", fontSize = 10.5.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)
                                                    if (isExamDay) {
                                                        Surface(
                                                            color = Color(0xFFFEF3C7),
                                                            shape = RoundedCornerShape(4.dp),
                                                            border = BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.5f))
                                                        ) {
                                                            Text(
                                                                text = "📝 امتحان",
                                                                fontSize = 8.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color(0xFFB45309),
                                                                maxLines = 1,
                                                                softWrap = false,
                                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                            if (record.actualCheckIn.isNotEmpty()) {
                                                Text("الدخول: ${formatTimeTo12HourArabic(record.actualCheckIn)} | الانصراف: ${if(record.actualCheckOut.isEmpty()) "لم يسجل" else formatTimeTo12HourArabic(record.actualCheckOut)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                            }
                                        }

                                        Column(
                                            horizontalAlignment = Alignment.End,
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = when(record.status) {
                                                    "حضور" -> Color(0xFF22C55E).copy(alpha = 0.15f)
                                                    "غياب" -> Color(0xFFEF4444).copy(alpha = 0.15f)
                                                    "إجازة" -> Color(0xFFEAB308).copy(alpha = 0.15f)
                                                    else -> Color.Gray.copy(alpha = 0.15f)
                                                }
                                            ) {
                                                Text(
                                                    text = record.status,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = when(record.status) {
                                                        "حضور" -> Color(0xFF15803D)
                                                        "غياب" -> Color(0xFFB91C1C)
                                                        "إجازة" -> Color(0xFFB45309)
                                                        else -> Color.DarkGray
                                                    },
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }

                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(2.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                IconButton(
                                                    onClick = {
                                                        recordToEditInReport = record
                                                        editInputDate = record.date
                                                        editInputSubject = record.subjectName
                                                        editInputStatus = record.status
                                                        editInputCheckIn = record.actualCheckIn
                                                        editInputCheckOut = record.actualCheckOut
                                                        editInputNote = record.studentNote
                                                        showEditDialogInReport = true
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Edit,
                                                        contentDescription = "تعديل",
                                                        tint = DawamiNavy,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                }

                                                IconButton(
                                                    onClick = {
                                                        recordToDeleteInReport = record
                                                        showDeleteDialogInReport = true
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.DeleteOutline,
                                                        contentDescription = "حذف",
                                                        tint = Color.Red,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- Edit Record Dialog in Reports Screen ---
        if (showEditDialogInReport && recordToEditInReport != null) {
            val rec = recordToEditInReport!!
            val associatedCourse = courses.find { it.id == rec.courseId }
            val relevantSubjects = remember(dbSubjects, associatedCourse) {
                val list = if (associatedCourse != null) {
                    dbSubjects.filter { sub ->
                        (associatedCourse.diplomaName.isNotEmpty() && sub.diplomaName.equals(associatedCourse.diplomaName, ignoreCase = true)) ||
                        (associatedCourse.departmentName.isNotEmpty() && sub.departmentName.equals(associatedCourse.departmentName, ignoreCase = true))
                    }.map { it.name }
                } else emptyList()
                (list + listOf("عام", rec.subjectName)).filter { it.isNotBlank() }.distinct()
            }

            AlertDialog(
                onDismissRequest = { showEditDialogInReport = false },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = DawamiNavy)
                        Text(
                            text = "تعديل حركة الطالب ✏️",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = DawamiNavy
                        )
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "${rec.studentName} • ${rec.courseName}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )

                        // Date field
                        OutlinedTextField(
                            value = "$editInputDate (${viewModel.getArabicDayOfWeek(editInputDate)})",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("التاريخ", fontSize = 10.sp) },
                            trailingIcon = {
                                IconButton(onClick = {
                                    val cal = Calendar.getInstance()
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val fMonth = String.format("%02d", m + 1)
                                            val fDay = String.format("%02d", d)
                                            editInputDate = "$y-$fMonth-$fDay"
                                        },
                                        cal.get(Calendar.YEAR),
                                        cal.get(Calendar.MONTH),
                                        cal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                }) {
                                    Icon(Icons.Default.CalendarToday, contentDescription = null, tint = DawamiNavy)
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp)
                        )

                        // Subject dropdown
                        ExposedDropdownMenuBox(
                            expanded = isEditSubjectDropdownExpanded,
                            onExpandedChange = { isEditSubjectDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = editInputSubject,
                                onValueChange = { editInputSubject = it },
                                label = { Text("المادة التدريبية", fontSize = 10.sp) },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isEditSubjectDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp)
                            )
                            ExposedDropdownMenu(
                                expanded = isEditSubjectDropdownExpanded,
                                onDismissRequest = { isEditSubjectDropdownExpanded = false }
                            ) {
                                relevantSubjects.forEach { sub ->
                                    DropdownMenuItem(
                                        text = { Text(sub, fontSize = 11.sp) },
                                        onClick = {
                                            editInputSubject = sub
                                            isEditSubjectDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Status selection
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("الحالة:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                listOf("حضور", "غياب", "مستأذن", "إجازة").forEach { st ->
                                    val isSel = editInputStatus == st
                                    val bgCol = if (isSel) {
                                        when (st) {
                                            "حضور" -> Color(0xFFE6F4EA)
                                            "غياب" -> Color(0xFFFCE8E6)
                                            "مستأذن" -> Color(0xFFFEF7E0)
                                            else -> Color(0xFFE8F0FE)
                                        }
                                    } else Color.Transparent
                                    val borderCol = if (isSel) {
                                        when (st) {
                                            "حضور" -> Color(0xFF137333)
                                            "غياب" -> Color(0xFFC5221F)
                                            "مستأذن" -> Color(0xFFB06000)
                                            else -> Color(0xFF1A73E8)
                                        }
                                    } else Color.LightGray
                                    val txtCol = if (isSel) borderCol else MaterialTheme.colorScheme.onSurfaceVariant

                                    Surface(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { editInputStatus = st },
                                        color = bgCol,
                                        shape = RoundedCornerShape(6.dp),
                                        border = BorderStroke(1.dp, borderCol)
                                    ) {
                                        Box(
                                            modifier = Modifier.padding(vertical = 6.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(st, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = txtCol)
                                        }
                                    }
                                }
                            }
                        }

                        // Time fields
                        if (editInputStatus == "حضور" || editInputStatus == "مستأذن") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = if (editInputCheckIn.isNotBlank()) formatTimeTo12HourArabic(editInputCheckIn) else "",
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("وقت الدخول", fontSize = 10.sp) },
                                    trailingIcon = {
                                        IconButton(onClick = {
                                            val cal = Calendar.getInstance()
                                            android.app.TimePickerDialog(
                                                context,
                                                { _, h, m ->
                                                    editInputCheckIn = String.format("%02d:%02d", h, m)
                                                },
                                                cal.get(Calendar.HOUR_OF_DAY),
                                                cal.get(Calendar.MINUTE),
                                                false
                                            ).show()
                                        }) {
                                            Icon(Icons.Default.AccessTime, contentDescription = null, tint = DawamiNavy)
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp)
                                )

                                OutlinedTextField(
                                    value = if (editInputCheckOut.isNotBlank()) formatTimeTo12HourArabic(editInputCheckOut) else "",
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("وقت الخروج", fontSize = 10.sp) },
                                    trailingIcon = {
                                        IconButton(onClick = {
                                            val cal = Calendar.getInstance()
                                            android.app.TimePickerDialog(
                                                context,
                                                { _, h, m ->
                                                    editInputCheckOut = String.format("%02d:%02d", h, m)
                                                },
                                                cal.get(Calendar.HOUR_OF_DAY),
                                                cal.get(Calendar.MINUTE),
                                                false
                                            ).show()
                                        }) {
                                            Icon(Icons.Default.AccessTime, contentDescription = null, tint = DawamiNavy)
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp)
                                )
                            }
                        }

                        // Note field
                        OutlinedTextField(
                            value = editInputNote,
                            onValueChange = { editInputNote = it },
                            label = { Text("ملاحظة الطالب", fontSize = 10.sp) },
                            placeholder = { Text("ملاحظة أو مبرر...", fontSize = 10.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                            maxLines = 2
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (editInputDate.isBlank()) {
                                Toast.makeText(context, "الرجاء تحديد التاريخ!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val updated = rec.copy(
                                date = editInputDate,
                                dayOfWeek = viewModel.getArabicDayOfWeek(editInputDate),
                                status = editInputStatus,
                                subjectName = editInputSubject,
                                actualCheckIn = if (editInputStatus == "حضور" || editInputStatus == "مستأذن") editInputCheckIn else "",
                                actualCheckOut = if (editInputStatus == "حضور" || editInputStatus == "مستأذن") editInputCheckOut else "",
                                studentNote = editInputNote,
                                updatedAt = System.currentTimeMillis()
                            )

                            viewModel.insertStudentAttendance(updated)
                            Toast.makeText(context, "تم حفظ تعديل حركة الطالب بنجاح! 💾", Toast.LENGTH_SHORT).show()
                            showEditDialogInReport = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                    ) {
                        Text("حفظ التعديلات", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditDialogInReport = false }) {
                        Text("إلغاء", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                shape = RoundedCornerShape(12.dp),
                containerColor = MaterialTheme.colorScheme.surface
            )
        }

        // --- Delete Confirmation Dialog in Reports Screen ---
        if (showDeleteDialogInReport && recordToDeleteInReport != null) {
            val rec = recordToDeleteInReport!!
            AlertDialog(
                onDismissRequest = { showDeleteDialogInReport = false },
                title = {
                    Text(
                        text = "تأكيد حذف حركة الحضور 🗑️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = DawamiNavy
                    )
                },
                text = {
                    Text(
                        text = "هل أنت متأكد من حذف حركة الطالب (${rec.studentName}) ليوم ${rec.date} لمادة (${rec.subjectName.ifEmpty { "عام" }}) بحالة (${rec.status})؟ سيتم تحديث التقرير فوراً.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.deleteStudentAttendanceRecord(rec)
                            Toast.makeText(context, "تم حذف الحركة بنجاح وتحديث التقرير!", Toast.LENGTH_SHORT).show()
                            showDeleteDialogInReport = false
                            recordToDeleteInReport = null
                        }
                    ) {
                        Text("نعم، احذف", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteDialogInReport = false }) {
                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                shape = RoundedCornerShape(10.dp),
                containerColor = MaterialTheme.colorScheme.surface
            )
        }
    }
}

data class StudentGroupHeader(val title: String, val size: Int, val isExpanded: Boolean)
