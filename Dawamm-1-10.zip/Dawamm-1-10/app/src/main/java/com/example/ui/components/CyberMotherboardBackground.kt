package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * High-performance Jetpack Compose Canvas rendering a sleek Cyber Motherboard PCB layout
 * with subtle PCB circuit traces, 45°/90° angles, micro vias (nodes), and smooth neon pulses.
 */
@Composable
fun CyberMotherboardBackground(
    modifier: Modifier = Modifier,
    animate: Boolean = false
) {
    val baseDark = Color(0xFF050B14)
    val gridColor = Color(0xFF0B1B2F).copy(alpha = 0.4f)
    val traceColor = Color(0xFF00F0FF).copy(alpha = 0.18f)
    val secondaryTraceColor = Color(0xFF0E7490).copy(alpha = 0.25f)
    val amberTraceColor = Color(0xFFF59E0B).copy(alpha = 0.22f)
    val neonCyan = Color(0xFF00F0FF)
    val electricAmber = Color(0xFFFBBF24)

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // 1. Base Dark Cyber Canvas
        drawRect(color = baseDark)

        // 2. Subtle Cyber Grid Nodes (Dotted Matrix)
        val gridStep = 40f
        var x = 0f
        while (x < w) {
            var y = 0f
            while (y < h) {
                drawCircle(
                    color = gridColor,
                    radius = 1f,
                    center = Offset(x, y)
                )
                y += gridStep
            }
            x += gridStep
        }

        // 3. Central Motherboard Processor Socket / IC Outline
        val chipW = w * 0.38f
        val chipH = h * 0.16f
        val chipX = (w - chipW) / 2f
        val chipY = h * 0.32f

        // Chip Outer Frame
        drawRect(
            color = secondaryTraceColor,
            topLeft = Offset(chipX, chipY),
            size = Size(chipW, chipH),
            style = Stroke(width = 1.5f)
        )
        // Chip Corner Accents
        val cornerLen = 12f
        drawLine(neonCyan.copy(alpha = 0.6f), Offset(chipX, chipY), Offset(chipX + cornerLen, chipY), 2f)
        drawLine(neonCyan.copy(alpha = 0.6f), Offset(chipX, chipY), Offset(chipX, chipY + cornerLen), 2f)
        drawLine(neonCyan.copy(alpha = 0.6f), Offset(chipX + chipW, chipY), Offset(chipX + chipW - cornerLen, chipY), 2f)
        drawLine(neonCyan.copy(alpha = 0.6f), Offset(chipX + chipW, chipY), Offset(chipX + chipW, chipY + cornerLen), 2f)

        // 4. PCB Circuit Traces (45° and 90° lines)
        // Bus 1: Top Left to Center Chip
        val p1 = Path().apply {
            moveTo(w * 0.05f, h * 0.05f)
            lineTo(w * 0.22f, h * 0.05f)
            lineTo(w * 0.35f, h * 0.18f)
            lineTo(w * 0.35f, chipY)
        }
        drawPath(p1, traceColor, style = Stroke(width = 1.5f, cap = StrokeCap.Round))

        // Bus 2: Top Right to Center Chip
        val p2 = Path().apply {
            moveTo(w * 0.95f, h * 0.08f)
            lineTo(w * 0.78f, h * 0.08f)
            lineTo(w * 0.65f, h * 0.21f)
            lineTo(w * 0.65f, chipY)
        }
        drawPath(p2, traceColor, style = Stroke(width = 1.5f, cap = StrokeCap.Round))

        // Bus 3: Left Lateral Data Highway
        val p3 = Path().apply {
            moveTo(w * 0.04f, h * 0.45f)
            lineTo(w * 0.18f, h * 0.45f)
            lineTo(w * 0.28f, h * 0.55f)
            lineTo(w * 0.28f, h * 0.78f)
            lineTo(w * 0.12f, h * 0.94f)
        }
        drawPath(p3, secondaryTraceColor, style = Stroke(width = 1.5f, cap = StrokeCap.Round))

        // Bus 4: Right Lateral Data Highway (Amber Accented)
        val p4 = Path().apply {
            moveTo(w * 0.96f, h * 0.42f)
            lineTo(w * 0.82f, h * 0.42f)
            lineTo(w * 0.72f, h * 0.52f)
            lineTo(w * 0.72f, h * 0.75f)
            lineTo(w * 0.88f, h * 0.91f)
        }
        drawPath(p4, amberTraceColor, style = Stroke(width = 1.5f, cap = StrokeCap.Round))

        // Bus 5: Bottom Center Memory Bus
        val p5 = Path().apply {
            moveTo(chipX + chipW * 0.5f, chipY + chipH)
            lineTo(chipX + chipW * 0.5f, h * 0.62f)
            lineTo(w * 0.5f, h * 0.82f)
            lineTo(w * 0.5f, h * 0.96f)
        }
        drawPath(p5, traceColor, style = Stroke(width = 1.5f, cap = StrokeCap.Round))

        // 5. Circuit Nodes / Micro Vias (Pads with rings)
        val nodes = listOf(
            Offset(w * 0.05f, h * 0.05f) to neonCyan,
            Offset(w * 0.95f, h * 0.08f) to neonCyan,
            Offset(w * 0.04f, h * 0.45f) to neonCyan,
            Offset(w * 0.12f, h * 0.94f) to neonCyan,
            Offset(w * 0.96f, h * 0.42f) to electricAmber,
            Offset(w * 0.88f, h * 0.91f) to electricAmber,
            Offset(w * 0.5f, h * 0.96f) to neonCyan,
            Offset(w * 0.35f, h * 0.18f) to secondaryTraceColor,
            Offset(w * 0.65f, h * 0.21f) to secondaryTraceColor,
            Offset(w * 0.28f, h * 0.55f) to secondaryTraceColor,
            Offset(w * 0.72f, h * 0.52f) to electricAmber
        )

        nodes.forEach { (pos, color) ->
            // Outer solder pad
            drawCircle(
                color = color.copy(alpha = 0.3f),
                radius = 4.5f,
                center = pos,
                style = Stroke(width = 1f)
            )
            // Inner micro-via core
            drawCircle(
                color = color.copy(alpha = 0.85f),
                radius = 2f,
                center = pos
            )
        }
    }
}
