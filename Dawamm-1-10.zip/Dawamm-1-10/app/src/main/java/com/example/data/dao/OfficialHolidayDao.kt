package com.example.data.dao

import androidx.room.*
import com.example.data.entity.OfficialHoliday
import kotlinx.coroutines.flow.Flow

@Dao
interface OfficialHolidayDao {
    @Query("SELECT * FROM official_holidays ORDER BY startDate ASC")
    fun getAllHolidays(): Flow<List<OfficialHoliday>>

    @Query("SELECT * FROM official_holidays WHERE isEnabled = 1 ORDER BY startDate ASC")
    fun getEnabledHolidays(): Flow<List<OfficialHoliday>>

    @Query("SELECT * FROM official_holidays WHERE isEnabled = 1")
    suspend fun getEnabledHolidaysSync(): List<OfficialHoliday>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHoliday(holiday: OfficialHoliday): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHolidays(holidays: List<OfficialHoliday>)

    @Update
    suspend fun updateHoliday(holiday: OfficialHoliday)

    @Delete
    suspend fun deleteHoliday(holiday: OfficialHoliday)

    @Query("DELETE FROM official_holidays")
    suspend fun deleteAllHolidays()
}
