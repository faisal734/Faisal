package com.example.data.repository

import com.example.data.dao.CourseDao
import com.example.data.dao.SubjectDao
import com.example.data.dao.SubjectReferenceDao
import com.example.data.entity.Course
import com.example.data.entity.CourseSubjectCrossRef
import com.example.data.entity.Subject
import com.example.data.entity.SubjectReference
import kotlinx.coroutines.flow.Flow

/**
 * CourseRepository: مسؤول عن إدارة الدورات التدريبية والمواد والمقررات والأقسام والمراجع.
 */
class CourseRepository(
    private val courseDao: CourseDao,
    private val subjectDao: SubjectDao,
    private val subjectReferenceDao: SubjectReferenceDao
) {
    val allCourses: Flow<List<Course>> = courseDao.getAllCourses()
    val allSubjects: Flow<List<Subject>> = subjectDao.getAllSubjects()
    val allCourseSubjects: Flow<List<CourseSubjectCrossRef>> = subjectDao.getAllCourseSubjects()
    val allReferences: Flow<List<SubjectReference>> = subjectReferenceDao.getAllReferences()

    suspend fun getAllCoursesSync(): List<Course> = courseDao.getAllCoursesSync()
    suspend fun getCourseById(courseId: Int): Course? = courseDao.getCourseById(courseId)
    suspend fun insertCourse(course: Course): Long = courseDao.insertCourse(course)
    suspend fun updateCourse(course: Course) = courseDao.updateCourse(course)
    suspend fun deleteCourse(course: Course) = courseDao.deleteCourse(course)
    suspend fun deleteAllCourses() = courseDao.deleteAllCourses()

    suspend fun insertSubject(subject: Subject): Long = subjectDao.insertSubject(subject)
    suspend fun updateSubject(subject: Subject) = subjectDao.updateSubject(subject)
    suspend fun deleteSubject(subject: Subject) = subjectDao.deleteSubject(subject)
    suspend fun getSubjectById(subjectId: Int): Subject? = subjectDao.getSubjectById(subjectId)
    suspend fun deleteAllSubjects() = subjectDao.deleteAllSubjects()

    suspend fun insertCourseSubject(crossRef: CourseSubjectCrossRef) = subjectDao.insertCourseSubject(crossRef)
    suspend fun deleteCourseSubject(crossRef: CourseSubjectCrossRef) = subjectDao.deleteCourseSubject(crossRef)
    suspend fun deleteAllCourseSubjects() = subjectDao.deleteAllCourseSubjects()

    fun getReferencesForSubject(subjectName: String): Flow<List<SubjectReference>> = subjectReferenceDao.getReferencesForSubject(subjectName)
    suspend fun insertSubjectReference(reference: SubjectReference): Long = subjectReferenceDao.insertReference(reference)
    suspend fun updateSubjectReference(reference: SubjectReference) = subjectReferenceDao.updateReference(reference)
    suspend fun deleteSubjectReference(reference: SubjectReference) = subjectReferenceDao.deleteReference(reference)
    suspend fun deleteReferencesBySubject(subjectName: String) = subjectReferenceDao.deleteReferencesBySubject(subjectName)
    suspend fun updateSubjectReferenceName(oldName: String, newName: String) = subjectReferenceDao.updateSubjectName(oldName, newName)
    suspend fun deleteAllSubjectReferences() = subjectReferenceDao.deleteAllReferences()
}
