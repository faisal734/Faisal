package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.Course
import com.example.data.entity.TrainerTransaction
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppAdminViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainerFinancesScreen(
    viewModel: MainViewModel,
    adminViewModel: AppAdminViewModel? = null,
    showMainLayout: Boolean = true
) {
    val context = LocalContext.current
    val courses by viewModel.dbCourses.collectAsState()
    val transactions by (adminViewModel?.allTrainerTransactions ?: viewModel.dbTrainerTransactions).collectAsState()

    androidx.activity.compose.BackHandler {
        viewModel.navigateTo(Screen.Selection)
    }

    // Search and Filter States
    var searchQuery by remember { mutableStateOf("") }
    var selectedTypeFilter by remember { mutableStateOf("ALL") } // ALL, لكم, عليكم
    var selectedDateFilter by remember { mutableStateOf("TODAY") } // TODAY, THIS_WEEK, THIS_MONTH, ALL
    var selectedCourseFilterId by remember { mutableStateOf<Long?>(null) }
    var courseFilterDropdownExpanded by remember { mutableStateOf(false) }

    // Dialog state for adding new financial transaction
    var showAddFinanceDialog by remember { mutableStateOf(false) }
    var selectedCourseId by remember { mutableStateOf<Long?>(null) }
    var selectedCourseName by remember { mutableStateOf("عام (غير محددة لدورة)") }
    var amountInput by remember { mutableStateOf("") }
    val sdf = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US) }
    val todayDate = remember { sdf.format(java.util.Date()) }
    var dateInput by remember { mutableStateOf(todayDate) }
    var typeInput by remember { mutableStateOf("لكم") }
    var noteInput by remember { mutableStateOf("") }
    var courseDropdownExpanded by remember { mutableStateOf(false) }

    // Dialog state for editing financial transaction
    var editingTransaction by remember { mutableStateOf<TrainerTransaction?>(null) }
    var editAmountInput by remember { mutableStateOf("") }
    var editDateInput by remember { mutableStateOf("") }
    var editTypeInput by remember { mutableStateOf("لكم") }
    var editNoteInput by remember { mutableStateOf("") }
    var editCourseId by remember { mutableStateOf<Long?>(null) }
    var editCourseName by remember { mutableStateOf("") }

    // Dialog state for deleting financial transaction
    var deletingTransaction by remember { mutableStateOf<TrainerTransaction?>(null) }
    var showEditTransactionConfirmDialog by remember { mutableStateOf(false) }

    // Dialog state for clearing financial transactions
    var showClearFinanceConfirmDialog by remember { mutableStateOf(false) }

    // PDF Export launcher for Financial Transactions
    val coroutineScope = rememberCoroutineScope()
    val pdfFinanceReportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            if (transactions.isEmpty()) {
                Toast.makeText(context, "لا توجد معاملات مالية لتصديرها! ❌", Toast.LENGTH_SHORT).show()
            } else {
                coroutineScope.launch(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                            com.example.ui.pdf.PdfReportHelper.exportTrainerFinancesToPdf(
                                viewModel = viewModel,
                                transactions = transactions,
                                outputStream = outputStream
                            )
                        }
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "تم تصدير وحفظ تقرير المعاملات المالية بصيغة PDF بنجاح! 📄💾", Toast.LENGTH_LONG).show()
                        }
                        viewModel.logActivity(
                            category = "FINANCIAL",
                            actionType = "CREATE",
                            title = "تصدير المعاملات المالية PDF 📄",
                            description = "تم تصدير وحفظ تقرير المعاملات والمسندات المالية كملف PDF بنجاح"
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "فشل تصدير ملف PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
    }

    // Filtered financial transactions computation
    val filteredTransactions = remember(transactions, searchQuery, selectedCourseFilterId, selectedTypeFilter, selectedDateFilter) {
        val calendar = java.util.Calendar.getInstance()
        val todayStr = sdf.format(calendar.time)

        calendar.add(java.util.Calendar.DAY_OF_YEAR, -7)
        val weekAgoStr = sdf.format(calendar.time)

        calendar.time = java.util.Date()
        calendar.add(java.util.Calendar.MONTH, -1)
        val monthAgoStr = sdf.format(calendar.time)

        transactions.filter { tx ->
            val typeMatches = selectedTypeFilter == "ALL" || tx.type == selectedTypeFilter
            val dateMatches = when (selectedDateFilter) {
                "TODAY" -> tx.date == todayStr
                "THIS_WEEK" -> tx.date >= weekAgoStr
                "THIS_MONTH" -> tx.date >= monthAgoStr
                else -> true
            }
            val courseMatches = selectedCourseFilterId == null || tx.courseId == selectedCourseFilterId
            val queryMatches = searchQuery.isBlank() ||
                    tx.note.contains(searchQuery, ignoreCase = true) ||
                    tx.courseName.contains(searchQuery, ignoreCase = true) ||
                    tx.amount.toString().contains(searchQuery) ||
                    tx.date.contains(searchQuery, ignoreCase = true)

            typeMatches && dateMatches && courseMatches && queryMatches
        }.sortedByDescending { it.id }
    }

    // Finance totals
    val totalLakum = transactions.filter { it.type == "لكم" }.sumOf { it.amount }
    val totalAlaykum = transactions.filter { it.type == "عليكم" }.sumOf { it.amount }
    val netFinancialSum = totalLakum - totalAlaykum

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MainLayout(
            viewModel = viewModel,
            showScaffold = showMainLayout
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Header Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "إدارة المستحقات والسلف المالية 💰",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = DawamiNavy
                                        )
                                        Text(
                                            text = "شاشة مخصصة تماماً للمالية (سندات القبض، السلف، ومستحقات المدرب والدورات)",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(20.dp),
                                        color = DawamiTeal.copy(alpha = 0.15f),
                                        border = BorderStroke(1.dp, DawamiTeal)
                                    ) {
                                        Text(
                                            text = "الشاشة المالية",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiTeal,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                Divider(color = Color(0xFFF1F5F9))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Button(
                                        onClick = { showAddFinanceDialog = true },
                                        modifier = Modifier.weight(1f).height(34.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AddCard,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("إضافة سند مالي ➕", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }

                                    Button(
                                        onClick = {
                                            if (transactions.isEmpty()) {
                                                Toast.makeText(context, "لا توجد معاملات مالية لتصديرها! ❌", Toast.LENGTH_SHORT).show()
                                            } else if (viewModel.trainerBaseDirUri.value.isNotEmpty()) {
                                                coroutineScope.launch(Dispatchers.IO) {
                                                    val success = viewModel.savePdfReportToReportsFolder(context, "المعاملات_المالية.pdf") { outputStream ->
                                                        com.example.ui.pdf.PdfReportHelper.exportTrainerFinancesToPdf(
                                                            viewModel = viewModel,
                                                            transactions = transactions,
                                                            outputStream = outputStream
                                                        )
                                                    }
                                                    withContext(Dispatchers.Main) {
                                                        if (success) {
                                                            Toast.makeText(context, "تم حفظ تقرير المعاملات المالية تلقائياً في مجلد Reports بنجاح! 📄⚡", Toast.LENGTH_LONG).show()
                                                            viewModel.logActivity(
                                                                category = "FINANCIAL",
                                                                actionType = "CREATE",
                                                                title = "تصدير المعاملات المالية PDF 📄",
                                                                description = "تم تصدير وحفظ تقرير المعاملات والمسحوبات المالية في مجلد Reports"
                                                            )
                                                        } else {
                                                            pdfFinanceReportLauncher.launch("المعاملات_المالية.pdf")
                                                        }
                                                    }
                                                }
                                            } else {
                                                pdfFinanceReportLauncher.launch("المعاملات_المالية.pdf")
                                            }
                                        },
                                        modifier = Modifier.weight(1f).height(34.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PictureAsPdf,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تصدير PDF 📄", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }

                                    Button(
                                        onClick = { showClearFinanceConfirmDialog = true },
                                        modifier = Modifier.height(34.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "مسح المعاملات",
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Financial Summary Cards (3 Cards)
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ActivitySummaryCard(
                                modifier = Modifier.weight(1f),
                                title = "مستحقات لكم (+)",
                                value = "${formatFinanceAmountNoDecimals(totalLakum)} ر.ي",
                                subtitle = "مستحقات للمدرب",
                                icon = Icons.Default.TrendingUp,
                                iconColor = Color(0xFF059669),
                                bgContainerColor = Color(0xFFD1FAE5),
                                isSelected = selectedTypeFilter == "لكم",
                                onClick = {
                                    selectedTypeFilter = if (selectedTypeFilter == "لكم") "ALL" else "لكم"
                                }
                            )

                            ActivitySummaryCard(
                                modifier = Modifier.weight(1f),
                                title = "سلف عليكم (-)",
                                value = "${formatFinanceAmountNoDecimals(totalAlaykum)} ر.ي",
                                subtitle = "مسحوبات وسلف",
                                icon = Icons.Default.TrendingDown,
                                iconColor = Color(0xFFDC2626),
                                bgContainerColor = Color(0xFFFEE2E2),
                                isSelected = selectedTypeFilter == "عليكم",
                                onClick = {
                                    selectedTypeFilter = if (selectedTypeFilter == "عليكم") "ALL" else "عليكم"
                                }
                            )

                            ActivitySummaryCard(
                                modifier = Modifier.weight(1f),
                                title = "صافي الرصيد المالي",
                                value = "${formatFinanceAmountNoDecimals(netFinancialSum)} ر.ي",
                                subtitle = "الصافي المستحق",
                                icon = Icons.Default.AccountBalance,
                                iconColor = DawamiNavy,
                                bgContainerColor = DawamiNavy.copy(alpha = 0.1f),
                                isSelected = selectedTypeFilter == "ALL",
                                onClick = {
                                    selectedTypeFilter = "ALL"
                                }
                            )
                        }
                    }

                    // Search & Filters Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder = { Text("بحث عن مستند مالي بالبيان، الدورة، أو المبلغ...", fontSize = 11.sp) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Search,
                                            contentDescription = null,
                                            tint = DawamiNavy,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    },
                                    trailingIcon = {
                                        if (searchQuery.isNotEmpty()) {
                                            IconButton(onClick = { searchQuery = "" }) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "مسح",
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    textStyle = TextStyle(fontSize = 11.5.sp)
                                )

                                // Date Filter
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "التصفية الزمنية (التاريخ): 📅",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiNavy
                                    )
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        FilterChipPill(
                                            label = "اليوم ($todayDate) ✨",
                                            isSelected = selectedDateFilter == "TODAY",
                                            onClick = { selectedDateFilter = "TODAY" }
                                        )
                                        FilterChipPill(
                                            label = "هذا الأسبوع 📆",
                                            isSelected = selectedDateFilter == "THIS_WEEK",
                                            onClick = { selectedDateFilter = "THIS_WEEK" }
                                        )
                                        FilterChipPill(
                                            label = "هذا الشهر 🗓️",
                                            isSelected = selectedDateFilter == "THIS_MONTH",
                                            onClick = { selectedDateFilter = "THIS_MONTH" }
                                        )
                                        FilterChipPill(
                                            label = "جميع الأوقات 🌐",
                                            isSelected = selectedDateFilter == "ALL",
                                            onClick = { selectedDateFilter = "ALL" }
                                        )
                                    }
                                }

                                // Course Dropdown Filter
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "تصفية حسب الدورة: 📚",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiNavy
                                    )

                                    ExposedDropdownMenuBox(
                                        expanded = courseFilterDropdownExpanded,
                                        onExpandedChange = { courseFilterDropdownExpanded = !courseFilterDropdownExpanded }
                                    ) {
                                        Surface(
                                            modifier = Modifier.menuAnchor(),
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (selectedCourseFilterId != null) DawamiNavy.copy(alpha = 0.1f) else Color(0xFFF1F5F9),
                                            border = BorderStroke(1.dp, if (selectedCourseFilterId != null) DawamiNavy else Color(0xFFCBD5E1))
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(
                                                    text = courses.find { it.id.toLong() == selectedCourseFilterId }?.name ?: "جميع الدورات",
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = DawamiNavy
                                                )
                                                Icon(
                                                    imageVector = Icons.Default.ArrowDropDown,
                                                    contentDescription = null,
                                                    tint = DawamiNavy,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }

                                        ExposedDropdownMenu(
                                            expanded = courseFilterDropdownExpanded,
                                            onDismissRequest = { courseFilterDropdownExpanded = false }
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text("جميع الدورات (الكل)", fontSize = 11.sp) },
                                                onClick = {
                                                    selectedCourseFilterId = null
                                                    courseFilterDropdownExpanded = false
                                                }
                                            )
                                            courses.forEach { course ->
                                                DropdownMenuItem(
                                                    text = { Text(course.name, fontSize = 11.sp) },
                                                    onClick = {
                                                        selectedCourseFilterId = course.id.toLong()
                                                        courseFilterDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                // Type Filter Chips
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "تصفية حسب نوع المعاملة: 🏷️",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiNavy
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        FilterChipPill(
                                            label = "جميع الأنواع",
                                            isSelected = selectedTypeFilter == "ALL",
                                            onClick = { selectedTypeFilter = "ALL" }
                                        )
                                        FilterChipPill(
                                            label = "لكم (مستحقات) 📈",
                                            isSelected = selectedTypeFilter == "لكم",
                                            onClick = { selectedTypeFilter = "لكم" }
                                        )
                                        FilterChipPill(
                                            label = "عليكم (سلف) 📉",
                                            isSelected = selectedTypeFilter == "عليكم",
                                            onClick = { selectedTypeFilter = "عليكم" }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Section Title
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "قائمة السندات والمعاملات المالية (${filteredTransactions.size}) 💳",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = DawamiNavy
                                )
                                Text(
                                    text = if (selectedDateFilter == "TODAY") "عرض معاملات اليوم الحالي ($todayDate)" else "عرض المعاملات المفلترة",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }

                            if (searchQuery.isNotEmpty() || selectedTypeFilter != "ALL" || selectedDateFilter != "TODAY" || selectedCourseFilterId != null) {
                                TextButton(
                                    onClick = {
                                        searchQuery = ""
                                        selectedTypeFilter = "ALL"
                                        selectedDateFilter = "TODAY"
                                        selectedCourseFilterId = null
                                    },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Text("إعادة ضبط الفلاتر 🔄", fontSize = 10.5.sp, color = Color(0xFF2563EB))
                                }
                            }
                        }
                    }

                    // Transactions List
                    if (filteredTransactions.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AccountBalanceWallet,
                                        contentDescription = null,
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(38.dp)
                                    )
                                    Text(
                                        text = if (selectedDateFilter == "TODAY") "لا توجد معاملات مالية مسجلة لليوم الحالي ($todayDate)" else "لا توجد معاملات مالية مطابقة للبحث.",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiNavy,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "يمكنك إضافة مستند مالي جديد عبر زر 'إضافة سند مالي'.",
                                        fontSize = 10.5.sp,
                                        color = Color.Gray,
                                        textAlign = TextAlign.Center
                                    )
                                    if (selectedDateFilter == "TODAY") {
                                        Button(
                                            onClick = { selectedDateFilter = "ALL" },
                                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("عرض معاملات جميع الأوقات 🗓️", fontSize = 11.sp, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        items(filteredTransactions, key = { it.id }) { tx ->
                            FinancialTransactionCard(
                                transaction = tx,
                                onEdit = {
                                    editingTransaction = tx
                                    editAmountInput = tx.amount.toString()
                                    editDateInput = tx.date
                                    editTypeInput = tx.type
                                    editNoteInput = tx.note
                                    editCourseId = tx.courseId
                                    editCourseName = tx.courseName
                                },
                                onDelete = { deletingTransaction = tx }
                            )
                        }
                    }
                }
            }
        }
    }

    // --- DIALOG 1: Add Financial Document Dialog ---
    if (showAddFinanceDialog) {
        AlertDialog(
            onDismissRequest = { showAddFinanceDialog = false },
            title = {
                Text(
                    text = "إضافة مستند / حركة مالية 💰",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = courseDropdownExpanded,
                        onExpandedChange = { courseDropdownExpanded = !courseDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedCourseName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("الدورة", fontSize = 11.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = courseDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = TextStyle(fontSize = 11.sp)
                        )
                        ExposedDropdownMenu(
                            expanded = courseDropdownExpanded,
                            onDismissRequest = { courseDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("عام (غير محددة لدورة)", fontSize = 11.sp) },
                                onClick = {
                                    selectedCourseId = null
                                    selectedCourseName = "عام (غير محددة لدورة)"
                                    courseDropdownExpanded = false
                                }
                            )
                            courses.forEach { course ->
                                DropdownMenuItem(
                                    text = { Text(course.name, fontSize = 11.sp) },
                                    onClick = {
                                        selectedCourseId = course.id.toLong()
                                        selectedCourseName = course.name
                                        courseDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = amountInput,
                            onValueChange = { amountInput = it },
                            label = { Text("المبلغ (ر.ي)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = TextStyle(fontSize = 11.sp)
                        )

                        OutlinedTextField(
                            value = dateInput,
                            onValueChange = { dateInput = it },
                            label = { Text("التاريخ", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = TextStyle(fontSize = 11.sp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("النوع:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { typeInput = "لكم" },
                            shape = RoundedCornerShape(8.dp),
                            color = if (typeInput == "لكم") Color(0xFF10B981) else Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, if (typeInput == "لكم") Color(0xFF047857) else Color(0xFFCBD5E1))
                        ) {
                            Text(
                                text = "لكم (مستحق)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (typeInput == "لكم") Color.White else Color.DarkGray,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { typeInput = "عليكم" },
                            shape = RoundedCornerShape(8.dp),
                            color = if (typeInput == "عليكم") Color(0xFFEF4444) else Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, if (typeInput == "عليكم") Color(0xFFB91C1C) else Color(0xFFCBD5E1))
                        ) {
                            Text(
                                text = "عليكم (سلفة)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (typeInput == "عليكم") Color.White else Color.DarkGray,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = noteInput,
                        onValueChange = { noteInput = it },
                        label = { Text("ملاحظة / البيان (اختياري)", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = TextStyle(fontSize = 11.sp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountInput.toDoubleOrNull()
                        if (amt == null || amt <= 0.0) {
                            Toast.makeText(context, "الرجاء إدخال مبلغ صحيح", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (adminViewModel != null) {
                            adminViewModel.addTrainerTransaction(
                                courseId = selectedCourseId ?: 0L,
                                courseName = selectedCourseName,
                                amount = amt,
                                date = dateInput.trim(),
                                type = typeInput,
                                note = noteInput.trim()
                            )
                        } else {
                            viewModel.addTrainerTransaction(
                                courseId = selectedCourseId ?: 0L,
                                courseName = selectedCourseName,
                                amount = amt,
                                date = dateInput.trim(),
                                type = typeInput,
                                note = noteInput.trim()
                            )
                        }
                        Toast.makeText(context, "تم إضافة الحركة المالية وتسجيلها بنجاح ➕", Toast.LENGTH_SHORT).show()
                        showAddFinanceDialog = false
                        amountInput = ""
                        noteInput = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ المستند", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddFinanceDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // --- DIALOG 2: Edit Financial Document Dialog ---
    if (editingTransaction != null) {
        var editCourseDropdownExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { editingTransaction = null },
            title = {
                Text(
                    text = "تعديل المستند المالي ✏️",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = editCourseDropdownExpanded,
                        onExpandedChange = { editCourseDropdownExpanded = !editCourseDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = editCourseName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("الدورة التدريبية المرتبطة", fontSize = 11.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = editCourseDropdownExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = TextStyle(fontSize = 11.sp)
                        )

                        ExposedDropdownMenu(
                            expanded = editCourseDropdownExpanded,
                            onDismissRequest = { editCourseDropdownExpanded = false }
                        ) {
                            courses.forEach { course ->
                                DropdownMenuItem(
                                    text = { Text(course.name, fontSize = 11.sp) },
                                    onClick = {
                                        editCourseId = course.id.toLong()
                                        editCourseName = course.name
                                        editCourseDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = editAmountInput,
                        onValueChange = { editAmountInput = it },
                        label = { Text("المبلغ (ر.ي)", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = TextStyle(fontSize = 11.sp)
                    )

                    OutlinedTextField(
                        value = editDateInput,
                        onValueChange = { editDateInput = it },
                        label = { Text("التاريخ (YYYY-MM-DD)", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = TextStyle(fontSize = 11.sp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f).clickable { editTypeInput = "لكم" },
                            shape = RoundedCornerShape(8.dp),
                            color = if (editTypeInput == "لكم") Color(0xFF10B981) else Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, if (editTypeInput == "لكم") Color(0xFF047857) else Color(0xFFCBD5E1))
                        ) {
                            Text(
                                text = "لكم (مستحق)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (editTypeInput == "لكم") Color.White else Color.DarkGray,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }

                        Surface(
                            modifier = Modifier.weight(1f).clickable { editTypeInput = "عليكم" },
                            shape = RoundedCornerShape(8.dp),
                            color = if (editTypeInput == "عليكم") Color(0xFFEF4444) else Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, if (editTypeInput == "عليكم") Color(0xFFB91C1C) else Color(0xFFCBD5E1))
                        ) {
                            Text(
                                text = "عليكم (سلفة)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (editTypeInput == "عليكم") Color.White else Color.DarkGray,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = editNoteInput,
                        onValueChange = { editNoteInput = it },
                        label = { Text("ملاحظة / البيان (اختياري)", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = TextStyle(fontSize = 11.sp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = editAmountInput.toDoubleOrNull()
                        val tx = editingTransaction
                        if (amt == null || amt <= 0.0 || tx == null) {
                            Toast.makeText(context, "الرجاء إدخال مبلغ صحيح", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val updatedTx = tx.copy(
                            courseId = editCourseId ?: tx.courseId,
                            courseName = editCourseName,
                            amount = amt,
                            date = editDateInput.trim(),
                            type = editTypeInput,
                            note = editNoteInput.trim()
                        )
                        showEditTransactionConfirmDialog = true
                        if (!showEditTransactionConfirmDialog) Toast.makeText(context, "تم تعديل الحركة المالية بنجاح ✏️", Toast.LENGTH_SHORT).show()
                        if (showEditTransactionConfirmDialog) { /* do nothing */ } else editingTransaction = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ التعديلات", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingTransaction = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // --- DIALOG 3: Delete Financial Document Confirmation ---
    if (deletingTransaction != null) {
        val txToDelete = deletingTransaction
        AlertDialog(
            onDismissRequest = { deletingTransaction = null },
            title = {
                Text("حذف المستند المالي ⚠️", fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
            },
            text = {
                Text("هل أنت تأكد من رغبتك في حذف المعاملة المالية بالمبلغ (${txToDelete?.amount ?: 0.0} ر.ي)؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (txToDelete != null) {
                            if (adminViewModel != null) {
                                adminViewModel.deleteTrainerTransaction(txToDelete)
                            } else {
                                viewModel.deleteTrainerTransaction(txToDelete)
                            }
                            Toast.makeText(context, "تم حذف المعاملة المالية 🗑️", Toast.LENGTH_SHORT).show()
                        }
                        deletingTransaction = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("تأكيد الحذف", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingTransaction = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // --- DIALOG 3.5: Edit Financial Document Confirmation ---
    if (showEditTransactionConfirmDialog && editingTransaction != null) {
        val originalTx = editingTransaction!!
        AlertDialog(
            onDismissRequest = { showEditTransactionConfirmDialog = false },
            title = {
                Text("تأكيد تعديل المستند المالي 💰", fontWeight = FontWeight.Bold, color = DawamiNavy)
            },
            text = {
                Text("هل أنت متأكد من رغبتك في حفظ التعديلات الجديدة على هذا المستند المالي؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = editAmountInput.toDoubleOrNull() ?: 0.0
                        val updatedTx = originalTx.copy(
                            courseId = editCourseId ?: originalTx.courseId,
                            courseName = editCourseName,
                            amount = amt,
                            date = editDateInput.trim(),
                            type = editTypeInput,
                            note = editNoteInput.trim()
                        )
                        if (adminViewModel != null) {
                            adminViewModel.updateTrainerTransaction(updatedTx)
                        } else {
                            viewModel.updateTrainerTransaction(updatedTx)
                        }
                        Toast.makeText(context, "تم تعديل المستند المالي بنجاح! ✨", Toast.LENGTH_SHORT).show()
                        showEditTransactionConfirmDialog = false
                        editingTransaction = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("تأكيد وحفظ", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditTransactionConfirmDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // --- DIALOG 4: Clear Financial Transactions Confirmation ---
    if (showClearFinanceConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearFinanceConfirmDialog = false },
            title = {
                Text("تفريغ المعاملات المالية ⚠️", fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
            },
            text = {
                Text("هل أنت تأكد من رغبتك في مسح وتفريغ كافة السندات والمعاملات المالية المسجلة؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (adminViewModel != null) {
                            adminViewModel.wipeTrainerFinances()
                        } else {
                            viewModel.wipeTrainerFinances()
                        }
                        Toast.makeText(context, "تم تفريغ كافة المعاملات المالية بنجاح 🧹", Toast.LENGTH_SHORT).show()
                        showClearFinanceConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("تأكيد المسح", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearFinanceConfirmDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun FinancialTransactionCard(
    transaction: TrainerTransaction,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (transaction.type == "لكم") Color(0xFFD1FAE5) else Color(0xFFFEE2E2)
                    ) {
                        Text(
                            text = if (transaction.type == "لكم") "مستحق (+)" else "سلفة (-)",
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (transaction.type == "لكم") Color(0xFF047857) else Color(0xFFB91C1C),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = "${formatFinanceAmountNoDecimals(transaction.amount)} ر.ي",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = DawamiNavy
                    )
                }

                Text(
                    text = "الدورة: ${transaction.courseName}",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.DarkGray
                )

                if (transaction.note.isNotBlank()) {
                    Text(
                        text = "البيان: ${transaction.note}",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }

                Text(
                    text = "التاريخ: ${transaction.date}",
                    fontSize = 9.sp,
                    color = Color.Gray
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = DawamiNavy, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

