package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppHeader
import com.example.ui.components.DawamiBottomNavigationBar
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

data class AppFeatureItem(
    val id: String,
    val category: String,
    val icon: ImageVector,
    val title: String,
    val badgeText: String,
    val badgeColor: Color,
    val description: String,
    val highlights: List<String>,
    val targetScreen: Screen? = null
)

data class InstructionStep(
    val title: String,
    val detail: String
)

data class InstructionModule(
    val id: String,
    val icon: ImageVector,
    val stepNumber: String,
    val title: String,
    val intro: String,
    val steps: List<InstructionStep>,
    val tip: String,
    val targetScreen: Screen
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppFeaturesGuideScreen(viewModel: MainViewModel, showMainLayout: Boolean = true) {
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val notifications by viewModel.inAppNotifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()

    if (showMainLayout) {
        BackHandler {
            if (isLoggedIn) {
                viewModel.navigateTo(Screen.Selection)
            } else {
                viewModel.navigateBack()
            }
        }
    }

    // Comprehensive updated features data
    val allFeatures = remember {
        listOf(
            // Category 1: الحضور والغياب الذكي
            AppFeatureItem(
                id = "att_smart_checkin",
                category = "الحضور والغياب",
                icon = Icons.Default.HowToReg,
                title = "التحضير الذكي ومطابقة الوقت الفعلي ⏱️",
                badgeText = "رصد وتحقق ذكي",
                badgeColor = Color(0xFF0D9488),
                description = "نظام متقدم لرصد حضور الطلاب (جماعياً أو فردياً أو للمحددين) مع التحقق الذكي من التوقيت الفعلي.",
                highlights = listOf(
                    "مقارنة ذكية بين وقت بداية الدورة الافتراضي ووقت أداة الوقت مع خيار اعتماد أحدهما",
                    "رصد حضور (الآن) بالوقت الفعلي الحالي من الجهاز مع تقييم فارق الدقائق (مبكر / متأخر)",
                    "رصد جماعي بنقرة واحدة لجميع طلاب القاعة وتوفير الوقت في بداية الدرس",
                    "حاسبة فورية لإجمالي الحاضرين والغائبين ونسب الانضباط اللحظية"
                ),
                targetScreen = Screen.StudentAttendance
            ),
            AppFeatureItem(
                id = "att_smart_checkout",
                category = "الحضور والغياب",
                icon = Icons.Default.Schedule,
                title = "الانصراف الذكي ومعالجة غير المسجلين 🚪",
                badgeText = "انصراف آلي متكامل",
                badgeColor = Color(0xFF2563EB),
                description = "تسجيل انصراف متقدم للطلاب والمدرب مع معالجة ذكية للطلاب الذين لم يسجلوا حضوراً اليوم.",
                highlights = listOf(
                    "عرض قائمة بأسماء الطلاب غير المسجلين اليوم لاتخاذ القرار المناسب بشأنهم",
                    "خيار اعتماد تسجيل غياب رسمي للطلاب غير المسجلين أو إبقاؤهم بدون حركة",
                    "ربط تلقائي لانصراف المدرب مع انصراف الطلاب في حركة واحدة متناسقة",
                    "إمكانية تحديد مجموعة طلاب وتطبيق الانصراف المباشر عليهم فقط"
                ),
                targetScreen = Screen.StudentAttendance
            ),
            AppFeatureItem(
                id = "att_whatsapp_alerts",
                category = "الحضور والغياب",
                icon = Icons.Default.Send,
                title = "تنبيهات الواتساب الفورية والعقوبات اللطيفة 📱💬",
                badgeText = "تواصل وانضباط",
                badgeColor = Color(0xFF16A34A),
                description = "ربط مباشر بالواتساب لإبلاغ أولياء الأمور فورياً، مع قائمة عقوبات فكاهية لضبط التأخير بروح تربوية.",
                highlights = listOf(
                    "فتح محادثة واتساب ولي الأمر بضغطة زر مع رسالة مهيأة مسبقاً باسم الطالب والتاريخ",
                    "توثيق حالة الإرسال في سجل الطالب لمنع تكرار الإرسال بالخطأ",
                    "قائمة عقوبات فكاهية ولطيفة (مثل تلخيص فقرة أو إلقاء حكمة) لتعزيز الانضباط بود",
                    "حفظ أرقام أولياء الأمور في ملف الطالب للوصول الفوري في أي لحظة"
                ),
                targetScreen = Screen.StudentAttendance
            ),
            AppFeatureItem(
                id = "att_trainer_sync",
                category = "الحضور والغياب",
                icon = Icons.Default.AccountTree,
                title = "حركات دوام المدرب وربطها التلقائي 👨‍🏫",
                badgeText = "توثيق معتمد",
                badgeColor = Color(0xFF7C3AED),
                description = "سجل دوام يومي مستقل للمدرب يوثق أوقات الحضور والانصراف ويرتبط تلقائياً بمستحقات الساعات وكشوفات الـ PDF.",
                highlights = listOf(
                    "توثيق دقيق لحضور وانصراف المدرب لكل دورة تدريبية ومادة",
                    "مزامنة انصراف المدرب مع انصراف طلابه لضمان اكتمال السجلات الرسمية",
                    "احتساب عدد الساعات الفعلية المنفذة لكل محاضرة وتجميعها في كشف الحساب",
                    "ظهور توقيت دوام المدرب في الترويسة الرسمية لكشوفات المعهد المعتمدة"
                ),
                targetScreen = Screen.Attendance
            ),

            // Category 2: المناهج والتحضير
            AppFeatureItem(
                id = "curr_tree",
                category = "المناهج والتحضير",
                icon = Icons.Default.AccountTree,
                title = "بنك مواضيع المادة بهيكلية مستويين 🌳",
                badgeText = "هيكلية مرنة ومطورة",
                badgeColor = Color(0xFF0284C7),
                description = "تنظيم متكامل للمفردات والمناهج التعليمية في شجرة مواضيع رئيسية وفرعية لتسهيل المتابعة.",
                highlights = listOf(
                    "هيكلية مستويين: مستوى 1 (رئيسي) ومستوى 2 (فرعي م2) لتقسيم دقيق للمفردات",
                    "خاصية الطي والتوسيع الذكية لكل موضوع رئيسي مع إمكانية إضافة وحذف وتعديل المواضيع",
                    "أزرار سريعة للتحكم: (توسيع الكل 🔽) و (طي الكل 🔼) لتصفح مرن بدون إرباك",
                    "ربط المواضيع بالدورات والمواد دون الحاجة لإعادة كتابة المحتوى يدوياً"
                ),
                targetScreen = Screen.Subjects
            ),
            AppFeatureItem(
                id = "curr_references",
                category = "المناهج والتحضير",
                icon = Icons.Default.LibraryBooks,
                title = "إدارة المراجع والمصادر الإثرائية للمواد 📚🔗",
                badgeText = "مكتبة أكاديمية",
                badgeColor = Color(0xFFF59E0B),
                description = "إرفاق المصادر والروابط والمذكرات لكل مادة دراسية على حدة لتسهيل الرجوع إليها ومشاركتها.",
                highlights = listOf(
                    "إضافة مراجع بصيغة روابط ويب (URL) أو ملفات ومستندات وصور محلية",
                    "تصنيف المراجع (كتاب، مذكرة، رابط ويب إثرائي، ملخص، إلخ)",
                    "مشاركة المراجع مباشرة مع الطلاب عبر تطبيقات التواصل الاجتماعي",
                    "أرشفة دائمة للمصادر مرتبطة باسم المادة الأكاديمية"
                ),
                targetScreen = Screen.SubjectReferences
            ),
            AppFeatureItem(
                id = "curr_prep",
                category = "المناهج والتحضير",
                icon = Icons.Default.MenuBook,
                title = "تحضير الدروس ومتابعة نسبة إنجاز المنهج 📖✍️",
                badgeText = "متابعة الخطة الزمنية",
                badgeColor = Color(0xFF059669),
                description = "توثيق الدروس المشروحة يومياً وتشطيبها من شجرة المناهج مع حساب نسبة التغطية التراكمية.",
                highlights = listOf(
                    "تحديد المواضيع المشروحة في كل جلسة مع تسجيل التاريخ والتوقيت بالدقيقة",
                    "شريط تقدم ذكي يوضح النسبة المئوية الدقيقة لتغطية مفردات المنهج",
                    "توثيق الملاحظات والتوجيهات التربوية لكل موضوع مشروح",
                    "كشف تحضير دروس تراكمي معتمد للطباعة ومطابقة الخطط الأكاديمية"
                ),
                targetScreen = Screen.LessonPreparation
            ),

            // Category 3: الاختبارات والتكليفات
            AppFeatureItem(
                id = "eval_exams",
                category = "الاختبارات والتكليفات",
                icon = Icons.Default.Quiz,
                title = "مصحح الاختبارات النظرية والتحريرية 💯",
                badgeText = "حساب تقديرات فوري",
                badgeColor = Color(0xFF7C3AED),
                description = "نظام متكامل لرصد درجات الاختبارات التحريرية والتطبيقية مع حساب النسب والتقديرات آلياً.",
                highlights = listOf(
                    "رصد الدرجة المستحقة من الدرجة العظمى مع مرونة كاملة في التعديل",
                    "حساب التقديرات الآلية المعتمدة (ممتاز، جيد جداً، جيد، مقبول، راسب)",
                    "حساب النسبة المئوية لكل طالب مع إبراز أعلى وأقل الدرجات في القاعة",
                    "تصدير سجل درجات الطلاب الرسمي في ملف PDF معتمد للطباعة"
                ),
                targetScreen = Screen.TheoryExamGrader
            ),
            AppFeatureItem(
                id = "eval_assignments",
                category = "الاختبارات والتكليفات",
                icon = Icons.Default.Assignment,
                title = "إعداد التكليفات والواجبات المنزلية ومتابعتها 📄🔍",
                badgeText = "تقييم عملي دقيق",
                badgeColor = Color(0xFFD97706),
                description = "إنشاء المهام والتكليفات لكل مادة وتوثيق تسليمات الطلاب وتقييم جودة الإنجاز.",
                highlights = listOf(
                    "تخصيص الواجبات والتمارين لكل دورة مع تحديد تاريخ الاستحقاق المطلوب",
                    "رصد استلام الواجب لكل طالب (تم التسليم، متأخر، لم يسلم)",
                    "تقييم جودة الحل بملاحظات دقيقة لإبقاء الطلاب تحت المتابعة المستمرة",
                    "كشف متابعة تسليمات الواجبات لكافة طلاب الشعبة بلمحة واحدة"
                ),
                targetScreen = Screen.AssignmentSetup
            ),
            AppFeatureItem(
                id = "eval_violations",
                category = "الاختبارات والتكليفات",
                icon = Icons.Default.Warning,
                title = "سجل الملاحظات والمخالفات السلوكية ⚠️",
                badgeText = "انضباط وسلوك",
                badgeColor = Color(0xFFDC2626),
                description = "أداة توثيق للملاحظات السلوكية والانضباطية للطلاب لضمان بيئة تعليمية هادئة وجادة.",
                highlights = listOf(
                    "تسجيل الملاحظات السلوكية مع نوع المخالفة والتاريخ والإجراء المتخذ",
                    "ربط المخالفات بملف الطالب لمراجعتها عند التقييم النهائي",
                    "إمكانية إشعار ولي الأمر هاتفياً أو عبر الواتساب عند الحاجة",
                    "سجل تاريخي يتيح للمدرب متابعة تحسن سلوك الطالب بمرور الوقت"
                ),
                targetScreen = Screen.StudentViolations
            ),

            // Category 4: التقارير و PDF
            AppFeatureItem(
                id = "rep_official_pdf",
                category = "التقارير و PDF",
                icon = Icons.Default.PictureAsPdf,
                title = "كشوفات PDF رسمية معتمدة للطباعة 🖨️📄",
                badgeText = "هوية أكاديمية رسمية",
                badgeColor = Color(0xFFDC2626),
                description = "طباعة وتصدير كافة الكشوفات بصيغة PDF أنيقة تتضمن الترويسة الكاملة وشعار المعهد والتوقيعات.",
                highlights = listOf(
                    "ترويسة المعهد الرسمية (شعار المعهد، اسم المؤسسة، القسم، الدبلوم، المادة)",
                    "بلوك التوقيعات الثلاثية المعتمدة (المدرب، المشرف الأكاديمي، شؤون الطلاب)",
                    "كشوفات حضور وغياب شهرية ودورية مع تفقيط الإحصائيات بدقة",
                    "تصدير فوري ومشاركة سهلة ومباشرة عبر الواتساب والبريد وتطبيقات الطباعة"
                ),
                targetScreen = Screen.Reports
            ),
            AppFeatureItem(
                id = "rep_student_details",
                category = "التقارير و PDF",
                icon = Icons.Default.Analytics,
                title = "تقارير الحضور والدرجات التفصيلية للطلاب 📊",
                badgeText = "كشوفات متخصصة",
                badgeColor = Color(0xFF0284C7),
                description = "استخراج تقارير تفصيلية لكل طالب أو لكل شعبة مع إمكانية الفلترة بالدورة والتواريخ.",
                highlights = listOf(
                    "تقرير حضور تفصيلي يوضح كل يوم دوام وحالة الطالب وساعة دخوله وخروجه",
                    "حاسبة معدل الغياب التراكمي وتنبيهات الحرمان الأكاديمي للطلاب",
                    "كشف الدرجات الفصلي والنهائي جاهز للمطابقة والتسليم لشؤون الطلاب",
                    "طباعة إشعار أداء فردي لكل طالب لمشاركته مع ولي الأمر"
                ),
                targetScreen = Screen.StudentReports
            ),

            // Category 5: المالية والأمان
            AppFeatureItem(
                id = "sys_trainer_finances",
                category = "المالية والأمان",
                icon = Icons.Default.AccountBalanceWallet,
                title = "كشف حساب المدرب والمسحوبات والسلف 💰📊",
                badgeText = "مطابقة مالية دقيقة",
                badgeColor = Color(0xFF059669),
                description = "متابعة السلف والمكافآت وحساب صافي مستحقات المدرب تلقائياً بعد خصم المسحوبات.",
                highlights = listOf(
                    "تسجيل العهد والمسحوبات والسلف بالمبلغ والتاريخ والبيان السندي",
                    "حساب تلقائي لصافي المستحقات (إجمالي مستحق الساعات المنفذة - المسحوبات)",
                    "كشف حساب مالي شفاف ومفصل موثق للطباعة بصيغة PDF",
                    "مطابقة فورية مع إدارة الحسابات في المعهد بدون أي فوارق حسابية"
                ),
                targetScreen = Screen.TrainerFinances
            ),
            AppFeatureItem(
                id = "sys_teaching_stats",
                category = "المالية والأمان",
                icon = Icons.Default.Assessment,
                title = "مؤشرات الأداء وإحصائيات التدريس 📈",
                badgeText = "لوحة تحليلية بصرية",
                badgeColor = Color(0xFF4338CA),
                description = "لوحة مؤشرات إحصائية تلخص أداء التدريس وساعات العمل الفعلية ومعدلات الانضباط.",
                highlights = listOf(
                    "إحصائيات دقيقة لعدد المحاضرات والساعات المنفذة لكل دورة ومادة",
                    "مؤشرات انضباط القاعة ومعدل الحضور والغياب التراكمي للطلاب",
                    "متابعة التقدم في الخطة الزمنية للمناهج ومقارنتها بالجدول المقرر",
                    "مخططات ورسوم توضيحية تسهل تقييم الأداء الفصلي للمدرب"
                ),
                targetScreen = Screen.TeachingStats
            ),
            AppFeatureItem(
                id = "sys_security_backup",
                category = "المالية والأمان",
                icon = Icons.Default.CloudSync,
                title = "النسخ الاحتياطي والأمان والوضع الداكن 🛡️🌙",
                badgeText = "حماية كاملة للبيانات",
                badgeColor = Color(0xFF374151),
                description = "حماية فائقة لبياناتك مع إمكانية تصدير واسترجاع قاعدة البيانات في ثوانٍ، وتأمين بالبصمة.",
                highlights = listOf(
                    "إنشاء وتصدير نسخة احتياطية كاملة من قاعدة البيانات وحفظها بأمان",
                    "استعادة النسخة الاحتياطية بسهولة دون فقدان أي سجلات أو درجات",
                    "تأمين التطبيق وتسجيل الدخول السريع ببصمة الإصبع",
                    "وضع ليلي / داكن (Dark Mode) كامل مريح للعين أثناء العمل الليلي"
                ),
                targetScreen = Screen.BackupRestore
            ),
            AppFeatureItem(
                id = "sys_branding_alarms",
                category = "المالية والأمان",
                icon = Icons.Default.NotificationsActive,
                title = "هوية المعهد والمنبهات الذكية 🏫🔔",
                badgeText = "تخصيص وتنبيه ذكي",
                badgeColor = Color(0xFFEA580C),
                description = "تخصيص بيانات وهوية المعهد واللوجو، مع منبهات ذكية تنبهك بمواعيد المحاضرات ورصد الانصراف.",
                highlights = listOf(
                    "رفع وتحديث شعار المعهد واسم المؤسسة وبيانات القادة للتوقيعات",
                    "تنبيهات صوتية ذكية قبل بدء الدورة بـ 10 أو 15 دقيقة للتجهيز",
                    "تذكير تلقائي برصد انصراف الطلاب في نهاية وقت المحاضرة",
                    "سجل تنبيهات داخلي لمراجعة كافة الإشعارات الصادرة في أي وقت"
                ),
                targetScreen = Screen.InstituteSettings
            )
        )
    }

    // Categories list for Tab 0
    val categories = remember {
        listOf("الحضور والغياب", "المناهج والتحضير", "الاختبارات والتكليفات", "التقارير و PDF", "المالية والأمان")
    }

    var selectedCategory by remember { mutableStateOf("الحضور والغياب") }

    // Features belonging to selected category
    val currentCategoryFeatures = remember(selectedCategory, allFeatures) {
        allFeatures.filter { it.category == selectedCategory }
    }

    // Index of the selected feature within the current category
    var selectedFeatureIndex by remember(selectedCategory) { mutableIntStateOf(0) }

    // Ensure index is within bounds
    val safeFeatureIndex = if (currentCategoryFeatures.isNotEmpty()) {
        selectedFeatureIndex.coerceIn(0, currentCategoryFeatures.size - 1)
    } else 0

    val currentFeature = currentCategoryFeatures.getOrNull(safeFeatureIndex)

    // Interactive Walkthrough Modules for Tab 1
    val instructionModules = remember {
        listOf(
            InstructionModule(
                id = "walk_setup",
                icon = Icons.Default.VpnKey,
                stepNumber = "١",
                title = "التأسيس وهوية المعهد والأمان",
                intro = "الخطوات الأساسية لتفعيل نسختك وضبط الهوية الرسمية لك ولمعهدك في كافة الكشوفات.",
                steps = listOf(
                    InstructionStep("تفعيل الترخيص", "أدخل كود التفعيل السنوي المعتمد الممنوح لك لفتح كامل خصائص النظام بنجاح."),
                    InstructionStep("الملف الشخصي", "سجّل اسمك وبياناتك المهنية لتظهر تلقائياً في خانة المدرب بكافة المخرجات."),
                    InstructionStep("هوية المعهد", "ارفع شعار المعهد واسم المؤسسة وحدد أسماء المشرفين للتوقيعات الثلاثية المعتمدة."),
                    InstructionStep("أمان النظام", "فعّل الدخول السريع بالبصمة وأنشئ نسخة احتياطية أولية لبياناتك بضغطة زر.")
                ),
                tip = "أي تعديل تجريه على بيانات المعهد أو الشعار ينعكس فوراً وتلقائياً على كافة التقارير السابقة والجديدة.",
                targetScreen = Screen.InstituteSettings
            ),
            InstructionModule(
                id = "walk_courses",
                icon = Icons.Default.School,
                stepNumber = "٢",
                title = "تهيئة الدورات والمناهج والطلاب",
                intro = "تنظيم الفصول الدراسية، وبناء شجرة المفردات الدراسية، وقيد بيانات الطلاب للتواصل.",
                steps = listOf(
                    InstructionStep("إنشاء الدورة", "حدد المسمى الأكاديمي، وتاريخ البدء والانتهاء، والتوقيت اليومي الرسمي للدورة."),
                    InstructionStep("إضافة الطلاب", "أدخل أسماء الطلاب وأرقام هواتفهم لتفعيل مراسلة أولياء الأمور السريعة عبر الواتساب."),
                    InstructionStep("شجرة المناهج", "أنشئ بنك مواضيع المادة بمستويين (رئيسي وفرعي م2) واستخدم أزرار طي/توسيع الكل."),
                    InstructionStep("المراجع الإثرائية", "اربط المراجع والمستندات والروابط بكل مادة لتسهيل مشاركتها مع الطلاب.")
                ),
                tip = "خاصية (توسيع الكل / طي الكل) في شاشة المواضيع تجعل تصفح شجرة المناهج الطويلة في غاية السلاسة والسرعة.",
                targetScreen = Screen.Courses
            ),
            InstructionModule(
                id = "walk_attendance",
                icon = Icons.Default.HowToReg,
                stepNumber = "٣",
                title = "حافظة الدوام والرصد الذكي",
                intro = "إثبات حضور وانصراف القاعة بدقة متناهية، ومطابقة التوقيت، والتواصل مع أولياء الأمور.",
                steps = listOf(
                    InstructionStep("فتح الحافظة", "اختر الدورة التدريبية وسيقوم النظام تلقائياً بتحميل كشف طلاب الشعبة وتاريخ اليوم."),
                    InstructionStep("التحضير الذكي", "استخدم الرصد السريع؛ يفحص النظام مطابقة وقت الدورة أو اعتماد وقت (الآن) الفعلي."),
                    InstructionStep("تنبيه الواتساب", "اضغط أيقونة الواتساب بجانب الطالب الغائب لإرسال رسالة جاهزة لولي أمره بنقرة واحدة."),
                    InstructionStep("الانصراف الذكي", "سجّل الانصراف مع خيار رصد غياب للطلاب غير المسجلين وربط انصراف المدرب آلياً.")
                ),
                tip = "التحضير الذكي يحسب فارق الدقائق بين وقت الحضور الفعلي ووقت بداية الدورة ويقيمه تلقائياً (مبكر/متأخر).",
                targetScreen = Screen.StudentAttendance
            ),
            InstructionModule(
                id = "walk_prep_exams",
                icon = Icons.Default.MenuBook,
                stepNumber = "٤",
                title = "تحضير الدروس وتصحيح الاختبارات",
                intro = "توثيق التغطية الأكاديمية للمنهج، وتصحيح الاختبارات التحريرية، ومتابعة الواجبات.",
                steps = listOf(
                    InstructionStep("توثيق الدرس", "اختر الموضوع المشروح من الشجرة ليتم تشطيبه وحساب ساعات الشرح المنفذة."),
                    InstructionStep("مؤشر الإنجاز", "راقب شريط التغطية الفعلي للمنهج الذي يرتفع آلياً كلما أنجزت مفردات جديدة."),
                    InstructionStep("مصحح الاختبارات", "رصد درجات الاختبارات التحريرية ليقوم النظام باحتساب التقديرات والنسبة آلياً."),
                    InstructionStep("متابعة التكليفات", "سجل استلام الواجبات المنزلية وقيم جودة الحل لمتابعة الجدية المستمرة للطلاب.")
                ),
                tip = "مصحح الاختبارات يصنف تقديرات الطلاب تلقائياً (ممتاز، جيد جداً، ..) مع حفظ السجل للطباعة الفورية.",
                targetScreen = Screen.LessonPreparation
            ),
            InstructionModule(
                id = "walk_reports_finance",
                icon = Icons.Default.PictureAsPdf,
                stepNumber = "٥",
                title = "التقارير الرسمية PDF والمالية",
                intro = "استخراج الكشوفات المعتمدة الجاهزة للطباعة، ومطابقة السلف والمستحقات، والأمان.",
                steps = listOf(
                    InstructionStep("تصدير PDF", "اختر كشف الحضور الشهري أو سجل الدرجات واضغط تصدير PDF معتمد بالترويسة."),
                    InstructionStep("كشف حساب المدرب", "سجل السلف والمسحوبات ليتم خصمها من مستحقات الساعات وحساب الصافي بدقة."),
                    InstructionStep("لوحة الإحصائيات", "راجع إحصائيات ساعات العمل الفعلية المنفذة ونسب انضباط القاعات التراكمية."),
                    InstructionStep("النسخ الاحتياطي", "احفظ نسخة احتياطية شاملة لقاعدة بياناتك بضغطة زر لاستعادتها بأمان وقت الحاجة.")
                ),
                tip = "تقارير الـ PDF مصممة بمعايير معتمدة رسمياً وتتضمن شعار المعهد، ومساحات التوقيعات الثلاثية المعتمدة.",
                targetScreen = Screen.Reports
            )
        )
    }

    var selectedInstructionIndex by remember { mutableIntStateOf(0) }
    val currentInstruction = instructionModules[selectedInstructionIndex.coerceIn(0, instructionModules.size - 1)]

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                if (showMainLayout) {
                    AppHeader(
                        title = "دليل ومزايا نظام دوامي الذكي 🌟",
                        username = "",
                        onHomeClick = {
                            if (isLoggedIn) viewModel.navigateTo(Screen.Selection) else viewModel.navigateBack()
                        },
                        onBackClick = {
                            if (isLoggedIn) viewModel.navigateTo(Screen.Selection) else viewModel.navigateBack()
                        },
                        isDark = isDarkTheme,
                        onToggleTheme = { viewModel.toggleTheme() },
                        unreadNotificationCount = unreadCount,
                        onNotificationClick = { viewModel.openNotificationCenter() }
                    )
                }
            },
            bottomBar = {
                if (showMainLayout) {
                    DawamiBottomNavigationBar(viewModel = viewModel)
                }
            }
        ) { innerPadding ->
            var selectedTab by remember { mutableIntStateOf(0) }
            val tabTitles = listOf("مزايا النظام والإضافات 🚀", "شرح استخدام الواجهات 📖")

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Top Tab Bar
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = if (isDarkTheme) Color(0xFF1E293B) else DawamiNavy,
                    contentColor = Color.White
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedTab == index) DawamiGold else Color.White.copy(alpha = 0.8f)
                                )
                            }
                        )
                    }
                }

                // Main Content Body - Zero Scroll Distraction Architecture
                if (selectedTab == 0) {
                    // ==========================================
                    // TAB 0: مزايا البرنامج والإضافات (Interactive Showcase)
                    // ==========================================
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Horizontal Category Selector Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            categories.forEach { cat ->
                                val isSelected = (selectedCategory == cat)
                                Surface(
                                    color = if (isSelected) DawamiNavy else if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0),
                                    shape = RoundedCornerShape(20.dp),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) DawamiGold else Color.Transparent
                                    ),
                                    modifier = Modifier.clickable {
                                        selectedCategory = cat
                                        selectedFeatureIndex = 0
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = cat,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) Color.White else if (isDarkTheme) Color.LightGray else DawamiNavy
                                        )
                                    }
                                }
                            }
                        }

                        // 2. Feature Selector Bar (Sub-tabs for features in this category)
                        if (currentCategoryFeatures.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9),
                                        RoundedCornerShape(10.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                // Previous feature button
                                IconButton(
                                    onClick = {
                                        if (safeFeatureIndex > 0) {
                                            selectedFeatureIndex = safeFeatureIndex - 1
                                        } else {
                                            selectedFeatureIndex = currentCategoryFeatures.size - 1
                                        }
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.NavigateBefore,
                                        contentDescription = "السابق",
                                        tint = if (isDarkTheme) Color.White else DawamiNavy,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // Feature indicator pills
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    currentCategoryFeatures.forEachIndexed { idx, feat ->
                                        val isCurrent = (idx == safeFeatureIndex)
                                        Box(
                                            modifier = Modifier
                                                .height(6.dp)
                                                .width(if (isCurrent) 22.dp else 7.dp)
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(if (isCurrent) DawamiNavy else Color.LightGray)
                                                .clickable { selectedFeatureIndex = idx }
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${safeFeatureIndex + 1} من ${currentCategoryFeatures.size}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDarkTheme) Color.LightGray else Color.Gray
                                    )
                                }

                                // Next feature button
                                IconButton(
                                    onClick = {
                                        if (safeFeatureIndex < currentCategoryFeatures.size - 1) {
                                            selectedFeatureIndex = safeFeatureIndex + 1
                                        } else {
                                            selectedFeatureIndex = 0
                                        }
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.NavigateNext,
                                        contentDescription = "التالي",
                                        tint = if (isDarkTheme) Color.White else DawamiNavy,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                        }

                        // 3. Focused Feature Showcase Card (Full Details without Scrolling)
                        if (currentFeature != null) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                                ),
                                border = BorderStroke(
                                    1.dp,
                                    if (isDarkTheme) Color(0xFF334155) else DawamiNavy.copy(alpha = 0.2f)
                                ),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(12.dp)
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // Top Content (Header + Description + Highlights)
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        // Header: Icon + Title + Badge
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Surface(
                                                color = currentFeature.badgeColor.copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.size(44.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Icon(
                                                        imageVector = currentFeature.icon,
                                                        contentDescription = null,
                                                        tint = currentFeature.badgeColor,
                                                        modifier = Modifier.size(24.dp)
                                                    )
                                                }
                                            }

                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = currentFeature.title,
                                                    fontSize = 13.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isDarkTheme) Color.White else DawamiNavy,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Surface(
                                                    color = currentFeature.badgeColor.copy(alpha = 0.12f),
                                                    shape = RoundedCornerShape(6.dp)
                                                ) {
                                                    Text(
                                                        text = currentFeature.badgeText,
                                                        fontSize = 9.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = currentFeature.badgeColor,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }

                                        // Elevator Pitch / Description
                                        Surface(
                                            color = if (isDarkTheme) Color(0xFF0F172A) else Color(0xFFF8FAFC),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(0.5.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = currentFeature.description,
                                                fontSize = 11.sp,
                                                color = if (isDarkTheme) Color.LightGray else Color(0xFF475569),
                                                lineHeight = 16.sp,
                                                modifier = Modifier.padding(8.dp)
                                            )
                                        }

                                        // Structured Highlights Points
                                        Text(
                                            text = "أبرز إمكانيات الميزة:",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDarkTheme) DawamiGold else DawamiNavy
                                        )

                                        Column(
                                            verticalArrangement = Arrangement.spacedBy(5.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            currentFeature.highlights.forEach { highlight ->
                                                Row(
                                                    verticalAlignment = Alignment.Top,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.CheckCircle,
                                                        contentDescription = null,
                                                        tint = currentFeature.badgeColor,
                                                        modifier = Modifier
                                                            .size(14.dp)
                                                            .padding(top = 2.dp)
                                                    )
                                                    Text(
                                                        text = highlight,
                                                        fontSize = 10.5.sp,
                                                        color = if (isDarkTheme) Color.White else Color(0xFF1E293B),
                                                        lineHeight = 15.sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    // Bottom Action Row (Fast Navigation Button + Quick Next/Prev)
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        if (currentFeature.targetScreen != null) {
                                            Button(
                                                onClick = {
                                                    if (isLoggedIn) {
                                                        viewModel.navigateTo(currentFeature.targetScreen)
                                                    } else {
                                                        viewModel.navigateTo(Screen.Login)
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = currentFeature.badgeColor),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(38.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (isLoggedIn) Icons.Default.Launch else Icons.Default.Lock,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = if (isLoggedIn) "الانتقال السريع للشاشة 🚀" else "تسجيل الدخول للوصول للشاشة 🔒",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                            }
                                        }

                                        // Category switcher footer
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TextButton(
                                                onClick = {
                                                    if (safeFeatureIndex > 0) {
                                                        selectedFeatureIndex = safeFeatureIndex - 1
                                                    } else {
                                                        selectedFeatureIndex = currentCategoryFeatures.size - 1
                                                    }
                                                },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Text("◀ الميزة السابقة", fontSize = 10.sp, color = DawamiNavy)
                                            }

                                            Text(
                                                text = "${selectedCategory} (${safeFeatureIndex + 1}/${currentCategoryFeatures.size})",
                                                fontSize = 9.5.sp,
                                                color = Color.Gray
                                            )

                                            TextButton(
                                                onClick = {
                                                    if (safeFeatureIndex < currentCategoryFeatures.size - 1) {
                                                        selectedFeatureIndex = safeFeatureIndex + 1
                                                    } else {
                                                        selectedFeatureIndex = 0
                                                    }
                                                },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Text("الميزة التالية ▶", fontSize = 10.sp, color = DawamiNavy)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(16.dp))
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // ==========================================
                    // TAB 1: شرح استخدام الواجهات (Interactive Walkthrough)
                    // ==========================================
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Horizontal Workflow Navigator Chips
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            instructionModules.forEachIndexed { idx, mod ->
                                val isSelected = (selectedInstructionIndex == idx)
                                Surface(
                                    color = if (isSelected) DawamiNavy else if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0),
                                    shape = RoundedCornerShape(18.dp),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) DawamiGold else Color.Transparent
                                    ),
                                    modifier = Modifier.clickable { selectedInstructionIndex = idx }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(18.dp)
                                                .clip(CircleShape)
                                                .background(if (isSelected) DawamiGold else DawamiNavy.copy(alpha = 0.2f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = mod.stepNumber,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) DawamiNavy else Color.White
                                            )
                                        }
                                        Text(
                                            text = mod.title,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) Color.White else if (isDarkTheme) Color.LightGray else DawamiNavy
                                        )
                                    }
                                }
                            }
                        }

                        // 2. Walkthrough Canvas Card (Zero Scroll Distraction)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isDarkTheme) Color(0xFF334155) else DawamiNavy.copy(alpha = 0.2f)
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp)
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                // Content (Header + 4 Steps + Tip)
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    // Module Header
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Surface(
                                            color = DawamiGold.copy(alpha = 0.18f),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.size(42.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = currentInstruction.icon,
                                                    contentDescription = null,
                                                    tint = DawamiGold,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                        }

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "المحطة ${currentInstruction.stepNumber}: ${currentInstruction.title}",
                                                fontSize = 13.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isDarkTheme) Color.White else DawamiNavy
                                            )
                                            Text(
                                                text = currentInstruction.intro,
                                                fontSize = 10.5.sp,
                                                color = if (isDarkTheme) Color.LightGray else Color.DarkGray,
                                                lineHeight = 14.sp
                                            )
                                        }
                                    }

                                    // The 4 Interactive Steps
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(5.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        currentInstruction.steps.forEachIndexed { sIdx, step ->
                                            Surface(
                                                color = if (isDarkTheme) Color(0xFF0F172A) else Color(0xFFF8FAFC),
                                                shape = RoundedCornerShape(8.dp),
                                                border = BorderStroke(0.5.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                                    verticalAlignment = Alignment.Top,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Surface(
                                                        color = DawamiNavy,
                                                        shape = CircleShape,
                                                        modifier = Modifier.size(18.dp)
                                                    ) {
                                                        Box(contentAlignment = Alignment.Center) {
                                                            Text(
                                                                text = "${sIdx + 1}",
                                                                fontSize = 9.5.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color.White
                                                            )
                                                        }
                                                    }
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = step.title,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (isDarkTheme) DawamiGold else DawamiNavy
                                                        )
                                                        Text(
                                                            text = step.detail,
                                                            fontSize = 10.sp,
                                                            color = if (isDarkTheme) Color.LightGray else Color(0xFF334155),
                                                            lineHeight = 14.sp
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Smart Tip Callout
                                    Surface(
                                        color = if (isDarkTheme) Color(0xFF1E1B4B) else Color(0xFFFEF3C7).copy(alpha = 0.5f),
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF4338CA) else DawamiGold.copy(alpha = 0.4f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(8.dp),
                                            verticalAlignment = Alignment.Top,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Lightbulb,
                                                contentDescription = null,
                                                tint = DawamiGold,
                                                modifier = Modifier.size(16.dp).padding(top = 1.dp)
                                            )
                                            Column {
                                                Text(
                                                    text = "تلميح ذكي وتوجيه عملي 💡:",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isDarkTheme) Color(0xFFC7D2FE) else Color(0xFF92400E)
                                                )
                                                Text(
                                                    text = currentInstruction.tip,
                                                    fontSize = 9.5.sp,
                                                    color = if (isDarkTheme) Color(0xFFE0E7FF) else Color(0xFF78350F),
                                                    lineHeight = 13.sp
                                                )
                                            }
                                        }
                                    }
                                }

                                // Bottom Navigation Footer
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // Direct action button
                                    Button(
                                        onClick = {
                                            if (isLoggedIn) {
                                                viewModel.navigateTo(currentInstruction.targetScreen)
                                            } else {
                                                viewModel.navigateTo(Screen.Login)
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(38.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Launch,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isLoggedIn) "الانتقال المباشر لواجهة العمل 🎯" else "تسجيل الدخول لتجربة الواجهة 🔒",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }

                                    // Next / Prev workflow switcher
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(
                                            onClick = {
                                                if (selectedInstructionIndex > 0) {
                                                    selectedInstructionIndex--
                                                } else {
                                                    selectedInstructionIndex = instructionModules.size - 1
                                                }
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("◀ الواجهة السابقة", fontSize = 10.sp, color = DawamiNavy)
                                        }

                                        Text(
                                            text = "المحطة ${currentInstruction.stepNumber} من ${instructionModules.size}",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Gray
                                        )

                                        TextButton(
                                            onClick = {
                                                if (selectedInstructionIndex < instructionModules.size - 1) {
                                                    selectedInstructionIndex++
                                                } else {
                                                    selectedInstructionIndex = 0
                                                }
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("الواجهة التالية ▶", fontSize = 10.sp, color = DawamiNavy)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
