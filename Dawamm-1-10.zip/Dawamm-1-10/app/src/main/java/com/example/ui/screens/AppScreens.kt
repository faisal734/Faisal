package com.example.ui.screens

import com.example.data.entity.OfficialHoliday
import androidx.compose.material3.MaterialTheme


import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.rememberAsyncImagePainter
import com.example.data.entity.Attendance
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentAttendance
import com.example.data.entity.DailyCourseNote
import com.example.data.entity.TrainerTransaction
import com.example.data.entity.AppActivityLog
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.delay
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.input.pointer.pointerInput

fun formatFinanceAmountNoDecimals(amount: Double): String {
    val formatter = java.text.DecimalFormat("#,##0", java.text.DecimalFormatSymbols(java.util.Locale.US))
    return formatter.format(kotlin.math.round(amount))
}


fun calculateEndDate(
    startDateStr: String,
    targetDays: Int,
    includeThursday: Boolean,
    holidays: List<OfficialHoliday> = emptyList()
): String {
    if (startDateStr.isBlank() || targetDays <= 0) return startDateStr
    val parts = startDateStr.split("-")
    if (parts.size != 3) return startDateStr
    val year = parts[0].toIntOrNull() ?: return startDateStr
    val month = parts[1].toIntOrNull() ?: return startDateStr
    val day = parts[2].toIntOrNull() ?: return startDateStr
    
    val calendar = java.util.Calendar.getInstance()
    calendar.set(year, month - 1, day)
    
    var daysCounted = 0
    var safetyIterations = 0
    val currentCalendar = calendar.clone() as java.util.Calendar
    val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    
    while (daysCounted < targetDays && safetyIterations < 3650) {
        safetyIterations++
        val dayOfWeek = currentCalendar.get(java.util.Calendar.DAY_OF_WEEK)
        val isFriday = (dayOfWeek == java.util.Calendar.FRIDAY)
        val isThursday = (dayOfWeek == java.util.Calendar.THURSDAY)
        val dateStr = sdf.format(currentCalendar.time)
        val isHoliday = holidays.any { it.isEnabled && it.startDate.isNotBlank() && it.endDate.isNotBlank() && dateStr >= it.startDate && dateStr <= it.endDate }
        
        var isValid = true
        if (isFriday || isHoliday) {
            isValid = false
        } else if (isThursday && !includeThursday) {
            isValid = false
        }
        
        if (isValid) {
            daysCounted++
            if (daysCounted == targetDays) {
                break
            }
        }
        currentCalendar.add(java.util.Calendar.DAY_OF_YEAR, 1)
    }
    
    val endYear = currentCalendar.get(java.util.Calendar.YEAR)
    val endMonth = currentCalendar.get(java.util.Calendar.MONTH) + 1
    val endDay = currentCalendar.get(java.util.Calendar.DAY_OF_MONTH)
    
    val formattedMonth = if (endMonth < 10) "0$endMonth" else "$endMonth"
    val formattedDay = if (endDay < 10) "0$endDay" else "$endDay"
    return "$endYear-$formattedMonth-$formattedDay"
}

fun calculateEndTime(startTimeStr: String, hoursDouble: Double): String {
    if (startTimeStr.isBlank() || hoursDouble <= 0) return startTimeStr
    val parts = startTimeStr.split(":")
    if (parts.size != 2) return startTimeStr
    val startHour = parts[0].toIntOrNull() ?: return startTimeStr
    val startMin = parts[1].toIntOrNull() ?: return startTimeStr
    
    val totalMinutesToAdd = (hoursDouble * 60).toInt()
    val endTotalMinutes = (startHour * 60 + startMin + totalMinutesToAdd) % (24 * 60)
    
    val endHour = endTotalMinutes / 60
    val endMin = endTotalMinutes % 60
    
    val hStr = if (endHour < 10) "0$endHour" else "$endHour"
    val mStr = if (endMin < 10) "0$endMin" else "$endMin"
    return "$hStr:$mStr"
}

fun countTrainingDays(
    startDateStr: String,
    endDateStr: String,
    includeThursday: Boolean,
    holidays: List<OfficialHoliday> = emptyList()
): Int {
    if (startDateStr.isBlank() || endDateStr.isBlank()) return 0
    val startParts = startDateStr.split("-")
    val endParts = endDateStr.split("-")
    if (startParts.size != 3 || endParts.size != 3) return 0
    
    val startYear = startParts[0].toIntOrNull() ?: return 0
    val startMonth = startParts[1].toIntOrNull() ?: return 0
    val startDay = startParts[2].toIntOrNull() ?: return 0
    
    val endYear = endParts[0].toIntOrNull() ?: return 0
    val endMonth = endParts[1].toIntOrNull() ?: return 0
    val endDay = endParts[2].toIntOrNull() ?: return 0
    
    val startCal = java.util.Calendar.getInstance()
    startCal.set(startYear, startMonth - 1, startDay)
    
    val endCal = java.util.Calendar.getInstance()
    endCal.set(endYear, endMonth - 1, endDay)
    
    if (startCal.after(endCal)) return 0
    
    var count = 0
    var safetyIterations = 0
    val tempCal = startCal.clone() as java.util.Calendar
    val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    while (!tempCal.after(endCal) && safetyIterations < 3650) {
        safetyIterations++
        val dayOfWeek = tempCal.get(java.util.Calendar.DAY_OF_WEEK)
        val isFriday = (dayOfWeek == java.util.Calendar.FRIDAY)
        val isThursday = (dayOfWeek == java.util.Calendar.THURSDAY)
        val dateStr = sdf.format(tempCal.time)
        val isHoliday = holidays.any { it.isEnabled && it.startDate.isNotBlank() && it.endDate.isNotBlank() && dateStr >= it.startDate && dateStr <= it.endDate }
        
        var isValid = true
        if (isFriday || isHoliday) {
            isValid = false
        } else if (isThursday && !includeThursday) {
            isValid = false
        }
        
        if (isValid) {
            count++
        }
        tempCal.add(java.util.Calendar.DAY_OF_YEAR, 1)
    }
    return count
}

fun countHours(startTimeStr: String, endTimeStr: String): Double {
    if (startTimeStr.isBlank() || endTimeStr.isBlank()) return 0.0
    val startParts = startTimeStr.split(":")
    val endParts = endTimeStr.split(":")
    if (startParts.size != 2 || endParts.size != 2) return 0.0
    
    val startHour = startParts[0].toIntOrNull() ?: return 0.0
    val startMin = startParts[1].toIntOrNull() ?: return 0.0
    val endHour = endParts[0].toIntOrNull() ?: return 0.0
    val endMin = endParts[1].toIntOrNull() ?: return 0.0
    
    var diffMinutes = (endHour * 60 + endMin) - (startHour * 60 + startMin)
    if (diffMinutes < 0) {
        diffMinutes += 24 * 60
    }
    return diffMinutes / 60.0
}

private fun String.toEnglishNumbers(): String {
    val arabicDigits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
    val englishDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    var result = this
    for (i in 0..9) {
        result = result.replace(arabicDigits[i], englishDigits[i])
    }
    return result
}

fun formatSystemDateTime(dateTimeStr: String): String {
    if (dateTimeStr.isEmpty()) return "غير متوفر"
    return try {
        val sdf24 = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        val d = sdf24.parse(dateTimeStr) ?: return dateTimeStr
        val sdf12 = java.text.SimpleDateFormat("yyyy-MM-dd hh:mm a", java.util.Locale.US)
        val formatted = sdf12.format(d)
        formatted.replace("AM", "ص").replace("PM", "م")
    } catch (e: Exception) {
        dateTimeStr
    }
}

@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: androidx.compose.ui.unit.TextUnit = androidx.compose.ui.unit.TextUnit.Unspecified,
    fontStyle: androidx.compose.ui.text.font.FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: androidx.compose.ui.text.font.FontFamily? = null,
    letterSpacing: androidx.compose.ui.unit.TextUnit = androidx.compose.ui.unit.TextUnit.Unspecified,
    textDecoration: androidx.compose.ui.text.style.TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: androidx.compose.ui.unit.TextUnit = androidx.compose.ui.unit.TextUnit.Unspecified,
    overflow: androidx.compose.ui.text.style.TextOverflow = androidx.compose.ui.text.style.TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: ((androidx.compose.ui.text.TextLayoutResult) -> Unit)? = null,
    style: androidx.compose.ui.text.TextStyle = LocalTextStyle.current
) {
    androidx.compose.material3.Text(
        text = text.toEnglishNumbers(),
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        onTextLayout = onTextLayout,
        style = style
    )
}

// ---------------- SPLASH SCREEN ----------------
@Composable
fun SplashScreen(viewModel: MainViewModel) {
    var opacity by remember { mutableStateOf(0.1f) }
    val animatedOpacity by animateFloatAsState(
        targetValue = opacity,
        animationSpec = tween(durationMillis = 1500),
        label = "LogoFadeIn"
    )

    LaunchedEffect(Unit) {
        opacity = 1.0f
        delay(2200) // Beautiful cinematic duration
        viewModel.checkNavigationOnStart()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DawamiNavy, DawamiNavy.copy(alpha = 0.85f))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(16.dp)
        ) {
            DawamiLogo(
                size = 180.dp,
                opacity = animatedOpacity
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "دوامي",
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "DAWAMI",
                color = DawamiGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "إدارة الدوام والدورات التدريبية",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 11.sp
            )
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp)
        ) {
            AppFooter()
        }
    }
}

// ---------------- ACTIVATION SCREEN (SECURITY & COPY PROTECTION) ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivationScreen(viewModel: MainViewModel) {
    var activationCode by remember { mutableStateOf("") }
    val activationError by viewModel.activationError.collectAsState()
    val context = LocalContext.current

    Scaffold(
        bottomBar = { AppFooter() }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.surface)
                    )
                ),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(horizontal = 16.dp, vertical = 24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                // Security Shield Header
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = DawamiNavy),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Surface(
                            color = Color.White.copy(alpha = 0.15f),
                            shape = CircleShape,
                            modifier = Modifier.size(72.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = "قفل الحماية",
                                    tint = DawamiGold,
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "نظام التفعيل والأمان المطور 🛡️",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "تم دمج خوارزمية حماية متطورة لمنع نسخ التطبيق بشكل غير مصرح به أو تفكيك واجهاته البرمجية، لضمان أعلى مستويات الأمان والخصوصية لبياناتك.",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                    }
                }

                // Activation Code Form
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "أدخل رمز التفعيل الخاص بك",
                            color = DawamiNavy,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "يرجى إدخال كود التفعيل المخصص الممنوح لك لفتح وتفعيل صلاحيات البرنامج.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )

                        // PasswordVisualTransformation hides the activation code as requested
                        OutlinedTextField(
                            value = activationCode,
                            onValueChange = { activationCode = it },
                            label = { Text("رمز التفعيل المكون من 6 أرقام") },
                            placeholder = { Text("أدخل الكود السري هنا") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = "كود مخفي", tint = DawamiNavy)
                            }
                        )

                        if (activationError != null) {
                            Text(
                                text = activationError!!,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }

                        Button(
                            onClick = {
                                if (activationCode.isBlank()) {
                                    Toast.makeText(context, "الرجاء إدخال رمز التفعيل أولاً!", Toast.LENGTH_SHORT).show()
                                } else {
                                    val success = viewModel.activateApp(activationCode)
                                    if (success) {
                                        Toast.makeText(context, "تهانينا! تم التحقق وتفعيل البرنامج بنجاح 🎉", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Key, contentDescription = "تفعيل")
                                Text("تفعيل وتشغيل البرنامج", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        OutlinedButton(
                            onClick = {
                                viewModel.startTrialMode()
                                Toast.makeText(context, "تم الدخول بالوضع التجريبي للبرنامج بنجاح 👍", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = DawamiNavy)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "تجربة")
                                Text("الدخول بالوضع التجريبي مجاناً ⏱️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // WhatsApp Helper Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DawamiTeal.copy(alpha = 0.08f)),
                    border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.2f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "لا تملك رمز تفعيل؟",
                            color = DawamiNavy,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "إذا كنت بحاجة إلى رمز تفعيل مخصص لجهازك لتشغيل البرنامج وتفعيله، يمكنك التواصل مباشرة مع المطور بنقرة واحدة.",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.5.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(
                            onClick = {
                                viewModel.triggerDeveloperContactDialog()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.height(44.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "طلب الرمز عبر الواتساب")
                                Text("طلب رمز التفعيل عبر واتساب / اتصال 💬", color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- PROGRAM FEATURES CARD ----------------
@Composable
fun FeaturesCard() {
    DawamiFeaturesCard()
}

// ---------------- LOGIN SCREEN & REGISTER SCREEN ----------------
// تم نقل LoginScreen و RegisterScreen إلى AuthScreens.kt لتقليل حجم الملف ورفع كفاءة البناء

// ---------------- SELECTION SCREEN (شاشة اختيار الواجهة الرئيسية) ----------------
// تم نقل SelectionScreen و DashboardCard و QuickSettingItem إلى SelectionScreen.kt لتقليل حجم الملف ورفع كفاءة البناء

// ---------------- MAIN CONTAINER & NAVIGATION RAIL / BOTTOM BAR ----------------
@Composable
fun MainLayout(
    viewModel: MainViewModel,
    showScaffold: Boolean = true,
    content: @Composable (PaddingValues) -> Unit
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val loggedInUser by viewModel.loggedInUser.collectAsState()
    val selectedRoleMode by viewModel.selectedRoleMode.collectAsState()
    val context = LocalContext.current
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val notifications by viewModel.inAppNotifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }
    val instituteLogoUri by viewModel.instituteLogoUri.collectAsState()

    // Register BackHandler for all screens using MainLayout to support sequential back navigation
    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (!showScaffold) {
            content(PaddingValues(0.dp))
        } else {
            Scaffold(
                topBar = {
                    AppHeader(
                        title = if (selectedRoleMode.startsWith("student")) "متابعة الطلاب" else "متابعة الأستاذ",
                        username = loggedInUser,
                        onHomeClick = { viewModel.navigateTo(Screen.Selection) },
                        onBackClick = { viewModel.navigateBack() },
                        isDark = isDarkTheme,
                        onToggleTheme = { viewModel.toggleTheme() },
                        unreadNotificationCount = unreadCount,
                        onNotificationClick = { viewModel.openNotificationCenter() },
                        logoUri = instituteLogoUri
                    )
                },
            bottomBar = {
                DawamiBottomNavigationBar(viewModel = viewModel)
            }
        ) { innerPadding ->
            content(innerPadding)
        }
        } // end of else
    }
}

