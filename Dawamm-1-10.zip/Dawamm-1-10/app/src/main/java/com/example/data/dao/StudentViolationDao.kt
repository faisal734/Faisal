package com.example.data.dao

import androidx.room.*
import com.example.data.entity.StudentViolation
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentViolationDao {
    @Query("SELECT * FROM student_violations ORDER BY id DESC")
    fun getAllViolations(): Flow<List<StudentViolation>>

    @Query("SELECT * FROM student_violations WHERE courseId = :courseId ORDER BY id DESC")
    fun getViolationsForCourse(courseId: Long): Flow<List<StudentViolation>>

    @Query("SELECT * FROM student_violations WHERE courseId = :courseId AND subjectName = :subjectName ORDER BY id DESC")
    fun getViolationsForCourseAndSubject(courseId: Long, subjectName: String): Flow<List<StudentViolation>>

    @Query("SELECT * FROM student_violations WHERE studentId = :studentId ORDER BY id DESC")
    fun getViolationsForStudent(studentId: Long): Flow<List<StudentViolation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertViolation(violation: StudentViolation): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertViolations(violations: List<StudentViolation>): List<Long>

    @Update
    suspend fun updateViolation(violation: StudentViolation)

    @Delete
    suspend fun deleteViolation(violation: StudentViolation)

    @Query("DELETE FROM student_violations WHERE id = :id")
    suspend fun deleteViolationById(id: Long)

    @Query("DELETE FROM student_violations")
    suspend fun deleteAllViolations()
}
