package com.example.ui.screens

import androidx.compose.material3.MaterialTheme


import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentGradeConfig
import com.example.ui.viewmodel.*
import com.example.ui.pdf.PdfReportHelper
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiTeal
import com.example.ui.theme.LightBackground
import com.example.ui.dialogs.GradesImportExportDialog
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*

// --- Unified Helpers to access Grade Info safely ---
fun StudentGrade.getScoresMap(): Map<String, Double> {
    return if (isDiploma) {
        mapOf(
            "حضور" to attendanceScore,
            "مشاركة" to participationScore,
            "تكاليف" to assignmentsScore,
            "مشاريع" to projectsScore,
            "اختبار نظري" to theoreticalExamScore,
            "اختبار عملي" to practicalExamScore
        )
    } else {
        StudentGrade.deserializeScores(customScoresJson)
    }
}

fun StudentGrade.getTotalScore(): Double {
    return if (isDiploma) {
        getDiplomaTotal()
    } else {
        StudentGrade.deserializeScores(customScoresJson).values.sum()
    }
}

fun calculateDynamicAttendanceScore(
    allAttendance: List<com.example.data.entity.StudentAttendance>,
    courseId: Int,
    subjectName: String,
    studentId: Int,
    maxAttendanceScore: Double,
    allCourseSubjects: List<String> = emptyList(),
    taughtDaysCount: Int = -1
): Pair<Double, String> {
    if (maxAttendanceScore <= 0.0) return Pair(0.0, "لم يتم تحديد تقسيم للحضور لهذه المادة.")
    
    // Filter attendance records for this course & subject strictly
    val subjectAttendance = allAttendance.filter { att ->
        if (att.courseId != courseId) return@filter false
        val recSubject = att.subjectName.trim()
        if (recSubject.isNotEmpty()) {
            recSubject.equals(subjectName.trim(), ignoreCase = true)
        } else {
            allCourseSubjects.isEmpty() || allCourseSubjects.size == 1
        }
    }
    
    val uniqueDates = subjectAttendance.map { it.date }.distinct()
    val subjectDays = if (taughtDaysCount >= 0) taughtDaysCount else uniqueDates.size
    
    if (subjectDays == 0) {
        return Pair(0.0, "لا توجد أيام تحضير مسجلة للمادة بعد (0 أيام).")
    }
    
    val studentRecords = subjectAttendance.filter { it.studentId == studentId }
    val attendedDays = studentRecords.count { it.status == "حضور" }
    val excusedDays = studentRecords.count { it.status == "مستأذن" }
    val leaveDays = studentRecords.count { it.status == "إجازة" }
    val absentDays = studentRecords.count { it.status == "غياب" }
    
    // Effective attendance: full day for "حضور" (1.0) and half day for "مستأذن" (0.5)
    // Capped by subjectDays to prevent illogical excess from legacy transfer data
    var effectiveDays = attendedDays.toDouble() + (excusedDays.toDouble() * 0.5)
    effectiveDays = effectiveDays.coerceAtMost(subjectDays.toDouble())
    
    // Effective required days excludes approved leave days
    val effectiveRequiredDays = (subjectDays - leaveDays).coerceAtLeast(1)
    
    val calculated = ((effectiveDays / effectiveRequiredDays.toDouble()) * maxAttendanceScore).coerceIn(0.0, maxAttendanceScore)
    // Round to 2 decimal places
    val rounded = Math.round(calculated * 100.0) / 100.0
    
    val breakdownParts = mutableListOf<String>()
    if (attendedDays > 0) breakdownParts.add("حضور: $attendedDays")
    if (excusedDays > 0) breakdownParts.add("مستأذن: $excusedDays (نصف درجة)")
    if (leaveDays > 0) breakdownParts.add("إجازة: $leaveDays (معفاة)")
    if (absentDays > 0) breakdownParts.add("غياب: $absentDays")
    
    val breakdownStr = if (breakdownParts.isNotEmpty()) breakdownParts.joinToString("، ") else "لا توجد حركات"
    val details = "[$breakdownStr] من أصل $subjectDays أيام مسجلة للمادة. الدرجة التلقائية: $rounded من $maxAttendanceScore"
    
    return Pair(rounded, details)
}

fun calculateDynamicParticipationScore(
    allAttendance: List<com.example.data.entity.StudentAttendance>,
    courseId: Int,
    subjectName: String,
    studentId: Int,
    maxParticipationScore: Double,
    allCourseSubjects: List<String> = emptyList(),
    taughtDaysCount: Int = -1
): Pair<Double, String> {
    if (maxParticipationScore <= 0.0) return Pair(0.0, "لم يتم تحديد درجة للمشاركة لهذه المادة.")
    
    val subjectAttendance = allAttendance.filter { att ->
        if (att.courseId != courseId) return@filter false
        val recSubject = att.subjectName.trim()
        if (recSubject.isNotEmpty()) {
            recSubject.equals(subjectName.trim(), ignoreCase = true)
        } else {
            allCourseSubjects.isEmpty() || allCourseSubjects.size == 1
        }
    }

    val uniqueDates = subjectAttendance.map { it.date }.distinct()
    val totalDays = if (taughtDaysCount >= 0) taughtDaysCount else uniqueDates.size
    
    if (totalDays == 0) {
        return Pair(0.0, "لا توجد أيام تحضير مسجلة للمادة بعد (0 أيام).")
    }
    
    val studentRecords = subjectAttendance.filter { it.studentId == studentId }
    val leaveDays = studentRecords.count { it.status.trim() == "إجازة" }
    
    var earnedStars = studentRecords.filter {
        val st = it.status.trim()
        st != "غياب" && st != "غائب" && st != "إجازة"
    }.sumOf { it.participationStars }
    
    // Effective required participation days excludes approved leave days
    val effectiveRequiredDays = (totalDays - leaveDays).coerceAtLeast(0)
    
    if (effectiveRequiredDays == 0) {
        return Pair(maxParticipationScore, "جميع أيام التحضير للمادة إجازة معتمدة ($leaveDays أيام). الدرجة المحسوبة كاملة: $maxParticipationScore من $maxParticipationScore")
    }
    
    val maxPossibleStars = effectiveRequiredDays * 5
    // Cap maximum earned stars to prevent legacy mismatch
    earnedStars = earnedStars.coerceAtMost(maxPossibleStars)
    
    if (maxPossibleStars == 0) {
        return Pair(0.0, "لا توجد حركات تقييم مسجلة للمشاركة.")
    }
    
    val ratio = (earnedStars.toDouble() / maxPossibleStars.toDouble()).coerceIn(0.0, 1.0)
    val calculated = ratio * maxParticipationScore
    val rounded = Math.round(calculated * 100.0) / 100.0
    
    val detailsParts = mutableListOf<String>()
    detailsParts.add("نجوم المشاركة: $earnedStars من $maxPossibleStars")
    if (leaveDays > 0) detailsParts.add("إجازة: $leaveDays أيام (معفاة)")
    
    val detailsStr = detailsParts.joinToString("، ")
    val details = "[$detailsStr] من أصل $totalDays أيام مسجلة للمادة. الدرجة المحسوبة آلياً: $rounded من $maxParticipationScore"
    return Pair(rounded, details)
}

fun calculateDynamicAssignmentScore(
    allSubmissions: List<com.example.data.entity.StudentAssignmentSubmission>,
    allTemplates: List<com.example.data.entity.SubjectAssignmentTemplate>,
    courseId: Int,
    subjectName: String,
    studentId: Int,
    maxAssignmentScore: Double,
    categoryFilter: String = "ALL"
): Pair<Double, String> {
    if (maxAssignmentScore <= 0.0) return Pair(0.0, "لم يتم تحديد درجة لهذا البند.")

    val allSubjectTemplates = allTemplates.filter {
        it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true) &&
        (courseId <= 0 || it.isApplicableForCourse(courseId))
    }

    val templates = when (categoryFilter) {
        "تكاليف" -> allSubjectTemplates.filter {
            val t = if (it.type.isNotBlank()) it.type else it.title
            !t.contains("مشروع") && !t.contains("عملي")
        }
        "مشاريع" -> allSubjectTemplates.filter {
            val t = if (it.type.isNotBlank()) it.type else it.title
            t.contains("مشروع") || t.contains("عملي")
        }
        else -> allSubjectTemplates
    }

    val totalCount = templates.size
    if (totalCount == 0) {
        return Pair(0.0, "لا توجد عناصر مهيأة لـ $categoryFilter لهذه المادة في النظام.")
    }

    var totalEarnedScore = 0.0
    var completedCount = 0

    templates.forEach { tmpl ->
        val sub = allSubmissions.filter { s ->
            s.courseId == courseId &&
            s.subjectName.trim().equals(subjectName.trim(), ignoreCase = true) &&
            s.studentId == studentId &&
            s.assignmentTitle.trim().equals(tmpl.title.trim(), ignoreCase = true)
        }.maxByOrNull { it.id }
        if (sub != null && sub.isCompleted) {
            completedCount++
            val sScore = sub.score ?: when(sub.evaluationRating) {
                "ممتاز" -> tmpl.maxScore
                "جيد جداً" -> tmpl.maxScore * 0.75
                "جيد" -> tmpl.maxScore * 0.50
                "مقبول" -> tmpl.maxScore * 0.25
                else -> tmpl.maxScore
            }
            totalEarnedScore += sScore
        }
    }

    val totalTemplateMax = templates.sumOf { it.maxScore }
    val calculatedScore = if (totalTemplateMax > 0.0 && totalTemplateMax != maxAssignmentScore) {
        (totalEarnedScore / totalTemplateMax) * maxAssignmentScore
    } else {
        totalEarnedScore
    }.coerceAtMost(maxAssignmentScore)

    val rounded = Math.round(calculatedScore).toDouble()
    val formattedScoreStr = if (rounded % 1.0 == 0.0) rounded.toInt().toString() else rounded.toString()
    val formattedMaxStr = if (maxAssignmentScore % 1.0 == 0.0) maxAssignmentScore.toInt().toString() else maxAssignmentScore.toString()
    val details = "أنجز الطالب $completedCount من أصل $totalCount ($formattedScoreStr من $formattedMaxStr درجة)."
    return Pair(rounded, details)
}

// ---------------- GRADES SCREEN (درجات الطلاب) ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GradesScreen(
    viewModel: MainViewModel,
    gradingViewModel: GradingViewModel? = null,
    showMainLayout: Boolean = true
) {
    val context = LocalContext.current
    val dbCourses by viewModel.dbCourses.collectAsState()
    val showCompletedCourses by viewModel.showCompletedCoursesInDropdowns.collectAsState()
    val dbAllStudents by viewModel.dbAllStudents.collectAsState()
    val dbAllGrades by (gradingViewModel?.allGrades ?: viewModel.dbAllGrades).collectAsState()
    val dbAllGradeConfigs by (gradingViewModel?.allGradeConfigs ?: viewModel.dbAllGradeConfigs).collectAsState()
    val dbAllStudentAttendance by viewModel.dbAllStudentAttendance.collectAsState()
    val dbAssignmentTemplates by (gradingViewModel?.allAssignmentTemplates ?: viewModel.dbAssignmentTemplates).collectAsState()
    val dbAssignmentSubmissions by (gradingViewModel?.allAssignmentSubmissions ?: viewModel.dbAssignmentSubmissions).collectAsState()
    val dbCourseSubjects by viewModel.dbCourseSubjects.collectAsState()
    val dbSubjects by viewModel.dbSubjects.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()

    val selectedCourseForGrades by viewModel.selectedCourseForGrades.collectAsState()

    val isCourseEnded = remember(selectedCourseForGrades) {
        if (selectedCourseForGrades == null) false
        else {
            val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            val isPastEndDate = selectedCourseForGrades!!.endDate.isNotBlank() && todayStr > selectedCourseForGrades!!.endDate
            val isCompleted = selectedCourseForGrades!!.isCompleted
            isCompleted || isPastEndDate
        }
    }
    var isEditUnlockedForEndedCourse by remember(selectedCourseForGrades?.id) { mutableStateOf(false) }
    var showUnlockConfirmDialog by remember { mutableStateOf(false) }
    val isLockedForEditing = isCourseEnded && !isEditUnlockedForEndedCourse

    var isCourseDropdownExpanded by remember { mutableStateOf(false) }

    var forceShowSetup by remember(selectedCourseForGrades?.id) { mutableStateOf(false) }

    // Find current config with smart diploma template / sibling fallback
    val currentConfig = selectedCourseForGrades?.let { course ->
        if (forceShowSetup) {
            null
        } else {
            val exact = dbAllGradeConfigs.find { it.courseId == course.id }
            val assignedSubjs = dbCourseSubjects.filter { it.courseId == course.id }
                .mapNotNull { cs -> dbSubjects.find { it.id == cs.subjectId }?.name }
                .filter { it.isNotBlank() }
            val assignedSubsJson = if (assignedSubjs.isNotEmpty()) assignedSubjs.joinToString("|") else ""

            val dipTemplateId = if (course.diplomaName.isNotEmpty()) StudentGradeConfig.getDiplomaTemplateId(course.diplomaName) else null
            val dipTemplate = if (dipTemplateId != null) dbAllGradeConfigs.find { it.courseId == dipTemplateId } else null
            val deptTemplateId = if (course.departmentName.isNotEmpty()) StudentGradeConfig.getDepartmentTemplateId(course.departmentName) else null
            val deptTemplate = if (deptTemplateId != null) dbAllGradeConfigs.find { it.courseId == deptTemplateId } else null

            val activeTemplate = dipTemplate ?: deptTemplate

            val resolvedExact = if (exact != null) {
                if (exact.diplomaSubjectsJson.isBlank() && assignedSubsJson.isNotEmpty()) {
                    exact.copy(diplomaSubjectsJson = assignedSubsJson)
                } else {
                    exact
                }
            } else null

            if (resolvedExact != null && resolvedExact.customFieldsJson.isNotEmpty()) {
                if (resolvedExact.subjectWeightsJson.isEmpty() && activeTemplate != null && activeTemplate.subjectWeightsJson.isNotEmpty()) {
                    resolvedExact.copy(subjectWeightsJson = activeTemplate.subjectWeightsJson)
                } else {
                    resolvedExact
                }
            } else if (resolvedExact != null) {
                if (activeTemplate != null && activeTemplate.customFieldsJson.isNotEmpty()) {
                    resolvedExact.copy(
                        customFieldsJson = activeTemplate.customFieldsJson,
                        subjectWeightsJson = if (activeTemplate.subjectWeightsJson.isNotEmpty()) activeTemplate.subjectWeightsJson else resolvedExact.subjectWeightsJson
                    )
                } else resolvedExact
            } else if (activeTemplate != null) {
                activeTemplate.copy(
                    courseId = course.id,
                    courseName = course.name,
                    diplomaSubjectsJson = if (assignedSubsJson.isNotEmpty()) assignedSubsJson else activeTemplate.diplomaSubjectsJson
                )
            } else {
                val siblingCourseIds = dbCourses.filter { it.diplomaName == course.diplomaName && it.id != course.id }.map { it.id }
                val siblingConfig = dbAllGradeConfigs.find { it.courseId in siblingCourseIds }
                if (siblingConfig != null) {
                    siblingConfig.copy(
                        courseId = course.id,
                        courseName = course.name,
                        diplomaSubjectsJson = if (assignedSubsJson.isNotEmpty()) assignedSubsJson else siblingConfig.diplomaSubjectsJson
                    )
                } else if (assignedSubsJson.isNotEmpty()) {
                    StudentGradeConfig(
                        courseId = course.id,
                        courseName = course.name,
                        isDiploma = true,
                        diplomaSubjectsJson = assignedSubsJson,
                        customFieldsJson = StudentGradeConfig.serializeFields(
                            if (course.departmentName.contains("حاسب") || course.departmentName.contains("حاسوب")) {
                                listOf(
                                    Pair("حضور", 5),
                                    Pair("مشاركة", 5),
                                    Pair("تكاليف", 10),
                                    Pair("مشاريع", 20),
                                    Pair("اختبار نظري", 20),
                                    Pair("اختبار عملي", 40)
                                )
                            } else {
                                listOf(
                                    Pair("حضور", 10),
                                    Pair("مشاركة", 10),
                                    Pair("تكاليف", 20),
                                    Pair("اختبار نظري", 30),
                                    Pair("اختبار عملي", 30)
                                )
                            }
                        )
                    )
                } else {
                    null
                }
            }
        }
    }

    // State for showing suspended/withdrawn students (Option 1: default excluded, optional toggle)
    var showSuspendedAndWithdrawn by remember { mutableStateOf(false) }

    // All relevant students for selected course (excluding disconnected/graduated/deleted)
    val allCourseStudentsRaw = selectedCourseForGrades?.let { course ->
        dbAllStudents.filter { it.courseId == course.id && it.status != "منقطع" && it.status != "خريج" && it.status != "محذوف" }
    } ?: emptyList()

    val inactiveStudentsCount = remember(allCourseStudentsRaw) {
        allCourseStudentsRaw.count { it.status == "منسحب" || it.status == "توقيف قيد" || it.status == "موقوف" || it.status == "موقف" }
    }

    // Find students for selected course according to toggle
    val courseStudents = remember(allCourseStudentsRaw, showSuspendedAndWithdrawn) {
        if (showSuspendedAndWithdrawn) {
            allCourseStudentsRaw
        } else {
            allCourseStudentsRaw.filter { it.status != "منسحب" && it.status != "توقيف قيد" && it.status != "موقوف" && it.status != "موقف" }
        }
    }

    // Find grades for selected course
    val courseGrades = selectedCourseForGrades?.let { course ->
        dbAllGrades.filter { it.courseId == course.id }
    } ?: emptyList()

    // Configuration screen states
    var configTypeIsDiploma by remember { mutableStateOf(true) }
    
    // Custom Configuration Subjects Setup
    var customSubjectNameInput by remember { mutableStateOf("") }
    var customSubjectsList by remember { mutableStateOf(listOf<String>()) }
    
    // Custom fields setup (Name to MaxScore)
    var customFieldNameInput by remember { mutableStateOf("") }
    var customFieldMaxInput by remember { mutableStateOf("") }
    var customFieldsList by remember { mutableStateOf(listOf<Pair<String, Int>>()) }
    var customTemplateNameInput by remember { mutableStateOf("") }

    val courseSubjects = remember(selectedCourseForGrades, dbAllGradeConfigs, dbCourseSubjects, dbSubjects) {
        val course = selectedCourseForGrades
        if (course == null) {
            StudentGradeConfig.DEFAULT_DIPLOMA_SUBJECTS
        } else {
            val exact = dbAllGradeConfigs.find { it.courseId == course.id }
            val assignedSubs = dbCourseSubjects.filter { it.courseId == course.id }
                .mapNotNull { cs -> dbSubjects.find { it.id == cs.subjectId }?.name }
                .filter { it.isNotBlank() }

            if (exact != null && exact.diplomaSubjectsJson.isNotEmpty()) {
                exact.getDiplomaSubjects()
            } else if (assignedSubs.isNotEmpty()) {
                assignedSubs
            } else {
                val templateId = StudentGradeConfig.getDiplomaTemplateId(course.diplomaName)
                val deptTemplateId = StudentGradeConfig.getDepartmentTemplateId(course.departmentName)
                val template = dbAllGradeConfigs.find { it.courseId == templateId }
                    ?: dbAllGradeConfigs.find { it.courseId == deptTemplateId }
                
                template?.getDiplomaSubjects() ?: StudentGradeConfig.DEFAULT_DIPLOMA_SUBJECTS
            }
        }
    }

    val defaultFieldsForSelectedCourse = remember(selectedCourseForGrades, dbAllGradeConfigs) {
        val course = selectedCourseForGrades
        if (course == null) {
            listOf(
                Pair("حضور", 10),
                Pair("مشاركة", 10),
                Pair("تكاليف", 20),
                Pair("اختبار نظري", 30),
                Pair("اختبار عملي", 30)
            )
        } else {
            val dipTemplateId = StudentGradeConfig.getDiplomaTemplateId(course.diplomaName)
            val dipConfig = dbAllGradeConfigs.find { it.courseId == dipTemplateId }
            
            val deptTemplateId = StudentGradeConfig.getDepartmentTemplateId(course.departmentName)
            val deptConfig = dbAllGradeConfigs.find { it.courseId == deptTemplateId }
            
            val templateConfig = dipConfig ?: deptConfig
            if (templateConfig != null) {
                StudentGradeConfig.deserializeFields(templateConfig.customFieldsJson)
            } else {
                if (course.departmentName.contains("حاسب") || course.departmentName.contains("حاسوب")) {
                    listOf(
                        Pair("حضور", 5),
                        Pair("مشاركة", 5),
                        Pair("تكاليف", 10),
                        Pair("مشاريع", 20),
                        Pair("اختبار نظري", 20),
                        Pair("اختبار عملي", 40)
                    )
                } else {
                    listOf(
                        Pair("حضور", 10),
                        Pair("مشاركة", 10),
                        Pair("تكاليف", 20),
                        Pair("اختبار نظري", 30),
                        Pair("اختبار عملي", 30)
                    )
                }
            }
        }
    }

    // Subject weights states
    val defaultDiplomaWeights = remember(selectedCourseForGrades?.id, courseSubjects, dbAllGradeConfigs) {
        val initial = androidx.compose.runtime.mutableStateMapOf<String, String>()
        val course = selectedCourseForGrades
        var templateConfig: StudentGradeConfig? = null
        if (course != null) {
            val dipTemplateId = StudentGradeConfig.getDiplomaTemplateId(course.diplomaName)
            templateConfig = dbAllGradeConfigs.find { it.courseId == dipTemplateId }
            if (templateConfig == null) {
                val deptTemplateId = StudentGradeConfig.getDepartmentTemplateId(course.departmentName)
                templateConfig = dbAllGradeConfigs.find { it.courseId == deptTemplateId }
            }
            if (templateConfig == null) {
                val siblingCourseIds = dbCourses.filter { it.diplomaName == course.diplomaName && it.id != course.id }.map { it.id }
                templateConfig = dbAllGradeConfigs.find { it.courseId in siblingCourseIds }
            }
            if (templateConfig == null) {
                templateConfig = dbAllGradeConfigs.find { it.courseId == course.id }
            }
        }
        val templateWeights = templateConfig?.getSubjectWeights() ?: emptyMap()
        
        courseSubjects.forEach { sub ->
            val w = templateWeights[sub]
            if (w != null) {
                initial[sub] = w.toInt().toString()
            } else {
                val eq = 100 / courseSubjects.size
                initial[sub] = eq.toString()
            }
        }
        
        // Ensure total is 100
        val sum = initial.values.sumOf { it.toDoubleOrNull() ?: 0.0 }
        if (sum != 100.0 && courseSubjects.isNotEmpty()) {
            val diff = 100.0 - sum
            val firstSub = courseSubjects[0]
            val currentVal = initial[firstSub]?.toDoubleOrNull() ?: 0.0
            initial[firstSub] = (currentVal + diff).toInt().toString()
        }
        initial
    }

    val customSubjectsWeights = remember(selectedCourseForGrades?.id) {
        mutableStateMapOf<String, String>()
    }

    var passingGradeInput by remember(selectedCourseForGrades?.id, currentConfig) {
        mutableStateOf(currentConfig?.passingGradePercentage?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() } ?: "75")
    }

    // Dialog State for Grade Entry
    var showGradeDialogForStudent by remember { mutableStateOf<Student?>(null) }
    var showGradeDialogForSubject by remember { mutableStateOf<String?>(null) } // Subject Name

    var showDeleteGradeConfigConfirmDialog by remember { mutableStateOf(false) }
    var showEditWeightsDialog by remember { mutableStateOf(false) }
    var showBulkComponentDialog by remember { mutableStateOf(false) }
    var showBulkFinalGradeDialog by remember { mutableStateOf(false) }
    var showSmartPrefillConfirmDialog by remember { mutableStateOf(false) }
    var showAutoSyncConfirmDialog by remember { mutableStateOf(false) }
    var showImportExportExcelDialog by remember { mutableStateOf(false) }

    val courseGradingModes by viewModel.courseGradingModes.collectAsState()

    var showReportTypeDialog by remember { mutableStateOf(false) }
    var pendingShareAction by remember { mutableStateOf<((String) -> Unit)?>(null) }
    var showWhatsAppChoiceDialog by remember { mutableStateOf(false) }
    var shareMessageText by remember { mutableStateOf("") }
    val selectedTabIndex by viewModel.selectedGradesTabIndex.collectAsState()

    var gradeSearchQuery by remember { mutableStateOf("") }
    var gradeFilterChip by remember { mutableStateOf("الكل") }

    val filteredCourseStudents = remember(courseStudents, gradeSearchQuery, gradeFilterChip, courseGrades, currentConfig, dbAllGrades) {
        val query = gradeSearchQuery.trim()
        val rawSubjects = if (currentConfig?.isDiploma == true) {
            currentConfig.getDiplomaSubjects()
        } else {
            val configFields = StudentGradeConfig.deserializeFields(currentConfig?.customFieldsJson ?: "")
            configFields.map { it.first.substringBefore("_") }.distinct()
        }
        val subjects = StudentGradeConfig.sortSubjectsList(rawSubjects)

        courseStudents.filter { student ->
            val matchesSearch = query.isEmpty() ||
                    student.name.contains(query, ignoreCase = true) ||
                    student.id.toString().contains(query) ||
                    student.phoneNumber.contains(query)

            val studentGrades = courseGrades.filter { it.studentId == student.id && it.getTotalScore() > 0.0 }
            val isFullyGraded = subjects.isNotEmpty() && subjects.all { subj -> studentGrades.any { it.subjectName == subj } }
            val hasIncomplete = !isFullyGraded
            val hasPast = dbAllGrades.any { it.studentId == student.id && it.courseId != student.courseId && it.getTotalScore() > 0 }

            val matchesFilter = when (gradeFilterChip) {
                "مكتمل الرصد" -> isFullyGraded
                "غير مكتمل" -> hasIncomplete
                "سجل سابق متوفر" -> hasPast
                else -> true
            }

            matchesSearch && matchesFilter
        }
    }

    // Live Automatic Grade Synchronization for AUTO Mode (Updates student grades in real-time)
    val currentModeForCourse = selectedCourseForGrades?.let { 
        courseGradingModes[it.id] ?: viewModel.getCourseGradingMode(it.id) 
    } ?: "AUTO"

    LaunchedEffect(
        selectedCourseForGrades?.id,
        currentModeForCourse,
        dbAssignmentSubmissions.size,
        dbAssignmentTemplates.size,
        dbAllStudentAttendance.size
    ) {
        val course = selectedCourseForGrades
        if (course != null && currentModeForCourse == "AUTO") {
            viewModel.autoSyncGradesFromAttendanceAndAssignments(course.id)
        }
    }

    // Navigation and Main UI Scaffold
    MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->

        Column(modifier = Modifier.fillMaxSize().padding(innerPadding).background(MaterialTheme.colorScheme.background)) {


            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                edgePadding = 6.dp,
                containerColor = if (viewModel.isDarkTheme.collectAsState().value) Color(0xFF1E293B) else Color(0xFFF1F5F9),
                contentColor = DawamiNavy,
                indicator = {},
                divider = {},
                modifier = Modifier
                    .padding(8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .padding(2.dp)
            ) {
                val gradeTabs = listOf(
                    "رصد الدرجات 📝",
                    "المشاريع والواجبات 📋",
                    "التصحيح الآلي 🤖",
                    "كشوف الدرجات 📜"
                )
                gradeTabs.forEachIndexed { tabIndex, title ->
                    Tab(
                        selected = selectedTabIndex == tabIndex,
                        onClick = { viewModel.setSelectedGradesTabIndex(tabIndex) },
                        modifier = Modifier
                            .padding(2.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (selectedTabIndex == tabIndex) (if (viewModel.isDarkTheme.collectAsState().value) Color(0xFF334155) else Color.White)
                                else Color.Transparent
                            )
                    ) {
                        Text(
                            text = title,
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
            if (selectedTabIndex == 0) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp),

            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            // Screen Header Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(10.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = DawamiNavy.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Grade, contentDescription = null, tint = DawamiNavy)
                                }
                            }
                            Text(
                                text = "نظام رصد الدرجات المتكامل",
                                color = DawamiNavy,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "اختر الدورة التدريبية لتهيئة توزيع درجات المواد ومن ثم رصدها للطلاب بسلاسة ويسر.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            lineHeight = 18.sp
                        )

                        // Select Course Dropdown
                        ExposedDropdownMenuBox(
                            expanded = isCourseDropdownExpanded,
                            onExpandedChange = { isCourseDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = selectedCourseForGrades?.name ?: "اختر الدورة التدريبية...",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("الدورة التدريبية") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCourseDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                            )

                            ExposedDropdownMenu(
                                expanded = isCourseDropdownExpanded,
                                onDismissRequest = { isCourseDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                            )
                                            Icon(
                                                imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = null,
                                                tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.toggleShowCompletedCoursesInDropdowns()
                                    }
                                )
                                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                                val displayedCourses = if (showCompletedCourses) dbCourses else dbCourses.filter { !it.isCompleted }
                                displayedCourses.forEach { course ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = if (course.isCompleted) "${course.name} (منتهية 🔒)" else course.name,
                                                fontWeight = FontWeight.Medium,
                                                color = if (course.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                            )
                                        },
                                        onClick = {
                                            viewModel.selectCourseForGrades(course)
                                            isCourseDropdownExpanded = false
                                            // Reset temp custom setup configs
                                            customSubjectsList = emptyList()
                                            customFieldsList = emptyList()
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (selectedCourseForGrades != null) {
                if (isCourseEnded) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isLockedForEditing) Color(0xFFF8FAFC) else Color(0xFFFFFBEB)
                            ),
                            border = BorderStroke(
                                1.2.dp,
                                if (isLockedForEditing) Color(0xFF94A3B8) else Color(0xFFF59E0B)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(if (isLockedForEditing) Color(0xFFE2E8F0) else Color(0xFFFEF3C7)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isLockedForEditing) Icons.Default.Lock else Icons.Default.LockOpen,
                                            contentDescription = null,
                                            tint = if (isLockedForEditing) Color(0xFF475569) else Color(0xFFD97706),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = if (isLockedForEditing) "دورة منتهية رسمياً (وضع الأرشيف والحماية 🔒)" else "وضع التعديل الاستثنائي مفعّل ⚠️",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isLockedForEditing) Color(0xFF1E293B) else Color(0xFF92400E)
                                        )
                                        val endDateTxt = selectedCourseForGrades?.endDate?.ifBlank { "تاريخ سابق" } ?: "تاريخ سابق"
                                        Text(
                                            text = if (isLockedForEditing)
                                                "انتهت بتاريخ ($endDateTxt). الدرجات محفوظة للقراءة فقط لمنع التعديل بالخطأ."
                                            else
                                                "تم فتح قفل التعديل. يمكنك تعديل الدرجات، وتذكر إعادة القفل بعد الانتهاء.",
                                            fontSize = 10.sp,
                                            color = if (isLockedForEditing) Color(0xFF64748B) else Color(0xFFB45309),
                                            lineHeight = 14.sp
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        if (isLockedForEditing) {
                                            showUnlockConfirmDialog = true
                                        } else {
                                            isEditUnlockedForEndedCourse = false
                                            Toast.makeText(context, "تمت إعادة قفل وحماية سجلات الدرجات بنجاح 🔒", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isLockedForEditing) DawamiNavy else Color(0xFFD97706)
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isLockedForEditing) Icons.Default.LockOpen else Icons.Default.Lock,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isLockedForEditing) "فتح القفل 🔓" else "إعادة القفل 🔒",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                if (currentConfig == null || currentConfig.customFieldsJson.isBlank()) {
                    // --- CONFIGURATION SETUP VIEW ---
                    item {
                        val matchingDeptConfig = remember(selectedCourseForGrades, dbAllGradeConfigs) {
                            selectedCourseForGrades?.let { course ->
                                if (course.departmentName.isNotBlank()) {
                                    val templateId = StudentGradeConfig.getDepartmentTemplateId(course.departmentName)
                                    dbAllGradeConfigs.find { it.courseId == templateId }
                                        ?: dbAllGradeConfigs.find { gc ->
                                            val gcCourse = dbCourses.find { it.id == gc.courseId }
                                            gcCourse != null && gcCourse.id != course.id && gcCourse.departmentName.isNotEmpty() && gcCourse.departmentName == course.departmentName
                                        }
                                } else null
                            }
                        }

                        val matchingDiplConfig = remember(selectedCourseForGrades, dbAllGradeConfigs) {
                            selectedCourseForGrades?.let { course ->
                                if (course.diplomaName.isNotBlank()) {
                                    val templateId = StudentGradeConfig.getDiplomaTemplateId(course.diplomaName)
                                    dbAllGradeConfigs.find { it.courseId == templateId }
                                        ?: dbAllGradeConfigs.find { gc ->
                                            val gcCourse = dbCourses.find { it.id == gc.courseId }
                                            gcCourse != null && gcCourse.id != course.id && gcCourse.diplomaName.isNotEmpty() && gcCourse.diplomaName == course.diplomaName
                                        }
                                } else null
                            }
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(10.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = "تهيئة درجات دورة: ${selectedCourseForGrades?.name}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = DawamiNavy
                                )

                                val allSavedTemplates = remember(dbAllGradeConfigs) {
                                    dbAllGradeConfigs.filter { it.courseId < 0 || it.courseName.startsWith("قالب ") }
                                }
                                var isTemplateDropdownExpanded by remember { mutableStateOf(false) }

                                if (allSavedTemplates.isNotEmpty()) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = DawamiTeal.copy(alpha = 0.05f)),
                                        border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.3f)),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Text(
                                                text = "📋 تطبيق قالب محفوظ مسبقاً:",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = DawamiTeal
                                            )
                                            
                                            ExposedDropdownMenuBox(
                                                expanded = isTemplateDropdownExpanded,
                                                onExpandedChange = { isTemplateDropdownExpanded = !isTemplateDropdownExpanded }
                                            ) {
                                                OutlinedTextField(
                                                    value = "اختر قالباً لتطبيقه...",
                                                    onValueChange = {},
                                                    readOnly = true,
                                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTemplateDropdownExpanded) },
                                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                                                    textStyle = TextStyle(fontSize = 11.sp)
                                                )
                                                ExposedDropdownMenu(
                                                    expanded = isTemplateDropdownExpanded,
                                                    onDismissRequest = { isTemplateDropdownExpanded = false }
                                                ) {
                                                    allSavedTemplates.forEach { template ->
                                                        DropdownMenuItem(
                                                            text = { Text(template.courseName, fontSize = 11.sp) },
                                                            onClick = {
                                                                selectedCourseForGrades?.let { course ->
                                                                    viewModel.saveGradeConfig(
                                                                        courseId = course.id,
                                                                        courseName = course.name,
                                                                        isDiploma = template.isDiploma,
                                                                        customFields = StudentGradeConfig.deserializeFields(template.customFieldsJson),
                                                                        subjectWeights = template.getSubjectWeights()
                                                                    )
                                                                    Toast.makeText(context, "تم تطبيق ${template.courseName} بنجاح! 🎉", Toast.LENGTH_SHORT).show()
                                                                }
                                                                isTemplateDropdownExpanded = false
                                                            },
                                                            trailingIcon = {
                                                                IconButton(
                                                                    onClick = {
                                                                        viewModel.deleteStudentGradeConfigByCourseId(template.courseId)
                                                                        Toast.makeText(context, "تم حذف القالب بنجاح! 🗑️", Toast.LENGTH_SHORT).show()
                                                                    }
                                                                ) {
                                                                    Icon(
                                                                        imageVector = Icons.Default.Delete,
                                                                        contentDescription = "حذف القالب",
                                                                        tint = Color.Red.copy(alpha = 0.7f),
                                                                        modifier = Modifier.size(18.dp)
                                                                    )
                                                                }
                                                            }
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Smart templates suggestion UI
                                if (matchingDeptConfig != null || matchingDiplConfig != null) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = DawamiTeal.copy(alpha = 0.05f)),
                                        border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.3f)),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Text(
                                                text = "📋 قوالب ذكية مقترحة للقسم / الدبلوم مسبقاً:",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = DawamiTeal
                                            )
                                            
                                            if (matchingDeptConfig != null) {
                                                Button(
                                                    onClick = {
                                                        selectedCourseForGrades?.let { course ->
                                                            viewModel.saveGradeConfig(
                                                                courseId = course.id,
                                                                courseName = course.name,
                                                                isDiploma = matchingDeptConfig.isDiploma,
                                                                customFields = StudentGradeConfig.deserializeFields(matchingDeptConfig.customFieldsJson),
                                                                subjectWeights = matchingDeptConfig.getSubjectWeights()
                                                            )
                                                            Toast.makeText(context, "تم تطبيق قالب قسم (${course.departmentName}) بنجاح! 🎉", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                                    modifier = Modifier.fillMaxWidth(),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("تطبيق قالب القسم: ${selectedCourseForGrades?.departmentName}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            
                                            if (matchingDiplConfig != null) {
                                                Button(
                                                    onClick = {
                                                        selectedCourseForGrades?.let { course ->
                                                            viewModel.saveGradeConfig(
                                                                courseId = course.id,
                                                                courseName = course.name,
                                                                isDiploma = matchingDiplConfig.isDiploma,
                                                                customFields = StudentGradeConfig.deserializeFields(matchingDiplConfig.customFieldsJson),
                                                                subjectWeights = matchingDiplConfig.getSubjectWeights()
                                                            )
                                                            Toast.makeText(context, "تم تطبيق قالب دبلوم (${course.diplomaName}) بنجاح! 🎉", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                                    modifier = Modifier.fillMaxWidth(),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("تطبيق قالب دبلوم: ${selectedCourseForGrades?.diplomaName}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Option 1: Department/Diploma Configuration
                                    Card(
                                        onClick = { configTypeIsDiploma = true },
                                        modifier = Modifier.weight(1f),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (configTypeIsDiploma) DawamiNavy.copy(alpha = 0.05f) else Color.White
                                        ),
                                        border = BorderStroke(
                                            width = if (configTypeIsDiploma) 2.dp else 1.dp,
                                            color = if (configTypeIsDiploma) DawamiNavy else Color(0xFFE2E8F0)
                                        ),
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Computer,
                                                contentDescription = null,
                                                tint = if (configTypeIsDiploma) DawamiNavy else Color.Gray
                                            )
                                            Text(
                                                text = "تهيئة القسم والدبلوم",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = if (configTypeIsDiploma) DawamiNavy else Color.DarkGray
                                            )
                                            val fieldsSummary = defaultFieldsForSelectedCourse.joinToString("، ") { "${it.first} ${it.second}" }
                                            Text(
                                                text = "${courseSubjects.size} مواد بوزن نسبي مجموعهم 100 درجة (التقسيم للمادة: $fieldsSummary)",
                                                textAlign = TextAlign.Center,
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                lineHeight = 14.sp
                                            )
                                        }
                                    }

                                    // Option 2: General/Custom Course
                                    Card(
                                        onClick = { configTypeIsDiploma = false },
                                        modifier = Modifier.weight(1f),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (!configTypeIsDiploma) DawamiNavy.copy(alpha = 0.05f) else Color.White
                                        ),
                                        border = BorderStroke(
                                            width = if (!configTypeIsDiploma) 2.dp else 1.dp,
                                            color = if (!configTypeIsDiploma) DawamiNavy else Color(0xFFE2E8F0)
                                        ),
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Create,
                                                contentDescription = null,
                                                tint = if (!configTypeIsDiploma) DawamiNavy else Color.Gray
                                            )
                                            Text(
                                                text = "دورة عامة / مخصصة",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = if (!configTypeIsDiploma) DawamiNavy else Color.DarkGray
                                            )
                                            Text(
                                                text = "قم بإدخال أسماء المواد يدوياً مع تقسيم الدرجة الكلية (المجموع 100) وتحديد الأوزان النسبية للمواد",
                                                textAlign = TextAlign.Center,
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                lineHeight = 14.sp
                                            )
                                        }
                                    }
                                }

                                if (configTypeIsDiploma) {
                                    // Previews Diploma Setup
                                    Surface(
                                        color = Color(0xFFF8FAFC),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            val fieldsSummary = defaultFieldsForSelectedCourse.joinToString("، ") { "${it.first} ${it.second}" }
                                            Text(
                                                text = "📋 سيتم تهيئة الـ ${courseSubjects.size} مواد التالية تلقائياً مع تقسيم درجات كل مادة حسب تهيئة القسم والبرنامج ($fieldsSummary):",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = DawamiNavy
                                            )
                                            courseSubjects.forEach { sub ->
                                                Text("• $sub", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                            }
                                        }
                                    }

                                    // Relative Weights for Diploma
                                    Surface(
                                        color = Color(0xFFF8FAFC),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Text(
                                                text = "⚖️ حدد أوزان المواد (المجموع 100 للمعدل النسبي الموزون، أو 700 لدبلوم الحاسوب بحيث كل مادة من 100):",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = DawamiNavy
                                            )
                                            
                                            courseSubjects.forEach { sub ->
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = sub,
                                                        fontSize = 11.sp,
                                                        modifier = Modifier.weight(1.5f),
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    OutlinedTextField(
                                                        value = defaultDiplomaWeights[sub] ?: "",
                                                        onValueChange = { valFiltered ->
                                                            val numeric = valFiltered.filter { it.isDigit() || it == '.' }
                                                            defaultDiplomaWeights[sub] = numeric
                                                        },
                                                        placeholder = { Text("الوزن", fontSize = 11.sp) },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.weight(0.7f).height(46.dp),
                                                        shape = RoundedCornerShape(8.dp),
                                                        singleLine = true,
                                                        textStyle = TextStyle(fontSize = 11.sp)
                                                    )
                                                }
                                            }
                                            
                                            val currentWeightsSum = defaultDiplomaWeights.values.sumOf { it.toDoubleOrNull() ?: 0.0 }
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "إجمالي أوزان المواد الحالي: $currentWeightsSum",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    color = if (currentWeightsSum > 0.0) Color(0xFF10B981) else Color.Red
                                                )
                                                
                                                TextButton(
                                                    onClick = {
                                                        // Distribute equally
                                                        val eq = 100 / courseSubjects.size
                                                        courseSubjects.forEach { sub ->
                                                            defaultDiplomaWeights[sub] = eq.toString()
                                                        }
                                                        val sum = courseSubjects.sumOf { defaultDiplomaWeights[it]?.toDoubleOrNull() ?: 0.0 }
                                                        if (sum != 100.0 && courseSubjects.isNotEmpty()) {
                                                            val diff = 100.0 - sum
                                                            val firstSub = courseSubjects[0]
                                                            val currentVal = defaultDiplomaWeights[firstSub]?.toDoubleOrNull() ?: 0.0
                                                            defaultDiplomaWeights[firstSub] = (currentVal + diff).toInt().toString()
                                                        }
                                                    }
                                                ) {
                                                    Text("توزيع بالتساوي ⚖️", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                                }
                                            }
                                        }
                                    }

                                    // Passing Grade Percentage for Diploma
                                    Surface(
                                        color = Color(0xFFF0FDF4),
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "🎯 نسبة النجاح المعتمدة للمادة والدبلوم (%):",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.5.sp,
                                                    color = Color(0xFF166534)
                                                )
                                                OutlinedTextField(
                                                    value = passingGradeInput,
                                                    onValueChange = { valFiltered ->
                                                        val numeric = valFiltered.filter { it.isDigit() || it == '.' }
                                                        passingGradeInput = numeric
                                                    },
                                                    placeholder = { Text("75", fontSize = 11.sp) },
                                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                    modifier = Modifier.width(80.dp).height(46.dp),
                                                    shape = RoundedCornerShape(8.dp),
                                                    singleLine = true,
                                                    textStyle = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF166534))
                                                )
                                            }
                                            val currentPassVal = passingGradeInput.toDoubleOrNull() ?: 75.0
                                            Text(
                                                text = "ℹ️ القيمة الافتراضية للنجاح هي $currentPassVal%. يتم احتساب درجة النجاح لكل مادة وفقاً لوزنها تلقائياً (مثلاً إذا كان وزن المادة 15، تكون درجة النجاح فيها ${String.format(java.util.Locale.US, "%.2f", (currentPassVal / 100.0) * 15.0)}).",
                                                fontSize = 10.sp,
                                                color = Color(0xFF15803D),
                                                lineHeight = 14.sp
                                            )
                                        }
                                    }

                                    OutlinedTextField(
                                        value = customTemplateNameInput,
                                        onValueChange = { customTemplateNameInput = it },
                                        label = { Text("حفظ كقالب مخصص باسم (اختياري)", fontSize = 11.sp) },
                                        placeholder = { Text("مثال: قالب دبلومات شبكات") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        textStyle = TextStyle(fontSize = 11.sp)
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Button(
                                        onClick = {
                                            val currentWeightsSum = defaultDiplomaWeights.values.sumOf { it.toDoubleOrNull() ?: 0.0 }
                                            if (currentWeightsSum <= 0.0) {
                                                Toast.makeText(context, "الرجاء إدخال أوزان صحيحة للمواد! المجموع الحالي: $currentWeightsSum", Toast.LENGTH_LONG).show()
                                                return@Button
                                            }

                                            val fixedFields = defaultFieldsForSelectedCourse
                                            val compiledFields = mutableListOf<Pair<String, Int>>()
                                            courseSubjects.forEach { sub ->
                                                fixedFields.forEach { field ->
                                                    compiledFields.add(Pair("${sub}_${field.first}", field.second))
                                                }
                                            }

                                            val weightsMap = defaultDiplomaWeights.mapValues { it.value.toDoubleOrNull() ?: 0.0 }
                                            val selectedPassPercentage = passingGradeInput.toDoubleOrNull() ?: 75.0

                                            selectedCourseForGrades?.let { course ->
                                                viewModel.saveGradeConfig(
                                                    courseId = course.id,
                                                    courseName = course.name,
                                                    isDiploma = true,
                                                    customFields = compiledFields,
                                                    subjectWeights = weightsMap,
                                                    passingGradePercentage = selectedPassPercentage
                                                )
                                                
                                                // Proactively save as department & diploma template if names are set
                                                if (course.departmentName.isNotBlank()) {
                                                    viewModel.saveDepartmentTemplate(course.departmentName, isDiploma = true, compiledFields, weightsMap, selectedPassPercentage)
                                                }
                                                if (course.diplomaName.isNotBlank()) {
                                                    viewModel.saveDiplomaTemplate(course.diplomaName, isDiploma = true, compiledFields, weightsMap, selectedPassPercentage)
                                                }
                                                if (customTemplateNameInput.isNotBlank()) {
                                                    viewModel.saveCustomTemplate(
                                                        templateName = customTemplateNameInput.trim(),
                                                        isDiploma = true,
                                                        customFields = compiledFields,
                                                        subjectWeights = weightsMap,
                                                        passingGradePercentage = selectedPassPercentage
                                                    )
                                                    customTemplateNameInput = ""
                                                }

                                                Toast.makeText(context, "تم حفظ تهيئة الدبلوم بالأوزان ونسبة النجاح (${selectedPassPercentage}%) بنجاح! 🎉", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().height(48.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                                    ) {
                                        Text("تأكيد وحفظ تهيئة الدبلوم", fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    // Dynamic Custom Setup
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text(
                                            text = "1. إضافة أسماء المواد الدراسية للدورة:",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = DawamiNavy
                                        )

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = customSubjectNameInput,
                                                onValueChange = { customSubjectNameInput = it },
                                                label = { Text("اسم المادة") },
                                                placeholder = { Text("مثل: لغة إنجليزية 1") },
                                                modifier = Modifier.weight(1f),
                                                singleLine = true,
                                                shape = RoundedCornerShape(12.dp)
                                            )

                                            Button(
                                                onClick = {
                                                    val sub = customSubjectNameInput.trim()
                                                    if (sub.isNotEmpty() && !customSubjectsList.contains(sub)) {
                                                        customSubjectsList = customSubjectsList + sub
                                                        customSubjectsWeights[sub] = "0.0"
                                                        customSubjectNameInput = ""
                                                    }
                                                },
                                                modifier = Modifier.height(56.dp),
                                                shape = RoundedCornerShape(12.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                                            ) {
                                                Icon(Icons.Default.Add, contentDescription = "إضافة مادة")
                                            }
                                        }

                                        // Listed Custom Subjects
                                        if (customSubjectsList.isNotEmpty()) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                customSubjectsList.forEach { sub ->
                                                    InputChip(
                                                        selected = true,
                                                        onClick = { 
                                                            customSubjectsList = customSubjectsList - sub 
                                                            customSubjectsWeights.remove(sub)
                                                        },
                                                        label = { Text(sub, fontSize = 11.sp) },
                                                        trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) }
                                                    )
                                                }
                                            }
                                        }

                                        HorizontalDivider(color = Color(0xFFF1F5F9))

                                        Text(
                                            text = "2. تقسيم درجات المادة (المجموع الكلي يجب أن يساوي 100):",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = DawamiNavy
                                        )

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = customFieldNameInput,
                                                onValueChange = { customFieldNameInput = it },
                                                label = { Text("البيان") },
                                                placeholder = { Text("مثل: حضور أو نهائي") },
                                                modifier = Modifier.weight(1.2f),
                                                singleLine = true,
                                                shape = RoundedCornerShape(12.dp)
                                            )

                                            OutlinedTextField(
                                                value = customFieldMaxInput,
                                                onValueChange = { customFieldMaxInput = it },
                                                label = { Text("الدرجة") },
                                                placeholder = { Text("50") },
                                                modifier = Modifier.weight(0.8f),
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                singleLine = true,
                                                shape = RoundedCornerShape(12.dp)
                                            )

                                            Button(
                                                onClick = {
                                                    val fName = customFieldNameInput.trim()
                                                    val fMax = customFieldMaxInput.toIntOrNull() ?: 0
                                                    if (fName.isNotEmpty() && fMax > 0) {
                                                        val currentSum = customFieldsList.sumOf { it.second }
                                                        if (currentSum + fMax > 100) {
                                                            Toast.makeText(context, "الحد الأقصى للمجموع هو 100! المجموع الحالي: $currentSum", Toast.LENGTH_SHORT).show()
                                                        } else {
                                                            customFieldsList = customFieldsList + Pair(fName, fMax)
                                                            customFieldNameInput = ""
                                                            customFieldMaxInput = ""
                                                        }
                                                    }
                                                },
                                                modifier = Modifier.height(56.dp),
                                                shape = RoundedCornerShape(12.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                                            ) {
                                                Icon(Icons.Default.Add, contentDescription = "إضافة تقسيم")
                                            }
                                        }

                                        // Listed custom fields divisions
                                        val totalCustomSum = customFieldsList.sumOf { it.second }
                                        Text(
                                            text = "إجمالي تقسيم الدرجات: $totalCustomSum من 100",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = if (totalCustomSum == 100) Color(0xFF10B981) else DawamiGold
                                        )

                                        if (customFieldsList.isNotEmpty()) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                customFieldsList.forEach { field ->
                                                    InputChip(
                                                        selected = true,
                                                        onClick = { customFieldsList = customFieldsList - field },
                                                        label = { Text("${field.first}: ${field.second}", fontSize = 11.sp) },
                                                        trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) }
                                                    )
                                                }
                                            }
                                        }

                                        HorizontalDivider(color = Color(0xFFF1F5F9))

                                        // Custom relative weights section
                                        if (customSubjectsList.isNotEmpty()) {
                                            Text(
                                                text = "3. تحديد الأوزان النسبية للمواد الدراسية (المجموع الكلي يجب أن يساوي 100):",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = DawamiNavy
                                            )
                                            
                                            customSubjectsList.forEach { sub ->
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = sub,
                                                        fontSize = 11.sp,
                                                        modifier = Modifier.weight(1.5f),
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    OutlinedTextField(
                                                        value = customSubjectsWeights[sub] ?: "",
                                                        onValueChange = { valFiltered ->
                                                            val numeric = valFiltered.filter { it.isDigit() || it == '.' }
                                                            customSubjectsWeights[sub] = numeric
                                                        },
                                                        placeholder = { Text("الوزن", fontSize = 11.sp) },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.weight(0.7f).height(46.dp),
                                                        shape = RoundedCornerShape(8.dp),
                                                        singleLine = true,
                                                        textStyle = TextStyle(fontSize = 11.sp)
                                                    )
                                                }
                                            }
                                            
                                            val customWeightsSum = customSubjectsWeights.values.sumOf { it.toDoubleOrNull() ?: 0.0 }
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "إجمالي أوزان المواد الحالي: $customWeightsSum",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    color = if (customWeightsSum > 0.0) Color(0xFF10B981) else Color.Red
                                                )
                                                
                                                TextButton(
                                                    onClick = {
                                                        val size = customSubjectsList.size
                                                        if (size > 0) {
                                                            val base = 100.0 / size
                                                            customSubjectsList.forEach { sub ->
                                                                customSubjectsWeights[sub] = String.format(Locale.US, "%.1f", base)
                                                            }
                                                        }
                                                    }
                                                ) {
                                                    Text("توزيع بالتساوي", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                                }
                                            }
                                        }

                                        // Passing Grade Percentage for Custom Course
                                        Surface(
                                            color = Color(0xFFF0FDF4),
                                            shape = RoundedCornerShape(12.dp),
                                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(14.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "🎯 نسبة النجاح المعتمدة للمادة والدورة (%):",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 11.5.sp,
                                                        color = Color(0xFF166534)
                                                    )
                                                    OutlinedTextField(
                                                        value = passingGradeInput,
                                                        onValueChange = { valFiltered ->
                                                            val numeric = valFiltered.filter { it.isDigit() || it == '.' }
                                                            passingGradeInput = numeric
                                                        },
                                                        placeholder = { Text("75", fontSize = 11.sp) },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.width(80.dp).height(46.dp),
                                                        shape = RoundedCornerShape(8.dp),
                                                        singleLine = true,
                                                        textStyle = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF166534))
                                                    )
                                                }
                                                val currentPassVal = passingGradeInput.toDoubleOrNull() ?: 75.0
                                                Text(
                                                    text = "ℹ️ القيمة الافتراضية للنجاح هي $currentPassVal%. يتم احتساب درجة النجاح لكل مادة وفقاً لوزنها تلقائياً.",
                                                    fontSize = 10.sp,
                                                    color = Color(0xFF15803D),
                                                    lineHeight = 14.sp
                                                )
                                            }
                                        }

                                        OutlinedTextField(
                                            value = customTemplateNameInput,
                                            onValueChange = { customTemplateNameInput = it },
                                            label = { Text("حفظ كقالب مخصص باسم (اختياري)", fontSize = 11.sp) },
                                            placeholder = { Text("مثال: قالب دورات البرمجة") },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true,
                                            shape = RoundedCornerShape(12.dp),
                                            textStyle = TextStyle(fontSize = 11.sp)
                                        )

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Button(
                                            onClick = {
                                                if (customSubjectsList.isEmpty()) {
                                                    Toast.makeText(context, "الرجاء إضافة مادة واحدة على الأقل!", Toast.LENGTH_SHORT).show()
                                                    return@Button
                                                }
                                                if (totalCustomSum != 100) {
                                                    Toast.makeText(context, "يجب أن يكون إجمالي تقسيم درجات المادة مساوياً لـ 100 تماماً!", Toast.LENGTH_SHORT).show()
                                                    return@Button
                                                }
                                                val customWeightsSum = customSubjectsWeights.values.sumOf { it.toDoubleOrNull() ?: 0.0 }
                                                if (customWeightsSum <= 0.0) {
                                                    Toast.makeText(context, "الرجاء إدخال أوزان صحيحة للمواد! المجموع الحالي: $customWeightsSum", Toast.LENGTH_LONG).show()
                                                    return@Button
                                                }

                                                val compiled = mutableListOf<Pair<String, Int>>()
                                                customSubjectsList.forEach { sub ->
                                                    customFieldsList.forEach { field ->
                                                        compiled.add(Pair("${sub}_${field.first}", field.second))
                                                    }
                                                }

                                                val weightsMap = customSubjectsWeights.mapValues { it.value.toDoubleOrNull() ?: 0.0 }
                                                val selectedPassPercentage = passingGradeInput.toDoubleOrNull() ?: 75.0

                                                selectedCourseForGrades?.let { course ->
                                                    viewModel.saveGradeConfig(
                                                        courseId = course.id,
                                                        courseName = course.name,
                                                        isDiploma = false,
                                                        customFields = compiled,
                                                        subjectWeights = weightsMap,
                                                        passingGradePercentage = selectedPassPercentage
                                                    )
                                                    
                                                    // Save template records
                                                    if (course.departmentName.isNotBlank()) {
                                                        viewModel.saveDepartmentTemplate(course.departmentName, isDiploma = false, compiled, weightsMap, selectedPassPercentage)
                                                    }
                                                    if (course.diplomaName.isNotBlank()) {
                                                        viewModel.saveDiplomaTemplate(course.diplomaName, isDiploma = false, compiled, weightsMap, selectedPassPercentage)
                                                    }
                                                    if (customTemplateNameInput.isNotBlank()) {
                                                        viewModel.saveCustomTemplate(
                                                            templateName = customTemplateNameInput.trim(),
                                                            isDiploma = false,
                                                            customFields = compiled,
                                                            subjectWeights = weightsMap,
                                                            passingGradePercentage = selectedPassPercentage
                                                        )
                                                        customTemplateNameInput = ""
                                                    }

                                                    Toast.makeText(context, "تم حفظ تهيئة الدورة المخصصة بالأوزان ونسبة النجاح (${selectedPassPercentage}%) بنجاح! 🎉", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth().height(48.dp),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                                        ) {
                                            Text("تأكيد وحفظ تهيئة الدورة المخصصة والأوزان", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // --- GRADES ENTRY & MANAGEMENT VIEW ---
                    item {
                        val planSubjects = remember(currentConfig) {
                            if (currentConfig.isDiploma) {
                                currentConfig.getDiplomaSubjects()
                            } else {
                                val configFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson)
                                configFields.map { it.first.substringBefore("_") }.distinct()
                            }
                        }
                        val fullyGradedCount = remember(courseStudents, courseGrades, planSubjects) {
                            courseStudents.count { s ->
                                planSubjects.isNotEmpty() && planSubjects.all { sub ->
                                    courseGrades.any { it.studentId == s.id && it.subjectName == sub && it.getTotalScore() > 0 }
                                }
                            }
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(16.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(
                                            text = "خطة درجات الدورة: ${if (currentConfig.isDiploma) "دبلوم حاسوب معتمد (7 مواد)" else "دورة مخصصة"}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "${courseStudents.size} طالب مسجل • ${planSubjects.size} مواد • مكتمل الرصد لـ $fullyGradedCount طالب",
                                            color = DawamiGold,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Surface(
                                        color = Color.White.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = if (courseStudents.isNotEmpty()) "${((fullyGradedCount.toFloat() / courseStudents.size) * 100).toInt()}% منجز" else "0%",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedButton(
                                        onClick = { viewModel.setSelectedGradesTabIndex(3) },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                        border = BorderStroke(1.dp, DawamiGold),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1.2f).height(36.dp),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                                    ) {
                                        Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(15.dp), tint = DawamiGold)
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("الكشف الشامل", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiGold)
                                    }

                                    // Excel Import & Export Button
                                    Button(
                                        onClick = { showImportExportExcelDialog = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1.3f).height(36.dp),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                                    ) {
                                        Icon(Icons.Default.TableView, contentDescription = null, modifier = Modifier.size(15.dp), tint = Color.White)
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("Excel استيراد/تصدير 📊", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }

                                    if (!currentConfig.isDiploma) {
                                        OutlinedButton(
                                            onClick = {
                                                showEditWeightsDialog = true
                                            },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.weight(0.9f).height(36.dp),
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(2.dp))
                                            Text("الأوزان", fontSize = 10.sp)
                                        }
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            showDeleteGradeConfigConfirmDialog = true
                                        },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(0.9f).height(36.dp),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                    ) {
                                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(13.dp))
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text("تهيئة", fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        if (showDeleteGradeConfigConfirmDialog) {
                            AlertDialog(
                                onDismissRequest = { showDeleteGradeConfigConfirmDialog = false },
                                title = {
                                    Text(
                                        text = "تأكيد إعادة التهيئة ⚠️",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = DawamiNavy
                                    )
                                },
                                text = {
                                    Text(
                                        text = "هل أنت متأكد من مسح التهيئة السابقة وتغييرها؟ سيؤدي هذا الإجراء إلى حذف كافة درجات الطلاب المدخلة لهذه الدورة نهائياً ولا يمكن التراجع عنه.",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                },
                                confirmButton = {
                                    TextButton(
                                        onClick = {
                                            currentConfig?.let {
                                                viewModel.deleteStudentGradeConfigByCourseId(it.courseId)
                                                Toast.makeText(context, "تم مسح التهيئة السابقة، يمكنك اختيار تهيئة جديدة الآن.", Toast.LENGTH_LONG).show()
                                            }
                                            showDeleteGradeConfigConfirmDialog = false
                                        }
                                    ) {
                                        Text("نعم، إعادة تهيئة", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                    }
                                },
                                dismissButton = {
                                    TextButton(
                                        onClick = { showDeleteGradeConfigConfirmDialog = false }
                                    ) {
                                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        }

                        if (showEditWeightsDialog && currentConfig != null) {
                            val weightsMapState = remember(currentConfig) {
                                val existing = currentConfig.getSubjectWeights()
                                val m = androidx.compose.runtime.mutableStateMapOf<String, String>()
                                val rawSubjects = if (currentConfig.isDiploma) currentConfig.getDiplomaSubjects() else StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson).map { it.first.substringBefore("_") }.distinct()
                                val subjects = StudentGradeConfig.sortSubjectsList(rawSubjects)
                                subjects.forEach { s ->
                                    m[s] = existing[s]?.toString() ?: "0.0"
                                }
                                m
                            }
                            var editPassingPercentageInput by remember(currentConfig) {
                                val p = currentConfig.passingGradePercentage
                                mutableStateOf(if (p % 1.0 == 0.0) p.toInt().toString() else p.toString())
                            }

                            AlertDialog(
                                onDismissRequest = { showEditWeightsDialog = false },
                                title = { Text("تعديل أوزان المواد ونسبة النجاح ⚖️", fontWeight = FontWeight.Bold, color = DawamiNavy) },
                                text = {
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("أدخل أوزان المواد ونسبة النجاح المعتمدة للدورة أو الدبلوم.", fontSize = 11.sp, color = Color.Gray)
                                        
                                        // حقل نسبة النجاح
                                        Surface(
                                            color = Color(0xFFF0FDF4),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "🎯 نسبة النجاح المعتمدة (%):",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    color = Color(0xFF166534)
                                                )
                                                OutlinedTextField(
                                                    value = editPassingPercentageInput,
                                                    onValueChange = { 
                                                        val numeric = it.filter { ch -> ch.isDigit() || ch == '.' }
                                                        editPassingPercentageInput = numeric
                                                    },
                                                    modifier = Modifier.width(75.dp).height(44.dp),
                                                    singleLine = true,
                                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                    textStyle = TextStyle(fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF166534))
                                                )
                                            }
                                        }

                                        val currentEditingPassPercent = editPassingPercentageInput.toDoubleOrNull() ?: 75.0

                                        LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp)) {
                                            items(weightsMapState.keys.toList()) { sub ->
                                                val wVal = weightsMapState[sub]?.toDoubleOrNull() ?: 0.0
                                                val passThreshold = (currentEditingPassPercent / 100.0) * wVal
                                                val passThreshStr = if (passThreshold % 1.0 == 0.0) passThreshold.toInt().toString() else String.format(Locale.US, "%.2f", passThreshold)
                                                
                                                Row(
                                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(sub, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                                        Text("حد النجاح: $passThreshStr", fontSize = 9.5.sp, color = Color(0xFF15803D))
                                                    }
                                                    OutlinedTextField(
                                                        value = weightsMapState[sub] ?: "",
                                                        onValueChange = { 
                                                            val numeric = it.filter { ch -> ch.isDigit() || ch == '.' }
                                                            weightsMapState[sub] = numeric
                                                        },
                                                        modifier = Modifier.width(80.dp).height(48.dp),
                                                        singleLine = true,
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        textStyle = TextStyle(fontSize = 11.sp)
                                                    )
                                                }
                                            }
                                        }
                                        val sum = weightsMapState.values.sumOf { it.toDoubleOrNull() ?: 0.0 }
                                        Text("المجموع الحالي للأوزان: $sum", fontWeight = FontWeight.Bold, color = if (sum > 0.0) Color(0xFF10B981) else Color.Red, fontSize = 11.sp)
                                    }
                                },
                                confirmButton = {
                                    Button(
                                        onClick = {
                                            val sum = weightsMapState.values.sumOf { it.toDoubleOrNull() ?: 0.0 }
                                            if (sum <= 0.0) {
                                                Toast.makeText(context, "الرجاء إدخال أوزان صحيحة بحيث يكون المجموع أكبر من صفر", Toast.LENGTH_SHORT).show()
                                                return@Button
                                            }
                                            val newWeights = weightsMapState.mapValues { it.value.toDoubleOrNull() ?: 0.0 }
                                            val newPassPercentage = editPassingPercentageInput.toDoubleOrNull() ?: 75.0

                                            viewModel.saveGradeConfig(
                                                courseId = currentConfig.courseId,
                                                courseName = currentConfig.courseName,
                                                isDiploma = currentConfig.isDiploma,
                                                customFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson),
                                                subjectWeights = newWeights,
                                                passingGradePercentage = newPassPercentage
                                            )
                                            
                                            // Proactively update the diploma template so sibling courses inherit this weight edit automatically!
                                            selectedCourseForGrades?.let { course ->
                                                if (course.diplomaName.isNotEmpty() && currentConfig.isDiploma) {
                                                    val dipTemplateId = StudentGradeConfig.getDiplomaTemplateId(course.diplomaName)
                                                    viewModel.saveGradeConfig(
                                                        courseId = dipTemplateId,
                                                        courseName = "${course.diplomaName} Template",
                                                        isDiploma = true,
                                                        customFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson),
                                                        subjectWeights = newWeights,
                                                        passingGradePercentage = newPassPercentage
                                                    )
                                                }
                                            }
                                            
                                            Toast.makeText(context, "تم حفظ الأوزان ونسبة النجاح (${newPassPercentage}%) بنجاح! 🎉⚖️", Toast.LENGTH_SHORT).show()
                                            showEditWeightsDialog = false
                                        }
                                    ) {
                                        Text("حفظ")
                                    }
                                },
                                dismissButton = {
                                    TextButton(onClick = { showEditWeightsDialog = false }) { Text("إلغاء") }
                                }
                            )
                        }
                    }

                    item {
                        val targetCourseId = selectedCourseForGrades?.id ?: currentConfig.courseId
                        val currentMode = courseGradingModes[targetCourseId] ?: viewModel.getCourseGradingMode(targetCourseId)
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.15f)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Mode title & status
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Tune,
                                            contentDescription = null,
                                            tint = DawamiNavy,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Text(
                                            text = "نظام ونمط رصد درجات الدورة:",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy
                                        )
                                    }
                                    // Current mode badge
                                    Surface(
                                        color = when (currentMode) {
                                            "MANUAL_FINAL" -> Color(0xFFEFF6FF)
                                            "MANUAL_BREAKDOWN" -> Color(0xFFFFFBEB)
                                            else -> Color(0xFFECFDF5)
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        border = BorderStroke(
                                            1.dp,
                                            when (currentMode) {
                                                "MANUAL_FINAL" -> Color(0xFF93C5FD)
                                                "MANUAL_BREAKDOWN" -> Color(0xFFFCD34D)
                                                else -> Color(0xFFA7F3D0)
                                            }
                                        )
                                    ) {
                                        Text(
                                            text = when (currentMode) {
                                                "MANUAL_FINAL" -> "🎯 رصد يدوي نهائي"
                                                "MANUAL_BREAKDOWN" -> "✍️ رصد يدوي تفصيلي"
                                                else -> "🤖 رصد آلي"
                                            },
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (currentMode) {
                                                "MANUAL_FINAL" -> Color(0xFF1D4ED8)
                                                "MANUAL_BREAKDOWN" -> Color(0xFFB45309)
                                                else -> Color(0xFF047857)
                                            },
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                // Mode selection tabs
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFF1F5F9), RoundedCornerShape(10.dp))
                                        .padding(3.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    // 1. AUTO
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (currentMode == "AUTO") DawamiTeal else Color.Transparent)
                                            .clickable {
                                                if (isLockedForEditing) {
                                                    Toast.makeText(context, "سجلات الدورة منتهية ومحمية 🔒. اضغط على 'فتح القفل 🔓' أعلى الشاشة لتغيير النمط.", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    viewModel.setCourseGradingMode(targetCourseId, "AUTO")
                                                    gradeFilterChip = "الكل"
                                                    gradeSearchQuery = ""
                                                    Toast.makeText(context, "تم تفعيل نمط الرصد الآلي للدورة 🤖", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "🤖 رصد آلي",
                                            fontSize = 11.5.sp,
                                            fontWeight = if (currentMode == "AUTO") FontWeight.Bold else FontWeight.Normal,
                                            color = if (currentMode == "AUTO") Color.White else Color(0xFF475569),
                                            textAlign = TextAlign.Center
                                        )
                                    }

                                    // 2. MANUAL_BREAKDOWN
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (currentMode == "MANUAL_BREAKDOWN") Color(0xFFD97706) else Color.Transparent)
                                            .clickable {
                                                if (isLockedForEditing) {
                                                    Toast.makeText(context, "سجلات الدورة منتهية ومحمية 🔒. اضغط على 'فتح القفل 🔓' أعلى الشاشة لتغيير النمط.", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    viewModel.setCourseGradingMode(targetCourseId, "MANUAL_BREAKDOWN")
                                                    gradeFilterChip = "الكل"
                                                    gradeSearchQuery = ""
                                                    Toast.makeText(context, "تم تفعيل نمط الرصد اليدوي لتفاصيل وتكوينات المادة ✍️", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "✍️ يدوي تفصيلي",
                                            fontSize = 11.5.sp,
                                            fontWeight = if (currentMode == "MANUAL_BREAKDOWN") FontWeight.Bold else FontWeight.Normal,
                                            color = if (currentMode == "MANUAL_BREAKDOWN") Color.White else Color(0xFF475569),
                                            textAlign = TextAlign.Center
                                        )
                                    }

                                    // 3. MANUAL_FINAL
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (currentMode == "MANUAL_FINAL") Color(0xFF2563EB) else Color.Transparent)
                                            .clickable {
                                                if (isLockedForEditing) {
                                                    Toast.makeText(context, "سجلات الدورة منتهية ومحمية 🔒. اضغط على 'فتح القفل 🔓' أعلى الشاشة لتغيير النمط.", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    viewModel.setCourseGradingMode(targetCourseId, "MANUAL_FINAL")
                                                    gradeFilterChip = "الكل"
                                                    gradeSearchQuery = ""
                                                    Toast.makeText(context, "تم تفعيل نمط الرصد اليدوي النهائي للمادة 🎯", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "🎯 يدوي نهائي",
                                            fontSize = 11.5.sp,
                                            fontWeight = if (currentMode == "MANUAL_FINAL") FontWeight.Bold else FontWeight.Normal,
                                            color = if (currentMode == "MANUAL_FINAL") Color.White else Color(0xFF475569),
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }

                                // Content per mode
                                when (currentMode) {
                                    "MANUAL_FINAL" -> {
                                        Surface(
                                            color = Color(0xFFEFF6FF),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = Color(0xFF2563EB),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Text(
                                                    text = "🎯 تم تفعيل الرصد اليدوي النهائي: يتم اعتماد الدرجة النهائية المرصودة للمادة مباشرة وتجاهل شاشات المشاريع والاختبار النظري تفادياً لأي تعارض.",
                                                    fontSize = 10.5.sp,
                                                    color = Color(0xFF1E40AF),
                                                    lineHeight = 15.sp
                                                )
                                            }
                                        }


                                    }

                                    "MANUAL_BREAKDOWN" -> {
                                        Surface(
                                            color = Color(0xFFFFFBEB),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.EditNote,
                                                    contentDescription = null,
                                                    tint = Color(0xFFD97706),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Text(
                                                    text = "✍️ تم تفعيل رصد تفاصيل وتكوينات المادة: يسمح لك بكتابة وتعديل درجات الحضور والمشاركة والتكاليف والمشاريع والاختبارات يدوياً لكل طالب.",
                                                    fontSize = 10.5.sp,
                                                    color = Color(0xFF92400E),
                                                    lineHeight = 15.sp
                                                )
                                            }
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    if (isLockedForEditing) {
                                                        Toast.makeText(context, "سجلات الدورة مقفلة ومحمية 🔒. اضغط على 'فتح القفل 🔓' أعلى الشاشة للرصد.", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        showBulkComponentDialog = true
                                                    }
                                                },
                                                modifier = Modifier.weight(1.2f).height(44.dp),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                                            ) {
                                                Icon(Icons.Default.FlashOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(17.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "تطبيق درجة جماعية للمكون ⚡",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    color = Color.White
                                                )
                                            }

                                             OutlinedButton(
                                                onClick = {
                                                    if (isLockedForEditing) {
                                                        Toast.makeText(context, "سجلات الدورة مقفلة ومحمية 🔒. اضغط على 'فتح القفل 🔓' أعلى الشاشة للتعبئة.", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        showSmartPrefillConfirmDialog = true
                                                    }
                                                },
                                                modifier = Modifier.weight(1f).height(44.dp),
                                                shape = RoundedCornerShape(10.dp),
                                                border = BorderStroke(1.dp, Color(0xFFD97706)),
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD97706))
                                            ) {
                                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(17.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "تعبئة ذكية 📥",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }

                                    else -> {
                                        Surface(
                                            color = Color(0xFFF0FDF4),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.AutoAwesome,
                                                    contentDescription = null,
                                                    tint = DawamiTeal,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Text(
                                                    text = "🤖 الرصد الآلي نشط: يتم حساب وتحديث درجات الحضور والمشاركة والواجبات تلقائياً من سجلات التحضير والتكاليف.",
                                                    fontSize = 10.5.sp,
                                                    color = Color(0xFF166534),
                                                    lineHeight = 15.sp
                                                )
                                            }
                                        }

                                        Button(
                                            onClick = {
                                                if (isLockedForEditing) {
                                                    Toast.makeText(context, "سجلات الدورة مقفلة ومحمية 🔒. اضغط على 'فتح القفل 🔓' أعلى الشاشة للمزامنة.", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    showAutoSyncConfirmDialog = true
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth().height(48.dp),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal)
                                        ) {
                                            Icon(Icons.Default.Sync, contentDescription = null, tint = Color.White)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("مزامنة تلقائية للدرجات مع التحضير والواجبات 🔄", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (courseStudents.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.PeopleOutline, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("لا يوجد طلاب مسجلين في هذه الدورة حالياً.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                                }
                            }
                        }
                    } else {
                        // Quick Search & Filter Chips Bar
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = gradeSearchQuery,
                                        onValueChange = { gradeSearchQuery = it },
                                        placeholder = { Text("بحث سريع عن طالب بالاسم أو رقم الهوية...", fontSize = 12.sp) },
                                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(20.dp)) },
                                        trailingIcon = {
                                            if (gradeSearchQuery.isNotEmpty()) {
                                                IconButton(onClick = { gradeSearchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                                    Icon(Icons.Default.Close, contentDescription = "مسح", modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = DawamiNavy,
                                            unfocusedBorderColor = Color(0xFFCBD5E1)
                                        )
                                    )

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val filterOptions = listOf(
                                            "الكل" to "الكل (${courseStudents.size})",
                                            "مكتمل الرصد" to "مكتمل الرصد",
                                            "غير مكتمل" to "غير مكتمل",
                                            "سجل سابق متوفر" to "سجل سابق متوفر"
                                        )
                                        filterOptions.forEach { (filterKey, label) ->
                                            val isSelected = gradeFilterChip == filterKey
                                            FilterChip(
                                                selected = isSelected,
                                                onClick = { gradeFilterChip = filterKey },
                                                label = { Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = DawamiNavy,
                                                    selectedLabelColor = Color.White
                                                ),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                        }
                                    }

                                    if (filteredCourseStudents.size != courseStudents.size) {
                                        Text(
                                            text = "عرض ${filteredCourseStudents.size} من أصل ${courseStudents.size} طالب",
                                            fontSize = 10.5.sp,
                                            color = DawamiTeal,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }

                                    if (inactiveStudentsCount > 0) {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { showSuspendedAndWithdrawn = !showSuspendedAndWithdrawn },
                                            color = if (showSuspendedAndWithdrawn) Color(0xFFFEF3C7) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, if (showSuspendedAndWithdrawn) Color(0xFFF59E0B) else Color(0xFFCBD5E1))
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Checkbox(
                                                        checked = showSuspendedAndWithdrawn,
                                                        onCheckedChange = { showSuspendedAndWithdrawn = it },
                                                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFFD97706))
                                                    )
                                                    Text(
                                                        text = "إظهار الطلاب المنسحبين والموقوفين ($inactiveStudentsCount)",
                                                        fontSize = 11.5.sp,
                                                        fontWeight = if (showSuspendedAndWithdrawn) FontWeight.Bold else FontWeight.Medium,
                                                        color = if (showSuspendedAndWithdrawn) Color(0xFF92400E) else MaterialTheme.colorScheme.onSurface
                                                    )
                                                }
                                                if (showSuspendedAndWithdrawn) {
                                                    Surface(
                                                        color = Color(0xFFD97706),
                                                        shape = RoundedCornerShape(4.dp)
                                                    ) {
                                                        Text(
                                                            text = "للقراءة فقط 🔒",
                                                            fontSize = 9.sp,
                                                            color = Color.White,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (filteredCourseStudents.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.SearchOff, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(40.dp))
                                        Text("لا توجد نتائج تطابق البحث أو الفلتر المحدد", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        OutlinedButton(
                                            onClick = {
                                                gradeSearchQuery = ""
                                                gradeFilterChip = "الكل"
                                            },
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("إعادة ضبط الفلتر", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        } else {
                            items(filteredCourseStudents, key = { it.id }) { student ->
                                StudentGradeEntryCard(
                                    student = student,
                                    config = currentConfig,
                                    grades = courseGrades.filter { it.studentId == student.id },
                                    viewModel = viewModel,
                                    isLockedForEditing = isLockedForEditing,
                                    onEditGrade = { subject ->
                                        if (isLockedForEditing) {
                                            Toast.makeText(context, "سجلات هذه الدورة منتهية ومحمية 🔒. اضغط على 'فتح القفل 🔓' أعلى الشاشة لتعديل درجات الطلاب.", Toast.LENGTH_LONG).show()
                                        } else {
                                            showGradeDialogForStudent = student
                                            showGradeDialogForSubject = subject
                                        }
                                    },
                                    onShareGrades = {
                                        val studentGrades = courseGrades.filter { it.studentId == student.id }
                                        val configFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson)
                                        val rawSubjects = if (currentConfig.isDiploma) {
                                            currentConfig.getDiplomaSubjects()
                                        } else {
                                            configFields.map { it.first.substringBefore("_") }.distinct()
                                        }
                                        val subjects = StudentGradeConfig.sortSubjectsList(rawSubjects)
                                        val totalSum = studentGrades.sumOf { it.getTotalScore() }.toFloat()
                                        val avg = if (subjects.isNotEmpty()) totalSum / subjects.size else 0f
                                        
                                        val hasWeights = currentConfig.subjectWeightsJson.isNotEmpty()
                                        val configWeightsMap = if (hasWeights) currentConfig.getSubjectWeights() else emptyMap<String, Double>()
                                        val configWeightsSum = configWeightsMap.values.sum()

                                        var weightedTotalScore = 0.0
                                        var totalWeightEvaluated = 0.0

                                        subjects.forEach { subjectName ->
                                            val gradeRecord = studentGrades.find { it.subjectName == subjectName }
                                            if (gradeRecord != null && hasWeights) {
                                                val subjectWeight = configWeightsMap[subjectName] ?: 0.0
                                                weightedTotalScore += (gradeRecord.getTotalScore() * subjectWeight / 100.0)
                                                totalWeightEvaluated += subjectWeight
                                            }
                                        }

                                        val weightedAveragePercentage = if (totalWeightEvaluated > 0.0) {
                                            (weightedTotalScore / totalWeightEvaluated) * 100.0
                                        } else 0.0

                                        pendingShareAction = { reportMode ->
                                            shareMessageText = generateStudentGradeReportText(
                                                studentName = student.name,
                                                courseName = selectedCourseForGrades!!.name,
                                                subjects = subjects,
                                                studentGrades = studentGrades,
                                                totalSum = totalSum,
                                                avg = avg,
                                                weightedTotalScore = weightedTotalScore,
                                                configWeightsSum = configWeightsSum,
                                                weightedAveragePercentage = weightedAveragePercentage,
                                                hasWeights = hasWeights,
                                                instituteName = viewModel.instituteName.value,
                                                isDetailed = reportMode == "DETAILED",
                                                subjectWeights = configWeightsMap,
                                                config = currentConfig,
                                                reportMode = reportMode
                                            )
                                            showWhatsAppChoiceDialog = true
                                        }
                                        showReportTypeDialog = true
                                    }
                                )
                            }
                        }
                    }
                }
            }
            }
            } else if (selectedTabIndex == 1) {
                val scrollState = rememberScrollState()
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp)
                        .verticalScroll(scrollState)
                ) {
                    AssignmentCheckingSection(
                        viewModel = viewModel,
                        isDarkTheme = isDarkTheme,
                        courses = dbCourses,
                        allStudents = dbAllStudents,
                        assignmentTemplates = dbAssignmentTemplates,
                        assignmentSubmissions = dbAssignmentSubmissions
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            } else if (selectedTabIndex == 2) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp)
                ) {
                    TheoryExamGraderScreen(viewModel = viewModel, gradingViewModel = gradingViewModel, showMainLayout = false)
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp)
                ) {
                    GradeReportsScreen(viewModel = viewModel, gradingViewModel = gradingViewModel, showMainLayout = false)
                }
            }
        }
    }

    // --- BULK COMPONENT GRADE DIALOG ---
    if (showBulkComponentDialog && currentConfig != null) {
        val allConfigFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson ?: "")
        val rawSubjects = if (currentConfig.isDiploma) currentConfig.getDiplomaSubjects() else allConfigFields.map { it.first.substringBefore("_") }.distinct()
        val subjects = StudentGradeConfig.sortSubjectsList(rawSubjects)

        val selectedSubjects = remember { mutableStateOf(if (subjects.isNotEmpty()) setOf(subjects.first()) else emptySet<String>()) }
        val availableComponents = listOf(
            "حضور" to "درجات الحضور",
            "مشاركة" to "درجات المشاركة",
            "تكاليف" to "درجات التكاليف والواجبات",
            "مشاريع" to "درجات المشاريع والبحوث",
            "اختبار نظري" to "الاختبار النظري",
            "اختبار عملي" to "الاختبار العملي"
        )
        var selectedComponent by remember { mutableStateOf(availableComponents.first().first) }
        var scoreInput by remember { mutableStateOf("5") }
        var onlyUnassigned by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showBulkComponentDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.FlashOn, contentDescription = null, tint = Color(0xFFD97706))
                    Text("رصد درجة جماعية لمكوّن ⚡", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "اختر المادة والمكوّن والدرجة المراد تطبيقها بضغطة واحدة على جميع طلاب الدورة (${courseStudents.size} طالب):",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Subject selector if multiple
                    if (subjects.size > 1) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("المواد المستهدفة (تحديد متعدد):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                            val allSelected = selectedSubjects.value.size == subjects.size
                            Text(
                                text = if (allSelected) "إلغاء تحديد الكل" else "تحديد الكل",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF2563EB),
                                modifier = Modifier.clickable {
                                    if (allSelected) {
                                        selectedSubjects.value = emptySet()
                                    } else {
                                        selectedSubjects.value = subjects.toSet()
                                    }
                                }
                            )
                        }
                        @OptIn(ExperimentalLayoutApi::class)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            subjects.forEach { s ->
                                val isSelected = selectedSubjects.value.contains(s)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        if (isSelected) {
                                            selectedSubjects.value = selectedSubjects.value - s
                                        } else {
                                            selectedSubjects.value = selectedSubjects.value + s
                                        }
                                    },
                                    label = { Text(s, fontSize = 11.sp) },
                                    leadingIcon = {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }

                    // Component selector
                    Text("المكوّن المراد رصده:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                    @OptIn(ExperimentalLayoutApi::class)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        availableComponents.forEach { (compKey, _) ->
                            FilterChip(
                                selected = selectedComponent == compKey,
                                onClick = { selectedComponent = compKey },
                                label = { Text(compKey, fontSize = 11.sp) }
                            )
                        }
                    }

                    // Score input
                    OutlinedTextField(
                        value = scoreInput,
                        onValueChange = { value ->
                            scoreInput = value.filter { it.isDigit() || it == '.' }
                        },
                        label = { Text("الدرجة المرصودة للمكوّن", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    // Quick buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("5", "10", "15", "20", "30", "40").forEach { qScore ->
                            Surface(
                                color = if (scoreInput == qScore) Color(0xFFD97706) else Color(0xFFF1F5F9),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.weight(1f).clickable { scoreInput = qScore }
                            ) {
                                Text(
                                    text = qScore,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (scoreInput == qScore) Color.White else Color(0xFF334155),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onlyUnassigned = !onlyUnassigned }
                    ) {
                        Checkbox(checked = onlyUnassigned, onCheckedChange = { onlyUnassigned = it })
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تطبيق فقط للطلاب الذين لم تُرصد لهم درجات بعد", fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val subjectsToApply = if (subjects.size > 1) selectedSubjects.value.toList() else listOf(subjects.firstOrNull() ?: "")
                        if (subjectsToApply.isEmpty()) {
                            Toast.makeText(context, "الرجاء تحديد مادة واحدة على الأقل! ⚠️", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val scoreVal = scoreInput.toDoubleOrNull() ?: 0.0
                        viewModel.bulkApplyComponentGrade(
                            courseId = currentConfig.courseId,
                            subjectNames = subjectsToApply,
                            componentName = selectedComponent,
                            score = scoreVal,
                            onlyIfEmpty = onlyUnassigned
                        )
                        Toast.makeText(context, "تم تطبيق درجة $selectedComponent بنجاح على المواد المحددة! ⚡", Toast.LENGTH_SHORT).show()
                        showBulkComponentDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تطبيق جماعي فوري ⚡", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBulkComponentDialog = false }) { Text("إلغاء") }
            }
        )
    }

    // --- BULK FINAL GRADE DIALOG ---
    if (showBulkFinalGradeDialog && currentConfig != null) {
        val allConfigFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson ?: "")
        val rawSubjects = if (currentConfig.isDiploma) currentConfig.getDiplomaSubjects() else allConfigFields.map { it.first.substringBefore("_") }.distinct()
        val subjects = StudentGradeConfig.sortSubjectsList(rawSubjects)

        val selectedSubjectsFinal = remember { mutableStateOf(if (subjects.isNotEmpty()) setOf(subjects.first()) else emptySet<String>()) }
        var finalScoreInput by remember { mutableStateOf("100") }
        var onlyUnassigned by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showBulkFinalGradeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Stars, contentDescription = null, tint = Color(0xFF2563EB))
                    Text("رصد الدرجة النهائية جماعياً 🎯", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "رصد درجة نهائية موحدة لجميع طلاب الدورة (${courseStudents.size} طالب) مع اعتبارها مباشرة وتجاوز شاشات المشاريع والاختبار النظري:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Subject selector if multiple
                    if (subjects.size > 1) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("المواد المستهدفة (تحديد متعدد):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                            val allSelected = selectedSubjectsFinal.value.size == subjects.size
                            Text(
                                text = if (allSelected) "إلغاء تحديد الكل" else "تحديد الكل",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF2563EB),
                                modifier = Modifier.clickable {
                                    if (allSelected) {
                                        selectedSubjectsFinal.value = emptySet()
                                    } else {
                                        selectedSubjectsFinal.value = subjects.toSet()
                                    }
                                }
                            )
                        }
                        @OptIn(ExperimentalLayoutApi::class)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            subjects.forEach { s ->
                                val isSelected = selectedSubjectsFinal.value.contains(s)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        if (isSelected) {
                                            selectedSubjectsFinal.value = selectedSubjectsFinal.value - s
                                        } else {
                                            selectedSubjectsFinal.value = selectedSubjectsFinal.value + s
                                        }
                                    },
                                    label = { Text(s, fontSize = 11.sp) },
                                    leadingIcon = {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }

                    // Calculate max weight for the selected subject based on the course/institute structure configuration
                    val bulkSubjectWeights = currentConfig.getSubjectWeights()
                    val firstSelectedSubject = selectedSubjectsFinal.value.firstOrNull() ?: subjects.firstOrNull() ?: ""
                    val bulkConfiguredWeight = bulkSubjectWeights[firstSelectedSubject]
                        ?: bulkSubjectWeights.entries.find { it.key.trim().equals(firstSelectedSubject.trim(), ignoreCase = true) }?.value
                        ?: if (!currentConfig.isDiploma && currentConfig.customFieldsJson.isNotBlank()) {
                            val fields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson)
                            val matchingFields = fields.filter { it.first.startsWith("${firstSelectedSubject}_") }
                            if (matchingFields.isNotEmpty()) matchingFields.sumOf { it.second }.toDouble()
                            else if (fields.isNotEmpty()) fields.sumOf { it.second }.toDouble()
                            else 100.0
                        } else 100.0
                    val bulkSubjectMaxWeight = if (bulkConfiguredWeight > 0.0) bulkConfiguredWeight else 100.0
                    val bulkMaxWeightFormatted = if (bulkSubjectMaxWeight % 1.0 == 0.0) bulkSubjectMaxWeight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", bulkSubjectMaxWeight)

                    // Score input
                    OutlinedTextField(
                        value = finalScoreInput,
                        onValueChange = { value ->
                            val numeric = value.filter { it.isDigit() || it == '.' }
                            val num = numeric.toDoubleOrNull() ?: 0.0
                            if (num <= bulkSubjectMaxWeight) {
                                finalScoreInput = numeric
                            } else {
                                finalScoreInput = bulkMaxWeightFormatted
                                Toast.makeText(context, "الحد الأقصى للدرجة المعتمدة حسب وزن المادة هو $bulkMaxWeightFormatted", Toast.LENGTH_SHORT).show()
                            }
                        },
                        label = { Text("الدرجة النهائية للمادة (من $bulkMaxWeightFormatted حسب وزن المادة)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onlyUnassigned = !onlyUnassigned }
                    ) {
                        Checkbox(checked = onlyUnassigned, onCheckedChange = { onlyUnassigned = it })
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تطبيق فقط للطلاب الذين لم تُرصد لهم درجات بعد", fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val subjectsToApply = if (subjects.size > 1) selectedSubjectsFinal.value.toList() else listOf(subjects.firstOrNull() ?: "")
                        if (subjectsToApply.isEmpty()) {
                            Toast.makeText(context, "الرجاء تحديد مادة واحدة على الأقل! ⚠️", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val scoreVal = finalScoreInput.toDoubleOrNull() ?: 0.0
                        viewModel.bulkApplyFinalGrade(
                            courseId = currentConfig.courseId,
                            subjectNames = subjectsToApply,
                            finalScore = scoreVal,
                            onlyIfEmpty = onlyUnassigned
                        )
                        Toast.makeText(context, "تم اعتماد ورصد الدرجة النهائية ($scoreVal) للمواد المحددة بنجاح! 🎯", Toast.LENGTH_SHORT).show()
                        showBulkFinalGradeDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("اعتماد ورصد نهائي جماعي ⚡", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBulkFinalGradeDialog = false }) { Text("إلغاء") }
            }
        )
    }

    // --- SMART PREFILL CONFIRMATION DIALOG ---
    if (showSmartPrefillConfirmDialog && currentConfig != null) {
        AlertDialog(
            onDismissRequest = { showSmartPrefillConfirmDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.HelpOutline, contentDescription = null, tint = Color(0xFFD97706))
                    Text("تأكيد التعبئة الذكية للدرجات 📥", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في جلب وتعبئة درجات الطلاب تلقائياً؟\n\nسيقوم النظام بحساب درجات الحضور، المشاركة، التكاليف، والمشاريع لجميع طلاب هذه الدورة من سجلات التحضير والواجبات المعتمدة وتعبئتها للتعديل اليدوي عليها.\n\n⚠️ يرجى ملاحظة أن هذا الإجراء سيستبدل الدرجات غير المحفوظة الحالية.",
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSmartPrefillConfirmDialog = false
                        val allConfigFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson ?: "")
                        val rawSubjects = if (currentConfig.isDiploma) {
                            currentConfig.getDiplomaSubjects()
                        } else {
                            allConfigFields.map { it.first.substringBefore("_") }.distinct()
                        }
                        val subjects = StudentGradeConfig.sortSubjectsList(rawSubjects)
                        val courseSubjectStats = viewModel.getCourseSubjectStats(currentConfig.courseId)

                        courseStudents.forEach { student ->
                            subjects.forEach { subject ->
                                val stat = courseSubjectStats.find { it.subjectName.trim().equals(subject.trim(), ignoreCase = true) }
                                val taughtDaysCount = stat?.taughtDaysCount ?: -1

                                val existingGradeRecord = courseGrades.find { it.studentId == student.id && it.subjectName == subject }
                                val subjectFields = if (currentConfig.isDiploma) {
                                    val specific = allConfigFields.filter { it.first.startsWith("${subject}_") }
                                        .map { Pair(it.first.substringAfter("${subject}_"), it.second) }
                                    if (specific.isNotEmpty()) specific else {
                                        val plain = allConfigFields.filter { !it.first.contains("_") }
                                        if (plain.isNotEmpty()) plain else listOf(
                                            Pair("حضور", 5), Pair("مشاركة", 5), Pair("تكاليف", 10),
                                            Pair("مشاريع", 20), Pair("اختبار نظري", 20), Pair("اختبار عملي", 40)
                                        )
                                    }
                                } else {
                                    allConfigFields.filter { it.first.startsWith("${subject}_") }
                                        .map { Pair(it.first.substringAfter("${subject}_"), it.second) }
                                }

                                val attField = subjectFields.find { it.first.equals("حضور", ignoreCase = true) || it.first.contains("حضور") }
                                val calcAtt = if (attField != null) calculateDynamicAttendanceScore(dbAllStudentAttendance, currentConfig.courseId, subject, student.id, attField.second.toDouble(), subjects, taughtDaysCount).first else 0.0

                                val partField = subjectFields.find { it.first.equals("مشاركة", ignoreCase = true) || it.first.contains("مشاركة") }
                                val calcPart = if (partField != null) calculateDynamicParticipationScore(dbAllStudentAttendance, currentConfig.courseId, subject, student.id, partField.second.toDouble(), subjects, taughtDaysCount).first else 0.0

                                val assField = subjectFields.find { it.first.contains("تكاليف") || it.first.contains("واجبات") || it.first.contains("بحوث") }
                                val calcAss = if (assField != null) calculateDynamicAssignmentScore(dbAssignmentSubmissions, dbAssignmentTemplates, currentConfig.courseId, subject, student.id, assField.second.toDouble(), "تكاليف").first else 0.0

                                val proField = subjectFields.find { it.first.contains("مشاريع") || it.first.contains("مشروع") }
                                val calcProj = if (proField != null) calculateDynamicAssignmentScore(dbAssignmentSubmissions, dbAssignmentTemplates, currentConfig.courseId, subject, student.id, proField.second.toDouble(), "مشاريع").first else 0.0

                                if (currentConfig.isDiploma) {
                                    val gradeObj = StudentGrade(
                                        id = existingGradeRecord?.id ?: 0,
                                        studentId = student.id,
                                        studentName = student.name,
                                        courseId = currentConfig.courseId,
                                        courseName = currentConfig.courseName,
                                        isDiploma = true,
                                        subjectName = subject,
                                        attendanceScore = calcAtt,
                                        participationScore = calcPart,
                                        assignmentsScore = calcAss,
                                        projectsScore = calcProj,
                                        theoreticalExamScore = existingGradeRecord?.theoreticalExamScore ?: 0.0,
                                        practicalExamScore = existingGradeRecord?.practicalExamScore ?: 0.0
                                    ).withManualGrading(true)
                                    viewModel.saveStudentGrade(gradeObj)
                                } else {
                                    val scoresMap = mutableMapOf<String, Double>()
                                    val existingScores = existingGradeRecord?.getScoresMap() ?: emptyMap()
                                    subjectFields.forEach { (fName, _) ->
                                        var sc = existingScores[fName] ?: 0.0
                                        if (attField != null && fName == attField.first) sc = calcAtt
                                        else if (partField != null && fName == partField.first) sc = calcPart
                                        else if (assField != null && fName == assField.first) sc = calcAss
                                        else if (proField != null && fName == proField.first) sc = calcProj
                                        scoresMap[fName] = sc
                                    }
                                    val gradeObj = StudentGrade(
                                        id = existingGradeRecord?.id ?: 0,
                                        studentId = student.id,
                                        studentName = student.name,
                                        courseId = currentConfig.courseId,
                                        courseName = currentConfig.courseName,
                                        isDiploma = false,
                                        subjectName = subject,
                                        customScoresJson = StudentGrade.serializeScores(scoresMap)
                                    ).withManualGrading(true)
                                    viewModel.saveStudentGrade(gradeObj)
                                }
                            }
                        }
                        Toast.makeText(context, "تم جلب وتعبئة درجات الحضور والتكاليف والمشاريع والاختبارات بنجاح للتعديل اليدوي! 📥✍️", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("نعم، تعبئة الآن 📥", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showSmartPrefillConfirmDialog = false }
                ) {
                    Text("إلغاء")
                }
            }
        )
    }

    // --- UNLOCK CONFIRMATION DIALOG FOR COMPLETED COURSES ---
    if (showUnlockConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showUnlockConfirmDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.WarningAmber, contentDescription = null, tint = Color(0xFFD97706))
                    Text("تأكيد فتح قفل التعديل 🔓", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Text(
                    text = "تنبيه: هذه الدورة (${selectedCourseForGrades?.name ?: ""}) مكتملة ومنتهية رسمياً.\n\n" +
                            "السجلات محفوظة حالياً في وضع الحماية والأرشيف لمنع أي تغيير غير مقصود في درجات الطلاب المعتمدة.\n\n" +
                            "هل تريد فتح قفل التعديل لتعديل أو رصد درجات استثنائية (مثل اختبارات تكميلية أو مراجعة ورقة إجابة)؟",
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUnlockConfirmDialog = false
                        isEditUnlockedForEndedCourse = true
                        Toast.makeText(context, "تم فتح قفل التعديل بنجاح 🔓. يمكنك الآن تعديل الدرجات وحفظها.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("نعم، فتح قفل التعديل 🔓", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showUnlockConfirmDialog = false }
                ) {
                    Text("إلغاء")
                }
            }
        )
    }

    // --- AUTO SYNC CONFIRMATION DIALOG ---
    if (showAutoSyncConfirmDialog && currentConfig != null) {
        AlertDialog(
            onDismissRequest = { showAutoSyncConfirmDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.HelpOutline, contentDescription = null, tint = DawamiTeal)
                    Text("تأكيد المزامنة التلقائية للدرجات 🔄", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في مزامنة درجات التحضير والواجبات تلقائياً؟\n\nسيقوم النظام بحساب درجات الحضور والمشاركة والواجبات لجميع طلاب الدورة من سجلات التحضير والتكاليف وتحديث كشف الدرجات تلقائياً.\n\n⚠️ يرجى ملاحظة أن هذا التحديث سيسري على الطلاب الذين لم يتم رصد درجاتهم يدوياً فقط.",
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showAutoSyncConfirmDialog = false
                        val allConfigFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson ?: "")
                        val rawSubjects = if (currentConfig.isDiploma) {
                            currentConfig.getDiplomaSubjects()
                        } else {
                            allConfigFields.map { it.first.substringBefore("_") }.distinct()
                        }
                        val subjects = StudentGradeConfig.sortSubjectsList(rawSubjects)
                        val courseSubjectStats = viewModel.getCourseSubjectStats(currentConfig.courseId)

                        var syncedCount = 0
                        courseStudents.forEach { student ->
                            subjects.forEach { subject ->
                                val stat = courseSubjectStats.find { it.subjectName.trim().equals(subject.trim(), ignoreCase = true) }
                                val taughtDaysCount = stat?.taughtDaysCount ?: -1

                                val existingGradeRecord = courseGrades.find { it.studentId == student.id && it.subjectName == subject }
                                if (existingGradeRecord?.isManualGrading() == true || existingGradeRecord?.isManualFinalGrading() == true) {
                                    return@forEach
                                }
                                val subjectFields = if (currentConfig.isDiploma) {
                                    val specific = allConfigFields.filter { it.first.startsWith("${subject}_") }
                                        .map { Pair(it.first.substringAfter("${subject}_"), it.second) }
                                    if (specific.isNotEmpty()) {
                                        specific
                                    } else {
                                        val plain = allConfigFields.filter { !it.first.contains("_") }
                                        if (plain.isNotEmpty()) {
                                            plain
                                        } else {
                                            listOf(
                                                Pair("حضور", 5),
                                                Pair("مشاركة", 5),
                                                Pair("تكاليف", 10),
                                                Pair("مشاريع", 20),
                                                Pair("اختبار نظري", 20),
                                                Pair("اختبار عملي", 40)
                                            )
                                        }
                                    }
                                } else {
                                    allConfigFields.filter { it.first.startsWith("${subject}_") }
                                        .map { Pair(it.first.substringAfter("${subject}_"), it.second) }
                                }

                                val attendanceField = subjectFields.find { it.first.equals("حضور", ignoreCase = true) || it.first.contains("حضور") }
                                val calculatedAtt = if (attendanceField != null) {
                                    calculateDynamicAttendanceScore(dbAllStudentAttendance, currentConfig.courseId, subject, student.id, attendanceField.second.toDouble(), subjects, taughtDaysCount).first
                                } else 0.0

                                val participationField = subjectFields.find { it.first.equals("مشاركة", ignoreCase = true) || it.first.contains("مشاركة") }
                                val calculatedPart = if (participationField != null) {
                                    calculateDynamicParticipationScore(dbAllStudentAttendance, currentConfig.courseId, subject, student.id, participationField.second.toDouble(), subjects, taughtDaysCount).first
                                } else 0.0

                                val assignmentField = subjectFields.find {
                                    it.first.contains("تكاليف", ignoreCase = true) ||
                                    it.first.contains("واجبات", ignoreCase = true) ||
                                    it.first.contains("بحوث", ignoreCase = true)
                                }
                                val calculatedAss = if (assignmentField != null) {
                                    calculateDynamicAssignmentScore(dbAssignmentSubmissions, dbAssignmentTemplates, currentConfig.courseId, subject, student.id, assignmentField.second.toDouble(), "تكاليف").first
                                } else 0.0

                                val projectField = subjectFields.find {
                                    it.first.contains("مشاريع", ignoreCase = true) ||
                                    it.first.contains("مشروع", ignoreCase = true)
                                }
                                val calculatedProj = if (projectField != null) {
                                    calculateDynamicAssignmentScore(dbAssignmentSubmissions, dbAssignmentTemplates, currentConfig.courseId, subject, student.id, projectField.second.toDouble(), "مشاريع").first
                                } else 0.0

                                val isSubjectManual = viewModel.isManualAssignmentGrading(currentConfig.courseId, subject)
                                val finalAss = if (isSubjectManual) (existingGradeRecord?.assignmentsScore ?: 0.0) else calculatedAss
                                val finalProj = if (isSubjectManual) (existingGradeRecord?.projectsScore ?: 0.0) else calculatedProj

                                if (currentConfig.isDiploma) {
                                    val existingExamScores = (existingGradeRecord?.theoreticalExamScore ?: 0.0) +
                                            (existingGradeRecord?.practicalExamScore ?: 0.0)
                                    val totalScore = calculatedAtt + calculatedPart + finalAss + finalProj + existingExamScores

                                    val hasExistingScores = existingGradeRecord != null && (
                                        existingGradeRecord.theoreticalExamScore > 0.0 ||
                                        existingGradeRecord.practicalExamScore > 0.0 ||
                                        existingGradeRecord.assignmentsScore > 0.0 ||
                                        existingGradeRecord.projectsScore > 0.0 ||
                                        existingGradeRecord.attendanceScore > 0.0 ||
                                        existingGradeRecord.participationScore > 0.0
                                    )
                                    if (totalScore > 0.0 || hasExistingScores) {
                                        val gradeObj = StudentGrade(
                                            id = existingGradeRecord?.id ?: 0,
                                            studentId = student.id,
                                            studentName = student.name,
                                            courseId = currentConfig.courseId,
                                            courseName = currentConfig.courseName,
                                            isDiploma = true,
                                            subjectName = subject,
                                            attendanceScore = if (calculatedAtt > 0.0) calculatedAtt else (existingGradeRecord?.attendanceScore ?: 0.0),
                                            participationScore = if (calculatedPart > 0.0) calculatedPart else (existingGradeRecord?.participationScore ?: 0.0),
                                            assignmentsScore = if (finalAss > 0.0) finalAss else (existingGradeRecord?.assignmentsScore ?: 0.0),
                                            projectsScore = if (finalProj > 0.0) finalProj else (existingGradeRecord?.projectsScore ?: 0.0),
                                            theoreticalExamScore = existingGradeRecord?.theoreticalExamScore ?: 0.0,
                                            practicalExamScore = existingGradeRecord?.practicalExamScore ?: 0.0
                                        )
                                        viewModel.saveStudentGrade(gradeObj)
                                        syncedCount++
                                    }
                                } else {
                                    val scoresMap = mutableMapOf<String, Double>()
                                    val existingScores = existingGradeRecord?.getScoresMap() ?: emptyMap()
                                    subjectFields.forEach { (fieldName, _) ->
                                        var score = existingScores[fieldName] ?: 0.0
                                        if (attendanceField != null && fieldName == attendanceField.first) {
                                            score = if (calculatedAtt > 0.0) calculatedAtt else (existingScores[fieldName] ?: 0.0)
                                        } else if (participationField != null && fieldName == participationField.first) {
                                            score = if (calculatedPart > 0.0) calculatedPart else (existingScores[fieldName] ?: 0.0)
                                        } else if (assignmentField != null && fieldName == assignmentField.first) {
                                            score = if (isSubjectManual) (existingScores[fieldName] ?: 0.0) else if (calculatedAss > 0.0) calculatedAss else (existingScores[fieldName] ?: 0.0)
                                        } else if (projectField != null && fieldName == projectField.first) {
                                            score = if (isSubjectManual) (existingScores[fieldName] ?: 0.0) else if (calculatedProj > 0.0) calculatedProj else (existingScores[fieldName] ?: 0.0)
                                        }
                                        scoresMap[fieldName] = score
                                    }
                                    val totalScore = scoresMap.values.sum()
                                    val hasExistingCustom = existingGradeRecord != null && existingScores.values.any { it > 0.0 }
                                    if (totalScore > 0.0 || hasExistingCustom) {
                                        val gradeObj = StudentGrade(
                                            id = existingGradeRecord?.id ?: 0,
                                            studentId = student.id,
                                            studentName = student.name,
                                            courseId = currentConfig.courseId,
                                            courseName = currentConfig.courseName,
                                            isDiploma = false,
                                            subjectName = subject,
                                            customScoresJson = StudentGrade.serializeScores(scoresMap)
                                        )
                                        viewModel.saveStudentGrade(gradeObj)
                                        syncedCount++
                                    }
                                }
                            }
                        }
                        Toast.makeText(context, "تم مزامنة درجات التحضير والمشاركة والتكاليف لجميع الطلاب تلقائياً بنجاح! 🚀🔄", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("نعم، مزامنة الآن 🔄", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showAutoSyncConfirmDialog = false }
                ) {
                    Text("إلغاء")
                }
            }
        )
    }

    // --- GRADE ENTRY DIALOG ---
    if (showGradeDialogForStudent != null && showGradeDialogForSubject != null) {
        val student = showGradeDialogForStudent!!
        val subject = showGradeDialogForSubject!!
        val stat = if (currentConfig != null) viewModel.getCourseSubjectStats(currentConfig!!.courseId).find { it.subjectName.trim().equals(subject.trim(), ignoreCase = true) } else null
        val taughtDaysCount = stat?.taughtDaysCount ?: -1

        val existingGradeRecord = courseGrades.find { it.studentId == student.id && it.subjectName == subject }
        val pastGradeRecord = if (existingGradeRecord == null && currentConfig != null) {
            viewModel.dbAllGrades.value.filter {
                it.studentId == student.id && it.subjectName.trim().equals(subject.trim(), ignoreCase = true) && it.courseId != currentConfig!!.courseId
            }.maxByOrNull { it.id }
        } else null
        
        val allConfigFields = StudentGradeConfig.deserializeFields(currentConfig?.customFieldsJson ?: "")
        val rawDialogSubjects = if (currentConfig?.isDiploma == true) {
            currentConfig!!.getDiplomaSubjects()
        } else {
            allConfigFields.map { it.first.substringBefore("_") }.distinct()
        }
        val dialogSubjects = StudentGradeConfig.sortSubjectsList(rawDialogSubjects)

         val subjectFields = if (currentConfig?.isDiploma == true) {
            val specific = allConfigFields.filter { it.first.startsWith("${subject}_") }
                .map { Pair(it.first.substringAfter("${subject}_"), it.second) }
            val plain = allConfigFields.filter { !it.first.contains("_") }
            if (specific.isNotEmpty() && specific.sumOf { it.second } == 100) {
                specific
            } else if (plain.isNotEmpty()) {
                plain
            } else {
                listOf(
                    Pair("حضور", 5),
                    Pair("مشاركة", 5),
                    Pair("تكاليف", 10),
                    Pair("مشاريع", 20),
                    Pair("اختبار نظري", 20),
                    Pair("اختبار عملي", 40)
                )
            }
        } else {
            val specific = allConfigFields.filter { it.first.startsWith("${subject}_") }
                .map { Pair(it.first.substringAfter("${subject}_"), it.second) }
            val plain = allConfigFields.filter { !it.first.contains("_") }
            if (specific.isNotEmpty() && specific.sumOf { it.second } == 100) specific else if (plain.isNotEmpty()) plain else allConfigFields
        }

        val attendanceField = subjectFields.find { it.first.equals("حضور", ignoreCase = true) || it.first.contains("حضور") }
        val calculatedAttResult = if (attendanceField != null) {
            calculateDynamicAttendanceScore(
                allAttendance = dbAllStudentAttendance,
                courseId = currentConfig!!.courseId,
                subjectName = subject,
                studentId = student.id,
                maxAttendanceScore = attendanceField.second.toDouble(),
                allCourseSubjects = dialogSubjects,
                taughtDaysCount = taughtDaysCount
            )
        } else null

        val participationField = subjectFields.find { it.first.equals("مشاركة", ignoreCase = true) || it.first.contains("مشاركة") }
        val calculatedPartResult = if (participationField != null) {
            calculateDynamicParticipationScore(
                allAttendance = dbAllStudentAttendance,
                courseId = currentConfig!!.courseId,
                subjectName = subject,
                studentId = student.id,
                maxParticipationScore = participationField.second.toDouble(),
                allCourseSubjects = dialogSubjects,
                taughtDaysCount = taughtDaysCount
            )
        } else null

        val assignmentField = subjectFields.find {
            it.first.contains("تكاليف", ignoreCase = true) ||
            it.first.contains("واجبات", ignoreCase = true) ||
            it.first.contains("بحوث", ignoreCase = true)
        }
        val calculatedAssignmentResult = if (assignmentField != null) {
            calculateDynamicAssignmentScore(
                allSubmissions = dbAssignmentSubmissions,
                allTemplates = dbAssignmentTemplates,
                courseId = currentConfig!!.courseId,
                subjectName = subject,
                studentId = student.id,
                maxAssignmentScore = assignmentField.second.toDouble(),
                categoryFilter = "تكاليف"
            )
        } else null

        val projectField = subjectFields.find {
            it.first.contains("مشاريع", ignoreCase = true) ||
            it.first.contains("مشروع", ignoreCase = true)
        }
        val calculatedProjectResult = if (projectField != null) {
            calculateDynamicAssignmentScore(
                allSubmissions = dbAssignmentSubmissions,
                allTemplates = dbAssignmentTemplates,
                courseId = currentConfig!!.courseId,
                subjectName = subject,
                studentId = student.id,
                maxAssignmentScore = projectField.second.toDouble(),
                categoryFilter = "مشاريع"
            )
        } else null

        val theoreticalExamField = subjectFields.find {
            it.first.contains("نظري", ignoreCase = true) || (it.first.contains("اختبار", ignoreCase = true) && !it.first.contains("عملي", ignoreCase = true))
        }
        val practicalExamField = subjectFields.find {
            it.first.contains("عملي", ignoreCase = true)
        }

        val existingTheoryScore = when {
            existingGradeRecord != null && existingGradeRecord.theoreticalExamScore > 0.0 -> existingGradeRecord.theoreticalExamScore
            existingGradeRecord != null && !existingGradeRecord.isDiploma -> existingGradeRecord.getScoresMap().entries.find { it.key.contains("نظري") || (it.key.contains("اختبار") && !it.key.contains("عملي")) }?.value ?: 0.0
            pastGradeRecord != null -> pastGradeRecord.theoreticalExamScore
            else -> 0.0
        }

        val existingPracticalScore = when {
            existingGradeRecord != null && existingGradeRecord.practicalExamScore > 0.0 -> existingGradeRecord.practicalExamScore
            existingGradeRecord != null && !existingGradeRecord.isDiploma -> existingGradeRecord.getScoresMap().entries.find { it.key.contains("عملي") }?.value ?: 0.0
            pastGradeRecord != null -> pastGradeRecord.practicalExamScore
            else -> 0.0
        }

        val calculatedTotalPreviousScore = if (existingGradeRecord != null && existingGradeRecord.isManualFinalGrading()) {
            existingGradeRecord.getTotalScore()
        } else {
            var sum = 0.0
            val existingScores = existingGradeRecord?.getScoresMap() ?: emptyMap()
            subjectFields.forEach { (fieldName, _) ->
                val score = when {
                    existingScores.containsKey(fieldName) && (existingScores[fieldName] ?: 0.0) > 0.0 -> existingScores[fieldName] ?: 0.0
                    attendanceField != null && fieldName == attendanceField.first -> calculatedAttResult?.first ?: 0.0
                    participationField != null && fieldName == participationField.first -> calculatedPartResult?.first ?: 0.0
                    assignmentField != null && fieldName == assignmentField.first -> calculatedAssignmentResult?.first ?: 0.0
                    projectField != null && fieldName == projectField.first -> calculatedProjectResult?.first ?: 0.0
                    theoreticalExamField != null && fieldName == theoreticalExamField.first -> existingTheoryScore
                    practicalExamField != null && fieldName == practicalExamField.first -> existingPracticalScore
                    else -> existingScores[fieldName] ?: 0.0
                }
                sum += score
            }
            if (sum > 0.0) sum else (existingGradeRecord?.getTotalScore() ?: 0.0)
        }

        val courseGradingMode = courseGradingModes[currentConfig!!.courseId] ?: viewModel.getCourseGradingMode(currentConfig!!.courseId)
        var selectedDialogGradingMode by remember(student.id, subject, existingGradeRecord, pastGradeRecord, courseGradingMode) {
            val initial = if (existingGradeRecord?.isManualFinalGrading() == true) {
                "MANUAL_FINAL"
            } else if (existingGradeRecord?.isManualGrading() == true || pastGradeRecord != null) {
                "MANUAL_BREAKDOWN"
            } else if (courseGradingMode == "MANUAL_FINAL") {
                "MANUAL_FINAL"
            } else if (courseGradingMode == "MANUAL_BREAKDOWN") {
                "MANUAL_BREAKDOWN"
            } else {
                "AUTO"
            }
            mutableStateOf(initial)
        }

        val subjectWeights = currentConfig?.getSubjectWeights() ?: emptyMap()
        val configuredWeight = subjectWeights[subject]
            ?: subjectWeights.entries.find { it.key.trim().equals(subject.trim(), ignoreCase = true) }?.value
            ?: if (currentConfig != null && !currentConfig.isDiploma && currentConfig.customFieldsJson.isNotBlank()) {
                val fields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson)
                val matchingFields = fields.filter { it.first.startsWith("${subject}_") }
                if (matchingFields.isNotEmpty()) matchingFields.sumOf { it.second }.toDouble()
                else if (fields.isNotEmpty()) fields.sumOf { it.second }.toDouble()
                else 100.0
            } else 100.0
        val subjectMaxWeight = if (configuredWeight > 0.0) configuredWeight else 100.0
        val maxWeightFormatted = if (subjectMaxWeight % 1.0 == 0.0) subjectMaxWeight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", subjectMaxWeight)

        var manualFinalScore100Input by remember(student.id, subject, existingGradeRecord, courseGradingMode) {
            val initial = if (existingGradeRecord != null && existingGradeRecord.isManualFinalGrading()) {
                val s = existingGradeRecord.getTotalScore()
                if (s % 1.0 == 0.0) s.toInt().toString() else s.toString()
            } else if (calculatedTotalPreviousScore > 0.0) {
                if (calculatedTotalPreviousScore % 1.0 == 0.0) calculatedTotalPreviousScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", calculatedTotalPreviousScore)
            } else if (existingGradeRecord != null && existingGradeRecord.getTotalScore() > 0) {
                val s = existingGradeRecord.getTotalScore()
                if (s % 1.0 == 0.0) s.toInt().toString() else s.toString()
            } else {
                ""
            }
            mutableStateOf(initial)
        }

        var manualFinalScoreWeightedInput by remember(student.id, subject, existingGradeRecord, courseGradingMode) {
            val initialScore100 = if (existingGradeRecord != null && existingGradeRecord.isManualFinalGrading()) {
                existingGradeRecord.getTotalScore()
            } else if (calculatedTotalPreviousScore > 0.0) {
                calculatedTotalPreviousScore
            } else if (existingGradeRecord != null && existingGradeRecord.getTotalScore() > 0) {
                existingGradeRecord.getTotalScore()
            } else {
                null
            }
            val str = if (initialScore100 != null) {
                val w = (initialScore100 * subjectMaxWeight) / 100.0
                if (w % 1.0 == 0.0) w.toInt().toString() else String.format(java.util.Locale.US, "%.1f", w)
            } else {
                ""
            }
            mutableStateOf(str)
        }

        val isManualMode = selectedDialogGradingMode == "MANUAL_BREAKDOWN"
        val isManualFinalMode = selectedDialogGradingMode == "MANUAL_FINAL"
        val isAutoMode = selectedDialogGradingMode == "AUTO"

        var linkAttendanceToGrades by remember(student.id, subject, selectedDialogGradingMode, pastGradeRecord) {
            val initialLink = isAutoMode && pastGradeRecord == null && (existingGradeRecord == null || (attendanceField != null && calculatedAttResult != null && 
                existingGradeRecord.getScoresMap()[attendanceField.first]?.toInt() == calculatedAttResult.first.toInt()))
            mutableStateOf(initialLink)
        }

        var linkParticipationToGrades by remember(student.id, subject, selectedDialogGradingMode, pastGradeRecord) {
            val initialLink = isAutoMode && pastGradeRecord == null && (existingGradeRecord == null || (participationField != null && calculatedPartResult != null &&
                existingGradeRecord.getScoresMap()[participationField.first]?.toInt() == calculatedPartResult.first.toInt()))
            mutableStateOf(initialLink)
        }

        var linkAssignmentsToGrades by remember(student.id, subject, selectedDialogGradingMode, pastGradeRecord) {
            val initialLink = isAutoMode && pastGradeRecord == null && (existingGradeRecord == null || (assignmentField != null && calculatedAssignmentResult != null &&
                existingGradeRecord.getScoresMap()[assignmentField.first]?.toInt() == calculatedAssignmentResult.first.toInt()))
            mutableStateOf(initialLink)
        }

        val parsedScores = remember(student.id, subject, existingGradeRecord, pastGradeRecord) {
            if (existingGradeRecord != null && !existingGradeRecord.isManualFinalGrading()) {
                existingGradeRecord.getScoresMap()
            } else if (pastGradeRecord != null) {
                pastGradeRecord.getScoresMap()
            } else {
                emptyMap()
            }
        }

        val inputsMap = remember(student.id, subject, existingGradeRecord, pastGradeRecord) {
            val initial = mutableStateMapOf<String, String>()
            subjectFields.forEach { (fieldName, _) ->
                val existingVal = parsedScores[fieldName]
                val scoreStr = if (existingVal != null) {
                    if (existingVal % 1.0 == 0.0) existingVal.toInt().toString() else existingVal.toString()
                } else {
                    when {
                        attendanceField != null && fieldName == attendanceField.first && calculatedAttResult != null -> {
                            calculatedAttResult.first.toInt().toString()
                        }
                        participationField != null && fieldName == participationField.first && calculatedPartResult != null -> {
                            calculatedPartResult.first.toInt().toString()
                        }
                        assignmentField != null && fieldName == assignmentField.first && calculatedAssignmentResult != null -> {
                            calculatedAssignmentResult.first.toInt().toString()
                        }
                        projectField != null && fieldName == projectField.first && calculatedProjectResult != null -> {
                            calculatedProjectResult.first.toInt().toString()
                        }
                        theoreticalExamField != null && fieldName == theoreticalExamField.first && existingTheoryScore > 0.0 -> {
                            existingTheoryScore.toInt().toString()
                        }
                        practicalExamField != null && fieldName == practicalExamField.first && existingPracticalScore > 0.0 -> {
                            existingPracticalScore.toInt().toString()
                        }
                        else -> ""
                    }
                }
                initial[fieldName] = scoreStr
            }
            initial
        }

        var gradeNoteInput by remember(student.id, subject, existingGradeRecord) {
            mutableStateOf(existingGradeRecord?.getGradeNote() ?: "")
        }

        // Apply dynamic attendance if linked
        if (attendanceField != null) {
            if (isAutoMode && linkAttendanceToGrades && calculatedAttResult != null) {
                inputsMap[attendanceField.first] = calculatedAttResult.first.toInt().toString()
            } else if (!linkAttendanceToGrades) {
                val existingVal = parsedScores[attendanceField.first]
                if (existingVal != null) {
                    inputsMap[attendanceField.first] = if (existingVal % 1.0 == 0.0) existingVal.toInt().toString() else existingVal.toString()
                }
            }
        }

        // Apply dynamic participation if linked
        if (participationField != null) {
            if (isAutoMode && linkParticipationToGrades && calculatedPartResult != null) {
                inputsMap[participationField.first] = calculatedPartResult.first.toInt().toString()
            } else if (!linkParticipationToGrades) {
                val existingVal = parsedScores[participationField.first]
                if (existingVal != null) {
                    inputsMap[participationField.first] = if (existingVal % 1.0 == 0.0) existingVal.toInt().toString() else existingVal.toString()
                }
            }
        }

        // Apply dynamic assignment if linked
        if (assignmentField != null) {
            if (isAutoMode && linkAssignmentsToGrades && calculatedAssignmentResult != null) {
                inputsMap[assignmentField.first] = calculatedAssignmentResult.first.toInt().toString()
            } else if (!linkAssignmentsToGrades) {
                val existingVal = parsedScores[assignmentField.first]
                if (existingVal != null) {
                    inputsMap[assignmentField.first] = if (existingVal % 1.0 == 0.0) existingVal.toInt().toString() else existingVal.toString()
                }
            }
        }

        // Apply dynamic project if linked
        if (projectField != null) {
            if (isAutoMode && linkAssignmentsToGrades && calculatedProjectResult != null) {
                inputsMap[projectField.first] = calculatedProjectResult.first.toInt().toString()
            } else if (!linkAssignmentsToGrades) {
                val existingVal = parsedScores[projectField.first]
                if (existingVal != null) {
                    inputsMap[projectField.first] = if (existingVal % 1.0 == 0.0) existingVal.toInt().toString() else existingVal.toString()
                }
            }
        }

        // Apply exam scores in auto mode if empty or 0
        if (isAutoMode && theoreticalExamField != null && existingTheoryScore > 0.0 && (inputsMap[theoreticalExamField.first].isNullOrBlank() || inputsMap[theoreticalExamField.first] == "0")) {
            inputsMap[theoreticalExamField.first] = existingTheoryScore.toInt().toString()
        }
        if (isAutoMode && practicalExamField != null && existingPracticalScore > 0.0 && (inputsMap[practicalExamField.first].isNullOrBlank() || inputsMap[practicalExamField.first] == "0")) {
            inputsMap[practicalExamField.first] = existingPracticalScore.toInt().toString()
        }

        val buildFinalGradeObject: () -> StudentGrade = {
            if (isManualFinalMode) {
                val scoreVal = manualFinalScore100Input.toDoubleOrNull() ?: (((manualFinalScoreWeightedInput.toDoubleOrNull() ?: 0.0) / subjectMaxWeight) * 100.0)
                val base = existingGradeRecord ?: StudentGrade(
                    id = 0,
                    studentId = student.id,
                    studentName = student.name,
                    courseId = currentConfig!!.courseId,
                    courseName = currentConfig.courseName,
                    isDiploma = currentConfig.isDiploma,
                    subjectName = subject
                )
                val att = inputsMap["حضور"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("حضور") }?.value?.toDoubleOrNull() ?: base.attendanceScore)
                val part = inputsMap["مشاركة"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("مشاركة") }?.value?.toDoubleOrNull() ?: base.participationScore)
                val ass = inputsMap["تكاليف"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("تكاليف") || it.key.contains("واجبات") || it.key.contains("بحوث") }?.value?.toDoubleOrNull() ?: base.assignmentsScore)
                val proj = inputsMap["مشاريع"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("مشاريع") || it.key.contains("مشروع") }?.value?.toDoubleOrNull() ?: base.projectsScore)
                val theo = inputsMap["اختبار نظري"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("نظري") || (it.key.contains("اختبار") && !it.key.contains("عملي")) }?.value?.toDoubleOrNull() ?: (base.theoreticalExamScore.takeIf { it > 0.0 } ?: existingTheoryScore))
                val prac = inputsMap["اختبار عملي"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("عملي") }?.value?.toDoubleOrNull() ?: (base.practicalExamScore.takeIf { it > 0.0 } ?: existingPracticalScore))

                val rawGrade = base.copy(
                    attendanceScore = att,
                    participationScore = part,
                    assignmentsScore = ass,
                    projectsScore = proj,
                    theoreticalExamScore = theo,
                    practicalExamScore = prac
                ).withManualFinalGrading(scoreVal)
                
                rawGrade.copy(customScoresJson = StudentGrade.withNote(rawGrade.customScoresJson, gradeNoteInput.trim()))
            } else {
                val baseGradeObj = if (currentConfig!!.isDiploma) {
                    StudentGrade(
                        id = existingGradeRecord?.id ?: 0,
                        studentId = student.id,
                        studentName = student.name,
                        courseId = currentConfig.courseId,
                        courseName = currentConfig.courseName,
                        isDiploma = true,
                        subjectName = subject,
                        attendanceScore = inputsMap["حضور"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("حضور") }?.value?.toDoubleOrNull() ?: (existingGradeRecord?.attendanceScore ?: 0.0)),
                        participationScore = inputsMap["مشاركة"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("مشاركة") }?.value?.toDoubleOrNull() ?: (existingGradeRecord?.participationScore ?: 0.0)),
                        assignmentsScore = inputsMap["تكاليف"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("تكاليف") || it.key.contains("واجبات") || it.key.contains("بحوث") }?.value?.toDoubleOrNull() ?: (existingGradeRecord?.assignmentsScore ?: 0.0)),
                        projectsScore = inputsMap["مشاريع"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("مشاريع") || it.key.contains("مشروع") }?.value?.toDoubleOrNull() ?: (existingGradeRecord?.projectsScore ?: 0.0)),
                        theoreticalExamScore = inputsMap["اختبار نظري"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("نظري") || (it.key.contains("اختبار") && !it.key.contains("عملي")) }?.value?.toDoubleOrNull() ?: (existingGradeRecord?.theoreticalExamScore ?: 0.0)),
                        practicalExamScore = inputsMap["اختبار عملي"]?.toDoubleOrNull() ?: (inputsMap.entries.find { it.key.contains("عملي") }?.value?.toDoubleOrNull() ?: (existingGradeRecord?.practicalExamScore ?: 0.0))
                    )
                } else {
                    val scoresMap = subjectFields.associate { (fieldName, _) ->
                        fieldName to (inputsMap[fieldName]?.toDoubleOrNull() ?: 0.0)
                    }
                    StudentGrade(
                        id = existingGradeRecord?.id ?: 0,
                        studentId = student.id,
                        studentName = student.name,
                        courseId = currentConfig.courseId,
                        courseName = currentConfig.courseName,
                        isDiploma = false,
                        subjectName = subject,
                        customScoresJson = StudentGrade.serializeScores(scoresMap)
                    )
                }
                val withNoteGrade = baseGradeObj.copy(customScoresJson = StudentGrade.withNote(baseGradeObj.customScoresJson, gradeNoteInput.trim()))
                withNoteGrade.withManualGrading(isManualMode)
            }
        }

        val onSaveAndNext: () -> Unit = {
            val finalGradeObj = buildFinalGradeObject()
            viewModel.saveStudentGrade(finalGradeObj)

            val activeStudentList = if (filteredCourseStudents.isNotEmpty()) filteredCourseStudents else courseStudents
            val currentStudentIndex = activeStudentList.indexOfFirst { it.id == student.id }
            if (currentStudentIndex != -1 && currentStudentIndex < activeStudentList.size - 1) {
                Toast.makeText(context, "تم الحفظ والانتقال للطالب التالي! ⬅️", Toast.LENGTH_SHORT).show()
                showGradeDialogForStudent = activeStudentList[currentStudentIndex + 1]
            } else {
                Toast.makeText(context, "تم حفظ درجات آخر طالب بالدورة! ✨", Toast.LENGTH_SHORT).show()
                showGradeDialogForStudent = null
                showGradeDialogForSubject = null
            }
        }

        val onSaveOnly: () -> Unit = {
            val finalGradeObj = buildFinalGradeObject()
            viewModel.saveStudentGrade(finalGradeObj)
            Toast.makeText(context, "تم حفظ الدرجة بنجاح! ✨", Toast.LENGTH_SHORT).show()
            showGradeDialogForStudent = null
            showGradeDialogForSubject = null
        }

        Dialog(
            onDismissRequest = {
                showGradeDialogForStudent = null
                showGradeDialogForSubject = null
            },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color(0xFFF1F5F9))
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    val activeStudentList = if (filteredCourseStudents.isNotEmpty()) filteredCourseStudents else courseStudents
                    val currentStudentIndex = activeStudentList.indexOfFirst { it.id == student.id }
                    val totalStudentCount = activeStudentList.size

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Surface(
                                color = DawamiNavy.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (currentStudentIndex != -1) "طالب ${currentStudentIndex + 1} من $totalStudentCount" else "",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiNavy,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Text(
                                text = subject,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiTeal
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = {
                                    if (currentStudentIndex > 0) {
                                        showGradeDialogForStudent = activeStudentList[currentStudentIndex - 1]
                                    }
                                },
                                enabled = currentStudentIndex > 0,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "السابق", modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = {
                                    if (currentStudentIndex != -1 && currentStudentIndex < totalStudentCount - 1) {
                                        showGradeDialogForStudent = activeStudentList[currentStudentIndex + 1]
                                    }
                                },
                                enabled = currentStudentIndex != -1 && currentStudentIndex < totalStudentCount - 1,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "التالي", modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    Text(
                        text = "للطالب: ${student.name}" + if (student.phoneNumber.isNotBlank()) " (${student.phoneNumber})" else "",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        softWrap = true
                    )

                    // Unified Grading Mode Control Selector (Auto vs Manual Breakdown vs Manual Final)
                    Surface(
                        color = when (selectedDialogGradingMode) {
                            "MANUAL_FINAL" -> Color(0xFFEFF6FF)
                            "MANUAL_BREAKDOWN" -> Color(0xFFFFFBEB)
                            else -> Color(0xFFF0FDF4)
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, when (selectedDialogGradingMode) {
                            "MANUAL_FINAL" -> Color(0xFF93C5FD)
                            "MANUAL_BREAKDOWN" -> Color(0xFFFCD34D)
                            else -> Color(0xFF86EFAC)
                        }),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "⚙️ نمط رصد درجات المادة:",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (selectedDialogGradingMode) {
                                        "MANUAL_FINAL" -> Color(0xFF1E40AF)
                                        "MANUAL_BREAKDOWN" -> Color(0xFF92400E)
                                        else -> Color(0xFF166534)
                                    }
                                )
                                Row(
                                    modifier = Modifier
                                        .background(Color.White, RoundedCornerShape(8.dp))
                                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                                        .padding(2.dp),
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isAutoMode) DawamiTeal else Color.Transparent)
                                            .clickable {
                                                selectedDialogGradingMode = "AUTO"
                                                linkAttendanceToGrades = true
                                                linkParticipationToGrades = true
                                                linkAssignmentsToGrades = true
                                                if (attendanceField != null && calculatedAttResult != null) {
                                                    inputsMap[attendanceField.first] = calculatedAttResult.first.toInt().toString()
                                                }
                                                if (participationField != null && calculatedPartResult != null) {
                                                    inputsMap[participationField.first] = calculatedPartResult.first.toInt().toString()
                                                }
                                                if (assignmentField != null && calculatedAssignmentResult != null) {
                                                    inputsMap[assignmentField.first] = calculatedAssignmentResult.first.toInt().toString()
                                                }
                                                if (projectField != null && calculatedProjectResult != null) {
                                                    inputsMap[projectField.first] = calculatedProjectResult.first.toInt().toString()
                                                }
                                                if (theoreticalExamField != null && existingTheoryScore > 0.0) {
                                                    inputsMap[theoreticalExamField.first] = existingTheoryScore.toInt().toString()
                                                }
                                                if (practicalExamField != null && existingPracticalScore > 0.0) {
                                                    inputsMap[practicalExamField.first] = existingPracticalScore.toInt().toString()
                                                }
                                            }
                                            .padding(horizontal = 7.dp, vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "🤖 آلي",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isAutoMode) Color.White else Color(0xFF64748B)
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isManualMode) Color(0xFFD97706) else Color.Transparent)
                                            .clickable {
                                                selectedDialogGradingMode = "MANUAL_BREAKDOWN"
                                                linkAttendanceToGrades = false
                                                linkParticipationToGrades = false
                                                linkAssignmentsToGrades = false
                                                // Ensure any empty fields get populated with current values so teacher can edit them
                                                subjectFields.forEach { (fieldName, _) ->
                                                    if (inputsMap[fieldName].isNullOrBlank()) {
                                                        when {
                                                            attendanceField != null && fieldName == attendanceField.first && calculatedAttResult != null -> {
                                                                inputsMap[fieldName] = calculatedAttResult.first.toInt().toString()
                                                            }
                                                            participationField != null && fieldName == participationField.first && calculatedPartResult != null -> {
                                                                inputsMap[fieldName] = calculatedPartResult.first.toInt().toString()
                                                            }
                                                            assignmentField != null && fieldName == assignmentField.first && calculatedAssignmentResult != null -> {
                                                                inputsMap[fieldName] = calculatedAssignmentResult.first.toInt().toString()
                                                            }
                                                            projectField != null && fieldName == projectField.first && calculatedProjectResult != null -> {
                                                                inputsMap[fieldName] = calculatedProjectResult.first.toInt().toString()
                                                            }
                                                            theoreticalExamField != null && fieldName == theoreticalExamField.first && existingTheoryScore > 0.0 -> {
                                                                inputsMap[fieldName] = existingTheoryScore.toInt().toString()
                                                            }
                                                            practicalExamField != null && fieldName == practicalExamField.first && existingPracticalScore > 0.0 -> {
                                                                inputsMap[fieldName] = existingPracticalScore.toInt().toString()
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            .padding(horizontal = 7.dp, vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "✍️ تفصيلي",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isManualMode) Color.White else Color(0xFF64748B)
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isManualFinalMode) Color(0xFF2563EB) else Color.Transparent)
                                            .clickable {
                                                selectedDialogGradingMode = "MANUAL_FINAL"
                                                linkAttendanceToGrades = false
                                                linkParticipationToGrades = false
                                                linkAssignmentsToGrades = false
                                                val currentFieldsTotal = subjectFields.sumOf { (name, _) -> inputsMap[name]?.toDoubleOrNull() ?: 0.0 }
                                                val targetTotal = if (currentFieldsTotal > 0.0) currentFieldsTotal else calculatedTotalPreviousScore
                                                if (targetTotal > 0.0 && (manualFinalScore100Input.isBlank() || manualFinalScore100Input == "0")) {
                                                    manualFinalScore100Input = if (targetTotal % 1.0 == 0.0) targetTotal.toInt().toString() else String.format(java.util.Locale.US, "%.1f", targetTotal)
                                                    val w = (targetTotal * subjectMaxWeight) / 100.0
                                                    manualFinalScoreWeightedInput = if (w % 1.0 == 0.0) w.toInt().toString() else String.format(java.util.Locale.US, "%.1f", w)
                                                }
                                            }
                                            .padding(horizontal = 7.dp, vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "🎯 نهائي",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isManualFinalMode) Color.White else Color(0xFF64748B)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = when (selectedDialogGradingMode) {
                                    "MANUAL_FINAL" -> "🎯 يدوي نهائي نشط: رصد الدرجة الكلية للمادة مباشرة دون الحاجة لشاشات المشاريع أو الاختبار النظري."
                                    "MANUAL_BREAKDOWN" -> "✍️ يدوي تفصيلي نشط: إدخال درجات المكوّنات يدوياً وتثبيتها دون استبدالها تلقائياً."
                                    else -> "🤖 رصد آلي نشط: جلب تلقائي لدرجات الحضور والمشاركة والتكاليف من سجلات التحضير والمهام."
                                },
                                fontSize = 9.5.sp,
                                color = when (selectedDialogGradingMode) {
                                    "MANUAL_FINAL" -> Color(0xFF1D4ED8)
                                    "MANUAL_BREAKDOWN" -> Color(0xFFB45309)
                                    else -> Color(0xFF15803D)
                                },
                                lineHeight = 13.sp
                            )
                        }
                    }

                    HorizontalDivider(color = Color(0xFFF1F5F9))

                    if (isManualFinalMode) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                            border = BorderStroke(1.dp, Color(0xFFBFDBFE))
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Stars, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(20.dp))
                                    Text(
                                        text = "الرصد النهائي المعتمد (تحويل تلقائي متزامن ⇄):",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.5.sp,
                                        color = Color(0xFF1E3A8A)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // حقل الدرجة حسب الوزن
                                    OutlinedTextField(
                                        value = manualFinalScoreWeightedInput,
                                        onValueChange = { value ->
                                            val numeric = value.filter { it.isDigit() || it == '.' }
                                            if (numeric.isEmpty()) {
                                                manualFinalScoreWeightedInput = ""
                                                manualFinalScore100Input = ""
                                            } else {
                                                val num = numeric.toDoubleOrNull() ?: 0.0
                                                if (num <= subjectMaxWeight) {
                                                    manualFinalScoreWeightedInput = numeric
                                                    val conv100 = (num / subjectMaxWeight) * 100.0
                                                    manualFinalScore100Input = if (conv100 % 1.0 == 0.0) conv100.toInt().toString() else String.format(java.util.Locale.US, "%.1f", conv100)
                                                } else {
                                                    manualFinalScoreWeightedInput = maxWeightFormatted
                                                    manualFinalScore100Input = "100"
                                                    Toast.makeText(context, "الحد الأقصى حسب الوزن هو $maxWeightFormatted", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        label = { Text("الدرجة من $maxWeightFormatted (الوزن)", fontSize = 10.5.sp) },
                                        placeholder = { Text("من $maxWeightFormatted", fontSize = 10.5.sp) },
                                        modifier = Modifier.weight(1f),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                        keyboardActions = KeyboardActions(onDone = { onSaveAndNext() }),
                                        shape = RoundedCornerShape(10.dp),
                                        singleLine = true,
                                        textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                                    )

                                    // أيقونة التزامن
                                    Surface(
                                        color = Color(0xFFDBEAFE),
                                        shape = CircleShape,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.CompareArrows,
                                                contentDescription = "تحويل متزامن",
                                                tint = Color(0xFF2563EB),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }

                                    // حقل الدرجة من 100
                                    OutlinedTextField(
                                        value = manualFinalScore100Input,
                                        onValueChange = { value ->
                                            val numeric = value.filter { it.isDigit() || it == '.' }
                                            if (numeric.isEmpty()) {
                                                manualFinalScore100Input = ""
                                                manualFinalScoreWeightedInput = ""
                                            } else {
                                                val num = numeric.toDoubleOrNull() ?: 0.0
                                                if (num <= 100.0) {
                                                    manualFinalScore100Input = numeric
                                                    val convWeight = (num / 100.0) * subjectMaxWeight
                                                    manualFinalScoreWeightedInput = if (convWeight % 1.0 == 0.0) convWeight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", convWeight)
                                                } else {
                                                    manualFinalScore100Input = "100"
                                                    manualFinalScoreWeightedInput = maxWeightFormatted
                                                    Toast.makeText(context, "الحد الأقصى للدرجة المعيارية هو 100", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        label = { Text("الدرجة من 100 (المعيارية)", fontSize = 10.5.sp) },
                                        placeholder = { Text("من 100", fontSize = 10.5.sp) },
                                        modifier = Modifier.weight(1f),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                        keyboardActions = KeyboardActions(onDone = { onSaveAndNext() }),
                                        shape = RoundedCornerShape(10.dp),
                                        singleLine = true,
                                        textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                                    )
                                }

                                 val passingPercentage = currentConfig?.getPassingPercentage() ?: 75.0
                                val passingThreshold = (passingPercentage / 100.0) * subjectMaxWeight
                                val passThreshFormatted = if (passingThreshold % 1.0 == 0.0) passingThreshold.toInt().toString() else String.format(java.util.Locale.US, "%.2f", passingThreshold)
                                val passPercentageFormatted = if (passingPercentage % 1.0 == 0.0) passingPercentage.toInt().toString() else String.format(java.util.Locale.US, "%.1f", passingPercentage)

                                val entered100Score = manualFinalScore100Input.toDoubleOrNull()
                                val isEnteredPass = entered100Score != null && entered100Score >= passingPercentage
                                val hasEnteredScore = manualFinalScore100Input.isNotBlank()

                                Surface(
                                    color = if (hasEnteredScore && !isEnteredPass) Color(0xFFFEF2F2) else Color(0xFFF0FDF4),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (hasEnteredScore && !isEnteredPass) Color(0xFFFECACA) else Color(0xFFBBF7D0)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "🎯 حد النجاح في المادة ($passPercentageFormatted%):",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (hasEnteredScore && !isEnteredPass) Color(0xFF991B1B) else Color(0xFF166534)
                                            )
                                            Text(
                                                text = "الدرجة المطلوبة للنجاح: $passThreshFormatted من $maxWeightFormatted ($passPercentageFormatted من 100)",
                                                fontSize = 9.5.sp,
                                                color = if (hasEnteredScore && !isEnteredPass) Color(0xFFB91C1C) else Color(0xFF15803D)
                                            )
                                        }
                                        if (hasEnteredScore) {
                                            Surface(
                                                color = if (isEnteredPass) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = if (isEnteredPass) "✅ ناجح" else "⚠️ راسب",
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isEnteredPass) Color(0xFF15803D) else Color(0xFFDC2626)
                                                )
                                            }
                                        }
                                    }
                                }

                                Text(
                                    text = "💡 اكتب الدرجة في أي حقل (حسب وزن المادة من $maxWeightFormatted أو المعيارية من 100) وسيتم احتساب الحقل الآخر وعكسه في بطاقة المادة وتقارير الطالب تلقائياً.",
                                    fontSize = 9.5.sp,
                                    color = Color(0xFF1E40AF),
                                    lineHeight = 13.sp
                                )
                            }
                        }
                    } else {
                        // Dynamic Attendance UI banner (when in auto mode)
                        if (isAutoMode && attendanceField != null && calculatedAttResult != null) {
                        Surface(
                            color = DawamiTeal.copy(alpha = 0.05f),
                            border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "🔄 ربط تلقائي لدرجات الحضور بالتحضير:",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = DawamiTeal
                                    )
                                    Switch(
                                        checked = linkAttendanceToGrades,
                                        onCheckedChange = { 
                                            linkAttendanceToGrades = it
                                            if (it) {
                                                inputsMap[attendanceField.first] = calculatedAttResult.first.toInt().toString()
                                            }
                                        },
                                        modifier = Modifier.scale(0.8f)
                                    )
                                }
                                Text(
                                    text = calculatedAttResult.second,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    // Dynamic Participation UI banner (when in auto mode)
                    if (!isManualMode && participationField != null && calculatedPartResult != null) {
                        Surface(
                            color = DawamiGold.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "⭐ ربط تلقائي لدرجات المشاركة بالنجوم اليومية:",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color(0xFFD97706)
                                    )
                                    Switch(
                                        checked = linkParticipationToGrades,
                                        onCheckedChange = { 
                                            linkParticipationToGrades = it
                                            if (it) {
                                                inputsMap[participationField.first] = calculatedPartResult.first.toInt().toString()
                                            }
                                        },
                                        modifier = Modifier.scale(0.8f)
                                    )
                                }
                                Text(
                                    text = calculatedPartResult.second,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    // Dynamic Assignment / Research UI banner (when in auto mode)
                    if (!isManualMode && assignmentField != null && calculatedAssignmentResult != null) {
                        Surface(
                            color = Color(0xFF3B82F6).copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, Color(0xFF3B82F6).copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "📝 ربط تلقائي لدرجات البحوث/الواجبات بتشييك المهام:",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color(0xFF2563EB)
                                    )
                                    Switch(
                                        checked = linkAssignmentsToGrades,
                                        onCheckedChange = { 
                                            linkAssignmentsToGrades = it
                                            if (it) {
                                                inputsMap[assignmentField.first] = calculatedAssignmentResult.first.toInt().toString()
                                            }
                                        },
                                        modifier = Modifier.scale(0.8f)
                                    )
                                }
                                Text(
                                    text = calculatedAssignmentResult.second,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    subjectFields.chunked(2).forEach { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            pair.forEach { (fieldName, maxScore) ->
                                val currentVal = inputsMap[fieldName] ?: ""
                                val isAttendanceAndLinked = !isManualMode && linkAttendanceToGrades && attendanceField != null && fieldName == attendanceField.first
                                val isParticipationAndLinked = !isManualMode && linkParticipationToGrades && participationField != null && fieldName == participationField.first
                                val isAssignmentAndLinked = !isManualMode && linkAssignmentsToGrades && assignmentField != null && fieldName == assignmentField.first
                                val isProjectAndLinked = !isManualMode && linkAssignmentsToGrades && projectField != null && fieldName == projectField.first
                                val isLinkedField = isAttendanceAndLinked || isParticipationAndLinked || isAssignmentAndLinked || isProjectAndLinked
                                
                                OutlinedTextField(
                                    value = currentVal,
                                    onValueChange = { value ->
                                        if (isLinkedField) return@OutlinedTextField
                                        val numeric = value.filter { it.isDigit() || it == '.' }
                                        if (numeric.isEmpty()) {
                                            inputsMap[fieldName] = ""
                                        } else {
                                            val num = numeric.toDoubleOrNull() ?: 0.0
                                            if (num <= maxScore) {
                                                inputsMap[fieldName] = numeric
                                            } else {
                                                inputsMap[fieldName] = maxScore.toString()
                                                Toast.makeText(context, "الحد الأقصى للدرجة هو $maxScore", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    readOnly = isLinkedField,
                                    label = { Text("$fieldName (من $maxScore)", fontSize = 11.sp) },
                                    modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                    keyboardActions = KeyboardActions(onDone = { onSaveAndNext() }),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true,
                                    textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                                )
                            }
                            if (pair.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { onSaveAndNext() },
                            modifier = Modifier.weight(1.3f).height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal)
                        ) {
                            Text("حفظ وتالي ⚡", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = Color.White, maxLines = 1)
                        }

                        Button(
                            onClick = { onSaveOnly() },
                            modifier = Modifier.weight(1.1f).height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                        ) {
                            Text("حفظ سريع 💾", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, maxLines = 1)
                        }

                        OutlinedButton(
                            onClick = {
                                showGradeDialogForStudent = null
                                showGradeDialogForSubject = null
                            },
                            modifier = Modifier.weight(0.8f).height(46.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("إلغاء", fontSize = 11.5.sp, maxLines = 1)
                        }
                    }

                    HorizontalDivider(color = Color(0xFFF1F5F9))

                    val totalLiveScore = if (isManualFinalMode) {
                        manualFinalScore100Input.toDoubleOrNull() ?: (((manualFinalScoreWeightedInput.toDoubleOrNull() ?: 0.0) / subjectMaxWeight) * 100.0)
                    } else {
                        subjectFields.sumOf { (name, _) ->
                            inputsMap[name]?.toDoubleOrNull() ?: 0.0
                        }
                    }

                    // Note input field for student in this subject
                    OutlinedTextField(
                        value = gradeNoteInput,
                        onValueChange = { gradeNoteInput = it },
                        label = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.EditNote, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(16.dp))
                                Text("ملاحظة الطالب في هذه المادة (تظهر في التقرير النهائي)", fontSize = 11.sp)
                            }
                        },
                        placeholder = { Text("مثال: متميز في التطبيق العملي / يحتاج لمتابعة", fontSize = 10.5.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        maxLines = 2,
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                    )

                    Surface(
                        color = if (isManualFinalMode) Color(0xFFEFF6FF) else DawamiNavy.copy(alpha = 0.05f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (isManualFinalMode) "الدرجة النهائية المعتمدة للمادة:" else "المجموع الكلي للمادة:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (isManualFinalMode) Color(0xFF1D4ED8) else DawamiNavy
                            )
                            if (isManualFinalMode) {
                                val liveWeighted = (totalLiveScore * subjectMaxWeight) / 100.0
                                val formWeighted = if (liveWeighted % 1.0 == 0.0) liveWeighted.toInt().toString() else String.format(java.util.Locale.US, "%.1f", liveWeighted)
                                val form100 = if (totalLiveScore % 1.0 == 0.0) totalLiveScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", totalLiveScore)
                                Text(
                                    "$formWeighted من $maxWeightFormatted ($form100 من 100) 🎯",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp,
                                    color = Color(0xFF1D4ED8)
                                )
                            } else {
                                Text(
                                    "${if (totalLiveScore % 1.0 == 0.0) totalLiveScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", totalLiveScore)} من 100",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = DawamiNavy
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showWhatsAppChoiceDialog) {
        WhatsAppChoiceDialog(
            onDismiss = { showWhatsAppChoiceDialog = false },
            shareMessageText = shareMessageText,
            context = context
        )
    }

    val isCourseManualFinal = currentModeForCourse == "MANUAL_FINAL"

    if (showReportTypeDialog && pendingShareAction != null) {
        ReportTypeSelectionDialog(
            onDismiss = {
                showReportTypeDialog = false
                pendingShareAction = null
            },
            onSelectType = { reportMode ->
                showReportTypeDialog = false
                pendingShareAction?.invoke(reportMode)
                pendingShareAction = null
            },
            isManualFinal = isCourseManualFinal
        )
    }

    if (showImportExportExcelDialog && selectedCourseForGrades != null) {
        val activeSubject = courseSubjects.firstOrNull() ?: "المقرر العام"
        GradesImportExportDialog(
            course = selectedCourseForGrades!!,
            allCourseStudents = courseStudents,
            config = currentConfig,
            existingGrades = courseGrades,
            currentSelectedSubject = activeSubject,
            viewModel = viewModel,
            gradingViewModel = gradingViewModel,
            onDismiss = { showImportExportExcelDialog = false }
        )
    }
}

@Composable
fun StudentGradeEntryCard(
    student: Student,
    config: StudentGradeConfig,
    grades: List<StudentGrade>,
    viewModel: MainViewModel? = null,
    isLockedForEditing: Boolean = false,
    onEditGrade: (String) -> Unit,
    onShareGrades: () -> Unit
) {
    val context = LocalContext.current
    var isExpanded by remember(student.id) { mutableStateOf(false) }

    val configFields = StudentGradeConfig.deserializeFields(config.customFieldsJson)
    val rawSubjectsList = if (config.isDiploma) {
        config.getDiplomaSubjects()
    } else {
        configFields.map { it.first.substringBefore("_") }.distinct()
    }
    val subjectsList = StudentGradeConfig.sortSubjectsList(rawSubjectsList)

    val weights = config.getSubjectWeights()
    val hasWeights = weights.isNotEmpty()
    val defaultWeight = if (subjectsList.isNotEmpty()) 100.0 / subjectsList.size else 0.0

    // فحص إن كان الطالب لديه درجات أو حضور سابق في دورة أخرى لمواد مشتركة في دورته الحالية
    val pastGradesForStudent = remember(student.id, student.courseId, viewModel?.dbAllGrades?.value) {
        viewModel?.dbAllGrades?.value?.filter {
            it.studentId == student.id && it.courseId != student.courseId && it.getTotalScore() > 0
        } ?: emptyList()
    }

    // المواد المشتركة التي تتوفر لها درجات في دورات سابقة
    val subjectsWithPastGrades = remember(subjectsList, pastGradesForStudent) {
        subjectsList.filter { subj ->
            pastGradesForStudent.any { it.subjectName.trim().equals(subj.trim(), ignoreCase = true) }
        }
    }

    // 1. مواد غير مرصودة في الدورة الحالية ولكن لها درجات سابقة (جاهزة للجلب المباشر)
    val unrecordedSubjectsWithPastGrades = remember(subjectsWithPastGrades, grades) {
        subjectsWithPastGrades.filter { subj ->
            val curGrade = grades.find { it.subjectName.trim().equals(subj.trim(), ignoreCase = true) }
            curGrade == null || curGrade.getTotalScore() <= 0.0
        }
    }

    // 2. مواد مرصودة بالفعل في الدورة الحالية ولها درجات سابقة أيضاً (يوجد تعارض في الرصد)
    val conflictingSubjectsWithPastGrades = remember(subjectsWithPastGrades, grades) {
        subjectsWithPastGrades.filter { subj ->
            val curGrade = grades.find { it.subjectName.trim().equals(subj.trim(), ignoreCase = true) }
            curGrade != null && curGrade.getTotalScore() > 0.0
        }
    }

    // Compute weighted score & average GPA
    val configWeightsSum = subjectsList.sumOf { weights[it] ?: defaultWeight }
    val activeGrades = grades.filter { it.getTotalScore() > 0.0 }
    var weightedTotalScore = 0.0
    var gradedWeightsSum = 0.0
    var gradedCount = 0
    subjectsList.forEach { sub ->
        val gr = activeGrades.find { it.subjectName == sub }
        val w = weights[sub] ?: defaultWeight
        if (gr != null) {
            gradedCount++
            weightedTotalScore += (gr.getTotalScore() / 100.0) * w
            gradedWeightsSum += w
        }
    }

    val weightedAveragePercentage = if (gradedWeightsSum > 0.0) (weightedTotalScore / gradedWeightsSum) * 100.0 else 0.0
    val scoredTotalSum = activeGrades.sumOf { it.getTotalScore() }.toFloat()
    val scoredAvg = if (activeGrades.isNotEmpty()) scoredTotalSum / activeGrades.size else 0f

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = DawamiNavy.copy(alpha = 0.1f),
                        shape = CircleShape,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.weight(1f, fill = false)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = student.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 2,
                                softWrap = true
                            )
                            if (student.status == "منسحب" || student.status == "توقيف قيد" || student.status == "موقوف" || student.status == "موقف") {
                                Surface(
                                    color = Color(0xFFDC2626).copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = student.status,
                                        fontSize = 9.sp,
                                        color = Color(0xFFDC2626),
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (student.phoneNumber.isNotBlank()) {
                                Text(
                                    text = student.phoneNumber,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text("•", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                text = "المواد: ${activeGrades.size} من ${subjectsList.size}",
                                fontSize = 10.sp,
                                color = if (activeGrades.size == subjectsList.size && subjectsList.isNotEmpty()) Color(0xFF10B981) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (subjectsWithPastGrades.isNotEmpty()) {
                            Surface(
                                color = Color(0xFF0284C7).copy(alpha = 0.12f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "سجل سابق متوفر (${subjectsWithPastGrades.size}) 🔄",
                                    fontSize = 9.sp,
                                    color = Color(0xFF0284C7),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        val passingPercentage = config.getPassingPercentage()
                        val isAllSubjectsGraded = activeGrades.size >= subjectsList.size && subjectsList.isNotEmpty()
                        val effectiveAverage = if (hasWeights && gradedWeightsSum > 0.0) weightedAveragePercentage else scoredAvg.toDouble()
                        val isStudentPassing = effectiveAverage >= passingPercentage

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (activeGrades.isNotEmpty()) {
                                if (isAllSubjectsGraded) {
                                    Surface(
                                        color = if (isStudentPassing) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (isStudentPassing) "ناجح ✅" else "راسب ⚠️",
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                            fontSize = 8.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isStudentPassing) Color(0xFF15803D) else Color(0xFFDC2626)
                                        )
                                    }
                                } else {
                                    Surface(
                                        color = Color(0xFFFEF3C7), // Warm Amber
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "قيد الرصد ⏳",
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                            fontSize = 8.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFB45309)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = if (hasWeights) {
                                    if (isAllSubjectsGraded) {
                                        "المعدل الموزون: ${String.format(Locale.US, "%.1f", weightedAveragePercentage)}%"
                                    } else {
                                        "المعدل الحالي: ${String.format(Locale.US, "%.1f", weightedAveragePercentage)}%"
                                    }
                                } else {
                                    if (isAllSubjectsGraded) {
                                        "المعدل: ${String.format(Locale.US, "%.1f", scoredAvg)}%"
                                    } else {
                                        "المعدل الحالي: ${String.format(Locale.US, "%.1f", scoredAvg)}%"
                                    }
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = DawamiNavy
                            )
                        }
                        Text(
                            text = if (hasWeights) {
                                if (isAllSubjectsGraded) {
                                    if (configWeightsSum == 100.0) {
                                        "مجموع الدرجات الموزون: ${String.format(Locale.US, "%.1f", weightedTotalScore)} من 100"
                                    } else {
                                        "مجموع الدرجات الموزون: ${String.format(Locale.US, "%.1f", weightedTotalScore)} من ${configWeightsSum.toInt()}"
                                    }
                                } else {
                                    if (configWeightsSum == 100.0) {
                                        "المكتسب: ${String.format(Locale.US, "%.1f", weightedTotalScore)}% من 100%"
                                    } else {
                                        "المكتسب: ${String.format(Locale.US, "%.1f", weightedTotalScore)} من ${configWeightsSum.toInt()}"
                                    }
                                }
                            } else {
                                if (isAllSubjectsGraded) {
                                    "مجموع الدرجات: ${scoredTotalSum.toInt()}"
                                } else {
                                    "المكتسب: ${scoredTotalSum.toInt()} من ${subjectsList.size * 100}"
                                }
                            },
                            fontSize = 10.sp,
                            color = DawamiTeal
                        )
                    }

                    IconButton(
                        onClick = { onShareGrades() },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Surface(
                            color = Color(0xFF25D366), // WhatsApp Green
                            shape = CircleShape,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "مشاركة النتيجة عبر الواتساب",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = Color.Gray
                    )
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF8FAFC))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "كشف درجات المواد مع الأوزان النسبية للرصد والتعديل:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    subjectsList.forEach { subjectName ->
                        val gradeRecord = grades.find { it.subjectName == subjectName }
                        val pastGradeRecord = if (gradeRecord == null) {
                            pastGradesForStudent.filter { it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true) }.maxByOrNull { it.id }
                        } else null
                        val weight = weights[subjectName] ?: defaultWeight
                        val passingPercentage = config.getPassingPercentage()
                        val passingScoreForSubject = (passingPercentage / 100.0) * (if (hasWeights && weight > 0) weight else 100.0)
                        val effectiveScore100 = gradeRecord?.getTotalScore() ?: pastGradeRecord?.getTotalScore()
                        val isSubjectPassed = effectiveScore100 != null && effectiveScore100 >= passingPercentage
                        
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(end = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = subjectName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (pastGradeRecord != null && gradeRecord == null) Color.Gray else Color(0xFF1E293B)
                                    )
                                    @OptIn(ExperimentalLayoutApi::class)
                                    FlowRow(
                                        verticalArrangement = Arrangement.Center,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Surface(
                                            color = DawamiNavy.copy(alpha = 0.08f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            val formattedWeight = if (weight % 1.0 == 0.0) weight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weight)
                                            Text(
                                                text = "وزن: $formattedWeight%",
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = DawamiNavy,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }

                                        val passThreshStr = if (passingScoreForSubject % 1.0 == 0.0) passingScoreForSubject.toInt().toString() else String.format(java.util.Locale.US, "%.1f", passingScoreForSubject)

                                        Surface(
                                            color = Color(0xFFF0FDF4),
                                            shape = RoundedCornerShape(4.dp),
                                            border = BorderStroke(0.5.dp, Color(0xFFBBF7D0))
                                        ) {
                                            Text(
                                                text = "حد النجاح: $passThreshStr",
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = Color(0xFF15803D),
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }

                                        if (gradeRecord != null) {
                                            Surface(
                                                color = if (isSubjectPassed) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = if (isSubjectPassed) "ناجح ✅" else "راسب ⚠️",
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isSubjectPassed) Color(0xFF15803D) else Color(0xFFDC2626),
                                                    maxLines = 1,
                                                    softWrap = false
                                                )
                                            }

                                            if (gradeRecord.isManualFinalGrading()) {
                                                Surface(
                                                    color = Color(0xFFEFF6FF),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "🎯 يدوي نهائي",
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF1D4ED8),
                                                        maxLines = 1,
                                                        softWrap = false
                                                    )
                                                }
                                            } else if (gradeRecord.isManualGrading()) {
                                                Surface(
                                                    color = Color(0xFFFEF3C7),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "✍️ يدوي",
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFFB45309),
                                                        maxLines = 1,
                                                        softWrap = false
                                                    )
                                                }
                                            } else {
                                                Surface(
                                                    color = Color(0xFFECFDF5),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "🤖 آلي",
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF047857),
                                                        maxLines = 1,
                                                        softWrap = false
                                                    )
                                                }
                                            }
                                        } else if (pastGradeRecord != null) {
                                            Surface(
                                                color = Color(0xFFF1F5F9),
                                                shape = RoundedCornerShape(4.dp),
                                                border = BorderStroke(0.5.dp, Color(0xFFCBD5E1))
                                            ) {
                                                Text(
                                                    text = "👻 شبحية (غير معتمدة)",
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF64748B),
                                                    maxLines = 1,
                                                    softWrap = false
                                                )
                                            }
                                        }
                                    }
                                    
                                    if (gradeRecord != null) {
                                        if (gradeRecord.isManualFinalGrading()) {
                                            val total100 = gradeRecord.getTotalScore()
                                            val formatted100 = if (total100 % 1.0 == 0.0) total100.toInt().toString() else String.format(java.util.Locale.US, "%.1f", total100)
                                            if (hasWeights && weight > 0) {
                                                val weightedScore = (total100 * weight) / 100.0
                                                val formattedWeighted = if (weightedScore % 1.0 == 0.0) weightedScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weightedScore)
                                                val formattedMax = if (weight % 1.0 == 0.0) weight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weight)
                                                Text(
                                                    text = "رصد نهائي: $formattedWeighted من $formattedMax ($formatted100 من 100) 🎯",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = Color(0xFF1D4ED8)
                                                )
                                            } else {
                                                Text(
                                                    text = "درجة نهائية مباشرة معتمدة: $formatted100 من 100 🎯",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = Color(0xFF1D4ED8)
                                                )
                                            }
                                        } else {
                                            val scoresMap = gradeRecord.getScoresMap()
                                            @OptIn(ExperimentalLayoutApi::class)
                                            FlowRow(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                val entries = scoresMap.entries.toList()
                                                entries.forEachIndexed { index, entry ->
                                                    Text(
                                                        text = "${entry.key}: ${entry.value.toInt()}",
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        softWrap = false,
                                                        maxLines = 1
                                                    )
                                                    if (index < entries.size - 1) {
                                                        Text(
                                                            text = " |",
                                                            fontSize = 10.sp,
                                                            color = Color.LightGray,
                                                            softWrap = false,
                                                            maxLines = 1
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        val subNote = gradeRecord.getGradeNote()
                                        if (subNote.isNotBlank()) {
                                            Surface(
                                                color = Color(0xFFFEF3C7),
                                                shape = RoundedCornerShape(4.dp),
                                                border = BorderStroke(0.5.dp, Color(0xFFF59E0B).copy(alpha = 0.5f))
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(start = 6.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Icon(Icons.Default.EditNote, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(13.dp))
                                                    Text(
                                                        text = "ملاحظة: $subNote",
                                                        fontSize = 9.sp,
                                                        color = Color(0xFF92400E),
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                    Box(
                                                        modifier = Modifier
                                                            .padding(start = 2.dp)
                                                            .size(15.dp)
                                                            .background(Color(0xFFEF4444).copy(alpha = 0.18f), shape = CircleShape)
                                                            .clickable {
                                                                if (isLockedForEditing) {
                                                                    Toast.makeText(context, "سجلات هذه الدورة منتهية ومحمية 🔒. اضغط على 'فتح القفل 🔓' للتعديل.", Toast.LENGTH_SHORT).show()
                                                                } else {
                                                                    val updatedCustomJson = StudentGrade.withNote(gradeRecord.customScoresJson, "")
                                                                    val updatedGrade = gradeRecord.copy(customScoresJson = updatedCustomJson)
                                                                    viewModel?.saveStudentGrade(updatedGrade)
                                                                    Toast.makeText(context, "تم حذف الملاحظة 🗑️", Toast.LENGTH_SHORT).show()
                                                                }
                                                            },
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Close,
                                                            contentDescription = "حذف الملاحظة",
                                                            tint = Color(0xFFDC2626),
                                                            modifier = Modifier.size(9.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    } else if (pastGradeRecord != null) {
                                        val scoresMap = pastGradeRecord.getScoresMap()
                                        @OptIn(ExperimentalLayoutApi::class)
                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            val entries = scoresMap.entries.toList()
                                            entries.forEachIndexed { index, entry ->
                                                Text(
                                                    text = "${entry.key}: ${entry.value.toInt()}",
                                                    fontSize = 10.sp,
                                                    color = Color(0xFF94A3B8),
                                                    softWrap = false,
                                                    maxLines = 1
                                                )
                                                if (index < entries.size - 1) {
                                                    Text(
                                                        text = " |",
                                                        fontSize = 10.sp,
                                                        color = Color.LightGray.copy(alpha = 0.5f),
                                                        softWrap = false,
                                                        maxLines = 1
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = "تم جلبها كدرجة شبحية من الدورة السابقة (${pastGradeRecord.courseName}). لحفظها واعتمادها في هذه الدورة، اضغط أيقونة الرصد ثم احفظ.",
                                            fontSize = 8.5.sp,
                                            color = Color(0xFF64748B),
                                            lineHeight = 12.sp
                                        )
                                    } else {
                                        Text(
                                            text = "غير مرصود بعد ⚠️",
                                            fontSize = 10.sp,
                                            color = DawamiGold,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = if (gradeRecord != null) {
                                            if (isSubjectPassed) Color(0xFF10B981).copy(alpha = 0.1f)
                                            else Color(0xFFEF4444).copy(alpha = 0.1f)
                                        } else if (pastGradeRecord != null) {
                                            if (isSubjectPassed) Color(0xFF10B981).copy(alpha = 0.05f)
                                            else Color(0xFFEF4444).copy(alpha = 0.05f)
                                        } else {
                                            Color.LightGray.copy(alpha = 0.2f)
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        border = if (pastGradeRecord != null && gradeRecord == null) {
                                            BorderStroke(1.dp, if (isSubjectPassed) Color(0xFF10B981).copy(alpha = 0.3f) else Color(0xFFEF4444).copy(alpha = 0.3f))
                                        } else null
                                    ) {
                                        Text(
                                            text = if (gradeRecord != null) {
                                                val score100 = gradeRecord.getTotalScore()
                                                val formatted100 = if (score100 % 1.0 == 0.0) score100.toInt().toString() else String.format(java.util.Locale.US, "%.1f", score100)
                                                if (hasWeights && weight > 0) {
                                                    val weightedScore = (score100 * weight) / 100.0
                                                    val formattedWeighted = if (weightedScore % 1.0 == 0.0) weightedScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weightedScore)
                                                    val formattedMax = if (weight % 1.0 == 0.0) weight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weight)
                                                    "\u202A$formatted100 / 100\u202C\n\u202A$formattedWeighted / $formattedMax\u202C"
                                                } else {
                                                    "\u202A$formatted100 / 100\u202C"
                                                }
                                            } else if (pastGradeRecord != null) {
                                                val score100 = pastGradeRecord.getTotalScore()
                                                val formatted100 = if (score100 % 1.0 == 0.0) score100.toInt().toString() else String.format(java.util.Locale.US, "%.1f", score100)
                                                if (hasWeights && weight > 0) {
                                                    val weightedScore = (score100 * weight) / 100.0
                                                    val formattedWeighted = if (weightedScore % 1.0 == 0.0) weightedScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weightedScore)
                                                    val formattedMax = if (weight % 1.0 == 0.0) weight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weight)
                                                    "\u202A$formatted100 / 100\u202C\n\u202A$formattedWeighted / $formattedMax\u202C"
                                                } else {
                                                    "\u202A$formatted100 / 100\u202C"
                                                }
                                            } else "- / 100",
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            textAlign = TextAlign.Center,
                                            color = if (gradeRecord != null) {
                                                if (isSubjectPassed) Color(0xFF10B981)
                                                else Color(0xFFDC2626)
                                            } else if (pastGradeRecord != null) {
                                                if (isSubjectPassed) Color(0xFF10B981).copy(alpha = 0.7f)
                                                else Color(0xFFDC2626).copy(alpha = 0.7f)
                                            } else {
                                                Color.Gray
                                            }
                                        )
                                    }

                                    val isInactiveStudent = student.status == "منسحب" || student.status == "توقيف قيد" || student.status == "موقوف" || student.status == "موقف"
                                    IconButton(
                                        onClick = {
                                            if (isLockedForEditing) {
                                                Toast.makeText(context, "سجلات هذه الدورة منتهية ومحمية 🔒. اضغط على 'فتح القفل 🔓' أعلى الشاشة للتعديل.", Toast.LENGTH_LONG).show()
                                            } else if (isInactiveStudent) {
                                                Toast.makeText(context, "لا يمكن رصد أو تعديل درجات طالب موقوف أو منسحب! ⚠️", Toast.LENGTH_SHORT).show()
                                            } else {
                                                onEditGrade(subjectName)
                                            }
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isLockedForEditing || isInactiveStudent) Icons.Default.Lock else Icons.Default.Edit,
                                            contentDescription = if (isLockedForEditing) "سجل مقفل (دورة منتهية)" else if (isInactiveStudent) "حساب مقفل (موقوف/منسحب)" else "تعديل ورصد",
                                            tint = if (isLockedForEditing) Color(0xFF64748B) else if (isInactiveStudent) Color.Gray else if (pastGradeRecord != null && gradeRecord == null) Color(0xFF0284C7) else DawamiNavy,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// ---------------- GRADE REPORTS SCREEN (تقارير الدرجات) ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GradeReportsScreen(
    viewModel: MainViewModel,
    gradingViewModel: GradingViewModel? = null,
    showMainLayout: Boolean = true
) {
    val context = LocalContext.current
    val dbCourses by viewModel.dbCourses.collectAsState()
    val showCompletedCourses by viewModel.showCompletedCoursesInDropdowns.collectAsState()
    val dbAllStudents by viewModel.dbAllStudents.collectAsState()
    val dbAllGrades by (gradingViewModel?.allGrades ?: viewModel.dbAllGrades).collectAsState()
    val dbAllGradeConfigs by (gradingViewModel?.allGradeConfigs ?: viewModel.dbAllGradeConfigs).collectAsState()

    var selectedDepartment by remember { mutableStateOf<String?>(null) }
    var selectedDiploma by remember { mutableStateOf<String?>(null) }
    var selectedCourseForReport by remember { mutableStateOf<Course?>(null) }
    var selectedSubjectForReport by remember { mutableStateOf<String?>(null) } // null = الكل
    var selectedStudentForReport by remember { mutableStateOf<Student?>(null) } // null = الكل
    var showImportExportExcelReportDialog by remember { mutableStateOf(false) }

    var isDeptDropdownExpanded by remember { mutableStateOf(false) }
    var isDipDropdownExpanded by remember { mutableStateOf(false) }
    var isCourseDropdownExpanded by remember { mutableStateOf(false) }
    var isSubjectDropdownExpanded by remember { mutableStateOf(false) }
    var isStudentDropdownExpanded by remember { mutableStateOf(false) }

    var showReportTypeDialog by remember { mutableStateOf(false) }
    var pendingShareAction by remember { mutableStateOf<((String) -> Unit)?>(null) }
    var showWhatsAppChoiceDialog by remember { mutableStateOf(false) }
    var shareMessageText by remember { mutableStateOf("") }

    var isBatchSharing by remember { mutableStateOf(false) }
    var batchStudentsToShare by remember { mutableStateOf(listOf<StudentBatchData>()) }
    var currentBatchIndex by remember { mutableStateOf(0) }

    // Department & Diploma filter options
    val departmentsList = remember(dbCourses) {
        listOf("الكل") + dbCourses.map { it.departmentName }.filter { it.isNotBlank() }.distinct()
    }

    val diplomasList = remember(dbCourses, selectedDepartment) {
        val filtered = if (!selectedDepartment.isNullOrEmpty() && selectedDepartment != "الكل") {
            dbCourses.filter { it.departmentName == selectedDepartment }
        } else {
            dbCourses
        }
        listOf("الكل") + filtered.map { it.diplomaName }.filter { it.isNotBlank() }.distinct()
    }

    val filteredCourses = remember(dbCourses, selectedDepartment, selectedDiploma, showCompletedCourses) {
        dbCourses.filter { course ->
            val completedMatch = showCompletedCourses || !course.isCompleted
            val deptMatch = selectedDepartment.isNullOrEmpty() || selectedDepartment == "الكل" || course.departmentName == selectedDepartment
            val dipMatch = selectedDiploma.isNullOrEmpty() || selectedDiploma == "الكل" || course.diplomaName == selectedDiploma
            completedMatch && deptMatch && dipMatch
        }
    }

    val uniqueDepartments = remember(dbCourses) {
        dbCourses.map { it.departmentName }.filter { it.isNotBlank() }.distinct()
    }

    val uniqueDiplomas = remember(dbCourses, selectedDepartment) {
        val filtered = if (!selectedDepartment.isNullOrEmpty() && selectedDepartment != "الكل") {
            dbCourses.filter { it.departmentName == selectedDepartment }
        } else {
            dbCourses
        }
        filtered.map { it.diplomaName }.filter { it.isNotBlank() }.distinct()
    }

    LaunchedEffect(uniqueDepartments) {
        if (uniqueDepartments.size == 1 && (selectedDepartment == null || selectedDepartment == "الكل")) {
            selectedDepartment = uniqueDepartments.first()
        }
    }

    LaunchedEffect(uniqueDiplomas) {
        if (uniqueDiplomas.size == 1 && (selectedDiploma == null || selectedDiploma == "الكل" || !uniqueDiplomas.contains(selectedDiploma))) {
            selectedDiploma = uniqueDiplomas.first()
        }
    }

    LaunchedEffect(filteredCourses) {
        if (filteredCourses.size == 1 && selectedCourseForReport == null) {
            selectedCourseForReport = filteredCourses.first()
        }
    }

    val currentConfig = selectedCourseForReport?.let { course ->
        val exact = dbAllGradeConfigs.find { it.courseId == course.id }
        val dipTemplateId = if (course.diplomaName.isNotEmpty()) StudentGradeConfig.getDiplomaTemplateId(course.diplomaName) else null
        val dipTemplate = if (dipTemplateId != null) dbAllGradeConfigs.find { it.courseId == dipTemplateId } else null
        val deptTemplateId = if (course.departmentName.isNotEmpty()) StudentGradeConfig.getDepartmentTemplateId(course.departmentName) else null
        val deptTemplate = if (deptTemplateId != null) dbAllGradeConfigs.find { it.courseId == deptTemplateId } else null

        val activeTemplate = dipTemplate ?: deptTemplate

        if (exact != null && exact.customFieldsJson.isNotEmpty()) {
            if (exact.subjectWeightsJson.isEmpty() && activeTemplate != null && activeTemplate.subjectWeightsJson.isNotEmpty()) {
                exact.copy(subjectWeightsJson = activeTemplate.subjectWeightsJson)
            } else {
                exact
            }
        } else if (exact != null) {
            if (activeTemplate != null && activeTemplate.customFieldsJson.isNotEmpty()) {
                exact.copy(
                    customFieldsJson = activeTemplate.customFieldsJson,
                    subjectWeightsJson = if (activeTemplate.subjectWeightsJson.isNotEmpty()) activeTemplate.subjectWeightsJson else exact.subjectWeightsJson
                )
            } else exact
        } else if (activeTemplate != null) {
            activeTemplate.copy(courseId = course.id, courseName = course.name)
        } else null
    }

    val courseStudents = selectedCourseForReport?.let { course ->
        dbAllStudents.filter { it.courseId == course.id }
    } ?: emptyList()

    val courseGrades = selectedCourseForReport?.let { course ->
        dbAllGrades.filter { it.courseId == course.id }
    } ?: emptyList()

    val configFields = currentConfig?.let { StudentGradeConfig.deserializeFields(it.customFieldsJson) } ?: emptyList()
    val rawSubjects = if (currentConfig?.isDiploma == true) {
        currentConfig.getDiplomaSubjects()
    } else {
        configFields.map { it.first.substringBefore("_") }.distinct()
    }
    val courseSubjects = StudentGradeConfig.sortSubjectsList(rawSubjects)

    val displayedStudents = remember(courseStudents, selectedStudentForReport) {
        if (selectedStudentForReport != null) {
            listOf(selectedStudentForReport!!)
        } else {
            courseStudents
        }
    }

    val coroutineScope = rememberCoroutineScope()
    var showExportGradesModeDialog by remember { mutableStateOf(false) }
    var exportGradesIsWeighted by remember { mutableStateOf(false) }

    val pdfSaveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null && selectedCourseForReport != null && currentConfig != null) {
            val course = selectedCourseForReport!!
            val config = currentConfig
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        PdfReportHelper.exportCourseGradesToPdf(
                            viewModel = viewModel,
                            course = course,
                            config = config,
                            students = displayedStudents,
                            grades = courseGrades,
                            outputStream = outputStream,
                            useWeighted = exportGradesIsWeighted
                        )
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "تم تصدير كشف الدرجات بنجاح بصيغة PDF! 📄💾", Toast.LENGTH_LONG).show()
                    }
                    viewModel.logActivity(
                        category = "GRADES",
                        actionType = "CREATE",
                        title = "تصدير كشف الدرجات PDF 📄",
                        description = "تم تصدير وحفظ كشف درجات الطلاب لدورة (${course.name}) كملف PDF بنجاح"
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "فشل تصدير كشف الدرجات: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = DawamiNavy.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Assessment, contentDescription = null, tint = DawamiNavy)
                                }
                            }
                            Text(
                                text = "تقارير كشوفات درجات الدورات والطلاب",
                                color = DawamiNavy,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "قم بتصفيات البحث بالقسم والدبلوم والدورة والمادة والطالب لاستعراض الدرجات وتصدير كشف PDF أو مشاركته عبر الواتساب والمشاركة العامة.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            lineHeight = 18.sp
                        )

                        // 1. Department Filter Dropdown
                        ExposedDropdownMenuBox(
                            expanded = isDeptDropdownExpanded,
                            onExpandedChange = { isDeptDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = if (selectedDepartment.isNullOrEmpty() || selectedDepartment == "الكل") "القسم: الكل" else "القسم: $selectedDepartment",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("القسم") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDeptDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                            )

                            ExposedDropdownMenu(
                                expanded = isDeptDropdownExpanded,
                                onDismissRequest = { isDeptDropdownExpanded = false }
                            ) {
                                departmentsList.forEach { dept ->
                                    DropdownMenuItem(
                                        text = { Text(if (dept == "الكل") "الكل (جميع الأقسام)" else dept, fontWeight = FontWeight.Medium) },
                                        onClick = {
                                            selectedDepartment = dept
                                            selectedDiploma = "الكل"
                                            selectedCourseForReport = null
                                            selectedSubjectForReport = null
                                            selectedStudentForReport = null
                                            isDeptDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // 2. Diploma Filter Dropdown
                        ExposedDropdownMenuBox(
                            expanded = isDipDropdownExpanded,
                            onExpandedChange = { isDipDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = if (selectedDiploma.isNullOrEmpty() || selectedDiploma == "الكل") "الدبلوم: الكل" else "الدبلوم: $selectedDiploma",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("الدبلوم") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDipDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                            )

                            ExposedDropdownMenu(
                                expanded = isDipDropdownExpanded,
                                onDismissRequest = { isDipDropdownExpanded = false }
                            ) {
                                diplomasList.forEach { dip ->
                                    DropdownMenuItem(
                                        text = { Text(if (dip == "الكل") "الكل (جميع الدبلومات)" else dip, fontWeight = FontWeight.Medium) },
                                        onClick = {
                                            selectedDiploma = dip
                                            selectedCourseForReport = null
                                            selectedSubjectForReport = null
                                            selectedStudentForReport = null
                                            isDipDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // 3. Course Filter Dropdown
                        ExposedDropdownMenuBox(
                            expanded = isCourseDropdownExpanded,
                            onExpandedChange = { isCourseDropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = selectedCourseForReport?.name ?: "اختر الدورة التدريبية...",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("الدورة التدريبية") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCourseDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                            )

                            ExposedDropdownMenu(
                                expanded = isCourseDropdownExpanded,
                                onDismissRequest = { isCourseDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                            )
                                            Icon(
                                                imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = null,
                                                tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.toggleShowCompletedCoursesInDropdowns()
                                    }
                                )
                                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                                if (filteredCourses.isEmpty()) {
                                    DropdownMenuItem(
                                        text = { Text("لا توجد دورات مطابقة للفلترة", color = Color.Gray) },
                                        onClick = { isCourseDropdownExpanded = false }
                                    )
                                } else {
                                    filteredCourses.forEach { course ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = if (course.isCompleted) "${course.name} (منتهية 🔒)" else course.name,
                                                    fontWeight = FontWeight.Medium,
                                                    color = if (course.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                                )
                                            },
                                            onClick = {
                                                selectedCourseForReport = course
                                                selectedSubjectForReport = null
                                                selectedStudentForReport = null
                                                isCourseDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        if (selectedCourseForReport != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // 4. Subject Filter Dropdown
                                ExposedDropdownMenuBox(
                                    expanded = isSubjectDropdownExpanded,
                                    onExpandedChange = { isSubjectDropdownExpanded = it },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    OutlinedTextField(
                                        value = if (selectedSubjectForReport.isNullOrEmpty() || selectedSubjectForReport == "الكل") "المادة: الكل" else selectedSubjectForReport!!,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("المادة") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSubjectDropdownExpanded) },
                                        modifier = Modifier.menuAnchor(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                                    )

                                    ExposedDropdownMenu(
                                        expanded = isSubjectDropdownExpanded,
                                        onDismissRequest = { isSubjectDropdownExpanded = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("الكل (جميع المواد)", fontWeight = FontWeight.Medium) },
                                            onClick = {
                                                selectedSubjectForReport = null
                                                isSubjectDropdownExpanded = false
                                            }
                                        )
                                        courseSubjects.forEach { subName ->
                                            DropdownMenuItem(
                                                text = { Text(subName, fontWeight = FontWeight.Medium) },
                                                onClick = {
                                                    selectedSubjectForReport = subName
                                                    isSubjectDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                // 5. Student Filter Dropdown
                                ExposedDropdownMenuBox(
                                    expanded = isStudentDropdownExpanded,
                                    onExpandedChange = { isStudentDropdownExpanded = it },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    OutlinedTextField(
                                        value = selectedStudentForReport?.name ?: "الطالب: الكل",
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("الطالب المحدد") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStudentDropdownExpanded) },
                                        modifier = Modifier.menuAnchor(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                                    )

                                    ExposedDropdownMenu(
                                        expanded = isStudentDropdownExpanded,
                                        onDismissRequest = { isStudentDropdownExpanded = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("الكل (جميع الطلاب)", fontWeight = FontWeight.Medium) },
                                            onClick = {
                                                selectedStudentForReport = null
                                                isStudentDropdownExpanded = false
                                            }
                                        )
                                        courseStudents.forEach { student ->
                                            DropdownMenuItem(
                                                text = { Text(student.name, fontWeight = FontWeight.Medium) },
                                                onClick = {
                                                    selectedStudentForReport = student
                                                    isStudentDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (selectedCourseForReport != null) {
                if (currentConfig == null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = DawamiGold, modifier = Modifier.size(40.dp))
                                    Text("هذه الدورة لم يتم تهيئة تقسيم درجاتها بعد! ⚠️", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("الرجاء الذهاب لشاشة (الدرجات) من القائمة لتهيئة هذه الدورة ورصد درجات الطلاب أولاً.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                } else {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // PDF Export Button
                            Button(
                                onClick = {
                                    if (displayedStudents.isEmpty()) {
                                        Toast.makeText(context, "لا يوجد طلاب مطبقون للفلترة الحالية لتصدير الكشف! ❌", Toast.LENGTH_SHORT).show()
                                    } else {
                                        showExportGradesModeDialog = true
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تصدير PDF 📄", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                            }

                            // Excel Export & Import Button
                            Button(
                                onClick = {
                                    if (displayedStudents.isEmpty()) {
                                        Toast.makeText(context, "لا يوجد طلاب مطبقون للفلترة الحالية! ❌", Toast.LENGTH_SHORT).show()
                                    } else {
                                        showImportExportExcelReportDialog = true
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.TableView, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Excel استيراد/تصدير 📊", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                            }

                            // Share / WhatsApp Button
                            Button(
                                onClick = {
                                    if (displayedStudents.isEmpty()) {
                                        Toast.makeText(context, "لا يوجد طلاب مطبقون للفلترة الحالية! ❌", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val filterSubjects = if (!selectedSubjectForReport.isNullOrEmpty() && selectedSubjectForReport != "الكل") {
                                            listOf(selectedSubjectForReport!!)
                                        } else {
                                            courseSubjects
                                        }

                                        if (selectedStudentForReport != null) {
                                            // Share single selected student
                                            val student = selectedStudentForReport!!
                                            val studentGrades = courseGrades.filter { it.studentId == student.id }
                                            val totalSum = studentGrades.sumOf { it.getTotalScore() }.toFloat()
                                            val avg = if (filterSubjects.isNotEmpty()) totalSum / filterSubjects.size else 0f

                                            val hasWeights = currentConfig.subjectWeightsJson.isNotEmpty()
                                            val configWeightsMap = if (hasWeights) currentConfig.getSubjectWeights() else emptyMap<String, Double>()
                                            val configWeightsSum = configWeightsMap.values.sum()

                                            var weightedTotalScore = 0.0
                                            var totalWeightEvaluated = 0.0

                                            filterSubjects.forEach { subjectName ->
                                                val gradeRecord = studentGrades.find { it.subjectName == subjectName }
                                                if (gradeRecord != null && hasWeights) {
                                                    val subjectWeight = configWeightsMap[subjectName] ?: 0.0
                                                    weightedTotalScore += (gradeRecord.getTotalScore() * subjectWeight / 100.0)
                                                    totalWeightEvaluated += subjectWeight
                                                }
                                            }

                                            val weightedAveragePercentage = if (totalWeightEvaluated > 0.0) {
                                                (weightedTotalScore / totalWeightEvaluated) * 100.0
                                            } else 0.0

                                            pendingShareAction = { reportMode ->
                                                shareMessageText = generateStudentGradeReportText(
                                                    studentName = student.name,
                                                    courseName = selectedCourseForReport!!.name,
                                                    subjects = filterSubjects,
                                                    studentGrades = studentGrades,
                                                    totalSum = totalSum,
                                                    avg = avg,
                                                    weightedTotalScore = weightedTotalScore,
                                                    configWeightsSum = configWeightsSum,
                                                    weightedAveragePercentage = weightedAveragePercentage,
                                                    hasWeights = hasWeights,
                                                    instituteName = viewModel.instituteName.value,
                                                    isDetailed = reportMode == "DETAILED",
                                                    subjectWeights = configWeightsMap,
                                                    config = currentConfig,
                                                    reportMode = reportMode
                                                )
                                                showWhatsAppChoiceDialog = true
                                            }
                                            showReportTypeDialog = true
                                        } else {
                                            // Batch share all course students
                                            pendingShareAction = { reportMode ->
                                                val batchList = mutableListOf<StudentBatchData>()
                                                courseStudents.forEach { student ->
                                                    val studentGrades = courseGrades.filter { it.studentId == student.id }
                                                    val totalSum = studentGrades.sumOf { it.getTotalScore() }.toFloat()
                                                    val avg = if (filterSubjects.isNotEmpty()) totalSum / filterSubjects.size else 0f

                                                    val hasWeights = currentConfig.subjectWeightsJson.isNotEmpty()
                                                    val configWeightsMap = if (hasWeights) currentConfig.getSubjectWeights() else emptyMap<String, Double>()
                                                    val configWeightsSum = configWeightsMap.values.sum()

                                                    var weightedTotalScore = 0.0
                                                    var totalWeightEvaluated = 0.0

                                                    filterSubjects.forEach { subjectName ->
                                                        val gradeRecord = studentGrades.find { it.subjectName == subjectName }
                                                        if (gradeRecord != null && hasWeights) {
                                                            val subjectWeight = configWeightsMap[subjectName] ?: 0.0
                                                            weightedTotalScore += (gradeRecord.getTotalScore() * subjectWeight / 100.0)
                                                            totalWeightEvaluated += subjectWeight
                                                        }
                                                    }

                                                    val weightedAveragePercentage = if (totalWeightEvaluated > 0.0) {
                                                        (weightedTotalScore / totalWeightEvaluated) * 100.0
                                                    } else 0.0

                                                    val msgText = generateStudentGradeReportText(
                                                        studentName = student.name,
                                                        courseName = selectedCourseForReport!!.name,
                                                        subjects = filterSubjects,
                                                        studentGrades = studentGrades,
                                                        totalSum = totalSum,
                                                        avg = avg,
                                                        weightedTotalScore = weightedTotalScore,
                                                        configWeightsSum = configWeightsSum,
                                                        weightedAveragePercentage = weightedAveragePercentage,
                                                        hasWeights = hasWeights,
                                                        instituteName = viewModel.instituteName.value,
                                                        isDetailed = reportMode == "DETAILED",
                                                        subjectWeights = configWeightsMap,
                                                        config = currentConfig,
                                                        reportMode = reportMode
                                                    )

                                                    val cleanedPhone = student.phoneNumber.replace(Regex("[^0-9+]"), "").trim()
                                                    batchList.add(
                                                        StudentBatchData(
                                                            studentName = student.name,
                                                            phoneNumber = cleanedPhone,
                                                            messageText = msgText
                                                        )
                                                    )
                                                }

                                                batchStudentsToShare = batchList
                                                currentBatchIndex = 0
                                                isBatchSharing = true
                                            }
                                            showReportTypeDialog = true
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (selectedStudentForReport != null) "مشاركة النتيجة 📱" else "مشاركة للجميع 📱", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "تفاصيل ودرجات الطلاب حسب التهيئة:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = DawamiNavy
                                )

                                val weights = currentConfig.getSubjectWeights()
                                val hasWeights = weights.isNotEmpty()
                                val defaultWeight = if (courseSubjects.isNotEmpty()) 100.0 / courseSubjects.size else 0.0

                                val activeSubjects = if (!selectedSubjectForReport.isNullOrEmpty() && selectedSubjectForReport != "الكل") {
                                    listOf(selectedSubjectForReport!!)
                                } else {
                                    courseSubjects
                                }

                                displayedStudents.forEach { student ->
                                    val gradesForStudent = courseGrades.filter { it.studentId == student.id }
                                    val totalSum = gradesForStudent.sumOf { it.getTotalScore() }.toFloat()

                                    val configWeightsSum = activeSubjects.sumOf { weights[it] ?: defaultWeight }
                                    var weightedTotalScore = 0.0
                                    var gradedWeightsSum = 0.0
                                    activeSubjects.forEach { sub ->
                                        val gr = gradesForStudent.find { it.subjectName == sub }
                                        if (gr != null) {
                                            val w = weights[sub] ?: defaultWeight
                                            weightedTotalScore += (gr.getTotalScore() / 100.0) * w
                                            gradedWeightsSum += w
                                        }
                                    }

                                    val weightedAveragePercentage = if (gradedWeightsSum > 0.0) (weightedTotalScore / gradedWeightsSum) * 100.0 else 0.0
                                    val avg = if (activeSubjects.isNotEmpty()) totalSum / activeSubjects.size else 0f

                                    var isExpanded by remember(student.id) { mutableStateOf(false) }

                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable { isExpanded = !isExpanded }
                                                    .padding(vertical = 4.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Icon(
                                                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                                        contentDescription = if (isExpanded) "طي التفاصيل" else "توسيع التفاصيل",
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                    Column {
                                                        Text(
                                                            text = student.name,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 14.sp,
                                                            color = MaterialTheme.colorScheme.onSurface
                                                        )
                                                        if (!isExpanded) {
                                                            val averageStr = if (hasWeights) {
                                                                "${String.format(java.util.Locale.US, "%.1f", weightedAveragePercentage)}%"
                                                            } else {
                                                                "${String.format(java.util.Locale.US, "%.1f", avg)}%"
                                                            }
                                                            Text(
                                                                text = "${if (hasWeights) "المعدل الموزون" else "المعدل"}: $averageStr | المجموع: ${totalSum.toInt()}",
                                                                fontSize = 11.sp,
                                                                color = DawamiNavy
                                                            )
                                                        }
                                                    }
                                                }

                                                IconButton(
                                                    onClick = {
                                                        val studentGrades = courseGrades.filter { it.studentId == student.id }
                                                        pendingShareAction = { reportMode ->
                                                            shareMessageText = generateStudentGradeReportText(
                                                                studentName = student.name,
                                                                courseName = selectedCourseForReport!!.name,
                                                                subjects = activeSubjects,
                                                                studentGrades = studentGrades,
                                                                totalSum = totalSum,
                                                                avg = avg,
                                                                weightedTotalScore = weightedTotalScore,
                                                                configWeightsSum = configWeightsSum,
                                                                weightedAveragePercentage = weightedAveragePercentage,
                                                                hasWeights = hasWeights,
                                                                instituteName = viewModel.instituteName.value,
                                                                isDetailed = reportMode == "DETAILED",
                                                                subjectWeights = weights,
                                                                config = currentConfig,
                                                                reportMode = reportMode
                                                            )
                                                            showWhatsAppChoiceDialog = true
                                                        }
                                                        showReportTypeDialog = true
                                                    },
                                                    modifier = Modifier.size(30.dp)
                                                ) {
                                                    Surface(
                                                        color = Color(0xFF25D366),
                                                        shape = CircleShape,
                                                        modifier = Modifier.fillMaxSize()
                                                    ) {
                                                        Box(contentAlignment = Alignment.Center) {
                                                            Icon(
                                                                imageVector = Icons.Default.Share,
                                                                contentDescription = "مشاركة نتيجته",
                                                                tint = Color.White,
                                                                modifier = Modifier.size(14.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            AnimatedVisibility(
                                                visible = isExpanded,
                                                enter = expandVertically() + fadeIn(),
                                                exit = shrinkVertically() + fadeOut()
                                            ) {
                                                Column(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    HorizontalDivider(color = Color(0xFFE2E8F0))

                                                    // Display subject grades formatted as requested (e.g. مقدمة في الحاسوب 14/15)
                                                    activeSubjects.forEach { subjectName ->
                                                        val gradeRecord = gradesForStudent.find { it.subjectName == subjectName }
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Text(
                                                                text = subjectName,
                                                                fontSize = 12.sp,
                                                                fontWeight = FontWeight.Medium,
                                                                color = MaterialTheme.colorScheme.onSurface
                                                            )
                                                            Column(horizontalAlignment = Alignment.End) {
                                                                Text(
                                                                    text = if (gradeRecord != null) "${gradeRecord.getTotalScore().toInt()} / 100" else "غير مرصود",
                                                                    fontSize = 12.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = if (gradeRecord != null) DawamiNavy else Color.Red
                                                                )
                                                                if (gradeRecord != null && hasWeights) {
                                                                    val subjectWeight = weights[subjectName] ?: defaultWeight
                                                                    if (subjectWeight > 0) {
                                                                        val weightedScore = (gradeRecord.getTotalScore() * subjectWeight) / 100.0
                                                                        val formattedWeighted = if (weightedScore % 1.0 == 0.0) weightedScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weightedScore)
                                                                        val formattedMax = if (subjectWeight % 1.0 == 0.0) subjectWeight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", subjectWeight)
                                                                        Text(
                                                                            text = "$formattedWeighted / $formattedMax",
                                                                            fontSize = 11.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                            color = DawamiTeal
                                                                        )
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }

                                                    Spacer(modifier = Modifier.height(4.dp))

                                                    Column(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                         Surface(
                                                             color = Color(0xFFF1F5F9),
                                                             shape = RoundedCornerShape(8.dp),
                                                             modifier = Modifier.fillMaxWidth()
                                                         ) {
                                                             Row(
                                                                 modifier = Modifier
                                                                     .fillMaxWidth()
                                                                     .padding(horizontal = 10.dp, vertical = 6.dp),
                                                                 horizontalArrangement = Arrangement.SpaceBetween,
                                                                 verticalAlignment = Alignment.CenterVertically
                                                             ) {
                                                                 Text(
                                                                     text = "الدرجة الكلية :",
                                                                     fontSize = 12.sp,
                                                                     fontWeight = FontWeight.Bold,
                                                                     color = DawamiNavy,
                                                                     maxLines = 1,
                                                                     softWrap = false
                                                                 )
                                                                 Text(
                                                                     text = "${totalSum.toInt()} من ${activeSubjects.size * 100}",
                                                                     fontSize = 12.sp,
                                                                     fontWeight = FontWeight.Bold,
                                                                     color = DawamiNavy,
                                                                     maxLines = 1,
                                                                     softWrap = false
                                                                 )
                                                             }
                                                         }
                                                        Surface(
                                                            color = Color(0xFFE0F2FE),
                                                            shape = RoundedCornerShape(8.dp),
                                                            modifier = Modifier.fillMaxWidth()
                                                        ) {
                                                            Row(
                                                                modifier = Modifier
                                                                     .fillMaxWidth()
                                                                     .padding(horizontal = 10.dp, vertical = 6.dp),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Text(
                                                                    text = if (hasWeights) "المعدل الموزون :" else "المعدل العام :",
                                                                    fontSize = 12.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = Color(0xFF0369A1),
                                                                    maxLines = 1,
                                                                    softWrap = false
                                                                )
                                                                Text(
                                                                    text = if (hasWeights) {
                                                                        "${String.format(java.util.Locale.US, "%.1f", weightedAveragePercentage)}%"
                                                                    } else {
                                                                        "${String.format(java.util.Locale.US, "%.1f", avg)}%"
                                                                    },
                                                                    fontSize = 12.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = Color(0xFF0369A1),
                                                                    maxLines = 1,
                                                                    softWrap = false
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (isBatchSharing) {
        BatchWhatsAppShareDialog(
            onDismiss = { isBatchSharing = false },
            batchList = batchStudentsToShare,
            currentIndex = currentBatchIndex,
            onIndexChanged = { currentBatchIndex = it },
            context = context
        )
    }

    if (showWhatsAppChoiceDialog) {
        WhatsAppChoiceDialog(
            onDismiss = { showWhatsAppChoiceDialog = false },
            shareMessageText = shareMessageText,
            context = context
        )
    }

    val reportCourseGradingMode = selectedCourseForReport?.let { viewModel.getCourseGradingMode(it.id) } ?: "AUTO"
    val isReportCourseManualFinal = reportCourseGradingMode == "MANUAL_FINAL"

    if (showReportTypeDialog && pendingShareAction != null) {
        ReportTypeSelectionDialog(
            onDismiss = {
                showReportTypeDialog = false
                pendingShareAction = null
            },
            onSelectType = { reportMode ->
                showReportTypeDialog = false
                pendingShareAction?.invoke(reportMode)
                pendingShareAction = null
            },
            isManualFinal = isReportCourseManualFinal
        )
    }

    if (showExportGradesModeDialog && selectedCourseForReport != null && currentConfig != null) {
        AlertDialog(
            onDismissRequest = { showExportGradesModeDialog = false },
            icon = {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "تصدير كشف درجات الطلاب الرسمي PDF",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "اختر نمط احتساب وعرض درجات المواد في التقرير:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // خيار 1: حسب تهيئة المواد (الدرجة الفعلية لكل مادة)
                    Card(
                        onClick = {
                            exportGradesIsWeighted = false
                            showExportGradesModeDialog = false
                            val fileName = if (selectedStudentForReport != null) {
                                "كشف_درجات_${selectedStudentForReport!!.name.replace(" ", "_")}.pdf"
                            } else {
                                "كشف_درجات_${selectedCourseForReport?.name?.replace(" ", "_") ?: "الدورة"}.pdf"
                            }

                            if (viewModel.trainerBaseDirUri.value.isNotEmpty() && selectedCourseForReport != null && currentConfig != null) {
                                val course = selectedCourseForReport!!
                                val config = currentConfig!!
                                coroutineScope.launch(Dispatchers.IO) {
                                    val success = viewModel.savePdfReportToReportsFolder(context, fileName) { outputStream ->
                                        PdfReportHelper.exportCourseGradesToPdf(
                                            viewModel = viewModel,
                                            course = course,
                                            config = config,
                                            students = displayedStudents,
                                            grades = courseGrades,
                                            outputStream = outputStream,
                                            useWeighted = false
                                        )
                                    }
                                    withContext(Dispatchers.Main) {
                                        if (success) {
                                            Toast.makeText(context, "تم حفظ كشف الدرجات تلقائياً في مجلد Reports بنجاح! 📄⚡", Toast.LENGTH_LONG).show()
                                            viewModel.logActivity(
                                                category = "GRADES",
                                                actionType = "CREATE",
                                                title = "تصدير كشف الدرجات PDF 📄",
                                                description = "تم تصدير وحفظ كشف درجات الطلاب لدورة (${course.name}) في مجلد Reports"
                                            )
                                        } else {
                                            pdfSaveLauncher.launch(fileName)
                                        }
                                    }
                                }
                            } else {
                                pdfSaveLauncher.launch(fileName)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.5.dp, DawamiNavy.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = DawamiNavy.copy(alpha = 0.1f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Grading, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(20.dp))
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "حسب تهيئة المواد (الدرجة المرصودة)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = DawamiNavy
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = "يعرض الدرجة الفعلية المرصودة لكل مادة من الدرجة العظمى (مثل 100) موضحة تحت اسم المادة، مع المجموع العام والمعدل %.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    // خيار 2: حسب الموزون العام (أوزان المواد المعتمدة)
                    Card(
                        onClick = {
                            exportGradesIsWeighted = true
                            showExportGradesModeDialog = false
                            val fileName = if (selectedStudentForReport != null) {
                                "كشف_درجات_${selectedStudentForReport!!.name.replace(" ", "_")}_موزون.pdf"
                            } else {
                                "كشف_درجات_${selectedCourseForReport?.name?.replace(" ", "_") ?: "الدورة"}_موزون.pdf"
                            }

                            if (viewModel.trainerBaseDirUri.value.isNotEmpty() && selectedCourseForReport != null && currentConfig != null) {
                                val course = selectedCourseForReport!!
                                val config = currentConfig!!
                                coroutineScope.launch(Dispatchers.IO) {
                                    val success = viewModel.savePdfReportToReportsFolder(context, fileName) { outputStream ->
                                        PdfReportHelper.exportCourseGradesToPdf(
                                            viewModel = viewModel,
                                            course = course,
                                            config = config,
                                            students = displayedStudents,
                                            grades = courseGrades,
                                            outputStream = outputStream,
                                            useWeighted = true
                                        )
                                    }
                                    withContext(Dispatchers.Main) {
                                        if (success) {
                                            Toast.makeText(context, "تم حفظ كشف الدرجات الموزون تلقائياً في مجلد Reports بنجاح! 📄⚡", Toast.LENGTH_LONG).show()
                                            viewModel.logActivity(
                                                category = "GRADES",
                                                actionType = "CREATE",
                                                title = "تصدير كشف الدرجات الموزون PDF 📄",
                                                description = "تم تصدير وحفظ كشف درجات الطلاب الموزون لدورة (${course.name}) في مجلد Reports"
                                            )
                                        } else {
                                            pdfSaveLauncher.launch(fileName)
                                        }
                                    }
                                }
                            } else {
                                pdfSaveLauncher.launch(fileName)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.5.dp, DawamiTeal.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = DawamiTeal.copy(alpha = 0.1f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Calculate, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(20.dp))
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "حسب الموزون العام (أوزان المواد المعتمدة)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = DawamiTeal
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = "يعرض الدرجة الموزونة لكل مادة بحسب وزنها النسبي (مثل وزن 15) موضحاً تحت اسم المادة، مع مجموع الأوزان والمعدل الموزون.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showExportGradesModeDialog = false }) {
                    Text("إلغاء", fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }

    if (showImportExportExcelReportDialog && selectedCourseForReport != null) {
        val activeSub = if (!selectedSubjectForReport.isNullOrEmpty() && selectedSubjectForReport != "الكل") {
            selectedSubjectForReport!!
        } else {
            courseSubjects.firstOrNull() ?: "المقرر العام"
        }
        GradesImportExportDialog(
            course = selectedCourseForReport!!,
            allCourseStudents = courseStudents,
            config = currentConfig,
            existingGrades = courseGrades,
            currentSelectedSubject = activeSub,
            viewModel = viewModel,
            gradingViewModel = gradingViewModel,
            onDismiss = { showImportExportExcelReportDialog = false }
        )
    }
}

@Composable
fun WhatsAppChoiceDialog(
    onDismiss: () -> Unit,
    shareMessageText: String,
    context: android.content.Context
) {
    var editableText by remember(shareMessageText) { mutableStateOf(shareMessageText) }
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current

    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl
    ) {
        AlertDialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 12.dp),
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.EditNote,
                        contentDescription = null,
                        tint = DawamiNavy,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "معاينة وتعديل نص التقرير",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "يمكنك مراجعة أو تعديل أو إضافة أي ملاحظات على نص التقرير أدناه قبل إرساله:",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = editableText,
                        onValueChange = { editableText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 180.dp, max = 380.dp),
                        textStyle = TextStyle(fontSize = 12.sp, lineHeight = 18.sp),
                        shape = RoundedCornerShape(10.dp),
                        label = { Text("نص التقرير القابل للتعديل ✍️", fontSize = 11.sp) }
                    )

                    Text(
                        text = "💡 تنبيه: التقرير يتضمن كافة أسماء ودرجات الطلاب (يمكنك التمرير لأسفل لإنهاء المعاينة)",
                        fontSize = 10.5.sp,
                        color = Color(0xFF0284C7)
                    )

                    // Quick text utility buttons: Copy & Reset
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = {
                                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(editableText))
                                Toast.makeText(context, "تم نسخ نص التقرير كاملاً للحافظة بنجاح! 📋", Toast.LENGTH_SHORT).show()
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp), tint = Color(0xFF0284C7))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("نسخ النص 📋", fontSize = 11.sp, color = Color(0xFF0284C7), fontWeight = FontWeight.Bold)
                        }

                        if (editableText != shareMessageText) {
                            TextButton(
                                onClick = { editableText = shareMessageText },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(15.dp), tint = Color(0xFFD97706))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("استعادة النص الأصلي 🔄", fontSize = 11.sp, color = Color(0xFFD97706), fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // زر نسخ نص التقرير الرئيسي
                    Button(
                        onClick = {
                            clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(editableText))
                            try {
                                val clip = android.content.ClipData.newPlainText("Report Text", editableText)
                                (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager)?.setPrimaryClip(clip)
                            } catch (e: Exception) { e.printStackTrace() }
                            Toast.makeText(context, "تم نسخ نص التقرير كاملاً للحافظة بنجاح! 📋", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("نسخ نص التقرير 📋", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            onDismiss()
                            try {
                                // Always copy full text to clipboard for backup
                                try {
                                    val clip = android.content.ClipData.newPlainText("Report Text", editableText)
                                    (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager)?.setPrimaryClip(clip)
                                } catch (e: Exception) { e.printStackTrace() }

                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, editableText)
                                    putExtra(Intent.EXTRA_SUBJECT, "التقرير الختامي للدورة")
                                    setPackage("com.whatsapp")
                                }
                                context.startActivity(intent)
                                Toast.makeText(context, "تم توجيه التقرير كاملاً لواتساب 💬", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "تطبيق واتساب العادي غير مثبت على جهازك", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إرسال عبر واتساب (WhatsApp)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Button(
                        onClick = {
                            onDismiss()
                            try {
                                // Always copy full text to clipboard for backup
                                try {
                                    val clip = android.content.ClipData.newPlainText("Report Text", editableText)
                                    (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager)?.setPrimaryClip(clip)
                                } catch (e: Exception) { e.printStackTrace() }

                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, editableText)
                                    putExtra(Intent.EXTRA_SUBJECT, "التقرير الختامي للدورة")
                                    setPackage("com.whatsapp.w4b")
                                }
                                context.startActivity(intent)
                                Toast.makeText(context, "تم توجيه التقرير كاملاً لواتساب الأعمال 💬", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "تطبيق واتساب الأعمال غير مثبت على جهازك", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("واتساب الأعمال (WhatsApp Business)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Button(
                        onClick = {
                            onDismiss()
                            try {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, editableText)
                                }
                                val chooser = Intent.createChooser(intent, "مشاركة التقرير عبر:")
                                context.startActivity(chooser)
                            } catch (e: Exception) {
                                Toast.makeText(context, "تعذر فتح تطبيق المشاركة", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("مشاركة عامة (تطبيقات أخرى)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إلغاء", fontSize = 12.sp)
                    }
                }
            }
        )
    }
}

fun generateStudentGradeReportText(
    studentName: String,
    courseName: String,
    subjects: List<String>,
    studentGrades: List<StudentGrade>,
    totalSum: Float,
    avg: Float,
    weightedTotalScore: Double,
    configWeightsSum: Double,
    weightedAveragePercentage: Double,
    hasWeights: Boolean,
    instituteName: String,
    isDetailed: Boolean = false,
    subjectWeights: Map<String, Double> = emptyMap(),
    config: StudentGradeConfig? = null,
    reportMode: String = if (isDetailed) "DETAILED" else if (hasWeights) "CONFIG_WEIGHTED" else "RAW_100"
): String {
    val sb = StringBuilder()
    val isSingleSubject = subjects.size == 1
    val passingPercentage = config?.getPassingPercentage() ?: 75.0
    val passingPercentageStr = if (passingPercentage % 1.0 == 0.0) passingPercentage.toInt().toString() else String.format(java.util.Locale.US, "%.1f", passingPercentage)

    if (reportMode == "DETAILED" || isDetailed) {
        sb.append("📊 *كشف نتائج درجات الطالب*\n")
        sb.append("👤 *الاسم:* $studentName\n")
        sb.append("📚 *الدورة:* $courseName\n")
        sb.append("الدرجة النهائية\n")
        if (config == null || config.isDiploma) {
            sb.append("حضور 5      مشاركة 5\n")
            sb.append("تكاليف 10  مشاريع 20\n")
            sb.append("اختبار نظري 20       اختبار عملي 40\n")
        } else {
            val customFields = StudentGradeConfig.deserializeFields(config.customFieldsJson)
            val uniqueSubFields = customFields.map { it.first.substringAfter("_") to it.second }.distinctBy { it.first }
            val chunked = uniqueSubFields.chunked(2)
            chunked.forEach { pair ->
                if (pair.size == 2) {
                    sb.append("${pair[0].first} ${pair[0].second}      ${pair[1].first} ${pair[1].second}\n")
                } else if (pair.size == 1) {
                    sb.append("${pair[0].first} ${pair[0].second}\n")
                }
            }
        }
        sb.append("على حسب التهيئة للمادة\n\n")
        sb.append("📝 *تفاصيل الدرجات:*\n")

        subjects.forEach { subjectName ->
            val gradeRecord = studentGrades.find { it.subjectName == subjectName }
            if (gradeRecord != null) {
                sb.append("🔷 $subjectName:\n")
                val weight = subjectWeights[subjectName] ?: 0.0
                val totalScore = gradeRecord.getTotalScore()
                val formattedScore = if (totalScore % 1.0 == 0.0) totalScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", totalScore)
                val isSubjectPassed = totalScore >= passingPercentage
                val passBadge = if (isSubjectPassed) "ناجح ✅" else "راسب ⚠️"

                if (!isSingleSubject) {
                    if (hasWeights && weight > 0) {
                        val weightedScore = (totalScore * weight) / 100.0
                        val formattedWeighted = if (weightedScore % 1.0 == 0.0) weightedScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weightedScore)
                        val formattedMax = if (weight % 1.0 == 0.0) weight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weight)
                        val passSubjectThreshold = (passingPercentage / 100.0) * weight
                        val passSubjectThresholdStr = if (passSubjectThreshold % 1.0 == 0.0) passSubjectThreshold.toInt().toString() else String.format(java.util.Locale.US, "%.2f", passSubjectThreshold)
                        if (!isSubjectPassed) {
                            sb.append("(حد النجاح: $passSubjectThresholdStr)\n\n")
                        }
                        sb.append("الدرجة النهائية:  $formattedWeighted من $formattedMax\n")
                    } else {
                        if (!isSubjectPassed) {
                            sb.append("(حد النجاح: $passingPercentageStr من 100)\n\n")
                        }
                    }
                    sb.append("الاجمالي $formattedScore من 100\n")
                    sb.append("[$passBadge]\n\n")
                }

                if (config == null || config.isDiploma) {
                    val attendance = gradeRecord.attendanceScore
                    val participation = gradeRecord.participationScore
                    val assignments = gradeRecord.assignmentsScore
                    val projects = gradeRecord.projectsScore
                    val theory = gradeRecord.theoreticalExamScore
                    val practical = gradeRecord.practicalExamScore
                    
                    val fmtAtt = if (attendance % 1.0 == 0.0) attendance.toInt().toString() else String.format(java.util.Locale.US, "%.1f", attendance)
                    val fmtPart = if (participation % 1.0 == 0.0) participation.toInt().toString() else String.format(java.util.Locale.US, "%.1f", participation)
                    val fmtAss = if (assignments % 1.0 == 0.0) assignments.toInt().toString() else String.format(java.util.Locale.US, "%.1f", assignments)
                    val fmtProj = if (projects % 1.0 == 0.0) projects.toInt().toString() else String.format(java.util.Locale.US, "%.1f", projects)
                    val fmtTheo = if (theory % 1.0 == 0.0) theory.toInt().toString() else String.format(java.util.Locale.US, "%.1f", theory)
                    val fmtPrac = if (practical % 1.0 == 0.0) practical.toInt().toString() else String.format(java.util.Locale.US, "%.1f", practical)
                    
                    sb.append("▪️ حضور: $fmtAtt -- مشاركة: $fmtPart\n")
                    sb.append("▪️ تكاليف: $fmtAss -- مشاريع: $fmtProj\n")
                    sb.append("▪️ اختبار نظري: $fmtTheo -- اختبار عملي: $fmtPrac\n")
                } else {
                    val customScores = StudentGrade.deserializeScores(gradeRecord.customScoresJson)
                    val customFields = StudentGradeConfig.deserializeFields(config.customFieldsJson)
                    val subjectFields = customFields.filter { it.first.substringBefore("_") == subjectName }
                    val formattedFields = subjectFields.map { pair ->
                        val fullKey = pair.first
                        val fieldDisplayName = fullKey.substringAfter("_")
                        val score = customScores[fullKey] ?: 0.0
                        val fmtScore = if (score % 1.0 == 0.0) score.toInt().toString() else String.format(java.util.Locale.US, "%.1f", score)
                        "$fieldDisplayName: $fmtScore"
                    }
                    val chunkedFields = formattedFields.chunked(2)
                    chunkedFields.forEach { pair ->
                        if (pair.size == 2) {
                            sb.append("▪️ ${pair[0]} -- ▪️ ${pair[1]}\n")
                        } else if (pair.size == 1) {
                            sb.append("▪️ ${pair[0]}\n")
                        }
                    }
                }

                if (isSingleSubject) {
                    if (!isSubjectPassed) {
                        if (hasWeights && weight > 0) {
                            val passSubjectThreshold = (passingPercentage / 100.0) * weight
                            val passSubjectThresholdStr = if (passSubjectThreshold % 1.0 == 0.0) passSubjectThreshold.toInt().toString() else String.format(java.util.Locale.US, "%.2f", passSubjectThreshold)
                            val formattedMax = if (weight % 1.0 == 0.0) weight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weight)
                            sb.append("🎯 *حد النجاح:* $passSubjectThresholdStr من $formattedMax\n")
                        } else {
                            sb.append("🎯 *حد النجاح:* $passingPercentageStr من 100\n")
                        }
                    }

                    val subNote = gradeRecord.getGradeNote()
                    val noteSuffix = if (subNote.isNotBlank()) " (💡 $subNote)" else ""

                    if (hasWeights && weight > 0) {
                        val weightedScore = (totalScore * weight) / 100.0
                        val formattedWeighted = if (weightedScore % 1.0 == 0.0) weightedScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weightedScore)
                        val formattedMax = if (weight % 1.0 == 0.0) weight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weight)
                        sb.append("*مجموع المادة:* $formattedWeighted من $formattedMax$noteSuffix\n")
                    } else {
                        sb.append("*مجموع المادة:* $formattedScore من 100$noteSuffix\n")
                    }
                    sb.append("*الحالة:* $passBadge\n\n")
                } else {
                    val subNote = gradeRecord.getGradeNote()
                    if (subNote.isNotBlank()) {
                        sb.append(" (💡 $subNote)\n\n")
                    } else {
                        sb.append("\n")
                    }
                }
            } else {
                sb.append("🔸 $subjectName: غير مرصود بعد \n\n")
            }
        }

        if (!isSingleSubject) {
            val isAllRecorded = subjects.all { sub ->
                val gr = studentGrades.find { it.subjectName == sub }
                gr != null && gr.getTotalScore() > 0.0
            }
            val effectiveFinalGpa = if (hasWeights) weightedAveragePercentage else avg.toDouble()
            val isFinalPassed = effectiveFinalGpa >= passingPercentage
            val finalStatusText = if (!isAllRecorded) {
                "قيد الرصد والتقييم ⏳"
            } else if (isFinalPassed) {
                "ناجح ومجتاز للدورة/الدبلوم بنجاح 🎓✅"
            } else {
                "راسب (لم يستوفِ متطلبات النجاح) ⚠️"
            }

            if (hasWeights) {
                val formattedWeightedTotal = if (weightedTotalScore % 1.0 == 0.0) weightedTotalScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weightedTotalScore)
                val formattedMaxSum = if (configWeightsSum % 1.0 == 0.0) configWeightsSum.toInt().toString() else String.format(java.util.Locale.US, "%.1f", configWeightsSum)
                sb.append("*المجموع الكلي:* ${totalSum.toInt()} من ${subjects.size * 100}\n")
                sb.append("*المجموع حسب الوزن:* $formattedWeightedTotal من $formattedMaxSum\n")
                sb.append("*المعدل النهائي:* ${String.format(java.util.Locale.US, "%.1f", weightedAveragePercentage)}%\n")
                sb.append("🎯 *درجة/معدل النجاح:* $passingPercentageStr%\n")
                sb.append("🏆 *النتيجة النهائية:* $finalStatusText\n\n")
            } else {
                sb.append("*المجموع الكلي:* ${totalSum.toInt()} من ${subjects.size * 100}\n")
                sb.append("*المعدل النهائي:* ${String.format(java.util.Locale.US, "%.1f", avg)}%\n")
                sb.append("🎯 *درجة/معدل النجاح:* $passingPercentageStr%\n")
                sb.append("🏆 *النتيجة النهائية:* $finalStatusText\n\n")
            }
        }
    } else {
        val useWeights = reportMode == "CONFIG_WEIGHTED" && hasWeights

        sb.append("👤 *الاسم:* $studentName\n")
        sb.append("📚 *الدورة:* $courseName\n")
        if (!useWeights && !isSingleSubject) {
            sb.append("🎯 *حد النجاح:* $passingPercentageStr من 100\n")
        }
        sb.append("\n📝 *نتائج المواد:*\n\n")

        subjects.forEach { subjectName ->
            val gradeRecord = studentGrades.find { it.subjectName == subjectName }
            if (gradeRecord != null) {
                val weight = subjectWeights[subjectName] ?: 0.0
                val subNote = gradeRecord.getGradeNote()
                val noteSuffix = if (subNote.isNotBlank()) "\n (💡 $subNote)" else ""
                val isSubjectPassed = gradeRecord.getTotalScore() >= passingPercentage
                val passSuffix = if (isSubjectPassed) "✅" else "⚠️"
                sb.append("▪️ $subjectName:\n")

                if (!isSubjectPassed) {
                    if (useWeights && weight > 0) {
                        val passSubjectThreshold = (passingPercentage / 100.0) * weight
                        val passSubjectThresholdStr = if (passSubjectThreshold % 1.0 == 0.0) passSubjectThreshold.toInt().toString() else String.format(java.util.Locale.US, "%.2f", passSubjectThreshold)
                        val formattedMax = if (weight % 1.0 == 0.0) weight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weight)
                        sb.append("🎯 *حد النجاح:* $passSubjectThresholdStr من $formattedMax\n")
                    } else {
                        sb.append("🎯 *حد النجاح:* $passingPercentageStr من 100\n")
                    }
                }

                if (useWeights && weight > 0) {
                    val weightedScore = (gradeRecord.getTotalScore() * weight) / 100.0
                    val formattedWeighted = if (weightedScore % 1.0 == 0.0) weightedScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weightedScore)
                    val formattedMax = if (weight % 1.0 == 0.0) weight.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weight)
                    sb.append("الدرجة: $formattedWeighted من $formattedMax $passSuffix$noteSuffix\n\n")
                } else {
                    val score = gradeRecord.getTotalScore()
                    val formattedScore = if (score % 1.0 == 0.0) score.toInt().toString() else String.format(java.util.Locale.US, "%.1f", score)
                    sb.append("الدرجة: $formattedScore من 100 $passSuffix$noteSuffix\n\n")
                }

                if (isSingleSubject) {
                    sb.append("*الحالة:* ${if (isSubjectPassed) "ناجح ✅" else "راسب ⚠️"}\n\n")
                }
            } else {
                sb.append("▪️ $subjectName:\nغير مرصود بعد ⚠️\n\n")
            }
        }
        
        if (!isSingleSubject) {
            val isAllRecorded = subjects.all { sub ->
                val gr = studentGrades.find { it.subjectName == sub }
                gr != null && gr.getTotalScore() > 0.0
            }
            val effectiveFinalGpa = if (useWeights) weightedAveragePercentage else avg.toDouble()
            val isFinalPassed = effectiveFinalGpa >= passingPercentage
            val finalStatusText = if (!isAllRecorded) {
                "قيد الرصد ⏳"
            } else if (isFinalPassed) {
                "ناجح ✅"
            } else {
                "راسب ⚠️"
            }

            if (useWeights) {
                val formattedWeightedTotal = if (weightedTotalScore % 1.0 == 0.0) weightedTotalScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weightedTotalScore)
                val formattedMaxSum = if (configWeightsSum % 1.0 == 0.0) configWeightsSum.toInt().toString() else String.format(java.util.Locale.US, "%.1f", configWeightsSum)
                sb.append("*المجموع:* $formattedWeightedTotal من $formattedMaxSum\n")
                sb.append("📈 *المعدل الموزون العام:* ${String.format(java.util.Locale.US, "%.1f", weightedAveragePercentage)}%\n")
                sb.append("🎯 *نسبة النجاح:* $passingPercentageStr% | *الحالة:* $finalStatusText\n\n")
            } else {
                sb.append("*المجموع:* ${totalSum.toInt()} من ${subjects.size * 100}\n")
                sb.append("📈 *المعدل العام:* ${String.format(java.util.Locale.US, "%.1f", avg)}%\n")
                sb.append("🎯 *نسبة النجاح:* $passingPercentageStr% | *الحالة:* $finalStatusText\n\n")
            }
        }
    }

    sb.append("شاكرين لكم اهتمامكم ومتابعتكم المستمرة.\n")
    if (instituteName.isNotBlank()) {
        sb.append("*$instituteName* 🏫")
    }

    return sb.toString()
}

@Composable
fun ReportTypeSelectionDialog(
    onDismiss: () -> Unit,
    onSelectType: (reportMode: String) -> Unit,
    isManualFinal: Boolean = false
) {
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl
    ) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Title section
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            tint = DawamiNavy,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تحديد نوع التقرير",
                            style = TextStyle(
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy
                            ),
                            textAlign = TextAlign.Center
                        )
                    }

                    Text(
                        text = "يرجى تحديد تفاصيل التقرير الذي ترغب في مشاركته:",
                        style = TextStyle(
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    // Option 1: Detailed Report Button
                    OutlinedButton(
                        onClick = { onSelectType("DETAILED") },
                        enabled = !isManualFinal,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (!isManualFinal) DawamiNavy else Color(0xFF94A3B8),
                            disabledContentColor = Color(0xFF94A3B8)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.5.dp,
                            if (!isManualFinal) DawamiNavy.copy(alpha = 0.5f) else Color(0xFFCBD5E1)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (!isManualFinal) Icons.Default.Description else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (!isManualFinal) DawamiNavy else Color(0xFF94A3B8),
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (!isManualFinal) "تقرير مفصل بجميع درجات المواد" else "تقرير مفصل بجميع درجات المواد 🔒",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (!isManualFinal) DawamiNavy else Color(0xFF94A3B8)
                                )
                                Text(
                                    text = if (!isManualFinal) {
                                        "يحتوي على درجات كل مادة بالتفصيل."
                                    } else {
                                        "غير متاح بنمط الرصد اليدوي النهائي ⚠️"
                                    },
                                    fontSize = 10.5.sp,
                                    color = if (!isManualFinal) MaterialTheme.colorScheme.onSurfaceVariant else Color(0xFFEF4444).copy(alpha = 0.85f),
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    // Option 2: Summary Report (From 100)
                    OutlinedButton(
                        onClick = { onSelectType("RAW_100") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = DawamiNavy
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.5.dp,
                            DawamiNavy.copy(alpha = 0.5f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assignment,
                                contentDescription = null,
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "تقرير مختصر بالمجموع والمعدل (من 100) 💯",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = DawamiNavy
                                )
                                Text(
                                    text = "يحتوي على درجات المواد والمعدل العام الصافي من 100%.",
                                    fontSize = 10.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    // Option 3: Summary Report (According to Config)
                    OutlinedButton(
                        onClick = { onSelectType("CONFIG_WEIGHTED") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isManualFinal) DawamiNavy.copy(alpha = 0.06f) else Color.Transparent,
                            contentColor = DawamiNavy
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            if (isManualFinal) 2.dp else 1.5.dp,
                            if (isManualFinal) DawamiNavy else DawamiNavy.copy(alpha = 0.5f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = DawamiTeal,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "تقرير مختصر بالمجموع والمعدل (حسب التهيئة) ⚙️",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = DawamiNavy
                                    )
                                    if (isManualFinal) {
                                        Surface(
                                            color = DawamiNavy,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "المعتمد",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = "يحتوي على المجموع والمعدل العام وفق أوزان وتهيئة درجات الدورة.",
                                    fontSize = 10.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Cancel button
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(
                            text = "إلغاء",
                            color = Color(0xFFEF4444),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}



