package com.example.data.entity

import androidx.room.Entity

@Entity(tableName = "course_subjects", primaryKeys = ["courseId", "subjectId"])
data class CourseSubjectCrossRef(
    val courseId: Int,
    val subjectId: Int,
    val status: String = "قيد التدريس", // "قيد التدريس", "مكتملة التدريس", "في انتظار الاختبار", "مكتملة بالكامل"
    val targetDays: Int = 5,             // عدد الأيام المقررة في الخطة (الافتراضي 5 أيام)
    val completedDate: String = "",       // تاريخ إكمال التدريس "yyyy-MM-dd"
    val notes: String = ""               // ملاحظات إضافية
)

data class CourseSubjectStat(
    val subjectId: Int,
    val subjectName: String,
    val courseId: Int,
    val courseName: String,
    val taughtDaysCount: Int,      // عدد أيام التدريس الفعلية المحسوبة من تحضير الطلاب
    val targetDays: Int,           // الأيام المحددة في الخطة
    val status: String,            // "قيد التدريس", "مكتملة التدريس", "في انتظار الاختبار", "مكتملة بالكامل"
    val firstTaughtDate: String,   // تاريخ أول يوم تدريس
    val lastTaughtDate: String,    // تاريخ آخر يوم تدريس
    val completedDate: String,     // تاريخ الاعتماد كمكتملة
    val notes: String = ""
)


