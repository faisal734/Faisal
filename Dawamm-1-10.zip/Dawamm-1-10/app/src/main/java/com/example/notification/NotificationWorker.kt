package com.example.notification

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import android.content.Intent
import com.example.data.database.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NotificationWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val courseId = inputData.getInt("course_id", -1)
        val courseName = inputData.getString("course_name") ?: ""
        val type = inputData.getString("type") ?: ""
        val title = inputData.getString("title") ?: "تنبيه"
        val message = inputData.getString("message") ?: ""

        Log.d("NotificationWorker", "Executing worker for course: $courseName, type: $type")

        // Manually trigger the receiver logic
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra("course_id", courseId)
            putExtra("course_name", courseName)
            putExtra("type", type)
            putExtra("title", title)
            putExtra("message", message)
            putExtra("from_worker", true)
        }
        
        context.sendBroadcast(intent)
        
        Result.success()
    }
}
