package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentAttendance
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel

// Data class for student attendance statistics
data class StudentAttendanceStat(
    val student: Student,
    val presentCount: Int,
    val lateCount: Int,
    val totalDelayMinutes: Int,
    val leaveCount: Int,
    val excusedCount: Int,
    val absentCount: Int,
    val totalSessions: Int,
    val attendanceRate: Int,
    val hasWarning: Boolean,
    val attendanceList: List<StudentAttendance>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CourseAttendanceAnalyticsScreen(
    viewModel: MainViewModel,
    attendanceViewModel: AttendanceViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    showMainLayout: Boolean = true
) {
    val courses by viewModel.dbCourses.collectAsState()
    val allStudents by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val allAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()
    val selectedCourseForStudentAtt by viewModel.selectedCourseForStudentAttendance.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val context = LocalContext.current

    // Course Selection State
    var selectedCourseId by remember(courses, selectedCourseForStudentAtt) {
        mutableIntStateOf(
            selectedCourseForStudentAtt?.id ?: courses.firstOrNull()?.id ?: 0
        )
    }

    var showCourseDropdown by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf("الكل") } // "الكل", "مستمر", "توقيف قيد", "منسحب"
    var selectedSortOption by remember { mutableStateOf("الأنشط") } // "الأنشط", "الأكثر غياباً", "الأكثر تأخيراً", "حسب الحالة", "أبجدياً"
    var includePreviousCoursesHistory by remember { mutableStateOf(false) } // مفتاح تصفية الإحصائيات المرن
    var selectedStudentForDetail by remember { mutableStateOf<StudentAttendanceStat?>(null) }
    var isRefreshingStats by remember { mutableStateOf(false) }
    var refreshTrigger by remember { mutableStateOf(0) }
    val coroutineScope = rememberCoroutineScope()

    val currentCourse = courses.find { it.id == selectedCourseId } ?: courses.firstOrNull()

    // Calculate Course & Student Stats
    val courseStudents = remember(allStudents, selectedCourseId, refreshTrigger) {
        allStudents.filter { it.courseId == selectedCourseId }
    }

    val courseAttendanceRecords = remember(allAttendance, selectedCourseId, refreshTrigger) {
        allAttendance.filter { it.courseId == selectedCourseId }
    }

    // Student status counts
    val continuingCount = courseStudents.count { it.status == "مستمر" || it.status.isBlank() }
    val suspendedCount = courseStudents.count { it.status == "توقيف قيد" || it.status == "موقف" }
    val withdrawnCount = courseStudents.count { it.status == "منسحب" }
    val totalStudentsCount = courseStudents.size

    // Attendance Breakdown Across Course
    val coursePresentCount = courseAttendanceRecords.count { it.status == "حضور" }
    val courseLateCount = courseAttendanceRecords.count { it.checkInDelayMinutes > 0 }
    val courseLeaveCount = courseAttendanceRecords.count { it.status == "استئذان" || it.status == "مستأذن" }
    val courseExcusedCount = courseAttendanceRecords.count { it.status == "إجازة" }
    val courseAbsentCount = courseAttendanceRecords.count { it.status == "غياب" }
    val totalCourseRecords = courseAttendanceRecords.count { it.status != "إجازة" }

    val courseDisciplineRate = if (totalCourseRecords > 0) {
        ((coursePresentCount.toFloat() / totalCourseRecords) * 100).toInt()
    } else 100

    val uniqueDatesCount = courseAttendanceRecords.map { it.date }.distinct().size

    // Individual Student Stats
    val studentStatsList = remember(courseStudents, courseAttendanceRecords, allAttendance, includePreviousCoursesHistory) {
        courseStudents.map { student ->
            val stAtts = if (includePreviousCoursesHistory) {
                allAttendance.filter { it.studentId == student.id }
            } else {
                courseAttendanceRecords.filter { it.studentId == student.id }
            }
            val pCount = stAtts.count { it.status == "حضور" }
            val lCount = stAtts.count { it.checkInDelayMinutes > 0 }
            val delayMins = stAtts.sumOf { it.checkInDelayMinutes }
            val leaveC = stAtts.count { it.status == "استئذان" || it.status == "مستأذن" }
            val excC = stAtts.count { it.status == "إجازة" }
            val abC = stAtts.count { it.status == "غياب" }
            val requiredSessions = stAtts.count { it.status != "إجازة" }
            val totalS = stAtts.size
            val rate = if (requiredSessions > 0) ((pCount.toFloat() / requiredSessions) * 100).toInt() else 100
            val warning = abC >= 3 || (requiredSessions >= 4 && rate < 75)

            StudentAttendanceStat(
                student = student,
                presentCount = pCount,
                lateCount = lCount,
                totalDelayMinutes = delayMins,
                leaveCount = leaveC,
                excusedCount = excC,
                absentCount = abC,
                totalSessions = totalS,
                attendanceRate = rate,
                hasWarning = warning,
                attendanceList = stAtts.sortedByDescending { it.date }
            )
        }
    }

    // Filtered & Sorted Student Stats
    val filteredStudentStats = remember(studentStatsList, searchQuery, selectedStatusFilter, selectedSortOption) {
        var list = studentStatsList

        // Filter by Search
        if (searchQuery.isNotBlank()) {
            list = list.filter { it.student.name.contains(searchQuery.trim(), ignoreCase = true) }
        }

        val isCourseCompleted = currentCourse?.isCompleted == true
        // Filter by Status
        if (selectedStatusFilter != "الكل") {
            list = when (selectedStatusFilter) {
                "مستمر" -> list.filter { (it.student.status == "مستمر" || it.student.status.isBlank()) && !isCourseCompleted }
                "خريج" -> list.filter { it.student.status == "خريج" || ((it.student.status == "مستمر" || it.student.status.isBlank()) && isCourseCompleted) }
                "توقيف قيد" -> list.filter { it.student.status == "توقيف قيد" || it.student.status == "موقف" }
                "منسحب" -> list.filter { it.student.status == "منسحب" }
                else -> list
            }
        }

        // Sort
        when (selectedSortOption) {
            "الأنشط" -> list.sortedByDescending { it.attendanceRate }
            "الأكثر غياباً" -> list.sortedByDescending { it.absentCount }
            "الأكثر تأخيراً" -> list.sortedByDescending { it.totalDelayMinutes }
            "حسب الحالة" -> list.sortedBy {
                when (it.student.status) {
                    "مستمر", "" -> 1
                    "توقيف قيد", "موقف" -> 2
                    "منسحب" -> 3
                    else -> 4
                }
            }
            "أبجدياً" -> list.sortedBy { it.student.name }
            else -> list
        }
    }

    val screenContent = @Composable {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(if (isDarkTheme) Color(0xFF0F172A) else Color(0xFFF8FAFC))
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header Card & Course Selector
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Surface(
                                            color = DawamiNavy.copy(alpha = 0.12f),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.size(42.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.Default.Analytics,
                                                    contentDescription = null,
                                                    tint = DawamiNavy,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                        }
                                        Column {
                                            Text(
                                                text = "إحصائيات الحضور والطلاب 📊",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp,
                                                color = if (isDarkTheme) Color.White else Color(0xFF0F172A)
                                            )
                                            Text(
                                                text = "تحليل بياني شامل للطلاب وحالات الدورة",
                                                fontSize = 11.5.sp,
                                                color = Color(0xFF64748B)
                                            )
                                        }
                                    }

                                    // Refresh Button
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = DawamiTeal.copy(alpha = 0.12f),
                                        border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.3f)),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable(enabled = !isRefreshingStats) {
                                                isRefreshingStats = true
                                                refreshTrigger++
                                                coroutineScope.launch {
                                                    kotlinx.coroutines.delay(300)
                                                    isRefreshingStats = false
                                                    Toast.makeText(context, "تم تحديث الإحصائيات بنجاح 🔄", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            if (isRefreshingStats) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(14.dp),
                                                    strokeWidth = 2.dp,
                                                    color = DawamiTeal
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Default.Refresh,
                                                    contentDescription = "تحديث الإحصائيات",
                                                    tint = DawamiTeal,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                            Text(
                                                text = "تحديث",
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = DawamiTeal
                                            )
                                        }
                                    }
                                }

                                // Course Selector Dropdown Button (Dedicated Full Row)
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    Surface(
                                        onClick = { showCourseDropdown = true },
                                        shape = RoundedCornerShape(12.dp),
                                        color = DawamiNavy.copy(alpha = 0.08f),
                                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.25f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.School,
                                                    contentDescription = null,
                                                    tint = DawamiNavy,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Text(
                                                    text = "الدورة التدريبية: ${currentCourse?.name ?: "اختر الدورة"}",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.5.sp,
                                                    color = DawamiNavy
                                                )
                                            }
                                            Icon(
                                                imageVector = Icons.Default.ArrowDropDown,
                                                contentDescription = null,
                                                tint = DawamiNavy
                                            )
                                        }
                                    }

                                    DropdownMenu(
                                        expanded = showCourseDropdown,
                                        onDismissRequest = { showCourseDropdown = false },
                                        modifier = Modifier.background(if (isDarkTheme) Color(0xFF1E293B) else Color.White)
                                    ) {
                                        courses.forEach { course ->
                                            DropdownMenuItem(
                                                text = {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Text(
                                                            text = if (course.isCompleted) "🔒 ${course.name} (منتهية)" else "🟢 ${course.name}",
                                                            fontSize = 13.sp,
                                                            fontWeight = if (course.id == selectedCourseId) FontWeight.Bold else FontWeight.Normal,
                                                            color = if (course.id == selectedCourseId) DawamiNavy else if (isDarkTheme) Color.White else Color.Black
                                                        )
                                                    }
                                                },
                                                onClick = {
                                                    selectedCourseId = course.id
                                                    showCourseDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }

                                if (currentCourse != null) {
                                    HorizontalDivider(color = Color(0xFFE2E8F0))

                                    // Interactive Analytics Filter Switch
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(DawamiNavy.copy(alpha = 0.08f))
                                            .padding(3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(9.dp))
                                                .clickable { includePreviousCoursesHistory = false },
                                            color = if (!includePreviousCoursesHistory) DawamiNavy else Color.Transparent,
                                            shape = RoundedCornerShape(9.dp)
                                        ) {
                                            Box(modifier = Modifier.padding(vertical = 7.dp), contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "🎯 الدورة الحالية فقط",
                                                    fontSize = 11.5.sp,
                                                    fontWeight = if (!includePreviousCoursesHistory) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (!includePreviousCoursesHistory) Color.White else DawamiNavy
                                                )
                                            }
                                        }

                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(9.dp))
                                                .clickable { includePreviousCoursesHistory = true },
                                            color = if (includePreviousCoursesHistory) DawamiNavy else Color.Transparent,
                                            shape = RoundedCornerShape(9.dp)
                                        ) {
                                            Box(modifier = Modifier.padding(vertical = 7.dp), contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "🌐 الدورة الحالية + السابقة",
                                                    fontSize = 11.5.sp,
                                                    fontWeight = if (includePreviousCoursesHistory) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (includePreviousCoursesHistory) Color.White else DawamiNavy
                                                )
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "فترة الدورة: من ${currentCourse.startDate.ifBlank { "غير محددة" }} إلى ${currentCourse.endDate.ifBlank { "مستمرة" }}",
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B)
                                        )
                                        if (currentCourse.isCompleted) {
                                            Surface(
                                                color = Color(0xFFFEF2F2),
                                                shape = RoundedCornerShape(8.dp),
                                                border = BorderStroke(1.dp, Color(0xFFFCA5A5))
                                            ) {
                                                Text(
                                                    text = "🔒 دورة منتهية",
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF991B1B)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Course Level Overview & Status Donut Chart
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Text(
                                    text = "📊 التقرير الإحصائي والأكاديمي الشامل للدورة",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isDarkTheme) Color.White else Color(0xFF0F172A)
                                )

                                // KPI Metric Cards Grid
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    KpiMetricCard(
                                        title = "إجمالي الطلاب",
                                        value = "$totalStudentsCount طالب",
                                        badgeColor = DawamiTeal,
                                        icon = Icons.Default.Groups,
                                        modifier = Modifier.weight(1f),
                                        isDark = isDarkTheme
                                    )
                                    KpiMetricCard(
                                        title = "الانضباط العام",
                                        value = "$courseDisciplineRate%",
                                        badgeColor = if (courseDisciplineRate >= 85) Color(0xFF10B981) else Color(0xFFF59E0B),
                                        icon = Icons.Default.Speed,
                                        modifier = Modifier.weight(1f),
                                        isDark = isDarkTheme
                                    )
                                    KpiMetricCard(
                                        title = "أيام انعقاد الدورة",
                                        value = "$uniqueDatesCount يوم",
                                        badgeColor = DawamiNavy,
                                        icon = Icons.Default.CalendarToday,
                                        modifier = Modifier.weight(1f),
                                        isDark = isDarkTheme
                                    )
                                }

                                HorizontalDivider(color = Color(0xFFE2E8F0))

                                // Donut Chart Section for Student Statuses
                                Text(
                                    text = "🏷️ توزيع حالات قيد الطلاب بالدورة",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isDarkTheme) Color.White else Color(0xFF1E293B)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceAround
                                ) {
                                    // Custom Donut Canvas
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.size(130.dp)
                                    ) {
                                        StudentStatusDonutChart(
                                            continuing = continuingCount,
                                            suspended = suspendedCount,
                                            withdrawn = withdrawnCount,
                                            total = totalStudentsCount
                                        )
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = "$totalStudentsCount",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 20.sp,
                                                color = if (isDarkTheme) Color.White else Color(0xFF0F172A)
                                            )
                                            Text(
                                                text = "طالب",
                                                fontSize = 10.sp,
                                                color = Color(0xFF64748B)
                                            )
                                        }
                                    }

                                    // Legend Column
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.weight(1f).padding(start = 16.dp)
                                    ) {
                                        StatusLegendItem(
                                            label = "مستمرون",
                                            count = continuingCount,
                                            total = totalStudentsCount,
                                            color = Color(0xFF10B981),
                                            isDark = isDarkTheme
                                        )
                                        StatusLegendItem(
                                            label = "توقيف قيد",
                                            count = suspendedCount,
                                            total = totalStudentsCount,
                                            color = Color(0xFFF59E0B),
                                            isDark = isDarkTheme
                                        )
                                        StatusLegendItem(
                                            label = "منسحبون",
                                            count = withdrawnCount,
                                            total = totalStudentsCount,
                                            color = Color(0xFFEF4444),
                                            isDark = isDarkTheme
                                        )
                                    }
                                }

                                HorizontalDivider(color = Color(0xFFE2E8F0))

                                // Course Attendance Breakdown Segmented Bar
                                Text(
                                    text = "📈 تفكيك حركة الحضور والغياب الإجمالية للدورة",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isDarkTheme) Color.White else Color(0xFF1E293B)
                                )

                                AttendanceSegmentedBar(
                                    present = coursePresentCount,
                                    late = courseLateCount,
                                    leave = courseLeaveCount,
                                    excused = courseExcusedCount,
                                    absent = courseAbsentCount,
                                    total = totalCourseRecords
                                )

                                // Attendance Metric Badges Grid
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    AttendanceBadgeChip("حضور", coursePresentCount, totalCourseRecords, Color(0xFF10B981), Modifier.weight(1f))
                                    AttendanceBadgeChip("تأخير", courseLateCount, totalCourseRecords, Color(0xFFF59E0B), Modifier.weight(1f))
                                    AttendanceBadgeChip("استئذان", courseLeaveCount, totalCourseRecords, Color(0xFF0284C7), Modifier.weight(1f))
                                    AttendanceBadgeChip("إجازة", courseExcusedCount, totalCourseRecords, Color(0xFF8B5CF6), Modifier.weight(1f))
                                    AttendanceBadgeChip("غياب", courseAbsentCount, totalCourseRecords, Color(0xFFEF4444), Modifier.weight(1f))
                                }
                            }
                        }
                    }

                    // Student Section Header & Search / Filters
                    item {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(top = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "👨‍🎓 الإحصائية البيانية لكل طالب (${filteredStudentStats.size})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isDarkTheme) Color.White else Color(0xFF0F172A)
                                )
                            }

                            // Search Field
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("بحث عن طالب بالاسم...", fontSize = 12.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = "" }) {
                                            Icon(Icons.Default.Clear, contentDescription = null, tint = Color.Gray)
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White,
                                    unfocusedContainerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                                )
                            )

                            // Status Filter Chips
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("الكل", "مستمر", "خريج", "توقيف قيد", "منسحب").forEach { statusLabel ->
                                    val isSelected = selectedStatusFilter == statusLabel
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { selectedStatusFilter = statusLabel },
                                        label = { Text(statusLabel, fontSize = 11.5.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = DawamiNavy,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }

                            // Sort Options Dropdown Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("الترتيب حسب:", fontSize = 11.5.sp, color = Color(0xFF64748B))
                                ScrollableTabRow(
                                    selectedTabIndex = listOf("الأنشط", "الأكثر غياباً", "الأكثر تأخيراً", "حسب الحالة", "أبجدياً").indexOf(selectedSortOption),
                                    edgePadding = 0.dp,
                                    containerColor = Color.Transparent,
                                    divider = {}
                                ) {
                                    listOf("الأنشط", "الأكثر غياباً", "الأكثر تأخيراً", "حسب الحالة", "أبجدياً").forEach { sortTitle ->
                                        val isSel = selectedSortOption == sortTitle
                                        Tab(
                                            selected = isSel,
                                            onClick = { selectedSortOption = sortTitle },
                                            text = {
                                                Text(
                                                    sortTitle,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSel) DawamiNavy else Color(0xFF64748B)
                                                )
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // List of Student Attendance Cards
                    if (filteredStudentStats.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 20.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.PersonSearch, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.Gray)
                                    Text("لا يوجد طلاب يطابقون شروط البحث أو الفلترة", fontSize = 13.sp, color = Color.Gray, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    } else {
                        items(filteredStudentStats, key = { it.student.id }) { stat ->
                            StudentAnalyticsCard(
                                stat = stat,
                                isDark = isDarkTheme,
                                isCourseCompleted = currentCourse?.isCompleted == true,
                                onClick = { selectedStudentForDetail = stat }
                            )
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(30.dp))
                    }
                }
            }

            // Student Detail Modal Dialog
            selectedStudentForDetail?.let { stat ->
                StudentAttendanceDetailDialog(
                    stat = stat,
                    isDark = isDarkTheme,
                    onDismiss = { selectedStudentForDetail = null }
                )
            }
        }
    }

    if (showMainLayout) {
        MainLayout(viewModel = viewModel, showScaffold = true) { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
                screenContent()
            }
        }
    } else {
        screenContent()
    }
}

// ---------------- KPI METRIC CARD ----------------
@Composable
private fun KpiMetricCard(
    title: String,
    value: String,
    badgeColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    isDark: Boolean
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = badgeColor.copy(alpha = if (isDark) 0.15f else 0.08f)
        ),
        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.25f))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(icon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(15.dp))
                Text(title, fontSize = 10.sp, color = Color(0xFF64748B), maxLines = 1)
            }
            Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = badgeColor)
        }
    }
}

// ---------------- STUDENT STATUS DONUT CHART ----------------
@Composable
private fun StudentStatusDonutChart(
    continuing: Int,
    suspended: Int,
    withdrawn: Int,
    total: Int
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 22.dp.toPx()
        val diameter = size.minDimension - strokeWidth
        val radius = diameter / 2f
        val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
        val arcSize = Size(diameter, diameter)

        if (total == 0) {
            drawArc(
                color = Color(0xFFE2E8F0),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth)
            )
            return@Canvas
        }

        val continuingAngle = (continuing.toFloat() / total) * 360f
        val suspendedAngle = (suspended.toFloat() / total) * 360f
        val withdrawnAngle = (withdrawn.toFloat() / total) * 360f

        var currentStart = -90f

        if (continuingAngle > 0) {
            drawArc(
                color = Color(0xFF10B981),
                startAngle = currentStart,
                sweepAngle = continuingAngle - 2f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            currentStart += continuingAngle
        }

        if (suspendedAngle > 0) {
            drawArc(
                color = Color(0xFFF59E0B),
                startAngle = currentStart,
                sweepAngle = suspendedAngle - 2f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            currentStart += suspendedAngle
        }

        if (withdrawnAngle > 0) {
            drawArc(
                color = Color(0xFFEF4444),
                startAngle = currentStart,
                sweepAngle = withdrawnAngle - 2f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
private fun StatusLegendItem(
    label: String,
    count: Int,
    total: Int,
    color: Color,
    isDark: Boolean
) {
    val pct = if (total > 0) ((count.toFloat() / total) * 100).toInt() else 0
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Text(label, fontSize = 12.sp, color = if (isDark) Color.White else Color(0xFF334155))
        }
        Text(
            text = "$count ($pct%)",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = color
        )
    }
}

// ---------------- ATTENDANCE SEGMENTED BAR ----------------
@Composable
private fun AttendanceSegmentedBar(
    present: Int,
    late: Int,
    leave: Int,
    excused: Int,
    absent: Int,
    total: Int
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(14.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(Color(0xFFE2E8F0))
        ) {
            if (total > 0) {
                Row(modifier = Modifier.fillMaxSize()) {
                    if (present > 0) {
                        Box(
                            modifier = Modifier
                                .weight(present.toFloat())
                                .fillMaxHeight()
                                .background(Color(0xFF10B981))
                        )
                    }
                    if (late > 0) {
                        Box(
                            modifier = Modifier
                                .weight(late.toFloat())
                                .fillMaxHeight()
                                .background(Color(0xFFF59E0B))
                        )
                    }
                    if (leave > 0) {
                        Box(
                            modifier = Modifier
                                .weight(leave.toFloat())
                                .fillMaxHeight()
                                .background(Color(0xFF0284C7))
                        )
                    }
                    if (excused > 0) {
                        Box(
                            modifier = Modifier
                                .weight(excused.toFloat())
                                .fillMaxHeight()
                                .background(Color(0xFF8B5CF6))
                        )
                    }
                    if (absent > 0) {
                        Box(
                            modifier = Modifier
                                .weight(absent.toFloat())
                                .fillMaxHeight()
                                .background(Color(0xFFEF4444))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AttendanceBadgeChip(
    label: String,
    count: Int,
    total: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    val percentage = if (total > 0) ((count.toDouble() / total.toDouble()) * 100).toInt() else 0
    Surface(
        color = color.copy(alpha = 0.1f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.35f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Box(modifier = Modifier.size(5.dp).clip(CircleShape).background(color))
                Text(
                    text = label,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = color,
                    maxLines = 1,
                    softWrap = false
                )
            }
            Text(
                text = "$count",
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = "($percentage%)",
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Medium,
                color = color.copy(alpha = 0.85f)
            )
        }
    }
}

// ---------------- STUDENT ANALYTICS CARD ----------------
@Composable
private fun StudentAnalyticsCard(
    stat: StudentAttendanceStat,
    isDark: Boolean,
    isCourseCompleted: Boolean = false,
    onClick: () -> Unit
) {
    val statusColor = when (stat.student.status) {
        "توقيف قيد", "موقف" -> Color(0xFFF59E0B)
        "منسحب" -> Color(0xFFEF4444)
        else -> Color(0xFF10B981)
    }

    val rateColor = when {
        stat.attendanceRate >= 85 -> Color(0xFF10B981)
        stat.attendanceRate >= 70 -> Color(0xFFF59E0B)
        else -> Color(0xFFEF4444)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF1E293B) else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(
            1.dp,
            if (stat.hasWarning) Color(0xFFFCA5A5) else Color(0xFFE2E8F0)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Student Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = statusColor.copy(alpha = 0.15f),
                        shape = CircleShape,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = stat.student.name.take(1),
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                fontSize = 16.sp
                            )
                        }
                    }
                    Column {
                        Text(
                            text = stat.student.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = if (isDark) Color.White else Color(0xFF0F172A)
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                color = statusColor.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                val effectiveStatusDisplay = when {
                                    stat.student.status == "خريج" -> "خريج 🎓"
                                    isCourseCompleted && (stat.student.status.isBlank() || stat.student.status == "مستمر") -> "خريج 🎓"
                                    stat.student.status.isBlank() -> "مستمر"
                                    else -> stat.student.status
                                }
                                Text(
                                    text = effectiveStatusDisplay,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = statusColor,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "رمز الطالب: #${stat.student.id}",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }

                // Attendance Rate Badge
                Surface(
                    color = rateColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, rateColor.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = rateColor, modifier = Modifier.size(14.dp))
                        Text(
                            text = "${stat.attendanceRate}% انضباط",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = rateColor
                        )
                    }
                }
            }

            // Visual Segmented Bar for student
            AttendanceSegmentedBar(
                present = stat.presentCount,
                late = stat.lateCount,
                leave = stat.leaveCount,
                excused = stat.excusedCount,
                absent = stat.absentCount,
                total = stat.totalSessions
            )

            // Numbers Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🟢 حضور: ${stat.presentCount}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                Text("⏱️ تأخير: ${stat.lateCount} (${stat.totalDelayMinutes} د)", fontSize = 11.sp, color = Color(0xFFF59E0B))
                Text("🔵 استئذان: ${stat.leaveCount}", fontSize = 11.sp, color = Color(0xFF0284C7))
                Text("🟡 إجازة: ${stat.excusedCount}", fontSize = 11.sp, color = Color(0xFF8B5CF6))
                Text("🔴 غياب: ${stat.absentCount}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444))
            }

            if (stat.hasWarning) {
                Surface(
                    color = Color(0xFFFEF2F2),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp))
                        Text(
                            text = "تنبيه غياب مرتفع! (${stat.absentCount} يوم غياب - نسبة الحضور ${stat.attendanceRate}%)",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF991B1B)
                        )
                    }
                }
            }
        }
    }
}

// ---------------- STUDENT DETAIL MODAL DIALOG ----------------
@Composable
private fun StudentAttendanceDetailDialog(
    stat: StudentAttendanceStat,
    isDark: Boolean,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isDark) Color(0xFF1E293B) else Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = stat.student.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = if (isDark) Color.White else Color(0xFF0F172A)
                        )
                        Text(
                            text = "سجل الحضور التفصيلي للطالب",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = null)
                    }
                }

                HorizontalDivider(color = Color(0xFFE2E8F0))

                // Stats Summary Header Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MetricChipDetail("نسبة الانضباط", "${stat.attendanceRate}%", DawamiNavy, Modifier.weight(1f))
                    MetricChipDetail("أيام الحضور", "${stat.presentCount}", Color(0xFF10B981), Modifier.weight(1f))
                    MetricChipDetail("أيام الغياب", "${stat.absentCount}", Color(0xFFEF4444), Modifier.weight(1f))
                    MetricChipDetail("التأخيرات", "${stat.totalDelayMinutes}د", Color(0xFFF59E0B), Modifier.weight(1f))
                }

                Text(
                    text = "📋 السجلات اليومية الحالية (${stat.attendanceList.size} يوم):",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp,
                    color = if (isDark) Color.White else Color(0xFF1E293B)
                )

                // Timeline List
                if (stat.attendanceList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("لا توجد سجلات حضور مسجلة لهذا الطالب حتى الآن", fontSize = 12.sp, color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(stat.attendanceList) { att ->
                            AttendanceRecordDetailItem(att = att, isDark = isDark)
                        }
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("إغلاق التقرير التفصيلي 👍", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun MetricChipDetail(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = color.copy(alpha = 0.1f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f))
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 9.5.sp, color = Color(0xFF64748B), maxLines = 1)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = color)
        }
    }
}

@Composable
private fun AttendanceRecordDetailItem(att: StudentAttendance, isDark: Boolean) {
    val statusColor = when (att.status) {
        "حضور" -> Color(0xFF10B981)
        "تأخير" -> Color(0xFFF59E0B)
        "استئذان", "مستأذن" -> Color(0xFF0284C7)
        "إجازة" -> Color(0xFF8B5CF6)
        "غياب" -> Color(0xFFEF4444)
        else -> Color.Gray
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF0F172A) else Color(0xFFF1F5F9)),
        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.2f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "${att.dayOfWeek} (${att.date})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp,
                        color = if (isDark) Color.White else Color(0xFF0F172A)
                    )
                    if (att.subjectName.isNotBlank()) {
                        Surface(color = DawamiNavy.copy(alpha = 0.08f), shape = RoundedCornerShape(4.dp)) {
                            Text(
                                text = "🏷️ ${att.subjectName}",
                                fontSize = 9.sp,
                                color = DawamiNavy,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    if (att.checkInDelayMinutes > 0) {
                        Surface(color = Color(0xFFFEF3C7), shape = RoundedCornerShape(4.dp)) {
                            Text(
                                text = "تأخير ${att.checkInDelayMinutes} دقيقة",
                                fontSize = 9.sp,
                                color = Color(0xFFD97706),
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                val checkInText = if (att.actualCheckIn.isNotBlank()) "دخول: ${att.actualCheckIn}" else "بدون دخول"
                val checkOutText = if (att.actualCheckOut.isNotBlank()) "خروج: ${att.actualCheckOut}" else ""
                Text(
                    text = "$checkInText ${if (checkOutText.isNotBlank()) " | $checkOutText" else ""}",
                    fontSize = 10.sp,
                    color = Color(0xFF64748B)
                )
                if (att.studentNote.isNotBlank()) {
                    Text(
                        text = "ملاحظة: ${att.studentNote}",
                        fontSize = 9.5.sp,
                        color = DawamiNavy
                    )
                }
            }

            Surface(
                color = statusColor.copy(alpha = 0.15f),
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, statusColor.copy(alpha = 0.3f))
            ) {
                Text(
                    text = att.status,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = statusColor,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}
