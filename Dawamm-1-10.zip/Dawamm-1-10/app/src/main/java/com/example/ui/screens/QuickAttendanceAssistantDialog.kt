package com.example.ui.screens

import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.StudentAttendance
import com.example.ui.components.*
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.utils.AudioPlayerHelper
import kotlin.math.roundToInt

// ==========================================
// QUICK ATTENDANCE ASSISTANT MODULE
// ==========================================

enum class QuickAssistantMode {
    CheckIn,
    CheckOut
}

enum class AttendanceConfirmType {
    CHECK_IN,
    CHECK_OUT,
    ABSENT,
    EXCUSED,
    LEAVE
}

private fun calculateTimeDiffMinutes(timeA: String, timeB: String): Int? {
    try {
        val partsA = timeA.split(":").map { it.trim().toInt() }
        val partsB = timeB.split(":").map { it.trim().toInt() }
        if (partsA.size >= 2 && partsB.size >= 2) {
            val mA = partsA[0] * 60 + partsA[1]
            val mB = partsB[0] * 60 + partsB[1]
            return mA - mB
        }
    } catch (_: Exception) { }
    return null
}

private fun adjustTimeMinutes(timeStr: String, deltaMinutes: Int): String {
    try {
        val parts = timeStr.split(":").map { it.trim().toInt() }
        if (parts.size >= 2) {
            var totalMin = parts[0] * 60 + parts[1] + deltaMinutes
            if (totalMin < 0) totalMin += 24 * 60
            totalMin %= (24 * 60)
            val h = totalMin / 60
            val m = totalMin % 60
            return String.format(java.util.Locale.US, "%02d:%02d", h, m)
        }
    } catch (_: Exception) { }
    return timeStr
}

data class StudentUndoAction(
    val studentId: Int,
    val previousStatus: String,
    val previousCheckIn: String,
    val previousCheckOut: String,
    val previousRecord: com.example.data.entity.StudentAttendance,
    val wasNull: Boolean
)

data class TrainerUndoAction(
    val previousStatus: String,
    val previousCheckIn: String,
    val previousCheckOut: String,
    val previousRecord: com.example.data.entity.Attendance,
    val wasNull: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickAttendanceAssistantDialog(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val loggedInUser by viewModel.loggedInUser.collectAsState()
    val activeCourses by viewModel.activeCourses.collectAsState()
    val dbCourses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val selectedCourse by viewModel.selectedCourseForStudentAttendance.collectAsState()
    val studentAttendanceList by viewModel.studentAttendanceList.collectAsState()
    val dbAllStudentAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()
    val dbAttendance by (attendanceViewModel?.allAttendance ?: viewModel.dbAttendance).collectAsState()
    val allSubjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()
    val dbCourseSubjects by (courseViewModel?.allCourseSubjects ?: viewModel.dbCourseSubjects).collectAsState()
    val currentSubjectInput by viewModel.studentAttendanceSubjectInput.collectAsState()

    // Mode: CheckIn vs CheckOut
    var assistantMode by remember { mutableStateOf(QuickAssistantMode.CheckIn) }

    val dateFormat = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US) }
    val dayFormat = remember { java.text.SimpleDateFormat("EEEE", java.util.Locale("ar")) }
    var currentSelectedDateObj by remember { mutableStateOf(java.util.Date()) }

    val todayStr = remember(currentSelectedDateObj) { dateFormat.format(currentSelectedDateObj) }
    val dayNameAr = remember(currentSelectedDateObj) { dayFormat.format(currentSelectedDateObj) }
    val currentTime = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date()) }

    var isTopControlsExpanded by remember { mutableStateOf(false) }

    var isCourseDropdownExpanded by remember { mutableStateOf(false) }
    var isSubjectDropdownExpanded by remember { mutableStateOf(false) }
    var pendingCheckInAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    // Smart Prompts
    var showTrainerCheckoutPrompt by remember { mutableStateOf(false) }
    var trainerCheckoutTime by remember { mutableStateOf("") }
    var showAbsentSummaryDialog by remember { mutableStateOf(false) }
    var absentSummaryStudentsList by remember { mutableStateOf<List<String>>(emptyList()) }
    
    // Trainer Absent/Leave/Excused 4-option dialog
    var showTrainerAbsentLeaveDialog by remember { mutableStateOf(false) }
    var trainerActionType by remember { mutableStateOf("غياب") } // "غياب" or "إجازة" or "مستأذن"

    // Unrecorded students checkout dialog (Requirement 4)
    var showUnrecordedCheckoutDialog by remember { mutableStateOf(false) }
    var unrecordedCheckoutTime by remember { mutableStateOf("") }
    var unrecordedTargetStudents by remember { mutableStateOf<List<StudentAttendance>>(emptyList()) }
    
    // Time Confirmation & Feedback Dialog states
    var showTimeConfirmationDialog by remember { mutableStateOf(false) }
    var confirmActionType by remember { mutableStateOf(AttendanceConfirmType.CHECK_IN) }
    var confirmIsTrainerIncluded by remember { mutableStateOf(false) }
    var confirmTargetStudents by remember { mutableStateOf<List<StudentAttendance>>(emptyList()) }
    var confirmUnrecordedStudents by remember { mutableStateOf<List<StudentAttendance>>(emptyList()) }
    var confirmSelectedTime by remember { mutableStateOf("") }
    
    var lastCompletedCourseId by remember { mutableStateOf<Int?>(null) }
    var showCourseCompletedDialog by remember { mutableStateOf(false) }

    // Critical Action Confirmation States
    var showBulkClearConfirmDialog by remember { mutableStateOf(false) }
    var showBulkCancelCheckoutConfirmDialog by remember { mutableStateOf(false) }
    var studentToClearConfirm by remember { mutableStateOf<StudentAttendance?>(null) }
    var showTrainerUndoConfirmDialog by remember { mutableStateOf(false) }

    LaunchedEffect(todayStr) {
        viewModel.studentAttendanceDateInput.value = todayStr
        viewModel.attendanceDateInput.value = todayStr
        viewModel.studentAttendanceDayInput.value = dayNameAr
        viewModel.attendanceDayInput.value = dayNameAr
    }

    val showCompletedCourses by viewModel.showCompletedCoursesInDropdowns.collectAsState()

    // Filter courses: hide completed courses unless showCompletedCourses is true, and sort by startTime
    val eligibleCourses = remember(activeCourses, dbCourses, dbCourseSubjects, allSubjects, dbAttendance, dbAllStudentAttendance, showCompletedCourses) {
        val baseList = if (showCompletedCourses) dbCourses else activeCourses
        baseList
            .filter { course ->
                if (showCompletedCourses) return@filter true
                if (course.isCompleted) return@filter false
                val stats = viewModel.getCourseSubjectStats(
                    courseId = course.id,
                    courseSubjectsList = dbCourseSubjects,
                    attendanceList = dbAttendance,
                    studentAttendanceList = dbAllStudentAttendance,
                    subjectsList = allSubjects,
                    coursesList = dbCourses
                )
                val allCompleted = stats.isNotEmpty() && stats.all { it.status.contains("مكتمل") }
                !allCompleted
            }
            .sortedBy { it.startTime }
    }

    LaunchedEffect(eligibleCourses) {
        if (eligibleCourses.isNotEmpty()) {
            if (selectedCourse == null || eligibleCourses.none { it.id == selectedCourse?.id }) {
                viewModel.selectCourseForStudentAttendance(eligibleCourses.first())
            }
        }
    }

    // Resolve subjects for current course
    val courseCrossRefs = remember(selectedCourse, dbCourseSubjects) {
        if (selectedCourse != null) dbCourseSubjects.filter { it.courseId == selectedCourse!!.id } else emptyList()
    }
    val assignedSubjectIds = remember(courseCrossRefs) { courseCrossRefs.map { it.subjectId }.toSet() }
    val availableCourseSubjects = remember(selectedCourse, allSubjects, assignedSubjectIds) {
        if (selectedCourse == null) emptyList()
        else allSubjects.filter { sub ->
            sub.id in assignedSubjectIds ||
            (selectedCourse!!.diplomaName.isNotEmpty() && sub.diplomaName.equals(selectedCourse!!.diplomaName, ignoreCase = true))
        }.sortedWith(compareBy<com.example.data.entity.Subject> { com.example.data.entity.StudentGradeConfig.getSubjectRank(it.name) }.thenBy { it.name })
    }

    var courseSubjectStats by remember { mutableStateOf<List<com.example.data.entity.CourseSubjectStat>>(emptyList()) }
    LaunchedEffect(selectedCourse, dbAttendance, dbAllStudentAttendance, allSubjects, dbCourseSubjects, dbCourses) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            courseSubjectStats = if (selectedCourse != null) {
                viewModel.getCourseSubjectStats(
                    courseId = selectedCourse!!.id,
                    courseSubjectsList = dbCourseSubjects,
                    attendanceList = dbAttendance,
                    studentAttendanceList = dbAllStudentAttendance,
                    subjectsList = allSubjects,
                    coursesList = dbCourses
                )
            } else emptyList()
        }
    }

    var showAllSubjects by remember { mutableStateOf(false) }

    val remainingCourseSubjects = remember(availableCourseSubjects, courseSubjectStats) {
        val remaining = availableCourseSubjects.filter { sub ->
            val stat = courseSubjectStats.find { it.subjectId == sub.id || it.subjectName.trim().equals(sub.name.trim(), ignoreCase = true) }
            val isCompleted = stat?.status?.contains("مكتمل") == true
            !isCompleted
        }
        if (remaining.isEmpty()) availableCourseSubjects else remaining
    }

    val displayedSubjectsList = remember(showAllSubjects, availableCourseSubjects, remainingCourseSubjects) {
        if (showAllSubjects) availableCourseSubjects else remainingCourseSubjects
    }

    // Default subject according to teaching statistics
    val defaultSubjectFromStats = remember(selectedCourse, courseSubjectStats, availableCourseSubjects, remainingCourseSubjects) {
        if (selectedCourse == null) ""
        else {
            val sharedPrefs = context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
            val savedPrefSubject = sharedPrefs.getString("default_subject_of_${selectedCourse!!.id}", "") ?: ""
            val prefSubjectValid = availableCourseSubjects.find { it.name.trim().equals(savedPrefSubject.trim(), ignoreCase = true) }
            val prefStat = if (prefSubjectValid != null) courseSubjectStats.find { it.subjectId == prefSubjectValid.id || it.subjectName.trim().equals(prefSubjectValid.name.trim(), ignoreCase = true) } else null
            val isPrefStillActive = prefSubjectValid != null && (prefStat == null || !prefStat.status.contains("مكتمل"))

            if (isPrefStillActive) {
                savedPrefSubject
            } else {
                val inProgressStat = courseSubjectStats.firstOrNull {
                    it.status.contains("قيد التدريس") || (it.taughtDaysCount > 0 && !it.status.contains("مكتمل") && !it.status.contains("منتهية"))
                }
                val notStartedStat = courseSubjectStats.firstOrNull {
                    !it.status.contains("مكتمل") && !it.status.contains("منتهية")
                }
                inProgressStat?.subjectName?.takeIf { it.isNotBlank() }
                    ?: notStartedStat?.subjectName?.takeIf { it.isNotBlank() }
                    ?: remainingCourseSubjects.firstOrNull()?.name
                    ?: availableCourseSubjects.firstOrNull()?.name
                    ?: selectedCourse?.diplomaName?.takeIf { it.isNotBlank() }
                    ?: selectedCourse?.name
                    ?: "عام"
            }
        }
    }

    // Auto-initialize subject according to teaching statistics
    LaunchedEffect(selectedCourse?.id, defaultSubjectFromStats) {
        if (selectedCourse != null && defaultSubjectFromStats.isNotBlank()) {
            val isCurrentSubjectValidForCourse = availableCourseSubjects.any { it.name.trim().equals(currentSubjectInput.trim(), ignoreCase = true) }
            if (currentSubjectInput.isBlank() || !isCurrentSubjectValidForCourse) {
                viewModel.updateStudentAttendanceSubject(defaultSubjectFromStats)
            }
        }
    }

    val trainerRecord = remember(dbAttendance, selectedCourse, todayStr) {
        dbAttendance.find { it.courseId == selectedCourse?.id && it.date == todayStr }
    }

    val isCourseEndedForDate = remember(selectedCourse, todayStr) {
        if (selectedCourse == null) false
        else {
            val isPastEndDate = selectedCourse?.endDate?.isNotBlank() == true && todayStr > selectedCourse!!.endDate
            val isCompletedAndPastOrSame = selectedCourse?.isCompleted == true && (selectedCourse?.endDate.isNullOrBlank() || todayStr >= selectedCourse!!.endDate)
            isPastEndDate || isCompletedAndPastOrSame
        }
    }

    // Stabilize cards: sort alphabetically
    val sortedStudents = remember(studentAttendanceList) {
        studentAttendanceList.sortedBy { it.studentName }
    }

    // Multi-Selection State for Trainer and Students
    var isTrainerSelected by remember { mutableStateOf(false) }
    val selectedStudentMap = remember { mutableStateMapOf<Int, Boolean>() }
    val selectedStudentCount = selectedStudentMap.count { it.value }
    val selectedItemCount = (if (isTrainerSelected) 1 else 0) + selectedStudentCount
    val totalItemCount = 1 + sortedStudents.size
    val isAllSelected = totalItemCount > 0 && selectedItemCount == totalItemCount

    LaunchedEffect(selectedCourse?.id) {
        isTrainerSelected = false
        selectedStudentMap.clear()
    }

    val toggleSelectAll: () -> Unit = {
        if (isAllSelected) {
            isTrainerSelected = false
            selectedStudentMap.clear()
        } else {
            isTrainerSelected = true
            sortedStudents.forEach { selectedStudentMap[it.studentId] = true }
        }
    }

    // Next course detection based on eligible courses order
    val nextCourse = remember(selectedCourse, eligibleCourses) {
        if (selectedCourse == null || eligibleCourses.isEmpty()) null
        else {
            val currentIndex = eligibleCourses.indexOfFirst { it.id == selectedCourse!!.id }
            if (currentIndex in 0 until eligibleCourses.size - 1) eligibleCourses[currentIndex + 1] else null
        }
    }

    // Course completion check
    val isCourseFullyCompleted = remember(sortedStudents, trainerRecord) {
        if (sortedStudents.isEmpty()) false
        else {
            val uncompletedStudents = sortedStudents.count { it.status == "لم يسجل" || (it.status == "حضور" && it.actualCheckOut.isEmpty()) }
            val trainerDone = trainerRecord != null && (trainerRecord.status != "حضور" || trainerRecord.actualCheckOut.isNotEmpty())
            uncompletedStudents == 0 && trainerDone
        }
    }

    LaunchedEffect(isCourseFullyCompleted, selectedCourse?.id) {
        if (isCourseFullyCompleted && selectedCourse != null && lastCompletedCourseId != selectedCourse!!.id) {
            lastCompletedCourseId = selectedCourse!!.id
            showCourseCompletedDialog = true
        }
    }

    // Daily Note Sync
    val noteState by viewModel.attendanceNoteInput.collectAsState()
    var noteText by remember { mutableStateOf(noteState) }

    LaunchedEffect(noteState) {
        if (noteText != noteState) noteText = noteState
    }

    LaunchedEffect(noteText) {
        kotlinx.coroutines.delay(500)
        if (noteText != viewModel.attendanceNoteInput.value) {
            viewModel.attendanceNoteInput.value = noteText
            viewModel.addOrUpdateAttendanceTemp()
        }
    }

    val displayedSubject = currentSubjectInput.ifEmpty {
        defaultSubjectFromStats.ifEmpty { "عام" }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = onDismiss,
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("مساعد الرصد السريع", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("⚡", fontSize = 11.sp)
                                }
                                // Unified single row for Course and Subject selectors
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(top = 1.dp)
                                ) {
                                    // 1. Course Selector Chip
                                    Box {
                                        Surface(
                                            onClick = { isCourseDropdownExpanded = true },
                                            shape = RoundedCornerShape(6.dp),
                                            color = DawamiNavy.copy(alpha = 0.08f)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                Text(
                                                    text = "الدورة: ${selectedCourse?.name ?: "اختر الدورة"}",
                                                    fontSize = 8.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = DawamiNavy,
                                                    maxLines = 1
                                                )
                                                Icon(
                                                    Icons.Default.ArrowDropDown,
                                                    contentDescription = null,
                                                    tint = DawamiNavy,
                                                    modifier = Modifier.size(13.dp)
                                                )
                                            }
                                        }
                                        DropdownMenu(
                                            expanded = isCourseDropdownExpanded,
                                            onDismissRequest = { isCourseDropdownExpanded = false },
                                            modifier = Modifier.background(MaterialTheme.colorScheme.surface)
                                        ) {
                                            DropdownMenuItem(
                                                text = {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                                        )
                                                        Icon(
                                                            imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                            contentDescription = null,
                                                            tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                                            modifier = Modifier.size(15.dp)
                                                        )
                                                    }
                                                },
                                                onClick = {
                                                    viewModel.toggleShowCompletedCoursesInDropdowns()
                                                }
                                            )
                                            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                                            eligibleCourses.forEach { course ->
                                                DropdownMenuItem(
                                                    text = {
                                                        Text(
                                                            text = if (course.isCompleted) "${course.name} (منتهية 🔒)" else course.name,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (course.isCompleted) Color.Gray else DawamiNavy
                                                        )
                                                    },
                                                    onClick = {
                                                        viewModel.selectCourseForStudentAttendance(course)
                                                        isCourseDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // 2. Subject Selector Chip
                                    Surface(
                                        onClick = {
                                            if (availableCourseSubjects.isNotEmpty()) {
                                                pendingCheckInAction = null
                                                isSubjectDropdownExpanded = true
                                            }
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        color = DawamiTeal.copy(alpha = 0.12f)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            Text(
                                                text = "المادة: $displayedSubject",
                                                fontSize = 8.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = DawamiTeal,
                                                maxLines = 1
                                            )
                                            if (availableCourseSubjects.isNotEmpty()) {
                                                Icon(
                                                    Icons.Default.ArrowDropDown,
                                                    contentDescription = null,
                                                    tint = DawamiTeal,
                                                    modifier = Modifier.size(13.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            titleContentColor = DawamiNavy
                        ),
                        actions = {}
                    )
                }
            ) { padding ->
                if (selectedCourse == null) {
                    Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                        Text("الرجاء اختيار دورة تدريبية لبدء الرصد السريع", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .background(if (viewModel.isDarkTheme.collectAsState().value) Color(0xFF0F172A) else Color(0xFFF8FAFC))
                    ) {
                        // --- Fixed Top Control Area ---
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shadowElevation = 2.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                                // --- Date Navigation Bar ---
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    val isToday = dateFormat.format(currentSelectedDateObj) == dateFormat.format(java.util.Date())

                                    // Previous Day Button
                                    IconButton(
                                        onClick = {
                                            val cal = java.util.Calendar.getInstance().apply { time = currentSelectedDateObj; add(java.util.Calendar.DAY_OF_YEAR, -1) }
                                            currentSelectedDateObj = cal.time
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.KeyboardArrowRight, contentDescription = "اليوم السابق", tint = DawamiNavy)
                                    }

                                    // Date Display
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.DateRange, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        val displayFormat = java.text.SimpleDateFormat("EEEE، d MMMM", java.util.Locale("ar"))
                                        Text(
                                            text = displayFormat.format(currentSelectedDateObj),
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy,
                                            fontSize = 12.sp
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (!isToday) {
                                            IconButton(
                                                onClick = { currentSelectedDateObj = java.util.Date() },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Home, contentDescription = "اليوم الحالي", tint = DawamiTeal)
                                            }
                                        }

                                        // Next Day Button
                                        IconButton(
                                            onClick = {
                                                val cal = java.util.Calendar.getInstance().apply { time = currentSelectedDateObj; add(java.util.Calendar.DAY_OF_YEAR, 1) }
                                                currentSelectedDateObj = cal.time
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "اليوم التالي", tint = DawamiNavy)
                                        }
                                    }
                                }

                                // Toggle Button for top controls
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { isTopControlsExpanded = !isTopControlsExpanded }
                                        .background(if (viewModel.isDarkTheme.collectAsState().value) Color(0xFF1E293B) else Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = if (isTopControlsExpanded) "إخفاء التفاصيل وأدوات التحضير" else "إظهار التفاصيل وأدوات التحضير",
                                        fontSize = 10.sp,
                                        color = DawamiNavy,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Icon(
                                        imageVector = if (isTopControlsExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Toggle Header",
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                AnimatedVisibility(visible = isTopControlsExpanded) {
                                    Column {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        // Mode Selector: Radio Button Style Toggle
                                        Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                        .padding(3.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    // Check-in Mode
                                    Surface(
                                        onClick = { assistantMode = QuickAssistantMode.CheckIn },
                                        modifier = Modifier.weight(1f).height(36.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (assistantMode == QuickAssistantMode.CheckIn) Color(0xFF16A34A) else Color.Transparent
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxSize(),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected = assistantMode == QuickAssistantMode.CheckIn,
                                                onClick = { assistantMode = QuickAssistantMode.CheckIn },
                                                colors = RadioButtonDefaults.colors(
                                                    selectedColor = Color.White,
                                                    unselectedColor = MaterialTheme.colorScheme.onSurfaceVariant
                                                ),
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "🟢 وضع رصد الحضور",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (assistantMode == QuickAssistantMode.CheckIn) Color.White else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }

                                    // Check-out Mode
                                    Surface(
                                        onClick = { assistantMode = QuickAssistantMode.CheckOut },
                                        modifier = Modifier.weight(1f).height(36.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (assistantMode == QuickAssistantMode.CheckOut) Color(0xFF0284C7) else Color.Transparent
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxSize(),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected = assistantMode == QuickAssistantMode.CheckOut,
                                                onClick = { assistantMode = QuickAssistantMode.CheckOut },
                                                colors = RadioButtonDefaults.colors(
                                                    selectedColor = Color.White,
                                                    unselectedColor = MaterialTheme.colorScheme.onSurfaceVariant
                                                ),
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "📤 وضع رصد الانصراف",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (assistantMode == QuickAssistantMode.CheckOut) Color.White else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                // Stats Bar
                                val countPresent = sortedStudents.count { it.status == "حضور" }
                                val countAbsent = sortedStudents.count { it.status == "غياب" }
                                val countExcused = sortedStudents.count { it.status == "مستأذن" }
                                val countLeave = sortedStudents.count { it.status == "إجازة" }
                                val countWait = sortedStudents.count { it.status == "لم يسجل" }
                                
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    StatItem("حاضر", countPresent, Color(0xFF16A34A))
                                    StatItem("غائب", countAbsent, Color(0xFFDC2626))
                                    StatItem("مستأذن", countExcused, Color(0xFF0284C7))
                                    StatItem("إجازة", countLeave, Color(0xFFD97706))
                                    StatItem("بانتظار", countWait, Color.Gray)
                                }
                                
                                Spacer(modifier = Modifier.height(3.dp))
                                
                                // Daily Note
                                OutlinedTextField(
                                    value = noteText,
                                    onValueChange = { noteText = it },
                                    label = { Text("ملاحظة التحضير اليومية", fontSize = 9.sp) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp),
                                    textStyle = TextStyle(fontSize = 10.5.sp),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
                                    )
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                if (!isCourseEndedForDate) {
                                    // --- Multi-Selection & Reset Bar ---
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                    Surface(
                                        onClick = toggleSelectAll,
                                        shape = RoundedCornerShape(8.dp),
                                        color = DawamiNavy.copy(alpha = 0.08f),
                                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.25f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Checkbox(
                                                checked = isAllSelected,
                                                onCheckedChange = { toggleSelectAll() },
                                                modifier = Modifier.size(20.dp),
                                                colors = CheckboxDefaults.colors(checkedColor = DawamiNavy)
                                            )
                                            Spacer(modifier = Modifier.width(5.dp))
                                            Text(
                                                text = "تحديد الكل / إلغاء التحديد ($selectedItemCount)",
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = DawamiNavy
                                            )
                                        }
                                    }

                                    // Reset / Clear attendance button
                                    Surface(
                                        onClick = {
                                            if (selectedItemCount == 0) {
                                                Toast.makeText(context, "الرجاء تحديد الطلاب أو المدرب أولاً! ⚠️", Toast.LENGTH_SHORT).show()
                                                return@Surface
                                            }
                                            showBulkClearConfirmDialog = true
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFF1F5F9),
                                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "مسح السجل 🔄",
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF475569)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                // Quick Bulk Action Buttons depending on mode
                                if (assistantMode == QuickAssistantMode.CheckIn) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        // 1. Check-in Now
                                        Surface(
                                            onClick = {
                                                if (selectedItemCount == 0) {
                                                    Toast.makeText(context, "الرجاء تحديد الطلاب أو المدرب لتسجيل الحضور ⚠️", Toast.LENGTH_SHORT).show()
                                                    return@Surface
                                                }
                                                val targetStudents = sortedStudents.filter { selectedStudentMap[it.studentId] == true }
                                                val unrecStudents = targetStudents.filter { it.status == "لم يسجل" || it.status.isEmpty() }
                                                val tStatus = trainerRecord?.status ?: "لم يسجل"
                                                val isTrainerEligible = isTrainerSelected && tStatus == "لم يسجل"

                                                if (isTrainerSelected && tStatus != "لم يسجل") {
                                                    Toast.makeText(context, "المدرب لديه حركة مسجلة مسبقاً ($tStatus)! يجب إعادة تعيين حالة المدرب أولاً ⚠️", Toast.LENGTH_SHORT).show()
                                                }

                                                if (unrecStudents.isEmpty() && !isTrainerEligible) {
                                                    if (!isTrainerSelected) {
                                                        Toast.makeText(context, "الطلاب المحددون لديهم حركات مسجلة مسبقاً! يجب إعادة التعيين (المسح) أولاً لتغيير حالتهم ⚠️", Toast.LENGTH_SHORT).show()
                                                    }
                                                    return@Surface
                                                }

                                                if (isTrainerEligible) {
                                                    pendingCheckInAction = {
                                                        confirmActionType = AttendanceConfirmType.CHECK_IN
                                                        confirmSelectedTime = currentTime
                                                        confirmTargetStudents = unrecStudents
                                                        confirmIsTrainerIncluded = true
                                                        showTimeConfirmationDialog = true
                                                    }
                                                    isSubjectDropdownExpanded = true
                                                } else {
                                                    confirmActionType = AttendanceConfirmType.CHECK_IN
                                                    confirmSelectedTime = currentTime
                                                    confirmTargetStudents = unrecStudents
                                                    confirmIsTrainerIncluded = false
                                                    showTimeConfirmationDialog = true
                                                }
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFF16A34A),
                                            shadowElevation = 1.dp,
                                            modifier = Modifier.weight(1.1f).height(34.dp)
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp), contentAlignment = Alignment.Center) {
                                                Text("حضور الآن ⚡", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center, maxLines = 1)
                                            }
                                        }

                                        // 2. Check-in Scheduled
                                        Surface(
                                            onClick = {
                                                if (selectedItemCount == 0) {
                                                    Toast.makeText(context, "الرجاء تحديد الطلاب أو المدرب لتسجيل الحضور ⚠️", Toast.LENGTH_SHORT).show()
                                                    return@Surface
                                                }
                                                val schedStart = selectedCourse?.startTime ?: currentTime
                                                val targetStudents = sortedStudents.filter { selectedStudentMap[it.studentId] == true }
                                                val unrecStudents = targetStudents.filter { it.status == "لم يسجل" || it.status.isEmpty() }
                                                val tStatus = trainerRecord?.status ?: "لم يسجل"
                                                val isTrainerEligible = isTrainerSelected && tStatus == "لم يسجل"

                                                if (isTrainerSelected && tStatus != "لم يسجل") {
                                                    Toast.makeText(context, "المدرب لديه حركة مسجلة مسبقاً ($tStatus)! يجب إعادة تعيين حالة المدرب أولاً ⚠️", Toast.LENGTH_SHORT).show()
                                                }

                                                if (unrecStudents.isEmpty() && !isTrainerEligible) {
                                                    if (!isTrainerSelected) {
                                                        Toast.makeText(context, "الطلاب المحددون لديهم حركات مسجلة مسبقاً! يجب إعادة التعيين (المسح) أولاً لتغيير حالتهم ⚠️", Toast.LENGTH_SHORT).show()
                                                    }
                                                    return@Surface
                                                }

                                                if (isTrainerEligible) {
                                                    pendingCheckInAction = {
                                                        confirmActionType = AttendanceConfirmType.CHECK_IN
                                                        confirmSelectedTime = schedStart
                                                        confirmTargetStudents = unrecStudents
                                                        confirmIsTrainerIncluded = true
                                                        showTimeConfirmationDialog = true
                                                    }
                                                    isSubjectDropdownExpanded = true
                                                } else {
                                                    confirmActionType = AttendanceConfirmType.CHECK_IN
                                                    confirmSelectedTime = schedStart
                                                    confirmTargetStudents = unrecStudents
                                                    confirmIsTrainerIncluded = false
                                                    showTimeConfirmationDialog = true
                                                }
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFF0D9488),
                                            shadowElevation = 1.dp,
                                            modifier = Modifier.weight(1.1f).height(34.dp)
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp), contentAlignment = Alignment.Center) {
                                                Text("حضور الدورة 📥", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center, maxLines = 1)
                                            }
                                        }

                                        // 3. Absent
                                        Surface(
                                            onClick = {
                                                if (selectedItemCount == 0) {
                                                    Toast.makeText(context, "الرجاء تحديد الطلاب أو المدرب لتسجيل الغياب ⚠️", Toast.LENGTH_SHORT).show()
                                                    return@Surface
                                                }
                                                val targetStudents = sortedStudents.filter { selectedStudentMap[it.studentId] == true }
                                                val unrecStudents = targetStudents.filter { it.status == "لم يسجل" || it.status.isEmpty() }
                                                val tStatus = trainerRecord?.status ?: "لم يسجل"
                                                val isTrainerEligible = isTrainerSelected && tStatus == "لم يسجل"

                                                if (isTrainerSelected && tStatus != "لم يسجل") {
                                                    Toast.makeText(context, "المدرب لديه حركة مسجلة مسبقاً ($tStatus)! يجب إعادة تعيين حالة المدرب أولاً ⚠️", Toast.LENGTH_SHORT).show()
                                                }

                                                if (unrecStudents.isEmpty() && !isTrainerEligible) {
                                                    if (!isTrainerSelected) {
                                                        Toast.makeText(context, "الطلاب المحددون لديهم حركات مسجلة مسبقاً! يجب إعادة التعيين (المسح) أولاً لتغيير حالتهم ⚠️", Toast.LENGTH_SHORT).show()
                                                    }
                                                    return@Surface
                                                }

                                                confirmActionType = AttendanceConfirmType.ABSENT
                                                confirmSelectedTime = currentTime
                                                confirmTargetStudents = unrecStudents
                                                confirmIsTrainerIncluded = isTrainerEligible
                                                showTimeConfirmationDialog = true
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFFDC2626),
                                            shadowElevation = 1.dp,
                                            modifier = Modifier.weight(0.9f).height(34.dp)
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp), contentAlignment = Alignment.Center) {
                                                Text("غياب ❌", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center, maxLines = 1)
                                            }
                                        }

                                        // 4. Excused
                                        Surface(
                                            onClick = {
                                                if (selectedItemCount == 0) {
                                                    Toast.makeText(context, "الرجاء تحديد الطلاب أو المدرب لرصد الاستئذان ⚠️", Toast.LENGTH_SHORT).show()
                                                    return@Surface
                                                }
                                                val targetStudents = sortedStudents.filter { selectedStudentMap[it.studentId] == true }
                                                val unrecStudents = targetStudents.filter { it.status == "لم يسجل" || it.status.isEmpty() }
                                                val tStatus = trainerRecord?.status ?: "لم يسجل"
                                                val isTrainerEligible = isTrainerSelected && tStatus == "لم يسجل"

                                                if (isTrainerSelected && tStatus != "لم يسجل") {
                                                    Toast.makeText(context, "المدرب لديه حركة مسجلة مسبقاً ($tStatus)! يجب إعادة تعيين حالة المدرب أولاً ⚠️", Toast.LENGTH_SHORT).show()
                                                }

                                                if (unrecStudents.isEmpty() && !isTrainerEligible) {
                                                    if (!isTrainerSelected) {
                                                        Toast.makeText(context, "الطلاب المحددون لديهم حركات مسجلة مسبقاً! يجب إعادة التعيين (المسح) أولاً لتغيير حالتهم ⚠️", Toast.LENGTH_SHORT).show()
                                                    }
                                                    return@Surface
                                                }

                                                confirmActionType = AttendanceConfirmType.EXCUSED
                                                confirmSelectedTime = currentTime
                                                confirmTargetStudents = unrecStudents
                                                confirmIsTrainerIncluded = isTrainerEligible
                                                showTimeConfirmationDialog = true
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFF0284C7),
                                            shadowElevation = 1.dp,
                                            modifier = Modifier.weight(0.9f).height(34.dp)
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp), contentAlignment = Alignment.Center) {
                                                Text("مستأذن 🔵", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center, maxLines = 1)
                                            }
                                        }

                                        // 5. Leave
                                        Surface(
                                            onClick = {
                                                if (selectedItemCount == 0) {
                                                    Toast.makeText(context, "الرجاء تحديد الطلاب أو المدرب لرصد الإجازة ⚠️", Toast.LENGTH_SHORT).show()
                                                    return@Surface
                                                }
                                                val targetStudents = sortedStudents.filter { selectedStudentMap[it.studentId] == true }
                                                val unrecStudents = targetStudents.filter { it.status == "لم يسجل" || it.status.isEmpty() }
                                                val tStatus = trainerRecord?.status ?: "لم يسجل"
                                                val isTrainerEligible = isTrainerSelected && tStatus == "لم يسجل"

                                                if (isTrainerSelected && tStatus != "لم يسجل") {
                                                    Toast.makeText(context, "المدرب لديه حركة مسجلة مسبقاً ($tStatus)! يجب إعادة تعيين حالة المدرب أولاً ⚠️", Toast.LENGTH_SHORT).show()
                                                }

                                                if (unrecStudents.isEmpty() && !isTrainerEligible) {
                                                    if (!isTrainerSelected) {
                                                        Toast.makeText(context, "الطلاب المحددون لديهم حركات مسجلة مسبقاً! يجب إعادة التعيين (المسح) أولاً لتغيير حالتهم ⚠️", Toast.LENGTH_SHORT).show()
                                                    }
                                                    return@Surface
                                                }

                                                confirmActionType = AttendanceConfirmType.LEAVE
                                                confirmSelectedTime = currentTime
                                                confirmTargetStudents = unrecStudents
                                                confirmIsTrainerIncluded = isTrainerEligible
                                                showTimeConfirmationDialog = true
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFFD97706),
                                            shadowElevation = 1.dp,
                                            modifier = Modifier.weight(0.9f).height(34.dp)
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp), contentAlignment = Alignment.Center) {
                                                Text("إجازة 🟡", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center, maxLines = 1)
                                            }
                                        }
                                    }
                                } else {
                                    // Check-Out Actions
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        // 1. Check-out Now
                                        Surface(
                                            onClick = {
                                                if (selectedItemCount == 0) {
                                                    Toast.makeText(context, "الرجاء تحديد الطلاب أو المدرب لتسجيل الانصراف ⚠️", Toast.LENGTH_SHORT).show()
                                                    return@Surface
                                                }
                                                val targetStudents = sortedStudents.filter { selectedStudentMap[it.studentId] == true }
                                                val attendedStudents = targetStudents.filter { it.status == "حضور" && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() }
                                                val unrecStudents = targetStudents.filter { it.status == "لم يسجل" || it.status.isEmpty() }
                                                val alreadyOutStudents = targetStudents.filter { it.status == "حضور" && it.actualCheckOut.isNotEmpty() }
                                                val tStatus = trainerRecord?.status ?: "لم يسجل"
                                                val tCheckIn = trainerRecord?.actualCheckIn ?: ""
                                                val tCheckOut = trainerRecord?.actualCheckOut ?: ""
                                                val isTrainerEligible = isTrainerSelected && (tStatus == "حضور" && tCheckIn.isNotEmpty() && tCheckOut.isEmpty())

                                                if (isTrainerSelected && !isTrainerEligible) {
                                                    if (tStatus != "حضور" || tCheckIn.isEmpty()) {
                                                        Toast.makeText(context, "لا يمكن تسجيل انصراف للمدرب لأنه غير مسجل حضور اليوم! ⚠️", Toast.LENGTH_SHORT).show()
                                                    } else if (tCheckOut.isNotEmpty()) {
                                                        Toast.makeText(context, "المدرب مسجل له انصراف مسبقاً! قم بإلغاء الانصراف أولاً ⚠️", Toast.LENGTH_SHORT).show()
                                                    }
                                                }

                                                if (attendedStudents.isEmpty() && unrecStudents.isEmpty() && !isTrainerEligible) {
                                                    if (alreadyOutStudents.isNotEmpty()) {
                                                        Toast.makeText(context, "الطلاب المحددون مسجل لهم انصراف بالفعل! ⚠️", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        Toast.makeText(context, "الطلاب المحددون غير مسجلين حضور لتسجيل انصرافهم! ⚠️", Toast.LENGTH_SHORT).show()
                                                    }
                                                    return@Surface
                                                }

                                                confirmActionType = AttendanceConfirmType.CHECK_OUT
                                                confirmSelectedTime = currentTime
                                                confirmTargetStudents = attendedStudents
                                                confirmUnrecordedStudents = unrecStudents
                                                confirmIsTrainerIncluded = isTrainerEligible
                                                showTimeConfirmationDialog = true
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFF0284C7),
                                            shadowElevation = 1.dp,
                                            modifier = Modifier.weight(1f).height(34.dp)
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp), contentAlignment = Alignment.Center) {
                                                Text("انصراف الآن ⚡", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center, maxLines = 1)
                                            }
                                        }

                                        // 2. Check-out Scheduled
                                        Surface(
                                            onClick = {
                                                if (selectedItemCount == 0) {
                                                    Toast.makeText(context, "الرجاء تحديد الطلاب أو المدرب لتسجيل الانصراف ⚠️", Toast.LENGTH_SHORT).show()
                                                    return@Surface
                                                }
                                                val schedEnd = selectedCourse?.endTime ?: currentTime
                                                val targetStudents = sortedStudents.filter { selectedStudentMap[it.studentId] == true }
                                                val attendedStudents = targetStudents.filter { it.status == "حضور" && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() }
                                                val unrecStudents = targetStudents.filter { it.status == "لم يسجل" || it.status.isEmpty() }
                                                val alreadyOutStudents = targetStudents.filter { it.status == "حضور" && it.actualCheckOut.isNotEmpty() }
                                                val tStatus = trainerRecord?.status ?: "لم يسجل"
                                                val tCheckIn = trainerRecord?.actualCheckIn ?: ""
                                                val tCheckOut = trainerRecord?.actualCheckOut ?: ""
                                                val isTrainerEligible = isTrainerSelected && (tStatus == "حضور" && tCheckIn.isNotEmpty() && tCheckOut.isEmpty())

                                                if (isTrainerSelected && !isTrainerEligible) {
                                                    if (tStatus != "حضور" || tCheckIn.isEmpty()) {
                                                        Toast.makeText(context, "لا يمكن تسجيل انصراف للمدرب لأنه غير مسجل حضور اليوم! ⚠️", Toast.LENGTH_SHORT).show()
                                                    } else if (tCheckOut.isNotEmpty()) {
                                                        Toast.makeText(context, "المدرب مسجل له انصراف مسبقاً! قم بإلغاء الانصراف أولاً ⚠️", Toast.LENGTH_SHORT).show()
                                                    }
                                                }

                                                if (attendedStudents.isEmpty() && unrecStudents.isEmpty() && !isTrainerEligible) {
                                                    if (alreadyOutStudents.isNotEmpty()) {
                                                        Toast.makeText(context, "الطلاب المحددون مسجل لهم انصراف بالفعل! ⚠️", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        Toast.makeText(context, "الطلاب المحددون غير مسجلين حضور لتسجيل انصرافهم! ⚠️", Toast.LENGTH_SHORT).show()
                                                    }
                                                    return@Surface
                                                }

                                                confirmActionType = AttendanceConfirmType.CHECK_OUT
                                                confirmSelectedTime = schedEnd
                                                confirmTargetStudents = attendedStudents
                                                confirmUnrecordedStudents = unrecStudents
                                                confirmIsTrainerIncluded = isTrainerEligible
                                                showTimeConfirmationDialog = true
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = DawamiNavy,
                                            shadowElevation = 1.dp,
                                            modifier = Modifier.weight(1f).height(34.dp)
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp), contentAlignment = Alignment.Center) {
                                                Text("انصراف الدورة 📤", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center, maxLines = 1)
                                            }
                                        }

                                        // 3. Cancel Check-Out
                                        Surface(
                                            onClick = {
                                                if (selectedItemCount == 0) {
                                                    Toast.makeText(context, "الرجاء تحديد الطلاب أو المدرب لإلغاء الانصراف ⚠️", Toast.LENGTH_SHORT).show()
                                                    return@Surface
                                                }
                                                val targetStudents = sortedStudents.filter { selectedStudentMap[it.studentId] == true }
                                                val checkedOutStudents = targetStudents.filter { it.actualCheckOut.isNotEmpty() }
                                                val isTrainerCheckedOut = isTrainerSelected && trainerRecord != null && trainerRecord.actualCheckOut.isNotEmpty()
                                                if (checkedOutStudents.isEmpty() && !isTrainerCheckedOut) {
                                                    Toast.makeText(context, "لا يوجد عناصر مسجل لها انصراف بين المحددين! ⚠️", Toast.LENGTH_SHORT).show()
                                                    return@Surface
                                                }
                                                showBulkCancelCheckoutConfirmDialog = true
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFF64748B),
                                            shadowElevation = 1.dp,
                                            modifier = Modifier.weight(1f).height(34.dp)
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp), contentAlignment = Alignment.Center) {
                                                Text("إلغاء الانصراف ↩️", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center, maxLines = 1)
                                            }
                                        }
                                    }
                                }
                                    }
                                }
                            }
                        }
                        }

                        // --- Scrollable Area (Wide horizontal safe margins for smooth scrolling) ---
                        val studentPairs = remember(sortedStudents) { sortedStudents.chunked(2) }
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(top = 6.dp, bottom = 24.dp)
                        ) {
                            if (isCourseEndedForDate) {
                                item {
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 16.dp),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                        border = BorderStroke(1.2.dp, Color(0xFF94A3B8).copy(alpha = 0.8f))
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(20.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(50.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(0xFFE2E8F0)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Lock,
                                                    contentDescription = null,
                                                    tint = Color(0xFF475569),
                                                    modifier = Modifier.size(28.dp)
                                                )
                                            }
                                            Text(
                                                text = "دورة منتهية رسمياً 🔒",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF1E293B)
                                            )
                                            val endDateDisplay = selectedCourse?.endDate?.ifBlank { "تاريخ سابق" } ?: "تاريخ سابق"
                                            Text(
                                                text = "هذه الدورة (${selectedCourse?.name ?: ""}) منتهية رسمياً بتاريخ ($endDateDisplay).\n\n" +
                                                        "📌 ملاحظة:\n" +
                                                        "تم إيقاف ظهور بطاقات الطلاب والرصد السريع لهذه الدورة بعد تاريخ الانتهاء.\n" +
                                                        "إذا كنت ترغب في مراجعة وأرشفة سجلات الطلاب، يرجى التوجه إلى شاشة تحضير الطلاب والتنقل في التواريخ السابقة للدورة.",
                                                fontSize = 11.5.sp,
                                                color = Color(0xFF475569),
                                                textAlign = TextAlign.Center,
                                                lineHeight = 18.sp
                                            )
                                        }
                                    }
                                }
                            } else {
                            // 1. Trainer Card (Fixed at top, full-width with Checkbox)
                            item {
                                val tStatus = trainerRecord?.status ?: "لم يسجل"
                                val tCheckIn = trainerRecord?.actualCheckIn ?: ""
                                val tCheckOut = trainerRecord?.actualCheckOut ?: ""
                                val isTExam = trainerRecord?.isExamDay == true

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 4.dp)
                                        .clickable { isTrainerSelected = !isTrainerSelected },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isTrainerSelected) DawamiNavy.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                                    ),
                                    border = BorderStroke(
                                        if (isTrainerSelected) 1.5.dp else 1.dp,
                                        if (isTrainerSelected) DawamiNavy else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                    ),
                                    elevation = CardDefaults.cardElevation(if (isTrainerSelected) 2.dp else 0.5.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Checkbox(
                                                checked = isTrainerSelected,
                                                onCheckedChange = { isTrainerSelected = it },
                                                modifier = Modifier.size(24.dp),
                                                colors = CheckboxDefaults.colors(checkedColor = DawamiNavy)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .size(28.dp)
                                                    .clip(CircleShape)
                                                    .background(DawamiNavy.copy(alpha = 0.12f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.School, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = "المدرب: $loggedInUser",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.5.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                val tStatusDetail = when (tStatus) {
                                                    "حضور" -> {
                                                        if (tCheckIn.isNotEmpty() && tCheckOut.isNotEmpty()) {
                                                            "🟢 حاضر (دخول: ${formatTimeTo12HourArabic(tCheckIn)} • انصراف: ${formatTimeTo12HourArabic(tCheckOut)})"
                                                        } else if (tCheckOut.isNotEmpty()) {
                                                            "🟢 حاضر (انصراف: ${formatTimeTo12HourArabic(tCheckOut)})"
                                                        } else if (tCheckIn.isNotEmpty()) {
                                                            "🟢 حاضر (دخول: ${formatTimeTo12HourArabic(tCheckIn)})"
                                                        } else {
                                                            "🟢 حاضر"
                                                        }
                                                    }
                                                    "غياب" -> "🔴 غائب"
                                                    "إجازة" -> "🟡 إجازة معتمدة"
                                                    else -> "⚪ لم يسجل بعد"
                                                }
                                                Text(
                                                    text = tStatusDetail,
                                                    fontSize = 9.sp,
                                                    fontWeight = if (tStatus != "لم يسجل") FontWeight.Bold else FontWeight.Normal,
                                                    color = when (tStatus) {
                                                        "حضور" -> Color(0xFF16A34A)
                                                        "غياب" -> Color(0xFFDC2626)
                                                        "إجازة" -> Color(0xFFD97706)
                                                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                                                    }
                                                )
                                                if (isTExam) {
                                                    Surface(
                                                        color = Color(0xFFFEF3C7),
                                                        shape = RoundedCornerShape(4.dp),
                                                        border = BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.4f)),
                                                        modifier = Modifier.padding(top = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = "🛡️ موعد الاختبار النهائي",
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFFB45309),
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        if (tStatus != "لم يسجل" && trainerRecord != null) {
                                            FilledTonalIconButton(
                                                onClick = { showTrainerUndoConfirmDialog = true },
                                                modifier = Modifier.size(28.dp),
                                                colors = IconButtonDefaults.filledTonalIconButtonColors(
                                                    containerColor = DawamiNavy.copy(alpha = 0.08f),
                                                    contentColor = DawamiNavy
                                                )
                                            ) {
                                                Icon(Icons.Default.Undo, contentDescription = "تراجع", modifier = Modifier.size(14.dp))
                                            }
                                        }
                                    }
                                }
                            }

                            // 2. Students Section Header
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "قائمة الطلاب المسجلين (${sortedStudents.size})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp,
                                        color = DawamiNavy
                                    )
                                }
                            }

                            // 3. Students 2-Column Grid Rows (with Multi-Select Checkbox)
                            items(
                                items = studentPairs,
                                key = { pair -> pair.joinToString("-") { it.studentId.toString() } }
                            ) { pair ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 3.dp),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    pair.forEach { studentItem ->
                                        val isSelected = selectedStudentMap[studentItem.studentId] == true
                                        val sStatus = studentItem.status.ifEmpty { "لم يسجل" }
                                        val hasAttended = sStatus == "حضور"
                                        val isDoneCheckOut = studentItem.actualCheckOut.isNotEmpty()

                                        Card(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(90.dp)
                                                .clickable {
                                                    selectedStudentMap[studentItem.studentId] = !isSelected
                                                },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isSelected) DawamiNavy.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                                            ),
                                            border = BorderStroke(
                                                if (isSelected) 1.5.dp else 1.dp,
                                                if (isSelected) DawamiNavy else when (sStatus) {
                                                    "حضور" -> Color(0xFF16A34A).copy(alpha = 0.4f)
                                                    "غياب" -> Color(0xFFDC2626).copy(alpha = 0.4f)
                                                    "مستأذن" -> Color(0xFF0284C7).copy(alpha = 0.4f)
                                                    "إجازة" -> Color(0xFFD97706).copy(alpha = 0.4f)
                                                    else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                                }
                                            ),
                                            elevation = CardDefaults.cardElevation(if (isSelected) 2.dp else 0.5.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(horizontal = 7.dp, vertical = 6.dp),
                                                verticalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                // الصف الأول: الاسم ومربع الاختيار وزر الإلغاء
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Checkbox(
                                                            checked = isSelected,
                                                            onCheckedChange = { selectedStudentMap[studentItem.studentId] = it },
                                                            modifier = Modifier.size(18.dp),
                                                            colors = CheckboxDefaults.colors(checkedColor = DawamiNavy)
                                                        )
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(
                                                            text = studentItem.studentName,
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.onSurface,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                    }

                                                    if (sStatus != "لم يسجل") {
                                                        IconButton(
                                                            onClick = { studentToClearConfirm = studentItem },
                                                            modifier = Modifier.size(18.dp)
                                                        ) {
                                                            Icon(
                                                                Icons.Default.Close,
                                                                contentDescription = "مسح",
                                                                tint = Color.Gray,
                                                                modifier = Modifier.size(11.dp)
                                                            )
                                                        }
                                                    }
                                                }

                                                // الصف الثاني: حاضر ومقابل له وقت الحضور
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        text = when (sStatus) {
                                                            "حضور" -> "🟢 حاضر"
                                                            "غياب" -> "🔴 غائب"
                                                            "مستأذن" -> "🔵 مستأذن"
                                                            "إجازة" -> "🟡 إجازة"
                                                            else -> "⚪ لم يسجل"
                                                        },
                                                        fontSize = 9.sp,
                                                        fontWeight = if (sStatus != "لم يسجل") FontWeight.Bold else FontWeight.Normal,
                                                        color = when (sStatus) {
                                                            "حضور" -> Color(0xFF16A34A)
                                                            "غياب" -> Color(0xFFDC2626)
                                                            "مستأذن" -> Color(0xFF0284C7)
                                                            "إجازة" -> Color(0xFFD97706)
                                                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                                                        }
                                                    )

                                                    if (studentItem.actualCheckIn.isNotEmpty()) {
                                                        Text(
                                                            text = "${formatTimeTo12HourArabic(studentItem.actualCheckIn)} 📥",
                                                            fontSize = 8.5.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF16A34A),
                                                            maxLines = 1
                                                        )
                                                    } else {
                                                        Text(
                                                            text = "--:--",
                                                            fontSize = 8.sp,
                                                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                                            maxLines = 1
                                                        )
                                                    }
                                                }

                                                // الصف الثالث: انصراف ومقابل له وقت الانصراف أو أيقونة الانتظار
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        text = if (hasAttended) "انصراف" else "",
                                                        fontSize = 8.5.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                                    )

                                                    if (studentItem.actualCheckOut.isNotEmpty()) {
                                                        Text(
                                                            text = "${formatTimeTo12HourArabic(studentItem.actualCheckOut)} 📤",
                                                            fontSize = 8.5.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF0284C7),
                                                            maxLines = 1
                                                        )
                                                    } else if (hasAttended) {
                                                        Text(
                                                            text = "⏳ بانتظار الانصراف",
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFFD97706),
                                                            maxLines = 1
                                                        )
                                                    } else {
                                                        Text(
                                                            text = "",
                                                            fontSize = 8.sp
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (pair.size == 1) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                        }
                    }
                }
            }
        }
    }

    // --- Attendance / Check-out Time Confirmation Dialog with Feedback ---
    if (showTimeConfirmationDialog) {
        val isCheckIn = confirmActionType == AttendanceConfirmType.CHECK_IN
        val isCheckOut = confirmActionType == AttendanceConfirmType.CHECK_OUT
        val isAbsent = confirmActionType == AttendanceConfirmType.ABSENT
        val isExcused = confirmActionType == AttendanceConfirmType.EXCUSED
        val isLeave = confirmActionType == AttendanceConfirmType.LEAVE

        val trainerRecordForToday = dbAttendance.find { it.courseId == selectedCourse?.id && it.date == todayStr }
        val initialIsExam = (trainerRecordForToday?.isExamDay == true) || viewModel.isExamDayForNextRecord.value
        var isExamDaySelected by remember(showTimeConfirmationDialog) { mutableStateOf(initialIsExam) }

        val actionTitle = when (confirmActionType) {
            AttendanceConfirmType.CHECK_IN -> "تأكيد تسجيل الحضور في البطاقة"
            AttendanceConfirmType.CHECK_OUT -> "تأكيد تسجيل الانصراف في البطاقة"
            AttendanceConfirmType.ABSENT -> "تأكيد تسجيل الغياب في البطاقة ❌"
            AttendanceConfirmType.EXCUSED -> "تأكيد تسجيل الاستئذان في البطاقة 🔵"
            AttendanceConfirmType.LEAVE -> "تأكيد تسجيل الإجازة في البطاقة 🟡"
        }

        val themeColor = when (confirmActionType) {
            AttendanceConfirmType.CHECK_IN -> Color(0xFF16A34A)
            AttendanceConfirmType.CHECK_OUT -> Color(0xFF0284C7)
            AttendanceConfirmType.ABSENT -> Color(0xFFDC2626)
            AttendanceConfirmType.EXCUSED -> Color(0xFF0284C7)
            AttendanceConfirmType.LEAVE -> Color(0xFFD97706)
        }

        val schedTime = if (isCheckIn) (selectedCourse?.startTime ?: "") else if (isCheckOut) (selectedCourse?.endTime ?: "") else ""
        val timeDiffMinutes = remember(confirmSelectedTime, schedTime) {
            if (schedTime.isNotEmpty()) calculateTimeDiffMinutes(confirmSelectedTime, schedTime) else null
        }

        AlertDialog(
            onDismissRequest = { showTimeConfirmationDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(themeColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (confirmActionType) {
                                AttendanceConfirmType.CHECK_IN -> Icons.Default.CheckCircle
                                AttendanceConfirmType.CHECK_OUT -> Icons.Default.ExitToApp
                                AttendanceConfirmType.ABSENT -> Icons.Default.Close
                                AttendanceConfirmType.EXCUSED -> Icons.Default.Info
                                AttendanceConfirmType.LEAVE -> Icons.Default.DateRange
                            },
                            contentDescription = null,
                            tint = themeColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = actionTitle,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = DawamiNavy
                        )
                        Text(
                            text = "معاينة الحركة والتأكيد قبل التثبيت النهائي",
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // 1. Target Details Card
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("المستهدفون بالرصد في البطاقات:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                            }
                            if (confirmIsTrainerIncluded) {
                                Text("• المدرب: $loggedInUser", fontSize = 10.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                            }
                            if (confirmTargetStudents.isNotEmpty()) {
                                if (confirmTargetStudents.size == 1) {
                                    Text("• الطالب: ${confirmTargetStudents.first().studentName}", fontSize = 10.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                                } else {
                                    Text("• عدد (${confirmTargetStudents.size}) طلاب: ${confirmTargetStudents.take(3).joinToString("، ") { it.studentName }}${if (confirmTargetStudents.size > 3) " وغيرهم..." else ""}", fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                            } else if (!confirmIsTrainerIncluded && confirmUnrecordedStudents.isNotEmpty()) {
                                Text("• عدد (${confirmUnrecordedStudents.size}) طلاب بدون حركة", fontSize = 10.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }

                    // Exam Checkbox (Synced with Trainer and Student Cards)
                    if (isCheckIn) {
                        Surface(
                            color = if (isExamDaySelected) Color(0xFFFEF3C7) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, if (isExamDaySelected) Color(0xFFD97706) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isExamDaySelected = !isExamDaySelected }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Checkbox(
                                    checked = isExamDaySelected,
                                    onCheckedChange = { isExamDaySelected = it },
                                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFFD97706))
                                )
                                Text(
                                    text = "📝 تعيين جلسة اليوم كامتحان / اختبار للمادة",
                                    fontSize = 11.sp,
                                    fontWeight = if (isExamDaySelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isExamDaySelected) Color(0xFF92400E) else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // 2. Exact Time Feedback Box (The Core User Request!)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isCheckIn) Color(0xFFF0FDF4) else Color(0xFFF0F9FF),
                        border = BorderStroke(1.5.dp, if (isCheckIn) Color(0xFF86EFAC) else Color(0xFFBAE6FD)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "⏰ التوقيت الذي سيُسجل في البطاقة:",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCheckIn) Color(0xFF166534) else Color(0xFF075985)
                            )
                            
                            // Big bold 12-hour time badge
                            Text(
                                text = formatTimeTo12HourArabic(confirmSelectedTime),
                                fontSize = 26.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isCheckIn) Color(0xFF15803D) else Color(0xFF0284C7)
                            )
                            Text(
                                text = "نظام 24 ساعة: $confirmSelectedTime",
                                fontSize = 9.sp,
                                color = Color.Gray
                            )

                            // Real-time Feedback analysis
                            if (schedTime.isNotEmpty() && timeDiffMinutes != null) {
                                val feedbackBg: Color
                                val feedbackBorder: Color
                                val feedbackText: String
                                val feedbackTextColor: Color

                                if (isCheckIn) {
                                    when {
                                        timeDiffMinutes > 0 -> {
                                            feedbackBg = Color(0xFFFEF3C7)
                                            feedbackBorder = Color(0xFFFCD34D)
                                            feedbackTextColor = Color(0xFFB45309)
                                            feedbackText = "⚠️ تأخير بمقدار ($timeDiffMinutes دقيقة) عن موعد الدورة المجدول (${formatTimeTo12HourArabic(schedTime)})"
                                        }
                                        timeDiffMinutes == 0 -> {
                                            feedbackBg = Color(0xFFDCFCE7)
                                            feedbackBorder = Color(0xFF86EFAC)
                                            feedbackTextColor = Color(0xFF15803D)
                                            feedbackText = "✅ في موعد بدء الدورة المجدول تماماً (${formatTimeTo12HourArabic(schedTime)})"
                                        }
                                        else -> {
                                            feedbackBg = Color(0xFFCCFBF1)
                                            feedbackBorder = Color(0xFF5EEAD4)
                                            feedbackTextColor = Color(0xFF0F766E)
                                            feedbackText = "⚡ حضور مبكر بـ (${-timeDiffMinutes} دقيقة) قبل بدء الدورة (${formatTimeTo12HourArabic(schedTime)})"
                                        }
                                    }
                                } else {
                                    when {
                                        timeDiffMinutes < 0 -> {
                                            feedbackBg = Color(0xFFFFEDD5)
                                            feedbackBorder = Color(0xFFFDBA74)
                                            feedbackTextColor = Color(0xFFC2410C)
                                            feedbackText = "⚠️ انصراف مبكر قبل موعد نهاية الدورة بـ (${-timeDiffMinutes} دقيقة) (${formatTimeTo12HourArabic(schedTime)})"
                                        }
                                        timeDiffMinutes == 0 -> {
                                            feedbackBg = Color(0xFFDCFCE7)
                                            feedbackBorder = Color(0xFF86EFAC)
                                            feedbackTextColor = Color(0xFF15803D)
                                            feedbackText = "✅ في موعد نهاية الدورة المجدول تماماً (${formatTimeTo12HourArabic(schedTime)})"
                                        }
                                        else -> {
                                            feedbackBg = Color(0xFFE0F2FE)
                                            feedbackBorder = Color(0xFF7DD3FC)
                                            feedbackTextColor = Color(0xFF0369A1)
                                            feedbackText = "ℹ️ انصراف بعد نهاية الدورة بـ ($timeDiffMinutes دقيقة) (${formatTimeTo12HourArabic(schedTime)})"
                                        }
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = feedbackBg,
                                    border = BorderStroke(1.dp, feedbackBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = feedbackText,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = feedbackTextColor,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // 3. Quick Time adjustment and source toggles
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("الخيارات السريعة للتوقيت:", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Current actual time button
                            Surface(
                                onClick = { confirmSelectedTime = currentTime },
                                shape = RoundedCornerShape(6.dp),
                                color = if (confirmSelectedTime == currentTime) DawamiNavy.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, if (confirmSelectedTime == currentTime) DawamiNavy else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 5.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text("⚡ الآن (${formatTimeTo12HourArabic(currentTime)})", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                }
                            }

                            // Scheduled time button
                            if (schedTime.isNotEmpty()) {
                                Surface(
                                    onClick = { confirmSelectedTime = schedTime },
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (confirmSelectedTime == schedTime) DawamiNavy.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, if (confirmSelectedTime == schedTime) DawamiNavy else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(vertical = 5.dp, horizontal = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Text("📅 وقت الدورة (${formatTimeTo12HourArabic(schedTime)})", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                    }
                                }
                            }
                        }

                        // Fine tune buttons (-5m, -1m, +1m, +5m)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("تعديل دقائق:", fontSize = 8.5.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.weight(1f))
                            listOf(-5, -1, 1, 5).forEach { delta ->
                                Surface(
                                    onClick = { confirmSelectedTime = adjustTimeMinutes(confirmSelectedTime, delta) },
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFF1F5F9),
                                    border = BorderStroke(0.8.dp, Color(0xFFCBD5E1))
                                ) {
                                    Text(
                                        text = if (delta > 0) "+$delta د" else "$delta د",
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF334155),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        when (confirmActionType) {
                            AttendanceConfirmType.CHECK_IN -> {
                                viewModel.setIsExamDayForNextRecord(isExamDaySelected)
                                if (trainerRecordForToday != null && trainerRecordForToday.isExamDay != isExamDaySelected) {
                                    viewModel.toggleAttendanceExamDay(trainerRecordForToday)
                                }
                                if (confirmTargetStudents.isNotEmpty()) {
                                    viewModel.registerStudentCheckInBulk(confirmTargetStudents, confirmSelectedTime)
                                }
                                if (confirmIsTrainerIncluded) {
                                    viewModel.attendanceCheckInInput.value = confirmSelectedTime
                                    viewModel.attendanceDayInput.value = dayNameAr
                                    viewModel.attendanceDateInput.value = todayStr
                                    viewModel.recordCheckInOnly()
                                }
                                val gender = viewModel.voiceGender.value
                                val timeFormatted = formatTimeTo12HourArabic(confirmSelectedTime)
                                val appContext = context.applicationContext
                                val studentSuccessText = viewModel.studentCheckInSuccessText.value.ifBlank { "لقد تم تحضير الطلاب بنجاح شكرا لك" }

                                if (confirmIsTrainerIncluded && confirmTargetStudents.isNotEmpty()) {
                                    // 1. أولاً: تنبيه حضور المدرب فوراً
                                    AudioPlayerHelper.playAudioOrSpeak(context, "trainer_checkin_success", "تم تسجيل حضور المدرب بنجاح", gender)
                                    Toast.makeText(context, "تم تسجيل حضور المدرب في البطاقة بنجاح بتوقيت ($timeFormatted) 👨‍🏫⚡", Toast.LENGTH_SHORT).show()

                                    // 2. بعد ثوانٍ (3.5 ثوانٍ): تأخير تنبيه حضور الطلاب بعد انتهاء تنبيه المدرب
                                    val studentsCount = confirmTargetStudents.size
                                    Handler(Looper.getMainLooper()).postDelayed({
                                        AudioPlayerHelper.playAudioOrSpeak(appContext, "student_checkin_success", studentSuccessText, gender)
                                        Toast.makeText(appContext, "تم تسجيل حضور الطلاب ($studentsCount) في البطاقة بنجاح بتوقيت ($timeFormatted) 👥⚡", Toast.LENGTH_SHORT).show()
                                    }, 3500L)
                                } else if (confirmIsTrainerIncluded) {
                                    AudioPlayerHelper.playAudioOrSpeak(context, "trainer_checkin_success", "تم تسجيل حضور المدرب بنجاح", gender)
                                    Toast.makeText(context, "تم تسجيل حضور المدرب في البطاقة بنجاح بتوقيت ($timeFormatted) 👨‍🏫⚡", Toast.LENGTH_SHORT).show()
                                } else if (confirmTargetStudents.isNotEmpty()) {
                                    AudioPlayerHelper.playAudioOrSpeak(context, "student_checkin_success", studentSuccessText, gender)
                                    val targetDesc = if (confirmTargetStudents.size == 1) {
                                        "الطالب: ${confirmTargetStudents.first().studentName}"
                                    } else {
                                        "(${confirmTargetStudents.size}) طلاب"
                                    }
                                    Toast.makeText(context, "تم تسجيل الحضور في البطاقة بنجاح بتوقيت ($timeFormatted) لـ $targetDesc ⚡", Toast.LENGTH_SHORT).show()
                                }
                            }
                            AttendanceConfirmType.CHECK_OUT -> {
                                val gender = viewModel.voiceGender.value
                                if (confirmTargetStudents.isNotEmpty()) {
                                    viewModel.registerStudentCheckOutIndividualBulk(confirmTargetStudents, confirmSelectedTime)
                                    if (!confirmIsTrainerIncluded) {
                                        AudioPlayerHelper.playAudioOrSpeak(context, "student_checkout_success", "تم تسجيل انصراف الطلاب بنجاح", gender)
                                    }
                                }
                                if (confirmIsTrainerIncluded) {
                                    trainerCheckoutTime = confirmSelectedTime
                                    viewModel.attendanceCheckOutInput.value = trainerCheckoutTime
                                    viewModel.attendanceDateInput.value = todayStr
                                    val err = viewModel.recordCheckOutAndComplete()
                                    if (err == null) {
                                        AudioPlayerHelper.playAudioOrSpeak(context, "trainer_checkout_success", "تم تسجيل انصراف المدرب بنجاح", gender)
                                        showTrainerCheckoutPrompt = true
                                    }
                                } else {
                                    if (confirmUnrecordedStudents.isNotEmpty()) {
                                        unrecordedTargetStudents = confirmUnrecordedStudents
                                        unrecordedCheckoutTime = confirmSelectedTime
                                        showUnrecordedCheckoutDialog = true
                                    } else if (confirmTargetStudents.isNotEmpty()) {
                                        val targetDesc = if (confirmTargetStudents.size == 1) {
                                            "الطالب: ${confirmTargetStudents.first().studentName}"
                                        } else {
                                            "(${confirmTargetStudents.size}) طلاب"
                                        }
                                        Toast.makeText(context, "تم تسجيل الانصراف في البطاقة بنجاح بتوقيت (${formatTimeTo12HourArabic(confirmSelectedTime)}) لـ $targetDesc 📤", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                            AttendanceConfirmType.ABSENT -> {
                                if (confirmTargetStudents.isNotEmpty()) {
                                    viewModel.registerStudentAbsentBulk(confirmTargetStudents)
                                }
                                if (confirmIsTrainerIncluded) {
                                    trainerActionType = "غياب"
                                    showTrainerAbsentLeaveDialog = true
                                } else {
                                    val targetDesc = if (confirmTargetStudents.size == 1) "الطالب: ${confirmTargetStudents.first().studentName}" else "(${confirmTargetStudents.size}) طلاب"
                                    Toast.makeText(context, "تم اعتماد وتسجيل غياب ❌ لـ $targetDesc", Toast.LENGTH_SHORT).show()
                                }
                            }
                            AttendanceConfirmType.EXCUSED -> {
                                if (confirmTargetStudents.isNotEmpty()) {
                                    viewModel.registerStudentExcusedBulk(confirmTargetStudents)
                                }
                                if (confirmIsTrainerIncluded) {
                                    trainerActionType = "مستأذن"
                                    showTrainerAbsentLeaveDialog = true
                                } else {
                                    val targetDesc = if (confirmTargetStudents.size == 1) "الطالب: ${confirmTargetStudents.first().studentName}" else "(${confirmTargetStudents.size}) طلاب"
                                    Toast.makeText(context, "تم اعتماد وتسجيل استئذان 🔵 لـ $targetDesc", Toast.LENGTH_SHORT).show()
                                }
                            }
                            AttendanceConfirmType.LEAVE -> {
                                if (confirmTargetStudents.isNotEmpty()) {
                                    viewModel.registerStudentLeaveBulk(confirmTargetStudents)
                                }
                                if (confirmIsTrainerIncluded) {
                                    trainerActionType = "إجازة"
                                    showTrainerAbsentLeaveDialog = true
                                } else {
                                    val targetDesc = if (confirmTargetStudents.size == 1) "الطالب: ${confirmTargetStudents.first().studentName}" else "(${confirmTargetStudents.size}) طلاب"
                                    Toast.makeText(context, "تم اعتماد وتسجيل إجازة 🟡 لـ $targetDesc", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        showTimeConfirmationDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("✓ اعتماد وحفظ في البطاقة", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showTimeConfirmationDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("إلغاء ✕", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        )
    }

    // --- Trainer Check-out Prompt Dialog ---
    if (showTrainerCheckoutPrompt) {
        val activeStudents = sortedStudents.filter { it.status == "حضور" && it.actualCheckOut.isEmpty() }
        val unrecordedStudents = sortedStudents.filter { it.status == "لم يسجل" || it.status.isEmpty() }
        val schedEnd = selectedCourse?.endTime ?: trainerCheckoutTime

        AlertDialog(
            onDismissRequest = {
                val currentTrainer = dbAttendance.find { it.courseId == selectedCourse?.id && it.date == todayStr }
                if (currentTrainer != null && currentTrainer.actualCheckOut.isNotEmpty()) {
                    viewModel.cancelTrainerCheckOut(currentTrainer)
                }
                showTrainerCheckoutPrompt = false
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("⚡", fontSize = 16.sp)
                    Text(
                        text = "اعتماد انصراف المدرب والطلاب",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "تم رصد انصراف المدرب بنجاح الساعة ($trainerCheckoutTime). يوجد (${activeStudents.size}) طلاب حاضرين و (${unrecordedStudents.size}) طلاب بدون حركة. حدد الإجراء المطلوب:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Option 1: Trainer checkout time + absent for unrecorded
                    Surface(
                        onClick = {
                            if (activeStudents.isNotEmpty()) viewModel.registerStudentCheckOutIndividualBulk(activeStudents, trainerCheckoutTime)
                            if (unrecordedStudents.isNotEmpty()) {
                                viewModel.registerStudentAbsentBulk(unrecordedStudents)
                                absentSummaryStudentsList = unrecordedStudents.map { it.studentName }
                                showAbsentSummaryDialog = true
                            }
                            showTrainerCheckoutPrompt = false
                            Toast.makeText(context, "تم اعتماد انصراف الحاضرين بتوقيت المدرب وغياب لغير المسجلين ⚡", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF2F2),
                        border = BorderStroke(1.dp, Color(0xFFFECACA)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("1️⃣", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text("انصراف الحاضرين بتوقيت المدرب ($trainerCheckoutTime) + غياب لغير المسجلين (${unrecordedStudents.size}) ❌", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                                Text("اعتماد انصراف الحاضرين الآن وغياب لمن ليس له حركة", fontSize = 8.5.sp, color = Color(0xFFB91C1C))
                            }
                        }
                    }

                    // Option 2: Course scheduled checkout + absent for unrecorded
                    Surface(
                        onClick = {
                            if (activeStudents.isNotEmpty()) viewModel.registerStudentCheckOutIndividualBulk(activeStudents, schedEnd)
                            if (unrecordedStudents.isNotEmpty()) {
                                viewModel.registerStudentAbsentBulk(unrecordedStudents)
                                absentSummaryStudentsList = unrecordedStudents.map { it.studentName }
                                showAbsentSummaryDialog = true
                            }
                            showTrainerCheckoutPrompt = false
                            Toast.makeText(context, "تم اعتماد انصراف الدورة المجدول ($schedEnd) وغياب لغير المسجلين 📤", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFEFF6FF),
                        border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("2️⃣", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text("انصراف الدورة المجدول ($schedEnd) للحاضرين + غياب لغير المسجلين 📤", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF))
                                Text("اعتماد نهاية وقت الدورة للحاضرين وغياب لمن لم يسجل", fontSize = 8.5.sp, color = Color(0xFF2563EB))
                            }
                        }
                    }

                    if (unrecordedStudents.isNotEmpty()) {
                        // Option 3: Perfect attendance for unrecorded
                        Surface(
                            onClick = {
                                if (activeStudents.isNotEmpty()) viewModel.registerStudentCheckOutIndividualBulk(activeStudents, trainerCheckoutTime)
                                viewModel.registerStudentPerfectAttendanceBulk(unrecordedStudents, trainerCheckoutTime)
                                showTrainerCheckoutPrompt = false
                                Toast.makeText(context, "تم اعتماد انصراف الحاضرين وحضور/انصراف مثالي لـ (${unrecordedStudents.size}) طلاب ⭐", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF0FDF4),
                            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("3️⃣", fontSize = 12.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("اعتماد حضور وانصراف مثالي لغير المسجلين (${unrecordedStudents.size}) ⭐", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF166534))
                                    Text("حضور بداية الدورة وانصراف بتوقيت المدرب", fontSize = 8.5.sp, color = Color(0xFF15803D))
                                }
                            }
                        }

                        // Option 4: Excused for unrecorded
                        Surface(
                            onClick = {
                                if (activeStudents.isNotEmpty()) viewModel.registerStudentCheckOutIndividualBulk(activeStudents, trainerCheckoutTime)
                                viewModel.registerStudentExcusedBulk(unrecordedStudents)
                                showTrainerCheckoutPrompt = false
                                Toast.makeText(context, "تم اعتماد انصراف الحاضرين ومستأذن لـ (${unrecordedStudents.size}) طلاب 🔵", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF0F9FF),
                            border = BorderStroke(1.dp, Color(0xFFBAE6FD)),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("4️⃣", fontSize = 12.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("اعتماد مستأذن لغير المسجلين (${unrecordedStudents.size}) 🔵", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0369A1))
                                    Text("تسجيل حالة مستأذن للطلاب الذين لم يحضروا", fontSize = 8.5.sp, color = Color(0xFF0284C7))
                                }
                            }
                        }
                    }

                    // Option 5: Attended only, keep unrecorded for individual check
                    Surface(
                        onClick = {
                            if (activeStudents.isNotEmpty()) viewModel.registerStudentCheckOutIndividualBulk(activeStudents, trainerCheckoutTime)
                            showTrainerCheckoutPrompt = false
                            Toast.makeText(context, "تم اعتماد انصراف الحاضرين فقط بنجاح ⚡", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = DawamiNavy.copy(alpha = 0.08f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("👤", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text("انصراف الحاضرين فقط ومتابعة غير المسجلين يدوياً", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                Text("إبقاء غير المسجلين دون تعديل لتحديد حركاتهم فردياً", fontSize = 8.5.sp, color = DawamiNavy.copy(alpha = 0.8f))
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        val currentTrainer = dbAttendance.find { it.courseId == selectedCourse?.id && it.date == todayStr }
                        if (currentTrainer != null && currentTrainer.actualCheckOut.isNotEmpty()) {
                            viewModel.cancelTrainerCheckOut(currentTrainer)
                        }
                        showTrainerCheckoutPrompt = false
                        Toast.makeText(context, "تم إلغاء العملية والتراجع عن انصراف المدرب ↩️", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إلغاء والتراجع عن انصراف المدرب ↩️", fontSize = 10.5.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    // --- Unrecorded Students Check-out Options Dialog (Requirement 4) ---
    if (showUnrecordedCheckoutDialog) {
        val unrecCount = unrecordedTargetStudents.size

        AlertDialog(
            onDismissRequest = { showUnrecordedCheckoutDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("⚠️", fontSize = 16.sp)
                    Text(
                        text = "خيارات الطلاب غير المسجلين ($unrecCount)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "يوجد ($unrecCount) طلاب تم تحديدهم ولم تسجل لهم أي حركة (دخول أو غياب). حدد الإجراء المطلوب لاعتماد حركتهم:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Option 1: Perfect Check-in & Check-out
                    Surface(
                        onClick = {
                            viewModel.registerStudentPerfectAttendanceBulk(unrecordedTargetStudents, unrecordedCheckoutTime)
                            showUnrecordedCheckoutDialog = false
                            Toast.makeText(context, "تم اعتماد حضور وانصراف مثالي لـ ($unrecCount) طلاب 🌟", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF0FDF4),
                        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("⭐", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("1. اعتماد حضور مثالي وانصراف مثالي", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF166534))
                                Text("دخول بداية الدورة وانصراف بتوقيت الخروج", fontSize = 9.sp, color = Color(0xFF15803D))
                            }
                        }
                    }

                    // Option 2: Absent for all
                    Surface(
                        onClick = {
                            viewModel.registerStudentAbsentBulk(unrecordedTargetStudents)
                            val absentNames = unrecordedTargetStudents.map { it.studentName }
                            absentSummaryStudentsList = absentNames
                            showAbsentSummaryDialog = true
                            showUnrecordedCheckoutDialog = false
                            Toast.makeText(context, "تم اعتماد غياب للطلاب بدون حركة ($unrecCount) ❌", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF2F2),
                        border = BorderStroke(1.dp, Color(0xFFFECACA)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("❌", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("2. اعتماد غياب للطلاب بدون حركة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                                Text("تسجيل غياب لكافة الطلاب الذين لم يسجلوا", fontSize = 9.sp, color = Color(0xFFB91C1C))
                            }
                        }
                    }

                    // Option 3: Excused for all
                    Surface(
                        onClick = {
                            viewModel.registerStudentExcusedBulk(unrecordedTargetStudents)
                            showUnrecordedCheckoutDialog = false
                            Toast.makeText(context, "تم اعتماد مستأذن للطلاب بدون حركة ($unrecCount) 🔵", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF0F9FF),
                        border = BorderStroke(1.dp, Color(0xFFBAE6FD)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🔵", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("3. اعتماد مستأذن للطلاب بدون حركة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0369A1))
                                Text("تسجيل حالة مستأذن لكافة غير المسجلين", fontSize = 9.sp, color = Color(0xFF0284C7))
                            }
                        }
                    }

                    // Option 4: Manual individual selection
                    Surface(
                        onClick = {
                            showUnrecordedCheckoutDialog = false
                            Toast.makeText(context, "يمكنك الآن تحديد الحركة لكل طالب يدوياً من القائمة 👤", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = DawamiNavy.copy(alpha = 0.08f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("👤", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("4. تحديد حركة مختلفة لكل شخص (يدوياً)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                Text("إغلاق النافذة والمتابعة الفردية لكل طالب", fontSize = 9.sp, color = DawamiNavy.copy(alpha = 0.8f))
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showUnrecordedCheckoutDialog = false }) {
                    Text("إلغاء ↩️", color = Color.Gray, fontSize = 11.sp)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    if (showAbsentSummaryDialog) {
        AlertDialog(
            onDismissRequest = { showAbsentSummaryDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("📋", fontSize = 16.sp)
                    Text(
                        text = "تم اعتماد الغياب (${absentSummaryStudentsList.size} طلاب)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "تم رصد حركة الغياب ❌ للطلاب التالية أسماؤهم لعدم وجود تسجيل حركة مسبقة لهم اليوم:",
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        color = Color(0xFFFEF2F2),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFFECACA)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            absentSummaryStudentsList.forEachIndexed { index, name ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("❌", fontSize = 9.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${index + 1}. $name",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF991B1B)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAbsentSummaryDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("حسناً", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    // --- Trainer Absent / Leave / Excused 4 Options Dialog ---
    if (showTrainerAbsentLeaveDialog) {
        AlertDialog(
            onDismissRequest = { showTrainerAbsentLeaveDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = when (trainerActionType) {
                            "غياب" -> "🔴"
                            "إجازة" -> "🟡"
                            else -> "🔵"
                        },
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تحضير المدرب: $trainerActionType",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    val trainerDesc = when (trainerActionType) {
                        "غياب" -> "غائب"
                        "إجازة" -> "مجاز"
                        else -> "مستأذن"
                    }
                    Text(
                        text = "بما أن المدرب [$trainerDesc] اليوم، ما هو الإجراء المعتمد لطلاب هذه الدورة؟",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // Option 1: Mark Absent All
                    Surface(
                        onClick = {
                            viewModel.attendanceStatusInput.value = trainerActionType
                            viewModel.attendanceDateInput.value = todayStr
                            viewModel.attendanceDayInput.value = dayNameAr
                            viewModel.addOrUpdateAttendanceTemp()
                            if (sortedStudents.isNotEmpty()) viewModel.registerStudentAbsentBulk(sortedStudents)
                            showTrainerAbsentLeaveDialog = false
                            Toast.makeText(context, "تم رصد ($trainerActionType) للمدرب وغياب لكافة الطلاب ❌", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEE2E2),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🔴", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("1. تسجيل غياب للجميع", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB91C1C))
                        }
                    }

                    // Option 2: Mark Leave All
                    Surface(
                        onClick = {
                            viewModel.attendanceStatusInput.value = trainerActionType
                            viewModel.attendanceDateInput.value = todayStr
                            viewModel.attendanceDayInput.value = dayNameAr
                            viewModel.addOrUpdateAttendanceTemp()
                            if (sortedStudents.isNotEmpty()) viewModel.registerStudentLeaveBulk(sortedStudents)
                            showTrainerAbsentLeaveDialog = false
                            Toast.makeText(context, "تم رصد ($trainerActionType) للمدرب وإجازة لكافة الطلاب 🟡", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF3C7),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🟡", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("2. تسجيل إجازة معتمدة للجميع", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                        }
                    }

                    // Option 3: Reset / Keep unrecorded
                    Surface(
                        onClick = {
                            viewModel.attendanceStatusInput.value = trainerActionType
                            viewModel.attendanceDateInput.value = todayStr
                            viewModel.attendanceDayInput.value = dayNameAr
                            viewModel.addOrUpdateAttendanceTemp()
                            if (sortedStudents.isNotEmpty()) viewModel.deleteStudentAttendanceRecordBulk(sortedStudents)
                            showTrainerAbsentLeaveDialog = false
                            Toast.makeText(context, "تم رصد ($trainerActionType) للمدرب وإبقاء الطلاب دون تسجيل (إعادة تعيين) ⚪", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("⚪", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("3. إبقاء الطلاب (لم يسجل)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }

                    // Option 4: Individual Manual Handling
                    Surface(
                        onClick = {
                            viewModel.attendanceStatusInput.value = trainerActionType
                            viewModel.attendanceDateInput.value = todayStr
                            viewModel.attendanceDayInput.value = dayNameAr
                            viewModel.addOrUpdateAttendanceTemp()
                            showTrainerAbsentLeaveDialog = false
                            Toast.makeText(context, "تم رصد ($trainerActionType) للمدرب. يمكنك متابعة تحضير الطلاب فردياً 👤", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = DawamiNavy.copy(alpha = 0.08f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("👤", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("4. متابعة التحضير الفردي لكل طالب", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = {
                    showTrainerAbsentLeaveDialog = false
                    Toast.makeText(context, "تم إلغاء الإجراء ولم يتم تغيير حالة المدرب ↩️", Toast.LENGTH_SHORT).show()
                }) {
                    Text("إلغاء ↩️", color = Color.Gray, fontSize = 11.sp)
                }
            }
        )
    }

    // --- Auto Next Course Completion Dialog ---
    if (showCourseCompletedDialog) {
        AlertDialog(
            onDismissRequest = { showCourseCompletedDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🎉", fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("اكتمل رصد دورة (${selectedCourse?.name})", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = DawamiNavy)
                }
            },
            text = {
                Column {
                    Text(
                        text = "تم رصد جميع الطلاب والمدرب لهذه الدورة بنجاح.",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (nextCourse != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "هل تريد الانتقال إلى الدورة التالية (${nextCourse.name})؟",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0369A1)
                        )
                    } else {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "لقد تم الانتهاء من جميع الدورات التدريبية المجدولة لليوم! 👏",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D)
                        )
                    }
                }
            },
            confirmButton = {
                if (nextCourse != null) {
                    Button(
                        onClick = {
                            viewModel.selectCourseForStudentAttendance(nextCourse)
                            showCourseCompletedDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                    ) {
                        Text("الانتقال إلى (${nextCourse.name}) ➡️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = {
                            showCourseCompletedDialog = false
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                    ) {
                        Text("إغلاق المساعد ✅", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showCourseCompletedDialog = false }) {
                    Text("البقاء للمراجعة", color = Color.Gray, fontSize = 11.sp)
                }
            }
        )
    }

    // --- Bulk Clear / Reset Confirmation Dialog ---
    if (showBulkClearConfirmDialog) {
        val targetStudents = sortedStudents.filter { selectedStudentMap[it.studentId] == true }
        val targetDesc = if (isTrainerSelected && targetStudents.isNotEmpty()) {
            "المدرب و (${targetStudents.size}) طلاب"
        } else if (isTrainerSelected) {
            "المدرب فقط"
        } else if (targetStudents.size == 1) {
            "الطالب: ${targetStudents.first().studentName}"
        } else {
            "عدد (${targetStudents.size}) طلاب"
        }

        AlertDialog(
            onDismissRequest = { showBulkClearConfirmDialog = false },
            icon = {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(28.dp))
            },
            title = {
                Text(
                    text = "تأكيد مسح وتصفير السجل 🔄",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "هل أنت متأكد من مسح حركة التحضير المسجلة لـ ($targetDesc) ليوم $dayNameAr ($todayStr)؟",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "⚠️ ستتم إعادة تعيين حالتهم إلى (لم يسجل) وحذف أوقات الحضور والانصراف المرصودة.",
                        fontSize = 9.5.sp,
                        color = Color(0xFFDC2626)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isTrainerSelected && trainerRecord != null) {
                            viewModel.deleteAttendanceTemp(trainerRecord)
                        }
                        if (targetStudents.isNotEmpty()) {
                            viewModel.deleteStudentAttendanceRecordBulk(targetStudents)
                        }
                        showBulkClearConfirmDialog = false
                        Toast.makeText(context, "تم مسح وإعادة تعيين سجلات ($selectedItemCount) عنصر 🔄", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("نعم، تأكيد المسح", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showBulkClearConfirmDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("إلغاء", fontSize = 10.5.sp)
                }
            },
            shape = RoundedCornerShape(14.dp)
        )
    }

    // --- Bulk Cancel Check-out Confirmation Dialog ---
    if (showBulkCancelCheckoutConfirmDialog) {
        val targetStudents = sortedStudents.filter { selectedStudentMap[it.studentId] == true }
        val checkedOutStudents = targetStudents.filter { it.actualCheckOut.isNotEmpty() }
        val isTrainerCheckedOut = isTrainerSelected && trainerRecord != null && trainerRecord.actualCheckOut.isNotEmpty()

        val targetDesc = if (isTrainerCheckedOut && checkedOutStudents.isNotEmpty()) {
            "المدرب و (${checkedOutStudents.size}) طلاب"
        } else if (isTrainerCheckedOut) {
            "المدرب فقط"
        } else if (checkedOutStudents.size == 1) {
            "الطالب: ${checkedOutStudents.first().studentName}"
        } else {
            "عدد (${checkedOutStudents.size}) طلاب"
        }

        AlertDialog(
            onDismissRequest = { showBulkCancelCheckoutConfirmDialog = false },
            icon = {
                Icon(Icons.Default.Undo, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(28.dp))
            },
            title = {
                Text(
                    text = "تأكيد إلغاء الانصراف ↩️",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "هل أنت متأكد من إلغاء تسجيل الانصراف لـ ($targetDesc)؟",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "ℹ️ سيبقى سجل الحضور كما هو، وستعود حالة الانصراف إلى (⏳ بانتظار الانصراف).",
                        fontSize = 9.5.sp,
                        color = Color(0xFF0284C7)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (checkedOutStudents.isNotEmpty()) {
                            viewModel.cancelStudentCheckOutBulk(checkedOutStudents)
                        }
                        if (isTrainerCheckedOut && trainerRecord != null) {
                            viewModel.cancelTrainerCheckOut(trainerRecord)
                        }
                        showBulkCancelCheckoutConfirmDialog = false
                        Toast.makeText(context, "تم إلغاء تسجيل الانصراف بنجاح ↩️", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تأكيد الإلغاء ↩️", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showBulkCancelCheckoutConfirmDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تراجع", fontSize = 10.5.sp)
                }
            },
            shape = RoundedCornerShape(14.dp)
        )
    }

    // --- Individual Student Clear Confirmation Dialog ---
    studentToClearConfirm?.let { studentItem ->
        AlertDialog(
            onDismissRequest = { studentToClearConfirm = null },
            icon = {
                Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(26.dp))
            },
            title = {
                Text(
                    text = "تأكيد مسح حركة الطالب ✕",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(
                        text = "هل أنت متأكد من مسح حركة التحضير للطالب:",
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "👤 ${studentItem.studentName}",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )
                    val currStatus = studentItem.status.ifEmpty { "لم يسجل" }
                    Text(
                        text = "الحالة الحالية: [$currStatus] • سيتم تصفير السجل وإعادته إلى (لم يسجل).",
                        fontSize = 9.5.sp,
                        color = Color(0xFFDC2626)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteStudentAttendanceRecord(studentItem)
                        studentToClearConfirm = null
                        Toast.makeText(context, "تم مسح حركة الطالب ${studentItem.studentName} بنجاح 🔄", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("مسح السجل", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { studentToClearConfirm = null },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("إلغاء", fontSize = 10.sp)
                }
            },
            shape = RoundedCornerShape(14.dp)
        )
    }

    // --- Trainer Undo Confirmation Dialog ---
    if (showTrainerUndoConfirmDialog && trainerRecord != null) {
        AlertDialog(
            onDismissRequest = { showTrainerUndoConfirmDialog = false },
            icon = {
                Icon(Icons.Default.Undo, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(26.dp))
            },
            title = {
                Text(
                    text = "تأكيد إلغاء حركة المدرب ↩️",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(
                        text = "هل تريد إلغاء تسجيل حركة المدرب ($loggedInUser) لدورة (${selectedCourse?.name}) ليوم $dayNameAr ($todayStr)؟",
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "ستتم إعادة تعيين حالة المدرب إلى (لم يسجل).",
                        fontSize = 9.5.sp,
                        color = Color.Gray
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAttendanceTemp(trainerRecord)
                        showTrainerUndoConfirmDialog = false
                        Toast.makeText(context, "تم إلغاء حركة المدرب وإعادة التعيين ↩️", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تأكيد الإلغاء", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showTrainerUndoConfirmDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تراجع", fontSize = 10.sp)
                }
            },
            shape = RoundedCornerShape(14.dp)
        )
    }

    if (isSubjectDropdownExpanded && selectedCourse != null) {
        SubjectSelectionBottomSheet(
            currentCourse = selectedCourse!!,
            allSubjects = availableCourseSubjects.ifEmpty { allSubjects },
            courseSubjectStats = courseSubjectStats,
            courseCrossRefs = courseCrossRefs,
            selectedSubjectName = displayedSubject,
            onSelectSubject = { subject ->
                viewModel.updateStudentAttendanceSubject(subject.name)
                viewModel.updateTeacherAttendanceSubject(subject.name)
                isSubjectDropdownExpanded = false
                pendingCheckInAction?.invoke()
                pendingCheckInAction = null
            },
            onDismiss = {
                isSubjectDropdownExpanded = false
                pendingCheckInAction = null
            }
        )
    }
}

@Composable
fun QuickAssistantButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    textColor: Color,
    backgroundColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = backgroundColor,
        modifier = modifier.height(34.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = textColor, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(label, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = textColor, maxLines = 1)
        }
    }
}

@Composable
fun StatItem(label: String, count: Int, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = count.toString(), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = color)
        Text(text = label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
