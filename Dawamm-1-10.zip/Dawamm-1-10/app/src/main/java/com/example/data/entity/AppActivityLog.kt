package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_activity_logs")
data class AppActivityLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val dateStr: String = "",
    val timeStr: String = "",
    val category: String = "SYSTEM", // FINANCIAL, ATTENDANCE, GRADES, COURSES, STUDENTS, SYSTEM
    val actionType: String = "CREATE", // CREATE, UPDATE, DELETE, RECORD
    val title: String = "",
    val description: String = "",
    val relatedId: Long? = null
)
