package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lesson_session_topics")
data class LessonSessionTopic(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val courseId: Int,
    val subjectId: Int = 0,
    val topicId: Int,
    val date: String, // format: "yyyy-MM-dd"
    val isCompleted: Boolean = false,
    val completedAt: String = "", // format: "10:30 ص"
    val note: String = "" // "ملاحظة النقطة التدريبية"
)
