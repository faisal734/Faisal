package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lesson_topics")
data class LessonTopic(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectId: Int = 0,
    val courseId: Int = 0,
    val title: String,
    val description: String = "",
    val unitName: String = "",
    val orderIndex: Int = 0,
    val parentId: Int? = null,
    val level: Int = 1
)

