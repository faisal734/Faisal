package com.example.data.repository

import com.example.data.dao.StudentGradeConfigDao
import com.example.data.dao.StudentGradeDao
import com.example.data.dao.SubjectAssignmentTemplateDao
import com.example.data.dao.StudentAssignmentSubmissionDao
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentGradeConfig
import com.example.data.entity.SubjectAssignmentTemplate
import com.example.data.entity.StudentAssignmentSubmission
import kotlinx.coroutines.flow.Flow

/**
 * GradingRepository: مسؤول عن رصد درجات الطلاب، إعدادات الدرجات، التكاليف، والواجبات والمشاريع.
 */
class GradingRepository(
    private val studentGradeDao: StudentGradeDao,
    private val studentGradeConfigDao: StudentGradeConfigDao,
    private val subjectAssignmentTemplateDao: SubjectAssignmentTemplateDao,
    private val studentAssignmentSubmissionDao: StudentAssignmentSubmissionDao
) {
    val allGrades: Flow<List<StudentGrade>> = studentGradeDao.getAllGrades()
    val allGradeConfigs: Flow<List<StudentGradeConfig>> = studentGradeConfigDao.getAllGradeConfigs()
    val allAssignmentTemplates: Flow<List<SubjectAssignmentTemplate>> = subjectAssignmentTemplateDao.getAllAssignmentTemplates()
    val allAssignmentSubmissions: Flow<List<StudentAssignmentSubmission>> = studentAssignmentSubmissionDao.getAllSubmissions()

    // Grades
    fun getGradesByCourse(courseId: Int): Flow<List<StudentGrade>> = studentGradeDao.getGradesByCourse(courseId)
    fun getGradesByStudent(studentId: Int): Flow<List<StudentGrade>> = studentGradeDao.getGradesByStudent(studentId)
    suspend fun getGradeByStudentAndSubjectSync(studentId: Int, subjectName: String): StudentGrade? = studentGradeDao.getGradeByStudentAndSubjectSync(studentId, subjectName)
    suspend fun insertGrade(grade: StudentGrade): Long = studentGradeDao.insertGrade(grade)
    suspend fun deleteGrade(grade: StudentGrade) = studentGradeDao.deleteGrade(grade)
    suspend fun deleteGradesByCourseId(courseId: Int) = studentGradeDao.deleteGradesByCourseId(courseId)
    suspend fun deleteGradesByStudentId(studentId: Int) = studentGradeDao.deleteGradesByStudentId(studentId)
    suspend fun updateStudentGradeName(studentId: Int, newName: String) = studentGradeDao.updateStudentGradeName(studentId, newName)
    suspend fun updateCourseNameInGrades(courseId: Int, newName: String) = studentGradeDao.updateCourseName(courseId, newName)
    suspend fun updateSubjectNameInGrades(oldName: String, newName: String) = studentGradeDao.updateSubjectName(oldName, newName)
    suspend fun transferStudentGrades(studentId: Int, newCourseId: Int, newCourseName: String) = studentGradeDao.transferStudentGrades(studentId, newCourseId, newCourseName)
    suspend fun deleteAllGrades() = studentGradeDao.deleteAllGrades()

    // Grade Configs
    fun getGradeConfigForCourse(courseId: Int): Flow<StudentGradeConfig?> = studentGradeConfigDao.getGradeConfigForCourse(courseId)
    suspend fun getGradeConfigForCourseSync(courseId: Int): StudentGradeConfig? = studentGradeConfigDao.getGradeConfigForCourseSync(courseId)
    suspend fun insertGradeConfig(config: StudentGradeConfig): Long = studentGradeConfigDao.insertGradeConfig(config)
    suspend fun deleteGradeConfig(config: StudentGradeConfig) = studentGradeConfigDao.deleteGradeConfig(config)
    suspend fun deleteGradeConfigByCourseId(courseId: Int) = studentGradeConfigDao.deleteGradeConfigByCourseId(courseId)
    suspend fun deleteAllGradeConfigs() = studentGradeConfigDao.deleteAllGradeConfigs()

    // Assignments
    suspend fun insertAssignmentTemplate(template: SubjectAssignmentTemplate): Long = subjectAssignmentTemplateDao.insertTemplate(template)
    suspend fun updateAssignmentTemplate(template: SubjectAssignmentTemplate) = subjectAssignmentTemplateDao.updateTemplate(template)
    suspend fun deleteAssignmentTemplate(template: SubjectAssignmentTemplate) = subjectAssignmentTemplateDao.deleteTemplate(template)
    suspend fun deleteAssignmentTemplatesBySubject(subjectName: String) = subjectAssignmentTemplateDao.deleteTemplatesBySubject(subjectName)
    suspend fun updateSubjectNameInAssignmentTemplates(oldName: String, newName: String) = subjectAssignmentTemplateDao.updateSubjectName(oldName, newName)
    suspend fun deleteAllAssignmentTemplates() = subjectAssignmentTemplateDao.deleteAllTemplates()

    suspend fun insertAssignmentSubmission(submission: StudentAssignmentSubmission): Long = studentAssignmentSubmissionDao.insertSubmission(submission)
    suspend fun updateAssignmentSubmission(submission: StudentAssignmentSubmission) = studentAssignmentSubmissionDao.updateSubmission(submission)
    suspend fun deleteAssignmentSubmission(submission: StudentAssignmentSubmission) = studentAssignmentSubmissionDao.deleteSubmission(submission)
    suspend fun getSubmissionsForCourseDirect(courseId: Int): List<StudentAssignmentSubmission> = studentAssignmentSubmissionDao.getSubmissionsForCourseDirect(courseId)
    suspend fun getLatestAssignmentSubmissionDirect(courseId: Int, subjectName: String, studentId: Int, assignmentTitle: String): StudentAssignmentSubmission? = studentAssignmentSubmissionDao.getLatestSubmissionDirect(courseId, subjectName, studentId, assignmentTitle)
    suspend fun updateSubjectNameInSubmissions(oldName: String, newName: String) = studentAssignmentSubmissionDao.updateSubjectName(oldName, newName)
    suspend fun deleteAllAssignmentSubmissions() = studentAssignmentSubmissionDao.deleteAllSubmissions()
}
