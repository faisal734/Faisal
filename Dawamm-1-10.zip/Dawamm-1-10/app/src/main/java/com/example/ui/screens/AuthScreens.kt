package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppFooter
import com.example.ui.components.DawamiLogo
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.delay

// ---------------- LOGIN SCREEN ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(viewModel: MainViewModel) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val loginError by viewModel.loginError.collectAsState()
    val isBiometricEnabled by viewModel.isBiometricEnabled.collectAsState()
    var showBiometricDialog by remember { mutableStateOf(false) }
    var biometricScanState by remember { mutableStateOf(0) } // 0: Idle, 1: Scanning, 2: Success, 3: Error
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var lastDisplayedError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(loginError) {
        if (loginError != null && loginError != lastDisplayedError) {
            snackbarHostState.showSnackbar(
                message = loginError!!,
                duration = SnackbarDuration.Short
            )
            lastDisplayedError = loginError
        }
    }

    Scaffold(
        bottomBar = { AppFooter() }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(horizontal = 16.dp, vertical = 24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        DawamiLogo(size = 90.dp)
                        
                        Text(
                            text = "تسجيل الدخول الآمن",
                            color = DawamiNavy,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "أدخل بياناتك لمتابعة ساعات العمل والدورات",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("اسم المستخدم") },
                            placeholder = { Text("admin") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = DawamiNavy) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("كلمة المرور") },
                            placeholder = { Text("••••••••") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = DawamiNavy) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        if (loginError != null) {
                            Text(
                                text = loginError ?: "",
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { viewModel.login(username, password) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "دخول 🔑",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (isBiometricEnabled) {
                                IconButton(
                                    onClick = {
                                        biometricScanState = 1
                                    },
                                    modifier = Modifier
                                        .size(52.dp)
                                        .background(
                                            color = DawamiTeal.copy(alpha = 0.12f),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .border(
                                            width = 1.2.dp,
                                            color = DawamiTeal,
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Fingerprint,
                                        contentDescription = "الدخول ببصمة الإصبع",
                                        tint = DawamiTeal,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }

                        // منطق المصادقة الحقيقي
                        if (isBiometricEnabled && biometricScanState == 1) {
                            val activity = context as? androidx.fragment.app.FragmentActivity
                            LaunchedEffect(Unit) {
                                if (activity != null) {
                                    val success = viewModel.loginDirectlyWithBiometrics(activity)
                                    if (success) {
                                        biometricScanState = 2
                                        delay(800)
                                        biometricScanState = 0
                                    } else {
                                        biometricScanState = 3
                                        delay(2000)
                                        biometricScanState = 0
                                    }
                                } else {
                                    biometricScanState = 3
                                }
                            }
                        }

                        // حوار تفعيل البصمة لأول مرة
                        if (showBiometricDialog && !isBiometricEnabled && biometricScanState == 0) {
                            AlertDialog(
                                onDismissRequest = { showBiometricDialog = false },
                                title = {
                                    Text(
                                        text = "تفعيل البصمة الذكية 🔒",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        color = DawamiNavy,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                },
                                text = {
                                    Text(
                                        text = "هل ترغب في تفعيل خاصية تسجيل الدخول السريع والآمن باستخدام بصمة الإصبع لجهازك؟",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 18.sp
                                    )
                                },
                                confirmButton = {
                                    TextButton(
                                        onClick = {
                                            viewModel.saveBiometricEnabled(true)
                                            showBiometricDialog = false
                                        }
                                    ) {
                                        Text("تفعيل الآن", color = DawamiNavy, fontWeight = FontWeight.Bold)
                                    }
                                },
                                dismissButton = {
                                    TextButton(onClick = { showBiometricDialog = false }) {
                                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = { viewModel.navigateTo(Screen.AppFeaturesGuide) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.5.dp, DawamiNavy.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DawamiNavy)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = DawamiNavy,
                            modifier = Modifier.size(18.dp)
                        )
                        Text("مميزات البرنامج ودليل الاستخدام 💡", color = DawamiNavy, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Snackbar Host يوضع في أسفل الـ Box ليظهر فوق كل شيء
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.align(Alignment.BottomCenter),
                snackbar = { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = Color(0xFF323232),
                        contentColor = Color.White,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            )
        }
    }
}

// ---------------- REGISTER SCREEN (إنشاء حساب مستخدم جديد) ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(viewModel: MainViewModel) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    val registerError by viewModel.registerError.collectAsState()

    Scaffold(
        bottomBar = { AppFooter() }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(horizontal = 16.dp, vertical = 24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        DawamiLogo(size = 90.dp)
                        
                        Text(
                            text = "إنشاء حساب مستخدم جديد",
                            color = DawamiNavy,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "يرجى تعيين اسم المستخدم وكلمة المرور لتأمين حسابك عند أول استخدام للبرنامج",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("اسم المستخدم الجديد") },
                            placeholder = { Text("مثال: فيصل") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = DawamiNavy) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("كلمة المرور") },
                            placeholder = { Text("••••••••") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = DawamiNavy) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = confirmPassword,
                            onValueChange = { confirmPassword = it },
                            label = { Text("تأكيد كلمة المرور") },
                            placeholder = { Text("••••••••") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = DawamiNavy) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        if (registerError != null) {
                            Text(
                                text = registerError ?: "",
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = { viewModel.register(username, password, confirmPassword) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "إنشاء الحساب ومتابعة",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = { viewModel.navigateTo(Screen.AppFeaturesGuide) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.5.dp, DawamiNavy.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DawamiNavy)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = DawamiNavy,
                            modifier = Modifier.size(18.dp)
                        )
                        Text("مميزات البرنامج ودليل الاستخدام 💡", color = DawamiNavy, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
