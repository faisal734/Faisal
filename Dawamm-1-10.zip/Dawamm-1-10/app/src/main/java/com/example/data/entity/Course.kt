package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "courses")
data class Course(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val startDate: String, // format: "yyyy-MM-dd"
    val endDate: String,   // format: "yyyy-MM-dd"
    val startTime: String, // format: "HH:mm"
    val endTime: String,   // format: "HH:mm"
    val departmentName: String = "",
    val diplomaName: String = "",
    val trainerName: String = "",
    val isCompleted: Boolean = false
)
