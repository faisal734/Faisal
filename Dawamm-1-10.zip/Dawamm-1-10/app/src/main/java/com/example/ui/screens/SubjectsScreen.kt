package com.example.ui.screens

import android.widget.Toast
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.Course
import com.example.data.entity.Subject
import com.example.data.entity.LessonTopic
import com.example.data.entity.StudentGradeConfig
import com.example.data.entity.Student
import com.example.data.entity.StudentAttendance
import com.example.data.entity.Attendance
import com.example.data.entity.StudentGrade
import com.example.data.entity.CourseSubjectStat
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.GradingViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun SubjectsScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    showMainLayout: Boolean = true
) {
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val courses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val allSubjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()
    val courseSubjects by (courseViewModel?.allCourseSubjects ?: viewModel.dbCourseSubjects).collectAsState()
    val dbAllGradeConfigs by viewModel.dbAllGradeConfigs.collectAsState()
    val allTopics by viewModel.dbLessonTopics.collectAsState()
    val enabledOfficialHolidays by viewModel.enabledOfficialHolidays.collectAsState()
    val context = LocalContext.current

    val subjects = remember(allSubjects, courses, courseSubjects) {
        val list = if (courses.isEmpty()) {
            allSubjects
        } else {
            val linkedSubjectIds = courseSubjects.filter { cs -> courses.any { it.id == cs.courseId } }.map { it.subjectId }.toSet()
            allSubjects.filter { sub ->
                sub.id in linkedSubjectIds || courses.any { c ->
                    (c.departmentName.isNotEmpty() && c.departmentName == sub.departmentName) &&
                    (c.diplomaName.isNotEmpty() && c.diplomaName == sub.diplomaName)
                } || (sub.departmentName.isEmpty() && sub.diplomaName.isEmpty())
            }.ifEmpty { allSubjects }
        }
        list.sortedWith(compareBy<Subject> { StudentGradeConfig.getSubjectRank(it.name) }.thenBy { it.name })
    }

    // 0: Academic Structure (Departments, Diplomas & Subjects)
    // 1: Subjects List & Course Assignment
    // 2: Subject Topics Bank
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var selectedSubjectId by remember { mutableIntStateOf(subjects.firstOrNull()?.id ?: 0) }

    // Academic Structure Tree State
    val departmentsList = remember { mutableStateListOf<DepartmentItem>() }

    LaunchedEffect(allSubjects, dbAllGradeConfigs) {
        if (allSubjects.isNotEmpty()) {
            departmentsList.clear()
            val mapped = allSubjects.groupBy { it.departmentName.ifBlank { "أقسام عامة" } }.map { (deptName, deptSubjects) ->
                DepartmentItem(
                    name = deptName,
                    diplomas = deptSubjects.groupBy { it.diplomaName.ifBlank { "دبلومات وبرامج عامة" } }.map { (diplomaName, diplomaSubjects) ->
                        val cleanDipName = diplomaName.trim()
                        val cleanDeptName = deptName.trim()
                        val dipTemplateId = StudentGradeConfig.getDiplomaTemplateId(cleanDipName)
                        val deptTemplateId = StudentGradeConfig.getDepartmentTemplateId(cleanDeptName)
                        val savedConfig = dbAllGradeConfigs.find { it.courseId == dipTemplateId }
                            ?: dbAllGradeConfigs.find { it.courseId == deptTemplateId }
                        val allConfigFields = if (savedConfig != null && savedConfig.customFieldsJson.isNotBlank()) {
                            StudentGradeConfig.deserializeFields(savedConfig.customFieldsJson)
                        } else emptyList()
                        val customFields = allConfigFields.filter { !it.first.contains("_") }.toMutableList()
                        val subjectWeights = mutableMapOf<String, Double>()
                        if (savedConfig != null) {
                            val rawWeights = savedConfig.getSubjectWeights()
                            diplomaSubjects.forEach { sub ->
                                val cleanSub = sub.name.trim()
                                val w = rawWeights[cleanSub] ?: rawWeights[sub.name]
                                if (w != null && w > 0.0) subjectWeights[sub.name] = w
                            }
                        }
                        DiplomaItem(
                            name = diplomaName,
                            subjects = diplomaSubjects.map { it.name }.distinct().toMutableList(),
                            customFields = customFields,
                            diplomaTotal = savedConfig?.getDiplomaSubjects()?.size?.times(100.0) ?: (diplomaSubjects.size * 100.0),
                            subjectWeights = subjectWeights
                        )
                    }.toMutableList()
                )
            }
            departmentsList.addAll(mapped)
        }
    }

    var expandedDeptNames by remember { mutableStateOf(setOf<String>()) }
    var expandedDiplomaNames by remember { mutableStateOf(setOf<String>()) }

    var newDeptName by remember { mutableStateOf("") }
    var selectedDeptIndexForDiploma by remember { mutableIntStateOf(0) }
    var newDiplomaName by remember { mutableStateOf("") }

    var selectedDiplomaForSubject by remember { mutableStateOf<DiplomaItem?>(null) }
    var newSubjectName by remember { mutableStateOf("") }

    // Dialog state for Department & Diploma Edit and Delete
    var editingDept by remember { mutableStateOf<DepartmentItem?>(null) }
    var deletingDept by remember { mutableStateOf<DepartmentItem?>(null) }
    var editingDiploma by remember { mutableStateOf<Pair<DepartmentItem, DiplomaItem>?>(null) }
    var deletingDiploma by remember { mutableStateOf<Pair<DepartmentItem, DiplomaItem>?>(null) }
    var editingSubjectTarget by remember { mutableStateOf<Triple<DiplomaItem, Int, String>?>(null) }
    var deletingSubjectTarget by remember { mutableStateOf<Triple<DiplomaItem, Int, String>?>(null) }

    // Search and filter state for Tab 1
    var subjectSearchQuery by remember { mutableStateOf("") }
    var selectedDeptFilter by remember { mutableStateOf("الكل") }
    var selectedDiplomaFilter by remember { mutableStateOf("الكل") }

    LaunchedEffect(subjects) {
        if (selectedSubjectId == 0 && subjects.isNotEmpty()) {
            selectedSubjectId = subjects.first().id
        }
    }

    // Dialog States
    var showAddSubjectDialog by remember { mutableStateOf(false) }
    var editingSubject by remember { mutableStateOf<Subject?>(null) }
    var showEditSubjectConfirmDialog by remember { mutableStateOf(false) }
    var subjectToDelete by remember { mutableStateOf<Subject?>(null) }

    var showAddTopicDialog by remember { mutableStateOf(false) }
    var editingTopic by remember { mutableStateOf<LessonTopic?>(null) }
    var parentForNewTopic by remember { mutableStateOf<LessonTopic?>(null) } // if adding Level 2 subtopic
    var topicToDelete by remember { mutableStateOf<LessonTopic?>(null) }

    // States for TXT Import / Export
    var showImportTopicsDialog by remember { mutableStateOf(false) }
    var showExportTopicsDialog by remember { mutableStateOf(false) }
    var importTextState by remember { mutableStateOf("") }
    var clearExistingOnImport by remember { mutableStateOf(false) }

    val selectTxtFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    val fileContent = inputStream.bufferedReader().readText()
                    importTextState = fileContent
                    Toast.makeText(context, "تم قراءة الملف بنجاح! 📄", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "خطأ في قراءة الملف: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    val createTxtFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            try {
                val currentSubject = subjects.find { it.id == selectedSubjectId } ?: subjects.firstOrNull()
                if (currentSubject != null) {
                    val exportContent = viewModel.exportTopicsToText(currentSubject.id)
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(exportContent.toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(context, "تم حفظ الملف بنجاح! 💾", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "فشل حفظ الملف: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // State for expandable main topics in Subject Topics Bank tab
    val expandedBankTopics = remember { mutableStateMapOf<Int, Boolean>() }
    fun isBankTopicExpanded(id: Int) = expandedBankTopics[id] ?: true
    fun toggleBankTopicExpanded(id: Int) { expandedBankTopics[id] = !(expandedBankTopics[id] ?: true) }

    MainLayout(viewModel = viewModel, showScaffold = showMainLayout) { innerPadding ->
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Screen Banner
                Surface(
                    color = if (isDarkTheme) DarkSurface else Color.White,
                    tonalElevation = 2.dp,
                    border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                color = DawamiNavy.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.MenuBook,
                                        contentDescription = null,
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "إدارة المواد وتخصيصها للدورات 📖",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) Color.White else DawamiNavy
                                )
                                Text(
                                    text = "أنشئ المواد الدراسية وثبّت مواضيعها بـ مستويين، وخصصها للدورات بدون إعادة كتابة.",
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Tab Row
                        TabRow(
                            selectedTabIndex = selectedTabIndex,
                            containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9),
                            contentColor = DawamiNavy,
                            indicator = {},
                            divider = {},
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .padding(2.dp)
                        ) {
                            Tab(
                                selected = selectedTabIndex == 0,
                                onClick = { selectedTabIndex = 0 },
                                modifier = Modifier
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (selectedTabIndex == 0) (if (isDarkTheme) DarkSurface else Color.White)
                                        else Color.Transparent
                                    )
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AccountTree,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (selectedTabIndex == 0) DawamiNavy else Color.Gray
                                    )
                                    Text(
                                        text = "الهيكل والأقسام 📚",
                                        fontSize = 11.sp,
                                        fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Medium,
                                        color = if (selectedTabIndex == 0) DawamiNavy else Color.Gray
                                    )
                                }
                            }

                            Tab(
                                selected = selectedTabIndex == 1,
                                onClick = { selectedTabIndex = 1 },
                                modifier = Modifier
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (selectedTabIndex == 1) (if (isDarkTheme) DarkSurface else Color.White)
                                        else Color.Transparent
                                    )
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Category,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (selectedTabIndex == 1) DawamiNavy else Color.Gray
                                    )
                                    Text(
                                        text = "المواد وتعيين الدورات 🔗",
                                        fontSize = 11.sp,
                                        fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Medium,
                                        color = if (selectedTabIndex == 1) DawamiNavy else Color.Gray
                                    )
                                }
                            }

                            Tab(
                                selected = selectedTabIndex == 2,
                                onClick = { selectedTabIndex = 2 },
                                modifier = Modifier
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (selectedTabIndex == 2) (if (isDarkTheme) DarkSurface else Color.White)
                                        else Color.Transparent
                                    )
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MenuBook,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (selectedTabIndex == 2) DawamiNavy else Color.Gray
                                    )
                                    Text(
                                        text = "بنك المواضيع 📑",
                                        fontSize = 11.sp,
                                        fontWeight = if (selectedTabIndex == 2) FontWeight.Bold else FontWeight.Medium,
                                        color = if (selectedTabIndex == 2) DawamiNavy else Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }

                // Main Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (selectedTabIndex == 0) {
                        // --- TAB 0: ACADEMIC STRUCTURE (DEPARTMENTS, DIPLOMAS & SUBJECTS) ---
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Header Stats & Controls
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else Color.White),
                                    border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Surface(
                                                color = DawamiNavy.copy(alpha = 0.12f),
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.size(38.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Icon(Icons.Default.AccountTree, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(20.dp))
                                                }
                                            }
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "الهيكل الأكاديمي للأقسام والدبلومات 📚",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = if (isDarkTheme) Color.White else DawamiNavy
                                                )
                                                Text(
                                                    text = "أضف الأقسام والدبلومات والمواد المقررة، وحدّث مسمياتها بكل سهولة.",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        // Stats counters
                                        val totalDepts = departmentsList.size
                                        val totalDips = departmentsList.sumOf { it.diplomas.size }
                                        val totalSubs = departmentsList.sumOf { d -> d.diplomas.sumOf { it.subjects.size } }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                color = DawamiNavy.copy(alpha = 0.08f),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text("$totalDepts", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DawamiNavy)
                                                    Text("أقسام أكاديمية", fontSize = 10.sp, color = DawamiNavy)
                                                }
                                            }
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                color = DawamiGold.copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text("$totalDips", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFB45309))
                                                    Text("دبلومات وبرامج", fontSize = 10.sp, color = Color(0xFFB45309))
                                                }
                                            }
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                color = DawamiTeal.copy(alpha = 0.1f),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text("$totalSubs", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DawamiTeal)
                                                    Text("مواد مقررة", fontSize = 10.sp, color = DawamiTeal)
                                                }
                                            }
                                        }

                                        // Actions: Expand, Collapse, Save
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = {
                                                    expandedDeptNames = departmentsList.map { it.name }.toSet()
                                                    expandedDiplomaNames = departmentsList.flatMap { dept ->
                                                        dept.diplomas.map { dip -> "${dept.name}_${dip.name}" }
                                                    }.toSet()
                                                },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 6.dp)
                                            ) {
                                                Icon(Icons.Default.UnfoldMore, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("توسيع الكل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    expandedDeptNames = emptySet()
                                                    expandedDiplomaNames = emptySet()
                                                },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 6.dp)
                                            ) {
                                                Icon(Icons.Default.UnfoldLess, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("طي الكل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = {
                                                    viewModel.saveCurriculumStructure(departmentsList) {
                                                        Toast.makeText(context, "تم حفظ وتحديث الهيكل الأكاديمي بنجاح! 💾✨", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                modifier = Modifier.weight(1.2f),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 6.dp)
                                            ) {
                                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("حفظ الهيكل 💾", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            }
                                        }
                                    }
                                }
                            }

                            // Add Department Card
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else Color(0xFFF8FAFC)),
                                    border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedTextField(
                                            value = newDeptName,
                                            onValueChange = { newDeptName = it },
                                            placeholder = { Text("اسم قسم أكاديمي جديد...", fontSize = 11.sp) },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(10.dp),
                                            singleLine = true
                                        )
                                        Button(
                                            onClick = {
                                                if (newDeptName.isNotBlank()) {
                                                    val trimmed = newDeptName.trim()
                                                    if (departmentsList.none { it.name.equals(trimmed, ignoreCase = true) }) {
                                                        departmentsList.add(DepartmentItem(name = trimmed))
                                                        viewModel.saveCurriculumStructure(departmentsList)
                                                        newDeptName = ""
                                                        expandedDeptNames = expandedDeptNames + trimmed
                                                        Toast.makeText(context, "تمت إضافة القسم وحفظه بنجاح! 🏫", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        Toast.makeText(context, "هذا القسم موجود بالفعل", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("إضافة قسم", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            // Departments Tree List
                            items(departmentsList.indices.toList()) { deptIdx ->
                                val dept = departmentsList[deptIdx]
                                val isDeptExpanded = expandedDeptNames.contains(dept.name)

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                                    ),
                                    border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFCBD5E1))
                                ) {
                                    Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        // Department Header Row
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.weight(1f).clickable {
                                                    expandedDeptNames = if (isDeptExpanded) expandedDeptNames - dept.name else expandedDeptNames + dept.name
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = if (isDeptExpanded) Icons.Default.FolderOpen else Icons.Default.Folder,
                                                    contentDescription = null,
                                                    tint = DawamiNavy,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                                Column {
                                                    Text(
                                                        text = dept.name,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = if (isDarkTheme) Color.White else DawamiNavy
                                                    )
                                                    Text(
                                                        text = "${dept.diplomas.size} دبلوم/برنامج • ${dept.diplomas.sumOf { it.subjects.size }} مادة",
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(onClick = { editingDept = dept }, modifier = Modifier.size(28.dp)) {
                                                    Icon(Icons.Default.Edit, contentDescription = "تعديل القسم", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                                                }
                                                IconButton(onClick = { deletingDept = dept }, modifier = Modifier.size(28.dp)) {
                                                    Icon(Icons.Default.Delete, contentDescription = "حذف القسم", tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                                }
                                                IconButton(
                                                    onClick = {
                                                        expandedDeptNames = if (isDeptExpanded) expandedDeptNames - dept.name else expandedDeptNames + dept.name
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (isDeptExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                        contentDescription = null,
                                                        tint = DawamiNavy
                                                    )
                                                }
                                            }
                                        }

                                        // Department Children (Diplomas & Subjects)
                                        AnimatedVisibility(
                                            visible = isDeptExpanded,
                                            enter = expandVertically() + fadeIn(),
                                            exit = shrinkVertically() + fadeOut()
                                        ) {
                                            Column(modifier = Modifier.fillMaxWidth().padding(start = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                dept.diplomas.forEachIndexed { dipIdx, diploma ->
                                                    val dipKey = "${dept.name}_${diploma.name}"
                                                    val isDipExpanded = expandedDiplomaNames.contains(dipKey)

                                                    Card(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        shape = RoundedCornerShape(10.dp),
                                                        colors = CardDefaults.cardColors(
                                                            containerColor = if (isDarkTheme) DarkSurface else Color(0xFFF8FAFC)
                                                        ),
                                                        border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF475569) else Color(0xFFE2E8F0))
                                                    ) {
                                                        Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                            // Diploma Header Row
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Row(
                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                                    modifier = Modifier.weight(1f).clickable {
                                                                        expandedDiplomaNames = if (isDipExpanded) expandedDiplomaNames - dipKey else expandedDiplomaNames + dipKey
                                                                    }
                                                                ) {
                                                                    Icon(Icons.Default.School, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(18.dp))
                                                                    Text(
                                                                        text = diploma.name,
                                                                        fontWeight = FontWeight.Bold,
                                                                        fontSize = 11.5.sp,
                                                                        color = if (isDarkTheme) Color.White else DawamiNavy
                                                                    )
                                                                    Surface(
                                                                        color = DawamiGold.copy(alpha = 0.15f),
                                                                        shape = RoundedCornerShape(4.dp)
                                                                    ) {
                                                                        Text(
                                                                            text = "${diploma.subjects.size} مواد",
                                                                            fontSize = 9.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                            color = Color(0xFFB45309),
                                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                                        )
                                                                    }
                                                                }

                                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                                    IconButton(onClick = { editingDiploma = Pair(dept, diploma) }, modifier = Modifier.size(24.dp)) {
                                                                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = Color(0xFF2563EB), modifier = Modifier.size(14.dp))
                                                                    }
                                                                    IconButton(onClick = { deletingDiploma = Pair(dept, diploma) }, modifier = Modifier.size(24.dp)) {
                                                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp))
                                                                    }
                                                                    IconButton(
                                                                        onClick = {
                                                                            expandedDiplomaNames = if (isDipExpanded) expandedDiplomaNames - dipKey else expandedDiplomaNames + dipKey
                                                                        },
                                                                        modifier = Modifier.size(24.dp)
                                                                    ) {
                                                                        Icon(
                                                                            imageVector = if (isDipExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                                            contentDescription = null,
                                                                            tint = DawamiNavy
                                                                        )
                                                                    }
                                                                }
                                                            }

                                                            // Diploma Subjects List
                                                            AnimatedVisibility(visible = isDipExpanded) {
                                                                Column(modifier = Modifier.fillMaxWidth().padding(start = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                                    diploma.subjects.forEachIndexed { subIdx, subjectName ->
                                                                        Row(
                                                                            modifier = Modifier.fillMaxWidth().background(
                                                                                if (isDarkTheme) Color(0xFF0F172A) else Color.White,
                                                                                RoundedCornerShape(6.dp)
                                                                            ).padding(horizontal = 8.dp, vertical = 4.dp),
                                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                                            verticalAlignment = Alignment.CenterVertically
                                                                        ) {
                                                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                                                Icon(Icons.Default.MenuBook, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(14.dp))
                                                                                Text(subjectName, fontSize = 11.sp, color = if (isDarkTheme) Color.White else Color(0xFF1E293B))
                                                                            }
                                                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                                                IconButton(onClick = { editingSubjectTarget = Triple(diploma, subIdx, subjectName) }, modifier = Modifier.size(20.dp)) {
                                                                                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = Color(0xFF2563EB), modifier = Modifier.size(12.dp))
                                                                                }
                                                                                IconButton(onClick = { deletingSubjectTarget = Triple(diploma, subIdx, subjectName) }, modifier = Modifier.size(20.dp)) {
                                                                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFDC2626), modifier = Modifier.size(12.dp))
                                                                                }
                                                                            }
                                                                        }
                                                                    }

                                                                    // Add Subject to Diploma Input
                                                                    Row(
                                                                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                                        verticalAlignment = Alignment.CenterVertically
                                                                    ) {
                                                                        OutlinedTextField(
                                                                            value = if (selectedDiplomaForSubject == diploma) newSubjectName else "",
                                                                            onValueChange = {
                                                                                selectedDiplomaForSubject = diploma
                                                                                newSubjectName = it
                                                                            },
                                                                            placeholder = { Text("إضافة مادة جديدة للدبلوم...", fontSize = 10.5.sp) },
                                                                            modifier = Modifier.weight(1f),
                                                                            shape = RoundedCornerShape(8.dp),
                                                                            singleLine = true
                                                                        )
                                                                        Button(
                                                                            onClick = {
                                                                                if (newSubjectName.isNotBlank() && selectedDiplomaForSubject == diploma) {
                                                                                    val trimmed = newSubjectName.trim()
                                                                                    if (!diploma.subjects.contains(trimmed)) {
                                                                                        diploma.subjects.add(trimmed)
                                                                                        diploma.subjectWeights[trimmed] = 100.0
                                                                                        viewModel.saveCurriculumStructure(departmentsList)
                                                                                        newSubjectName = ""
                                                                                        selectedDiplomaForSubject = null
                                                                                        Toast.makeText(context, "تمت إضافة المادة وحفظها! 📖", Toast.LENGTH_SHORT).show()
                                                                                    }
                                                                                }
                                                                            },
                                                                            shape = RoundedCornerShape(8.dp),
                                                                            colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                                                        ) {
                                                                            Text("إضافة مادة", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                // Add Diploma to Department Input
                                                Row(
                                                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    OutlinedTextField(
                                                        value = if (selectedDeptIndexForDiploma == deptIdx) newDiplomaName else "",
                                                        onValueChange = {
                                                            selectedDeptIndexForDiploma = deptIdx
                                                            newDiplomaName = it
                                                        },
                                                        placeholder = { Text("إضافة دبلوم جديد لهذا القسم...", fontSize = 10.5.sp) },
                                                        modifier = Modifier.weight(1f),
                                                        shape = RoundedCornerShape(8.dp),
                                                        singleLine = true
                                                    )
                                                    Button(
                                                        onClick = {
                                                            if (newDiplomaName.isNotBlank() && selectedDeptIndexForDiploma == deptIdx) {
                                                                val trimmed = newDiplomaName.trim()
                                                                if (dept.diplomas.none { it.name.equals(trimmed, ignoreCase = true) }) {
                                                                    dept.diplomas.add(DiplomaItem(name = trimmed))
                                                                    viewModel.saveCurriculumStructure(departmentsList)
                                                                    newDiplomaName = ""
                                                                    expandedDiplomaNames = expandedDiplomaNames + "${dept.name}_$trimmed"
                                                                    Toast.makeText(context, "تمت إضافة الدبلوم بنجاح! 🎓", Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        },
                                                        shape = RoundedCornerShape(8.dp),
                                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                                    ) {
                                                        Text("إضافة دبلوم", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else if (selectedTabIndex == 1) {
                        // --- TAB 1: SUBJECTS LIST & COURSE ASSIGNMENT MATRIX ---
                        val allDeptsForFilter = remember(subjects, departmentsList) {
                            listOf("الكل") + (subjects.map { it.departmentName.trim() } + departmentsList.map { it.name.trim() })
                                .filter { it.isNotBlank() && it != "أقسام عامة" }
                                .distinct()
                        }

                        val allDiplomasForFilter = remember(subjects, departmentsList, selectedDeptFilter) {
                            if (selectedDeptFilter == "الكل") {
                                emptyList()
                            } else {
                                val fromSubs = subjects.filter { it.departmentName.trim().equals(selectedDeptFilter.trim(), ignoreCase = true) }.map { it.diplomaName.trim() }
                                val fromDepts = departmentsList.find { it.name.trim().equals(selectedDeptFilter.trim(), ignoreCase = true) }?.diplomas?.map { it.name.trim() } ?: emptyList()
                                listOf("الكل") + (fromSubs + fromDepts).filter { it.isNotBlank() && it != "دبلومات وبرامج عامة" }.distinct()
                            }
                        }

                        val filteredSubjectsForTab1 = remember(subjects, subjectSearchQuery, selectedDeptFilter, selectedDiplomaFilter) {
                            subjects.filter { s ->
                                val matchesSearch = subjectSearchQuery.isBlank() ||
                                        s.name.contains(subjectSearchQuery, ignoreCase = true) ||
                                        s.code.contains(subjectSearchQuery, ignoreCase = true)
                                val matchesDept = selectedDeptFilter == "الكل" || s.departmentName.trim().equals(selectedDeptFilter.trim(), ignoreCase = true)
                                val matchesDip = selectedDiplomaFilter == "الكل" || s.diplomaName.trim().equals(selectedDiplomaFilter.trim(), ignoreCase = true)
                                matchesSearch && matchesDept && matchesDip
                            }
                        }

                        // Search and Filter Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = subjectSearchQuery,
                                onValueChange = { subjectSearchQuery = it },
                                placeholder = { Text("بحث عن مادة بالاسم أو الرمز...", fontSize = 11.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                singleLine = true
                            )

                            Button(
                                onClick = {
                                    editingSubject = null
                                    showAddSubjectDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إضافة مادة ➕", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Department Filter Chips
                        if (allDeptsForFilter.size > 1) {
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(allDeptsForFilter) { deptName ->
                                    FilterChip(
                                        selected = selectedDeptFilter == deptName,
                                        onClick = {
                                            selectedDeptFilter = deptName
                                            selectedDiplomaFilter = "الكل"
                                        },
                                        label = { Text(if (deptName == "الكل") "كل الأقسام" else deptName, fontSize = 10.5.sp) },
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                }
                            }
                        }

                        // Diploma Filter Chips (when a department is chosen)
                        if (allDiplomasForFilter.size > 1) {
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(allDiplomasForFilter) { dipName ->
                                    FilterChip(
                                        selected = selectedDiplomaFilter == dipName,
                                        onClick = { selectedDiplomaFilter = dipName },
                                        label = { Text(if (dipName == "الكل") "كل الدبلومات" else dipName, fontSize = 10.sp) },
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = "قائمة المواد المتاحة وتعيينها للدورات (${filteredSubjectsForTab1.size}):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDarkTheme) Color.White else DawamiNavy
                        )

                        if (filteredSubjectsForTab1.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.LibraryBooks, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(42.dp))
                                    Text("لا توجد مواد مطابقة للبحث", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val subjectChunks = filteredSubjectsForTab1.chunked(2)
                                items(subjectChunks) { rowSubjects ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        rowSubjects.forEach { subject ->
                                            val subjectTopicsCount = allTopics.count { it.subjectId == subject.id }

                                            Box(modifier = Modifier.weight(1.5f)) {
                                                SubjectGridCard(
                                                    subject = subject,
                                                    isDarkTheme = isDarkTheme,
                                                    subjectTopicsCount = subjectTopicsCount,
                                                    courses = courses,
                                                    courseSubjects = courseSubjects,
                                                    viewModel = viewModel,
                                                    context = context,
                                                    onTopicBankClick = {
                                                        selectedSubjectId = subject.id
                                                        selectedTabIndex = 2
                                                    },
                                                    onEditClick = {
                                                        editingSubject = subject
                                                        showAddSubjectDialog = true
                                                    },
                                                    onDeleteClick = {
                                                        subjectToDelete = subject
                                                    }
                                                )
                                            }
                                        }
                                        if (rowSubjects.size < 2) {
                                            Spacer(modifier = Modifier.weight(1.5f))
                                        }
                                    }
                                }
                            }
                        }
                    } else if (selectedTabIndex == 2) {
                        // --- TAB 2: FIXED SUBJECT TOPICS BANK (STRICTLY 2 LEVELS) ---
                        val currentSubject = subjects.find { it.id == selectedSubjectId } ?: subjects.firstOrNull()

                        if (currentSubject == null) {
                            Text("يرجى إضافة مادة دراسية أولاً في التبويب الأول.")
                        } else {
                            // Subject Selector Dropdown
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "اختر المادة الدراسية:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) Color.White else DawamiNavy
                                )

                                var subjectDropdownExpanded by remember { mutableStateOf(false) }
                                Box(modifier = Modifier.weight(1f)) {
                                    OutlinedButton(
                                        onClick = { subjectDropdownExpanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (isDarkTheme) DarkSurface else Color.White
                                        ),
                                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.5f))
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = currentSubject.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = if (isDarkTheme) Color.White else DawamiNavy
                                            )
                                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                                        }
                                    }

                                    DropdownMenu(
                                        expanded = subjectDropdownExpanded,
                                        onDismissRequest = { subjectDropdownExpanded = false }
                                    ) {
                                        subjects.forEach { s ->
                                            DropdownMenuItem(
                                                text = { Text(text = s.name, fontWeight = if (s.id == currentSubject.id) FontWeight.Bold else FontWeight.Normal) },
                                                onClick = {
                                                    selectedSubjectId = s.id
                                                    subjectDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        importTextState = ""
                                        clearExistingOnImport = false
                                        showImportTopicsDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (isDarkTheme) DarkSurface else Color.White
                                    ),
                                    border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.7f)),
                                    contentPadding = PaddingValues(vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Upload,
                                        contentDescription = null,
                                        tint = DawamiTeal,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "استيراد المواضيع 📤",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiTeal
                                    )
                                }

                                OutlinedButton(
                                    onClick = {
                                        showExportTopicsDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (isDarkTheme) DarkSurface else Color.White
                                    ),
                                    border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.7f)),
                                    contentPadding = PaddingValues(vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Download,
                                        contentDescription = null,
                                        tint = if (isDarkTheme) DawamiGold else Color(0xFFB45309),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "تصدير وتعديل 📥",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDarkTheme) DawamiGold else Color(0xFFB45309)
                                    )
                                }
                            }

                            val subjectTopics = allTopics.filter { it.subjectId == currentSubject.id }
                            val mainTopics = subjectTopics.filter { it.level == 1 || it.parentId == null }

                            // Subject Header & Add Main Topic Button
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "مواضيع مادة (${currentSubject.name}) - مستويين:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) Color.White else DawamiNavy,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 2
                                )

                                Spacer(modifier = Modifier.width(6.dp))

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (mainTopics.any { mainTopic -> subjectTopics.any { it.parentId == mainTopic.id && it.level == 2 } }) {
                                        val allExpanded = mainTopics.all { isBankTopicExpanded(it.id) }
                                        OutlinedButton(
                                            onClick = {
                                                val targetState = !allExpanded
                                                mainTopics.forEach { expandedBankTopics[it.id] = targetState }
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (allExpanded) Icons.Default.UnfoldLess else Icons.Default.UnfoldMore,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = if (allExpanded) "طي الكل" else "توسيع الكل",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            editingTopic = null
                                            parentForNewTopic = null
                                            showAddTopicDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text("موضوع رئيسي", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    }
                                }
                            }

                            if (mainTopics.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "لا توجد مواضيع في بنك مادة '${currentSubject.name}' بعد.\nاضغط على 'موضوع رئيسي' لإضافة محاور المنهج.",
                                        fontSize = 11.sp,
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(mainTopics, key = { it.id }) { mainTopic ->
                                        val subTopics = subjectTopics.filter { it.parentId == mainTopic.id && it.level == 2 }
                                        val isExpanded = isBankTopicExpanded(mainTopic.id)

                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isDarkTheme) DarkSurface else Color.White
                                            ),
                                            border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f))
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                // Level 1: Main Topic Header
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable(enabled = subTopics.isNotEmpty()) {
                                                            toggleBankTopicExpanded(mainTopic.id)
                                                        },
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Surface(
                                                            color = Color(0xFF1E3A8A),
                                                            shape = RoundedCornerShape(4.dp)
                                                        ) {
                                                            Text(
                                                                text = "م1 رئيسي",
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color.White,
                                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                            )
                                                        }

                                                        Text(
                                                            text = mainTopic.title,
                                                            fontSize = 13.5.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (isDarkTheme) Color.White else DawamiNavy
                                                        )

                                                        if (subTopics.isNotEmpty()) {
                                                            Surface(
                                                                color = Color(0xFF0284C7).copy(alpha = 0.12f),
                                                                shape = RoundedCornerShape(10.dp)
                                                            ) {
                                                                Text(
                                                                    text = "${subTopics.size} فرعي",
                                                                    fontSize = 9.5.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = Color(0xFF0284C7),
                                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                                )
                                                            }
                                                        }
                                                    }

                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                                    ) {
                                                        // Add Sub-topic (Level 2) button
                                                        IconButton(
                                                            onClick = {
                                                                editingTopic = null
                                                                parentForNewTopic = mainTopic
                                                                showAddTopicDialog = true
                                                            }
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.AddCircleOutline,
                                                                contentDescription = "فرع مستوى 2",
                                                                tint = DawamiTeal,
                                                                modifier = Modifier.size(20.dp)
                                                            )
                                                        }
                                                        IconButton(
                                                            onClick = {
                                                                editingTopic = mainTopic
                                                                parentForNewTopic = null
                                                                showAddTopicDialog = true
                                                            }
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.Edit,
                                                                contentDescription = "تعديل",
                                                                tint = Color(0xFF2563EB),
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                        }
                                                        IconButton(
                                                            onClick = {
                                                                topicToDelete = mainTopic
                                                            }
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.Delete,
                                                                contentDescription = "حذف",
                                                                tint = Color(0xFFDC2626),
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                        }

                                                        if (subTopics.isNotEmpty()) {
                                                            IconButton(
                                                                onClick = { toggleBankTopicExpanded(mainTopic.id) }
                                                            ) {
                                                                Icon(
                                                                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                                    contentDescription = if (isExpanded) "طي" else "توسيع",
                                                                    tint = if (isDarkTheme) Color.White else DawamiNavy,
                                                                    modifier = Modifier.size(20.dp)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }

                                                if (mainTopic.description.isNotEmpty()) {
                                                    Text(
                                                        text = mainTopic.description,
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }

                                                // Level 2 Subtopics List
                                                if (subTopics.isNotEmpty()) {
                                                    AnimatedVisibility(
                                                        visible = isExpanded,
                                                        enter = fadeIn() + expandVertically(),
                                                        exit = fadeOut() + shrinkVertically()
                                                    ) {
                                                        Column(
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .padding(start = 12.dp),
                                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                                        ) {
                                                            subTopics.forEach { subTopic ->
                                                                Surface(
                                                                    modifier = Modifier.fillMaxWidth(),
                                                                    color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC),
                                                                    shape = RoundedCornerShape(8.dp),
                                                                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                                                                ) {
                                                                    Row(
                                                                        modifier = Modifier
                                                                            .fillMaxWidth()
                                                                            .padding(8.dp),
                                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                                        verticalAlignment = Alignment.CenterVertically
                                                                    ) {
                                                                        Row(
                                                                            verticalAlignment = Alignment.CenterVertically,
                                                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                                            modifier = Modifier.weight(1f)
                                                                        ) {
                                                                            Surface(
                                                                                color = Color(0xFF0284C7),
                                                                                shape = RoundedCornerShape(4.dp)
                                                                            ) {
                                                                                Text(
                                                                                    text = "م2 فرعي",
                                                                                    fontSize = 8.5.sp,
                                                                                    fontWeight = FontWeight.Bold,
                                                                                    color = Color.White,
                                                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                                                )
                                                                            }

                                                                            Text(
                                                                                text = subTopic.title,
                                                                                fontSize = 11.sp,
                                                                                fontWeight = FontWeight.Medium,
                                                                                color = if (isDarkTheme) Color.White else DawamiNavy
                                                                            )
                                                                        }

                                                                        Row {
                                                                            IconButton(
                                                                                onClick = {
                                                                                    editingTopic = subTopic
                                                                                    parentForNewTopic = mainTopic
                                                                                    showAddTopicDialog = true
                                                                                }
                                                                            ) {
                                                                                Icon(
                                                                                    imageVector = Icons.Default.Edit,
                                                                                    contentDescription = "تعديل",
                                                                                    tint = Color(0xFF2563EB),
                                                                                    modifier = Modifier.size(15.dp)
                                                                                )
                                                                            }
                                                                            IconButton(
                                                                                onClick = {
                                                                                    topicToDelete = subTopic
                                                                                }
                                                                            ) {
                                                                                Icon(
                                                                                    imageVector = Icons.Default.Delete,
                                                                                    contentDescription = "حذف",
                                                                                    tint = Color(0xFFDC2626),
                                                                                    modifier = Modifier.size(15.dp)
                                                                                )
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- ACADEMIC TREE EDIT / DELETE DIALOGS ---

    // Edit Department Dialog
    if (editingDept != null) {
        val currentDept = editingDept!!
        var tempName by remember(currentDept) { mutableStateOf(currentDept.name) }
        AlertDialog(
            onDismissRequest = { editingDept = null },
            title = { Text("تعديل اسم القسم الأكاديمي ✏️", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DawamiNavy) },
            text = {
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text("اسم القسم الأكاديمي") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = tempName.trim()
                        if (trimmed.isNotBlank()) {
                            currentDept.name = trimmed
                            viewModel.saveCurriculumStructure(departmentsList)
                            editingDept = null
                            Toast.makeText(context, "تم تعديل اسم القسم وتحديث مواده بنجاح! ✏️✅", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ التعديل", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingDept = null }) { Text("إلغاء") }
            }
        )
    }

    // Delete Department Dialog
    if (deletingDept != null) {
        val currentDept = deletingDept!!
        AlertDialog(
            onDismissRequest = { deletingDept = null },
            title = { Text("حذف القسم الأكاديمي 🗑️", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626)) },
            text = { Text("هل أنت متأكد من حذف قسم '${currentDept.name}' وجميع دبلوماته ومواده التابعة؟") },
            confirmButton = {
                Button(
                    onClick = {
                        departmentsList.remove(currentDept)
                        viewModel.saveCurriculumStructure(departmentsList)
                        deletingDept = null
                        Toast.makeText(context, "تم حذف القسم بنجاح 👍", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("تأكيد الحذف", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingDept = null }) { Text("إلغاء") }
            }
        )
    }

    // Edit Diploma Dialog
    if (editingDiploma != null) {
        val (dept, dip) = editingDiploma!!
        var tempName by remember(dip) { mutableStateOf(dip.name) }
        AlertDialog(
            onDismissRequest = { editingDiploma = null },
            title = { Text("تعديل اسم الدبلوم / البرنامج ✏️", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DawamiNavy) },
            text = {
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text("اسم الدبلوم") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = tempName.trim()
                        if (trimmed.isNotBlank()) {
                            dip.name = trimmed
                            viewModel.saveCurriculumStructure(departmentsList)
                            editingDiploma = null
                            Toast.makeText(context, "تم تعديل اسم الدبلوم! ✏️", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ التعديل", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingDiploma = null }) { Text("إلغاء") }
            }
        )
    }

    // Delete Diploma Dialog
    if (deletingDiploma != null) {
        val (dept, dip) = deletingDiploma!!
        AlertDialog(
            onDismissRequest = { deletingDiploma = null },
            title = { Text("حذف الدبلوم / البرنامج 🗑️", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626)) },
            text = { Text("هل أنت متأكد من حذف دبلوم '${dip.name}' ومواده التابعة؟") },
            confirmButton = {
                Button(
                    onClick = {
                        dept.diplomas.remove(dip)
                        viewModel.saveCurriculumStructure(departmentsList)
                        deletingDiploma = null
                        Toast.makeText(context, "تم حذف الدبلوم بنجاح 👍", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("تأكيد الحذف", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingDiploma = null }) { Text("إلغاء") }
            }
        )
    }

    // Edit Subject Dialog in Tree
    if (editingSubjectTarget != null) {
        val (dip, idx, oldSub) = editingSubjectTarget!!
        var tempName by remember(oldSub) { mutableStateOf(oldSub) }
        AlertDialog(
            onDismissRequest = { editingSubjectTarget = null },
            title = { Text("تعديل اسم المادة المقررة ✏️", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DawamiNavy) },
            text = {
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text("اسم المادة") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = tempName.trim()
                        if (trimmed.isNotBlank()) {
                            val existing = viewModel.dbSubjects.value.find { 
                                it.name == oldSub && (it.diplomaName == dip.name || it.diplomaName.isBlank()) 
                            }
                            if (existing != null) {
                                viewModel.updateSubject(existing.copy(name = trimmed))
                            }
                            dip.subjects[idx] = trimmed
                            val w = dip.subjectWeights.remove(oldSub)
                            if (w != null) dip.subjectWeights[trimmed] = w
                            viewModel.saveCurriculumStructure(departmentsList)
                            editingSubjectTarget = null
                            Toast.makeText(context, "تم تحديث اسم المادة! ✏️", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ التعديل", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingSubjectTarget = null }) { Text("إلغاء") }
            }
        )
    }

    // Delete Subject Dialog in Tree
    if (deletingSubjectTarget != null) {
        val (dip, idx, oldSub) = deletingSubjectTarget!!
        AlertDialog(
            onDismissRequest = { deletingSubjectTarget = null },
            title = { Text("حذف المادة المقررة 🗑️", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626)) },
            text = { Text("هل أنت متأكد من حذف مادة '$oldSub' من هذا الدبلوم؟") },
            confirmButton = {
                Button(
                    onClick = {
                        dip.subjects.remove(oldSub)
                        dip.subjectWeights.remove(oldSub)
                        viewModel.saveCurriculumStructure(departmentsList)
                        deletingSubjectTarget = null
                        Toast.makeText(context, "تم حذف المادة بنجاح 👍", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("تأكيد الحذف", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingSubjectTarget = null }) { Text("إلغاء") }
            }
        )
    }

    // --- DIALOGS ---

    // 0. Deletion Confirmation Dialogs
    if (subjectToDelete != null) {
        AlertDialog(
            onDismissRequest = { subjectToDelete = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626))
                    Text(
                        text = "تأكيد حذف المادة الدراسية ⚠️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Text(
                    text = "هل أنت تأكد من رغبتك في حذف المادة الدراسية:\n\"${subjectToDelete?.name}\"؟",
                    fontSize = 12.5.sp,
                    color = if (isDarkTheme) Color.White else Color.DarkGray
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val s = subjectToDelete
                        subjectToDelete = null
                        if (s != null) {
                            viewModel.deleteSubject(s)
                            Toast.makeText(context, "تم حذف المادة بنجاح", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("حذف المادة", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { subjectToDelete = null }) {
                    Text("إلغاء", color = DawamiNavy)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = if (isDarkTheme) DarkSurface else Color.White
        )
    }

    if (topicToDelete != null) {
        AlertDialog(
            onDismissRequest = { topicToDelete = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626))
                    Text(
                        text = "تأكيد حذف الموضوع ⚠️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Text(
                    text = "هل أنت تأكد من رغبتك في حذف الموضوع:\n\"${topicToDelete?.title}\"؟",
                    fontSize = 12.5.sp,
                    color = if (isDarkTheme) Color.White else Color.DarkGray
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val t = topicToDelete
                        topicToDelete = null
                        if (t != null) {
                            viewModel.deleteLessonTopic(t)
                            Toast.makeText(context, "تم حذف الموضوع بنجاح", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("حذف الموضوع", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { topicToDelete = null }) {
                    Text("إلغاء", color = DawamiNavy)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = if (isDarkTheme) DarkSurface else Color.White
        )
    }

    // 1. Add / Edit Subject Dialog
    if (showAddSubjectDialog) {
        var nameInput by remember { mutableStateOf(editingSubject?.name ?: "") }
        var codeInput by remember { mutableStateOf(editingSubject?.code ?: "") }
        var descInput by remember { mutableStateOf(editingSubject?.description ?: "") }
        var deptInput by remember { mutableStateOf(editingSubject?.departmentName ?: "") }
        var dipInput by remember { mutableStateOf(editingSubject?.diplomaName ?: "") }
        var deptMenuExpanded by remember { mutableStateOf(false) }
        var dipMenuExpanded by remember { mutableStateOf(false) }

        val availableDepts = remember(departmentsList, subjects) {
            (departmentsList.map { it.name.trim() } + subjects.map { it.departmentName.trim() })
                .filter { it.isNotBlank() && it != "أقسام عامة" }
                .distinct()
        }

        val availableDiplomas = remember(departmentsList, subjects, deptInput) {
            val fromDept = departmentsList.find { it.name.trim().equals(deptInput.trim(), ignoreCase = true) }?.diplomas?.map { it.name.trim() } ?: emptyList()
            val fromSubjects = subjects.filter { it.departmentName.trim().equals(deptInput.trim(), ignoreCase = true) }.map { it.diplomaName.trim() }
            (fromDept + fromSubjects).filter { it.isNotBlank() && it != "دبلومات وبرامج عامة" }.distinct()
        }

        AlertDialog(
            onDismissRequest = { showAddSubjectDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Book, contentDescription = null, tint = DawamiNavy)
                    Text(
                        text = if (editingSubject == null) "إضافة مادة دراسية جديدة 📖" else "تعديل المادة الدراسية ✏️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("اسم المادة الدراسية *") },
                        placeholder = { Text("مثال: الرياضيات، اللغة العربية...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it },
                        label = { Text("رمز المادة (اختياري)") },
                        placeholder = { Text("مثال: MATH101") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    // Department selection & input
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = deptInput,
                            onValueChange = { deptInput = it },
                            label = { Text("القسم الأكاديمي (اختياري)") },
                            placeholder = { Text("اختر أو اكتب اسم القسم...") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true,
                            trailingIcon = {
                                if (availableDepts.isNotEmpty()) {
                                    IconButton(onClick = { deptMenuExpanded = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = "قائمة الأقسام")
                                    }
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = deptMenuExpanded,
                            onDismissRequest = { deptMenuExpanded = false }
                        ) {
                            availableDepts.forEach { deptName ->
                                DropdownMenuItem(
                                    text = { Text(deptName) },
                                    onClick = {
                                        deptInput = deptName
                                        deptMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Diploma selection & input
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = dipInput,
                            onValueChange = { dipInput = it },
                            label = { Text("الدبلوم / البرنامج (اختياري)") },
                            placeholder = { Text("اختر أو اكتب اسم الدبلوم...") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true,
                            trailingIcon = {
                                if (availableDiplomas.isNotEmpty()) {
                                    IconButton(onClick = { dipMenuExpanded = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = "قائمة الدبلومات")
                                    }
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = dipMenuExpanded,
                            onDismissRequest = { dipMenuExpanded = false }
                        ) {
                            availableDiplomas.forEach { dipName ->
                                DropdownMenuItem(
                                    text = { Text(dipName) },
                                    onClick = {
                                        dipInput = dipName
                                        dipMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("وصف المادة (اختياري)") },
                        placeholder = { Text("أدخل وصف اختصاري للمادة...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nameInput.isBlank()) {
                            Toast.makeText(context, "الرجاء أدخل اسم المادة الدراسية", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (editingSubject == null) {
                            viewModel.addSubject(
                                name = nameInput.trim(),
                                code = codeInput.trim(),
                                description = descInput.trim(),
                                departmentName = deptInput.trim(),
                                diplomaName = dipInput.trim()
                            )
                            Toast.makeText(context, "تمت إضافة المادة بنجاح 👍", Toast.LENGTH_SHORT).show()
                            showAddSubjectDialog = false
                        } else {
                            showEditSubjectConfirmDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ المادة", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddSubjectDialog = false }) {
                    Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = if (isDarkTheme) DarkSurface else Color.White
        )

        if (showEditSubjectConfirmDialog && editingSubject != null) {
            AlertDialog(
                onDismissRequest = { showEditSubjectConfirmDialog = false },
                title = {
                    Text(
                        text = "تأكيد تعديل المادة الدراسية 📖",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = DawamiNavy
                    )
                },
                text = {
                    Text(
                        text = "هل أنت متأكد من رغبتك في حفظ التعديلات الجديدة على مادة '${editingSubject?.name}'؟",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.updateSubject(
                                editingSubject!!.copy(
                                    name = nameInput.trim(),
                                    code = codeInput.trim(),
                                    description = descInput.trim(),
                                    departmentName = deptInput.trim(),
                                    diplomaName = dipInput.trim()
                                )
                            )
                            Toast.makeText(context, "تم تحديث المادة بنجاح 👍", Toast.LENGTH_SHORT).show()
                            showEditSubjectConfirmDialog = false
                            showAddSubjectDialog = false
                        }
                    ) {
                        Text("تأكيد وحفظ", color = DawamiNavy, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showEditSubjectConfirmDialog = false }
                    ) {
                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                shape = RoundedCornerShape(10.dp),
                containerColor = MaterialTheme.colorScheme.surface
            )
        }
    }

    // --- IMPORT TOPICS DIALOG ---
    if (showImportTopicsDialog && selectedSubjectId != 0) {
        val currentSubject = subjects.find { it.id == selectedSubjectId } ?: subjects.firstOrNull()
        if (currentSubject != null) {
            AlertDialog(
                onDismissRequest = { showImportTopicsDialog = false },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Upload, contentDescription = null, tint = DawamiTeal)
                        Text(
                            text = "استيراد مواضيع مادة: ${currentSubject.name}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (isDarkTheme) Color.White else DawamiNavy
                        )
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                    ) {
                        Surface(
                            color = DawamiTeal.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "تنسيق النص المدعوم 📄:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiTeal
                                )
                                Text(
                                    text = "- السطر العادي يمثل موضوعاً رئيسياً (مستوى 1).\n- السطر الذي يبدأ بـ (-) يمثل موضوعاً فرعياً (مستوى 2) يتبع لآخر موضوع رئيسي تم تعريفه.",
                                    fontSize = 10.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "مثال:\nمقدمة في التقنية\n- تعريف الحاسب\n- أنظمة التشغيل\nتطبيقات الأوفيس\n- برنامج الوورد",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.Gray
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    selectTxtFileLauncher.launch(arrayOf("text/plain", "*/*"))
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isDarkTheme) DarkSurface else Color.White
                                ),
                                border = BorderStroke(1.dp, DawamiTeal),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(imageVector = Icons.Default.Attachment, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("اختر ملف TXT", fontSize = 11.sp)
                            }
                        }

                        OutlinedTextField(
                            value = importTextState,
                            onValueChange = { importTextState = it },
                            label = { Text("أو الصق النص هنا مباشرة 👇") },
                            placeholder = { Text("الصق محتوى المواضيع هنا...") },
                            modifier = Modifier.fillMaxWidth().height(160.dp),
                            textStyle = TextStyle(fontSize = 11.sp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = DawamiTeal,
                                focusedLabelColor = DawamiTeal
                            )
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { clearExistingOnImport = !clearExistingOnImport }
                        ) {
                            Checkbox(
                                checked = clearExistingOnImport,
                                onCheckedChange = { clearExistingOnImport = it },
                                colors = CheckboxDefaults.colors(checkedColor = DawamiTeal)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "حذف كافة مواضيع المادة الحالية قبل الاستيراد (استبدال كامل)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (clearExistingOnImport) Color.Red else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.importTopicsFromText(
                                subjectId = currentSubject.id,
                                text = importTextState,
                                clearExisting = clearExistingOnImport
                            ) { success, count ->
                                if (success) {
                                    Toast.makeText(context, "تم استيراد $count موضوع بنجاح! 🎉", Toast.LENGTH_LONG).show()
                                    showImportTopicsDialog = false
                                } else {
                                    Toast.makeText(context, "فشل الاستيراد، يرجى التحقق من الملف/النص ❌", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal)
                    ) {
                        Text("بدء الاستيراد 📥", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showImportTopicsDialog = false }) {
                        Text("إلغاء")
                    }
                },
                shape = RoundedCornerShape(18.dp),
                containerColor = if (isDarkTheme) DarkSurface else Color.White
            )
        }
    }

    // --- EXPORT TOPICS DIALOG ---
    if (showExportTopicsDialog && selectedSubjectId != 0) {
        val currentSubject = subjects.find { it.id == selectedSubjectId } ?: subjects.firstOrNull()
        if (currentSubject != null) {
            val exportContent = remember(showExportTopicsDialog) { viewModel.exportTopicsToText(currentSubject.id) }

            AlertDialog(
                onDismissRequest = { showExportTopicsDialog = false },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = if (isDarkTheme) DawamiGold else Color(0xFFB45309))
                        Text(
                            text = "تصدير وتعديل مواضيع مادة: ${currentSubject.name}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (isDarkTheme) Color.White else DawamiNavy
                        )
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = "يمكنك نسخ المواضيع وتعديلها في أي مكان، أو حفظها كملف ومشاركتها لرفعها مرة أخرى.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                            modifier = Modifier.fillMaxWidth().height(160.dp)
                        ) {
                            Box(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = exportContent.ifEmpty { "(لا توجد مواضيع لتصديرها)" },
                                    fontSize = 11.5.sp,
                                    modifier = Modifier.verticalScroll(rememberScrollState())
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
                            val annotatedString = androidx.compose.ui.text.buildAnnotatedString { append(exportContent) }
                            OutlinedButton(
                                onClick = {
                                    if (exportContent.isNotEmpty()) {
                                        clipboardManager.setText(annotatedString)
                                        Toast.makeText(context, "تم نسخ النص إلى الحافظة! 📋", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("نسخ النص", fontSize = 11.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    if (exportContent.isNotEmpty()) {
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_TEXT, exportContent)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة مواضيع المادة"))
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("مشاركة 🔗", fontSize = 11.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (exportContent.isNotEmpty()) {
                                createTxtFileLauncher.launch("مواضيع_${currentSubject.name}.txt")
                            } else {
                                Toast.makeText(context, "لا توجد مواضيع لتصديرها!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isDarkTheme) DawamiGold else Color(0xFFB45309))
                    ) {
                        Text("حفظ كملف TXT 💾", fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.Black else Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showExportTopicsDialog = false }) {
                        Text("إغلاق")
                    }
                },
                shape = RoundedCornerShape(18.dp),
                containerColor = if (isDarkTheme) DarkSurface else Color.White
            )
        }
    }

    // 2. Add / Edit Subject Topic Dialog (Level 1 or Level 2 only)
    if (showAddTopicDialog && selectedSubjectId != 0) {
        var titleInput by remember { mutableStateOf(editingTopic?.title ?: "") }
        var descInput by remember { mutableStateOf(editingTopic?.description ?: "") }

        val targetLevel = if (parentForNewTopic != null) 2 else 1

        AlertDialog(
            onDismissRequest = { showAddTopicDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.AccountTree, contentDescription = null, tint = DawamiNavy)
                    Text(
                        text = when {
                            editingTopic != null -> "تعديل موضوع المادة (مستوى $targetLevel) ✏️"
                            parentForNewTopic != null -> "إضافة موضوع فرعي (مستوى 2) لـ '${parentForNewTopic!!.title}' 🌿"
                            else -> "إضافة موضوع رئيسي (مستوى 1) ➕"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (parentForNewTopic != null) {
                        Surface(
                            color = DawamiGold.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "الموضوع الرئيسي: ${parentForNewTopic!!.title} ➔ سيتم إضافة موضوع فرعي (مستوى 2)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text(if (targetLevel == 1) "عنوان الموضوع الرئيسي (مستوى 1) *" else "عنوان الموضوع الفرعي (مستوى 2) *") },
                        placeholder = {
                            Text(if (targetLevel == 1) "مثال: الباب الأول - المعاملات والعمليات" else "مثال: الدرس 1.1 - العمليات الحسابية")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("تفاصيل أو ملاحظات الشرح (اختياري)") },
                        placeholder = { Text("أدخل تفاصيل إضافية...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (titleInput.isBlank()) {
                            Toast.makeText(context, "الرجاء أدخل عنوان الموضوع", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (editingTopic == null) {
                            viewModel.addLessonTopic(
                                subjectId = selectedSubjectId,
                                title = titleInput,
                                description = descInput,
                                parentId = parentForNewTopic?.id,
                                level = targetLevel
                            )
                            Toast.makeText(context, "تمت إضافة الموضوع (مستوى $targetLevel) بنجاح 👍", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.updateLessonTopic(
                                editingTopic!!.copy(
                                    title = titleInput.trim(),
                                    description = descInput.trim()
                                )
                            )
                            Toast.makeText(context, "تم تحديث الموضوع بنجاح 👍", Toast.LENGTH_SHORT).show()
                        }
                        showAddTopicDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ الموضوع", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTopicDialog = false }) {
                    Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = if (isDarkTheme) DarkSurface else Color.White
        )
    }
}

@Composable
fun SubjectGridCard(
    subject: Subject,
    isDarkTheme: Boolean,
    subjectTopicsCount: Int,
    courses: List<Course>,
    courseSubjects: List<com.example.data.entity.CourseSubjectCrossRef>,
    viewModel: MainViewModel,
    context: android.content.Context,
    onTopicBankClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDarkTheme) DarkSurface else Color.White
        ),
        border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header Row (Always visible)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = DawamiTeal.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = subject.name.take(1),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = DawamiTeal
                            )
                        }
                    }
                    Column {
                        Text(
                            text = subject.name,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDarkTheme) Color.White else DawamiNavy,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (subject.code.isNotEmpty()) {
                                Text(
                                    text = "رمز: ${subject.code}",
                                    fontSize = 9.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (subject.departmentName.isNotBlank() && subject.departmentName != "أقسام عامة") {
                                Surface(
                                    color = DawamiNavy.copy(alpha = 0.08f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = subject.departmentName,
                                        fontSize = 8.5.sp,
                                        color = DawamiNavy,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            if (subject.diplomaName.isNotBlank() && subject.diplomaName != "دبلومات وبرامج عامة") {
                                Surface(
                                    color = DawamiTeal.copy(alpha = 0.08f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = subject.diplomaName,
                                        fontSize = 8.5.sp,
                                        color = DawamiTeal,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "تقليص" else "توسيع",
                    tint = DawamiNavy,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Expanded content with clean animations
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (subject.description.isNotEmpty()) {
                        Text(
                            text = subject.description,
                            fontSize = 10.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Topics Summary Badge & Navigation to bank
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            color = Color(0xFFEFF6FF),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "📚 المواضيع: $subjectTopicsCount",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1D4ED8),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        // Quick action buttons (Edit, Delete, Topics bank)
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(
                                onClick = onTopicBankClick,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountTree,
                                    contentDescription = "بنك المواضيع",
                                    tint = DawamiNavy,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(
                                onClick = onEditClick,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "تعديل",
                                    tint = Color(0xFF2563EB),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(
                                onClick = onDeleteClick,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "حذف",
                                    tint = Color(0xFFDC2626),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Divider(color = if (isDarkTheme) Color(0xFF334155) else Color(0xFFF1F5F9))

                    // Course Assignment Switcher
                    Text(
                        text = "تعيين للدورات:",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDarkTheme) Color.White else DawamiNavy
                    )

                    if (courses.isEmpty()) {
                        Text(
                            text = "لا توجد دورات مضافة للنظام بعد.",
                            fontSize = 9.5.sp,
                            color = Color.Gray
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            courses.forEach { course ->
                                val isAssigned = courseSubjects.any { it.subjectId == subject.id && it.courseId == course.id }
                                val assignment = courseSubjects.find { it.subjectId == subject.id && it.courseId == course.id }
                                val isCourseCompleted = course.isCompleted
                                val currentTargetDays = if (assignment != null && assignment.targetDays > 0) {
                                    assignment.targetDays
                                } else if (isCourseCompleted) {
                                    assignment?.targetDays ?: 0
                                } else {
                                    5
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(
                                            if (isAssigned) DawamiNavy.copy(alpha = 0.08f)
                                            else Color.Transparent
                                        )
                                        .padding(horizontal = 4.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                viewModel.toggleSubjectCourseAssignment(
                                                    course.id,
                                                    subject.id,
                                                    defaultDays = if (isCourseCompleted) 0 else 5
                                                )
                                            }
                                            .padding(vertical = 4.dp)
                                    ) {
                                        Checkbox(
                                            checked = isAssigned,
                                            onCheckedChange = null,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Text(
                                            text = course.name + if (isCourseCompleted) " (منتهية)" else "",
                                            fontSize = 10.sp,
                                            fontWeight = if (isAssigned) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isCourseCompleted) Color.Gray else if (isDarkTheme) Color.White else DawamiNavy,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    if (isAssigned) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                                        ) {
                                            var daysText by remember(assignment?.targetDays, currentTargetDays) {
                                                mutableStateOf(currentTargetDays.toString())
                                            }

                                            BasicTextField(
                                                value = daysText,
                                                onValueChange = { newValue ->
                                                    if (newValue.all { char -> char.isDigit() }) {
                                                        daysText = newValue
                                                        val days = newValue.toIntOrNull() ?: 0
                                                        viewModel.updateCourseSubjectStatus(
                                                            courseId = course.id,
                                                            subjectId = subject.id,
                                                            newStatus = assignment?.status ?: "قيد التدريس",
                                                            targetDays = days
                                                        )
                                                    }
                                                },
                                                modifier = Modifier
                                                    .width(36.dp)
                                                    .background(if (isDarkTheme) Color(0xFF1E293B) else Color.White, RoundedCornerShape(4.dp))
                                                    .border(1.dp, if (isDarkTheme) Color(0xFF475569) else Color(0xFFCBD5E1), RoundedCornerShape(4.dp))
                                                    .padding(vertical = 2.dp),
                                                textStyle = TextStyle(
                                                    fontSize = 9.sp,
                                                    textAlign = TextAlign.Center,
                                                    color = if (isDarkTheme) Color.White else DawamiNavy,
                                                    fontWeight = FontWeight.Bold
                                                ),
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                singleLine = true
                                            )
                                            Text("يوم", fontSize = 8.sp, color = Color.Gray)

                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = "معين",
                                                tint = Color(0xFF16A34A),
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AssignmentManagementSection(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    gradingViewModel: GradingViewModel? = null,
    isDarkTheme: Boolean
) {
    val context = LocalContext.current
    val subjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()
    val courses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val allStudents by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val assignmentTemplates by (gradingViewModel?.allAssignmentTemplates ?: viewModel.dbAssignmentTemplates).collectAsState()
    val assignmentSubmissions by (gradingViewModel?.allAssignmentSubmissions ?: viewModel.dbAssignmentSubmissions).collectAsState()
    val subjectReferences by (courseViewModel?.allSubjectReferences ?: viewModel.dbSubjectReferences).collectAsState()

    val trainerBaseDirUri by viewModel.trainerBaseDirUri.collectAsState()
    val trainerBaseDirName by viewModel.trainerBaseDirName.collectAsState()

    var selectedSubjectForSetup by remember { mutableStateOf<String?>(subjects.firstOrNull()?.name ?: "ميكروسوفت وورد") }
    var showAddEditTemplateDialog by remember { mutableStateOf(false) }
    var editingTemplate by remember { mutableStateOf<com.example.data.entity.SubjectAssignmentTemplate?>(null) }
    var tempAttachmentPath by remember { mutableStateOf("") }
    var tempAttachmentName by remember { mutableStateOf("") }
    var viewingTemplateDetails by remember { mutableStateOf<com.example.data.entity.SubjectAssignmentTemplate?>(null) }
    var previewingImageAttachment by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showSharingDialog by remember { mutableStateOf(false) }
    var sharingTemplate by remember { mutableStateOf<com.example.data.entity.SubjectAssignmentTemplate?>(null) }
    var templateToDelete by remember { mutableStateOf<com.example.data.entity.SubjectAssignmentTemplate?>(null) }
    var setupScopeType by remember { mutableStateOf("GLOBAL") } // "GLOBAL" or "COURSE"
    var selectedCourseForSetup by remember { mutableStateOf<com.example.data.entity.Course?>(courses.firstOrNull()) }

    val selectAttachmentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val copied = handleFileSelection(context, uri, isReference = false, baseDirUriString = trainerBaseDirUri)
            if (copied != null) {
                tempAttachmentPath = copied.first
                tempAttachmentName = copied.second
                Toast.makeText(context, "تم إرفاق الملف بنجاح! 📎", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "فشل نسخ الملف، يرجى المحاولة مرة أخرى.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    var selectedCourseForCheck by remember { mutableStateOf<com.example.data.entity.Course?>(courses.firstOrNull()) }
    var selectedSubjectForCheck by remember { mutableStateOf<String?>(subjects.firstOrNull()?.name ?: "ميكروسوفت وورد") }
    var studentSearchQuery by remember { mutableStateOf("") }

    // Map to keep track of expanded students
    val expandedStudents = remember { mutableStateMapOf<Int, Boolean>() }

    // Helper functions to categorize tasks based on title and type
    fun getTaskType(title: String, type: String = ""): String {
        if (type.isNotBlank()) {
            if (type.contains("مشروع") || type.contains("عملي")) return "مشروع عملي"
            if (type.contains("بحث") || type.contains("نظري") || type.contains("واجب") || type.contains("تكليف")) return "بحث نظري"
            return type
        }
        return when {
            title.contains("مشروع") || title.contains("عملي") -> "مشروع عملي"
            else -> "بحث نظري"
        }
    }

    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero / Introduction Dashboard Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isDarkTheme) Color(0xFF1E293B) else DawamiNavy.copy(alpha = 0.05f)
            ),
            border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else DawamiNavy.copy(alpha = 0.15f))
        ) {
            Row(
                modifier = Modifier.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = DawamiNavy,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.AssignmentInd,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "لوحة التحكم بالمشاريع والتكليفات 📊",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDarkTheme) Color.White else DawamiNavy
                    )
                    Text(
                        text = "تهيئة المشاريع والواجبات ورصد التسليمات.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Setup Templates Section
        Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else Color.White),
                border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "اختر المادة الدراسية لتهيئة مشاريعها وتكليفاتها:",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDarkTheme) Color.White else DawamiNavy
                    )

                    // NEW LAYOUT: Dept / Diploma in Row, Subject in Row
                    
                    val allDepartments = remember(courses) { courses.map { it.departmentName }.distinct().filter { it.isNotBlank() } }
                    var selectedDepartment by remember { mutableStateOf(allDepartments.firstOrNull() ?: "") }
                    
                    LaunchedEffect(allDepartments) {
                        if (selectedDepartment.isEmpty() && allDepartments.isNotEmpty()) {
                            selectedDepartment = allDepartments.first()
                        }
                    }
                    
                    val allDiplomas = remember(courses, selectedDepartment) { courses.filter { it.departmentName == selectedDepartment }.map { it.diplomaName }.distinct().filter { it.isNotBlank() } }
                    var selectedDiploma by remember { mutableStateOf(allDiplomas.firstOrNull() ?: "") }
                    
                    LaunchedEffect(allDiplomas) {
                        if (!allDiplomas.contains(selectedDiploma)) {
                            selectedDiploma = allDiplomas.firstOrNull() ?: ""
                        }
                    }
                    
                    val filteredSubjects = remember(selectedDepartment, selectedDiploma, subjects) { 
                        subjects.filter { it.departmentName == selectedDepartment && it.diplomaName == selectedDiploma } 
                    }
                    
                    LaunchedEffect(filteredSubjects) {
                        if (!filteredSubjects.map { it.name }.contains(selectedSubjectForSetup)) {
                            selectedSubjectForSetup = filteredSubjects.firstOrNull()?.name
                        }
                    }

                    if (allDepartments.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("القسم والدبلوم المستهدف:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.White else DawamiNavy)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // Department selection
                                var isDeptExpanded by remember { mutableStateOf(false) }
                                Box(modifier = Modifier.weight(1f)) {
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { isDeptExpanded = true }
                                            .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                        color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(selectedDepartment.ifEmpty { "اختر القسم..." }, fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                    DropdownMenu(
                                        expanded = isDeptExpanded,
                                        onDismissRequest = { isDeptExpanded = false }
                                    ) {
                                        allDepartments.forEach { dept ->
                                            DropdownMenuItem(
                                                text = { Text(dept, fontSize = 11.sp) },
                                                onClick = {
                                                    selectedDepartment = dept
                                                    isDeptExpanded = false
                                                    selectedDiploma = allDiplomas.firstOrNull() ?: ""
                                                    selectedSubjectForSetup = filteredSubjects.firstOrNull()?.name
                                                }
                                            )
                                        }
                                    }
                                }

                                // Diploma selection
                                var isDiplomaExpanded by remember { mutableStateOf(false) }
                                Box(modifier = Modifier.weight(1f)) {
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { isDiplomaExpanded = true }
                                            .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                        color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(selectedDiploma.ifEmpty { "اختر الدبلوم..." }, fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                    DropdownMenu(
                                        expanded = isDiplomaExpanded,
                                        onDismissRequest = { isDiplomaExpanded = false }
                                    ) {
                                        allDiplomas.forEach { dip ->
                                            DropdownMenuItem(
                                                text = { Text(dip, fontSize = 11.sp) },
                                                onClick = {
                                                    selectedDiploma = dip
                                                    isDiplomaExpanded = false
                                                    selectedSubjectForSetup = filteredSubjects.firstOrNull()?.name
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("المادة الدراسية:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.White else DawamiNavy)
                        var isSubjectSetupDropdownExpanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { isSubjectSetupDropdownExpanded = true }
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedSubjectForSetup ?: "اختر المادة...", fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                            DropdownMenu(
                                expanded = isSubjectSetupDropdownExpanded,
                                onDismissRequest = { isSubjectSetupDropdownExpanded = false }
                            ) {
                                filteredSubjects.forEach { subj ->
                                    DropdownMenuItem(
                                        text = { Text(subj.name, fontSize = 11.sp) },
                                        onClick = {
                                            selectedSubjectForSetup = subj.name
                                            isSubjectSetupDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    
                    // Buttons Row
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.navigateTo(Screen.TheoryExamGrader) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("رصد نظري")
                        }
                        
                        Button(
                            onClick = { viewModel.navigateTo(Screen.Grades) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("رصد الدرجات")
                        }
                    }


                    // Scope Selector (General Templates vs Course Specific)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("نطاق إدارة المشاريع والتكليفات:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.White else DawamiNavy)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                "GLOBAL" to "🌐 القوالب العامة للمادة (لكافة الدورات)",
                                "COURSE" to "📌 تخصيص مشاريع لدورة محددة"
                            ).forEach { (scopeKey, label) ->
                                val isSel = setupScopeType == scopeKey
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { setupScopeType = scopeKey },
                                    color = if (isSel) DawamiNavy else (if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9)),
                                    border = BorderStroke(1.dp, if (isSel) DawamiNavy else Color.LightGray.copy(alpha = 0.5f))
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) Color.White else (if (isDarkTheme) Color.LightGray else Color.DarkGray),
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // If Course Specific is selected, show Course Dropdown
                    if (setupScopeType == "COURSE") {
                        val availableCoursesForDiploma = remember(courses, selectedDiploma) {
                            if (selectedDiploma.isNotBlank()) courses.filter { it.diplomaName == selectedDiploma } else courses
                        }
                        var isCourseSetupDropdownExpanded by remember { mutableStateOf(false) }

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("الدورة المستهدفة بالتخصيص:", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                            Box(modifier = Modifier.fillMaxWidth()) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { isCourseSetupDropdownExpanded = true }
                                        .border(1.dp, DawamiTeal.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                    color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF0FDFA)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = selectedCourseForSetup?.name ?: "اختر الدورة...",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                                DropdownMenu(
                                    expanded = isCourseSetupDropdownExpanded,
                                    onDismissRequest = { isCourseSetupDropdownExpanded = false }
                                ) {
                                    availableCoursesForDiploma.forEach { crs ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = if (crs.isCompleted) "${crs.name} (منتهية 🔒)" else crs.name,
                                                    fontSize = 11.sp,
                                                    color = if (crs.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                                )
                                            },
                                            onClick = {
                                                selectedCourseForSetup = crs
                                                isCourseSetupDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Notice / Explain box
                    Surface(
                        color = if (setupScopeType == "COURSE") DawamiTeal.copy(alpha = 0.08f) else DawamiNavy.copy(alpha = 0.05f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (setupScopeType == "COURSE") DawamiTeal.copy(alpha = 0.3f) else DawamiNavy.copy(alpha = 0.15f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = if (setupScopeType == "COURSE") DawamiTeal else DawamiNavy, modifier = Modifier.size(18.dp))
                            Text(
                                text = if (setupScopeType == "COURSE") {
                                    "وضع التخصيص لدورة (${selectedCourseForSetup?.name ?: ""}): أي حذف أو استبعاد هنا يُطبق على هذه الدورة فقط دون التأثير على القوالب العامة أو الدورات الأخرى المنتهية أو القائمة."
                                } else {
                                    "توضيح: المشاريع والواجبات المهيأة هنا هي القوالب المرجعية العامة لمادة (${selectedSubjectForSetup ?: ""}) لكافة الدورات المستمرة والجديدة."
                                },
                                fontSize = 11.sp,
                                color = if (setupScopeType == "COURSE") DawamiTeal else DawamiNavy,
                                lineHeight = 15.sp
                            )
                        }
                    }

                    val currentSubjectTemplates = remember(assignmentTemplates, selectedSubjectForSetup, setupScopeType, selectedCourseForSetup) {
                        val subj = (selectedSubjectForSetup ?: "").trim()
                        assignmentTemplates.filter {
                            it.subjectName.trim().equals(subj, ignoreCase = true) &&
                            if (setupScopeType == "GLOBAL") {
                                it.courseId == 0
                            } else {
                                selectedCourseForSetup?.let { crs -> it.isApplicableForCourse(crs.id) } ?: (it.courseId == 0)
                            }
                        }
                    }

                    val currentExcludedTemplates = remember(assignmentTemplates, selectedSubjectForSetup, setupScopeType, selectedCourseForSetup) {
                        val subj = (selectedSubjectForSetup ?: "").trim()
                        if (setupScopeType == "COURSE" && selectedCourseForSetup != null) {
                            assignmentTemplates.filter {
                                it.subjectName.trim().equals(subj, ignoreCase = true) &&
                                it.isExcludedForCourse(selectedCourseForSetup!!.id)
                            }
                        } else emptyList()
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (setupScopeType == "COURSE") "المشاريع المعتمدة لهذه الدورة (${currentSubjectTemplates.size}):" else "القوالب العامة المعتمدة للمادة (${currentSubjectTemplates.size}):",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDarkTheme) Color.White else Color.DarkGray
                        )

                        Button(
                            onClick = {
                                editingTemplate = null
                                tempAttachmentPath = ""
                                tempAttachmentName = ""
                                showAddEditTemplateDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (setupScopeType == "COURSE") "إضافة للدورة ➕" else "إضافة قالب عام ➕", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (currentSubjectTemplates.isEmpty()) {
                        // Empty State
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Inbox,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = if (setupScopeType == "COURSE") "لا توجد مشاريع معتمدة لمادة (${selectedSubjectForSetup ?: ""}) في هذه الدورة." else "لا توجد قوالب عامة مهيأة لمادة (${selectedSubjectForSetup ?: ""}) بعد.",
                                fontSize = 11.5.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = {
                                    editingTemplate = null
                                    tempAttachmentPath = ""
                                    tempAttachmentName = ""
                                    showAddEditTemplateDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (setupScopeType == "COURSE") "إضافة مشروع خاص بالدورة ➕" else "إضافة قالب عام جديد ➕", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            currentSubjectTemplates.forEachIndexed { index, tmpl ->
                                val taskType = getTaskType(tmpl.title, tmpl.type)
                                val (badgeColor, badgeText) = when (taskType) {
                                    "مشروع عملي" -> Color(0xFF8B5CF6) to "مشروع عملي 💻"
                                    else -> Color(0xFFD97706) to "بحث نظري 🔍"
                                }
                                val isSpecific = tmpl.courseId > 0

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            viewingTemplateDetails = tmpl
                                        },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                                    ),
                                    border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        // Dynamic right vertical strip color based on task type
                                        Box(
                                            modifier = Modifier
                                                .width(6.dp)
                                                .fillMaxHeight()
                                                .align(Alignment.CenterVertically)
                                                .background(badgeColor)
                                                .height(80.dp)
                                        )

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(
                                                modifier = Modifier.weight(1f),
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Surface(
                                                        color = badgeColor.copy(alpha = 0.15f),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = badgeText,
                                                            fontSize = 9.sp,
                                                            color = badgeColor,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }

                                                    Surface(
                                                        color = if (isSpecific) Color(0xFF8B5CF6).copy(alpha = 0.15f) else DawamiTeal.copy(alpha = 0.15f),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = if (isSpecific) "خاص بالدورة 📌" else "قالب عام 🌐",
                                                            fontSize = 8.5.sp,
                                                            color = if (isSpecific) Color(0xFF8B5CF6) else DawamiTeal,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                        )
                                                    }

                                                    Text(
                                                        text = tmpl.title,
                                                        fontSize = 12.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isDarkTheme) Color.White else DawamiNavy,
                                                        modifier = Modifier.weight(1f, fill = false)
                                                    )
                                                }
                                                if (tmpl.description.isNotEmpty()) {
                                                    Text(
                                                        text = tmpl.description,
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Text(
                                                    text = "الوزن والدرجة: ${tmpl.maxScore.toInt()} درجة",
                                                    fontSize = 10.5.sp,
                                                    color = DawamiTeal,
                                                    fontWeight = FontWeight.Bold
                                                )

                                                if (tmpl.attachmentPath.isNotBlank()) {
                                                    Surface(
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = if (isDarkTheme) Color(0xFF334155).copy(alpha = 0.5f) else Color(0xFFEFF6FF),
                                                        border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.6f)),
                                                        modifier = Modifier
                                                            .padding(top = 4.dp)
                                                            .clip(RoundedCornerShape(8.dp))
                                                            .clickable {
                                                                val ext = tmpl.attachmentName.substringAfterLast('.', "").lowercase()
                                                                if (ext in listOf("png", "jpg", "jpeg", "webp", "gif", "bmp")) {
                                                                    previewingImageAttachment = Pair(tmpl.attachmentPath, tmpl.attachmentName)
                                                                } else {
                                                                    openAttachmentFile(context, tmpl.attachmentPath, tmpl.attachmentName)
                                                                }
                                                            }
                                                    ) {
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.AttachFile,
                                                                contentDescription = "الملف المرفق",
                                                                tint = DawamiTeal,
                                                                modifier = Modifier.size(14.dp)
                                                            )
                                                            val sizeStr = getFileSizeLabelFromPath(tmpl.attachmentPath)
                                                            val sizeText = if (sizeStr.isNotBlank()) " ($sizeStr)" else ""
                                                            Text(
                                                                text = "${tmpl.attachmentName}$sizeText",
                                                                fontSize = 10.5.sp,
                                                                color = DawamiNavy,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                            Spacer(modifier = Modifier.width(3.dp))
                                                            Surface(
                                                                shape = RoundedCornerShape(4.dp),
                                                                color = DawamiTeal.copy(alpha = 0.15f)
                                                            ) {
                                                                Row(
                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                                ) {
                                                                    Icon(
                                                                        imageVector = Icons.Default.Visibility,
                                                                        contentDescription = null,
                                                                        tint = DawamiTeal,
                                                                        modifier = Modifier.size(11.dp)
                                                                    )
                                                                    Spacer(modifier = Modifier.width(2.dp))
                                                                    Text(
                                                                        text = "معاينة 👁️",
                                                                        fontSize = 8.5.sp,
                                                                        color = DawamiTeal,
                                                                        fontWeight = FontWeight.Bold
                                                                    )
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(4.dp))
                                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Button(
                                                        onClick = {
                                                            sharingTemplate = tmpl
                                                            showSharingDialog = true
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                        modifier = Modifier.height(28.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Share,
                                                            contentDescription = null,
                                                            tint = Color.White,
                                                            modifier = Modifier.size(12.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("مشاركة وإرسال 📤", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                                    }

                                                    if (isSpecific) {
                                                        OutlinedButton(
                                                            onClick = {
                                                                viewModel.exportAssignmentTemplateToGlobal(tmpl) {
                                                                    Toast.makeText(context, "تم تصدير المشروع لبنك القوالب العامة بنجاح! 🌐", Toast.LENGTH_SHORT).show()
                                                                }
                                                            },
                                                            shape = RoundedCornerShape(8.dp),
                                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                            modifier = Modifier.height(28.dp)
                                                        ) {
                                                            Icon(Icons.Default.CloudUpload, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(12.dp))
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("تصدير لقالب عام 🌐", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                                        }
                                                    }
                                                }
                                            }

                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Surface(
                                                    shape = CircleShape,
                                                    color = Color(0xFF2563EB).copy(alpha = 0.1f),
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    IconButton(
                                                        onClick = {
                                                            editingTemplate = tmpl
                                                            tempAttachmentPath = tmpl.attachmentPath
                                                            tempAttachmentName = tmpl.attachmentName
                                                            showAddEditTemplateDialog = true
                                                        }
                                                    ) {
                                                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                                Surface(
                                                    shape = CircleShape,
                                                    color = Color(0xFFDC2626).copy(alpha = 0.1f),
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    IconButton(
                                                        onClick = {
                                                            templateToDelete = tmpl
                                                        }
                                                    ) {
                                                        Icon(
                                                            imageVector = if (setupScopeType == "COURSE" && !isSpecific) Icons.Default.Block else Icons.Default.Delete,
                                                            contentDescription = "حذف أو استبعاد",
                                                            tint = Color(0xFFDC2626),
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Excluded Projects Section for Course
                    if (setupScopeType == "COURSE" && currentExcludedTemplates.isNotEmpty() && selectedCourseForSetup != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "مشاريع مستبعدة من دورة (${selectedCourseForSetup?.name ?: ""}) (${currentExcludedTemplates.size}):",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626)
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            currentExcludedTemplates.forEach { exTmpl ->
                                Surface(
                                    color = Color(0xFFFEF2F2),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(0.5.dp, Color(0xFFFCA5A5)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(exTmpl.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                                            Text("${exTmpl.type} (مستبعد من هذه الدورة فقط)", fontSize = 8.5.sp, color = Color(0xFFB91C1C))
                                        }
                                        Button(
                                            onClick = {
                                                selectedCourseForSetup?.let { crs ->
                                                    viewModel.restoreAssignmentTemplateToCourse(exTmpl, crs.id)
                                                    Toast.makeText(context, "تمت استعادة المشروع للدورة بنجاح 👍", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(26.dp)
                                        ) {
                                            Text("استعادة للدورة ↩️", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        if (false) {
                Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else Color.White),
                border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "رصد وتسجيل مشاريع وتكليفات الطلاب:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDarkTheme) Color.White else DawamiNavy
                    )

                    // Select Course
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("اختر الدورة والترم:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(courses) { crs ->
                                val isSelected = selectedCourseForCheck?.id == crs.id
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedCourseForCheck = crs },
                                    label = { Text(crs.name, fontSize = 11.sp) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = DawamiNavy,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }

                    // Select Subject Dropdown
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("اختر المادة الدراسية:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.White else DawamiNavy)
                        var isSubjectCheckDropdownExpanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { isSubjectCheckDropdownExpanded = true }
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedSubjectForCheck ?: "اختر المادة الدراسية...", fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                            DropdownMenu(
                                expanded = isSubjectCheckDropdownExpanded,
                                onDismissRequest = { isSubjectCheckDropdownExpanded = false }
                            ) {
                                subjects.forEach { subj ->
                                    DropdownMenuItem(
                                        text = { Text(subj.name, fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                                        onClick = {
                                            selectedSubjectForCheck = subj.name
                                            isSubjectCheckDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Search input
                    OutlinedTextField(
                        value = studentSearchQuery,
                        onValueChange = { studentSearchQuery = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("ابحث باسم الطالب لرصد تسليمه...", fontSize = 11.5.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    val activeCourse = selectedCourseForCheck
                    val activeSubjectName = selectedSubjectForCheck ?: ""

                    val activeCourseStudents = if (activeCourse != null) {
                        allStudents.filter { it.courseId == activeCourse.id && (studentSearchQuery.isEmpty() || it.name.contains(studentSearchQuery, ignoreCase = true)) }
                    } else emptyList()

                    val templatesForSubject = assignmentTemplates.filter {
                        it.subjectName.trim().equals(activeSubjectName.trim(), ignoreCase = true)
                    }

                    if (activeCourse == null) {
                        Text("الرجاء اختيار دورة نشطة لعرض قائمة الطلاب ورصد درجاتهم.", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else if (templatesForSubject.isEmpty()) {
                        Surface(
                            color = DawamiGold.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.2f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ لا توجد مشاريع أو واجبات مهيأة لمادة ($activeSubjectName) بعد.\nالرجاء الانتقال أولاً لتبويب (تهيئة المشاريع والواجبات) لإضافة التكليفات المطلوبة.",
                                fontSize = 11.sp,
                                color = Color(0xFFB45309),
                                modifier = Modifier.padding(12.dp),
                                lineHeight = 16.sp
                            )
                        }
                    } else if (activeCourseStudents.isEmpty()) {
                        Text("لا يوجد طلاب مسجلين في هذه الدورة يطابقون البحث.", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        // Class summary metrics card
                        val allClassSubmissions = assignmentSubmissions.filter {
                            it.courseId == activeCourse.id && it.subjectName.trim().equals(activeSubjectName.trim(), ignoreCase = true) && it.isCompleted
                        }
                        val totalPossibleSubmissions = activeCourseStudents.size * templatesForSubject.size
                        val classProgress = if (totalPossibleSubmissions > 0) allClassSubmissions.size.toFloat() / totalPossibleSubmissions.toFloat() else 0f

                        Surface(
                            color = DawamiTeal.copy(alpha = 0.05f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("معدل إنجاز الدفعة بالكامل 📈", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                    Text("تم تسليم ورصد ${allClassSubmissions.size} من أصل $totalPossibleSubmissions مشروع/تكليف", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Surface(
                                    color = DawamiTeal,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "${(classProgress * 100).toInt()}% إتمام",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        // Students expandable list
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            activeCourseStudents.forEach { student ->
                                val studentSubmissions = assignmentSubmissions.filter {
                                    it.courseId == activeCourse.id &&
                                    it.subjectName.trim().equals(activeSubjectName.trim(), ignoreCase = true) &&
                                    it.studentId == student.id &&
                                    it.isCompleted
                                }
                                val completedTitles = studentSubmissions.map { it.assignmentTitle.trim().lowercase() }
                                val completedCount = templatesForSubject.count { completedTitles.contains(it.title.trim().lowercase()) }
                                val totalCount = templatesForSubject.size
                                val progressRatio = if (totalCount > 0) completedCount.toFloat() / totalCount.toFloat() else 0f

                                val isExpanded = expandedStudents[student.id] ?: false

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        if (completedCount == totalCount) Color(0xFF86EFAC) else (if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                                    )
                                ) {
                                    Column {
                                        // Header (Collapsed view)
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { expandedStudents[student.id] = !isExpanded }
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                // Mini student avatar
                                                Surface(
                                                    color = if (completedCount == totalCount) Color(0xFFDCFCE7) else DawamiNavy.copy(alpha = 0.1f),
                                                    shape = CircleShape,
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text(
                                                            text = student.name.take(1),
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 13.sp,
                                                            color = if (completedCount == totalCount) Color(0xFF15803D) else DawamiNavy
                                                        )
                                                    }
                                                }

                                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                    Text(
                                                        text = student.name,
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isDarkTheme) Color.White else DawamiNavy
                                                    )
                                                    Text(
                                                        text = "تم رصد $completedCount من $totalCount تكليفات",
                                                        fontSize = 10.sp,
                                                        color = Color.Gray
                                                    )
                                                }
                                            }

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Surface(
                                                    color = if (completedCount == totalCount) Color(0xFF16A34A) else DawamiNavy.copy(alpha = 0.12f),
                                                    shape = RoundedCornerShape(10.dp)
                                                ) {
                                                    Text(
                                                        text = "${(progressRatio * 100).toInt()}%",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (completedCount == totalCount) Color.White else DawamiNavy,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                                    )
                                                }

                                                Icon(
                                                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                    contentDescription = null,
                                                    tint = Color.Gray,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }

                                        // Progress indicator
                                        LinearProgressIndicator(
                                            progress = { progressRatio },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(4.dp),
                                            color = if (completedCount == totalCount) Color(0xFF16A34A) else DawamiNavy,
                                            trackColor = if (isDarkTheme) Color(0xFF334155) else Color(0xFFF1F5F9)
                                        )

                                        // Expanded view
                                        AnimatedVisibility(
                                            visible = isExpanded,
                                            enter = expandVertically() + fadeIn(),
                                            exit = shrinkVertically() + fadeOut()
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(if (isDarkTheme) Color(0xFF0F172A) else Color(0xFFF8FAFC))
                                                    .padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = "قائمة مشاريع الطالب ورصد التقييمات:",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.Gray
                                                )

                                                templatesForSubject.forEach { tmpl ->
                                                    val sub = studentSubmissions.filter {
                                                        it.assignmentTitle.trim().equals(tmpl.title.trim(), ignoreCase = true)
                                                    }.maxByOrNull { it.id }
                                                    val isChecked = sub != null && sub.isCompleted
                                                    val currentRating = sub?.evaluationRating ?: ""

                                                    val taskType = getTaskType(tmpl.title)
                                                    val taskColor = when (taskType) {
                                                        "مشروع" -> Color(0xFF8B5CF6)
                                                        "واجب" -> Color(0xFF0D9488)
                                                        "بحث" -> Color(0xFFD97706)
                                                        else -> Color(0xFF334155)
                                                    }

                                                    Card(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        shape = RoundedCornerShape(10.dp),
                                                        colors = CardDefaults.cardColors(
                                                            containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                                                        ),
                                                        border = BorderStroke(
                                                            1.dp,
                                                            if (isChecked) taskColor.copy(alpha = 0.4f) else (if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                                                        )
                                                    ) {
                                                        Column(
                                                            modifier = Modifier.padding(10.dp),
                                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                                        ) {
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Row(
                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                                    modifier = Modifier
                                                                        .weight(1f)
                                                                        .clickable {
                                                                            viewModel.toggleStudentAssignmentSubmission(
                                                                                courseId = activeCourse.id,
                                                                                subjectName = activeSubjectName,
                                                                                studentId = student.id,
                                                                                studentName = student.name,
                                                                                assignmentTitle = tmpl.title
                                                                            )
                                                                        }
                                                                ) {
                                                                    Icon(
                                                                        imageVector = if (isChecked) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                                                        contentDescription = null,
                                                                        modifier = Modifier.size(20.dp),
                                                                        tint = if (isChecked) taskColor else Color.Gray
                                                                    )
                                                                    Column(modifier = Modifier.weight(1f)) {
                                                                        Text(
                                                                            text = tmpl.title,
                                                                            fontSize = 11.sp,
                                                                            fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Medium,
                                                                            color = if (isChecked) taskColor else (if (isDarkTheme) Color.White else Color.DarkGray),
                                                                            modifier = Modifier.weight(1f, fill = false)
                                                                        )
                                                                        if (tmpl.description.isNotEmpty()) {
                                                                            Text(
                                                                                text = tmpl.description,
                                                                                fontSize = 10.sp,
                                                                                color = Color.Gray,
                                                                                modifier = Modifier.weight(1f, fill = false)
                                                                            )
                                                                        }
                                                                    }
                                                                }

                                                                Row(
                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                                ) {
                                                                    val effectiveScore = sub?.score ?: if (isChecked && currentRating.isNotEmpty()) {
                                                                        when (currentRating) {
                                                                            "ممتاز" -> tmpl.maxScore
                                                                            "جيد جداً" -> tmpl.maxScore * 0.75
                                                                            "جيد" -> tmpl.maxScore * 0.50
                                                                            "مقبول" -> tmpl.maxScore * 0.25
                                                                            else -> 0.0
                                                                        }
                                                                    } else 0.0
                                                                    val formattedScoreStr = if (effectiveScore % 1.0 == 0.0) effectiveScore.toInt().toString() else effectiveScore.toString()

                                                                    Surface(
                                                                        color = taskColor.copy(alpha = 0.12f),
                                                                        shape = RoundedCornerShape(6.dp)
                                                                    ) {
                                                                        Text(
                                                                            text = "$formattedScoreStr / ${tmpl.maxScore.toInt()}",
                                                                            fontSize = 9.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                            color = taskColor,
                                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                                        )
                                                                    }

                                                                    if (isChecked && currentRating.isNotEmpty()) {
                                                                        Surface(
                                                                            color = when (currentRating) {
                                                                                "ممتاز" -> Color(0xFF16A34A)
                                                                                "جيد جداً" -> Color(0xFF0284C7)
                                                                                "جيد" -> Color(0xFFD97706)
                                                                                "مقبول" -> Color(0xFF64748B)
                                                                                else -> Color(0xFFDC2626)
                                                                            },
                                                                            shape = RoundedCornerShape(8.dp)
                                                                        ) {
                                                                            Text(
                                                                                text = currentRating,
                                                                                fontSize = 8.5.sp,
                                                                                fontWeight = FontWeight.Bold,
                                                                                color = Color.White,
                                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                                            )
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            // Rating Selector Buttons
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                val ratingOptions = listOf(
                                                                    "ممتاز" to "⭐ ممتاز",
                                                                    "جيد جداً" to "👍 ج.جيد",
                                                                    "جيد" to "👌 جيد",
                                                                    "مقبول" to "🤏 مقبول",
                                                                    "غير مكتمل" to "❌ لم ينجز"
                                                                )

                                                                ratingOptions.forEach { (ratingKey, ratingLabel) ->
                                                                    val isSelectedRating = when (ratingKey) {
                                                                        "غير مكتمل", "لم ينجز" -> (currentRating == "غير مكتمل" || currentRating == "لم ينجز")
                                                                        else -> currentRating == ratingKey
                                                                    }
                                                                    Surface(
                                                                        onClick = {
                                                                            val autoScore = when(ratingKey) {
                                                                                "ممتاز" -> tmpl.maxScore
                                                                                "جيد جداً" -> tmpl.maxScore * 0.75
                                                                                "جيد" -> tmpl.maxScore * 0.50
                                                                                "مقبول" -> tmpl.maxScore * 0.25
                                                                                else -> 0.0
                                                                            }
                                                                            viewModel.setStudentAssignmentRating(
                                                                                courseId = activeCourse.id,
                                                                                subjectName = activeSubjectName,
                                                                                studentId = student.id,
                                                                                studentName = student.name,
                                                                                assignmentTitle = tmpl.title,
                                                                                rating = if (isSelectedRating) "" else ratingKey,
                                                                                score = if (isSelectedRating) 0.0 else autoScore
                                                                            )
                                                                        },
                                                                        modifier = Modifier.weight(1f),
                                                                        shape = RoundedCornerShape(6.dp),
                                                                        color = if (isSelectedRating) {
                                                                            when (ratingKey) {
                                                                                "ممتاز" -> Color(0xFF16A34A)
                                                                                "جيد جداً" -> Color(0xFF0284C7)
                                                                                "جيد" -> Color(0xFFD97706)
                                                                                "مقبول" -> Color(0xFF64748B)
                                                                                else -> Color(0xFFDC2626)
                                                                            }
                                                                        } else (if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)).copy(alpha = 0.5f)
                                                                    ) {
                                                                        Text(
                                                                            text = ratingLabel,
                                                                            fontSize = 8.sp,
                                                                            fontWeight = if (isSelectedRating) FontWeight.Bold else FontWeight.Normal,
                                                                            color = if (isSelectedRating) Color.White else (if (isDarkTheme) Color.LightGray else Color.DarkGray),
                                                                            textAlign = TextAlign.Center,
                                                                            modifier = Modifier.padding(vertical = 6.dp)
                                                                        )
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Sharing and Send Assignment Dialog
    if (showSharingDialog && sharingTemplate != null) {
        var selectedCourseForSharing by remember { mutableStateOf<com.example.data.entity.Course?>(courses.firstOrNull()) }
        var showCourseDropdownInSharing by remember { mutableStateOf(false) }
        var selectedStudentForWhatsApp by remember { mutableStateOf<com.example.data.entity.Student?>(null) }
        val sharingStudents = remember(selectedCourseForSharing, allStudents) {
            selectedCourseForSharing?.let { course ->
                allStudents.filter { it.courseId == course.id }
            } ?: emptyList()
        }

        AlertDialog(
            onDismissRequest = { showSharingDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
                        Text(
                            text = "مشاركة وإرسال التكليف 📤",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = DawamiNavy
                        )
                    }
                    IconButton(onClick = { showSharingDialog = false }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.Gray, modifier = Modifier.size(16.dp))
                    }
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Header Card: Compact info & Course dropdown in one row
                    Surface(
                        color = DawamiTeal.copy(alpha = 0.06f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(0.5.dp, DawamiTeal.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "التكليف: ${sharingTemplate!!.title}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiNavy,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Surface(
                                    color = DawamiTeal,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = sharingTemplate!!.type,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            // Course Selection Dropdown (Compact Row)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("الدورة:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                Box(modifier = Modifier.weight(1f)) {
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { showCourseDropdownInSharing = true }
                                            .border(0.5.dp, Color.Gray.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        color = Color.White
                                    ) {
                                        Row(
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = selectedCourseForSharing?.name ?: "اختر الدورة...",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Medium,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    DropdownMenu(
                                        expanded = showCourseDropdownInSharing,
                                        onDismissRequest = { showCourseDropdownInSharing = false },
                                        modifier = Modifier.fillMaxWidth(0.85f)
                                    ) {
                                        courses.forEach { course ->
                                            DropdownMenuItem(
                                                text = { Text(course.name, fontSize = 10.5.sp) },
                                                onClick = {
                                                    selectedCourseForSharing = course
                                                    showCourseDropdownInSharing = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Sharing Action Buttons (Compact horizontal row/grid)
                    val shareText = buildAssignmentShareText(sharingTemplate!!)
                    val hasAttachment = sharingTemplate!!.attachmentPath.isNotBlank()

                    if (hasAttachment) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // 1. WhatsApp Button
                            Button(
                                onClick = {
                                    shareFileOnly(context, sharingTemplate!!.attachmentPath, sharingTemplate!!.attachmentName, shareText)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp)
                            ) {
                                Text("💬 واتساب المرفق", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }

                            // 2. Full Share
                            Button(
                                onClick = {
                                    shareFileWithText(context, sharingTemplate!!.attachmentPath, shareText, sharingTemplate!!.attachmentName)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp)
                            ) {
                                Text("✈️ مشاركة شاملة", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }

                            // 3. Text Only
                            OutlinedButton(
                                onClick = { shareTextOnly(context, shareText) },
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp)
                            ) {
                                Text("📝 نص فقط", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                            }
                        }
                    } else {
                        Button(
                            onClick = { shareTextOnly(context, shareText) },
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(vertical = 6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مشاركة نص التكليف 📤", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    // Student List Section Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("إرسال فردي للطلاب 👤", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        Text("${sharingStudents.size} طالب", fontSize = 9.5.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    }

                    if (sharingStudents.isEmpty()) {
                        Text(
                            text = "لا يوجد طلاب مسجلين في هذه الدورة.",
                            fontSize = 9.5.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        // Expanded Student List Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 380.dp)
                        ) {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(sharingStudents) { student ->
                                    val hasPhone = student.phoneNumber.isNotBlank()
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC), RoundedCornerShape(6.dp))
                                            .border(0.5.dp, Color.LightGray.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = student.name,
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (hasPhone) student.phoneNumber else "بدون رقم هاتف",
                                                fontSize = 8.5.sp,
                                                color = if (hasPhone) DawamiNavy else Color.Gray
                                            )
                                        }

                                        if (hasPhone) {
                                            Button(
                                                onClick = { selectedStudentForWhatsApp = student },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(4.dp),
                                                modifier = Modifier.height(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Send,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(10.dp)
                                                )
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("إرسال 💬", fontSize = 8.5.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showSharingDialog = false }
                ) {
                    Text("إغلاق", fontWeight = FontWeight.Bold, color = DawamiNavy)
                }
            }
        )

        // Sub-dialog to choose WhatsApp / WhatsApp Business for specific student
        if (selectedStudentForWhatsApp != null) {
            val student = selectedStudentForWhatsApp!!
            val shareText = buildAssignmentShareText(sharingTemplate!!)
            val hasAttachment = sharingTemplate!!.attachmentPath.isNotBlank()

            AlertDialog(
                onDismissRequest = { selectedStudentForWhatsApp = null },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = null, tint = Color(0xFF25D366))
                        Text(
                            text = "إرسال التكليف إلى الطالب",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = DawamiNavy
                        )
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            color = DawamiNavy.copy(alpha = 0.05f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = "اسم الطالب: ${student.name}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = DawamiNavy
                                )
                                Text(
                                    text = "رقم الهاتف: ${student.phoneNumber}",
                                    fontSize = 10.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }

                        Text(
                            text = "اختر تطبيق الواتساب المفضل لتوجيه الرسالة والمرفق مباشرة لمحادثة الطالب الخاصة:",
                            fontSize = 10.5.sp,
                            color = Color.DarkGray
                        )

                        // 1. WhatsApp Normal
                        Button(
                            onClick = {
                                val st = selectedStudentForWhatsApp
                                selectedStudentForWhatsApp = null
                                if (st != null) {
                                    sendAssignmentToStudentWhatsApp(
                                        context = context,
                                        phoneNumber = st.phoneNumber,
                                        text = shareText,
                                        attachmentPath = sharingTemplate!!.attachmentPath,
                                        attachmentName = sharingTemplate!!.attachmentName,
                                        isBusiness = false
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 12.dp)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("واتساب العادي (WhatsApp)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        // 2. WhatsApp Business
                        Button(
                            onClick = {
                                val st = selectedStudentForWhatsApp
                                selectedStudentForWhatsApp = null
                                if (st != null) {
                                    sendAssignmentToStudentWhatsApp(
                                        context = context,
                                        phoneNumber = st.phoneNumber,
                                        text = shareText,
                                        attachmentPath = sharingTemplate!!.attachmentPath,
                                        attachmentName = sharingTemplate!!.attachmentName,
                                        isBusiness = true
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 12.dp)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("واتساب الأعمال (WhatsApp Business)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { selectedStudentForWhatsApp = null }) {
                        Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                    }
                }
            )
        }
    }

    if (templateToDelete != null) {
        val tmpl = templateToDelete!!
        val isCourseScope = setupScopeType == "COURSE" && selectedCourseForSetup != null
        val isSpecific = tmpl.courseId > 0 && selectedCourseForSetup != null && tmpl.courseId == selectedCourseForSetup!!.id

        AlertDialog(
            onDismissRequest = { templateToDelete = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626))
                    Text(
                        text = if (isCourseScope && !isSpecific) "استبعاد مشروع من الدورة 🚫" else "تأكيد حذف المشروع ⚠️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "المشروع: \"${tmpl.title}\"",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = DawamiNavy
                    )
                    Text(
                        text = if (isCourseScope && !isSpecific) {
                            "هل أنت متأكد من استبعاد هذا المشروع من دورة (${selectedCourseForSetup?.name ?: ""}) فقط؟\n\nلن يُحذف القالب العام للمادة ولن تتأثر أي دورات أخرى سابقة أو منتهية."
                        } else if (isCourseScope && isSpecific) {
                            "هل أنت متأكد من حذف هذا المشروع الخاص بدورة (${selectedCourseForSetup?.name ?: ""}) نهائياً؟"
                        } else {
                            "هل أنت متأكد من رغبتك في حذف القالب العام للمادة نهائياً من بنك المشاريع؟"
                        },
                        fontSize = 12.sp,
                        color = if (isDarkTheme) Color.LightGray else Color.DarkGray
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val t = tmpl
                        templateToDelete = null
                        if (isCourseScope) {
                            viewModel.deleteAssignmentTemplateFromCourse(t, selectedCourseForSetup!!.id)
                            Toast.makeText(context, if (isSpecific) "تم حذف المشروع من الدورة بنجاح 👍" else "تم استبعاد المشروع من الدورة بنجاح 👍", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.deleteAssignmentTemplate(t)
                            Toast.makeText(context, "تم حذف القالب العام بنجاح", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(if (isCourseScope && !isSpecific) "استبعاد من الدورة" else "حذف", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { templateToDelete = null }) {
                    Text("إلغاء", color = DawamiNavy)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = if (isDarkTheme) DarkSurface else Color.White
        )
    }

    // Add / Edit Template Dialog
    if (showAddEditTemplateDialog) {
        var titleInput by remember { mutableStateOf(editingTemplate?.title ?: "") }
        var descInput by remember { mutableStateOf(editingTemplate?.description ?: "") }
        var scoreInput by remember { mutableStateOf(editingTemplate?.maxScore?.toInt()?.toString() ?: "10") }
        var alsoSaveAsGlobalInDialog by remember { mutableStateOf(false) }
        
        // Let's add an explicit Task Type selector in the dialog to make it exceptionally professional!
        var selectedTypeInDialog by remember {
            mutableStateOf(
                when {
                    editingTemplate?.type == "مشروع عملي" -> "مشروع عملي"
                    editingTemplate?.type == "بحث نظري" -> "بحث نظري"
                    else -> "مشروع عملي"
                }
            )
        }

        AlertDialog(
            onDismissRequest = { showAddEditTemplateDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.AddTask, contentDescription = null, tint = DawamiNavy)
                    Text(
                        text = if (editingTemplate == null) {
                            if (setupScopeType == "COURSE") "إضافة مشروع خاص بدورة (${selectedCourseForSetup?.name ?: ""}) ➕" else "إضافة قالب عام جديد للمادة ➕"
                        } else "تعديل بيانات التكليف ✏️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "المادة المستهدفة: ${selectedSubjectForSetup ?: ""}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiTeal
                    )

                    // Type Selector Chips inside Dialog
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("نوع التكليف:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                "مشروع عملي" to "💻 مشروع عملي",
                                "بحث نظري" to "🔍 بحث نظري",

                                
                            ).forEach { (typeKey, label) ->
                                val isSelected = selectedTypeInDialog == typeKey
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            selectedTypeInDialog = typeKey
                                        },
                                    color = if (isSelected) DawamiNavy else (if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)),
                                    border = BorderStroke(1.dp, if (isSelected) DawamiNavy else Color.Transparent)
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else Color.DarkGray,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("عنوان التكليف") },
                        placeholder = { Text("مثال: مشروع تصميم قاعدة بيانات المبيعات") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("الوصف والتوجيهات (اختياري)") },
                        placeholder = { Text("اكتب تفاصيل المشروع أو الشروط المطلوبة للتسليم...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = scoreInput,
                        onValueChange = { scoreInput = it },
                        label = { Text("الوزن / الدرجة المقررة") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("مرفق التكليف (اختياري):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        
                        if (tempAttachmentPath.isNotBlank()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                                    .border(1.dp, DawamiTeal.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AttachFile,
                                        contentDescription = null,
                                        tint = DawamiTeal,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = tempAttachmentName,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        tempAttachmentPath = ""
                                        tempAttachmentName = ""
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "حذف المرفق",
                                        tint = Color.Red,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        } else {
                            Button(
                                onClick = {
                                    selectAttachmentLauncher.launch("*/*")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy.copy(alpha = 0.15f)),
                                elevation = null,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.UploadFile,
                                    contentDescription = null,
                                    tint = DawamiNavy,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("اختر ملف لارفاقه (جميع الملفات) 📎", fontSize = 11.sp, color = DawamiNavy, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            text = "يتم حفظ الملف تلقائياً في مجلد التطبيق المخصص: dawami_assignments",
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        // Checkbox for Course scope: option to also save as global template
                        if (editingTemplate == null && setupScopeType == "COURSE" && selectedCourseForSetup != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { alsoSaveAsGlobalInDialog = !alsoSaveAsGlobalInDialog }
                                    .background(if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9))
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Checkbox(
                                    checked = alsoSaveAsGlobalInDialog,
                                    onCheckedChange = { alsoSaveAsGlobalInDialog = it }
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "حفظ كقالب عام للمادة أيضاً (ليظهر في الدورات الأخرى والقادمة) 🌐",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (isDarkTheme) Color.White else DawamiNavy
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedScore = scoreInput.toDoubleOrNull() ?: 10.0
                        if (titleInput.isNotBlank() && selectedSubjectForSetup != null) {
                            if (editingTemplate == null) {
                                val targetCourseId = if (setupScopeType == "COURSE" && selectedCourseForSetup != null && !alsoSaveAsGlobalInDialog) {
                                    selectedCourseForSetup!!.id
                                } else 0

                                viewModel.insertAssignmentTemplate(
                                    com.example.data.entity.SubjectAssignmentTemplate(
                                        subjectName = selectedSubjectForSetup!!,
                                        title = titleInput.trim(),
                                        description = descInput.trim(),
                                        maxScore = parsedScore,
                                        type = selectedTypeInDialog,
                                        attachmentPath = tempAttachmentPath,
                                        attachmentName = tempAttachmentName,
                                        courseId = targetCourseId
                                    )
                                )
                                Toast.makeText(context, if (targetCourseId > 0) "تم حفظ المشروع الخاص بالدورة بنجاح 👍" else "تم حفظ القالب العام للمادة بنجاح 👍", Toast.LENGTH_SHORT).show()
                            } else {
                                viewModel.updateAssignmentTemplate(
                                    editingTemplate!!.copy(
                                        title = titleInput.trim(),
                                        description = descInput.trim(),
                                        maxScore = parsedScore,
                                        type = selectedTypeInDialog,
                                        attachmentPath = tempAttachmentPath,
                                        attachmentName = tempAttachmentName
                                    )
                                )
                                Toast.makeText(context, "تم تحديث التكليف بنجاح 👍", Toast.LENGTH_SHORT).show()
                            }
                            showAddEditTemplateDialog = false
                        } else {
                            Toast.makeText(context, "الرجاء كتابة عنوان التكليف", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (editingTemplate == null) "حفظ المشروع" else "تحديث البيانات", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddEditTemplateDialog = false }) {
                    Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }

    // 1. Template Details Modal Dialog
    if (viewingTemplateDetails != null) {
        val tmpl = viewingTemplateDetails!!
        val taskType = getTaskType(tmpl.title, tmpl.type)
        val (badgeColor, badgeText) = when (taskType) {
            "مشروع عملي" -> Color(0xFF8B5CF6) to "مشروع عملي 💻"
            else -> Color(0xFFD97706) to "بحث نظري 🔍"
        }
        val isSpecific = tmpl.courseId > 0

        AlertDialog(
            onDismissRequest = { viewingTemplateDetails = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = badgeColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = badgeText,
                                fontSize = 9.sp,
                                color = badgeColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = tmpl.title,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = DawamiNavy,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(
                        onClick = { viewingTemplateDetails = null },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.Gray, modifier = Modifier.size(18.dp))
                    }
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Type and Scope badges
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = if (isSpecific) Color(0xFF8B5CF6).copy(alpha = 0.15f) else DawamiTeal.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (isSpecific) "خاص بالدورة 📌" else "قالب عام معتمد للمادة 🌐",
                                fontSize = 9.sp,
                                color = if (isSpecific) Color(0xFF8B5CF6) else DawamiTeal,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                        Surface(
                            color = DawamiGold.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "الدرجة المستحقة: ${tmpl.maxScore.toInt()} درجة 🎯",
                                fontSize = 9.sp,
                                color = DawamiGold,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Description
                    if (tmpl.description.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("تفاصيل وتعليمات التكليف:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                Text(tmpl.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 16.sp)
                            }
                        }
                    }

                    // Attachment Section
                    if (tmpl.attachmentPath.isNotBlank()) {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = DawamiTeal.copy(alpha = 0.08f)),
                            border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.AttachFile, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(18.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = tmpl.attachmentName,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        val sz = getFileSizeLabelFromPath(tmpl.attachmentPath)
                                        if (sz.isNotBlank()) {
                                            Text(text = "الحجم: $sz", fontSize = 9.sp, color = Color.Gray)
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // Open / Preview Button
                                    Button(
                                        onClick = {
                                            val ext = tmpl.attachmentName.substringAfterLast('.', "").lowercase()
                                            if (ext in listOf("png", "jpg", "jpeg", "webp", "gif", "bmp")) {
                                                previewingImageAttachment = Pair(tmpl.attachmentPath, tmpl.attachmentName)
                                            } else {
                                                openAttachmentFile(context, tmpl.attachmentPath, tmpl.attachmentName)
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.weight(1f).height(32.dp)
                                    ) {
                                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("معاينة وفتح 👁️", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // Share button
                                    Button(
                                        onClick = {
                                            viewingTemplateDetails = null
                                            sharingTemplate = tmpl
                                            showSharingDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.weight(1f).height(32.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("مشاركة وإرسال 📤", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val current = viewingTemplateDetails
                        viewingTemplateDetails = null
                        if (current != null) {
                            editingTemplate = current
                            tempAttachmentPath = current.attachmentPath
                            tempAttachmentName = current.attachmentName
                            showAddEditTemplateDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تعديل التكليف ✏️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewingTemplateDetails = null }) {
                    Text("إغلاق", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }

    // 2. In-App Image Viewer Dialog
    if (previewingImageAttachment != null) {
        val (filePath, fileName) = previewingImageAttachment!!
        Dialog(
            onDismissRequest = { previewingImageAttachment = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.94f)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f)),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(18.dp))
                            Text(
                                text = fileName,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { previewingImageAttachment = null },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.Gray, modifier = Modifier.size(18.dp))
                        }
                    }

                    // Image Display
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 180.dp, max = 380.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp)),
                        color = Color(0xFF0F172A)
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            AsyncImage(
                                model = if (filePath.startsWith("content://") || filePath.startsWith("file://")) {
                                    android.net.Uri.parse(filePath)
                                } else {
                                    java.io.File(filePath)
                                },
                                contentDescription = fileName,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Fit
                            )
                        }
                    }

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                openAttachmentFile(context, filePath, fileName)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f).height(36.dp)
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("فتح بالاستوديو ↗️", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { previewingImageAttachment = null },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("إغلاق", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubjectTeachingStatsSection(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    isDarkTheme: Boolean
) {
    val context = LocalContext.current
    val courses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val showCompletedCourses by viewModel.showCompletedCoursesInDropdowns.collectAsState()
    val dbSubjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()
    val dbCourseSubjects by (courseViewModel?.allCourseSubjects ?: viewModel.dbCourseSubjects).collectAsState()
    val dbAllStudentAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()
    val dbAttendance by (attendanceViewModel?.allAttendance ?: viewModel.dbAttendance).collectAsState()
    val dbAllStudents by viewModel.dbAllStudents.collectAsState()
    val dbAllGrades by viewModel.dbAllGrades.collectAsState()
    val dbAllGradeConfigs by viewModel.dbAllGradeConfigs.collectAsState()
    val enabledOfficialHolidays by viewModel.enabledOfficialHolidays.collectAsState()

    var selectedCourseId by remember { mutableIntStateOf(courses.firstOrNull()?.id ?: 0) }
    LaunchedEffect(courses) {
        if (selectedCourseId == 0 && courses.isNotEmpty()) {
            selectedCourseId = courses.first().id
        }
    }
    var isCourseDropdownExpanded by remember { mutableStateOf(false) }

    var editingStatSubjectId by remember { mutableIntStateOf(-1) }
    var editTargetDaysText by remember { mutableStateOf("") }
    var editNotesText by remember { mutableStateOf("") }
    var refreshTrigger by remember { mutableIntStateOf(0) }
    var isRefreshing by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    val selectedCourse = courses.find { it.id == selectedCourseId } ?: courses.firstOrNull()

    var showFinalReportDialog by remember { mutableStateOf(false) }
    var showReportSharePreviewDialog by remember { mutableStateOf(false) }
    var reportShareMessageText by remember { mutableStateOf("") }
    var currentExportStats by remember { mutableStateOf<List<com.example.data.entity.CourseSubjectStat>>(emptyList()) }
    var selectedStatForPdf by remember { mutableStateOf<com.example.data.entity.CourseSubjectStat?>(null) }
    var pdfExportType by remember { mutableStateOf("FINAL_REPORT") }
    var isGradesExportWeighted by remember { mutableStateOf(false) }
    var showGradesExportModeDialog by remember { mutableStateOf(false) }
    var showPdfSubjectsOrderDialog by remember { mutableStateOf(false) }

    val sharedPrefs = remember(context) {
        context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
    }
    var trainerNotes by remember(selectedCourseId) {
        mutableStateOf(sharedPrefs.getString("course_trainer_notes_$selectedCourseId", "") ?: "")
    }
    var showTrainerNotesDialog by remember { mutableStateOf(false) }
    var tempTrainerNotesText by remember { mutableStateOf("") }

    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null && selectedCourse != null) {
            coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        val studentsInCourse = dbAllStudents.filter { it.courseId == selectedCourse.id }
                        val grades = dbAllGrades.filter { it.courseId == selectedCourse.id }
                        if (pdfExportType == "GRADES") {
                            val exact = dbAllGradeConfigs.find { it.courseId == selectedCourse.id }
                            val dipTemplateId = if (selectedCourse.diplomaName.isNotEmpty()) StudentGradeConfig.getDiplomaTemplateId(selectedCourse.diplomaName) else null
                            val dipTemplate = if (dipTemplateId != null) dbAllGradeConfigs.find { it.courseId == dipTemplateId } else null
                            val config = exact ?: dipTemplate ?: StudentGradeConfig(courseId = selectedCourse.id, courseName = selectedCourse.name, isDiploma = true)
                            com.example.ui.pdf.PdfReportHelper.exportCourseGradesToPdf(
                                viewModel = viewModel,
                                course = selectedCourse,
                                config = config,
                                students = studentsInCourse,
                                grades = grades,
                                outputStream = outputStream,
                                useWeighted = isGradesExportWeighted
                            )
                        } else if (pdfExportType == "SINGLE_SUBJECT" && selectedStatForPdf != null) {
                            com.example.ui.pdf.PdfReportHelper.exportSingleSubjectReportToPdf(
                                viewModel = viewModel,
                                course = selectedCourse,
                                stat = selectedStatForPdf!!,
                                students = studentsInCourse,
                                grades = grades,
                                attendanceList = dbAllStudentAttendance,
                                attendanceSessions = dbAttendance,
                                outputStream = outputStream
                            )
                        } else {
                            val notesForPdf = sharedPrefs.getString("course_trainer_notes_${selectedCourse.id}", "") ?: ""
                            com.example.ui.pdf.PdfReportHelper.exportCourseFinalReportToPdf(
                                viewModel = viewModel,
                                course = selectedCourse,
                                stats = currentExportStats,
                                students = studentsInCourse,
                                grades = grades,
                                attendanceList = dbAllStudentAttendance,
                                outputStream = outputStream,
                                trainerNotes = notesForPdf
                            )
                        }
                    }
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        Toast.makeText(context, "تم تصدير التقرير بنجاح بصيغة PDF! 📄💾", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        Toast.makeText(context, "فشل تصدير التقرير: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    val triggerPdfLaunch: (String) -> Unit = { fileName ->
        if (viewModel.trainerBaseDirUri.value.isNotEmpty() && selectedCourse != null) {
            coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                val success = viewModel.savePdfReportToReportsFolder(context, fileName) { outputStream ->
                    val studentsInCourse = dbAllStudents.filter { it.courseId == selectedCourse!!.id }
                    val grades = dbAllGrades.filter { it.courseId == selectedCourse!!.id }
                    if (pdfExportType == "GRADES") {
                        val exact = dbAllGradeConfigs.find { it.courseId == selectedCourse!!.id }
                        val dipTemplateId = if (selectedCourse!!.diplomaName.isNotEmpty()) StudentGradeConfig.getDiplomaTemplateId(selectedCourse!!.diplomaName) else null
                        val dipTemplate = if (dipTemplateId != null) dbAllGradeConfigs.find { it.courseId == dipTemplateId } else null
                        val config = exact ?: dipTemplate ?: StudentGradeConfig(courseId = selectedCourse!!.id, courseName = selectedCourse!!.name, isDiploma = true)
                        com.example.ui.pdf.PdfReportHelper.exportCourseGradesToPdf(
                            viewModel = viewModel,
                            course = selectedCourse!!,
                            config = config,
                            students = studentsInCourse,
                            grades = grades,
                            outputStream = outputStream,
                            useWeighted = isGradesExportWeighted
                        )
                    } else if (pdfExportType == "SINGLE_SUBJECT" && selectedStatForPdf != null) {
                        com.example.ui.pdf.PdfReportHelper.exportSingleSubjectReportToPdf(
                            viewModel = viewModel,
                            course = selectedCourse!!,
                            stat = selectedStatForPdf!!,
                            students = studentsInCourse,
                            grades = grades,
                            attendanceList = dbAllStudentAttendance,
                            attendanceSessions = dbAttendance,
                            outputStream = outputStream
                        )
                    } else {
                        val notesForPdf = sharedPrefs.getString("course_trainer_notes_${selectedCourse!!.id}", "") ?: ""
                        com.example.ui.pdf.PdfReportHelper.exportCourseFinalReportToPdf(
                            viewModel = viewModel,
                            course = selectedCourse!!,
                            stats = currentExportStats,
                            students = studentsInCourse,
                            grades = grades,
                            attendanceList = dbAllStudentAttendance,
                            outputStream = outputStream,
                            trainerNotes = notesForPdf
                        )
                    }
                }
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    if (success) {
                        Toast.makeText(context, "تم حفظ التقرير تلقائياً في مجلد Reports بنجاح! 📄⚡", Toast.LENGTH_LONG).show()
                    } else {
                        pdfLauncher.launch(fileName)
                    }
                }
            }
        } else {
            pdfLauncher.launch(fileName)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Course Selector Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else Color.White),
            border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "اختر الدورة التدريبية لعرض إحصائيات التدريس وحالة المواد:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy,
                        modifier = Modifier.weight(1f)
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DawamiTeal.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(enabled = !isRefreshing) {
                                isRefreshing = true
                                refreshTrigger++
                                coroutineScope.launch {
                                    kotlinx.coroutines.delay(350)
                                    isRefreshing = false
                                    Toast.makeText(context, "تم تحديث إحصائيات المواد وحضور المدرب بنجاح 🔄", Toast.LENGTH_SHORT).show()
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (isRefreshing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(13.dp),
                                    strokeWidth = 1.8.dp,
                                    color = DawamiTeal
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "تحديث",
                                    tint = DawamiTeal,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            Text(
                                text = if (isRefreshing) "جارٍ التحديث..." else "تحديث",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiTeal
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { isCourseDropdownExpanded = true }
                                .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                            color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.School, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                                    Text(
                                        text = selectedCourse?.name ?: "اختر دورة...",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDarkTheme) Color.White else DawamiNavy,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        }

                        DropdownMenu(
                            expanded = isCourseDropdownExpanded,
                            onDismissRequest = { isCourseDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                        )
                                        Icon(
                                            imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = null,
                                            tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                },
                                onClick = {
                                    viewModel.toggleShowCompletedCoursesInDropdowns()
                                }
                            )
                            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                            val displayedCourses = if (showCompletedCourses) courses else courses.filter { !it.isCompleted }
                            displayedCourses.forEach { course ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = if (course.isCompleted) "${course.name} (منتهية 🔒)" else course.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = if (course.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    onClick = {
                                        selectedCourseId = course.id
                                        isCourseDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // زر ترتيب المواد لكشوفات PDF
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DawamiNavy.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(enabled = selectedCourse != null) {
                                showPdfSubjectsOrderDialog = true
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "ترتيب المواد في كشوفات PDF",
                                tint = DawamiNavy,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "ترتيب المواد 🔀",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy
                            )
                        }
                    }
                }
            }
        }

        if (selectedCourse != null) {
            var stats by remember { mutableStateOf<List<com.example.data.entity.CourseSubjectStat>>(emptyList()) }
            LaunchedEffect(dbSubjects, courses, dbCourseSubjects, dbAllStudentAttendance, dbAttendance, selectedCourse.id, refreshTrigger) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                    val s = viewModel.getCourseSubjectStats(
                        courseId = selectedCourse.id,
                        courseSubjectsList = dbCourseSubjects,
                        attendanceList = dbAttendance,
                        studentAttendanceList = dbAllStudentAttendance,
                        subjectsList = dbSubjects,
                        coursesList = courses
                    )
                    stats = s
                    currentExportStats = s
                }
            }

            val allSubjectsDone = stats.isNotEmpty() && stats.all { it.status.contains("مكتمل") }

            // Course Completion Status Card / Trigger
            if (allSubjectsDone && !selectedCourse.isCompleted) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    border = BorderStroke(1.dp, Color(0xFFF59E0B))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("اكتمل تدريس جميع مواد الدورة بنجاح! 🏁", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = Color(0xFF92400E))
                            Text("يمكنك جعل الدورة منتهية لحجبها عن القوائم اليومية تلقائياً.", fontSize = 9.5.sp, color = Color(0xFFB45309))
                        }
                        Button(
                            onClick = {
                                viewModel.toggleCourseCompleted(selectedCourse)
                                Toast.makeText(context, "تم تعيين الدورة كمنتهية بنجاح 🏁", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("جعلها منتهية 🏁", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else if (selectedCourse.isCompleted) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("🔒 حالة الدورة: منتهية", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = Color(0xFF334155))
                            val dateInfo = if (selectedCourse.endDate.isNotBlank()) "تاريخ الانتهاء: ${selectedCourse.endDate}" else "محجوبة تلقائياً عن القوائم المنسدلة اليومية."
                            Text(dateInfo, fontSize = 9.5.sp, color = Color(0xFF64748B))
                        }
                        OutlinedButton(
                            onClick = {
                                viewModel.toggleCourseCompleted(selectedCourse)
                                Toast.makeText(context, "تمت إعادة تنشيط الدورة كمستمرة 🔄", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("إعادة تنشيط 🔄", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        }
                    }
                }
            } else {
                // Course is ongoing: provide direct option to finish if desired
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("حالة الدورة: 🟢 مستمرة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF15803D))
                    OutlinedButton(
                        onClick = {
                            viewModel.toggleCourseCompleted(selectedCourse)
                            Toast.makeText(context, "تم تعيين الدورة كمنتهية 🏁", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                        border = BorderStroke(1.dp, Color(0xFFFECACA))
                    ) {
                        Text("جعل الدورة منتهية 🏁", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Overview Summary Cards Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val totalSubjects = stats.size
                val completedSubjects = stats.count { it.status == "مكتملة التدريس" || it.status == "مكتملة بالكامل" }
                val examPending = stats.count { it.status == "في انتظار الاختبار" || it.status == "مؤجلة الاختبار" }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                    border = BorderStroke(1.dp, Color(0xFFBFDBFE))
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text("إجمالي المواد", fontSize = 10.sp, color = Color(0xFF1E40AF), fontWeight = FontWeight.Bold)
                        Text("$totalSubjects", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFDCFCE7)),
                    border = BorderStroke(1.dp, Color(0xFF86EFAC))
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text("مكتملة التدريس", fontSize = 10.sp, color = Color(0xFF166534), fontWeight = FontWeight.Bold)
                        Text("$completedSubjects", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    border = BorderStroke(1.dp, Color(0xFFFDE68A))
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text("مؤجلة الامتحان", fontSize = 10.sp, color = Color(0xFF92400E), fontWeight = FontWeight.Bold)
                        Text("$examPending", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF78350F))
                    }
                }
            }

            val studentsInCourse = remember(selectedCourse.id, dbAllStudents) {
                dbAllStudents.filter { it.courseId == selectedCourse.id }
            }

            // حساب أيام التدريس المقررة بين تاريخ البداية والنهاية
            val courseDaysCount = remember(selectedCourse.startDate, selectedCourse.endDate, enabledOfficialHolidays) {
                val td = countTrainingDays(selectedCourse.startDate, selectedCourse.endDate, false, enabledOfficialHolidays)
                if (td > 0) td else {
                    try {
                        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                        val d1 = sdf.parse(selectedCourse.startDate)
                        val d2 = sdf.parse(selectedCourse.endDate)
                        if (d1 != null && d2 != null) {
                            val diff = ((d2.time - d1.time) / (1000 * 60 * 60 * 24)).toInt() + 1
                            if (diff > 0) diff else 0
                        } else 0
                    } catch (e: Exception) { 0 }
                }
            }

            // حساب عدد الأيام والساعات الفعلية المنجزة من سجلات تحضير المدرب
            val trainerCourseRecords = remember(selectedCourse.id, dbAttendance) {
                dbAttendance.filter { it.courseId == selectedCourse.id && it.status == "حضور" }
            }
            val actualTrainerDaysCount = trainerCourseRecords.size

            // بطاقة تواريخ الدورة ومدة الأيام وزر التقرير الختامي (مباشرة تحت المربعات الثلاثة)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDarkTheme) DarkSurface else Color(0xFFF8FAFC)
                ),
                border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // الصف الأول: تاريخ البداية، تاريخ النهاية، أيام الخطة، والأيام الفعلية
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // تاريخ البداية
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkTheme) Color(0xFF1E293B) else Color.White,
                            border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("📅 البداية", fontSize = 8.5.sp, color = if (isDarkTheme) Color(0xFF94A3B8) else Color(0xFF64748B), fontWeight = FontWeight.Medium)
                                Text(
                                    text = selectedCourse.startDate.ifEmpty { "غير محدد" },
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) Color.White else DawamiNavy,
                                    maxLines = 1
                                )
                            }
                        }

                        // تاريخ النهاية
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkTheme) Color(0xFF1E293B) else Color.White,
                            border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("🏁 النهاية", fontSize = 8.5.sp, color = if (isDarkTheme) Color(0xFF94A3B8) else Color(0xFF64748B), fontWeight = FontWeight.Medium)
                                Text(
                                    text = selectedCourse.endDate.ifEmpty { "غير محدد" },
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) Color.White else DawamiNavy,
                                    maxLines = 1
                                )
                            }
                        }

                        // أيام الخطة (التقويم)
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkTheme) Color(0xFF1E293B) else Color.White,
                            border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("⏳ أيام الخطة", fontSize = 8.5.sp, color = if (isDarkTheme) Color(0xFF94A3B8) else Color(0xFF64748B), fontWeight = FontWeight.Medium)
                                Text(
                                    text = "$courseDaysCount يوم",
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiTeal,
                                    maxLines = 1
                                )
                            }
                        }

                        // الأيام الفعلية (تحضير المدرب)
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDarkTheme) Color(0xFF064E3B).copy(alpha = 0.3f) else Color(0xFFECFDF5),
                            border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF059669) else Color(0xFFA7F3D0))
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("⏱️ الأيام الفعلية", fontSize = 8.5.sp, color = Color(0xFF059669), fontWeight = FontWeight.Bold)
                                Text(
                                    text = "$actualTrainerDaysCount يوم",
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF047857),
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    // الصف الثاني: زر التقرير الختامي للدورة والطلاب + أزرار الإجراء السريع (PDF و واتساب)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { showFinalReportDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp)
                        ) {
                            Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(15.dp), tint = Color.White)
                            Spacer(Modifier.width(4.dp))
                            Text("التقرير الختامي الشامل للدورة والطلاب 🎓", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                        }

                        // تصدير PDF سريع
                        FilledTonalButton(
                            onClick = {
                                pdfExportType = "FINAL_REPORT"
                                currentExportStats = stats
                                triggerPdfLaunch("التقرير_الختامي_${selectedCourse.name.replace(" ", "_")}.pdf")
                            },
                            modifier = Modifier.height(36.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFEFF6FF),
                                contentColor = Color(0xFF1D4ED8)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFFDC2626))
                            Spacer(Modifier.width(3.dp))
                            Text("PDF", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                        }

                        // مشاركة واتساب سريعة
                        FilledTonalButton(
                            onClick = {
                                val shareText = generateCourseFinalReportText(
                                    selectedCourse = selectedCourse,
                                    courseDaysCount = courseDaysCount,
                                    stats = stats,
                                    studentsInCourse = studentsInCourse,
                                    dbAllStudentAttendance = dbAllStudentAttendance,
                                    dbAllGrades = dbAllGrades,
                                    dbGradeConfigs = dbAllGradeConfigs,
                                    actualTrainerDaysCount = actualTrainerDaysCount,
                                    trainerNotes = trainerNotes
                                )

                                reportShareMessageText = shareText
                                showReportSharePreviewDialog = true
                            },
                            modifier = Modifier.height(36.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFDCFCE7),
                                contentColor = Color(0xFF15803D)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF15803D))
                            Spacer(Modifier.width(3.dp))
                            Text("واتساب", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // الصف الثالث: زر ملاحظات المدرب للدورة
                    OutlinedButton(
                        onClick = {
                            tempTrainerNotesText = trainerNotes
                            showTrainerNotesDialog = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(36.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (trainerNotes.isNotBlank()) (if (isDarkTheme) Color(0xFF064E3B).copy(alpha = 0.4f) else Color(0xFFECFDF5)) else (if (isDarkTheme) Color(0xFF1E293B) else Color.White),
                            contentColor = if (trainerNotes.isNotBlank()) Color(0xFF047857) else DawamiNavy
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (trainerNotes.isNotBlank()) Color(0xFF10B981) else (if (isDarkTheme) Color(0xFF475569) else Color(0xFFCBD5E1))
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                    ) {
                        Icon(
                            Icons.Default.EditNote,
                            contentDescription = null,
                            modifier = Modifier.size(17.dp),
                            tint = if (trainerNotes.isNotBlank()) Color(0xFF047857) else DawamiNavy
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (trainerNotes.isNotBlank()) "ملاحظات المدرب للدورة (مدونة ومدرجة في التقرير) 📝" else "ملاحظات المدرب للدورة التدريبية 📝",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }

            // نافذة إدخال وتعديل ملاحظات المدرب للدورة
            if (showTrainerNotesDialog && selectedCourse != null) {
                AlertDialog(
                    onDismissRequest = { showTrainerNotesDialog = false },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.EditNote, contentDescription = null, tint = DawamiNavy)
                            Text("ملاحظات المدرب للدورة", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        }
                    },
                    text = {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "دورة: ${selectedCourse.name}",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiTeal
                            )
                            Text(
                                text = "الملاحظات المدونة هنا ستظهر تلقائياً في التقرير الختامي الشامل (PDF و واتساب) الخاص بهذه الدورة:",
                                fontSize = 10.sp,
                                color = if (isDarkTheme) Color(0xFF94A3B8) else Color(0xFF64748B),
                                lineHeight = 15.sp
                            )
                            OutlinedTextField(
                                value = tempTrainerNotesText,
                                onValueChange = { tempTrainerNotesText = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 120.dp, max = 220.dp),
                                placeholder = {
                                    Text(
                                        "اكتب هنا ملاحظاتك وتوجيهاتك وتوصياتك الختامية للدورة والطلاب...",
                                        fontSize = 10.sp,
                                        color = Color.Gray
                                    )
                                },
                                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, lineHeight = 16.sp),
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = DawamiNavy,
                                    unfocusedBorderColor = if (isDarkTheme) Color(0xFF475569) else Color(0xFFCBD5E1)
                                )
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val trimmed = tempTrainerNotesText.trim()
                                sharedPrefs.edit().putString("course_trainer_notes_${selectedCourse.id}", trimmed).apply()
                                trainerNotes = trimmed
                                showTrainerNotesDialog = false
                                Toast.makeText(context, "تم حفظ ملاحظات المدرب بنجاح 💾", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("حفظ الملاحظات", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (trainerNotes.isNotBlank()) {
                                TextButton(
                                    onClick = {
                                        sharedPrefs.edit().remove("course_trainer_notes_${selectedCourse.id}").apply()
                                        trainerNotes = ""
                                        tempTrainerNotesText = ""
                                        showTrainerNotesDialog = false
                                        Toast.makeText(context, "تم مسح ملاحظات المدرب", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFDC2626))
                                ) {
                                    Text("مسح", fontSize = 10.5.sp)
                                }
                            }
                            TextButton(
                                onClick = { showTrainerNotesDialog = false }
                            ) {
                                Text("إلغاء", fontSize = 10.5.sp)
                            }
                        }
                    }
                )
            }

            // نافذة منبثقة تفاعلية للمعاينة وخيارات التقرير الختامي
            if (showFinalReportDialog) {
                val completedCount = stats.count { it.status == "مكتملة التدريس" || it.status == "مكتملة بالكامل" }
                val examPendingCount = stats.count { it.status == "في انتظار الاختبار" || it.status == "مؤجلة الاختبار" }
                val progressPct = if (stats.isNotEmpty()) (completedCount * 100) / stats.size else 0

                AlertDialog(
                    onDismissRequest = { showFinalReportDialog = false },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Assessment, contentDescription = null, tint = DawamiNavy)
                            Text("التقرير الختامي الشامل للدورة", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        }
                    },
                    text = {
                        Column(
                            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // ملخص بطاقة الدورة
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9))
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("📌 الدورة: ${selectedCourse.name}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.White else DawamiNavy)
                                    if (selectedCourse.trainerName.isNotEmpty()) {
                                        Text("👨‍🏫 المدرب: ${selectedCourse.trainerName}", fontSize = 10.sp, color = if (isDarkTheme) Color(0xFFCBD5E1) else Color(0xFF475569))
                                    }
                                    if (selectedCourse.departmentName.isNotEmpty() || selectedCourse.diplomaName.isNotEmpty()) {
                                        Text("🏢 القسم/الدبلوم: ${listOfNotNull(selectedCourse.departmentName.ifEmpty { null }, selectedCourse.diplomaName.ifEmpty { null }).joinToString(" - ")}", fontSize = 10.sp, color = if (isDarkTheme) Color(0xFFCBD5E1) else Color(0xFF475569))
                                    }
                                    Text("📅 المدة: من ${selectedCourse.startDate.ifEmpty { "-" }} إلى ${selectedCourse.endDate.ifEmpty { "-" }} ($courseDaysCount يوم تدريبي)", fontSize = 10.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)
                                    Text("🚦 الحالة: ${if (selectedCourse.isCompleted) "منتهية 🏁" else "مستمرة 🟢"}", fontSize = 10.sp, color = if (selectedCourse.isCompleted) Color(0xFFDC2626) else Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                                }
                            }

                            // إحصائيات الإنجاز
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC))
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("📊 ملخص الإنجاز الدراسي:", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                    Text("• إجمالي المواد المقررة: ${stats.size}", fontSize = 10.sp)
                                    Text("• المواد المكتملة تدريساً: $completedCount", fontSize = 10.sp, color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                                    Text("• المواد في انتظار/مؤجلة الاختبار: $examPendingCount", fontSize = 10.sp, color = Color(0xFFD97706))
                                    Text("• نسبة إنجاز الخطة: $progressPct%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                    Text("• عدد الطلاب المسجلين بالدورة: ${studentsInCourse.size} طالب", fontSize = 10.sp, fontWeight = FontWeight.Medium)
                                }
                            }

                            Text("اختر الإجراء المطلوب للتقرير:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) Color.White else DawamiNavy)

                            // خيار 1: تصدير تقرير إنجاز المواد والدورة PDF
                            Button(
                                onClick = {
                                    pdfExportType = "FINAL_REPORT"
                                    currentExportStats = stats
                                    showFinalReportDialog = false
                                    triggerPdfLaunch("التقرير_الختامي_${selectedCourse.name.replace(" ", "_")}.pdf")
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFFFCA5A5), modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("📄 تصدير تقرير إنجاز المواد والدورة PDF", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }

                            // خيار 2: تصدير كشف درجات الطلاب الرسمي PDF
                            OutlinedButton(
                                onClick = {
                                    pdfExportType = "GRADES"
                                    currentExportStats = stats
                                    showFinalReportDialog = false
                                    showGradesExportModeDialog = true
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = DawamiNavy),
                                border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Grading, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("📊 تصدير كشف درجات الطلاب الرسمي PDF", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }

                            // خيار 3: مشاركة التقرير المنسق عبر واتساب
                            FilledTonalButton(
                                onClick = {
                                    showFinalReportDialog = false
                                    val shareText = generateCourseFinalReportText(
                                        selectedCourse = selectedCourse,
                                        courseDaysCount = courseDaysCount,
                                        stats = stats,
                                        studentsInCourse = studentsInCourse,
                                        dbAllStudentAttendance = dbAllStudentAttendance,
                                        dbAllGrades = dbAllGrades,
                                        dbGradeConfigs = dbAllGradeConfigs,
                                        actualTrainerDaysCount = actualTrainerDaysCount,
                                        trainerNotes = trainerNotes
                                    )

                                    reportShareMessageText = shareText
                                    showReportSharePreviewDialog = true
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFDCFCE7), contentColor = Color(0xFF15803D)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("📲 مشاركة التقرير المنسق عبر واتساب", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showFinalReportDialog = false }) {
                            Text("إغلاق", fontWeight = FontWeight.Bold, color = DawamiNavy)
                        }
                    }
                )
            }

            if (showReportSharePreviewDialog) {
                WhatsAppChoiceDialog(
                    onDismiss = { showReportSharePreviewDialog = false },
                    shareMessageText = reportShareMessageText,
                    context = context
                )
            }

            // نافذة تعديل الخطة (الأيام المقررة) والملاحظات للمادة
            if (editingStatSubjectId != -1) {
                val statToEdit = stats.find { it.subjectId == editingStatSubjectId }
                if (statToEdit != null) {
                    AlertDialog(
                        onDismissRequest = { editingStatSubjectId = -1 },
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.EventNote, contentDescription = null, tint = DawamiNavy)
                                Text("تعديل خطة المادة ⚙️", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("المادة: ${statToEdit.subjectName}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DawamiTeal)

                                OutlinedTextField(
                                    value = editTargetDaysText,
                                    onValueChange = { if (it.all { c -> c.isDigit() }) editTargetDaysText = it },
                                    label = { Text("عدد الأيام المقررة في الخطة", fontSize = 10.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )

                                OutlinedTextField(
                                    value = editNotesText,
                                    onValueChange = { editNotesText = it },
                                    label = { Text("ملاحظات خاصة بالمادة", fontSize = 10.sp) },
                                    modifier = Modifier.fillMaxWidth().height(100.dp),
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    val days = editTargetDaysText.toIntOrNull() ?: 0
                                    viewModel.updateCourseSubjectStatus(
                                        courseId = selectedCourse.id,
                                        subjectId = editingStatSubjectId,
                                        newStatus = statToEdit.status,
                                        targetDays = days,
                                        notes = editNotesText
                                    )
                                    editingStatSubjectId = -1
                                    Toast.makeText(context, "تم تحديث خطة المادة بنجاح 💾", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                            ) {
                                Text("حفظ التغييرات", fontSize = 11.sp)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { editingStatSubjectId = -1 }) {
                                Text("إلغاء", fontSize = 11.sp)
                            }
                        }
                    )
                }
            }

            if (showGradesExportModeDialog && selectedCourse != null) {
                AlertDialog(
                    onDismissRequest = { showGradesExportModeDialog = false },
                    icon = {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(32.dp))
                    },
                    title = {
                        Text(
                            text = "تصدير كشف درجات الطلاب الرسمي PDF",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center
                        )
                    },
                    text = {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "اختر نمط احتساب وعرض درجات المواد في التقرير:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // خيار 1: حسب تهيئة المواد (الدرجة الفعلية لكل مادة)
                            Card(
                                onClick = {
                                    isGradesExportWeighted = false
                                    showGradesExportModeDialog = false
                                    triggerPdfLaunch("كشف_الدرجات_الرسمي_${selectedCourse.name.replace(" ", "_")}.pdf")
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.5.dp, DawamiNavy.copy(alpha = 0.3f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = DawamiNavy.copy(alpha = 0.1f),
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Grading, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(20.dp))
                                        }
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "حسب تهيئة المواد (الدرجة المرصودة)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = DawamiNavy
                                        )
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            text = "يعرض الدرجة الفعلية المرصودة لكل مادة من الدرجة العظمى (مثل 100) موضحة تحت اسم المادة، مع المجموع العام والمعدل %.",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            lineHeight = 14.sp
                                        )
                                    }
                                }
                            }

                            // خيار 2: حسب الموزون العام (أوزان المواد المعتمدة)
                            Card(
                                onClick = {
                                    isGradesExportWeighted = true
                                    showGradesExportModeDialog = false
                                    triggerPdfLaunch("كشف_الدرجات_الرسمي_${selectedCourse.name.replace(" ", "_")}_موزون.pdf")
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.5.dp, DawamiTeal.copy(alpha = 0.3f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = DawamiTeal.copy(alpha = 0.1f),
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Calculate, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(20.dp))
                                        }
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "حسب الموزون العام (أوزان المواد المعتمدة)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = DawamiTeal
                                        )
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            text = "يعرض الدرجة الموزونة لكل مادة بحسب وزنها النسبي (مثل وزن 15) موضحاً تحت اسم المادة، مع مجموع الأوزان والمعدل الموزون.",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            lineHeight = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton(onClick = { showGradesExportModeDialog = false }) {
                            Text("إلغاء", fontWeight = FontWeight.Bold)
                        }
                    },
                    shape = RoundedCornerShape(16.dp)
                )
            }

            if (showPdfSubjectsOrderDialog && selectedCourse != null) {
                val exactCfg = dbAllGradeConfigs.find { it.courseId == selectedCourse.id }
                val dipTemplateId = if (selectedCourse.diplomaName.isNotEmpty()) StudentGradeConfig.getDiplomaTemplateId(selectedCourse.diplomaName) else null
                val dipTemplate = if (dipTemplateId != null) dbAllGradeConfigs.find { it.courseId == dipTemplateId } else null
                val cfg = exactCfg ?: dipTemplate ?: StudentGradeConfig(courseId = selectedCourse.id, courseName = selectedCourse.name, isDiploma = true)

                val rawCourseSubjects = remember(selectedCourse.id, cfg) {
                    if (cfg.isDiploma) {
                        cfg.getDiplomaSubjects()
                    } else {
                        val cFields = StudentGradeConfig.deserializeFields(cfg.customFieldsJson)
                        val subs = cFields.map { it.first.substringBefore("_") }.distinct()
                        if (subs.isNotEmpty()) subs else listOf("المقرر العام")
                    }
                }

                var orderedSubjects by remember(selectedCourse.id, showPdfSubjectsOrderDialog) {
                    val saved = viewModel.getPdfSubjectsOrder(selectedCourse.id)
                    val list = if (!saved.isNullOrEmpty()) {
                        val ordered = saved.filter { sName -> rawCourseSubjects.any { it.trim().equals(sName.trim(), ignoreCase = true) } }
                        val remaining = rawCourseSubjects.filter { rName -> !ordered.any { it.trim().equals(rName.trim(), ignoreCase = true) } }
                        ordered + remaining
                    } else {
                        StudentGradeConfig.sortSubjectsList(rawCourseSubjects)
                    }
                    mutableStateOf(list.toMutableList())
                }

                AlertDialog(
                    onDismissRequest = { showPdfSubjectsOrderDialog = false },
                    icon = {
                        Icon(Icons.Default.SwapVert, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(32.dp))
                    },
                    title = {
                        Text(
                            text = "ترتيب المواد في كشوفات PDF 📄",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center
                        )
                    },
                    text = {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "حدد ترتيب ظهور أعمدة المواد في كشوفات درجات الطلاب الرسمية (PDF). لن تتأثر الدرجات أو تقارير الواتساب:",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 15.sp
                            )

                            // أزرار الضبط السريع
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            orderedSubjects = StudentGradeConfig.sortSubjectsList(rawCourseSubjects).toMutableList()
                                        },
                                    color = DawamiTeal.copy(alpha = 0.12f),
                                    border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.35f))
                                ) {
                                    Text(
                                        text = "البوربوينت بعد الوورد (افتراضي) 🎯",
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiTeal,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp)
                                    )
                                }

                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            val base = StudentGradeConfig.sortSubjectsList(rawCourseSubjects).toMutableList()
                                            val pptIdx = base.indexOfFirst { it.contains("بوربوينت") || it.contains("العروض") }
                                            val xlsIdx = base.indexOfFirst { it.contains("اكسل") || it.contains("إكسل") || it.contains("الجداول") }
                                            if (pptIdx != -1 && xlsIdx != -1) {
                                                val pptItem = base.removeAt(pptIdx)
                                                val newXlsIdx = base.indexOfFirst { it.contains("اكسل") || it.contains("إكسل") || it.contains("الجداول") }
                                                base.add(newXlsIdx + 1, pptItem)
                                            }
                                            orderedSubjects = base
                                        },
                                    color = Color.LightGray.copy(alpha = 0.2f),
                                    border = BorderStroke(1.dp, Color.Gray.copy(alpha = 0.3f))
                                ) {
                                    Text(
                                        text = "البوربوينت بعد الإكسل 🔄",
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.DarkGray,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp)
                                    )
                                }
                            }

                            // قائمة المواد مع أزرار الصعود والنزول
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                orderedSubjects.forEachIndexed { idx, subName ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Surface(
                                                    shape = CircleShape,
                                                    color = DawamiNavy.copy(alpha = 0.12f),
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text(
                                                            text = "${idx + 1}",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = DawamiNavy
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = subName,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(
                                                    onClick = {
                                                        if (idx > 0) {
                                                            val updated = orderedSubjects.toMutableList()
                                                            val item = updated.removeAt(idx)
                                                            updated.add(idx - 1, item)
                                                            orderedSubjects = updated
                                                        }
                                                    },
                                                    enabled = idx > 0,
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ArrowUpward,
                                                        contentDescription = "للأعلى",
                                                        tint = if (idx > 0) DawamiNavy else Color.LightGray,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }

                                                IconButton(
                                                    onClick = {
                                                        if (idx < orderedSubjects.size - 1) {
                                                            val updated = orderedSubjects.toMutableList()
                                                            val item = updated.removeAt(idx)
                                                            updated.add(idx + 1, item)
                                                            orderedSubjects = updated
                                                        }
                                                    },
                                                    enabled = idx < orderedSubjects.size - 1,
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ArrowDownward,
                                                        contentDescription = "للأسفل",
                                                        tint = if (idx < orderedSubjects.size - 1) DawamiNavy else Color.LightGray,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.savePdfSubjectsOrder(selectedCourse.id, orderedSubjects)
                                showPdfSubjectsOrderDialog = false
                                Toast.makeText(context, "تم حفظ ترتيب مواد كشوفات PDF بنجاح 📄✅", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("حفظ الترتيب ✅", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showPdfSubjectsOrderDialog = false }) {
                            Text("إلغاء", fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                        }
                    },
                    shape = RoundedCornerShape(16.dp)
                )
            }

            if (stats.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("لا توجد مواد مرتبطة بهذه الدورة.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            } else {
                stats.forEach { stat ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else Color.White),
                        border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stat.subjectName,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDarkTheme) Color.White else DawamiNavy
                                )

                                val (badgeBg, badgeFg, badgeText) = when (stat.status) {
                                    "مكتملة التدريس" -> Triple(Color(0xFFDCFCE7), Color(0xFF15803D), "مكتملة التدريس 🏁")
                                    "في انتظار الاختبار", "مؤجلة الاختبار" -> Triple(Color(0xFFFEF3C7), Color(0xFFB45309), "في انتظار الاختبار ⏳")
                                    "مكتملة بالكامل" -> Triple(Color(0xFFCCFBF1), Color(0xFF0F766E), "مكتملة بالكامل ✅")
                                    else -> Triple(Color(0xFFDBEAFE), Color(0xFF1D4ED8), "قيد التدريس 📖")
                                }

                                Surface(color = badgeBg, shape = RoundedCornerShape(6.dp)) {
                                    Text(
                                        text = badgeText,
                                        color = badgeFg,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = DawamiNavy.copy(alpha = 0.08f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "المنجز: ${stat.taughtDaysCount} يوم",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiNavy,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }

                                if (stat.targetDays > 0) {
                                    Surface(
                                        color = DawamiTeal.copy(alpha = 0.08f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "الخطة: ${stat.targetDays} يوم",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiTeal,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                if (stat.firstTaughtDate.isNotEmpty()) {
                                    Text(
                                        text = "البدء: ${stat.firstTaughtDate}",
                                        fontSize = 9.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (stat.targetDays > 0) {
                                val progress = (stat.taughtDaysCount.toFloat() / stat.targetDays.toFloat()).coerceIn(0f, 1f)
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    LinearProgressIndicator(
                                        progress = { progress },
                                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                        color = if (progress >= 1f) DawamiTeal else DawamiNavy,
                                        trackColor = if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0)
                                    )
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("نسبة الإنجاز", fontSize = 8.sp, color = Color.Gray)
                                        Text("${(progress * 100).toInt()}%", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                    }
                                }
                            }

                            HorizontalDivider(color = Color(0xFFF1F5F9))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.updateCourseSubjectStatus(selectedCourse.id, stat.subjectId, "مكتملة التدريس")
                                        Toast.makeText(context, "تم تغيير حالة (${stat.subjectName}) إلى مكتملة التدريس 🏁", Toast.LENGTH_SHORT).show()
                                    },
                                    enabled = stat.status != "مكتملة التدريس",
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp)
                                ) {
                                    Text("إكمال التدريس 🏁", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        viewModel.updateCourseSubjectStatus(selectedCourse.id, stat.subjectId, "في انتظار الاختبار")
                                        Toast.makeText(context, "تم تغيير حالة (${stat.subjectName}) إلى في انتظار الاختبار ⏳", Toast.LENGTH_SHORT).show()
                                    },
                                    enabled = stat.status != "في انتظار الاختبار",
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp)
                                ) {
                                    Text("تأجيل الاختبار ⏳", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        viewModel.updateCourseSubjectStatus(selectedCourse.id, stat.subjectId, "قيد التدريس")
                                        Toast.makeText(context, "تمت إعادة (${stat.subjectName}) إلى قيد التدريس 🔄", Toast.LENGTH_SHORT).show()
                                    },
                                    enabled = stat.status != "قيد التدريس",
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp)
                                ) {
                                    Text("قيد التدريس 🔄", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // أزرار تقارير المادة (PDF و واتساب)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // زر تصدير تقرير المادة بصيغة PDF
                                FilledTonalButton(
                                    onClick = {
                                        selectedStatForPdf = stat
                                        pdfExportType = "SINGLE_SUBJECT"
                                        val cleanSubName = stat.subjectName.replace("[^a-zA-Z0-9أ-ي]".toRegex(), "_")
                                        val cleanCourseName = selectedCourse.name.replace("[^a-zA-Z0-9أ-ي]".toRegex(), "_")
                                        triggerPdfLaunch("تقرير_مادة_${cleanSubName}_${cleanCourseName}.pdf")
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFEFF6FF),
                                        contentColor = DawamiNavy
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(vertical = 6.dp, horizontal = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PictureAsPdf,
                                        contentDescription = null,
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text("تقرير المادة (PDF) 📄", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                // زر تعديل الخطة والملاحظات للمادة
                                OutlinedButton(
                                    onClick = {
                                        editingStatSubjectId = stat.subjectId
                                        editTargetDaysText = stat.targetDays.toString()
                                        editNotesText = stat.notes
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(vertical = 6.dp, horizontal = 4.dp),
                                    border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.4f))
                                ) {
                                    Icon(Icons.Default.Settings, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("تعديل الخطة ⚙️", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                }

                                // زر مشاركة / نسخ تقرير المادة عبر الواتساب (دون تغيير)
                                FilledTonalButton(
                                    onClick = {
                                        val subjectShareText = generateSingleSubjectReportText(
                                            selectedCourse = selectedCourse,
                                            stat = stat,
                                            studentsInCourse = studentsInCourse,
                                            dbAllStudentAttendance = dbAllStudentAttendance,
                                            dbAttendance = dbAttendance,
                                            dbAllGrades = dbAllGrades,
                                            dbGradeConfigs = dbAllGradeConfigs
                                        )
                                        reportShareMessageText = subjectShareText
                                        showReportSharePreviewDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFEFF6FF),
                                        contentColor = DawamiNavy
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(vertical = 6.dp, horizontal = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = null,
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text("تقرير المادة (واتساب) 📲", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Utility helper functions for assignment attachments and sharing
fun copyFileToAppDir(context: android.content.Context, uri: android.net.Uri): Pair<String, String>? {
    try {
        val contentResolver = context.contentResolver
        val fileName = getAttachmentFileName(context, uri) ?: "attachment_${System.currentTimeMillis()}"
        
        val parentDir = java.io.File(context.filesDir, "dawami_assignments")
        if (!parentDir.exists()) {
            parentDir.mkdirs()
        }
        
        val destFile = java.io.File(parentDir, fileName)
        contentResolver.openInputStream(uri)?.use { inputStream ->
            java.io.FileOutputStream(destFile).use { outputStream ->
                inputStream.copyTo(outputStream)
            }
        }
        return Pair(destFile.absolutePath, fileName)
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return null
}

fun getAttachmentFileName(context: android.content.Context, uri: android.net.Uri): String? {
    var result: String? = null
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        try {
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (index != -1) {
                    result = cursor.getString(index)
                }
            }
        } finally {
            cursor?.close()
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/') ?: -1
        if (cut != -1) {
            result = result?.substring(cut + 1)
        }
    }
    return result
}

fun getFolderFriendlyName(context: android.content.Context, uri: android.net.Uri): String? {
    try {
        val docFile = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, uri)
        if (docFile != null && docFile.exists() && docFile.name != null) {
            return docFile.name
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    var result: String? = null
    if (uri.scheme == "content") {
        try {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (index != -1) {
                    result = cursor.getString(index)
                }
            }
            cursor?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/') ?: -1
        if (cut != -1) {
            result = result?.substring(cut + 1)
        }
    }
    return result
}

private fun findFileCaseInsensitive(parent: androidx.documentfile.provider.DocumentFile, name: String): androidx.documentfile.provider.DocumentFile? {
    val files = parent.listFiles()
    for (file in files) {
        val fileName = file.name
        if (fileName != null && fileName.equals(name, ignoreCase = true)) {
            return file
        }
    }
    return null
}

fun handleFileSelection(
    context: android.content.Context,
    uri: android.net.Uri,
    isReference: Boolean,
    baseDirUriString: String
): Pair<String, String>? {
    val fileName = getAttachmentFileName(context, uri) ?: "file_${System.currentTimeMillis()}"
    val subDirName = if (isReference) "references" else "projects"
    
    if (baseDirUriString.isNotEmpty()) {
        try {
            val baseUri = android.net.Uri.parse(baseDirUriString)
            val baseDir = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, baseUri)
            if (baseDir != null && baseDir.exists() && baseDir.isDirectory) {
                var targetSubDir = findFileCaseInsensitive(baseDir, subDirName)
                if (targetSubDir == null || !targetSubDir.exists()) {
                    targetSubDir = baseDir.createDirectory(subDirName)
                }
                
                if (targetSubDir != null && targetSubDir.exists() && targetSubDir.isDirectory) {
                    val existingFile = targetSubDir.findFile(fileName)
                    val isAlreadyInAppDir = uri.toString().contains("/$subDirName/") || 
                                             (existingFile != null && existingFile.uri.toString() == uri.toString())
                    
                    if (existingFile != null && (isAlreadyInAppDir || existingFile.exists())) {
                        return Pair(existingFile.uri.toString(), fileName)
                    }
                    
                    val newFile = targetSubDir.createFile("*/*", fileName)
                    if (newFile != null) {
                        context.contentResolver.openInputStream(uri)?.use { inputStream ->
                            context.contentResolver.openOutputStream(newFile.uri)?.use { outputStream ->
                                inputStream.copyTo(outputStream)
                            }
                        }
                        return Pair(newFile.uri.toString(), fileName)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    try {
        val baseDir = context.getExternalFilesDir(null) ?: context.filesDir
        val mainFolder = java.io.File(baseDir, "dawami_main")
        if (!mainFolder.exists()) {
            mainFolder.mkdirs()
        }
        
        val targetSubFolder = java.io.File(mainFolder, subDirName)
        if (!targetSubFolder.exists()) {
            targetSubFolder.mkdirs()
        }
        
        val destFile = java.io.File(targetSubFolder, fileName)
        val isAlreadyInAppDir = uri.path?.contains("/dawami_main/$subDirName/") == true || 
                                 destFile.absolutePath == uri.path || 
                                 destFile.exists()
        
        if (isAlreadyInAppDir && destFile.exists()) {
            return Pair(destFile.absolutePath, fileName)
        }
        
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            java.io.FileOutputStream(destFile).use { outputStream ->
                inputStream.copyTo(outputStream)
            }
        }
        return Pair(destFile.absolutePath, fileName)
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return null
}

fun getFilesInSubFolder(context: android.content.Context, isReference: Boolean, baseDirUriString: String): List<Pair<String, String>> {
    val subDirName = if (isReference) "references" else "projects"
    val fileList = mutableListOf<Pair<String, String>>()
    
    if (baseDirUriString.isNotEmpty()) {
        try {
            val baseUri = android.net.Uri.parse(baseDirUriString)
            val baseDir = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, baseUri)
            if (baseDir != null && baseDir.exists() && baseDir.isDirectory) {
                val targetSubDir = findFileCaseInsensitive(baseDir, subDirName)
                if (targetSubDir != null && targetSubDir.exists() && targetSubDir.isDirectory) {
                    val filesArray = targetSubDir.listFiles()
                    if (filesArray != null) {
                        for (docFile in filesArray) {
                            if (docFile.isFile && docFile.name != null) {
                                fileList.add(Pair(docFile.uri.toString(), docFile.name!!))
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    try {
        val baseDir = context.getExternalFilesDir(null) ?: context.filesDir
        val mainFolder = java.io.File(baseDir, "dawami_main")
        val targetSubFolder = java.io.File(mainFolder, subDirName)
        if (targetSubFolder.exists() && targetSubFolder.isDirectory) {
            targetSubFolder.listFiles()?.forEach { file ->
                if (file.isFile) {
                    if (fileList.none { it.second == file.name }) {
                        fileList.add(Pair(file.absolutePath, file.name))
                    }
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    
    return fileList
}

fun getShareableUri(context: android.content.Context, pathOrUri: String, preferredFileName: String? = null, refType: String? = null): android.net.Uri? {
    if (pathOrUri.isBlank()) return null
    val myAuthority = "${context.packageName}.fileprovider"

    try {
        val cacheDir = java.io.File(context.cacheDir, "shared_files").apply { if (!exists()) mkdirs() }
        
        var fileName = preferredFileName?.trim()?.takeIf { it.isNotBlank() } ?: ""
        
        if (fileName.isBlank() && pathOrUri.startsWith("content://")) {
            fileName = getAttachmentFileName(context, android.net.Uri.parse(pathOrUri)) ?: ""
        }
        if (fileName.isBlank()) {
            val lastSeg = java.io.File(pathOrUri).name
            if (lastSeg.isNotBlank() && !lastSeg.startsWith("content:")) {
                fileName = lastSeg
            }
        }
        if (fileName.isBlank()) {
            fileName = "shared_file_${System.currentTimeMillis()}"
        }

        // Determine extension
        var ext: String? = if (fileName.contains(".")) {
            fileName.substringAfterLast(".").lowercase()
        } else null

        if (ext.isNullOrBlank() && pathOrUri.startsWith("content://")) {
            try {
                val mime = context.contentResolver.getType(android.net.Uri.parse(pathOrUri))
                if (!mime.isNullOrBlank()) {
                    ext = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
                }
            } catch (e: Exception) { e.printStackTrace() }
        }

        if (ext.isNullOrBlank()) {
            ext = when (refType) {
                "PDF", "كتاب" -> "pdf"
                "Word" -> "docx"
                "Excel" -> "xlsx"
                "PowerPoint" -> "pptx"
                "صورة" -> "png"
                "فيديو" -> "mp4"
                else -> {
                    val fromUrl = android.webkit.MimeTypeMap.getFileExtensionFromUrl(pathOrUri).lowercase()
                    if (fromUrl.isNotBlank()) fromUrl else null
                }
            }
        }

        if (!fileName.contains(".") && !ext.isNullOrBlank()) {
            fileName = "$fileName.$ext"
        }

        val cacheFile = java.io.File(cacheDir, fileName)

        if (pathOrUri.startsWith("content://")) {
            val inputUri = android.net.Uri.parse(pathOrUri)
            context.contentResolver.openInputStream(inputUri)?.use { input ->
                cacheFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
        } else {
            val srcFile = java.io.File(pathOrUri)
            if (srcFile.exists()) {
                srcFile.inputStream().use { input ->
                    cacheFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
            }
        }

        if (cacheFile.exists() && cacheFile.length() > 0) {
            return androidx.core.content.FileProvider.getUriForFile(context, myAuthority, cacheFile)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }

    if (pathOrUri.startsWith("content://")) {
        return try { android.net.Uri.parse(pathOrUri) } catch (e: Exception) { null }
    }
    val file = java.io.File(pathOrUri)
    if (file.exists()) {
        return try {
            androidx.core.content.FileProvider.getUriForFile(context, myAuthority, file)
        } catch (e: Exception) { null }
    }

    return null
}

fun shareReference(context: android.content.Context, ref: com.example.data.entity.SubjectReference) {
    try {
        val typeEmoji = when (ref.type) {
            "كتاب" -> "📚"
            "صورة" -> "🖼️"
            "رابط" -> "🔗"
            else -> "📁"
        }
        
        val text = """
            مرجع اضافي

            اسم المادة: ${ref.subjectName}
            العنوان : ${ref.title}
            النوع : ${ref.type}${if (ref.type == "رابط" && ref.urlOrPath.isNotBlank()) "\nالرابط : ${ref.urlOrPath}" else ""}

            مع تمنياتنا لكم بالتوفيق والنجاح المستمر
        """.trimIndent()
        
        if (ref.type != "رابط" && ref.urlOrPath.isNotBlank()) {
            val uri = getShareableUri(context, ref.urlOrPath, ref.fileName, ref.type)
            if (uri != null) {
                try {
                    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                    if (clipboard != null) {
                        val clip = android.content.ClipData.newPlainText("Reference Text", text)
                        clipboard.setPrimaryClip(clip)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                val detectedMime = context.contentResolver.getType(uri)
                val targetFileName = ref.fileName.ifBlank { ref.urlOrPath }
                val extension = if (targetFileName.contains(".")) {
                    targetFileName.substringAfterLast(".").lowercase()
                } else {
                    when (ref.type) {
                        "PDF", "كتاب" -> "pdf"
                        "Word" -> "docx"
                        "Excel" -> "xlsx"
                        "PowerPoint" -> "pptx"
                        "صورة" -> "png"
                        "فيديو" -> "mp4"
                        else -> android.webkit.MimeTypeMap.getFileExtensionFromUrl(ref.urlOrPath).lowercase()
                    }
                }
                val mimeType = detectedMime ?: if (extension.isNotBlank()) {
                    android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: when (ref.type) {
                        "صورة" -> "image/*"
                        "كتاب", "PDF" -> "application/pdf"
                        "Word" -> "application/msword"
                        "Excel" -> "application/vnd.ms-excel"
                        "PowerPoint" -> "application/vnd.ms-powerpoint"
                        "فيديو" -> "video/*"
                        else -> "*/*"
                    }
                } else {
                    "*/*"
                }

                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = mimeType
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, text)
                    putExtra(Intent.EXTRA_SUBJECT, ref.title)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    clipData = android.content.ClipData.newUri(context.contentResolver, "Reference File", uri)
                }

                try {
                    val resInfoList = context.packageManager.queryIntentActivities(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                    for (resolveInfo in resInfoList) {
                        val packageName = resolveInfo.activityInfo.packageName
                        context.grantUriPermission(packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                val chooser = Intent.createChooser(intent, "مشاركة المرجع والملف عبر:").apply {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                Toast.makeText(context, "تم نسخ النص للحافظة 📋 وإرفاق الملف 📎", Toast.LENGTH_SHORT).show()
                context.startActivity(chooser)
                return
            }
        }
        
        val sendIntent = android.content.Intent().apply {
            action = android.content.Intent.ACTION_SEND
            putExtra(android.content.Intent.EXTRA_TEXT, text)
            type = "text/plain"
        }
        val shareIntent = android.content.Intent.createChooser(sendIntent, "مشاركة المرجع مع الطلاب")
        context.startActivity(shareIntent)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun buildAssignmentShareText(tmpl: com.example.data.entity.SubjectAssignmentTemplate): String {
    val builder = java.lang.StringBuilder()
    builder.append("المادة : ${tmpl.subjectName}\n")
    builder.append("نوع التكليف : ${tmpl.type}\n")
    builder.append("عنوان التكليف : ${tmpl.title}\n")
    if (tmpl.description.isNotBlank()) {
        builder.append("الوصف والتوجيهات : ${tmpl.description.trim()}\n")
    }
    builder.append("\n")
    builder.append("الرجاء من جميع الطلاب تسليم التكاليف بدقة وفي الموعد المحدد\n")
    builder.append("بالتوفيق للجميع")
    return builder.toString()
}

fun shareFileWithText(context: android.content.Context, filePath: String, text: String, fileName: String) {
    val uri = getShareableUri(context, filePath, fileName)
    if (uri == null) {
        Toast.makeText(context, "الملف غير موجود!", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        try {
            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
            if (clipboard != null) {
                val clip = android.content.ClipData.newPlainText("Assignment Text", text)
                clipboard.setPrimaryClip(clip)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val detectedMime = context.contentResolver.getType(uri)
        val targetName = fileName.ifBlank { filePath }
        val extension = if (targetName.contains(".")) {
            targetName.substringAfterLast(".").lowercase()
        } else {
            android.webkit.MimeTypeMap.getFileExtensionFromUrl(filePath).lowercase()
        }
        val mimeType = detectedMime ?: if (extension.isNotBlank()) {
            android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: "*/*"
        } else {
            "*/*"
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, text)
            putExtra(Intent.EXTRA_SUBJECT, "تنزيل مرفق التكليف")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = android.content.ClipData.newUri(context.contentResolver, "Attachment File", uri)
        }

        try {
            val resInfoList = context.packageManager.queryIntentActivities(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
            for (resolveInfo in resInfoList) {
                val packageName = resolveInfo.activityInfo.packageName
                context.grantUriPermission(packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val chooser = Intent.createChooser(intent, "مشاركة الملف والنص عبر:").apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        Toast.makeText(context, "تم نسخ النص للحافظة 📋 وإرفاق الملف 📎", Toast.LENGTH_SHORT).show()
        context.startActivity(chooser)
    } catch (e: Exception) {
        Toast.makeText(context, "فشل المشاركة: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

fun shareTextOnly(context: android.content.Context, text: String) {
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة النص عبر:"))
    } catch (e: Exception) {
        Toast.makeText(context, "فشل المشاركة: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

fun shareFileOnly(context: android.content.Context, filePath: String, fileName: String, textToCopy: String? = null) {
    val uri = getShareableUri(context, filePath, fileName)
    if (uri == null) {
        Toast.makeText(context, "الملف غير موجود!", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        if (!textToCopy.isNullOrBlank()) {
            try {
                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                if (clipboard != null) {
                    val clip = android.content.ClipData.newPlainText("Assignment Text", textToCopy)
                    clipboard.setPrimaryClip(clip)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            Toast.makeText(context, "تم نسخ الشرح للحافظة 📋 وإرفاق الملف 📎\n(يمكنك لصقه بالحافظة عند فتح الواتساب)", Toast.LENGTH_LONG).show()
        }
        val detectedMime = context.contentResolver.getType(uri)
        val targetName = fileName.ifBlank { filePath }
        val extension = if (targetName.contains(".")) {
            targetName.substringAfterLast(".").lowercase()
        } else {
            android.webkit.MimeTypeMap.getFileExtensionFromUrl(filePath).lowercase()
        }
        val mimeType = detectedMime ?: if (extension.isNotBlank()) {
            android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: "*/*"
        } else {
            "*/*"
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = android.content.ClipData.newUri(context.contentResolver, "File", uri)
        }

        try {
            val resInfoList = context.packageManager.queryIntentActivities(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
            for (resolveInfo in resInfoList) {
                val packageName = resolveInfo.activityInfo.packageName
                context.grantUriPermission(packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val chooser = Intent.createChooser(intent, "مشاركة الملف عبر:").apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(chooser)
    } catch (e: Exception) {
        Toast.makeText(context, "فشل مشاركة الملف: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

private data class FinalReportStudentInfo(
    val student: Student,
    val finalGpa: Double,
    val reason: String = "",
    val notes: List<Pair<String, String>>
)

fun generateCourseFinalReportText(
    selectedCourse: Course,
    courseDaysCount: Int,
    stats: List<CourseSubjectStat>,
    studentsInCourse: List<Student>,
    dbAllStudentAttendance: List<StudentAttendance>,
    dbAllGrades: List<StudentGrade>,
    dbGradeConfigs: List<StudentGradeConfig> = emptyList(),
    actualTrainerDaysCount: Int = 0,
    trainerNotes: String = ""
): String {
    val sortedStats = stats.sortedWith(compareBy<CourseSubjectStat> { StudentGradeConfig.getSubjectRank(it.subjectName) }.thenBy { it.subjectName })
    val completedCount = sortedStats.count { it.status == "مكتملة التدريس" || it.status == "مكتملة بالكامل" }
    val progressPct = if (sortedStats.isNotEmpty()) (completedCount * 100) / sortedStats.size else 0

    // Retrieve course grade config if available
    val exactConfig = dbGradeConfigs.find { it.courseId == selectedCourse.id }
    val dipTemplateId = if (selectedCourse.diplomaName.isNotEmpty()) StudentGradeConfig.getDiplomaTemplateId(selectedCourse.diplomaName) else null
    val dipConfig = if (dipTemplateId != null) dbGradeConfigs.find { it.courseId == dipTemplateId } else null
    val config = exactConfig ?: dipConfig
    val passingPercentage = config?.getPassingPercentage() ?: 75.0
    val subjectWeights = config?.getSubjectWeights() ?: emptyMap()
    val hasWeights = subjectWeights.isNotEmpty()

    // Course subjects
    val statSubjectNames = sortedStats.map { it.subjectName }.filter { it.isNotBlank() }.distinct()
    val allCourseSubjects = if (statSubjectNames.isNotEmpty()) {
        statSubjectNames
    } else {
        val dipSubs = config?.getDiplomaSubjects()
        if (!dipSubs.isNullOrEmpty()) dipSubs else StudentGradeConfig.DEFAULT_DIPLOMA_SUBJECTS
    }

    // Helper functions for student metrics
    fun getStudentAttendanceRate(stId: Int): Int {
        val stAtt = dbAllStudentAttendance.filter { it.studentId == stId }
        val totalSessions = stAtt.size
        val presentCount = stAtt.count { it.status == "حضور" }
        return if (totalSessions > 0) ((presentCount.toFloat() / totalSessions.toFloat()) * 100).toInt() else 100
    }

    fun isTheoryExamComplete(grade: StudentGrade?): Boolean {
        if (grade == null) return false
        if (grade.isManualFinalGrading()) return true
        if (grade.isDiploma) {
            return grade.theoreticalExamScore > 0.0 || grade.customScoresJson.contains("__theory_recorded__")
        }
        val deserialized = StudentGrade.deserializeScores(grade.customScoresJson)
        val hasTheoryKey = deserialized.any { it.key.contains("نظري") }
        return if (hasTheoryKey) {
            deserialized.any { it.key.contains("نظري") && it.value > 0.0 }
        } else {
            grade.customScoresJson.contains("__theory_recorded__") || grade.getTotalScore() > 0.0
        }
    }

    fun isPracticalExamComplete(grade: StudentGrade?): Boolean {
        if (grade == null) return false
        if (grade.isManualFinalGrading()) return true
        if (grade.isDiploma) {
            return grade.practicalExamScore > 0.0 || grade.customScoresJson.contains("__practical_recorded__")
        }
        val deserialized = StudentGrade.deserializeScores(grade.customScoresJson)
        val hasPracticalKey = deserialized.any { it.key.contains("عملي") }
        return if (hasPracticalKey) {
            deserialized.any { it.key.contains("عملي") && it.value > 0.0 }
        } else {
            grade.customScoresJson.contains("__practical_recorded__") || grade.getTotalScore() > 0.0
        }
    }

    // Classify students into 3 groups
    val group3SuspendedOrWithdrawn = mutableListOf<Student>()
    val group1PassedAndCompleted = mutableListOf<FinalReportStudentInfo>()
    val group2IncompleteOrFailed = mutableListOf<FinalReportStudentInfo>()

    for (st in studentsInCourse) {
        val isInactive = st.status == "توقيف قيد" || st.status == "موقوف" || st.status == "موقف" ||
                         st.status == "منسحب" || st.status == "منقطع" || st.status == "محذوف"
        if (isInactive) {
            group3SuspendedOrWithdrawn.add(st)
            continue
        }

        val stGrades = dbAllGrades.filter { it.studentId == st.id }

        // Compute final score across course subjects
        val scoresList = allCourseSubjects.map { subName ->
            val gr = stGrades.find { it.subjectName.trim().equals(subName.trim(), ignoreCase = true) }
            gr?.getTotalScore() ?: 0.0
        }

        val finalGpa = if (hasWeights) {
            var weightedTotal = 0.0
            var weightSum = 0.0
            allCourseSubjects.forEach { subName ->
                val w = subjectWeights[subName] ?: (100.0 / allCourseSubjects.size.coerceAtLeast(1))
                val gr = stGrades.find { it.subjectName.trim().equals(subName.trim(), ignoreCase = true) }
                val score = gr?.getTotalScore() ?: 0.0
                weightedTotal += (score / 100.0) * w
                weightSum += w
            }
            if (weightSum > 0.0) (weightedTotal / weightSum) * 100.0 else 0.0
        } else {
            if (allCourseSubjects.isNotEmpty()) scoresList.sum() / allCourseSubjects.size else 0.0
        }

        // Exam completion checks across all subjects
        val theoryComplete = allCourseSubjects.isNotEmpty() && allCourseSubjects.all { subName ->
            isTheoryExamComplete(stGrades.find { it.subjectName.trim().equals(subName.trim(), ignoreCase = true) })
        }
        val practicalComplete = allCourseSubjects.isNotEmpty() && allCourseSubjects.all { subName ->
            isPracticalExamComplete(stGrades.find { it.subjectName.trim().equals(subName.trim(), ignoreCase = true) })
        }

        // Pass check according to system rules (based on overall GPA threshold)
        val hasAnyRecordedGrades = stGrades.any { it.getTotalScore() > 0.0 }
        val isPassing = hasAnyRecordedGrades && finalGpa >= passingPercentage

        // Collect student notes per subject
        val notes = StudentGradeConfig.sortSubjectsList(allCourseSubjects).mapNotNull { subName ->
            val gr = stGrades.find { it.subjectName.trim().equals(subName.trim(), ignoreCase = true) }
            val note = gr?.getGradeNote()
            if (!note.isNullOrBlank()) subName to note else null
        }

        if (isPassing) {
            group1PassedAndCompleted.add(FinalReportStudentInfo(st, finalGpa, "", notes))
        } else {
            val reason = when {
                !theoryComplete && !practicalComplete -> "الاختبار النظري والعملي: غير مكتملين"
                !theoryComplete -> "الاختبار النظري: غير مكتمل"
                !practicalComplete -> "الاختبار العملي: غير مكتمل"
                else -> "الحالة: راسب"
            }
            group2IncompleteOrFailed.add(FinalReportStudentInfo(st, finalGpa, reason, notes))
        }
    }

    // Sort passed students descending by GPA
    group1PassedAndCompleted.sortByDescending { it.finalGpa }
    // Sort failed/incomplete students descending by GPA
    group2IncompleteOrFailed.sortByDescending { it.finalGpa }

    val daysDisplay = if (actualTrainerDaysCount > 0) actualTrainerDaysCount else courseDaysCount

    return buildString {
        append("🎓 التقرير الختامي للدورة\n")
        append("━━━━━━━━━━━━━━━━━━━━\n\n")

        append("📌 الدورة: ${selectedCourse.name}\n")
        if (selectedCourse.departmentName.isNotBlank()) {
            append("🏢 القسم: ${selectedCourse.departmentName}\n")
        }
        if (selectedCourse.diplomaName.isNotBlank()) {
            append("📜 الدبلوم: ${selectedCourse.diplomaName}\n")
        }
        if (selectedCourse.trainerName.isNotBlank()) {
            append("👨‍🏫 المدرب: ${selectedCourse.trainerName}\n")
        }
        append("📅 تاريخ البداية: ${selectedCourse.startDate.ifEmpty { "غير محدد" }}\n")
        append("🏁 تاريخ النهاية: ${selectedCourse.endDate.ifEmpty { "غير محدد" }}\n")
        append("⏳ عدد الأيام التدريبية: $daysDisplay\n")
        append("🚦 حالة الدورة: ${if (selectedCourse.isCompleted) "منتهية 🏁" else "مستمرة 🟢"}\n\n")

        append("━━━━━━━━━━━━━━━━━━━━\n")
        append("📊 ملخص الدورة\n")
        append("━━━━━━━━━━━━━━━━━━━━\n\n")

        append("• إجمالي المواد: ${sortedStats.size}\n")
        append("• المواد المكتملة: $completedCount\n")
        append("• نسبة إنجاز الخطة: $progressPct%\n")
        append("• إجمالي الطلاب: ${studentsInCourse.size}\n\n")

        append("━━━━━━━━━━━━━━━━━━━━\n")
        append("🟢 أولًا: الطلاب الناجحون والمكتملون\n")
        append("━━━━━━━━━━━━━━━━━━━━\n\n")

        if (group1PassedAndCompleted.isEmpty()) {
            append("لا يوجد طلاب ضمن هذه المجموعة.\n\n")
        } else {
            group1PassedAndCompleted.forEach { item ->
                val st = item.student
                val attRate = getStudentAttendanceRate(st.id)
                val fmtGpa = if (item.finalGpa % 1.0 == 0.0) item.finalGpa.toInt().toString() else String.format(java.util.Locale.US, "%.1f", item.finalGpa)
                append("👤 ${st.name}\n")
                append("• نسبة الالتزام: $attRate%\n")
                append("• المعدل النهائي: $fmtGpa / 100\n")
                append("• الحالة: ناجح ✅\n")
                if (item.notes.isNotEmpty()) {
                    append("\n📝 الملاحظات:\n")
                    item.notes.forEach { (subName, noteText) ->
                        append("• $subName: $noteText\n")
                    }
                }
                append("\n")
            }
        }

        append("━━━━━━━━━━━━━━━━━━━━\n")
        append("🟡 ثانيًا: الطلاب غير المكتملين أو الراسبين\n")
        append("━━━━━━━━━━━━━━━━━━━━\n\n")

        if (group2IncompleteOrFailed.isEmpty()) {
            append("لا يوجد طلاب ضمن هذه المجموعة.\n\n")
        } else {
            group2IncompleteOrFailed.forEach { item ->
                val st = item.student
                val attRate = getStudentAttendanceRate(st.id)
                val fmtGpa = if (item.finalGpa % 1.0 == 0.0) item.finalGpa.toInt().toString() else String.format(java.util.Locale.US, "%.1f", item.finalGpa)
                val statusStr = if (item.reason.contains("غير مكتمل")) "غير مكتمل ⏳" else "راسب"
                append("👤 ${st.name}\n")
                append("• نسبة الالتزام: $attRate%\n")
                append("• المعدل النهائي: $fmtGpa / 100\n")
                append("• الحالة: $statusStr\n")
                if (item.notes.isNotEmpty()) {
                    append("\n📝 الملاحظات:\n")
                    item.notes.forEach { (subName, noteText) ->
                        append("• $subName: $noteText\n")
                    }
                }
                append("\n")
            }
        }

        if (group3SuspendedOrWithdrawn.isNotEmpty()) {
            append("━━━━━━━━━━━━━━━━━━━━\n")
            append("🔴 ثالثًا: الطلاب الموقوفون أو المنسحبون\n")
            append("━━━━━━━━━━━━━━━━━━━━\n\n")

            group3SuspendedOrWithdrawn.forEach { st ->
                val attRate = getStudentAttendanceRate(st.id)
                val latestPresence = dbAllStudentAttendance.filter { it.studentId == st.id && it.status == "حضور" }.maxByOrNull { it.date }?.date
                val stopDate = if (!latestPresence.isNullOrBlank()) latestPresence
                               else if (st.statusChangeDate.isNotBlank()) st.statusChangeDate
                               else (dbAllStudentAttendance.filter { it.studentId == st.id }.maxByOrNull { it.date }?.date ?: "غير مسجل")
                append("👤 ${st.name}\n")
                append("• الحالة: ${st.status}\n")
                append("• نسبة الالتزام: $attRate%\n")
                append("• آخر حضور: $stopDate\n\n")
            }
        }

        append("━━━━━━━━━━━━━━━━━━━━\n")
        append("📊 الملخص النهائي للطلاب\n")
        append("━━━━━━━━━━━━━━━━━━━━\n\n")

        append("🟢 الناجحون والمكتملون: ${group1PassedAndCompleted.size}\n")
        append("🟡 غير المكتملين / الراسبين: ${group2IncompleteOrFailed.size}\n")
        append("🔴 الموقوفون / المنسحبون: ${group3SuspendedOrWithdrawn.size}\n")
        append("👥 إجمالي الطلاب: ${studentsInCourse.size}\n\n")

        if (trainerNotes.isNotBlank()) {
            append("━━━━━━━━━━━━━━━━━━━━\n")
            append("📝 ملاحظات وتوصيات المدرب\n")
            append("━━━━━━━━━━━━━━━━━━━━\n\n")
            append("${trainerNotes.trim()}\n\n")
        }

        append("━━━━━━━━━━━━━━━━━━━━\n")
        append("📱 تم استخراج التقرير بواسطة نظام دوامي الذكي")
    }
}

fun generateSingleSubjectReportText(
    selectedCourse: Course,
    stat: CourseSubjectStat,
    studentsInCourse: List<Student>,
    dbAllStudentAttendance: List<StudentAttendance>,
    dbAttendance: List<Attendance>,
    dbAllGrades: List<StudentGrade>,
    dbGradeConfigs: List<StudentGradeConfig> = emptyList()
): String {
    val config = dbGradeConfigs.find { it.courseId == selectedCourse.id }
    val weightsMap = config?.getSubjectWeights() ?: emptyMap()
    val subjectWeight = weightsMap[stat.subjectName]
    val hasSubjectWeight = subjectWeight != null && subjectWeight > 0.0
    val weightVal = subjectWeight ?: 0.0

    val passingPercentage = config?.getPassingPercentage() ?: 75.0

    // Dates for this subject
    val subDates = dbAttendance.filter {
        it.courseId == selectedCourse.id &&
        it.subjectName.trim().equals(stat.subjectName.trim(), ignoreCase = true)
    }.map { it.date.trim() }.filter { it.isNotBlank() }.distinct().sorted()

    fun getStudentSubAttendanceRate(studentId: Int): Int {
        if (subDates.isNotEmpty()) {
            val presentCount = dbAllStudentAttendance.count {
                it.studentId == studentId && it.date in subDates && it.status == "حضور"
            }
            return ((presentCount * 100) / subDates.size).coerceIn(0, 100)
        } else {
            val allStAtt = dbAllStudentAttendance.filter { it.studentId == studentId }
            val presentCount = allStAtt.count { it.status == "حضور" }
            return if (allStAtt.isNotEmpty()) ((presentCount * 100) / allStAtt.size).coerceIn(0, 100) else 0
        }
    }

    val activeStudents = studentsInCourse.filter { it.status != "توقيف قيد" && it.status != "منسحب" && it.status != "موقوف" }
    val suspendedStudents = studentsInCourse.filter { it.status == "توقيف قيد" || it.status == "منسحب" || it.status == "موقوف" }

    val subjectGrades = dbAllGrades.filter {
        it.courseId == selectedCourse.id &&
        it.subjectName.trim().equals(stat.subjectName.trim(), ignoreCase = true)
    }

    data class SingleSubjectStudentInfo(
        val student: Student,
        val score: Double,
        val weightedScore: Double,
        val isPassing: Boolean,
        val hasGrade: Boolean,
        val note: String,
        val attendanceRate: Int
    )

    val evaluatedActive = activeStudents.map { st ->
        val gr = subjectGrades.find { it.studentId == st.id }
        val score = gr?.getTotalScore() ?: 0.0
        val weighted = if (hasSubjectWeight) (score / 100.0) * weightVal else 0.0
        val hasGrade = gr != null && score > 0.0
        val isPassing = hasGrade && score >= passingPercentage
        val note = gr?.getGradeNote() ?: ""
        val attRate = getStudentSubAttendanceRate(st.id)

        SingleSubjectStudentInfo(
            student = st,
            score = score,
            weightedScore = weighted,
            isPassing = isPassing,
            hasGrade = hasGrade,
            note = note,
            attendanceRate = attRate
        )
    }

    val passedList = evaluatedActive.filter { it.isPassing }.sortedByDescending { it.score }
    val failedOrIncompleteList = evaluatedActive.filter { !it.isPassing }.sortedByDescending { it.score }

    val examineesCount = evaluatedActive.count { it.hasGrade }
    val passedCount = passedList.size
    val failedCount = failedOrIncompleteList.size
    val passRatePct = if (examineesCount > 0) ((passedCount * 100.0) / examineesCount) else 0.0
    val passRateFormatted = if (examineesCount == 0) "0%" else if (passRatePct % 1.0 == 0.0) "${passRatePct.toInt()}%" else String.format(java.util.Locale.US, "%.1f%%", passRatePct)

    val passEmoji = when {
        examineesCount == 0 -> "⚪"
        passRatePct >= 80.0 -> "🟢"
        passRatePct >= 65.0 -> "🟡"
        else -> "🔴"
    }

    val statusIcon = when (stat.status) {
        "مكتملة التدريس", "مكتملة بالكامل" -> "✅"
        "في انتظار الاختبار", "مؤجلة الاختبار" -> "⏳"
        else -> "📖"
    }

    val fmtWeight = if (weightVal % 1.0 == 0.0) weightVal.toInt().toString() else String.format(java.util.Locale.US, "%.1f", weightVal)

    return buildString {
        append("📘 تقرير إنجاز ونتائج المادة الدراسية\n")
        append("━━━━━━━━━━━━━━━━━━━━\n\n")

        append("📌 الدورة: ${selectedCourse.name}\n")
        if (selectedCourse.departmentName.isNotBlank()) {
            append("🏢 القسم: ${selectedCourse.departmentName}\n")
        }
        if (selectedCourse.diplomaName.isNotBlank()) {
            append("📜 الدبلوم: ${selectedCourse.diplomaName}\n")
        }
        append("📖 المادة: ${stat.subjectName}\n")
        if (hasSubjectWeight) {
            append("⚖️ وزن المادة: $fmtWeight درجة\n")
        }
        if (selectedCourse.trainerName.isNotBlank()) {
            append("👨‍🏫 المدرب: ${selectedCourse.trainerName}\n")
        }
        append("📅 بداية تدريس المادة: ${stat.firstTaughtDate.ifEmpty { "غير محدد" }}\n")
        append("🏁 نهاية تدريس المادة: ${stat.lastTaughtDate.ifEmpty { "غير محدد" }}\n")
        append("⏳ أيام تدريس المادة: ${stat.taughtDaysCount} أيام\n")
        append("🚦 حالة المادة: ${stat.status} $statusIcon\n\n")

        append("━━━━━━━━━━━━━━━━━━━━\n")
        append("📊 ملخص المادة ونسب النجاح\n")
        append("━━━━━━━━━━━━━━━━━━━━\n\n")

        append("• إجمالي الطلاب المسجلين: ${studentsInCourse.size}\n")
        append("• عدد المتقدمين للاختبار: $examineesCount\n")
        append("• عدد الناجحين: $passedCount\n")
        append("• عدد الراسبين / المعلقين: $failedCount\n")
        append("• نسبة النجاح في المادة: $passRateFormatted $passEmoji\n\n")

        append("━━━━━━━━━━━━━━━━━━━━\n")
        append("🟢 أولًا: الطلاب الناجحون في المادة\n")
        append("━━━━━━━━━━━━━━━━━━━━\n\n")

        if (passedList.isEmpty()) {
            append("لا يوجد طلاب ناجحون مرصودون حالياً.\n\n")
        } else {
            passedList.forEach { item ->
                val fmtScore = if (item.score % 1.0 == 0.0) item.score.toInt().toString() else String.format(java.util.Locale.US, "%.1f", item.score)
                append("👤 ${item.student.name}\n")
                append("• نسبة الحضور في المادة: ${item.attendanceRate}%\n")
                if (hasSubjectWeight) {
                    val fmtWScore = if (item.weightedScore % 1.0 == 0.0) item.weightedScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", item.weightedScore)
                    append("• الدرجة المعيارية: $fmtScore / 100\n")
                    append("• الدرجة الموزونة: $fmtWScore / $fmtWeight\n")
                } else {
                    append("• درجة المادة: $fmtScore / 100\n")
                }
                append("• الحالة: ناجح ✅\n")
                if (item.note.isNotBlank()) {
                    append("\n📝 الملاحظات:\n")
                    append("• ${item.note}\n")
                }
                append("\n")
            }
        }

        append("━━━━━━━━━━━━━━━━━━━━\n")
        append("🟡 ثانيًا: الطلاب غير المكتملين أو الراسبين\n")
        append("━━━━━━━━━━━━━━━━━━━━\n\n")

        if (failedOrIncompleteList.isEmpty()) {
            append("لا يوجد طلاب راسبون أو غير مكتملين.\n\n")
        } else {
            failedOrIncompleteList.forEach { item ->
                val fmtScore = if (item.score % 1.0 == 0.0) item.score.toInt().toString() else String.format(java.util.Locale.US, "%.1f", item.score)
                append("👤 ${item.student.name}\n")
                append("• نسبة الحضور في المادة: ${item.attendanceRate}%\n")
                if (item.hasGrade) {
                    if (hasSubjectWeight) {
                        val fmtWScore = if (item.weightedScore % 1.0 == 0.0) item.weightedScore.toInt().toString() else String.format(java.util.Locale.US, "%.1f", item.weightedScore)
                        append("• الدرجة المعيارية: $fmtScore / 100\n")
                        append("• الدرجة الموزونة: $fmtWScore / $fmtWeight\n")
                    } else {
                        append("• درجة المادة: $fmtScore / 100\n")
                    }
                    append("• الحالة: راسب ⚠️\n")
                } else {
                    append("• درجة المادة: لم تُرصد بعد\n")
                    append("• الحالة: غير مكتمل ⏳\n")
                }
                if (item.note.isNotBlank()) {
                    append("\n📝 الملاحظات:\n")
                    append("• ${item.note}\n")
                }
                append("\n")
            }
        }

        if (suspendedStudents.isNotEmpty()) {
            append("━━━━━━━━━━━━━━━━━━━━\n")
            append("🔴 ثالثًا: الطلاب الموقوفون / غير المختبرين\n")
            append("━━━━━━━━━━━━━━━━━━━━\n\n")

            suspendedStudents.forEach { st ->
                val attRate = getStudentSubAttendanceRate(st.id)
                val latestSubPres = dbAllStudentAttendance.filter {
                    it.studentId == st.id && (if (subDates.isNotEmpty()) it.date in subDates else true) && it.status == "حضور"
                }.maxByOrNull { it.date }?.date
                val stopDate = if (!latestSubPres.isNullOrBlank()) latestSubPres
                               else if (st.statusChangeDate.isNotBlank()) st.statusChangeDate
                               else (dbAllStudentAttendance.filter { it.studentId == st.id }.maxByOrNull { it.date }?.date ?: "غير مسجل")

                append("👤 ${st.name}\n")
                append("• الحالة: ${st.status}\n")
                append("• نسبة الحضور في المادة: $attRate%\n")
                append("• آخر حضور في المادة: $stopDate\n\n")
            }
        }

        append("━━━━━━━━━━━━━━━━━━━━\n")
        append("📊 إحصائية المادة الختامية\n")
        append("━━━━━━━━━━━━━━━━━━━━\n\n")

        append("🟢 الناجحون: $passedCount\n")
        append("🟡 الراسبون / الدور الثاني: $failedCount\n")
        append("🔴 الموقوفون / المنسحبون: ${suspendedStudents.size}\n")
        append("👥 إجمالي طلاب الدورة: ${studentsInCourse.size}\n\n")

        append("━━━━━━━━━━━━━━━━━━━━\n")
        append("📱 تم استخراج التقرير بواسطة نظام دوامي الذكي")
    }
}

fun sendTextViaWhatsApp(context: android.content.Context, phoneNumber: String, text: String) {
    try {
        var cleanNumber = phoneNumber.replace("+", "").replace(" ", "").trim()
        if (!cleanNumber.startsWith("967") && cleanNumber.startsWith("7")) {
            cleanNumber = "967$cleanNumber" // default to Yemen code if starting with 7
        }
        val url = "https://api.whatsapp.com/send?phone=$cleanNumber&text=${java.net.URLEncoder.encode(text, "UTF-8")}"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = android.net.Uri.parse(url)
        }
        context.startActivity(intent)
    } catch (e: java.lang.Exception) {
        Toast.makeText(context, "فشل فتح الواتساب: يرجى التحقق من تثبيت التطبيق.", Toast.LENGTH_LONG).show()
    }
}

fun sendAssignmentToStudentWhatsApp(
    context: android.content.Context,
    phoneNumber: String,
    text: String,
    attachmentPath: String,
    attachmentName: String,
    isBusiness: Boolean
) {
    try {
        var cleanNumber = phoneNumber.replace("+", "").replace("-", "").replace(" ", "").trim()
        if (cleanNumber.startsWith("00")) {
            cleanNumber = cleanNumber.substring(2)
        }
        if (!cleanNumber.startsWith("967") && cleanNumber.startsWith("7") && cleanNumber.length == 9) {
            cleanNumber = "967$cleanNumber"
        }
        val targetPackage = if (isBusiness) "com.whatsapp.w4b" else "com.whatsapp"
        val appName = if (isBusiness) "واتساب الأعمال" else "واتساب العادي"

        // Always copy text to clipboard for user convenience
        try {
            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
            if (clipboard != null) {
                val clip = android.content.ClipData.newPlainText("Assignment Text", text)
                clipboard.setPrimaryClip(clip)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (attachmentPath.isNotBlank()) {
            val uri = getShareableUri(context, attachmentPath)
            if (uri != null) {
                val extension = android.webkit.MimeTypeMap.getFileExtensionFromUrl(attachmentPath)
                val mimeType = if (!extension.isNullOrEmpty()) {
                    android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.lowercase()) ?: "*/*"
                } else {
                    "*/*"
                }

                try {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = mimeType
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_TEXT, text)
                        putExtra("jid", "$cleanNumber@s.whatsapp.net")
                        setPackage(targetPackage)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    Toast.makeText(context, "تم نسخ الشرح للحافظة 📋 وتوجيه المرفق لمحادثة الطالب عبر $appName 💬", Toast.LENGTH_SHORT).show()
                    context.startActivity(intent)
                } catch (e: Exception) {
                    try {
                        val encodedText = java.net.URLEncoder.encode(text, "UTF-8")
                        val url = "https://api.whatsapp.com/send?phone=$cleanNumber&text=$encodedText"
                        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                            setPackage(targetPackage)
                        }
                        Toast.makeText(context, "تم نسخ الشرح للحافظة 📋 وفتح محادثة الطالب عبر $appName 💬", Toast.LENGTH_SHORT).show()
                        context.startActivity(intent)
                    } catch (ex: Exception) {
                        Toast.makeText(context, "تطبيق $appName غير مثبت على جهازك", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(context, "ملف المرفق غير موجود!", Toast.LENGTH_SHORT).show()
            }
        } else {
            try {
                // Copy text to clipboard as backup
                try {
                    val clip = android.content.ClipData.newPlainText("Report Text", text)
                    (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager)?.setPrimaryClip(clip)
                } catch (e: Exception) { e.printStackTrace() }

                if (cleanNumber.isNotBlank()) {
                    try {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                            putExtra("jid", "$cleanNumber@s.whatsapp.net")
                            setPackage(targetPackage)
                        }
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        val encodedText = java.net.URLEncoder.encode(text, "UTF-8")
                        val url = "https://api.whatsapp.com/send?phone=$cleanNumber&text=$encodedText"
                        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                            setPackage(targetPackage)
                        }
                        context.startActivity(intent)
                    }
                } else {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, text)
                        setPackage(targetPackage)
                    }
                    context.startActivity(intent)
                }
            } catch (e: Exception) {
                Toast.makeText(context, "تطبيق $appName غير مثبت على جهازك", Toast.LENGTH_SHORT).show()
            }
        }
    } catch (e: Exception) {
        Toast.makeText(context, "فشل الإرسال: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

fun openAttachmentFile(context: android.content.Context, pathOrUri: String, fileName: String) {
    try {
        val uri = getShareableUri(context, pathOrUri, fileName)
        if (uri != null) {
            val extension = fileName.substringAfterLast('.', "").lowercase()
            val mimeType = when (extension) {
                "png", "jpg", "jpeg", "webp", "gif", "bmp" -> "image/*"
                "pdf" -> "application/pdf"
                "doc" -> "application/msword"
                "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                "xls" -> "application/vnd.ms-excel"
                "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                "ppt" -> "application/vnd.ms-powerpoint"
                "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                "txt" -> "text/plain"
                else -> "*/*"
            }
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "فتح المرفق بواسطة:"))
        } else if (pathOrUri.startsWith("content://")) {
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(pathOrUri)).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "فتح المرفق بواسطة:"))
        } else {
            val file = java.io.File(pathOrUri)
            if (file.exists()) {
                val myAuthority = "${context.packageName}.fileprovider"
                val fileUri = androidx.core.content.FileProvider.getUriForFile(context, myAuthority, file)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(fileUri, "*/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(intent, "فتح المرفق بواسطة:"))
            } else {
                Toast.makeText(context, "الملف غير موجود في المسار المحدد: $fileName", Toast.LENGTH_SHORT).show()
            }
        }
    } catch (e: Exception) {
        Toast.makeText(context, "لا يوجد تطبيق مناسب على جهازك لفتح هذا الملف ($fileName)", Toast.LENGTH_LONG).show()
    }
}



