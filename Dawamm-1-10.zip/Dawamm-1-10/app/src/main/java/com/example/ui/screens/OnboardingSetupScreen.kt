package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.TextStyle
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.GradingViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.ui.viewmodel.Screen

data class DepartmentItem(
    var name: String,
    val diplomas: MutableList<DiplomaItem> = mutableListOf(),
    val customFields: MutableList<Pair<String, Int>> = mutableListOf()
)

data class DiplomaItem(
    var name: String,
    val subjects: MutableList<String> = mutableListOf(),
    val customFields: MutableList<Pair<String, Int>> = mutableListOf(),
    var diplomaTotal: Double = 100.0,
    var passingPercentage: Double = 75.0,
    val subjectWeights: MutableMap<String, Double> = mutableMapOf(),
    val subjectCustomFields: MutableMap<String, List<Pair<String, Int>>> = mutableMapOf()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingSetupScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    gradingViewModel: GradingViewModel? = null
) {
    val context = LocalContext.current
    val hasCompletedOnboarding by viewModel.hasCompletedOnboarding.collectAsState()

    val isActivated by viewModel.isActivatedState.collectAsState()
    val courses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val students by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val coachAttendance by (attendanceViewModel?.allAttendance ?: viewModel.dbAttendance).collectAsState()
    val studentAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()
    val grades by (gradingViewModel?.allGrades ?: viewModel.dbAllGrades).collectAsState()

    // Current stored settings
    val currentInstName by viewModel.instituteName.collectAsState()
    val currentDirector by viewModel.directorName.collectAsState()
    val currentLogoUri by viewModel.instituteLogoUri.collectAsState()
    val currentOrgType by viewModel.orgType.collectAsState()

    var orgTypeState by remember { mutableStateOf(if (currentOrgType.isEmpty()) "معهد" else currentOrgType) }
    var instNameState by remember { mutableStateOf(if (currentInstName.isEmpty() || currentInstName == "معهد دوامي للتدريب") "معهد دوامي العالي للتدريب" else currentInstName) }
    var directorState by remember { mutableStateOf(if (currentDirector.isEmpty() || currentDirector == "مدير الهيئة / المؤسسة التدريبية") "د. محمد علي العفيف" else currentDirector) }
    var logoUriState by remember { mutableStateOf(currentLogoUri) }

    // Sync state if they load after database is populated
    LaunchedEffect(currentOrgType, currentInstName, currentDirector, currentLogoUri) {
        if (currentOrgType.isNotEmpty()) orgTypeState = currentOrgType
        if (currentInstName.isNotEmpty() && currentInstName != "معهد دوامي للتدريب") instNameState = currentInstName
        if (currentDirector.isNotEmpty() && currentDirector != "مدير الهيئة / المؤسسة التدريبية") directorState = currentDirector
        if (currentLogoUri.isNotEmpty()) logoUriState = currentLogoUri
    }

    var currentStep by remember { mutableIntStateOf(if (hasCompletedOnboarding) 2 else 1) }

    val dbSubjectsState by viewModel.dbSubjects.collectAsState()
    val dbAllGradeConfigs by viewModel.dbAllGradeConfigs.collectAsState()

    // Structure State
    val departmentsList = remember {
        mutableStateListOf<DepartmentItem>()
    }

    LaunchedEffect(dbSubjectsState, dbAllGradeConfigs) {
        if (dbSubjectsState.isNotEmpty()) {
            departmentsList.clear()
            val mapped = dbSubjectsState.groupBy { it.departmentName }.map { (deptName, deptSubjects) ->
                DepartmentItem(
                    name = deptName,
                    diplomas = deptSubjects.groupBy { it.diplomaName }.map { (diplomaName, diplomaSubjects) ->
                        val cleanDipName = diplomaName.trim()
                        val cleanDeptName = deptName.trim()
                        val dipTemplateId = com.example.data.entity.StudentGradeConfig.getDiplomaTemplateId(cleanDipName)
                        val deptTemplateId = com.example.data.entity.StudentGradeConfig.getDepartmentTemplateId(cleanDeptName)
                        
                        val savedConfig = dbAllGradeConfigs.find { it.courseId == dipTemplateId }
                            ?: dbAllGradeConfigs.find { 
                                val cName = it.courseName.trim()
                                cName == "قالب دبلوم: $cleanDipName" || cName == cleanDipName || cName.endsWith(cleanDipName)
                            }
                            ?: dbAllGradeConfigs.find { it.courseId == deptTemplateId }
                            ?: dbAllGradeConfigs.find { 
                                val cName = it.courseName.trim()
                                cName == "قالب قسم: $cleanDeptName" || cName == cleanDeptName || cName.endsWith(cleanDeptName)
                            }
                        
                        val allConfigFields = if (savedConfig != null && savedConfig.customFieldsJson.isNotBlank()) {
                            com.example.data.entity.StudentGradeConfig.deserializeFields(savedConfig.customFieldsJson)
                        } else {
                            emptyList()
                        }
                        
                        val customFields = allConfigFields.filter { !it.first.contains("_") }.toMutableList()
                        
                        val subjectCustomFields = mutableMapOf<String, List<Pair<String, Int>>>()
                        val subjectsList = diplomaSubjects.map { it.name }
                        subjectsList.forEach { sub ->
                            val cleanSub = sub.trim()
                            val specific = allConfigFields.filter { it.first.startsWith("${sub}_") || it.first.startsWith("${cleanSub}_") }
                                .map { Pair(it.first.substringAfter("_"), it.second) }
                            if (specific.isNotEmpty() && specific != customFields) {
                                subjectCustomFields[sub] = specific
                            }
                        }
                        
                        val subjectWeights = mutableMapOf<String, Double>()
                        if (savedConfig != null) {
                            val rawWeights = savedConfig.getSubjectWeights()
                            subjectsList.forEach { sub ->
                                val cleanSub = sub.trim()
                                val foundWeight = rawWeights[cleanSub]
                                    ?: rawWeights[sub]
                                    ?: rawWeights.entries.find { it.key.trim().equals(cleanSub, ignoreCase = true) }?.value
                                if (foundWeight != null && foundWeight > 0.0) {
                                    subjectWeights[sub] = foundWeight
                                }
                            }
                            // Retain any direct mappings if subjects match
                            rawWeights.forEach { (k, v) ->
                                if (!subjectWeights.containsKey(k) && v > 0.0) {
                                    subjectWeights[k] = v
                                }
                            }
                        }

                        // Ensure all subjects have a default weight of 100.0 if not already specified
                        if (subjectsList.isNotEmpty()) {
                            subjectsList.forEach { sub ->
                                if (!subjectWeights.containsKey(sub) || (subjectWeights[sub] ?: 0.0) <= 0.0) {
                                    subjectWeights[sub] = 100.0
                                }
                            }
                        }
                        
                        val diplomaTotal = if (subjectWeights.isNotEmpty()) {
                            val sum = subjectWeights.values.sum()
                            if (sum > 0.0) sum else (subjectsList.size * 100.0)
                        } else {
                            if (subjectsList.size > 1) (subjectsList.size * 100.0) else 100.0
                        }

                        val savedPassingPercentage = savedConfig?.getPassingPercentage() ?: 75.0
                        
                        DiplomaItem(
                            name = diplomaName,
                            subjects = subjectsList.toMutableList(),
                            customFields = customFields,
                            diplomaTotal = diplomaTotal,
                            passingPercentage = savedPassingPercentage,
                            subjectWeights = subjectWeights,
                            subjectCustomFields = subjectCustomFields
                        )
                    }.toMutableList()
                )
            }
            departmentsList.addAll(mapped)
        } else if (departmentsList.isEmpty()) {
            departmentsList.addAll(listOf(
                DepartmentItem(
                    name = "قسم الحاسوب وتقنية المعلومات",
                    diplomas = mutableListOf(
                        DiplomaItem(
                            name = "دبلوم قيادة الحاسوب (ICDL)",
                            subjects = mutableListOf(
                                "مقدمة في الحاسوب",
                                "معالج النصوص (وورد)",
                                "الجداول الإلكترونية (إكسل)",
                                "قواعد البيانات (أكسس)",
                                "العروض التقديمية (بوربوينت)",
                                "التعاون",
                                "أساسيات الإنترنت والشبكات"
                            ),
                            diplomaTotal = 700.0,
                            subjectWeights = mutableMapOf(
                                "مقدمة في الحاسوب" to 100.0,
                                "معالج النصوص (وورد)" to 100.0,
                                "الجداول الإلكترونية (إكسل)" to 100.0,
                                "قواعد البيانات (أكسس)" to 100.0,
                                "العروض التقديمية (بوربوينت)" to 100.0,
                                "التعاون" to 100.0,
                                "أساسيات الإنترنت والشبكات" to 100.0
                            )
                        ),
                        DiplomaItem(
                            name = "دبلوم البرمجة وتطوير البرمجيات",
                            subjects = mutableListOf(
                                "أساسيات البرمجة والتفكير المنطقي",
                                "البرمجة كائنية التوجه (OOP)",
                                "تصميم وقواعد البيانات SQL",
                                "تطوير تطبيقات الهواتف الذكية"
                            ),
                            diplomaTotal = 400.0,
                            subjectWeights = mutableMapOf(
                                "أساسيات البرمجة والتفكير المنطقي" to 100.0,
                                "البرمجة كائنية التوجه (OOP)" to 100.0,
                                "تصميم وقواعد البيانات SQL" to 100.0,
                                "تطوير تطبيقات الهواتف الذكية" to 100.0
                            )
                        )
                    )
                ),
                DepartmentItem(
                    name = "قسم اللغات والترجمة",
                    diplomas = mutableListOf(
                        DiplomaItem(
                            name = "دبلوم اللغة الإنجليزية المتقدم",
                            subjects = mutableListOf(
                                "القواعد والتراكيب اللغوية",
                                "الاستماع والمحادثة التفاعلية",
                                "الكتابة والمراسلات الإدارية"
                            ),
                            diplomaTotal = 300.0,
                            subjectWeights = mutableMapOf(
                                "القواعد والتراكيب اللغوية" to 100.0,
                                "الاستماع والمحادثة التفاعلية" to 100.0,
                                "الكتابة والمراسلات الإدارية" to 100.0
                            )
                        )
                    )
                ),
                DepartmentItem(
                    name = "قسم العلوم الإدارية والمالية",
                    diplomas = mutableListOf(
                        DiplomaItem(
                            name = "دبلوم المحاسبة الشاملة",
                            subjects = mutableListOf(
                                "مبادئ المحاسبة المالية",
                                "المحاسبة الإلكترونية والأنظمة",
                                "التحليل المالي والميزانيات"
                            ),
                            diplomaTotal = 300.0,
                            subjectWeights = mutableMapOf(
                                "مبادئ المحاسبة المالية" to 100.0,
                                "المحاسبة الإلكترونية والأنظمة" to 100.0,
                                "التحليل المالي والميزانيات" to 100.0
                            )
                        )
                    )
                )
            ))
        }
    }

    var expandedDeptNames by remember { mutableStateOf(setOf<String>()) }
    var expandedDiplomaNames by remember { mutableStateOf(setOf<String>()) }

    LaunchedEffect(departmentsList.size) {
        if (departmentsList.isNotEmpty() && expandedDeptNames.isEmpty()) {
            departmentsList.firstOrNull()?.let {
                expandedDeptNames = setOf(it.name)
            }
        }
    }

    var newDeptName by remember { mutableStateOf("") }
    var selectedDeptIndexForDiploma by remember { mutableIntStateOf(0) }
    var newDiplomaName by remember { mutableStateOf("") }

    var selectedDiplomaForSubject by remember { mutableStateOf<DiplomaItem?>(null) }
    var newSubjectName by remember { mutableStateOf("") }

    var configuringDiplomaForGrades by remember { mutableStateOf<DiplomaItem?>(null) }
    var configuringDiplomaDeptName by remember { mutableStateOf("") }
    var configuringSubjectForGrades by remember { mutableStateOf<Pair<DiplomaItem, String>?>(null) }

    // Dialog state for Edit and Delete
    var editingDept by remember { mutableStateOf<DepartmentItem?>(null) }
    var deletingDept by remember { mutableStateOf<DepartmentItem?>(null) }

    var editingDiploma by remember { mutableStateOf<Pair<DepartmentItem, DiplomaItem>?>(null) }
    var deletingDiploma by remember { mutableStateOf<Pair<DepartmentItem, DiplomaItem>?>(null) }

    var editingSubjectTarget by remember { mutableStateOf<Triple<DiplomaItem, Int, String>?>(null) }
    var deletingSubjectTarget by remember { mutableStateOf<Triple<DiplomaItem, Int, String>?>(null) }

    fun getDiplomaDefaultFields(deptName: String, diploma: DiplomaItem): List<Pair<String, Int>> {
        if (diploma.customFields.isNotEmpty()) return diploma.customFields
        val dipTemplateId = com.example.data.entity.StudentGradeConfig.getDiplomaTemplateId(diploma.name)
        val dipConfig = dbAllGradeConfigs.find { it.courseId == dipTemplateId }
        if (dipConfig != null && dipConfig.customFieldsJson.isNotBlank()) {
            val deserialized = com.example.data.entity.StudentGradeConfig.deserializeFields(dipConfig.customFieldsJson)
            if (deserialized.isNotEmpty()) return deserialized
        }
        val deptTemplateId = com.example.data.entity.StudentGradeConfig.getDepartmentTemplateId(deptName)
        val deptConfig = dbAllGradeConfigs.find { it.courseId == deptTemplateId }
        if (deptConfig != null && deptConfig.customFieldsJson.isNotBlank()) {
            val deserialized = com.example.data.entity.StudentGradeConfig.deserializeFields(deptConfig.customFieldsJson)
            if (deserialized.isNotEmpty()) return deserialized
        }
        return if (deptName.contains("حاسب") || deptName.contains("حاسوب")) {
            listOf(
                Pair("حضور", 5),
                Pair("مشاركة", 5),
                Pair("تكاليف", 10),
                Pair("مشاريع", 20),
                Pair("اختبار نظري", 20),
                Pair("اختبار عملي", 40)
            )
        } else {
            listOf(
                Pair("حضور", 10),
                Pair("مشاركة", 10),
                Pair("تكاليف", 20),
                Pair("اختبار نظري", 30),
                Pair("اختبار عملي", 30)
            )
        }
    }

    val logoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val path = viewModel.copyUriToInternalStorage(context, uri)
            if (path.isNotEmpty()) {
                logoUriState = path
                Toast.makeText(context, "تم رفع شعار المؤسسة بنجاح! 🖼️", Toast.LENGTH_SHORT).show()
            }
        }
    }

    BackHandler {
        if (currentStep == 2 && !hasCompletedOnboarding) {
            currentStep = 1
        } else {
            viewModel.navigateBack()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "تهيئة الهيكل الأكاديمي والهوية 🎓",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "خطوة $currentStep من 2 - ${if (currentStep == 1) "إعداد الهوية والتوقيعات" else "إدارة الأقسام والدبلومات والمواد"}",
                                fontSize = 11.sp,
                                color = DawamiGold
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            if (currentStep == 2 && !hasCompletedOnboarding) {
                                currentStep = 1
                            } else {
                                viewModel.navigateBack()
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "رجوع",
                                tint = Color.White
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = DawamiNavy)
                )
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Step Indicator Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = DawamiNavy.copy(alpha = 0.05f)),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier
                                    .clickable { currentStep = 1 }
                                    .padding(4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    color = if (currentStep == 1) DawamiNavy else Color.LightGray,
                                    shape = CircleShape,
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("1", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }
                                Text(
                                    text = "الهوية الرسمية",
                                    fontWeight = if (currentStep == 1) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.5.sp,
                                    color = if (currentStep == 1) DawamiNavy else Color.Gray
                                )
                            }

                            Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = Color.Gray)

                            Row(
                                modifier = Modifier
                                    .clickable { currentStep = 2 }
                                    .padding(4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    color = if (currentStep == 2) DawamiNavy else Color.LightGray,
                                    shape = CircleShape,
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("2", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }
                                Text(
                                    text = "الأقسام والمواد",
                                    fontWeight = if (currentStep == 2) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.5.sp,
                                    color = if (currentStep == 2) DawamiNavy else Color.Gray
                                )
                            }
                        }
                    }
                }

                if (currentStep == 1) {
                    // STEP 1: INSTITUTE IDENTITY
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "بيانات المنشأة والهيئة التعليمية 🏫",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = DawamiNavy
                                )

                                OutlinedTextField(
                                    value = instNameState,
                                    onValueChange = { instNameState = it },
                                    label = { Text("اسم المعهد / الكلية / المركز") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                OutlinedTextField(
                                    value = directorState,
                                    onValueChange = { directorState = it },
                                    label = { Text("اسم عميد / مدير المعهد") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("نوع المنشأة التدريبية:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        FilterChip(
                                            selected = orgTypeState == "معهد",
                                            onClick = { orgTypeState = "معهد" },
                                            label = { Text("معهد / مركز") }
                                        )
                                        FilterChip(
                                            selected = orgTypeState == "كلية",
                                            onClick = { orgTypeState = "كلية" },
                                            label = { Text("كلية / جامعة") }
                                        )
                                    }
                                }

                                Divider(color = Color(0xFFF1F5F9))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("شعار المنشأة الرسمي 🖼️", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DawamiNavy)
                                        Text("يظهر الترويسة في جميع تقارير الحضور والشهادات", fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Button(
                                        onClick = { logoPickerLauncher.launch(arrayOf("image/*")) },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                                    ) {
                                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("رفع الشعار", fontSize = 11.sp)
                                    }
                                }

                                Button(
                                    onClick = {
                                        if (instNameState.isNotBlank()) {
                                            currentStep = 2
                                        } else {
                                            Toast.makeText(context, "يرجى كتابة اسم المنشأة", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                                ) {
                                    Text("الانتقال لتهيئات الأقسام والدبلومات والمواد ➡️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    // STEP 2: DEPARTMENTS, DIPLOMAS & SUBJECTS STRUCTURE
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        color = DawamiNavy,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Category, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                        }
                                    }
                                    Column {
                                        Text(
                                            text = "إدارة الأقسام والدبلومات والمواد 📚",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = DawamiNavy
                                        )
                                        Text(
                                            text = "اضغط على أي قسم أو دبلوم لتوسيعه، تعديل بياناته، أو إضافة عناصر تابعة له",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                // Stats row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val totalDepts = departmentsList.size
                                    val totalDips = departmentsList.sumOf { it.diplomas.size }
                                    val totalSubs = departmentsList.sumOf { d -> d.diplomas.sumOf { it.subjects.size } }

                                    Surface(
                                        modifier = Modifier.weight(1f),
                                        color = DawamiNavy.copy(alpha = 0.08f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(8.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text("$totalDepts", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DawamiNavy)
                                            Text("أقسام أكاديمية", fontSize = 10.5.sp, color = DawamiNavy)
                                        }
                                    }

                                    Surface(
                                        modifier = Modifier.weight(1f),
                                        color = DawamiGold.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(8.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text("$totalDips", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFFB45309))
                                            Text("دبلومات وبرامج", fontSize = 10.5.sp, color = Color(0xFFB45309))
                                        }
                                    }

                                    Surface(
                                        modifier = Modifier.weight(1f),
                                        color = DawamiTeal.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(8.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text("$totalSubs", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DawamiTeal)
                                            Text("مواد مقررة", fontSize = 10.5.sp, color = DawamiTeal)
                                        }
                                    }
                                }

                                // Expand All / Collapse All controls
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            expandedDeptNames = departmentsList.map { it.name }.toSet()
                                            expandedDiplomaNames = departmentsList.flatMap { dept ->
                                                dept.diplomas.map { dip -> "${dept.name}_${dip.name}" }
                                            }.toSet()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp)
                                    ) {
                                        Icon(Icons.Default.UnfoldMore, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("توسيع الكل 📂", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            expandedDeptNames = emptySet()
                                            expandedDiplomaNames = emptySet()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp)
                                    ) {
                                        Icon(Icons.Default.UnfoldLess, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("طي الكل 📁", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Add Department Input Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "إضافة قسم أكاديمي جديد ➕",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    color = DawamiNavy
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = newDeptName,
                                        onValueChange = { newDeptName = it },
                                        placeholder = { Text("مثال: قسم علوم الحاسوب والذكاء الاصطناعي") },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp),
                                        singleLine = true
                                    )
                                    Button(
                                        onClick = {
                                            if (newDeptName.isNotBlank()) {
                                                val trimmed = newDeptName.trim()
                                                val newDept = DepartmentItem(name = trimmed)
                                                departmentsList.add(newDept)
                                                expandedDeptNames = expandedDeptNames + trimmed
                                                newDeptName = ""
                                                Toast.makeText(context, "تمت إضافة القسم بنجاح! 📂", Toast.LENGTH_SHORT).show()
                                            } else {
                                                Toast.makeText(context, "يرجى كتابة اسم القسم", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("إضافة", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Display Expandable Departments
                    itemsIndexed(departmentsList) { deptIdx, dept ->
                        val isDeptExpanded = expandedDeptNames.contains(dept.name)

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDeptExpanded) Color(0xFFF8FAFC) else MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isDeptExpanded) DawamiNavy.copy(alpha = 0.4f) else Color(0xFFCBD5E1)
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = if (isDeptExpanded) 3.dp else 1.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Department Header Row (Clickable to Expand/Collapse)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            expandedDeptNames = if (isDeptExpanded) {
                                                expandedDeptNames - dept.name
                                            } else {
                                                expandedDeptNames + dept.name
                                            }
                                        }
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Surface(
                                            color = DawamiNavy,
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text("${deptIdx + 1}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            }
                                        }

                                        Column {
                                            Text(dept.name, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DawamiNavy)
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text("${dept.diplomas.size} دبلومات", fontSize = 10.5.sp, color = Color.Gray)
                                                Text("•", fontSize = 10.5.sp, color = Color.Gray)
                                                Text("${dept.diplomas.sumOf { it.subjects.size }} مواد", fontSize = 10.5.sp, color = Color.Gray)
                                            }
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        // Edit Department
                                        IconButton(
                                            onClick = { editingDept = dept },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "تعديل القسم", tint = Color(0xFF2563EB), modifier = Modifier.size(18.dp))
                                        }

                                        // Delete Department
                                        IconButton(
                                            onClick = { deletingDept = dept },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف القسم", tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
                                        }

                                        // Expand / Collapse Chevron
                                        IconButton(
                                            onClick = {
                                                expandedDeptNames = if (isDeptExpanded) {
                                                    expandedDeptNames - dept.name
                                                } else {
                                                    expandedDeptNames + dept.name
                                                }
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (isDeptExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                contentDescription = if (isDeptExpanded) "طي" else "توسيع",
                                                tint = DawamiNavy
                                            )
                                        }
                                    }
                                }

                                // Department Expanded Content
                                AnimatedVisibility(
                                    visible = isDeptExpanded,
                                    enter = expandVertically() + fadeIn(),
                                    exit = shrinkVertically() + fadeOut()
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        HorizontalDivider(color = Color(0xFFE2E8F0))

                                        Text(
                                            text = "🎓 الدبلومات والبرامج الأكاديمية التابعة للقسم:",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy
                                        )

                                        if (dept.diplomas.isEmpty()) {
                                            Surface(
                                                modifier = Modifier.fillMaxWidth(),
                                                color = Color(0xFFFFFBEB),
                                                shape = RoundedCornerShape(8.dp),
                                                border = BorderStroke(1.dp, Color(0xFFFDE68A))
                                            ) {
                                                Text(
                                                    text = "لا توجد دبلومات مضافة لهذا القسم بعد. أضف أول دبلوم أدناه.",
                                                    fontSize = 11.5.sp,
                                                    color = Color(0xFF92400E),
                                                    modifier = Modifier.padding(10.dp),
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }

                                        // Diplomas List inside Department
                                        dept.diplomas.forEachIndexed { dipIdx, diploma ->
                                            val dipKey = "${dept.name}_${diploma.name}"
                                            val isDipExpanded = expandedDiplomaNames.contains(dipKey)

                                            Card(
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(12.dp),
                                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                                border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(10.dp),
                                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    // Diploma Header Row (Clickable)
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clickable {
                                                                expandedDiplomaNames = if (isDipExpanded) {
                                                                    expandedDiplomaNames - dipKey
                                                                } else {
                                                                    expandedDiplomaNames + dipKey
                                                                }
                                                            },
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.weight(1f),
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                        ) {
                                                            Icon(Icons.Default.School, contentDescription = null, tint = DawamiGold, modifier = Modifier.size(20.dp))
                                                            Column {
                                                                Text(diploma.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DawamiNavy)
                                                                Text("${diploma.subjects.size} مواد مقررة", fontSize = 10.5.sp, color = Color.Gray)
                                                            }
                                                        }

                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            // Edit Diploma
                                                            IconButton(
                                                                onClick = { editingDiploma = Pair(dept, diploma) },
                                                                modifier = Modifier.size(28.dp)
                                                            ) {
                                                                Icon(Icons.Default.Edit, contentDescription = "تعديل الدبلوم", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                                                            }

                                                            // Delete Diploma
                                                            IconButton(
                                                                onClick = { deletingDiploma = Pair(dept, diploma) },
                                                                modifier = Modifier.size(28.dp)
                                                            ) {
                                                                Icon(Icons.Default.Close, contentDescription = "حذف الدبلوم", tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                                            }

                                                            // Chevron
                                                            IconButton(
                                                                onClick = {
                                                                    expandedDiplomaNames = if (isDipExpanded) {
                                                                        expandedDiplomaNames - dipKey
                                                                    } else {
                                                                        expandedDiplomaNames + dipKey
                                                                    }
                                                                },
                                                                modifier = Modifier.size(28.dp)
                                                            ) {
                                                                Icon(
                                                                    imageVector = if (isDipExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                                    contentDescription = null,
                                                                    tint = DawamiNavy,
                                                                    modifier = Modifier.size(18.dp)
                                                                )
                                                            }
                                                        }
                                                    }

                                                    // Diploma Subjects Expanded Section
                                                    AnimatedVisibility(
                                                        visible = isDipExpanded,
                                                        enter = expandVertically() + fadeIn(),
                                                        exit = shrinkVertically() + fadeOut()
                                                    ) {
                                                        Column(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                                        ) {
                                                            HorizontalDivider(color = Color(0xFFF1F5F9))

                                                            // Diploma Final Grade Selection
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                            ) {
                                                                Text(
                                                                    text = "🎯 الدرجة النهائية للدبلوم:",
                                                                    fontSize = 11.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = DawamiNavy,
                                                                    modifier = Modifier.weight(1.2f)
                                                                )
                                                                Row(
                                                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                    modifier = Modifier.weight(1.8f)
                                                                ) {
                                                                    listOf(100.0, 700.0).forEach { score ->
                                                                        FilterChip(
                                                                            selected = diploma.diplomaTotal == score,
                                                                            onClick = {
                                                                                diploma.diplomaTotal = score
                                                                                if (diploma.subjects.isNotEmpty()) {
                                                                                    val share = score / diploma.subjects.size
                                                                                    diploma.subjects.forEach { sub ->
                                                                                        diploma.subjectWeights[sub] = Math.round(share * 10.0) / 10.0
                                                                                    }
                                                                                }
                                                                            },
                                                                            label = { Text("${score.toInt()}", fontSize = 10.5.sp) },
                                                                            shape = RoundedCornerShape(8.dp),
                                                                            modifier = Modifier.height(16.dp)
                                                                        )
                                                                    }
                                                                    
                                                                    var customScoreText by remember(diploma.diplomaTotal) {
                                                                        mutableStateOf(if (diploma.diplomaTotal != 100.0 && diploma.diplomaTotal != 700.0) diploma.diplomaTotal.toInt().toString() else "")
                                                                    }
                                                                    OutlinedTextField(
                                                                        value = customScoreText,
                                                                        onValueChange = { valText ->
                                                                            customScoreText = valText.filter { it.isDigit() }
                                                                            val parsed = customScoreText.toDoubleOrNull() ?: 0.0
                                                                            if (parsed > 0.0) {
                                                                                diploma.diplomaTotal = parsed
                                                                                if (diploma.subjects.isNotEmpty()) {
                                                                                    val share = parsed / diploma.subjects.size
                                                                                    diploma.subjects.forEach { sub ->
                                                                                        diploma.subjectWeights[sub] = Math.round(share * 10.0) / 10.0
                                                                                    }
                                                                                }
                                                                            }
                                                                        },
                                                                        placeholder = { Text("أخرى...", fontSize = 10.sp) },
                                                                        modifier = Modifier.width(85.dp).height(48.dp),
                                                                        singleLine = true,
                                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                                        textStyle = TextStyle(color = Color(0xFF1E293B), fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center),
                                                                        shape = RoundedCornerShape(8.dp),
                                                                        colors = OutlinedTextFieldDefaults.colors(
                                                                            focusedTextColor = Color(0xFF1E293B),
                                                                            unfocusedTextColor = Color(0xFF1E293B),
                                                                            focusedPlaceholderColor = Color.Gray,
                                                                            unfocusedPlaceholderColor = Color.Gray,
                                                                            focusedBorderColor = DawamiNavy,
                                                                            unfocusedBorderColor = Color(0xFFCBD5E1),
                                                                            cursorColor = DawamiNavy
                                                                        )
                                                                    )
                                                                }
                                                            }

                                                            // Passing Percentage Selection
                                                            Column(
                                                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                                            ) {
                                                                Text(
                                                                    text = "✅ نسبة النجاح المطلوبة (%):",
                                                                    fontSize = 11.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = DawamiNavy
                                                                )
                                                                Row(
                                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                    modifier = Modifier.fillMaxWidth()
                                                                ) {
                                                                    listOf(50.0, 60.0, 75.0).forEach { passScore ->
                                                                        FilterChip(
                                                                            selected = diploma.passingPercentage == passScore,
                                                                            onClick = { diploma.passingPercentage = passScore },
                                                                            label = { Text("${passScore.toInt()}%", fontSize = 10.5.sp) },
                                                                            shape = RoundedCornerShape(8.dp),
                                                                            modifier = Modifier.height(32.dp)
                                                                        )
                                                                    }
                                                                    var customPassScoreText by remember(diploma.passingPercentage) {
                                                                        mutableStateOf(if (diploma.passingPercentage != 50.0 && diploma.passingPercentage != 60.0 && diploma.passingPercentage != 75.0) diploma.passingPercentage.toInt().toString() else "")
                                                                    }
                                                                    OutlinedTextField(
                                                                        value = customPassScoreText,
                                                                        onValueChange = { valText ->
                                                                            customPassScoreText = valText.filter { it.isDigit() }
                                                                            val parsed = customPassScoreText.toDoubleOrNull() ?: 0.0
                                                                            if (parsed > 0.0) {
                                                                                diploma.passingPercentage = parsed
                                                                            }
                                                                        },
                                                                        placeholder = { Text("أخرى...", fontSize = 10.sp) },
                                                                        modifier = Modifier.width(85.dp).height(48.dp),
                                                                        singleLine = true,
                                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                                        textStyle = TextStyle(color = Color(0xFF1E293B), fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center),
                                                                        shape = RoundedCornerShape(8.dp),
                                                                        colors = OutlinedTextFieldDefaults.colors(
                                                                            focusedTextColor = Color(0xFF1E293B),
                                                                            unfocusedTextColor = Color(0xFF1E293B),
                                                                            focusedPlaceholderColor = Color.Gray,
                                                                            unfocusedPlaceholderColor = Color.Gray,
                                                                            focusedBorderColor = DawamiNavy,
                                                                            unfocusedBorderColor = Color(0xFFCBD5E1),
                                                                            cursorColor = DawamiNavy
                                                                        )
                                                                    )
                                                                }
                                                            }

                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Text("📖 المواد الدراسية المقررة:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                                                Row(
                                                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                                    verticalAlignment = Alignment.CenterVertically
                                                                ) {
                                                                    TextButton(
                                                                        onClick = {
                                                                            if (diploma.subjects.isNotEmpty()) {
                                                                                val share = diploma.diplomaTotal / diploma.subjects.size
                                                                                diploma.subjects.forEach { sub ->
                                                                                    diploma.subjectWeights[sub] = Math.round(share * 10.0) / 10.0
                                                                                }
                                                                                Toast.makeText(context, "تم توزيع الدرجات بالتساوي! ⚖️", Toast.LENGTH_SHORT).show()
                                                                            }
                                                                        }
                                                                    ) {
                                                                        Text("توزيع بالتساوي ⚖️", fontSize = 10.sp, color = DawamiTeal, fontWeight = FontWeight.Bold)
                                                                    }
                                                                    AssistChip(
                                                                        onClick = { selectedDiplomaForSubject = diploma },
                                                                        label = { Text("+ مادة", fontSize = 10.sp, color = DawamiTeal, fontWeight = FontWeight.Bold) },
                                                                        leadingIcon = { Icon(Icons.Default.Add, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(12.dp)) },
                                                                        shape = RoundedCornerShape(8.dp),
                                                                        modifier = Modifier.height(28.dp)
                                                                    )
                                                                }
                                                            }

                                                            if (diploma.subjects.isEmpty()) {
                                                                Text("لا توجد مواد مضافة لهذا الدبلوم بعد.", fontSize = 11.sp, color = Color.Gray)
                                                            } else {
                                                                // Subjects List / Chips
                                                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                                    diploma.subjects.forEachIndexed { subIdx, subjectName ->
                                                                        Surface(
                                                                            modifier = Modifier.fillMaxWidth(),
                                                                            color = Color(0xFFF8FAFC),
                                                                            shape = RoundedCornerShape(10.dp),
                                                                            border = BorderStroke(0.5.dp, Color(0xFFE2E8F0))
                                                                        ) {
                                                                            Row(
                                                                                modifier = Modifier
                                                                                    .fillMaxWidth()
                                                                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                                verticalAlignment = Alignment.CenterVertically
                                                                            ) {
                                                                                Row(
                                                                                    modifier = Modifier.weight(1f),
                                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                                                ) {
                                                                                    Icon(Icons.Default.Book, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(14.dp))
                                                                                    Text(subjectName, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = DawamiNavy)
                                                                                }

                                                                                Row(
                                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                                                ) {
                                                                                    // Subject Weight Input
                                                                                    var weightText by remember(subjectName, diploma.subjectWeights[subjectName]) {
                                                                                        mutableStateOf(diploma.subjectWeights[subjectName]?.toInt()?.toString() ?: "")
                                                                                    }
                                                                                    OutlinedTextField(
                                                                                        value = weightText,
                                                                                        onValueChange = { valText ->
                                                                                            weightText = valText.filter { it.isDigit() }
                                                                                            val parsed = weightText.toDoubleOrNull() ?: 0.0
                                                                                            diploma.subjectWeights[subjectName] = parsed
                                                                                        },
                                                                                        placeholder = { Text("الدرجة", fontSize = 10.sp) },
                                                                                        modifier = Modifier.width(75.dp).height(48.dp),
                                                                                        singleLine = true,
                                                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                                                        textStyle = TextStyle(color = Color(0xFF1E293B), fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center),
                                                                                        shape = RoundedCornerShape(8.dp),
                                                                                        colors = OutlinedTextFieldDefaults.colors(
                                                                                            focusedTextColor = Color(0xFF1E293B),
                                                                                            unfocusedTextColor = Color(0xFF1E293B),
                                                                                            focusedPlaceholderColor = Color.Gray,
                                                                                            unfocusedPlaceholderColor = Color.Gray,
                                                                                            focusedBorderColor = DawamiNavy,
                                                                                            unfocusedBorderColor = Color(0xFFCBD5E1),
                                                                                            cursorColor = DawamiNavy
                                                                                        )
                                                                                    )

                                                                                    // Custom Grades setup for this subject
                                                                                    val hasCustomGrades = diploma.subjectCustomFields[subjectName]?.isNotEmpty() == true
                                                                                    IconButton(
                                                                                        onClick = {
                                                                                            configuringSubjectForGrades = Pair(diploma, subjectName)
                                                                                            configuringDiplomaDeptName = dept.name
                                                                                        },
                                                                                        modifier = Modifier.size(28.dp)
                                                                                    ) {
                                                                                        Icon(
                                                                                            imageVector = Icons.Default.Settings,
                                                                                            contentDescription = "ضبط تفصيلي للمادة",
                                                                                            tint = if (hasCustomGrades) DawamiGold else Color.Gray,
                                                                                            modifier = Modifier.size(14.dp)
                                                                                        )
                                                                                    }

                                                                                    IconButton(
                                                                                        onClick = { editingSubjectTarget = Triple(diploma, subIdx, subjectName) },
                                                                                        modifier = Modifier.size(28.dp)
                                                                                    ) {
                                                                                        Icon(Icons.Default.Edit, contentDescription = "تعديل المادة", tint = Color(0xFF2563EB), modifier = Modifier.size(14.dp))
                                                                                    }
                                                                                    IconButton(
                                                                                        onClick = { deletingSubjectTarget = Triple(diploma, subIdx, subjectName) },
                                                                                        modifier = Modifier.size(28.dp)
                                                                                    ) {
                                                                                        Icon(Icons.Default.Close, contentDescription = "حذف المادة", tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp))
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            HorizontalDivider(color = Color(0xFFF1F5F9))

                                                            // Grade Distribution Summary
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                val fields = getDiplomaDefaultFields(dept.name, diploma)
                                                                val summary = fields.joinToString("، ") { "${it.first} (${it.second})" }
                                                                Text(
                                                                    text = "⚖️ التوزيع الافتراضي: $summary",
                                                                    fontSize = 10.5.sp,
                                                                    color = Color.Gray,
                                                                    modifier = Modifier.weight(1f),
                                                                    maxLines = 1,
                                                                    overflow = TextOverflow.Ellipsis
                                                                )
                                                                TextButton(
                                                                    onClick = {
                                                                        configuringDiplomaForGrades = diploma
                                                                        configuringDiplomaDeptName = dept.name
                                                                    },
                                                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                                                ) {
                                                                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(14.dp), tint = DawamiNavy)
                                                                    Spacer(Modifier.width(4.dp))
                                                                    Text("ضبط درجات الدبلوم", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        // Add Diploma Input Field inside Department
                                        Surface(
                                            modifier = Modifier.fillMaxWidth(),
                                            color = Color(0xFFF8FAFC),
                                            shape = RoundedCornerShape(12.dp),
                                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(8.dp),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                OutlinedTextField(
                                                    value = if (selectedDeptIndexForDiploma == deptIdx) newDiplomaName else "",
                                                    onValueChange = {
                                                        selectedDeptIndexForDiploma = deptIdx
                                                        newDiplomaName = it
                                                    },
                                                    placeholder = { Text("إضافة دبلوم جديد لهذا القسم...", fontSize = 11.5.sp) },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(10.dp),
                                                    singleLine = true
                                                )
                                                Button(
                                                    onClick = {
                                                        if (selectedDeptIndexForDiploma == deptIdx && newDiplomaName.isNotBlank()) {
                                                            val trimmed = newDiplomaName.trim()
                                                            val newDip = DiplomaItem(name = trimmed)
                                                            dept.diplomas.add(newDip)
                                                            expandedDiplomaNames = expandedDiplomaNames + "${dept.name}_$trimmed"
                                                            newDiplomaName = ""
                                                            Toast.makeText(context, "تمت إضافة الدبلوم بنجاح!", Toast.LENGTH_SHORT).show()
                                                        } else {
                                                            Toast.makeText(context, "يرجى كتابة اسم الدبلوم", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    shape = RoundedCornerShape(10.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                                                ) {
                                                    Text("إضافة دبلوم", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { currentStep = 1 },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("السابق ⬅️")
                            }

                            Button(
                                onClick = {
                                    // Save everything
                                    viewModel.saveOnboardingSetup(
                                        orgTypeVal = orgTypeState,
                                        instName = instNameState,
                                        dirName = directorState,
                                        logoUri = logoUriState,
                                        departments = departmentsList
                                    )
                                    Toast.makeText(context, "تم حفظ التهيئة بنجاح وشحن المواد المقررة! 🎉", Toast.LENGTH_LONG).show()
                                    viewModel.navigateTo(Screen.Selection)
                                },
                                modifier = Modifier
                                    .weight(2f)
                                    .height(50.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal)
                            ) {
                                Text("حفظ التهيئة والبدء بالنظام 🚀", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }

    // Edit Department Dialog
    if (editingDept != null) {
        val currentDept = editingDept!!
        var tempName by remember(currentDept) { mutableStateOf(currentDept.name) }
        AlertDialog(
            onDismissRequest = { editingDept = null },
            title = { Text("تعديل اسم القسم الأكاديمي ✏️", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DawamiNavy) },
            text = {
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text("اسم القسم الأكاديمي") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = tempName.trim()
                        if (trimmed.isNotBlank()) {
                            val oldName = currentDept.name
                            currentDept.name = trimmed
                            if (expandedDeptNames.contains(oldName)) {
                                expandedDeptNames = (expandedDeptNames - oldName) + trimmed
                            }
                            editingDept = null
                            Toast.makeText(context, "تم تعديل اسم القسم بنجاح! ✏️✅", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "يرجى كتابة اسم القسم", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ التعديل", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingDept = null }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }

    // Delete Department Dialog
    if (deletingDept != null) {
        val deptToRemove = deletingDept!!
        val dipCount = deptToRemove.diplomas.size
        val subCount = deptToRemove.diplomas.sumOf { it.subjects.size }
        AlertDialog(
            onDismissRequest = { deletingDept = null },
            title = { Text("حذف القسم الأكاديمي ⚠️", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626)) },
            text = {
                Text(
                    text = "هل أنت متاكد من رغبتك في حذف قسم (${deptToRemove.name})؟\nسوف يتم حذف $dipCount دبلوم و $subCount مادة تابعة لهذا القسم.",
                    fontSize = 13.sp,
                    color = Color.DarkGray
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        departmentsList.remove(deptToRemove)
                        expandedDeptNames = expandedDeptNames - deptToRemove.name
                        deletingDept = null
                        Toast.makeText(context, "تم حذف القسم بنجاح!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("نعم، حذف القسم", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingDept = null }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }

    // Edit Diploma Dialog
    if (editingDiploma != null) {
        val (dept, diploma) = editingDiploma!!
        var tempName by remember(diploma) { mutableStateOf(diploma.name) }
        AlertDialog(
            onDismissRequest = { editingDiploma = null },
            title = { Text("تعديل اسم الدبلوم ✏️", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DawamiNavy) },
            text = {
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text("اسم الدبلوم / البرنامج") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = tempName.trim()
                        if (trimmed.isNotBlank()) {
                            diploma.name = trimmed
                            editingDiploma = null
                            Toast.makeText(context, "تم تعديل اسم الدبلوم بنجاح!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "يرجى كتابة اسم الدبلوم", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ التعديل", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingDiploma = null }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }

    // Delete Diploma Dialog
    if (deletingDiploma != null) {
        val (dept, diploma) = deletingDiploma!!
        AlertDialog(
            onDismissRequest = { deletingDiploma = null },
            title = { Text("حذف الدبلوم ⚠️", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626)) },
            text = {
                Text(
                    text = "هل أنت متاكد من رغبتك في حذف دبلوم (${diploma.name}) التابع لقسم (${dept.name})؟\nسيتم حذف جميع المواد (${diploma.subjects.size}) التابعة له.",
                    fontSize = 13.sp,
                    color = Color.DarkGray
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        dept.diplomas.remove(diploma)
                        deletingDiploma = null
                        Toast.makeText(context, "تم حذف الدبلوم بنجاح!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("حذف الدبلوم", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingDiploma = null }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }

    // Edit Subject Dialog
    if (editingSubjectTarget != null) {
        val (diploma, subIdx, subName) = editingSubjectTarget!!
        var tempName by remember(subName) { mutableStateOf(subName) }
        AlertDialog(
            onDismissRequest = { editingSubjectTarget = null },
            title = { Text("تعديل اسم المادة المقررة ✏️", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DawamiNavy) },
            text = {
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text("اسم المادة") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = tempName.trim()
                        if (trimmed.isNotBlank()) {
                            if (subIdx in diploma.subjects.indices) {
                                val oldWeight = diploma.subjectWeights.remove(diploma.subjects[subIdx]) ?: 100.0
                                val oldCustomFields = diploma.subjectCustomFields.remove(diploma.subjects[subIdx])
                                diploma.subjects[subIdx] = trimmed
                                diploma.subjectWeights[trimmed] = oldWeight
                                if (oldCustomFields != null) {
                                    diploma.subjectCustomFields[trimmed] = oldCustomFields
                                }
                            }
                            editingSubjectTarget = null
                            Toast.makeText(context, "تم تعديل اسم المادة بنجاح!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "يرجى كتابة اسم المادة", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ التعديل", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingSubjectTarget = null }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }

    // Delete Subject Dialog
    if (deletingSubjectTarget != null) {
        val (diploma, subIdx, subName) = deletingSubjectTarget!!
        AlertDialog(
            onDismissRequest = { deletingSubjectTarget = null },
            title = { Text("حذف المادة ⚠️", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626)) },
            text = {
                Text("هل أنت متاكد من رغبتك في حذف مادة ($subName) من دبلوم (${diploma.name})؟", fontSize = 13.sp, color = Color.DarkGray)
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (subIdx in diploma.subjects.indices) {
                            val removedName = diploma.subjects.removeAt(subIdx)
                            diploma.subjectWeights.remove(removedName)
                            diploma.subjectCustomFields.remove(removedName)
                            diploma.diplomaTotal = if (diploma.subjectWeights.isNotEmpty()) diploma.subjectWeights.values.sum() else 100.0
                        }
                        deletingSubjectTarget = null
                        Toast.makeText(context, "تم حذف المادة بنجاح!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("حذف المادة", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingSubjectTarget = null }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }

    // Add Subject Dialog
    if (selectedDiplomaForSubject != null) {
        val targetDiploma = selectedDiplomaForSubject!!
        AlertDialog(
            onDismissRequest = { selectedDiplomaForSubject = null },
            title = { Text("إضافة مادة مقررة لـ (${targetDiploma.name})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy) },
            text = {
                OutlinedTextField(
                    value = newSubjectName,
                    onValueChange = { newSubjectName = it },
                    label = { Text("اسم المادة المقررة") },
                    placeholder = { Text("مثال: الجداول الإلكترونية المتقدمة") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newSubjectName.isNotBlank()) {
                            val trimmedName = newSubjectName.trim()
                            targetDiploma.subjects.add(trimmedName)
                            targetDiploma.subjectWeights[trimmedName] = 100.0
                            targetDiploma.diplomaTotal = targetDiploma.subjectWeights.values.sum()
                            newSubjectName = ""
                            selectedDiplomaForSubject = null
                            Toast.makeText(context, "تمت إضافة المادة بنجاح!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("إضافة المادة", fontWeight = FontWeight.Bold, color = DawamiNavy)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedDiplomaForSubject = null }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }

    // Configure Diploma Grades Dialog
    if (configuringDiplomaForGrades != null) {
        val targetDiploma = configuringDiplomaForGrades!!
        val tempFields = remember(targetDiploma) {
            val initial = mutableStateListOf<Pair<String, Int>>()
            initial.addAll(getDiplomaDefaultFields(configuringDiplomaDeptName, targetDiploma))
            initial
        }
        var newCatName by remember { mutableStateOf("") }
        var newCatMax by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { configuringDiplomaForGrades = null },
            title = {
                Text(
                    text = "ضبط توزيع درجات دبلوم: ${targetDiploma.name}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = DawamiNavy
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "قم بتعديل أو إضافة فئات رصد الدرجات (مجموع الدرجات يجب أن يكون 100):",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )

                    tempFields.forEachIndexed { idx, pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = pair.first,
                                onValueChange = { newVal ->
                                    tempFields[idx] = Pair(newVal, pair.second)
                                },
                                label = { Text("الفئة", fontSize = 11.sp) },
                                modifier = Modifier.weight(1.5f),
                                shape = RoundedCornerShape(8.dp),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = if (pair.second == 0) "" else pair.second.toString(),
                                onValueChange = { newVal ->
                                    val num = newVal.filter { it.isDigit() }.toIntOrNull() ?: 0
                                    tempFields[idx] = Pair(pair.first, num)
                                },
                                label = { Text("الدرجة القصوى", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                singleLine = true
                            )
                            IconButton(
                                onClick = { tempFields.removeAt(idx) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red)
                            }
                        }
                    }

                    HorizontalDivider(color = Color(0xFFF1F5F9))

                    Text(
                        text = "فئات مقترحة سريعة (انقر للإضافة):",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(
                            Triple("سلوك", 5, "السلوك والمواظبة"),
                            Triple("واجبات", 10, "الواجبات والمهام المدرسية"),
                            Triple("نشاط", 5, "النشاط العملي والصفي"),
                            Triple("أبحاث", 10, "الأبحاث والمشاريع الصغيرة"),
                            Triple("دفتر", 5, "دفتر المتابعة والتلخيص")
                        ).forEach { (suggestedName, suggestedScore, desc) ->
                            Surface(
                                color = DawamiTeal.copy(alpha = 0.08f),
                                contentColor = DawamiTeal,
                                border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.clickable {
                                    if (tempFields.none { it.first == suggestedName }) {
                                        tempFields.add(Pair(suggestedName, suggestedScore))
                                        Toast.makeText(context, "تم إضافة فئة '$suggestedName' بقيمة $suggestedScore! ➕", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "هذه الفئة مضافة بالفعل", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Text(text = "$suggestedName ($suggestedScore)", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Text(
                        text = "أو إضافة فئة مخصصة يدوياً:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newCatName,
                            onValueChange = { newCatName = it },
                            placeholder = { Text("مثال: أبحاث وعروض", fontSize = 11.sp) },
                            modifier = Modifier.weight(1.5f),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = newCatMax,
                            onValueChange = { newCatMax = it.filter { it.isDigit() } },
                            placeholder = { Text("الدرجة", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                val maxVal = newCatMax.toIntOrNull() ?: 0
                                if (newCatName.isNotBlank() && maxVal > 0) {
                                    tempFields.add(Pair(newCatName.trim(), maxVal))
                                    newCatName = ""
                                    newCatMax = ""
                                } else {
                                    Toast.makeText(context, "يرجى كتابة اسم الفئة والدرجة القصوى", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                        }
                    }

                    val totalSum = tempFields.sumOf { it.second }
                    Text(
                        text = "المجموع الكلي للدرجات: $totalSum من 100",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (totalSum == 100) Color(0xFF10B981) else DawamiGold
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val totalSum = tempFields.sumOf { it.second }
                        if (totalSum != 100) {
                            Toast.makeText(context, "يجب أن يكون مجموع الفئات مساوياً لـ 100 تماماً (المجموع الحالي: $totalSum)", Toast.LENGTH_LONG).show()
                        } else {
                            targetDiploma.customFields.clear()
                            targetDiploma.customFields.addAll(tempFields)
                            targetDiploma.subjectCustomFields.clear()
                            configuringDiplomaForGrades = null
                            Toast.makeText(context, "تم حفظ توزيع الدرجات للدبلوم بنجاح! 👍", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("حفظ التوزيع", fontWeight = FontWeight.Bold, color = DawamiNavy)
                }
            },
            dismissButton = {
                TextButton(onClick = { configuringDiplomaForGrades = null }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }
    // Configure Subject Grades Dialog
    if (configuringSubjectForGrades != null) {
        val (targetDiploma, subjectName) = configuringSubjectForGrades!!
        val tempFields = remember(targetDiploma, subjectName) {
            val initial = mutableStateListOf<Pair<String, Int>>()
            val existing = targetDiploma.subjectCustomFields[subjectName]
            if (existing != null && existing.isNotEmpty()) {
                initial.addAll(existing)
            } else {
                initial.addAll(getDiplomaDefaultFields(configuringDiplomaDeptName, targetDiploma))
            }
            initial
        }
        var newCatName by remember { mutableStateOf("") }
        var newCatMax by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { configuringSubjectForGrades = null },
            title = {
                Text(
                    text = "ضبط توزيع درجات مادة: $subjectName",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = DawamiNavy
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "قم بتعديل أو إضافة فئات رصد الدرجات للمادة (مجموع الدرجات يجب أن يكون 100):",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )

                    tempFields.forEachIndexed { idx, pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = pair.first,
                                onValueChange = { newVal ->
                                    tempFields[idx] = Pair(newVal, pair.second)
                                },
                                label = { Text("الفئة", fontSize = 11.sp) },
                                modifier = Modifier.weight(1.5f),
                                shape = RoundedCornerShape(8.dp),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = if (pair.second == 0) "" else pair.second.toString(),
                                onValueChange = { newVal ->
                                    val num = newVal.filter { it.isDigit() }.toIntOrNull() ?: 0
                                    tempFields[idx] = Pair(pair.first, num)
                                },
                                label = { Text("الدرجة القصوى", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                singleLine = true
                            )
                            IconButton(
                                onClick = { tempFields.removeAt(idx) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red)
                            }
                        }
                    }

                    HorizontalDivider(color = Color(0xFFF1F5F9))

                    Text(
                        text = "فئات مقترحة سريعة (انقر للإضافة):",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(
                            Triple("سلوك", 5, "السلوك والمواظبة"),
                            Triple("واجبات", 10, "الواجبات والمهام المدرسية"),
                            Triple("نشاط", 5, "النشاط العملي والصفي"),
                            Triple("أبحاث", 10, "الأبحاث والمشاريع الصغيرة"),
                            Triple("دفتر", 5, "دفتر المتابعة والتلخيص")
                        ).forEach { (suggestedName, suggestedScore, desc) ->
                            Surface(
                                color = DawamiTeal.copy(alpha = 0.08f),
                                contentColor = DawamiTeal,
                                border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.clickable {
                                    if (tempFields.none { it.first == suggestedName }) {
                                        tempFields.add(Pair(suggestedName, suggestedScore))
                                        Toast.makeText(context, "تم إضافة فئة '$suggestedName' بقيمة $suggestedScore! ➕", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "هذه الفئة مضافة بالفعل", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Text(text = "$suggestedName ($suggestedScore)", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Text(
                        text = "أو إضافة فئة مخصصة يدوياً:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newCatName,
                            onValueChange = { newCatName = it },
                            placeholder = { Text("مثال: أبحاث وعروض", fontSize = 11.sp) },
                            modifier = Modifier.weight(1.5f),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = newCatMax,
                            onValueChange = { newCatMax = it.filter { it.isDigit() } },
                            placeholder = { Text("الدرجة", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                val maxVal = newCatMax.toIntOrNull() ?: 0
                                if (newCatName.isNotBlank() && maxVal > 0) {
                                    tempFields.add(Pair(newCatName.trim(), maxVal))
                                    newCatName = ""
                                    newCatMax = ""
                                } else {
                                    Toast.makeText(context, "يرجى كتابة اسم الفئة والدرجة القصوى", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                        }
                    }

                    val totalSum = tempFields.sumOf { it.second }
                    Text(
                        text = "المجموع الكلي للدرجات: $totalSum من 100",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (totalSum == 100) Color(0xFF10B981) else DawamiGold
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val totalSum = tempFields.sumOf { it.second }
                        if (totalSum != 100) {
                            Toast.makeText(context, "يجب أن يكون مجموع الفئات مساوياً لـ 100 تماماً (المجموع الحالي: $totalSum)", Toast.LENGTH_LONG).show()
                        } else {
                            targetDiploma.subjectCustomFields[subjectName] = tempFields.toList()
                            configuringSubjectForGrades = null
                            Toast.makeText(context, "تم حفظ توزيع درجات المادة بنجاح! 👍", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("حفظ التوزيع", fontWeight = FontWeight.Bold, color = DawamiNavy)
                }
            },
            dismissButton = {
                TextButton(onClick = { configuringSubjectForGrades = null }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }
}
