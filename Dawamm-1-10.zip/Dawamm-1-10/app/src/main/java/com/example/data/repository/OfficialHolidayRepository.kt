package com.example.data.repository

import com.example.data.dao.OfficialHolidayDao
import com.example.data.entity.OfficialHoliday
import kotlinx.coroutines.flow.Flow

/**
 * OfficialHolidayRepository: مسؤول عن إدارة الإجازات الرسمية والعطلات المعتمدة في النظام.
 */
class OfficialHolidayRepository(
    private val officialHolidayDao: OfficialHolidayDao
) {
    val allHolidaysFlow: Flow<List<OfficialHoliday>> = officialHolidayDao.getAllHolidays()
    val enabledHolidaysFlow: Flow<List<OfficialHoliday>> = officialHolidayDao.getEnabledHolidays()

    suspend fun getEnabledHolidaysSync(): List<OfficialHoliday> = officialHolidayDao.getEnabledHolidaysSync()

    suspend fun insertHoliday(holiday: OfficialHoliday): Long = officialHolidayDao.insertHoliday(holiday)

    suspend fun insertHolidays(holidays: List<OfficialHoliday>) = officialHolidayDao.insertHolidays(holidays)

    suspend fun updateHoliday(holiday: OfficialHoliday) = officialHolidayDao.updateHoliday(holiday)

    suspend fun deleteHoliday(holiday: OfficialHoliday) = officialHolidayDao.deleteHoliday(holiday)

    suspend fun deleteAllHolidays() = officialHolidayDao.deleteAllHolidays()
}
