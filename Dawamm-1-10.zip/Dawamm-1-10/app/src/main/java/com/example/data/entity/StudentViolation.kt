package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student_violations")
data class StudentViolation(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val courseId: Long,
    val subjectName: String = "",
    val studentId: Long,
    val studentName: String,
    val studentPhone: String = "",
    val violationType: String, // e.g. "أجهزة ومعمل", "حضور وتأخير", "سلوك وقاعة", "أخرى"
    val violationTitle: String, // e.g. "عدم إغلاق جهاز الحاسوب بالشكل الصحيح"
    val actionTaken: String, // e.g. "إنذار رسمي أول (تكرار المخالفة سيعرضك لخصم درجات من المواظبة)"
    val date: String, // e.g. "2026/08/26"
    val time: String = "", // e.g. "10:30 ص"
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
