package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.GradingViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel

@Composable
fun AssignmentSetupScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    gradingViewModel: GradingViewModel? = null,
    showMainLayout: Boolean = true
) {
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    
    MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            AssignmentManagementSection(
                viewModel = viewModel,
                courseViewModel = courseViewModel,
                studentViewModel = studentViewModel,
                gradingViewModel = gradingViewModel,
                isDarkTheme = isDarkTheme
            )
        }
    }
}
