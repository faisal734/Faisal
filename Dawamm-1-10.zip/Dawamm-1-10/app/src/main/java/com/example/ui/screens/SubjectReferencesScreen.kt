package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.SubjectReference
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.MainViewModel

import java.io.File

fun getFileSizeLabelFromPath(path: String): String {
    if (path.isBlank() || path.startsWith("http")) return ""
    try {
        val file = File(path)
        if (file.exists()) {
            val sizeKb = file.length() / 1024
            if (sizeKb > 1024) return "${sizeKb / 1024} MB"
            return "$sizeKb KB"
        }
    } catch (e: Exception) {}
    return ""
}

@Composable
fun SubjectReferencesScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    showMainLayout: Boolean = true
) {
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()

    MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            SubjectReferencesSection(
                viewModel = viewModel,
                courseViewModel = courseViewModel,
                isDarkTheme = isDarkTheme
            )
        }
    }
}

@Composable
fun SubjectReferencesSection(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    isDarkTheme: Boolean
) {
    val context = LocalContext.current
    val subjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()
    val courses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val subjectReferences by (courseViewModel?.allSubjectReferences ?: viewModel.dbSubjectReferences).collectAsState()

    val trainerBaseDirUri by viewModel.trainerBaseDirUri.collectAsState()
    val trainerBaseDirName by viewModel.trainerBaseDirName.collectAsState()

    var selectedSubjectForRef by remember { mutableStateOf<String?>(subjects.firstOrNull()?.name ?: "ميكروسوفت وورد") }
    var showAddEditRefDialog by remember { mutableStateOf(false) }
    var showExistingFilesDialog by remember { mutableStateOf(false) }
    var editingRef by remember { mutableStateOf<SubjectReference?>(null) }
    var refToDelete by remember { mutableStateOf<SubjectReference?>(null) }
    var tempRefPath by remember { mutableStateOf("") }
    var tempRefName by remember { mutableStateOf("") }

    val selectRefFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val copied = handleFileSelection(context, uri, isReference = true, baseDirUriString = trainerBaseDirUri)
            if (copied != null) {
                tempRefPath = copied.first
                tempRefName = copied.second
                Toast.makeText(context, "تم إرفاق الملف بنجاح! 📎", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "فشل نسخ الملف، يرجى المحاولة مرة أخرى.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isDarkTheme) Color(0xFF1E293B) else DawamiNavy.copy(alpha = 0.05f)
            ),
            border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else DawamiNavy.copy(alpha = 0.15f))
        ) {
            Row(
                modifier = Modifier.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = DawamiNavy,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.LibraryBooks,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "المراجع الإضافية للمواد 📚",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDarkTheme) Color.White else DawamiNavy
                    )
                    Text(
                        text = "إدارة وعرض الكتب والملفات الإضافية.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // References Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else Color.White),
            border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "اختر المادة الدراسية لعرض وإدارة المراجع الإضافية:",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDarkTheme) Color.White else DawamiNavy
                )

                // Department & Diploma filter for references
                val allDepartments = remember(courses, subjects) {
                    (courses.map { it.departmentName } + subjects.map { it.departmentName })
                        .distinct()
                        .filter { it.isNotBlank() }
                }
                var selectedDepartment by remember { mutableStateOf("جميع الأقسام") }

                val allDiplomas = remember(courses, subjects, selectedDepartment) {
                    val filteredCourses = if (selectedDepartment == "جميع الأقسام" || selectedDepartment.isBlank()) courses else courses.filter { it.departmentName == selectedDepartment }
                    val filteredSubjects = if (selectedDepartment == "جميع الأقسام" || selectedDepartment.isBlank()) subjects else subjects.filter { it.departmentName == selectedDepartment }
                    (filteredCourses.map { it.diplomaName } + filteredSubjects.map { it.diplomaName })
                        .distinct()
                        .filter { it.isNotBlank() }
                }
                var selectedDiploma by remember { mutableStateOf("جميع الدبلومات") }

                if (allDepartments.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("القسم والدبلوم المستهدف:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Department selection
                            var isDeptExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1f)) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { isDeptExpanded = true }
                                        .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                    color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(selectedDepartment.ifEmpty { "جميع الأقسام" }, fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                                DropdownMenu(
                                    expanded = isDeptExpanded,
                                    onDismissRequest = { isDeptExpanded = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("جميع الأقسام", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                        onClick = {
                                            selectedDepartment = "جميع الأقسام"
                                            selectedDiploma = "جميع الدبلومات"
                                            isDeptExpanded = false
                                        }
                                    )
                                    allDepartments.forEach { dept ->
                                        DropdownMenuItem(
                                            text = { Text(dept, fontSize = 11.sp) },
                                            onClick = {
                                                selectedDepartment = dept
                                                selectedDiploma = "جميع الدبلومات"
                                                isDeptExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Diploma selection
                            var isDiplomaExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1f)) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { isDiplomaExpanded = true }
                                        .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                    color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(selectedDiploma.ifEmpty { "جميع الدبلومات" }, fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                                DropdownMenu(
                                    expanded = isDiplomaExpanded,
                                    onDismissRequest = { isDiplomaExpanded = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("جميع الدبلومات", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                        onClick = {
                                            selectedDiploma = "جميع الدبلومات"
                                            isDiplomaExpanded = false
                                        }
                                    )
                                    allDiplomas.forEach { dip ->
                                        DropdownMenuItem(
                                            text = { Text(dip, fontSize = 11.sp) },
                                            onClick = {
                                                selectedDiploma = dip
                                                isDiplomaExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Subjects list dropdown based on filters
                val filteredSubjects = remember(subjects, selectedDepartment, selectedDiploma) {
                    subjects.filter {
                        (selectedDepartment.isEmpty() || selectedDepartment == "جميع الأقسام" || it.departmentName == selectedDepartment) &&
                        (selectedDiploma.isEmpty() || selectedDiploma == "جميع الدبلومات" || it.diplomaName == selectedDiploma)
                    }.ifEmpty { subjects }
                }

                LaunchedEffect(filteredSubjects) {
                    if (filteredSubjects.none { it.name == selectedSubjectForRef }) {
                        selectedSubjectForRef = filteredSubjects.firstOrNull()?.name
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("المادة الدراسية:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    var isSubjectDropdownExpanded by remember { mutableStateOf(false) }

                    Box(modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { isSubjectDropdownExpanded = true }
                                .border(1.dp, Color.LightGray, RoundedCornerShape(10.dp)),
                            color = if (isDarkTheme) Color(0xFF1E293B) else Color.White
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = selectedSubjectForRef ?: "اختر المادة الدراسية...",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        }

                        DropdownMenu(
                            expanded = isSubjectDropdownExpanded,
                            onDismissRequest = { isSubjectDropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            if (filteredSubjects.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("لا توجد مواد مسجلة لهذا القسم والدبلوم", fontSize = 11.sp) },
                                    onClick = { isSubjectDropdownExpanded = false }
                                )
                            } else {
                                filteredSubjects.forEach { sub ->
                                    DropdownMenuItem(
                                        text = { Text(sub.name, fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                                        onClick = {
                                            selectedSubjectForRef = sub.name
                                            isSubjectDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "المراجع الإضافية للمادة (${selectedSubjectForRef ?: ""}):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )

                    Button(
                        onClick = {
                            editingRef = null
                            tempRefPath = ""
                            tempRefName = ""
                            showAddEditRefDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة مرجع 📚", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                // Display list of references for selected subject
                val refsForSubject = subjectReferences.filter { it.subjectName == selectedSubjectForRef }

                if (refsForSubject.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.LibraryBooks, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(36.dp))
                            Text(
                                text = "لا توجد مراجع إضافية مضافة لهذه المادة حتى الآن.",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        refsForSubject.forEach { ref ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC),
                                border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Surface(
                                            color = DawamiNavy.copy(alpha = 0.1f),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                val iconVector = when (ref.type) {
                                                    "PDF" -> Icons.Default.PictureAsPdf
                                                    "رابط" -> Icons.Default.Link
                                                    "صورة" -> Icons.Default.Image
                                                    "فيديو" -> Icons.Default.Videocam
                                                    "Word" -> Icons.Default.Description
                                                    "Excel" -> Icons.Default.TableChart
                                                    "PowerPoint" -> Icons.Default.Slideshow
                                                    else -> Icons.Default.InsertDriveFile
                                                }
                                                Icon(imageVector = iconVector, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(20.dp))
                                            }
                                        }

                                        Column {
                                            Text(ref.title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Text("نوع: ${ref.type}", fontSize = 10.sp, color = Color.Gray)
                                                if (ref.fileName.isNotBlank()) {
                                                    val sizeStr = getFileSizeLabelFromPath(ref.urlOrPath)
                                                    val sizeText = if (sizeStr.isNotBlank()) " ($sizeStr)" else ""
                                                    Text("• ${ref.fileName}$sizeText", fontSize = 10.sp, color = DawamiTeal)
                                                }
                                            }
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        if (ref.urlOrPath.isNotBlank()) {
                                            IconButton(
                                                onClick = {
                                                    try {
                                                        if (ref.type == "رابط") {
                                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(ref.urlOrPath))
                                                            context.startActivity(intent)
                                                        } else {
                                                            val uri = getShareableUri(context, ref.urlOrPath, ref.fileName)
                                                            if (uri != null) {
                                                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                                                    setDataAndType(
                                                                        uri,
                                                                        when (ref.type) {
                                                                            "PDF" -> "application/pdf"
                                                                            "صورة" -> "image/*"
                                                                            "فيديو" -> "video/*"
                                                                            "Word" -> "application/msword"
                                                                            "Excel" -> "application/vnd.ms-excel"
                                                                            "PowerPoint" -> "application/vnd.ms-powerpoint"
                                                                            else -> "*/*"
                                                                        }
                                                                    )
                                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                                }
                                                                context.startActivity(intent)
                                                            } else {
                                                                Toast.makeText(context, "الملف غير موجود المسار!", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    } catch (e: Exception) {
                                                        Toast.makeText(context, "فشل فتح المرجع: ${e.message}", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                modifier = Modifier.size(30.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (ref.type == "رابط") Icons.Default.OpenInNew else Icons.Default.Visibility,
                                                    contentDescription = "فتح",
                                                    tint = DawamiNavy,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }

                                            IconButton(
                                                onClick = { shareReference(context, ref) },
                                                modifier = Modifier.size(30.dp)
                                            ) {
                                                Icon(Icons.Default.Share, contentDescription = "مشاركة", tint = DawamiTeal, modifier = Modifier.size(16.dp))
                                            }
                                        }

                                        IconButton(
                                            onClick = {
                                                editingRef = ref
                                                tempRefPath = if (ref.type != "رابط") ref.urlOrPath else ""
                                                tempRefName = ref.fileName
                                                showAddEditRefDialog = true
                                            },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                        }

                                        IconButton(
                                            onClick = {
                                                refToDelete = ref
                                            },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Deletion Confirmation Dialog
        if (refToDelete != null) {
            AlertDialog(
                onDismissRequest = { refToDelete = null },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626))
                        Text(
                            text = "تأكيد حذف المرجع الإضافي ⚠️",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = DawamiNavy
                        )
                    }
                },
                text = {
                    Text(
                        text = "هل أنت تأكد من رغبتك في حذف المرجع:\n\"${refToDelete?.title}\"؟",
                        fontSize = 12.5.sp,
                        color = if (isDarkTheme) Color.White else Color.DarkGray
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val r = refToDelete
                            refToDelete = null
                            if (r != null) {
                                viewModel.deleteSubjectReference(r)
                                Toast.makeText(context, "تم حذف المرجع بنجاح", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                    ) {
                        Text("حذف المرجع", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { refToDelete = null }) {
                        Text("إلغاء", color = DawamiNavy)
                    }
                },
                shape = RoundedCornerShape(18.dp),
                containerColor = if (isDarkTheme) DarkSurface else Color.White
            )
        }

        // Add / Edit Subject Reference Dialog
        if (showAddEditRefDialog) {
            var titleInput by remember { mutableStateOf(editingRef?.title ?: "") }
            var selectedTypeInDialog by remember { mutableStateOf(editingRef?.type ?: "PDF") }
            var urlInputInDialog by remember { mutableStateOf(if (editingRef?.type == "رابط") editingRef?.urlOrPath ?: "" else "") }

            val allDepartments = remember(courses) { courses.map { it.departmentName }.distinct().filter { it.isNotBlank() } }
            var departmentVal by remember { mutableStateOf(editingRef?.department ?: allDepartments.firstOrNull() ?: "") }

            val allDiplomas = remember(courses, departmentVal) {
                courses.filter { it.departmentName == departmentVal }.map { it.diplomaName }.distinct().filter { it.isNotBlank() }
            }
            var diplomaVal by remember { mutableStateOf(editingRef?.diploma ?: allDiplomas.firstOrNull() ?: "") }

            AlertDialog(
                onDismissRequest = { showAddEditRefDialog = false },
                title = {
                    Text(if (editingRef == null) "إضافة مرجع إضافي جديد 📚" else "تعديل المرجع الإضافي ✏️", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = titleInput,
                            onValueChange = { titleInput = it },
                            label = { Text("عنوان المرجع (مثال: الكتاب المقترح)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        Text("نوع المرجع:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        val typesList = listOf("PDF", "Word", "Excel", "PowerPoint", "رابط", "صورة", "فيديو", "ملف آخر")
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            typesList.take(4).forEach { tp ->
                                FilterChip(
                                    selected = selectedTypeInDialog == tp,
                                    onClick = { selectedTypeInDialog = tp },
                                    label = { Text(tp, fontSize = 9.5.sp) },
                                    shape = RoundedCornerShape(6.dp)
                                )
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            typesList.drop(4).forEach { tp ->
                                FilterChip(
                                    selected = selectedTypeInDialog == tp,
                                    onClick = { selectedTypeInDialog = tp },
                                    label = { Text(tp, fontSize = 9.5.sp) },
                                    shape = RoundedCornerShape(6.dp)
                                )
                            }
                        }

                        if (selectedTypeInDialog == "رابط") {
                            OutlinedTextField(
                                value = urlInputInDialog,
                                onValueChange = { urlInputInDialog = it },
                                label = { Text("رابط الموقع / المرجع الإلكتروني") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                        } else {
                            Text("ملف المرجع المرفق:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { selectRefFileLauncher.launch("*/*") },
                                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("رفع ملف 📎", fontSize = 10.sp)
                                }

                                Button(
                                    onClick = { showExistingFilesDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.FolderSpecial, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("من المجلد 📂", fontSize = 10.sp)
                                }
                            }

                            if (tempRefName.isNotBlank()) {
                                Text("الملف المرفق: $tempRefName", fontSize = 10.5.sp, color = DawamiNavy, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (titleInput.isNotBlank()) {
                                val pathOrUrl = if (selectedTypeInDialog == "رابط") urlInputInDialog.trim() else tempRefPath
                                val fName = if (selectedTypeInDialog == "رابط") "" else tempRefName

                                if (editingRef == null) {
                                    viewModel.insertSubjectReference(
                                        SubjectReference(
                                            subjectName = selectedSubjectForRef ?: "",
                                            title = titleInput.trim(),
                                            type = selectedTypeInDialog,
                                            urlOrPath = pathOrUrl,
                                            fileName = fName,
                                            department = departmentVal,
                                            diploma = diplomaVal
                                        )
                                    )
                                    Toast.makeText(context, "تم حفظ وإضافة المرجع بنجاح 👍", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.updateSubjectReference(
                                        editingRef!!.copy(
                                            title = titleInput.trim(),
                                            type = selectedTypeInDialog,
                                            urlOrPath = pathOrUrl,
                                            fileName = fName,
                                            department = departmentVal,
                                            diploma = diplomaVal
                                        )
                                    )
                                    Toast.makeText(context, "تم تحديث المرجع بنجاح 👍", Toast.LENGTH_SHORT).show()
                                }
                                showAddEditRefDialog = false
                            } else {
                                Toast.makeText(context, "الرجاء كتابة عنوان المرجع", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(if (editingRef == null) "حفظ المرجع" else "تحديث البيانات", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddEditRefDialog = false }) {
                        Text("إلغاء", fontWeight = FontWeight.Bold, color = Color.Gray)
                    }
                }
            )
        }

        // Choose existing files inner dialog
        if (showExistingFilesDialog) {
            val existingFiles = getFilesInSubFolder(context, isReference = true, baseDirUriString = trainerBaseDirUri)
            AlertDialog(
                onDismissRequest = { showExistingFilesDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(imageVector = Icons.Default.FolderSpecial, contentDescription = null, tint = DawamiTeal)
                        Text("ملفات تم التعرف عليها بالمجلد 📂", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    if (existingFiles.isEmpty()) {
                        Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            Text("لا توجد ملفات في مجلد المراجع حالياً.\n(انسخ ملفاتك إلى مجلد references يدوياً)", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(existingFiles) { (filePath, fName) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                                        .clickable {
                                            tempRefPath = filePath
                                            tempRefName = fName
                                            showExistingFilesDialog = false
                                            Toast.makeText(context, "تم تحديد الملف: $fName", Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.FilePresent, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
                                    Text(text = fName, fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showExistingFilesDialog = false }) {
                        Text("إغلاق", fontWeight = FontWeight.Bold, color = DawamiNavy)
                    }
                }
            )
        }
    }
}
