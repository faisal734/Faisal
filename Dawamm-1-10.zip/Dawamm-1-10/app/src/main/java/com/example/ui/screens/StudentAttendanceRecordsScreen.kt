package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.entity.Attendance
import com.example.data.entity.Course
import com.example.data.entity.Student
import com.example.data.entity.StudentAttendance
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentViolation
import com.example.data.entity.Subject
import com.example.data.entity.TrainerTransaction
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.ui.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.utils.AudioPlayerHelper
import androidx.compose.foundation.layout.ExperimentalLayoutApi


// ---------------- STUDENT ATTENDANCE SCREEN ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CourseSubjectStatusDialog(
    viewModel: MainViewModel,
    course: Course,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val dbCourseSubjects by viewModel.dbCourseSubjects.collectAsState()
    val dbAllStudentAttendance by viewModel.dbAllStudentAttendance.collectAsState()

    var stats by remember { mutableStateOf<List<com.example.data.entity.CourseSubjectStat>>(emptyList()) }
    var refreshTrigger by remember { mutableStateOf(0) }
    var isRefreshing by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(dbCourseSubjects, dbAllStudentAttendance, course.id, refreshTrigger) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            stats = viewModel.getCourseSubjectStats(course.id)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Analytics, contentDescription = null, tint = DawamiNavy)
                    Column {
                        Text(
                            text = "إحصائيات وحالة تدريس المواد 📊",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = DawamiNavy
                        )
                        Text(
                            text = "الدورة: ${course.name}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DawamiTeal.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(enabled = !isRefreshing) {
                            isRefreshing = true
                            refreshTrigger++
                            coroutineScope.launch {
                                kotlinx.coroutines.delay(300)
                                isRefreshing = false
                                Toast.makeText(context, "تم تحديث إحصائيات تدريس المواد بنجاح 🔄", Toast.LENGTH_SHORT).show()
                            }
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (isRefreshing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(13.dp),
                                strokeWidth = 1.8.dp,
                                color = DawamiTeal
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث",
                                tint = DawamiTeal,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = "تحديث",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = DawamiTeal
                        )
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = Color(0xFFF1F5F9),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "💡 المادة المكتملة أو المؤجلة تختفي تلقائياً من قائمة التحضير المباشر ليتسنى لك بدء المادة الجديدة غداً، ويمكن إظهارها بأي وقت عند إجراء الامتحان.",
                        fontSize = 10.5.sp,
                        color = Color(0xFF334155),
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }

                if (stats.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لا توجد مواد مخصصة لهذه الدورة بعد.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    stats.forEach { stat ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = stat.subjectName,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiNavy
                                    )

                                    val (badgeBg, badgeFg, badgeText) = when (stat.status) {
                                        "مكتملة التدريس" -> Triple(Color(0xFFDCFCE7), Color(0xFF15803D), "مكتملة التدريس 🏁")
                                        "في انتظار الاختبار", "مؤجلة الاختبار" -> Triple(Color(0xFFFEF3C7), Color(0xFFB45309), "في انتظار الاختبار ⏳")
                                        "مكتملة بالكامل" -> Triple(Color(0xFFCCFBF1), Color(0xFF0F766E), "مكتملة بالكامل ✅")
                                        else -> Triple(Color(0xFFDBEAFE), Color(0xFF1D4ED8), "قيد التدريس 📖")
                                    }

                                    Surface(color = badgeBg, shape = RoundedCornerShape(6.dp)) {
                                        Text(
                                            text = badgeText,
                                            color = badgeFg,
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = DawamiNavy.copy(alpha = 0.08f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "تم تدريسها: ${stat.taughtDaysCount} أيام",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }

                                    if (stat.firstTaughtDate.isNotEmpty()) {
                                        Text(
                                            text = "من ${stat.firstTaughtDate} إلى ${stat.lastTaughtDate}",
                                            fontSize = 9.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                // Status Action Chips
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (stat.status != "مكتملة التدريس") {
                                        AssistChip(
                                            onClick = {
                                                viewModel.updateCourseSubjectStatus(course.id, stat.subjectId, "مكتملة التدريس")
                                                Toast.makeText(context, "تم تحديد (${stat.subjectName}) كمكتملة التدريس 🏁", Toast.LENGTH_SHORT).show()
                                            },
                                            label = { Text("إكمال التدريس 🏁", fontSize = 9.5.sp) },
                                            colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFFDCFCE7), labelColor = Color(0xFF15803D))
                                        )
                                    }

                                    if (stat.status != "في انتظار الاختبار") {
                                        AssistChip(
                                            onClick = {
                                                viewModel.updateCourseSubjectStatus(course.id, stat.subjectId, "في انتظار الاختبار")
                                                Toast.makeText(context, "تم تحديد (${stat.subjectName}) في انتظار الاختبار ⏳", Toast.LENGTH_SHORT).show()
                                            },
                                            label = { Text("تأجيل الاختبار ⏳", fontSize = 9.5.sp) },
                                            colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFFFEF3C7), labelColor = Color(0xFFB45309))
                                        )
                                    }

                                    if (stat.status != "قيد التدريس") {
                                        AssistChip(
                                            onClick = {
                                                viewModel.updateCourseSubjectStatus(course.id, stat.subjectId, "قيد التدريس")
                                                Toast.makeText(context, "تمت إعادة (${stat.subjectName}) إلى قيد التدريس 🔄", Toast.LENGTH_SHORT).show()
                                            },
                                            label = { Text("قيد التدريس 🔄", fontSize = 9.5.sp) },
                                            colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFFDBEAFE), labelColor = Color(0xFF1D4ED8))
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
            confirmButton = {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("إغلاق")
                }
            }
        )
    }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun StudentAttendanceRecordsScreen(
    viewModel: MainViewModel,
    attendanceViewModel: AttendanceViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    showMainLayout: Boolean = true
) {
    val dbCourses by viewModel.dbCourses.collectAsState()
    val showCompletedCourses by viewModel.showCompletedCoursesInDropdowns.collectAsState()
    val dbAllStudents by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val selectedCourse by viewModel.selectedCourseForStudentAttendance.collectAsState()
    val attendanceDate by viewModel.studentAttendanceDateInput.collectAsState()
    val attendanceDay by viewModel.studentAttendanceDayInput.collectAsState()
    val studentAttendanceList by viewModel.studentAttendanceList.collectAsState()
    val dailyNoteText by viewModel.dailyCourseNoteInput.collectAsState()
    val sharedTimeInput by viewModel.studentAttendanceTimeInput.collectAsState()
    val studentCheckInTimeInput by viewModel.studentCheckInTimeInput.collectAsState()
    val studentCheckOutTimeInput by viewModel.studentCheckOutTimeInput.collectAsState()
    val allSubjects by viewModel.dbSubjects.collectAsState()
    val dbCourseSubjects by viewModel.dbCourseSubjects.collectAsState()
    val studentAttendanceSelectedSubject by viewModel.studentAttendanceSubjectInput.collectAsState()

    val isCourseEndedForDate = remember(selectedCourse, attendanceDate) {
        if (selectedCourse == null) false
        else {
            val isPastEndDate = selectedCourse?.endDate?.isNotBlank() == true && attendanceDate > selectedCourse!!.endDate
            val isCompletedAndPastOrSame = selectedCourse?.isCompleted == true && (selectedCourse?.endDate.isNullOrBlank() || attendanceDate >= selectedCourse!!.endDate)
            isPastEndDate || isCompletedAndPastOrSame
        }
    }

    var isCourseDropdownExpanded by remember { mutableStateOf(false) }
    var showSubjectStatusDialog by remember { mutableStateOf(false) }
    var showCompletedSubjectsInAttendance by remember { mutableStateOf(false) }
    var isEditableInPastStudents by remember { mutableStateOf(false) }


    // Dialog edit state
    var selectedRecordForDialogEdit by remember { mutableStateOf<StudentAttendance?>(null) }
    var dialogStatus by remember { mutableStateOf("حضور") }
    var dialogCheckIn by remember { mutableStateOf("") }
    var dialogCheckOut by remember { mutableStateOf("") }
    var dialogBreakStartTime by remember { mutableStateOf("") }
    var dialogBreakReturnTime by remember { mutableStateOf("") }


    var pendingCourseTimeChoiceDialog by remember { mutableStateOf<CourseTimeChoiceData?>(null) }
    var pendingCheckInNowFeedbackDialog by remember { mutableStateOf<CheckInNowFeedbackData?>(null) }
    var showStudentEditConfirmDialog by remember { mutableStateOf(false) }
    var showStudentCheckOutResultDialog by remember { mutableStateOf<Pair<Int, List<String>>?>(null) }
    var showTrainerNotCheckedOutDialog by remember { mutableStateOf(false) }

    // --- New Unified Student Dialog States ---
    var showStudentUnifiedDialog by remember { mutableStateOf(false) }
    var studentUnifiedDialogMode by remember { mutableStateOf(StudentConfirmType.CHECK_IN) }
    var studentUnifiedTargetIds by remember { mutableStateOf<Set<Int>>(emptySet()) }

    var showBreakDurationDialog by remember { mutableStateOf(false) }
    var breakDurationInput by remember { mutableStateOf("15") }
    var studentIdForBreakDialog by remember { mutableStateOf<Int?>(null) }

    val context = LocalContext.current
    var expandedStudentId by remember { mutableStateOf<Int?>(null) }
    var isHeaderExpanded by remember { mutableStateOf(false) }
    var selectedStudentIds by remember { mutableStateOf(setOf<Int>()) }
    var isCompactSelectionMode by remember { mutableStateOf(false) }

    var showWhatsAppChoiceDialog by remember { mutableStateOf(false) }
    var shareMessageText by remember { mutableStateOf("") }

    var isBatchSharing by remember { mutableStateOf(false) }
    var batchStudentsToShare by remember { mutableStateOf(listOf<StudentBatchData>()) }
    var currentBatchIndex by remember { mutableStateOf(0) }

    var studentAttendanceToDelete by remember { mutableStateOf<StudentAttendance?>(null) }
    var showDeleteStudentAttendanceConfirmDialog by remember { mutableStateOf(false) }
    var showSelectedStudentsResetDialog by remember { mutableStateOf(false) }
    var studentCardActionConfirmDialog by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }

    val dbAttendance by (attendanceViewModel?.allAttendance ?: viewModel.dbAttendance).collectAsState()
    val dbAllStudentAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()
    val maxCumulativeDelayVal by viewModel.maxCumulativeDelay.collectAsState()
    val courseSubjectStats = remember(selectedCourse, dbAllStudentAttendance) {
        if (selectedCourse != null) viewModel.getCourseSubjectStats(selectedCourse!!.id) else emptyList()
    }
    val currentSubjectStat = remember(courseSubjectStats, studentAttendanceSelectedSubject) {
        courseSubjectStats.find { it.subjectName.trim().equals(studentAttendanceSelectedSubject.trim(), ignoreCase = true) }
    }

    val todayStr = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()) }
    val isStudentFormEnabled = (attendanceDate == todayStr || isEditableInPastStudents)
    
    var recordedStudentDates by remember { mutableStateOf(emptyList<String>()) }
    var studentStatsMap by remember { mutableStateOf(emptyMap<Int, Pair<Int, Int>>()) }

    LaunchedEffect(dbAllStudentAttendance, selectedCourse, dbAttendance) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            val courseId = selectedCourse?.id
            if (courseId == null) {
                recordedStudentDates = emptyList()
                studentStatsMap = emptyMap()
            } else {
                val teacherDates = dbAttendance.filter { it.courseId == courseId }.map { it.date }.toSet()
                val records = dbAllStudentAttendance.filter { it.courseId == courseId && it.date in teacherDates }
                recordedStudentDates = teacherDates.sorted()
                
                val map = mutableMapOf<Int, Pair<Int, Int>>()
                records.groupBy { it.studentId }.forEach { (studentId, studentRecords) ->
                    val totalDelay = studentRecords.sumOf { it.checkInDelayMinutes }
                    val totalAbsences = studentRecords.count { it.status == "غياب" }
                    map[studentId] = Pair(totalDelay, totalAbsences)
                }
                studentStatsMap = map
            }
        }
    }

    var showTrainerNotRecordedDialog by remember { mutableStateOf(false) }
    var showTrainerAbsenceWarningDialog by remember { mutableStateOf(false) }
    var trainerAbsenceStatusForWarning by remember { mutableStateOf("") }
    var onConfirmTrainerAbsenceWarning by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showBulkFunnyPenaltyDialog by remember { mutableStateOf(false) }

    val trainerRecordForDay = dbAttendance.find { it.courseId == selectedCourse?.id && it.date == attendanceDate }
    val trainerStatus = trainerRecordForDay?.status
    val validTrainerStatuses = remember { listOf("حضور", "غياب", "إجازة", "مستأذن") }
    val isTrainerMovementRecorded = trainerRecordForDay != null && (trainerStatus in validTrainerStatuses)

    val checkTrainerStatusAndRun: (String, () -> Unit) -> Unit = { newStatus, action ->
        if (!isTrainerMovementRecorded) {
            showTrainerNotRecordedDialog = true
        } else if (newStatus == "حضور" && (trainerStatus == "غياب" || trainerStatus == "إجازة")) {
            trainerAbsenceStatusForWarning = if (trainerStatus == "غياب") "غياب" else "إجازة"
            onConfirmTrainerAbsenceWarning = action
            showTrainerAbsenceWarningDialog = true
        } else {
            action()
        }
    }

    val onShareReportClick = {
        if (selectedCourse == null) {
            Toast.makeText(context, "الرجاء اختيار الدورة التدريبية أولاً", Toast.LENGTH_SHORT).show()
        } else if (studentAttendanceList.isEmpty()) {
            Toast.makeText(context, "لا يوجد طلاب مسجلون في هذه الدورة لتجهيز التقرير", Toast.LENGTH_SHORT).show()
        } else {
            val courseTitle = selectedCourse?.name ?: ""
            val dateText = "$attendanceDate ($attendanceDay)"
            val institute = viewModel.instituteName.value.ifEmpty { "معهد ايلازون للتدريب" }
            val trainerName = viewModel.loggedInUser.value.ifEmpty { 
                selectedCourse?.trainerName?.ifEmpty { "المدرب / الأستاذ" } ?: "المدرب / الأستاذ" 
            }

            // Classification of students
            val disciplinedPresent = mutableListOf<StudentAttendance>()
            val undisciplinedPresent = mutableListOf<Triple<StudentAttendance, Int, Int>>() // att, delay, earlyDeparture
            val absentStudents = mutableListOf<StudentAttendance>()
            val excusedStudents = mutableListOf<StudentAttendance>()
            val leaveStudents = mutableListOf<StudentAttendance>()
            val notRecordedStudents = mutableListOf<StudentAttendance>()

            studentAttendanceList.forEach { att ->
                when (att.status) {
                    "حضور" -> {
                        val isLate = att.checkInDelayMinutes > 0
                        val isEarly = att.checkOutDifferenceMinutes < 0
                        if (!isLate && !isEarly) {
                            disciplinedPresent.add(att)
                        } else {
                            val delayMins = if (isLate) att.checkInDelayMinutes else 0
                            val earlyMins = if (isEarly) -att.checkOutDifferenceMinutes else 0
                            undisciplinedPresent.add(Triple(att, delayMins, earlyMins))
                        }
                    }
                    "غياب" -> absentStudents.add(att)
                    "مستأذن" -> excusedStudents.add(att)
                    "إجازة" -> leaveStudents.add(att)
                    else -> notRecordedStudents.add(att)
                }
            }

            val totalCount = studentAttendanceList.size
            val disciplinedCount = disciplinedPresent.size
            val undisciplinedCount = undisciplinedPresent.size
            val absentCount = absentStudents.size
            val excusedCount = excusedStudents.size
            val leaveCount = leaveStudents.size
            val notRegisteredCount = notRecordedStudents.size

            val sb = StringBuilder()
            sb.append("📋 *التقرير اليومي لحالة طلاب الدورة*\n")
            sb.append("----------------------------------------\n")
            sb.append("🏫 *المعهد:* $institute\n")
            sb.append("👨‍🏫 *المدرب / الأستاذ:* $trainerName\n")
            sb.append("📚 *الدورة:* $courseTitle\n")
            val subjectName = trainerRecordForDay?.subjectName?.ifBlank { viewModel.studentAttendanceSubjectInput.value } ?: viewModel.studentAttendanceSubjectInput.value
            if (subjectName.isNotBlank()) {
                sb.append("📖 *المادة:* $subjectName\n")
            }
            sb.append("📅 *التاريخ:* $dateText\n")
            val teacherDailyNoteHeader = if (dailyNoteText.isNotBlank()) dailyNoteText else (studentAttendanceList.firstOrNull { it.courseDailyNote.isNotBlank() }?.courseDailyNote ?: "")
            if (teacherDailyNoteHeader.isNotEmpty()) {
                sb.append("📝 *ملاحظة الحركة اليومية:* $teacherDailyNoteHeader\n")
            }
            sb.append("----------------------------------------\n")
            sb.append("📈 *إحصائية اليوم:*\n")
            val statParts = mutableListOf<String>()
            statParts.add("إجمالي الطلاب: ($totalCount)")
            statParts.add("منضبط: ($disciplinedCount)")
            if (undisciplinedCount > 0 || (absentCount == 0 && excusedCount == 0)) {
                statParts.add("غير منضبط: ($undisciplinedCount)")
            }
            statParts.add("غياب: ($absentCount)")
            statParts.add("استئذان: ($excusedCount)")
            if (leaveCount > 0) {
                statParts.add("إجازة: ($leaveCount)")
            }
            if (notRegisteredCount > 0) {
                statParts.add("لم يسجل: ($notRegisteredCount)")
            }
            sb.append(statParts.joinToString(" | "))
            sb.append("\n----------------------------------------\n\n")

            // 1. حضور بانضباط
            if (disciplinedPresent.isNotEmpty()) {
                sb.append("🌟 *حضور بانضباط:*\n")
                disciplinedPresent.forEachIndexed { index, att ->
                    sb.append("${index + 1}. ${att.studentName}\n")
                    if (att.studentNote.isNotBlank()) {
                        sb.append("   💬 _${att.studentNote}_\n")
                    }
                }
                sb.append("\n")
            }

            // 2. حضور غير منضبط
            if (undisciplinedPresent.isNotEmpty()) {
                sb.append("⚠️ *حضور غير منضبط:*\n")
                undisciplinedPresent.forEachIndexed { index, (att, delayMins, earlyMins) ->
                    val detailParts = mutableListOf<String>()
                    if (delayMins > 0) detailParts.add("تأخر $delayMins د")
                    if (earlyMins > 0) detailParts.add("انصراف مبكر $earlyMins د")
                    val detailStr = if (detailParts.isNotEmpty()) " (${detailParts.joinToString(" • ")})" else ""
                    sb.append("${index + 1}. ${att.studentName}$detailStr\n")
                    if (att.studentNote.isNotBlank()) {
                        sb.append("   💬 _${att.studentNote}_\n")
                    }
                }
                sb.append("\n")
            }

            // 3. الغياب
            if (absentStudents.isNotEmpty()) {
                sb.append("❌ *الغياب:*\n")
                absentStudents.forEachIndexed { index, att ->
                    sb.append("${index + 1}. ${att.studentName}\n")
                    if (att.studentNote.isNotBlank()) {
                        sb.append("   💬 _${att.studentNote}_\n")
                    }
                }
                sb.append("\n")
            }

            // 4. الاستئذان
            if (excusedStudents.isNotEmpty()) {
                sb.append("📝 *الاستئذان:*\n")
                excusedStudents.forEachIndexed { index, att ->
                    sb.append("${index + 1}. ${att.studentName}\n")
                    if (att.studentNote.isNotBlank()) {
                        sb.append("   💬 _${att.studentNote}_\n")
                    }
                }
                sb.append("\n")
            }

            // 5. الإجازات (إن وجدت)
            if (leaveStudents.isNotEmpty()) {
                sb.append("🟡 *الإجازات المعتمدة:*\n")
                leaveStudents.forEachIndexed { index, att ->
                    sb.append("${index + 1}. ${att.studentName}\n")
                    if (att.studentNote.isNotBlank()) {
                        sb.append("   💬 _${att.studentNote}_\n")
                    }
                }
                sb.append("\n")
            }

            // 6. لم تسجل حركتهم (إن وجدوا)
            if (notRecordedStudents.isNotEmpty()) {
                sb.append("⚪ *لم تسجل حركتهم بعد:*\n")
                notRecordedStudents.forEachIndexed { index, att ->
                    sb.append("${index + 1}. ${att.studentName}\n")
                    if (att.studentNote.isNotBlank()) {
                        sb.append("   💬 _${att.studentNote}_\n")
                    }
                }
                sb.append("\n")
            }

            // Add lesson topics covered today if available
            selectedCourse?.let { c ->
                if (viewModel.includeLessonTopicsInReport.value) {
                    val lessonTopics = viewModel.dbLessonTopics.value
                    val sessionTopics = viewModel.dbLessonSessionTopics.value
                    val subjects = viewModel.dbSubjects.value
                    val todaySessionTopics = sessionTopics.filter { st ->
                        if (st.courseId != c.id || st.date != attendanceDate) false
                        else {
                            val topic = lessonTopics.find { it.id == st.topicId }
                            topic != null && topic.level <= 2
                        }
                    }

                    if (todaySessionTopics.isNotEmpty()) {
                        sb.append("----------------------------------------\n")
                        sb.append("📚 *النقاط والدروس المشروحة اليوم (مستويين):*\n")
                        todaySessionTopics.forEachIndexed { idx, st ->
                            val topic = lessonTopics.find { it.id == st.topicId }
                            val subject = subjects.find { it.id == (topic?.subjectId ?: st.subjectId) }
                            val subjectTag = if (subject != null) " [📖 ${subject.name}]" else ""
                            val statusStr = if (st.isCompleted) "🟢 تم الشرح (${st.completedAt})" else "⏳ قيد الشرح"
                            val levelTag = if (topic?.level == 1) "(رئيسي)" else "(فرعي)"
                            sb.append("${idx + 1}. *${topic?.title ?: "موضوع"}*$subjectTag $levelTag - $statusStr\n")
                            if (st.note.isNotEmpty()) {
                                sb.append("   ✍️ *ملاحظة:* ${st.note}\n")
                            }
                        }

                        val courseSubjectIds = viewModel.dbCourseSubjects.value.filter { it.courseId == c.id }.map { it.subjectId }
                        val totalCourseTopics = lessonTopics.count {
                            (it.subjectId in courseSubjectIds || it.courseId == c.id) && it.level <= 2
                        }
                        val completedCourseTopics = sessionTopics.count { st ->
                            val t = lessonTopics.find { it.id == st.topicId }
                            st.courseId == c.id && st.isCompleted && t != null && t.level <= 2
                        }
                        if (totalCourseTopics > 0) {
                            val progressPct = (completedCourseTopics * 100) / totalCourseTopics
                            sb.append("📊 *إنجاز المقررات لمستوى الدورة:* $progressPct% ($completedCourseTopics من $totalCourseTopics موضوع)\n")
                        }
                    }
                }
            }

            sb.append("----------------------------------------\n")
            sb.append("شاكرين لكم حسن المتابعة والإشراف 🌹\n")
            val selectedCourseOpt = selectedCourse
            val deptName = selectedCourseOpt?.departmentName?.ifBlank { "قسم الحاسوب وتقنية المعلومات" } ?: "قسم الحاسوب وتقنية المعلومات"
            sb.append("القسم: $deptName\n")
            sb.append("المعهد: $institute")
            
            shareMessageText = sb.toString()
            showWhatsAppChoiceDialog = true
        }
    }

    if (isBatchSharing) {
        BatchWhatsAppShareDialog(
            onDismiss = { isBatchSharing = false },
            batchList = batchStudentsToShare,
            currentIndex = currentBatchIndex,
            onIndexChanged = { currentBatchIndex = it },
            context = context
        )
    }

    // --- Student Unified Confirmation Dialog ---
    if (showStudentUnifiedDialog) {
        StudentUnifiedAttendanceDialog(
            viewModel = viewModel,
            confirmActionType = studentUnifiedDialogMode,
            targetStudentIds = studentUnifiedTargetIds,
            onConfirm = { time, trainerSync ->
                showStudentUnifiedDialog = false
                val selectedAtts = studentAttendanceList.filter { it.studentId in studentUnifiedTargetIds }
                
                when (studentUnifiedDialogMode) {
                    StudentConfirmType.CHECK_IN -> {
                        selectedAtts.forEach { att ->
                            viewModel.registerStudentCheckIn(att, time)
                        }
                        AudioPlayerHelper.playAudioOrSpeak(context, "student_checkin_success", "تم تسجيل حضور الطلاب بنجاح", viewModel.voiceGender.value)
                        Toast.makeText(context, "📥 تم تسجيل الحضور لـ (${selectedAtts.size}) طلاب بالوقت ($time)", Toast.LENGTH_SHORT).show()
                    }
                    StudentConfirmType.CHECK_OUT -> {
                        selectedAtts.forEach { att ->
                            viewModel.registerStudentCheckOut(att, time)
                        }
                        if (trainerSync) {
                            viewModel.attendanceCheckOutInput.value = time
                            viewModel.onAttendanceTimeChanged()
                            viewModel.recordCheckOutAndComplete()
                            Toast.makeText(context, "⏱️ تم تسجيل انصراف المدرب أيضاً", Toast.LENGTH_SHORT).show()
                        }
                        AudioPlayerHelper.playAudioOrSpeak(context, "student_checkout_success", "تم تسجيل انصراف الطلاب بنجاح", viewModel.voiceGender.value)
                        Toast.makeText(context, "📤 تم تسجيل الانصراف لـ (${selectedAtts.size}) طلاب بالوقت ($time)", Toast.LENGTH_SHORT).show()
                    }
                    StudentConfirmType.ABSENT -> {
                        selectedAtts.forEach { att ->
                            viewModel.registerStudentAbsent(att)
                        }
                        Toast.makeText(context, "❌ تم تسجيل غياب لـ (${selectedAtts.size}) طلاب", Toast.LENGTH_SHORT).show()
                    }
                    StudentConfirmType.EXCUSED -> {
                        selectedAtts.forEach { att ->
                            viewModel.registerStudentExcused(att)
                        }
                        Toast.makeText(context, "🔵 تم تسجيل استئذان لـ (${selectedAtts.size}) طلاب", Toast.LENGTH_SHORT).show()
                    }
                    StudentConfirmType.LEAVE -> {
                        selectedAtts.forEach { att ->
                            viewModel.registerStudentLeave(att)
                        }
                        Toast.makeText(context, "🟡 تم تسجيل إجازة لـ (${selectedAtts.size}) طلاب", Toast.LENGTH_SHORT).show()
                    }
                    StudentConfirmType.RESET -> {
                        selectedAtts.forEach { att ->
                            viewModel.resetIndividualAll(att)
                        }
                        Toast.makeText(context, "🔄 تم إعادة تعيين الحركة لـ (${selectedAtts.size}) طلاب", Toast.LENGTH_SHORT).show()
                    }
                }
                selectedStudentIds = emptySet()
            },
            onDismiss = { showStudentUnifiedDialog = false }
        )
    }

    if (showWhatsAppChoiceDialog) {
        AlertDialog(
            onDismissRequest = { showWhatsAppChoiceDialog = false },
            title = {
                Text(
                    text = "مشاركة عبر الواتساب",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Text(
                    text = "اختر تطبيق الواتساب المفضل لإرسال الحركة اليومية للطالب (ستقوم بتحديد جهة الاتصال يدويًا داخل التطبيق):",
                    fontSize = 11.sp
                )
            },
            confirmButton = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            showWhatsAppChoiceDialog = false
                            try {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, shareMessageText)
                                    setPackage("com.whatsapp")
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "تطبيق واتساب العادي غير مثبت، جرب واتساب الأعمال أو مشاركة عامة", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("واتساب العادي (WhatsApp)", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            showWhatsAppChoiceDialog = false
                            try {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, shareMessageText)
                                    setPackage("com.whatsapp.w4b")
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "تطبيق واتساب الأعمال غير مثبت على جهازك", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("واتساب الأعمال (WhatsApp Business)", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            showWhatsAppChoiceDialog = false
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, shareMessageText)
                            }
                            context.startActivity(Intent.createChooser(intent, "مشاركة الحركة عبر..."))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("مشاركة عامة وتطبيقات أخرى 📤", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { showWhatsAppChoiceDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إلغاء")
                    }
                }
            }
        )
    }

    if (selectedRecordForDialogEdit != null) {
        val record = selectedRecordForDialogEdit!!
        AlertDialog(
            onDismissRequest = { selectedRecordForDialogEdit = null },
            title = {
                Text(
                    text = "تعديل الحركة اليومية للطالب 📝",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "الطالب: ${record.studentName}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    
                    Text("الحالة اليومية:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("حضور", "غياب", "مستأذن", "إجازة").forEach { status ->
                            val isSelected = dialogStatus == status
                            Button(
                                onClick = { dialogStatus = status },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) {
                                        when (status) {
                                            "حضور" -> Color(0xFF22C55E)
                                            "غياب" -> Color(0xFFEF4444)
                                            "مستأذن" -> Color(0xFF0284C7)
                                            else -> Color(0xFFF59E0B)
                                        }
                                    } else Color(0xFFF1F5F9)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = status,
                                    color = if (isSelected) Color.White else Color.DarkGray,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (dialogStatus == "حضور") {
                        val showTimePicker = { initialTime: String, onTimeSelected: (String) -> Unit ->
                            var initHour = 8
                            var initMinute = 0
                            if (initialTime.contains(":")) {
                                val parts = initialTime.split(":")
                                if (parts.size == 2) {
                                    initHour = parts[0].toIntOrNull() ?: 8
                                    initMinute = parts[1].toIntOrNull() ?: 0
                                }
                            }
                            android.app.TimePickerDialog(
                                context,
                                { _, hour, minute ->
                                    onTimeSelected(String.format(java.util.Locale.US, "%02d:%02d", hour, minute))
                                },
                                initHour,
                                initMinute,
                                true
                            ).show()
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showTimePicker(dialogCheckIn) { dialogCheckIn = it } }
                        ) {
                            OutlinedTextField(
                                value = dialogCheckIn,
                                onValueChange = {},
                                readOnly = true,
                                enabled = false,
                                label = { Text("وقت الدخول", fontSize = 11.sp) },
                                trailingIcon = {
                                    Icon(Icons.Default.AccessTime, contentDescription = "اختر الوقت", tint = DawamiNavy)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                    disabledBorderColor = MaterialTheme.colorScheme.outline,
                                    disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledTrailingIconColor = DawamiNavy
                                ),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = TextStyle(fontSize = 13.sp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showTimePicker(dialogCheckOut) { dialogCheckOut = it } }
                        ) {
                            OutlinedTextField(
                                value = dialogCheckOut,
                                onValueChange = {},
                                readOnly = true,
                                enabled = false,
                                label = { Text("وقت الانصراف", fontSize = 11.sp) },
                                trailingIcon = {
                                    Icon(Icons.Default.AccessTime, contentDescription = "اختر الوقت", tint = DawamiNavy)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                    disabledBorderColor = MaterialTheme.colorScheme.outline,
                                    disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledTrailingIconColor = DawamiNavy
                                ),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = TextStyle(fontSize = 13.sp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showTimePicker(dialogBreakStartTime) { dialogBreakStartTime = it } }
                        ) {
                            OutlinedTextField(
                                value = dialogBreakStartTime,
                                onValueChange = {},
                                readOnly = true,
                                enabled = false,
                                label = { Text("وقت خروج الاستراحة", fontSize = 11.sp) },
                                trailingIcon = {
                                    Icon(Icons.Default.AccessTime, contentDescription = "اختر الوقت", tint = DawamiNavy)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                    disabledBorderColor = MaterialTheme.colorScheme.outline,
                                    disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledTrailingIconColor = DawamiNavy
                                ),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = TextStyle(fontSize = 13.sp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showTimePicker(dialogBreakReturnTime) { dialogBreakReturnTime = it } }
                        ) {
                            OutlinedTextField(
                                value = dialogBreakReturnTime,
                                onValueChange = {},
                                readOnly = true,
                                enabled = false,
                                label = { Text("وقت العودة من الاستراحة", fontSize = 11.sp) },
                                trailingIcon = {
                                    Icon(Icons.Default.AccessTime, contentDescription = "اختر الوقت", tint = DawamiNavy)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                    disabledBorderColor = MaterialTheme.colorScheme.outline,
                                    disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledTrailingIconColor = DawamiNavy
                                ),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = TextStyle(fontSize = 13.sp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val original = record
                        val expectedReturn = if (dialogBreakStartTime.isNotEmpty() && original.breakDurationMinutes > 0) {
                            viewModel.addMinutesToTime(dialogBreakStartTime, original.breakDurationMinutes)
                        } else {
                            dialogBreakReturnTime
                        }
                        val breakDelay = if (dialogBreakReturnTime.isNotEmpty() && expectedReturn.isNotEmpty()) {
                            viewModel.calculateMinutesDifference(dialogBreakReturnTime, expectedReturn)
                        } else 0

                        val updated = original.copy(
                            status = dialogStatus,
                            actualCheckIn = if (dialogStatus == "حضور") dialogCheckIn else "",
                            actualCheckOut = if (dialogStatus == "حضور") dialogCheckOut else "",
                            breakStartTime = if (dialogStatus == "حضور") dialogBreakStartTime else "",
                            breakActualReturnTime = if (dialogStatus == "حضور") dialogBreakReturnTime else "",
                            breakDelayMinutes = if (dialogStatus == "حضور") breakDelay else 0,
                            isOnBreak = if (dialogBreakReturnTime.isNotEmpty()) false else (if (dialogBreakStartTime.isNotEmpty() && dialogBreakReturnTime.isEmpty()) true else original.isOnBreak)
                        )
                        viewModel.insertStudentAttendance(updated)
                        selectedRecordForDialogEdit = null
                        Toast.makeText(context, "تم تعديل الحركة بنجاح", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ التعديل")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { selectedRecordForDialogEdit = null }
                ) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showDeleteStudentAttendanceConfirmDialog && studentAttendanceToDelete != null) {
        val record = studentAttendanceToDelete!!
        com.example.ui.components.GranularResetDialog(
            title = "إعادة تعيين حركة الطالب (${record.studentName})",
            subtitle = "اختر نوع إعادة التعيين المطلوب لسجل الطالب لهذا اليوم:",
            onDismiss = { 
                showDeleteStudentAttendanceConfirmDialog = false
                studentAttendanceToDelete = null
            },
            onResetAttendanceOnly = {
                viewModel.resetIndividualAttendanceOnly(record)
                showDeleteStudentAttendanceConfirmDialog = false
                studentAttendanceToDelete = null
                Toast.makeText(context, "تم إعادة تعيين الحضور للطالب بنجاح", Toast.LENGTH_SHORT).show()
            },
            onResetDepartureOnly = {
                viewModel.resetIndividualDepartureOnly(record)
                showDeleteStudentAttendanceConfirmDialog = false
                studentAttendanceToDelete = null
                Toast.makeText(context, "تم إعادة تعيين الانصراف للطالب بنجاح", Toast.LENGTH_SHORT).show()
            },
            onResetAll = {
                viewModel.resetIndividualAll(record)
                showDeleteStudentAttendanceConfirmDialog = false
                studentAttendanceToDelete = null
                Toast.makeText(context, "تم إعادة تعيين كافة حركات الطالب بنجاح", Toast.LENGTH_SHORT).show()
            }
        )
    }

    val checkInCourseTimeWithCheck: (String, String, (String) -> Unit, (() -> Unit)?) -> Unit = { title, subtitle, onConfirmTime, onSameTimeAction ->
        val defaultTime = selectedCourse?.startTime?.ifEmpty { "08:00" } ?: "08:00"
        val inputTime = studentCheckInTimeInput.ifEmpty { defaultTime }
        if (inputTime != defaultTime) {
            pendingCourseTimeChoiceDialog = CourseTimeChoiceData(
                title = title,
                subtitle = subtitle,
                defaultCourseTime = defaultTime,
                toolTime = inputTime,
                onConfirm = onConfirmTime
            )
        } else {
            if (onSameTimeAction != null) {
                onSameTimeAction()
            } else {
                onConfirmTime(defaultTime)
            }
        }
    }

    val checkInNowWithFeedback: (String, String, (String) -> Unit) -> Unit = { title, subtitle, onConfirmTime ->
        val nowTimeStr = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date())
        val defaultTime = selectedCourse?.startTime?.ifEmpty { "08:00" } ?: "08:00"
        pendingCheckInNowFeedbackDialog = CheckInNowFeedbackData(
            title = title,
            subtitle = subtitle,
            actualTime = nowTimeStr,
            courseStartTime = defaultTime,
            onConfirm = onConfirmTime
        )
    }

    if (pendingCourseTimeChoiceDialog != null) {
        val data = pendingCourseTimeChoiceDialog!!
        var selectedChoice by remember(data) { mutableStateOf("COURSE_DEFAULT") }

        AlertDialog(
            onDismissRequest = { pendingCourseTimeChoiceDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        color = Color(0xFF0D9488).copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, tint = Color(0xFF0D9488), modifier = Modifier.size(20.dp))
                        }
                    }
                    Column {
                        Text(
                            text = data.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = DawamiNavy
                        )
                        if (data.subtitle.isNotEmpty()) {
                            Text(
                                text = data.subtitle,
                                fontSize = 9.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "تنبيه: الوقت في أداة الوقت يختلف عن توقيت بداية الدورة الرسمي. يرجى اختيار التوقيت المراد اعتماده:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Option 1: Course default start time
                    Surface(
                        color = if (selectedChoice == "COURSE_DEFAULT") DawamiNavy.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.5.dp, if (selectedChoice == "COURSE_DEFAULT") DawamiNavy else Color.LightGray.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedChoice = "COURSE_DEFAULT" }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            RadioButton(
                                selected = selectedChoice == "COURSE_DEFAULT",
                                onClick = { selectedChoice = "COURSE_DEFAULT" },
                                colors = RadioButtonDefaults.colors(selectedColor = DawamiNavy)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "وقت الدورة الافتراضي (من شاشة الدورات)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiNavy
                                )
                                Text(
                                    text = "التوقيت: ${formatTimeTo12HourArabic(data.defaultCourseTime)} (${data.defaultCourseTime})",
                                    fontSize = 10.sp,
                                    color = Color(0xFF0D9488),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    // Option 2: Time written in time tool
                    Surface(
                        color = if (selectedChoice == "TOOL_TIME") DawamiNavy.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.5.dp, if (selectedChoice == "TOOL_TIME") DawamiNavy else Color.LightGray.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedChoice = "TOOL_TIME" }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            RadioButton(
                                selected = selectedChoice == "TOOL_TIME",
                                onClick = { selectedChoice = "TOOL_TIME" },
                                colors = RadioButtonDefaults.colors(selectedColor = DawamiNavy)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "الوقت المكتوب في أداة الوقت",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiNavy
                                )
                                Text(
                                    text = "التوقيت: ${formatTimeTo12HourArabic(data.toolTime)} (${data.toolTime})",
                                    fontSize = 10.sp,
                                    color = Color(0xFFEA580C),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                val chosenTime = if (selectedChoice == "COURSE_DEFAULT") data.defaultCourseTime else data.toolTime
                Button(
                    onClick = {
                        val callback = data.onConfirm
                        pendingCourseTimeChoiceDialog = null
                        callback(chosenTime)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "تأكيد الاعتماد (${formatTimeTo12HourArabic(chosenTime)})",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { pendingCourseTimeChoiceDialog = null },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("إلغاء", fontSize = 11.sp)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    if (pendingCheckInNowFeedbackDialog != null) {
        val data = pendingCheckInNowFeedbackDialog!!
        val diffMinutes = remember(data.actualTime, data.courseStartTime) {
            calculateTimeDiffMinutes(data.actualTime, data.courseStartTime)
        }

        AlertDialog(
            onDismissRequest = { pendingCheckInNowFeedbackDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        color = Color(0xFF16A34A).copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(20.dp))
                        }
                    }
                    Column {
                        Text(
                            text = data.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = DawamiNavy
                        )
                        if (data.subtitle.isNotEmpty()) {
                            Text(
                                text = data.subtitle,
                                fontSize = 9.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Actual Time Card
                    Surface(
                        color = Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(24.dp))
                            Column {
                                Text(
                                    text = "الوقت الفعلي الحالي من الجهاز:",
                                    fontSize = 10.5.sp,
                                    color = Color(0xFF15803D),
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "${formatTimeTo12HourArabic(data.actualTime)} (${data.actualTime})",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14532D)
                                )
                            }
                        }
                    }

                    // Smart Feedback comparing to Course Start Time
                    Surface(
                        color = when {
                            diffMinutes > 0 -> Color(0xFFFFFBEB)
                            diffMinutes < 0 -> Color(0xFFEFF6FF)
                            else -> Color(0xFFF0FDF4)
                        },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, when {
                            diffMinutes > 0 -> Color(0xFFFCD34D)
                            diffMinutes < 0 -> Color(0xFF93C5FD)
                            else -> Color(0xFF86EFAC)
                        }),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = when {
                                        diffMinutes > 0 -> "⚠️ تقييم موعد الحضور: تأخير"
                                        diffMinutes < 0 -> "✨ تقييم موعد الحضور: مبكر"
                                        else -> "✅ تقييم موعد الحضور: في الموعد"
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        diffMinutes > 0 -> Color(0xFFB45309)
                                        diffMinutes < 0 -> Color(0xFF1D4ED8)
                                        else -> Color(0xFF15803D)
                                    }
                                )
                            }
                            Text(
                                text = when {
                                    diffMinutes > 0 -> "تأخير بمقدار ($diffMinutes) دقيقة عن موعد بداية الدورة المحدد (${formatTimeTo12HourArabic(data.courseStartTime)})."
                                    diffMinutes < 0 -> "حضور مبكر بمقدار (${-diffMinutes}) دقيقة قبل موعد بداية الدورة (${formatTimeTo12HourArabic(data.courseStartTime)})."
                                    else -> "حضور مطابق تماماً لتوقيت بداية الدورة الرسمي (${formatTimeTo12HourArabic(data.courseStartTime)})."
                                },
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val callback = data.onConfirm
                        val actTime = data.actualTime
                        pendingCheckInNowFeedbackDialog = null
                        callback(actTime)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "تأكيد الحضور (${formatTimeTo12HourArabic(data.actualTime)})",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { pendingCheckInNowFeedbackDialog = null },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("إلغاء", fontSize = 11.sp)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }





    if (showSelectedStudentsResetDialog) {
        val targetIds = selectedStudentIds
        com.example.ui.components.GranularResetDialog(
            title = "إعادة تعيين الحركة لعدد (${targetIds.size}) طلاب محددين ⚠️",
            subtitle = "حدد نوع إعادة التعيين للطلاب المحددين:",
            onDismiss = { showSelectedStudentsResetDialog = false },
            onResetAttendanceOnly = {
                showSelectedStudentsResetDialog = false
                viewModel.resetUnifiedAttendanceOnly(targetIds)
                selectedStudentIds = emptySet()
                Toast.makeText(context, "تم إعادة تعيين الحضور للطلاب المحددين بنجاح", Toast.LENGTH_SHORT).show()
            },
            onResetDepartureOnly = {
                showSelectedStudentsResetDialog = false
                viewModel.resetUnifiedDepartureOnly(targetIds)
                selectedStudentIds = emptySet()
                Toast.makeText(context, "تم إعادة تعيين الانصراف للطلاب المحددين بنجاح", Toast.LENGTH_SHORT).show()
            },
            onResetAll = {
                showSelectedStudentsResetDialog = false
                viewModel.resetUnifiedAll(targetIds)
                selectedStudentIds = emptySet()
                Toast.makeText(context, "تم إعادة تعيين كافة حركات الطلاب المحددين بنجاح", Toast.LENGTH_SHORT).show()
            }
        )
    }

    studentCardActionConfirmDialog?.let { (msg, action) ->
        AlertDialog(
            onDismissRequest = { studentCardActionConfirmDialog = null },
            title = {
                Text(
                    text = "تأكيد الإجراء المحدد ⚡",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Text(
                    text = msg,
                    fontSize = 11.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        studentCardActionConfirmDialog = null
                        action()
                        selectedStudentIds = emptySet()
                        Toast.makeText(context, "تم تنفيذ الإجراء بنجاح", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("تأكيد", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { studentCardActionConfirmDialog = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showTrainerNotRecordedDialog) {
        AlertDialog(
            onDismissRequest = { showTrainerNotRecordedDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color(0xFFD97706),
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "تسلسل العمليات مطلوب ⚠️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Text(
                    text = "يتطلب النظام وجود حالة (حضور أو غياب أو إجازة أو مستأذن) للمدرب المسجل في هذه الدورة (${selectedCourse?.name ?: ""}) أولاً قبل السماح ببدء تحضير الطلاب لضمان تسلسل العمليات.",
                    fontSize = 11.5.sp,
                    lineHeight = 17.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { showTrainerNotRecordedDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حسناً فهمت", color = Color.White)
                }
            }
        )
    }

    if (showTrainerAbsenceWarningDialog) {
        AlertDialog(
            onDismissRequest = {
                showTrainerAbsenceWarningDialog = false
                onConfirmTrainerAbsenceWarning = null
            },
            title = {
                Text(
                    text = "تنبيه حالة الأستاذ ⚠️",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Text(
                    text = "إن حالة الأستاذ اليوم في هذه الدورة هي (${trainerAbsenceStatusForWarning}). هل أنت متأكد من رغبتك في تسجيل حضور للطلاب والاستمرار؟",
                    fontSize = 11.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onConfirmTrainerAbsenceWarning?.invoke()
                        showTrainerAbsenceWarningDialog = false
                        onConfirmTrainerAbsenceWarning = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("نعم")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showTrainerAbsenceWarningDialog = false
                        onConfirmTrainerAbsenceWarning = null
                    }
                ) {
                    Text("لا")
                }
            }
        )
    }

    if (showBulkFunnyPenaltyDialog) {
        val absentOrDelayed = studentAttendanceList.filter { it.status == "غياب" || it.checkInDelayMinutes > 0 }
        AlertDialog(
            onDismissRequest = { showBulkFunnyPenaltyDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("🎭", fontSize = 20.sp)
                    Text(
                        text = "عقوبات فكاهية للغائبين والمتأخرين",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "سيتم تخصيص عقوبة فكاهية عشوائية لكل طالب غائب أو متأخر وإضافتها لملاحظته الفردية:",
                        fontSize = 11.sp
                    )

                    if (absentOrDelayed.isEmpty()) {
                        Text(
                            text = "✨ لا يوجد طلاب غائبون أو متأخرون حالياً! جميع الطلاب ملتزمون 🎉",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF16A34A)
                        )
                    } else {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "عدد الطلاب المشمولين بالعقوبة الفكاهية: ${absentOrDelayed.size} طالب",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF78350F),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                if (absentOrDelayed.isNotEmpty()) {
                    Button(
                        onClick = {
                            absentOrDelayed.forEach { att ->
                                val penalty = com.example.ui.components.FunnyPenaltyHelper.getRandomPenalty(context)
                                val updatedNote = if (att.studentNote.isBlank()) {
                                    "🎭 [العقوبة الفكاهية]: $penalty"
                                } else {
                                    "${att.studentNote} | 🎭 [العقوبة الفكاهية]: $penalty"
                                }
                                viewModel.insertStudentAttendance(att.copy(studentNote = updatedNote))
                            }
                            showBulkFunnyPenaltyDialog = false
                            Toast.makeText(context, "تم تطبيق العقوبات الفكاهية العشوائية على الجميع 🎭🎉", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                    ) {
                        Text("تطبيق للجميع 🎲", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showBulkFunnyPenaltyDialog = false }) {
                    Text("إلغاء", fontSize = 11.sp)
                }
            }
        )
    }

    if (showBreakDurationDialog) {
        var customStartTime by remember { 
            mutableStateOf(java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date())) 
        }
        val targetStudent = studentAttendanceList.find { it.studentId == studentIdForBreakDialog }
        val validTargets = if (studentIdForBreakDialog != null) {
            listOfNotNull(targetStudent)
        } else {
            studentAttendanceList.filter { it.studentId in selectedStudentIds && it.status == "حضور" && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() && !it.isOnBreak }
        }

        AlertDialog(
            onDismissRequest = { 
                showBreakDurationDialog = false 
                studentIdForBreakDialog = null
            },
            title = {
                Text(
                    text = if (targetStudent != null) "بدء استراحة للطالب: ${targetStudent.studentName} ☕" else "بدء استراحة جماعية لعدد (${validTargets.size}) طلاب ☕",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "اختر مدة الاستراحة ووقت البدء:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text("خيارات سريعة للمدة:", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("10", "15", "20", "30", "45", "60").forEach { dur ->
                            FilterChip(
                                selected = breakDurationInput == dur,
                                onClick = { breakDurationInput = dur },
                                label = { Text("$dur د", fontSize = 10.5.sp) },
                                modifier = Modifier.height(28.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = breakDurationInput,
                        onValueChange = { breakDurationInput = it.filter { char -> char.isDigit() } },
                        label = { Text("مدة الاستراحة (بالدقائق)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = customStartTime,
                        onValueChange = { customStartTime = it },
                        label = { Text("وقت بدء الاستراحة (HH:mm)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val duration = breakDurationInput.toIntOrNull() ?: 15
                        if (validTargets.isEmpty()) {
                            Toast.makeText(context, "عذراً، لا يوجد طلاب حاضرين مؤهلين لبدء الاستراحة! ⚠️", Toast.LENGTH_SHORT).show()
                        } else {
                            validTargets.forEach { att ->
                                viewModel.registerStudentBreakStart(att, duration, customStartTime)
                            }
                            val msg = if (targetStudent != null) {
                                "تم تسجيل خروج ${targetStudent.studentName} إلى الاستراحة لمدة $duration دقيقة"
                            } else {
                                "تم تسجيل خروج لـ ${validTargets.size} طالب إلى الاستراحة لمدة $duration دقيقة"
                            }
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            selectedStudentIds = emptySet()
                        }
                        showBreakDurationDialog = false
                        studentIdForBreakDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("تأكيد لبدء الاستراحة ☕", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { 
                    showBreakDurationDialog = false 
                    studentIdForBreakDialog = null
                }) {
                    Text("إلغاء")
                }
            }
        )
    }

    var fastAttendanceSearchQuery by remember { mutableStateOf("") }
    var fastAttendanceFilterChip by remember { mutableStateOf("الكل") }

    val filteredStudentAttendanceList = remember(studentAttendanceList, fastAttendanceSearchQuery, fastAttendanceFilterChip) {
        studentAttendanceList.filter { att ->
            val query = fastAttendanceSearchQuery.trim()
            val matchesSearch = query.isEmpty() ||
                    att.studentName.contains(query, ignoreCase = true) ||
                    att.studentId.toString().contains(query)

            val matchesFilter = when (fastAttendanceFilterChip) {
                "غير مرصود" -> att.status == "لم يسجل" || att.status.isBlank()
                "حاضر" -> att.status == "حضور" && att.checkInDelayMinutes <= 0
                "غائب" -> att.status == "غياب"
                "متأخر" -> att.status == "حضور" && att.checkInDelayMinutes > 0
                "مستأذن" -> att.status == "مستأذن"
                else -> true
            }

            matchesSearch && matchesFilter
        }
    }

    val fastTotalCount = studentAttendanceList.size
    val fastRecordedCount = remember(studentAttendanceList) {
        studentAttendanceList.count { it.status.isNotBlank() && it.status != "لم يسجل" }
    }
    val fastUnmarkedCount = fastTotalCount - fastRecordedCount
    val fastProgressFraction = if (fastTotalCount > 0) fastRecordedCount.toFloat() / fastTotalCount else 0f

    val attendanceCardRows = remember(filteredStudentAttendanceList, expandedStudentId) {
        val rows = mutableListOf<List<StudentAttendance>>()
        val currentPair = mutableListOf<StudentAttendance>()
        for (student in filteredStudentAttendanceList) {
            if (student.studentId == expandedStudentId) {
                if (currentPair.isNotEmpty()) {
                    rows.add(currentPair.toList())
                    currentPair.clear()
                }
                rows.add(listOf(student))
            } else {
                currentPair.add(student)
                if (currentPair.size == 2) {
                    rows.add(currentPair.toList())
                    currentPair.clear()
                }
            }
        }
        if (currentPair.isNotEmpty()) {
            rows.add(currentPair.toList())
        }
        rows
    }

    MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            // Quick Navigation Shortcuts
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                viewModel.openTrainerGroup(1)
                            },
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = DawamiNavy.copy(alpha = 0.08f)),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.School, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                            Text("حضور الأستاذ 👨‍🏫", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        }
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.navigateTo(Screen.StudentViolations) },
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF59E0B).copy(alpha = 0.08f)),
                        border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.WarningAmber, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(16.dp))
                            Text("سجل المخالفات والانضباط ⚠️", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                        }
                    }
                }
            }

            // Setup & Selector Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(attendanceDate) {
                            detectTapGestures(
                                onDoubleTap = {
                                    if (attendanceDate != todayStr) {
                                        isEditableInPastStudents = !isEditableInPastStudents
                                        Toast.makeText(
                                            context,
                                            if (isEditableInPastStudents) "تم تمكين التعديل لليوم السابق 🔓" else "تم قفل الشاشة للقراءة فقط 🔒",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )
                        },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (attendanceDate != todayStr) {
                            val bannerText = if (isEditableInPastStudents) 
                                "وضع التعديل مفعل لليوم السابق 🔓 (انقر مرتين للإغلاق والتحويل للقراءة فقط 🔒)" 
                            else 
                                "وضع القراءة فقط لمنع التعديل غير المقصود 🔒 (انقر مرتين لتمكين التعديل 🔓)"
                            
                            val bannerBg = if (isEditableInPastStudents) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)
                            val bannerBorder = if (isEditableInPastStudents) Color(0xFFBBF7D0) else Color(0xFFFEE2E2)
                            val bannerTextCol = if (isEditableInPastStudents) Color(0xFF15803D) else Color(0xFFB91C1C)
                            
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(bannerBg, RoundedCornerShape(8.dp))
                                    .border(1.dp, bannerBorder, RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = bannerText,
                                    color = bannerTextCol,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isHeaderExpanded = !isHeaderExpanded },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.FactCheck, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(18.dp))
                                Text("تسجيل حضور وغياب الطلاب", color = DawamiNavy, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(
                                onClick = { isHeaderExpanded = !isHeaderExpanded },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = if (isHeaderExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = if (isHeaderExpanded) "طي أدوات التحكم" else "عرض أدوات التحكم",
                                    tint = DawamiNavy,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        AnimatedVisibility(visible = isHeaderExpanded) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                        // الصف الأول: الدورة التدريبية والمادة بجانب بعضهما بدون التفاف وبكامل النص
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Select Course
                            var isCourseDropdownExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1.5f)) {
                                ExposedDropdownMenuBox(
                                    expanded = isCourseDropdownExpanded,
                                    onExpandedChange = { isCourseDropdownExpanded = it }
                                ) {
                                    OutlinedTextField(
                                        value = selectedCourse?.name ?: "اختر الدورة التدريبية...",
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("الدورة التدريبية", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) },
                                        textStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface),
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCourseDropdownExpanded) },
                                        modifier = Modifier
                                            .menuAnchor()
                                            .fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        singleLine = true,
                                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                                    )

                                    ExposedDropdownMenu(
                                        expanded = isCourseDropdownExpanded,
                                        onDismissRequest = { isCourseDropdownExpanded = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                                        fontSize = 10.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                                    )
                                                    Icon(
                                                        imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                        contentDescription = null,
                                                        tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                }
                                            },
                                            onClick = {
                                                viewModel.toggleShowCompletedCoursesInDropdowns()
                                            }
                                        )
                                        HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                                        val displayedCourses = if (showCompletedCourses) dbCourses else dbCourses.filter { !it.isCompleted }
                                        displayedCourses.forEach { course ->
                                            DropdownMenuItem(
                                                text = {
                                                    Text(
                                                        text = if (course.isCompleted) "${course.name} (منتهية 🔒)" else course.name,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 11.5.sp,
                                                        maxLines = 1,
                                                        color = if (course.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                                    )
                                                },
                                                onClick = {
                                                    viewModel.selectCourseForStudentAttendance(course)
                                                    isCourseDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            // Display Teaching Subject (Uneditable on Student Screen)
                            Box(modifier = Modifier.weight(1.5f)) {
                                OutlinedTextField(
                                    value = if (selectedCourse == null) "اختر دورة أولاً" else studentAttendanceSelectedSubject.ifEmpty { "عام (بدون مادة)" },
                                    onValueChange = {},
                                    readOnly = true,
                                    enabled = false,
                                    label = {
                                        Text(
                                            "المادة التدريسية",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiTeal,
                                            maxLines = 1
                                        )
                                    },
                                    textStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface),
                                    leadingIcon = { Icon(Icons.Default.Book, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(12.dp)) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        disabledBorderColor = DawamiTeal.copy(alpha = 0.5f),
                                        disabledLabelColor = DawamiTeal,
                                        disabledTextColor = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }
                        }

                        // الصف الثاني: تاريخ الحركة وملاحظة الحركة اليومية
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            com.example.ui.components.InlineExpandableDatePicker(
                                selectedDate = attendanceDate,
                                onDateSelected = { viewModel.setStudentAttendanceDate(it) },
                                label = "تاريخ الحركة ($attendanceDay)",
                                modifier = Modifier.weight(1.1f)
                            )

                            OutlinedTextField(
                                value = dailyNoteText,
                                enabled = isStudentFormEnabled,
                                onValueChange = { viewModel.dailyCourseNoteInput.value = it },
                                placeholder = { Text("سجل ملاحظات اليوم...", fontSize = 10.5.sp) },
                                label = { Text("ملاحظة الحركة اليومية 📝", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                modifier = Modifier.weight(1.3f),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = TextStyle(fontSize = 11.sp),
                                minLines = 1,
                                maxLines = 10,
                                trailingIcon = {
                                    IconButton(
                                        enabled = isStudentFormEnabled,
                                        onClick = {
                                            viewModel.saveDailyCourseNote()
                                            Toast.makeText(context, "تم حفظ الملاحظة بنجاح!", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Save,
                                            contentDescription = "حفظ ملاحظة الحركة اليومية",
                                            tint = if (isStudentFormEnabled) DawamiNavy else Color.Gray,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            )
                        }

                        // الصف الرابع: وقت الدخول ووقت الانصراف للطلاب
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            com.example.ui.components.InlineExpandableTimePicker(
                                selectedTime = studentCheckInTimeInput,
                                label = "وقت الدخول 📥",
                                onTimeSelected = { viewModel.studentCheckInTimeInput.value = it },
                                modifier = Modifier.weight(1f)
                            )

                            com.example.ui.components.InlineExpandableTimePicker(
                                selectedTime = studentCheckOutTimeInput,
                                label = "وقت الانصراف 📤",
                                onTimeSelected = { viewModel.studentCheckOutTimeInput.value = it },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // ملخص حركات الطلاب الحالية (حضور، غياب، مستأذن، إجازة، بدون حركات)
                        Spacer(modifier = Modifier.height(10.dp))
                        val currentPresentCount = studentAttendanceList.count { it.status == "حضور" }
                        val currentAbsentCount = studentAttendanceList.count { it.status == "غياب" }
                        val currentExcusedCount = studentAttendanceList.count { it.status == "مستأذن" }
                        val currentLeaveCount = studentAttendanceList.count { it.status == "إجازة" }
                        val currentNotRegisteredCount = studentAttendanceList.count { it.status == "لم يسجل" }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp, horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // الحضور (دائرة خضراء)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF22C55E))
                                    )
                                    Text(
                                        text = "حضور: $currentPresentCount",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                // الغياب (دائرة حمراء)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFEF4444))
                                    )
                                    Text(
                                        text = "غياب: $currentAbsentCount",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                // مستأذن (دائرة زرقاء)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF0284C7))
                                    )
                                    Text(
                                        text = "مستأذن: $currentExcusedCount",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                // الإجازة (دائرة صفراء)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFEAB308))
                                    )
                                    Text(
                                        text = "إجازة: $currentLeaveCount",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                // بدون حركات (دائرة سوداء)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF1E293B))
                                    )
                                    Text(
                                        text = "لم يسجل: $currentNotRegisteredCount",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                            }
                        }
                    }
                }
            }



            if (selectedCourse != null) {
                if (currentSubjectStat != null && currentSubjectStat.targetDays > 0 && currentSubjectStat.status != "مكتملة التدريس" && !isCourseEndedForDate) {
                    val isLastScheduledDay = currentSubjectStat.taughtDaysCount == currentSubjectStat.targetDays - 1
                    val isSupplementaryDay = currentSubjectStat.taughtDaysCount >= currentSubjectStat.targetDays
                    
                    if (isLastScheduledDay || isSupplementaryDay) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0xFFFFFBEB)
                                ),
                                border = BorderStroke(1.2.dp, Color(0xFFD97706).copy(alpha = 0.8f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFFEF3C7)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = Color(0xFFD97706),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isLastScheduledDay) "📅 تنبيه الجلسة الأخيرة المجدولة للمادة!" else "⚠️ جلسة مراجعة تكميلية مفتوحة للمادة!",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF92400E)
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = if (isLastScheduledDay) {
                                                "اليوم هو اللقاء الأخير المجدول لمادة (${studentAttendanceSelectedSubject}). يرجى تفعيل خيار الامتحان عند تسجيل حركتك اليوم ليتم إغلاق المادة."
                                            } else {
                                                "تم تمديد خطة مادة (${studentAttendanceSelectedSubject}) لتبلغ (${currentSubjectStat.taughtDaysCount + 1} أيام). لإنهاء المادة رسمياً، يرجى تفعيل خيار الامتحان عند رصد حركة اليوم."
                                            },
                                            fontSize = 9.5.sp,
                                            color = Color(0xFFB45309),
                                            lineHeight = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (!isTrainerMovementRecorded && !isCourseEndedForDate) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFFFEF3C7)
                            ),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.7f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = Color(0xFFD97706),
                                    modifier = Modifier.size(20.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "بانتظار تسجيل حركة المدرب أولاً ⏳",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF92400E)
                                    )
                                    Text(
                                        text = "يتطلب تسلسل العمليات تسجيل حالة (حضور أو غياب أو إجازة أو مستأذن) للمدرب أولاً قبل بدء تحضير الطلاب.",
                                        fontSize = 10.sp,
                                        color = Color(0xFFB45309),
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Live Search + Filter Chips
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Search Bar
                            OutlinedTextField(
                                value = fastAttendanceSearchQuery,
                                onValueChange = { fastAttendanceSearchQuery = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                placeholder = { Text("ابحث باسم الطالب أو رقم الهاتف...", fontSize = 11.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "بحث",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                trailingIcon = {
                                    if (fastAttendanceSearchQuery.isNotEmpty()) {
                                        IconButton(onClick = { fastAttendanceSearchQuery = "" }) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "مسح",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                textStyle = TextStyle(fontSize = 11.5.sp)
                            )

                            // Filter Chips Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val filterChips = listOf("الكل", "غير مرصود", "حاضر", "غائب", "متأخر", "مستأذن")
                                filterChips.forEach { chipLabel ->
                                    val isSelected = fastAttendanceFilterChip == chipLabel
                                    val count = when (chipLabel) {
                                        "الكل" -> fastTotalCount
                                        "غير مرصود" -> fastUnmarkedCount
                                        "حاضر" -> studentAttendanceList.count { it.status == "حضور" && it.checkInDelayMinutes <= 0 }
                                        "غائب" -> studentAttendanceList.count { it.status == "غياب" }
                                        "متأخر" -> studentAttendanceList.count { it.status == "حضور" && it.checkInDelayMinutes > 0 }
                                        "مستأذن" -> studentAttendanceList.count { it.status == "مستأذن" }
                                        else -> 0
                                    }

                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { fastAttendanceFilterChip = chipLabel },
                                        label = {
                                            Text(
                                                text = "$chipLabel ($count)",
                                                fontSize = 10.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = DawamiNavy,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // Dynamic Action Bar & List Header Section
                item {
                    Column(
                        modifier = Modifier.padding(top = 4.dp, bottom = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (!isCourseEndedForDate) {
                            // Top Header Bar: Title, WhatsApp Share Button & Select-All Checkbox
                            Text(
                                text = "تسجيل الحركات اليومية للطلاب (${studentAttendanceList.size} طالب)",
                                color = DawamiNavy,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth().padding(bottom = 2.dp)
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                            // Batch Individual WhatsApp Share Button
                            Surface(
                                color = Color(0xFF16A34A).copy(alpha = 0.12f),
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, Color(0xFF16A34A).copy(alpha = 0.4f)),
                                modifier = Modifier.clickable {
                                    if (selectedCourse == null) {
                                        Toast.makeText(context, "الرجاء اختيار الدورة التدريبية أولاً", Toast.LENGTH_SHORT).show()
                                    } else if (studentAttendanceList.isEmpty()) {
                                        Toast.makeText(context, "لا يوجد طلاب مسجلون في هذه الدورة لتجهيز الحركة", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val batchList = mutableListOf<StudentBatchData>()
                                        val courseName = selectedCourse?.name ?: ""
                                        val institute = viewModel.instituteName.value
                                        val includeTopics = viewModel.includeLessonTopicsInReport.value
                                        
                                        studentAttendanceList.forEach { att ->
                                            val msg = generateIndividualAttendanceMessage(
                                                studentName = att.studentName,
                                                status = att.status,
                                                checkIn = att.actualCheckIn,
                                                checkOut = att.actualCheckOut,
                                                note = att.studentNote,
                                                courseName = courseName,
                                                date = attendanceDate,
                                                institute = institute,
                                                includeLessonTopics = includeTopics,
                                                viewModel = viewModel
                                            )
                                            val studentObj = dbAllStudents.find { it.id == att.studentId }
                                            val phone = studentObj?.phoneNumber?.replace(Regex("[^0-9+]"), "")?.trim() ?: ""
                                            batchList.add(
                                                StudentBatchData(
                                                    studentName = att.studentName,
                                                    phoneNumber = phone,
                                                    messageText = msg
                                                )
                                            )
                                        }
                                        
                                        batchStudentsToShare = batchList
                                        currentBatchIndex = 0
                                        isBatchSharing = true
                                    }
                                }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = null,
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = "إرسال فردي للطلاب بالواتساب 📱",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D),
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }

                            // Compact WhatsApp Share Button
                            Surface(
                                color = Color(0xFF25D366).copy(alpha = 0.12f),
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, Color(0xFF25D366).copy(alpha = 0.4f)),
                                modifier = Modifier.clickable { onShareReportClick() }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Send,
                                        contentDescription = null,
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = "تقرير الواتساب 📱",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D),
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }

                            // Bulk Funny Penalty Button
                            Surface(
                                color = Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                                modifier = Modifier.clickable { showBulkFunnyPenaltyDialog = true }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "عقوبات فكاهية 🎭",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFB45309),
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }

                            // New: "تحديد من في الاستراحة" Button for filtering/selecting students on break
                            val studentsOnBreakCount = studentAttendanceList.count { it.status == "حضور" && it.isOnBreak && it.actualCheckOut.isEmpty() }
                            if (studentsOnBreakCount > 0) {
                                Surface(
                                    color = DawamiGold.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(20.dp),
                                    border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.4f)),
                                    modifier = Modifier.clickable {
                                        selectedStudentIds = studentAttendanceList.filter { it.status == "حضور" && it.isOnBreak && it.actualCheckOut.isEmpty() }.map { it.studentId }.toSet()
                                    }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.BeachAccess,
                                            contentDescription = null,
                                            tint = Color(0xFFD97706),
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            text = "في الاستراحة ($studentsOnBreakCount) ☕",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFB45309),
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }
                            }

                            // Select All Checkbox & Compact Grid View Toggle
                            if (studentAttendanceList.isNotEmpty()) {
                                val allSelected = selectedStudentIds.size == studentAttendanceList.size && studentAttendanceList.isNotEmpty()
                                
                                Surface(
                                    color = if (isCompactSelectionMode || selectedStudentIds.isNotEmpty()) DawamiNavy.copy(alpha = 0.12f) else Color.Transparent,
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, if (isCompactSelectionMode || selectedStudentIds.isNotEmpty()) DawamiNavy else Color(0xFFCBD5E1)),
                                    modifier = Modifier.clickable {
                                        isCompactSelectionMode = !isCompactSelectionMode
                                    }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.GridView,
                                            contentDescription = null,
                                            tint = DawamiNavy,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Text(
                                            text = if (isCompactSelectionMode || selectedStudentIds.isNotEmpty()) "شبكة التحديد (3) 🔳" else "وضع التحديد 📱",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }

                                Surface(
                                    color = if (allSelected) DawamiNavy.copy(alpha = 0.12f) else Color.Transparent,
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, if (allSelected) DawamiNavy else Color(0xFFCBD5E1)),
                                    modifier = Modifier.clickable(enabled = isStudentFormEnabled) {
                                        selectedStudentIds = if (allSelected) emptySet() else studentAttendanceList.map { it.studentId }.toSet()
                                    }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Checkbox(
                                            checked = allSelected,
                                            onCheckedChange = { checked ->
                                                selectedStudentIds = if (checked) {
                                                    studentAttendanceList.map { it.studentId }.toSet()
                                                } else {
                                                    emptySet()
                                                }
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = DawamiNavy),
                                            enabled = isStudentFormEnabled,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = if (allSelected) "إلغاء التحديد" else "تحديد الكل",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }
                            }
                        }
                        }

                        // شريط التنقل العصري الموحد بين الأيام
                        ModernDayNavigator(
                            currentDate = attendanceDate,
                            currentDayName = attendanceDay,
                            todayDate = todayStr,
                            recordedDates = recordedStudentDates,
                            onDateSelected = { newDate ->
                                viewModel.setStudentAttendanceDate(newDate)
                            },
                            enabled = selectedCourse != null,
                            courseEndDate = selectedCourse?.endDate,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                        )

                        if (isCourseEndedForDate) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                border = BorderStroke(1.2.dp, Color(0xFF94A3B8).copy(alpha = 0.8f))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(50.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFE2E8F0)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = null,
                                            tint = Color(0xFF475569),
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                    Text(
                                        text = "دورة منتهية رسمياً 🔒",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1E293B)
                                    )
                                    val endDateDisplay = selectedCourse?.endDate?.ifBlank { "تاريخ سابق" } ?: "تاريخ سابق"
                                    Text(
                                        text = "انتهت فترة هذه الدورة التدريبية (${selectedCourse?.name ?: ""}) بتاريخ ($endDateDisplay).\n\n" +
                                                "📌 ملاحظة:\n" +
                                                "تم إيقاف ظهور بطاقات الطلاب ورصد التحضير في هذا التاريخ بعد انتهاء الدورة لحماية السجلات ومنع التكرار.\n" +
                                                "إذا كنت ترغب في مراجعة أو أرشفة سجلات الطلاب، يرجى الانتقال إلى الأيام السابقة (السابق 🗓️) في فترة الدورة الفعلية.",
                                        fontSize = 11.5.sp,
                                        color = Color(0xFF475569),
                                        textAlign = TextAlign.Center,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        } else {
                        // Smart Unified Action Card: Switches between General Batch & Selection Batch Actions
                        Crossfade(
                            targetState = selectedStudentIds.isNotEmpty(),
                            label = "BatchActionsTransition"
                        ) { isSelectionActive ->
                            if (!isSelectionActive) {
                                // MODE A: General Simultaneous Registration (When NO students are selected)
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = DawamiNavy.copy(alpha = 0.04f)),
                                    border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.15f)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Icon(Icons.Default.Groups, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(16.dp))
                                                Text(
                                                    text = "التسجيل الجماعي الموحد (لكافة طلاب الدورة)",
                                                    color = DawamiNavy,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.5.sp
                                                )
                                            }
                                            Text(
                                                text = "حدد طلاب بالأسفل لحركات تخصهم ⚡",
                                                color = Color.Gray,
                                                fontSize = 9.sp
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            val isUnifiedCheckInEnabled = selectedCourse != null && attendanceDate.isNotEmpty() && isStudentFormEnabled
                                            Button(
                                                onClick = {
                                                    checkTrainerStatusAndRun("حضور") {
                                                        studentUnifiedTargetIds = studentAttendanceList.map { it.studentId }.toSet()
                                                        studentUnifiedDialogMode = StudentConfirmType.CHECK_IN
                                                        showStudentUnifiedDialog = true
                                                    }
                                                },
                                                enabled = isUnifiedCheckInEnabled,
                                                modifier = Modifier.weight(1f).height(36.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                                            ) {
                                                Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(13.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("حضور جماعي", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }

                                            val isUnifiedCheckOutEnabled = selectedCourse != null && attendanceDate.isNotEmpty() && isStudentFormEnabled
                                            Button(
                                                onClick = {
                                                    checkTrainerStatusAndRun("انصراف") {
                                                        studentUnifiedTargetIds = studentAttendanceList.map { it.studentId }.toSet()
                                                        studentUnifiedDialogMode = StudentConfirmType.CHECK_OUT
                                                        showStudentUnifiedDialog = true
                                                    }
                                                },
                                                enabled = isUnifiedCheckOutEnabled,
                                                modifier = Modifier.weight(1f).height(36.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal)
                                            ) {
                                                Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(13.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("انصراف جماعي", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }

                                            val isUnifiedLeaveEnabled = selectedCourse != null && attendanceDate.isNotEmpty() && isStudentFormEnabled
                                            Button(
                                                onClick = {
                                                    checkTrainerStatusAndRun("إجازة") {
                                                        studentUnifiedTargetIds = studentAttendanceList.map { it.studentId }.toSet()
                                                        studentUnifiedDialogMode = StudentConfirmType.LEAVE
                                                        showStudentUnifiedDialog = true
                                                    }
                                                },
                                                enabled = isUnifiedLeaveEnabled,
                                                modifier = Modifier.weight(1f).height(36.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                                            ) {
                                                Icon(Icons.Default.BeachAccess, contentDescription = null, modifier = Modifier.size(13.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("إجازة للجميع", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }

                                            val isUnifiedResetEnabled = selectedCourse != null && attendanceDate.isNotEmpty() && isStudentFormEnabled
                                            Button(
                                                onClick = {
                                                    checkTrainerStatusAndRun("إعادة ضبط") {
                                                        studentUnifiedTargetIds = studentAttendanceList.map { it.studentId }.toSet()
                                                        studentUnifiedDialogMode = StudentConfirmType.RESET
                                                        showStudentUnifiedDialog = true
                                                    }
                                                },
                                                modifier = Modifier.weight(1f).height(36.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.85f))
                                            ) {
                                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(13.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("إعادة تعيين", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            } else {
                                // MODE B: Selection Batch Actions Bar (When 1 or more students ARE selected)
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                                    border = BorderStroke(1.5.dp, DawamiNavy),
                                    shape = RoundedCornerShape(14.dp),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        val selectedAtts = studentAttendanceList.filter { it.studentId in selectedStudentIds }
                                        val hasCheckedIn = selectedAtts.any { it.status == "حضور" && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() }
                                        val hasNotCheckedIn = selectedAtts.any { it.status != "غياب" && it.actualCheckOut.isEmpty() && (it.status == "لم يسجل" || it.status == "إجازة" || it.actualCheckIn.isEmpty()) }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Surface(
                                                    color = DawamiNavy,
                                                    shape = RoundedCornerShape(20.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.CheckCircle,
                                                        contentDescription = null,
                                                        tint = Color.White,
                                                        modifier = Modifier.padding(3.dp).size(14.dp)
                                                    )
                                                }
                                                Text(
                                                    text = "حركات الطلاب المحددين (${selectedStudentIds.size} طالب)",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    color = DawamiNavy
                                                )
                                            }

                                            Surface(
                                                color = Color.Red.copy(alpha = 0.1f),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.clickable { selectedStudentIds = emptySet() }
                                            ) {
                                                Text(
                                                    text = "إلغاء التحديد ✖",
                                                    fontSize = 10.5.sp,
                                                    color = Color.Red,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                )
                                            }
                                        }

                                        // Row 1: Attendance Actions (حضور)
                                        if (hasNotCheckedIn) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    val targets = selectedAtts.filter { it.status != "غياب" && it.actualCheckOut.isEmpty() && (it.status == "لم يسجل" || it.status == "إجازة" || it.actualCheckIn.isEmpty()) }
                                                    if (targets.isEmpty()) {
                                                        Toast.makeText(context, "عذراً، لا يوجد طلاب مؤهلين لتسجيل الحضور!", Toast.LENGTH_LONG).show()
                                                    } else {
                                                        checkTrainerStatusAndRun("حضور") {
                                                            studentUnifiedTargetIds = targets.map { it.studentId }.toSet()
                                                            studentUnifiedDialogMode = StudentConfirmType.CHECK_IN
                                                            showStudentUnifiedDialog = true
                                                        }
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                                modifier = Modifier.weight(1f).height(36.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.Login, contentDescription = null, modifier = Modifier.size(11.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("حضور المحددين", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        }

                                        // Row 2: Dismissal Actions (انصراف)
                                        if (hasCheckedIn) {
                                            Button(
                                                onClick = {
                                                    val targets = selectedAtts.filter { it.status == "حضور" && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() }
                                                    if (targets.isEmpty()) {
                                                        Toast.makeText(context, "عذراً، لا يوجد طلاب مؤهلين لتسجيل الانصراف!", Toast.LENGTH_LONG).show()
                                                    } else {
                                                        checkTrainerStatusAndRun("انصراف") {
                                                            studentUnifiedTargetIds = targets.map { it.studentId }.toSet()
                                                            studentUnifiedDialogMode = StudentConfirmType.CHECK_OUT
                                                            showStudentUnifiedDialog = true
                                                        }
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                                modifier = Modifier.fillMaxWidth().height(36.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(11.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("انصراف المحددين", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        // Row 3: Status Actions (غياب واستئذان وإجازة)
                                        if (hasNotCheckedIn) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            listOf(
                                                Triple("غياب", Color(0xFFDC2626), StudentConfirmType.ABSENT),
                                                Triple("استئذان", Color(0xFF0284C7), StudentConfirmType.EXCUSED),
                                                Triple("إجازة", Color(0xFFD97706), StudentConfirmType.LEAVE)
                                            ).forEach { (label, color, mode) ->
                                                Button(
                                                    onClick = {
                                                        val targets = selectedAtts.filter { it.actualCheckOut.isEmpty() && it.actualCheckIn.isEmpty() }
                                                        if (targets.isEmpty()) {
                                                            Toast.makeText(context, "عذراً، لا يوجد طلاب مؤهلين لهذه الحركة!", Toast.LENGTH_LONG).show()
                                                        } else {
                                                            checkTrainerStatusAndRun(label) {
                                                                studentUnifiedTargetIds = targets.map { it.studentId }.toSet()
                                                                studentUnifiedDialogMode = mode
                                                                showStudentUnifiedDialog = true
                                                            }
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = color),
                                                    modifier = Modifier.weight(1f).height(36.dp),
                                                    shape = RoundedCornerShape(8.dp),
                                                    contentPadding = PaddingValues(0.dp)
                                                ) {
                                                    Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                        }

                                        // Row 4: Break Actions (استراحة / فسحة)
                                        if (hasCheckedIn) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            val nowTimeStr = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date())

                                            Button(
                                                onClick = {
                                                    val targets = studentAttendanceList.filter { it.studentId in selectedStudentIds && it.status == "حضور" && it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() && !it.isOnBreak }
                                                    if (targets.isEmpty()) {
                                                        Toast.makeText(context, "عذراً، لا يوجد طلاب حاضرين مؤهلين لبدء الاستراحة من بين المحددين! (يجب تسجيل حضورهم أولاً وألا يكونوا في استراحة حالياً) ⚠️", Toast.LENGTH_LONG).show()
                                                    } else {
                                                        studentIdForBreakDialog = null
                                                        showBreakDurationDialog = true
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color(0xFF8B5CF6),
                                                    contentColor = Color.White
                                                ),
                                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f).height(36.dp)
                                            ) {
                                                Icon(Icons.Default.FreeBreakfast, contentDescription = null, modifier = Modifier.size(11.dp))
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text("خروج استراحة", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = {
                                                    val targets = studentAttendanceList.filter { it.studentId in selectedStudentIds && it.isOnBreak }
                                                    if (targets.isEmpty()) {
                                                        Toast.makeText(context, "لا يوجد طلاب من المحددين في استراحة حالياً", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        studentCardActionConfirmDialog = Pair(
                                                            "تأكيد تسجيل عودة من الاستراحة لعدد (${targets.size}) طلاب؟"
                                                        ) {
                                                            targets.forEach { att ->
                                                                viewModel.registerStudentBreakEnd(att, nowTimeStr)
                                                            }
                                                            Toast.makeText(context, "تم تسجيل عودة ${targets.size} طالب من الاستراحة", Toast.LENGTH_SHORT).show()
                                                            selectedStudentIds = emptySet()
                                                        }
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color(0xFF4F46E5),
                                                    contentColor = Color.White
                                                ),
                                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f).height(36.dp)
                                            ) {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(11.dp))
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text("رجوع استراحة", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        }

                                        // Row 5: Reset / Delete Record & WhatsApp Share
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    val targets = studentAttendanceList.filter { it.studentId in selectedStudentIds && it.status != "لم يسجل" }
                                                    if (targets.isEmpty()) {
                                                        Toast.makeText(context, "الطلاب المحددين غير مسجلين بالفعل", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        showSelectedStudentsResetDialog = true
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color(0xFFBE123C),
                                                    contentColor = Color.White
                                                ),
                                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f).height(36.dp)
                                            ) {
                                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(11.dp))
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text("إعادة تعيين", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = {
                                                    val targets = studentAttendanceList.filter { it.studentId in selectedStudentIds }
                                                    if (targets.isEmpty()) return@Button
                                                    val institute = viewModel.instituteName.value
                                                    val sb = StringBuilder()
                                                    val dateFormatted = formatArabicDateHeader(attendanceDate)
                                                    sb.append("📊 تقرير الحركة اليومية للطلاب المحددين\n")
                                                    sb.append("📅 التاريخ: $dateFormatted\n")
                                                    val courseName = selectedCourse?.name ?: ""
                                                    if (courseName.isNotEmpty()) sb.append("📚 الدورة: $courseName\n")
                                                    sb.append("👥 العدد: ${targets.size} طالب\n")
                                                    val teacherDailyNoteBatch = if (dailyNoteText.isNotBlank()) dailyNoteText else (targets.firstOrNull { it.courseDailyNote.isNotBlank() }?.courseDailyNote ?: "")
                                                    if (teacherDailyNoteBatch.isNotEmpty()) {
                                                        sb.append("📝 ملاحظة المعلم اليومية: $teacherDailyNoteBatch\n")
                                                    }
                                                    sb.append("----------------------------------------\n")
                                                    targets.forEachIndexed { idx, att ->
                                                        sb.append("${idx + 1}. ${att.studentName}\n")
                                                        sb.append("   - الحالة: ${att.status}\n")
                                                        if (att.actualCheckIn.isNotEmpty()) sb.append("   - الدخول: ${formatTimeTo12HourArabic(att.actualCheckIn)}\n")
                                                        if (att.actualCheckOut.isNotEmpty()) sb.append("   - الخروج: ${formatTimeTo12HourArabic(att.actualCheckOut)}\n")
                                                        if (att.studentNote.isNotEmpty()) sb.append("   - ملاحظة: ${att.studentNote}\n")
                                                    }
                                                    sb.append("----------------------------------------\n")
                                                    if (!selectedCourse?.trainerName.isNullOrBlank()) {
                                                        sb.append("المدرب المعتمد: ${selectedCourse?.trainerName}\n")
                                                    }
                                                    if (!selectedCourse?.departmentName.isNullOrBlank()) {
                                                        sb.append("القسم: ${selectedCourse?.departmentName}\n")
                                                    }
                                                    sb.append("المعهد: $institute\n")
                                                    shareMessageText = sb.toString()
                                                    showWhatsAppChoiceDialog = true
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color(0xFF15803D),
                                                    contentColor = Color.White
                                                ),
                                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f).height(36.dp)
                                            ) {
                                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(11.dp))
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text("واتساب للمحددين", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                         }
                                     }
                                 }
                             }
                         }
                     }
                }

                if (isCourseEndedForDate) {
                    // Hide student cards on days after course completion/end
                } else if (studentAttendanceList.isEmpty()) {
                         item {
                             Box(
                                 modifier = Modifier.fillMaxWidth().padding(top = 32.dp),
                                 contentAlignment = Alignment.Center
                             ) {
                                 Text("لا يوجد طلاب مسجلون في هذه الدورة التدريبية حالياً", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                             }
                         }
                     } else if (isCompactSelectionMode || selectedStudentIds.isNotEmpty()) {
                         item {
                             Row(
                                 modifier = Modifier
                                     .fillMaxWidth()
                                     .padding(vertical = 4.dp, horizontal = 2.dp),
                                 horizontalArrangement = Arrangement.SpaceBetween,
                                 verticalAlignment = Alignment.CenterVertically
                             ) {
                                 Text(
                                     text = "وضع التحديد السريع (3 طلاب في الصف) 📱",
                                     fontSize = 11.sp,
                                     fontWeight = FontWeight.Bold,
                                     color = DawamiNavy
                                 )
                                 Text(
                                     text = "تم تحديد ${selectedStudentIds.size} من ${studentAttendanceList.size}",
                                     fontSize = 10.5.sp,
                                     fontWeight = FontWeight.SemiBold,
                                     color = if (selectedStudentIds.isNotEmpty()) Color(0xFF059669) else MaterialTheme.colorScheme.onSurfaceVariant
                                 )
                             }
                         }
                         val chunks = studentAttendanceList.chunked(3)
                         items(
                             items = chunks,
                             key = { chunk -> chunk.first().studentId }
                         ) { rowStudents ->
                             Row(
                                 modifier = Modifier
                                     .fillMaxWidth()
                                     .padding(vertical = 3.dp),
                                 horizontalArrangement = Arrangement.spacedBy(6.dp)
                             ) {
                                 for (attendance in rowStudents) {
                                     val isSelected = attendance.studentId in selectedStudentIds
                                     CompactStudentSelectionCard(
                                         attendance = attendance,
                                         isSelected = isSelected,
                                         onToggleSelect = {
                                             selectedStudentIds = if (isSelected) {
                                                 selectedStudentIds - attendance.studentId
                                             } else {
                                                 selectedStudentIds + attendance.studentId
                                             }
                                         },
                                         modifier = Modifier.weight(1f)
                                     )
                                 }
                                 repeat(3 - rowStudents.size) {
                                     Spacer(modifier = Modifier.weight(1f))
                                 }
                             }
                         }
                     } else {
                         items(
                             items = attendanceCardRows,
                             key = { row -> row.joinToString("-") { it.studentId.toString() } }
                         ) { rowStudents ->
                             val isSingleRow = rowStudents.size == 1
                             val hasExpandedStudent = isSingleRow && rowStudents[0].studentId == expandedStudentId

                             Row(
                                 modifier = Modifier
                                     .fillMaxWidth()
                                     .then(
                                         if (hasExpandedStudent) Modifier else Modifier.height(IntrinsicSize.Max)
                                     ),
                                 horizontalArrangement = Arrangement.spacedBy(6.dp)
                             ) {
                                 for (attendance in rowStudents) {
                                     val isExpanded = attendance.studentId == expandedStudentId
                                     val cardModifier = if (isSingleRow && !isExpanded) {
                                         Modifier.weight(0.5f)
                                     } else {
                                         Modifier.weight(1f)
                                     }
                                     val stats = studentStatsMap[attendance.studentId]
                                     val totalDelayMinutes = stats?.first ?: 0
                                     val totalAbsences = stats?.second ?: 0

                                     val studentOverallStatus = dbAllStudents.find { it.id == attendance.studentId }?.status ?: "مستمر"
                                     StudentAttendanceCard(
                                         modifier = cardModifier,
                                         attendance = attendance,
                                         isSelected = attendance.studentId in selectedStudentIds,
                                         isSelectionModeActive = selectedStudentIds.isNotEmpty(),
                                         isExpanded = isExpanded,
                                        isExamDay = (trainerRecordForDay?.isExamDay == true) || dbAttendance.any { it.courseId == attendance.courseId && it.date == attendance.date && it.isExamDay },
                                         totalDelayMinutes = totalDelayMinutes,
                                         totalAbsences = totalAbsences,
                                         maxCumulativeDelay = maxCumulativeDelayVal,
                                         dailyNoteText = dailyNoteText,
                                         isEditable = isStudentFormEnabled,
                                         studentOverallStatus = studentOverallStatus,
                                          viewModel = viewModel,
                                         onSaveNote = { noteText ->
                                             viewModel.updateStudentPrivateNote(attendance, noteText)
                                         },
                                         onSaveStars = { stars ->
                                             viewModel.updateStudentParticipationStars(attendance, stars)
                                         },
                                         onShare = {
                                             val institute = viewModel.instituteName.value
                                             val sb = java.lang.StringBuilder()
                                             val dateFormatted = formatArabicDateHeader(attendanceDate)
                                             val statusStr = when (attendance.status) {
                                                 "حضور" -> "🟢 حضور"
                                                 "غياب" -> "🔴 غياب"
                                                 "مستأذن" -> "🔵 مستأذن"
                                                 "إجازة" -> "🟡 إجازة"
                                                 else -> "لم تسجل بعد"
                                             }
                                             sb.append("📋 تقرير الحركة اليومية للطالب").append("\n")
                                             sb.append("----------------------------------------").append("\n")
                                             sb.append("🏫 المعهد: " + institute).append("\n")
                                             sb.append("📚 الدورة: " + attendance.courseName).append("\n")
                                             sb.append("📅 التاريخ: " + dateFormatted).append("\n")
                                             sb.append("👤 الطالب: " + attendance.studentName).append("\n")
                                             sb.append("📌 الحالة: " + statusStr).append("\n")
                                             if (attendance.status == "حضور") {
                                                 if (attendance.actualCheckIn.isNotEmpty()) {
                                                     sb.append("📥 وقت الدخول: " + formatTimeTo12HourArabic(attendance.actualCheckIn)).append("\n")
                                                 }
                                                 if (attendance.actualCheckOut.isNotEmpty()) {
                                                     sb.append("📤 وقت الانصراف: " + formatTimeTo12HourArabic(attendance.actualCheckOut)).append("\n")
                                                 }
                                                 if (attendance.isOnBreak) {
                                                     sb.append("☕ حالة الاستراحة: في الاستراحة حالياً").append("\n")
                                                 } else if (attendance.breakActualReturnTime.isNotEmpty()) {
                                                     sb.append("☕ العودة من الاستراحة: " + formatTimeTo12HourArabic(attendance.breakActualReturnTime)).append("\n")
                                                     if (attendance.breakDelayMinutes > 0) {
                                                         sb.append("⚠️ تأخير الاستراحة: " + attendance.breakDelayMinutes + " دقيقة").append("\n")
                                                     }
                                                 }
                                             }
                                             sb.append("⭐ نجوم المشاركة: " + attendance.participationStars + " / 5").append("\n")
                                             val teacherDailyNoteCard = if (dailyNoteText.isNotBlank()) dailyNoteText else attendance.courseDailyNote
                                             if (teacherDailyNoteCard.isNotEmpty()) {
                                                 sb.append("📝 ملاحظة المعلم اليومية: " + teacherDailyNoteCard).append("\n")
                                             }
                                             if (attendance.studentNote.isNotEmpty()) {
                                                 sb.append("✍️ ملاحظة الطالب: " + attendance.studentNote).append("\n")
                                             }
                                             sb.append("----------------------------------------").append("\n")
                                             sb.append("🌹 شاكرين لكم حسن المتابعة").append("\n")
                                             if (!selectedCourse?.trainerName.isNullOrBlank()) {
                                                 sb.append("المدرب المعتمد: " + (selectedCourse?.trainerName ?: "")).append("\n")
                                             }
                                             if (!selectedCourse?.departmentName.isNullOrBlank()) {
                                                 sb.append("القسم: " + (selectedCourse?.departmentName ?: "")).append("\n")
                                             }
                                             sb.append("المعهد: " + institute)
                                             shareMessageText = sb.toString()
                                             showWhatsAppChoiceDialog = true
                                         },
                                         onToggleSelect = {
                                             selectedStudentIds = if (attendance.studentId in selectedStudentIds) {
                                                 selectedStudentIds - attendance.studentId
                                             } else {
                                                 selectedStudentIds + attendance.studentId
                                             }
                                         },
                                         onToggleExpand = {
                                             expandedStudentId = if (expandedStudentId == attendance.studentId) null else attendance.studentId
                                         },
                                          onCheckInNow = {
                                              checkTrainerStatusAndRun("حضور") {
                                                  studentUnifiedTargetIds = setOf(attendance.studentId)
                                                  studentUnifiedDialogMode = StudentConfirmType.CHECK_IN
                                                  showStudentUnifiedDialog = true
                                              }
                                          },
                                          onCheckInCourseTime = {
                                              checkTrainerStatusAndRun("حضور") {
                                                  studentUnifiedTargetIds = setOf(attendance.studentId)
                                                  studentUnifiedDialogMode = StudentConfirmType.CHECK_IN
                                                  showStudentUnifiedDialog = true
                                              }
                                          },
                                          onCheckOutNow = {
                                              checkTrainerStatusAndRun("انصراف") {
                                                  studentUnifiedTargetIds = setOf(attendance.studentId)
                                                  studentUnifiedDialogMode = StudentConfirmType.CHECK_OUT
                                                  showStudentUnifiedDialog = true
                                              }
                                          },
                                          onCheckOutCourseTime = {
                                              checkTrainerStatusAndRun("انصراف") {
                                                  studentUnifiedTargetIds = setOf(attendance.studentId)
                                                  studentUnifiedDialogMode = StudentConfirmType.CHECK_OUT
                                                  showStudentUnifiedDialog = true
                                              }
                                          },
                                          onAbsent = {
                                              checkTrainerStatusAndRun("غياب") {
                                                  studentUnifiedTargetIds = setOf(attendance.studentId)
                                                  studentUnifiedDialogMode = StudentConfirmType.ABSENT
                                                  showStudentUnifiedDialog = true
                                              }
                                          },
                                          onExcused = {
                                              checkTrainerStatusAndRun("مستأذن") {
                                                  studentUnifiedTargetIds = setOf(attendance.studentId)
                                                  studentUnifiedDialogMode = StudentConfirmType.EXCUSED
                                                  showStudentUnifiedDialog = true
                                              }
                                          },
                                          onLeave = {
                                              checkTrainerStatusAndRun("إجازة") {
                                                  studentUnifiedTargetIds = setOf(attendance.studentId)
                                                  studentUnifiedDialogMode = StudentConfirmType.LEAVE
                                                  showStudentUnifiedDialog = true
                                              }
                                          },
                                         onBreakStart = {
                                             checkTrainerStatusAndRun("استراحة") {
                                                 studentIdForBreakDialog = attendance.studentId
                                                 showBreakDurationDialog = true
                                             }
                                         },
                                         onBreakEnd = {
                                             val nowTimeStr = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date())
                                             if (viewModel.registerStudentBreakEnd(attendance, nowTimeStr)) {
                                                 Toast.makeText(context, "تم تسجيل عودة " + attendance.studentName + " من الاستراحة", Toast.LENGTH_SHORT).show()
                                             }
                                         },
                                          onDelete = {
                                              studentUnifiedTargetIds = setOf(attendance.studentId)
                                              studentUnifiedDialogMode = StudentConfirmType.RESET
                                              showStudentUnifiedDialog = true
                                          },
                                         onEdit = {
                                             checkTrainerStatusAndRun("تعديل") {
                                                 selectedRecordForDialogEdit = attendance
                                                 dialogStatus = attendance.status.ifEmpty { "حضور" }
                                                 dialogCheckIn = attendance.actualCheckIn
                                                 dialogCheckOut = attendance.actualCheckOut
                                                 dialogBreakStartTime = attendance.breakStartTime
                                                 dialogBreakReturnTime = attendance.breakActualReturnTime
                                             }
                                         }
                                     )
                                 }
                                 if (isSingleRow && !hasExpandedStudent) {
                                     Spacer(modifier = Modifier.weight(0.5f))
                                 }
                             }
                         }
                 }
             }
         }
     }
    }



@Composable
fun ActivitySummaryCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    bgContainerColor: Color,
    isSelected: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val isDark = com.example.ui.theme.LocalThemePreset.current.isDark
    Surface(
        modifier = modifier.clickable(enabled = onClick != null) { onClick?.invoke() },
        shape = RoundedCornerShape(10.dp),
        color = if (isDark) {
            if (isSelected) bgContainerColor.copy(alpha = 0.35f) else Color(0xFF1E293B)
        } else {
            bgContainerColor
        },
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) (if (isDark) DawamiGold else iconColor) else (if (isDark) Color(0xFF334155) else iconColor.copy(alpha = 0.25f))
        )
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isDark && isSelected) DawamiGold else iconColor,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isDark && isSelected) DawamiGold else iconColor
            )
            Text(
                text = title,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else DawamiNavy,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                fontSize = 8.sp,
                color = if (isDark) Color(0xFF94A3B8) else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun FilterChipPill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val isDark = com.example.ui.theme.LocalThemePreset.current.isDark
    Surface(
        modifier = Modifier.clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) (if (isDark) DawamiGold else DawamiNavy) else (if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9)),
        border = BorderStroke(1.dp, if (isSelected) (if (isDark) DawamiGold else DawamiNavy) else (if (isDark) Color(0xFF475569) else Color(0xFFCBD5E1)))
    ) {
        Text(
            text = label,
            fontSize = 10.5.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) (if (isDark) DawamiNavy else Color.White) else (if (isDark) Color.White else MaterialTheme.colorScheme.onSurface),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun StudentAttendanceCard(
    modifier: Modifier = Modifier,
    attendance: StudentAttendance,
    viewModel: MainViewModel,
    isSelected: Boolean,
    isSelectionModeActive: Boolean = false,
    isExpanded: Boolean,
    isExamDay: Boolean = false,
    totalDelayMinutes: Int,
    totalAbsences: Int,
    maxCumulativeDelay: Int,
    dailyNoteText: String = "",
    isEditable: Boolean = true,
    studentOverallStatus: String = "مستمر",
    onSaveNote: (String) -> Unit,
    onSaveStars: (Int) -> Unit,
    onShare: () -> Unit,
    onToggleSelect: () -> Unit,
    onToggleExpand: () -> Unit,
    onCheckInNow: () -> Unit,
    onCheckInCourseTime: () -> Unit,
    onCheckOutNow: () -> Unit,
    onCheckOutCourseTime: () -> Unit,
    onAbsent: () -> Unit,
    onExcused: () -> Unit,
    onLeave: () -> Unit,
    onBreakStart: () -> Unit,
    onBreakEnd: () -> Unit,
    onDelete: () -> Unit,
    onEdit: () -> Unit
) {
    val preset = LocalThemePreset.current
    val isDark = preset.isDark
    val cardContainerColor = if (isSelected) {
        if (isDark) Color(0xFF1E3A8A).copy(alpha = 0.5f) else Color(0xFFDBEAFE)
    } else MaterialTheme.colorScheme.surface

    val cardBorderStroke = if (isSelected) {
        BorderStroke(2.dp, if (isDark) DawamiGold else DawamiNavy)
    } else BorderStroke(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))

    data class BadgeStyle(val text: String, val bg: Color, val textColor: Color, val border: Color)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .combinedClickable(
                onClick = {
                    if (isSelectionModeActive) {
                        onToggleSelect()
                    } else {
                        onToggleExpand()
                    }
                },
                onLongClick = {
                    onToggleSelect()
                }
            ),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = cardContainerColor
        ),
        border = cardBorderStroke,
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 2.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Student Name (Top row)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (isSelectionModeActive) {
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggleSelect() },
                        modifier = Modifier.size(18.dp),
                        colors = CheckboxDefaults.colors(checkedColor = DawamiNavy)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = attendance.studentName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isDark) Color(0xFFF1F5F9) else Color(0xFF0F172A),
                        maxLines = 2,
                        overflow = TextOverflow.Clip
                    )
                    val displaySubject = attendance.subjectName.ifBlank { attendance.courseName }
                    if (displaySubject.isNotBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "📖 المادة: $displaySubject",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (isExamDay) {
                                Surface(
                                    color = if (isDark) Color(0xFF78350F).copy(alpha = 0.45f) else Color(0xFFFEF3C7),
                                    shape = RoundedCornerShape(4.dp),
                                    border = BorderStroke(1.dp, if (isDark) Color(0xFFF59E0B).copy(alpha = 0.6f) else Color(0xFFD97706).copy(alpha = 0.5f))
                                ) {
                                    Text(
                                        text = "📝 امتحان",
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color(0xFFFDE68A) else Color(0xFFB45309),
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                
                if (studentOverallStatus == "توقيف قيد" || studentOverallStatus == "منسحب" || studentOverallStatus == "موقف") {
                    Surface(
                        color = if (studentOverallStatus == "توقيف قيد" || studentOverallStatus == "موقف") Color(0xFFFEF3C7) else Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "($studentOverallStatus)",
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (studentOverallStatus == "توقيف قيد" || studentOverallStatus == "موقف") Color(0xFF92400E) else Color(0xFF991B1B),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Icons & Status row (matching screenshot)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Action Icons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(0.dp)
                ) {
                    // Expand / Collapse Arrow
                    IconButton(
                        onClick = { onToggleExpand() },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = if (isExpanded) "طي" else "توسيع",
                            tint = if (isDark) Color(0xFF94A3B8) else Color(0xFF475569),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Delete Button
                    IconButton(
                        onClick = { onDelete() },
                        enabled = isEditable,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "إعادة تعيين",
                            tint = if (isEditable) Color(0xFFDC2626) else Color.Gray,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    // Edit Button
                    IconButton(
                        onClick = { onEdit() },
                        enabled = isEditable,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "تعديل",
                            tint = if (isEditable) (if (isDark) Color(0xFF94A3B8) else Color(0xFF475569)) else Color.Gray,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    // Share Button
                    IconButton(
                        onClick = { onShare() },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "مشاركة",
                            tint = if (isDark) Color(0xFF34D399) else Color(0xFF16A34A),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                // Right side: Status Badge + Break
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    if (attendance.status == "حضور" && attendance.isOnBreak && attendance.actualCheckOut.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DawamiGold.copy(alpha = 0.18f),
                            border = BorderStroke(0.6.dp, DawamiGold.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "☕",
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }

                    StatusBadge(status = attendance.status)
                }
            }

            // Bottom Row (When Collapsed): Compact badges (matching screenshot)
            if (!isExpanded) {
                if (attendance.status == "حضور" || attendance.actualCheckIn.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Check-in Time Badge (Green / Red)
                        if (attendance.actualCheckIn.isNotEmpty()) {
                            val isCheckInLate = attendance.checkInDelayMinutes > 0
                            val checkInBg = if (isCheckInLate) {
                                if (isDark) Color(0xFF7F1D1D).copy(alpha = 0.4f) else Color(0xFFFEF2F2)
                            } else {
                                if (isDark) Color(0xFF064E3B).copy(alpha = 0.4f) else Color(0xFFECFDF5)
                            }
                            val checkInBorder = if (isCheckInLate) {
                                if (isDark) Color(0xFFEF4444).copy(alpha = 0.6f) else Color(0xFFFECACA)
                            } else {
                                if (isDark) Color(0xFF10B981).copy(alpha = 0.6f) else Color(0xFFA7F3D0)
                            }
                            val checkInTextColor = if (isCheckInLate) {
                                if (isDark) Color(0xFFFCA5A5) else Color(0xFF991B1B)
                            } else {
                                if (isDark) Color(0xFF6EE7B7) else Color(0xFF065F46)
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = checkInBg,
                                border = BorderStroke(0.8.dp, checkInBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 3.5.dp)
                                ) {
                                    Text(
                                        text = formatTimeTo12HourArabic(attendance.actualCheckIn),
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = checkInTextColor
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("📥", fontSize = 10.sp)
                                }
                            }
                        }

                        // Check-out Time Badge (Blue / Red / Amber)
                        if (attendance.actualCheckOut.isNotEmpty()) {
                            val isEarly = attendance.checkOutDifferenceMinutes < 0
                            val isLate = attendance.checkOutDifferenceMinutes > 0
                            val (checkOutBg, checkOutBorder, checkOutTextColor) = when {
                                isEarly -> Triple(
                                    if (isDark) Color(0xFF78350F).copy(alpha = 0.4f) else Color(0xFFFFFBEB),
                                    if (isDark) Color(0xFFF59E0B).copy(alpha = 0.6f) else Color(0xFFFDE68A),
                                    if (isDark) Color(0xFFFCD34D) else Color(0xFF92400E)
                                )
                                isLate -> Triple(
                                    if (isDark) Color(0xFF334155).copy(alpha = 0.4f) else Color(0xFFF8FAFC),
                                    if (isDark) Color(0xFF64748B).copy(alpha = 0.6f) else Color(0xFFCBD5E1),
                                    if (isDark) Color(0xFFE2E8F0) else Color(0xFF334155)
                                )
                                else -> Triple(
                                    if (isDark) Color(0xFF1E3A8A).copy(alpha = 0.4f) else Color(0xFFEFF6FF),
                                    if (isDark) Color(0xFF3B82F6).copy(alpha = 0.6f) else Color(0xFFBFDBFE),
                                    if (isDark) Color(0xFF93C5FD) else Color(0xFF1E40AF)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = checkOutBg,
                                border = BorderStroke(0.8.dp, checkOutBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 3.5.dp)
                                ) {
                                    Text(
                                        text = formatTimeTo12HourArabic(attendance.actualCheckOut),
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = checkOutTextColor
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("📤", fontSize = 10.sp)
                                }
                            }
                        }
                    }
                } else if (attendance.status.isNotEmpty() && attendance.status != "لم يسجل") {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (attendance.status) {
                            "غياب" -> if (isDark) Color(0xFF7F1D1D).copy(alpha = 0.3f) else Color(0xFFFEE2E2)
                            "مستأذن" -> if (isDark) Color(0xFF0C4A6E).copy(alpha = 0.3f) else Color(0xFFE0F2FE)
                            "إجازة" -> if (isDark) Color(0xFF78350F).copy(alpha = 0.3f) else Color(0xFFFEF3C7)
                            else -> if (isDark) Color(0xFF334155).copy(alpha = 0.3f) else Color(0xFFF1F5F9)
                        },
                        border = BorderStroke(0.8.dp, when (attendance.status) {
                            "غياب" -> Color(0xFFEF4444).copy(alpha = 0.4f)
                            "مستأذن" -> Color(0xFF0284C7).copy(alpha = 0.4f)
                            "إجازة" -> Color(0xFFF59E0B).copy(alpha = 0.4f)
                            else -> Color(0xFF94A3B8).copy(alpha = 0.4f)
                        }),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(
                            text = when (attendance.status) {
                                "غياب" -> "غائب اليوم 🔴"
                                "مستأذن" -> "مستأذن اليوم 🔵"
                                "إجازة" -> "في إجازة اليوم 🟡"
                                else -> "لم تسجل حركة اليوم ⚪"
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (attendance.status) {
                                "غياب" -> Color(0xFFDC2626)
                                "مستأذن" -> Color(0xFF0284C7)
                                "إجازة" -> Color(0xFFD97706)
                                else -> Color(0xFF64748B)
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            // Expanded Section (Matching Screenshot)
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val hasCheckedIn = attendance.status == "حضور"
                    val hasCheckedOut = attendance.actualCheckOut.isNotEmpty()

                    // Quick action buttons when pending registration
                    if (!hasCheckedIn && (attendance.status == "لم يسجل" || attendance.status.isEmpty())) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Button(
                                onClick = { onCheckInNow() },
                                enabled = isEditable,
                                modifier = Modifier.weight(1f).height(34.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(Icons.Default.Login, contentDescription = null, modifier = Modifier.size(11.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("حضور الآن", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { onCheckInCourseTime() },
                                enabled = isEditable,
                                modifier = Modifier.weight(1f).height(34.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(11.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("حضور الدورة", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onAbsent() },
                                enabled = isEditable,
                                modifier = Modifier.weight(1f).height(30.dp),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(0.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626))
                            ) {
                                Text("🔴 غياب", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { onExcused() },
                                enabled = isEditable,
                                modifier = Modifier.weight(1f).height(30.dp),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(0.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF0284C7))
                            ) {
                                Text("🔵 مستأذن", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { onLeave() },
                                enabled = isEditable,
                                modifier = Modifier.weight(1f).height(30.dp),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(0.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD97706))
                            ) {
                                Text("🟡 إجازة", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (hasCheckedIn && !hasCheckedOut) {
                        if (attendance.isOnBreak || (attendance.breakStartTime.isNotEmpty() && attendance.breakActualReturnTime.isEmpty())) {
                            Button(
                                onClick = { onBreakEnd() },
                                enabled = isEditable,
                                modifier = Modifier.fillMaxWidth().height(32.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("رجوع من الاستراحة ↩️", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (attendance.breakActualReturnTime.isNotEmpty() || attendance.breakStartTime.isEmpty()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Button(
                                    onClick = { onCheckOutNow() },
                                    enabled = isEditable,
                                    modifier = Modifier.weight(1f).height(34.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(11.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("انصراف الآن", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { onCheckOutCourseTime() },
                                    enabled = isEditable,
                                    modifier = Modifier.weight(1f).height(34.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569)),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(11.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("انصراف الدورة", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // --- 1. Movement Details Container (صندوق الأوقات والشارات الصريحة) ---
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = if (isDark) Color(0xFF1E293B) else Color(0xFFF8FAFC),
                        border = BorderStroke(0.8.dp, if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Row A: Times (دخول / انصراف)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // دخول
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("📥", fontSize = 13.sp)
                                    Text(
                                        text = "دخول: ${if (attendance.actualCheckIn.isNotEmpty()) formatTimeTo12HourArabic(attendance.actualCheckIn) else "--:--"}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp,
                                        color = if (attendance.actualCheckIn.isNotEmpty()) Color(0xFF15803D) else Color.Gray
                                    )
                                }

                                // انصراف
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("📤", fontSize = 13.sp)
                                    Text(
                                        text = "انصراف: ${if (attendance.actualCheckOut.isNotEmpty()) formatTimeTo12HourArabic(attendance.actualCheckOut) else "--:--"}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp,
                                        color = if (attendance.actualCheckOut.isNotEmpty()) Color(0xFF991B1B) else Color.Gray
                                    )
                                }
                            }

                            // Row B: Status Badges (دخول مثالي / انصراف متأخر)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Check-in Badge
                                if (attendance.actualCheckIn.isNotEmpty()) {
                                    val isLate = attendance.checkInDelayMinutes > 0
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isLate) Color(0xFFFEE2E2) else Color(0xFFDCFCE7),
                                        border = BorderStroke(0.8.dp, if (isLate) Color(0xFFEF4444).copy(alpha = 0.4f) else Color(0xFF22C55E).copy(alpha = 0.4f))
                                    ) {
                                        Text(
                                            text = if (isLate) "🔴 دخول متأخر (${attendance.checkInDelayMinutes} د)" else "🎯 دخول مثالي",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isLate) Color(0xFFDC2626) else Color(0xFF15803D),
                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.5.dp)
                                        )
                                    }
                                } else {
                                    Spacer(modifier = Modifier.width(1.dp))
                                }

                                // Check-out Badge
                                if (attendance.actualCheckOut.isNotEmpty()) {
                                    val isEarly = attendance.checkOutDifferenceMinutes < 0
                                    val isLate = attendance.checkOutDifferenceMinutes > 0
                                    val diffAbs = kotlin.math.abs(attendance.checkOutDifferenceMinutes)
                                    val badgeInfo = when {
                                        isEarly -> BadgeStyle("🔴 انصراف مبكر ($diffAbs د)", Color(0xFFFEE2E2), Color(0xFFDC2626), Color(0xFFEF4444))
                                        isLate -> BadgeStyle("🔴 انصراف متأخر ($diffAbs د)", Color(0xFFFEE2E2), Color(0xFFB91C1C), Color(0xFFEF4444))
                                        else -> BadgeStyle("🎯 انصراف مثالي", Color(0xFFDCFCE7), Color(0xFF15803D), Color(0xFF22C55E))
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = badgeInfo.bg,
                                        border = BorderStroke(0.8.dp, badgeInfo.border.copy(alpha = 0.4f))
                                    ) {
                                        Text(
                                            text = badgeInfo.text,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = badgeInfo.textColor,
                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.5.dp)
                                        )
                                    }
                                } else if (attendance.actualCheckIn.isNotEmpty()) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color(0xFFFFFBEB),
                                        border = BorderStroke(0.8.dp, Color(0xFFF59E0B).copy(alpha = 0.4f))
                                    ) {
                                        Text(
                                            text = "⏳ في انتظار الانصراف",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFD97706),
                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.5.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // --- 2. Engagement & Stars (شريط التفاعل والتقييم) ---
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 2.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Stars
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("نجوم المشاركة:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isDark) Color(0xFFF1F5F9) else DawamiNavy)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                for (star in 1..5) {
                                    Icon(
                                        imageVector = if (star <= attendance.participationStars) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "Star $star",
                                        tint = if (star <= attendance.participationStars) Color(0xFFFBBF24) else Color.LightGray,
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clickable(enabled = isEditable) {
                                                onSaveStars(star)
                                            }
                                    )
                                }
                                if (attendance.participationStars > 0) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Reset Stars",
                                        tint = Color.Red.copy(alpha = 0.7f),
                                        modifier = Modifier
                                            .padding(start = 4.dp)
                                            .size(16.dp)
                                            .clickable(enabled = isEditable) {
                                                onSaveStars(0)
                                            }
                                    )
                                }
                            }
                        }

                        // Engagement % and Bar
                        Column(
                            horizontalAlignment = Alignment.Start,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "تفاعل الطالب: ${attendance.participationStars * 20}%",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color(0xFFF1F5F9) else DawamiNavy
                            )
                            Box(
                                modifier = Modifier
                                    .width(80.dp)
                                    .height(5.dp)
                                    .background(Color(0xFFE2E8F0), RoundedCornerShape(2.5.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(fraction = (attendance.participationStars / 5f).coerceIn(0f, 1f))
                                        .background(
                                            when (attendance.participationStars) {
                                                5 -> Color(0xFF22C55E)
                                                4 -> Color(0xFF10B981)
                                                3 -> Color(0xFF3B82F6)
                                                2 -> Color(0xFFF59E0B)
                                                1 -> Color(0xFFEF4444)
                                                else -> Color.Transparent
                                            },
                                            RoundedCornerShape(2.5.dp)
                                        )
                                )
                            }
                        }
                    }

                    // --- 3. Cumulative Delay & Absences Card (السجل التراكمي للغياب والتأخير) ---
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF1E293B) else Color(0xFFF8FAFC)),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(0.8.dp, if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "📊 السجل التراكمي للغياب والتأخير في هذه الدورة:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color(0xFFF1F5F9) else DawamiNavy
                            )

                            // Cumulative Delay
                            val delayPercentage = if (maxCumulativeDelay > 0) {
                                (totalDelayMinutes.toFloat() / maxCumulativeDelay).coerceIn(0f, 1f)
                            } else 0f

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.AccessTime,
                                        contentDescription = null,
                                        tint = if (totalDelayMinutes > maxCumulativeDelay) Color.Red else (if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        "التأخير التراكمي: $totalDelayMinutes دقيقة / $maxCumulativeDelay د",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isDark) Color(0xFFE2E8F0) else Color(0xFF334155)
                                    )
                                }
                                if (totalDelayMinutes > maxCumulativeDelay) {
                                    Text("⚠️ تجاوز الحد", fontSize = 9.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(3.dp)
                                    .background(Color(0xFFE2E8F0), RoundedCornerShape(1.5.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(fraction = delayPercentage)
                                        .background(
                                            if (totalDelayMinutes > maxCumulativeDelay) Color.Red else Color(0xFFF59E0B),
                                            RoundedCornerShape(1.5.dp)
                                        )
                                )
                            }

                            // Cumulative Absences
                            val isAbsenceWarning = totalAbsences >= 3

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Cancel,
                                        contentDescription = null,
                                        tint = if (isAbsenceWarning) Color.Red else (if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        "الغياب التراكمي: $totalAbsences أيام",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color(0xFFE2E8F0) else Color(0xFF334155)
                                    )
                                }
                                if (isAbsenceWarning) {
                                    Text("🚨 إنذار غياب", fontSize = 10.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Red Warning Progress Bar (matching screenshot)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .background(
                                        if (isAbsenceWarning) Color(0xFFDC2626) else Color(0xFFE2E8F0),
                                        RoundedCornerShape(2.dp)
                                    )
                            )
                        }
                    }

                    // --- 3.5. Exam Grading Section (رصد درجات الامتحان النهائي للمادة) ---
                    if (isExamDay) {
                        val dbAllGradeConfigs by viewModel.dbAllGradeConfigs.collectAsState()
                        val currentConfig = dbAllGradeConfigs.find { it.courseId == attendance.courseId }
                        val isDiploma = currentConfig?.isDiploma == true
                        val dbAllGrades by viewModel.dbAllGrades.collectAsState()
                        val existingGrade = dbAllGrades.find {
                            it.studentId == attendance.studentId &&
                            it.courseId == attendance.courseId &&
                            it.subjectName.trim().equals(attendance.subjectName.trim(), ignoreCase = true)
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF1E1B4B) else Color(0xFFEEF2FF)),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.2.dp, if (isDark) Color(0xFF4F46E5) else Color(0xFFC7D2FE))
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("📝", fontSize = 14.sp)
                                    Text(
                                        text = "رصد درجات الامتحان النهائي للمادة:",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color(0xFFC7D2FE) else Color(0xFF3730A3)
                                    )
                                }

                                if (attendance.status != "حضور") {
                                    Text(
                                        text = "⚠️ يجب تسجيل حضور الطالب أولاً لرصد درجة الامتحان.",
                                        fontSize = 9.5.sp,
                                        color = Color.Red.copy(alpha = 0.8f),
                                        fontWeight = FontWeight.Medium
                                    )
                                } else {
                                    if (isDiploma) {
                                        var theoryInput by remember(existingGrade) { mutableStateOf(existingGrade?.theoreticalExamScore?.toString() ?: "0") }
                                        var practicalInput by remember(existingGrade) { mutableStateOf(existingGrade?.practicalExamScore?.toString() ?: "0") }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedTextField(
                                                value = theoryInput,
                                                onValueChange = { theoryInput = it },
                                                label = { Text("نظري (من 20)", fontSize = 9.sp) },
                                                modifier = Modifier.weight(1f),
                                                textStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                                                singleLine = true,
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                            )

                                            OutlinedTextField(
                                                value = practicalInput,
                                                onValueChange = { practicalInput = it },
                                                label = { Text("عملي (من 40)", fontSize = 9.sp) },
                                                modifier = Modifier.weight(1f),
                                                textStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                                                singleLine = true,
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                            )

                                            Button(
                                                onClick = {
                                                    val tScore = theoryInput.toDoubleOrNull() ?: 0.0
                                                    val pScore = practicalInput.toDoubleOrNull() ?: 0.0
                                                    val baseGrade = existingGrade ?: StudentGrade(
                                                        studentId = attendance.studentId,
                                                        studentName = attendance.studentName,
                                                        courseId = attendance.courseId,
                                                        courseName = attendance.courseName,
                                                        subjectName = attendance.subjectName,
                                                        isDiploma = true
                                                    )
                                                    val updated = baseGrade.copy(
                                                        theoreticalExamScore = tScore.coerceIn(0.0, 20.0),
                                                        practicalExamScore = pScore.coerceIn(0.0, 40.0)
                                                    )
                                                    viewModel.saveStudentGrade(updated)
                                                },
                                                modifier = Modifier.height(38.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = if (isDark) Color(0xFF4F46E5) else Color(0xFF4F46E5)),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text("حفظ", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    } else {
                                        var finalScoreInput by remember(existingGrade) {
                                            mutableStateOf(existingGrade?.getManualFinalScore()?.toString() ?: existingGrade?.getTotalScore()?.toString() ?: "0")
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedTextField(
                                                value = finalScoreInput,
                                                onValueChange = { finalScoreInput = it },
                                                label = { Text("الدرجة النهائية مباشرة", fontSize = 9.sp) },
                                                modifier = Modifier.weight(1f),
                                                textStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                                                singleLine = true,
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                            )

                                            Button(
                                                onClick = {
                                                    val fScore = finalScoreInput.toDoubleOrNull() ?: 0.0
                                                    val baseGrade = existingGrade ?: StudentGrade(
                                                        studentId = attendance.studentId,
                                                        studentName = attendance.studentName,
                                                        courseId = attendance.courseId,
                                                        courseName = attendance.courseName,
                                                        subjectName = attendance.subjectName,
                                                        isDiploma = false
                                                    )
                                                    val updated = baseGrade.withManualFinalGrading(fScore)
                                                    viewModel.saveStudentGrade(updated)
                                                },
                                                modifier = Modifier.height(38.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = if (isDark) Color(0xFF4F46E5) else Color(0xFF4F46E5)),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text("حفظ", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // --- 4. Teacher's Daily Course Note (مكان الملاحظة اليومية للأستاذ عند إضافتها) ---
                    val effectiveTeacherDailyNote = if (dailyNoteText.isNotBlank()) dailyNoteText else attendance.courseDailyNote
                    if (effectiveTeacherDailyNote.isNotBlank()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = if (isDark) Color(0xFF292524) else Color(0xFFFFFBEB),
                            border = BorderStroke(1.dp, if (isDark) Color(0xFF78350F) else Color(0xFFFDE68A))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("📢", fontSize = 15.sp)
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = "ملاحظة الأستاذ اليومية للدورة:",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.5.sp,
                                        color = if (isDark) DawamiGold else DawamiNavy
                                    )
                                    Text(
                                        text = effectiveTeacherDailyNote,
                                        fontSize = 10.5.sp,
                                        color = if (isDark) Color(0xFFE2E8F0) else Color(0xFF1E293B)
                                    )
                                }
                            }
                        }
                    }

                    // --- 5. Individual Student Note & Funny Penalty (ملاحظة الطالب الفردية والعقوبة الفكاهية) ---
                    val cardContext = LocalContext.current
                    var noteText by remember(attendance.studentNote) { mutableStateOf(attendance.studentNote) }
                    var showStudentFunnyPenaltyDialog by remember { mutableStateOf(false) }

                    if (showStudentFunnyPenaltyDialog) {
                        com.example.ui.components.FunnyPenaltyDialog(
                            studentName = attendance.studentName,
                            onDismiss = { showStudentFunnyPenaltyDialog = false },
                            onApplyPenalty = { penalty ->
                                val updatedNote = if (noteText.isBlank()) {
                                    "🎭 [العقوبة الفكاهية]: $penalty"
                                } else {
                                    "$noteText | 🎭 [العقوبة الفكاهية]: $penalty"
                                }
                                noteText = updatedNote
                                onSaveNote(updatedNote)
                                Toast.makeText(cardContext, "تمت إضافة العقوبة الفكاهية لملاحظة الطالب 🎭", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "ملاحظة الطالب الفردية 📝",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color(0xFFF1F5F9) else DawamiNavy
                        )
                        Surface(
                            onClick = { showStudentFunnyPenaltyDialog = true },
                            enabled = isEditable,
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEF3C7),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(horizontal = 10.dp)
                            ) {
                                Text(
                                    "عقوبة فكاهية 🎭",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFB45309)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        enabled = isEditable,
                        value = noteText,
                        onValueChange = { noteText = it },
                        placeholder = { Text("اكتب ملاحظة خاصة بالتحضير والسلوك...", fontSize = 10.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(fontSize = 11.sp),
                        trailingIcon = {
                            if (noteText != attendance.studentNote) {
                                IconButton(onClick = { onSaveNote(noteText) }) {
                                    Icon(Icons.Default.Check, contentDescription = "حفظ الملاحظة", tint = Color(0xFF16A34A))
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DawamiNavy,
                            unfocusedBorderColor = if (isDark) Color(0xFF475569) else Color(0xFFCBD5E1)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }
        }
    }
}

data class GroupHeader(val title: String, val size: Int, val isExpanded: Boolean)

@Composable
fun InstituteReportHeader(viewModel: com.example.ui.viewmodel.MainViewModel, reportTitle: String = "تقرير الحضور") {
    val instituteName by viewModel.instituteName.collectAsState()
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DawamiNavy)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val titleText = if (instituteName.isNotBlank() && instituteName != "المعهد المهني المتميز") {
                "$instituteName - $reportTitle"
            } else {
                reportTitle
            }
            Text(titleText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }
}

fun formatArabicDateHeader(dateStr: String): String {
    return dateStr
}

@Composable
fun CompactStudentSelectionCard(
    attendance: StudentAttendance,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = com.example.ui.theme.LocalThemePreset.current.isDark
    val cardBg = if (isSelected) {
        if (isDark) {
            when (attendance.status) {
                "حضور" -> Color(0xFF064E3B).copy(alpha = 0.4f)
                "غياب" -> Color(0xFF7F1D1D).copy(alpha = 0.4f)
                "إجازة" -> Color(0xFF78350F).copy(alpha = 0.4f)
                else -> Color(0xFF1E293B)
            }
        } else {
            when (attendance.status) {
                "حضور" -> Color(0xFFDCFCE7)
                "غياب" -> Color(0xFFFEE2E2)
                "إجازة" -> Color(0xFFFEF3C7)
                else -> Color(0xFFEFF6FF)
            }
        }
    } else MaterialTheme.colorScheme.surface

    val cardBorder = if (isSelected) {
        when (attendance.status) {
            "حضور" -> BorderStroke(1.5.dp, if (isDark) Color(0xFF34D399) else Color(0xFF16A34A))
            "غياب" -> BorderStroke(1.5.dp, if (isDark) Color(0xFFF87171) else Color(0xFFDC2626))
            "إجازة" -> BorderStroke(1.5.dp, if (isDark) Color(0xFFFBBF24) else Color(0xFFD97706))
            else -> BorderStroke(1.5.dp, DawamiNavy)
        }
    } else BorderStroke(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))

    val textColor = if (isSelected) {
        if (isDark) {
            when (attendance.status) {
                "حضور" -> Color(0xFF34D399)
                "غياب" -> Color(0xFFF87171)
                "إجازة" -> Color(0xFFFBBF24)
                else -> Color.White
            }
        } else {
            when (attendance.status) {
                "حضور" -> Color(0xFF15803D)
                "غياب" -> Color(0xFFB91C1C)
                "إجازة" -> Color(0xFFB45309)
                else -> DawamiNavy
            }
        }
    } else (if (isDark) Color.White else DawamiNavy)

    val checkboxColor = when (attendance.status) {
        "حضور" -> if (isDark) Color(0xFF34D399) else Color(0xFF16A34A)
        "غياب" -> if (isDark) Color(0xFFF87171) else Color(0xFFDC2626)
        "إجازة" -> if (isDark) Color(0xFFFBBF24) else Color(0xFFD97706)
        else -> DawamiNavy
    }

    val statusDotColor = when (attendance.status) {
        "حضور" -> Color(0xFF10B981)
        "غياب" -> Color(0xFFEF4444)
        "إجازة" -> Color(0xFFF59E0B)
        else -> Color(0xFF94A3B8)
    }

    Card(
        modifier = modifier
            .clickable { onToggleSelect() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = cardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 2.dp else 0.5.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(statusDotColor)
                )
                Text(
                    text = attendance.studentName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = textColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelect() },
                colors = CheckboxDefaults.colors(checkedColor = checkboxColor),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

data class StudentBatchData(
    val studentName: String,
    val phoneNumber: String,
    val messageText: String
)

@Composable
fun BatchWhatsAppShareDialog(
    onDismiss: () -> Unit,
    batchList: List<StudentBatchData>,
    currentIndex: Int,
    onIndexChanged: (Int) -> Unit,
    context: android.content.Context
) {
    if (batchList.isEmpty() || currentIndex < 0 || currentIndex >= batchList.size) {
        onDismiss()
        return
    }

    val currentItem = batchList[currentIndex]
    
    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 12.dp),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = null,
                    tint = DawamiNavy
                )
                Text(
                    text = "إرسال جماعي فردي بالواتساب 📱",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DawamiNavy
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val progress = (currentIndex + 1).toFloat() / batchList.size.toFloat()
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "الطالب الحالي: ${currentItem.studentName}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${currentIndex + 1} / ${batchList.size}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = DawamiNavy
                        )
                    }
                    LinearProgressIndicator(
                        progress = progress,
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = Color(0xFF25D366),
                        trackColor = Color(0xFFF1F5F9)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("رقم الهاتف المسجل:", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                    Text(
                        text = if (currentItem.phoneNumber.isNotEmpty()) currentItem.phoneNumber else "⚠️ غير مضاف! يرجى إضافة الرقم أولاً",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentItem.phoneNumber.isNotEmpty()) MaterialTheme.colorScheme.onSurface else Color.Red
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("معاينة الرسالة الخاصة به:", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 150.dp)
                            .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                            .verticalScroll(rememberScrollState())
                            .padding(8.dp)
                    ) {
                        Text(
                            text = currentItem.messageText,
                            fontSize = 10.sp,
                            lineHeight = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        },
        confirmButton = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = {
                            if (currentItem.phoneNumber.isEmpty()) {
                                Toast.makeText(context, "لا يمكن الإرسال لعدم وجود رقم هاتف مسجل!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            try {
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    data = Uri.parse("https://api.whatsapp.com/send?phone=${currentItem.phoneNumber}&text=${Uri.encode(currentItem.messageText)}")
                                    setPackage("com.whatsapp")
                                }
                                context.startActivity(intent)
                                
                                if (currentIndex + 1 < batchList.size) {
                                    onIndexChanged(currentIndex + 1)
                                } else {
                                    Toast.makeText(context, "تهانينا! اكتمل إرسال الكشف للجميع 🎉", Toast.LENGTH_LONG).show()
                                    onDismiss()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(context, "الرجاء تثبيت تطبيق واتساب العادي، أو استخدم واتساب الأعمال", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("واتساب العادي", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            if (currentItem.phoneNumber.isEmpty()) {
                                Toast.makeText(context, "لا يمكن الإرسال لعدم وجود رقم هاتف مسجل!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            try {
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    data = Uri.parse("https://api.whatsapp.com/send?phone=${currentItem.phoneNumber}&text=${Uri.encode(currentItem.messageText)}")
                                    setPackage("com.whatsapp.w4b")
                                }
                                context.startActivity(intent)
                                
                                if (currentIndex + 1 < batchList.size) {
                                    onIndexChanged(currentIndex + 1)
                                } else {
                                    Toast.makeText(context, "تهانينا! اكتمل إرسال الكشف للجميع 🎉", Toast.LENGTH_LONG).show()
                                    onDismiss()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(context, "تطبيق واتساب الأعمال غير مثبت على جهازك", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("واتساب الأعمال", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (currentIndex > 0) {
                        OutlinedButton(
                            onClick = { onIndexChanged(currentIndex - 1) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("⬅️ السابق", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            if (currentIndex + 1 < batchList.size) {
                                onIndexChanged(currentIndex + 1)
                            } else {
                                Toast.makeText(context, "وصلت لآخر طالب في الكشف", Toast.LENGTH_SHORT).show()
                                onDismiss()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("تخطي ➡️", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إلغاء وإغلاق النافذة ❌", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                }
            }
        },
        shape = RoundedCornerShape(12.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )
}

fun generateIndividualAttendanceMessage(
    studentName: String,
    status: String,
    checkIn: String,
    checkOut: String,
    note: String,
    courseName: String,
    date: String,
    institute: String,
    includeLessonTopics: Boolean,
    viewModel: MainViewModel
): String {
    val sb = StringBuilder()
    sb.append("📊 تقرير الحركة اليومية الفردي 📝\n\n")
    sb.append("👤 الطالب: $studentName\n")
    sb.append("📅 التاريخ: $date\n")
    if (courseName.isNotEmpty()) {
        sb.append("📚 الدورة: $courseName\n")
    }
    sb.append("----------------------------------------\n")
    val statusEmoji = when (status) {
        "حضور" -> "حضور ✅"
        "غياب" -> "غياب ❌"
        "إجازة" -> "إجازة ✉️"
        "تأخير" -> "تأخير ⏳"
        else -> status
    }
    sb.append("📌 الحالة اليومية: $statusEmoji\n")
    if (checkIn.isNotEmpty()) sb.append("⏰ وقت الحضور: ${formatTimeTo12HourArabic(checkIn)}\n")
    if (checkOut.isNotEmpty()) sb.append("⏰ وقت الانصراف: ${formatTimeTo12HourArabic(checkOut)}\n")
    if (note.isNotEmpty()) sb.append("✍️ ملاحظة: $note\n")
    
    if (includeLessonTopics) {
        val lessonTopics = viewModel.dbLessonTopics.value
        val sessionTopics = viewModel.dbLessonSessionTopics.value
        val subjects = viewModel.dbSubjects.value
        val todaySessionTopics = sessionTopics.filter { st ->
            if (st.courseId != viewModel.selectedCourseForStudents.value?.id || st.date != date) false
            else {
                val topic = lessonTopics.find { it.id == st.topicId }
                topic != null && topic.level <= 2
            }
        }

        if (todaySessionTopics.isNotEmpty()) {
            sb.append("----------------------------------------\n")
            sb.append("📚 الدروس المشروحة اليوم:\n")
            todaySessionTopics.forEachIndexed { idx, st ->
                val topic = lessonTopics.find { it.id == st.topicId }
                val subject = subjects.find { it.id == (topic?.subjectId ?: st.subjectId) }
                val subjectTag = if (subject != null) " [📖 ${subject.name}]" else ""
                val statusStr = if (st.isCompleted) "🟢 تم الشرح" else "⏳ قيد الشرح"
                sb.append("${idx + 1}. ${topic?.title ?: "موضوع"}$subjectTag - $statusStr\n")
            }
        }
    }
    
    sb.append("----------------------------------------\n")
    sb.append("شاكرين لكم حسن المتابعة والإشراف 🌹\n")
    val c = viewModel.selectedCourseForStudents.value
    if (!c?.trainerName.isNullOrBlank()) {
        sb.append("المدرب المعتمد: ${c?.trainerName}\n")
    }
    if (!c?.departmentName.isNullOrBlank()) {
        sb.append("القسم: ${c?.departmentName}\n")
    }
    sb.append("المعهد: $institute")
    return sb.toString()
}

data class CourseTimeChoiceData(
    val title: String,
    val subtitle: String,
    val defaultCourseTime: String,
    val toolTime: String,
    val onConfirm: (chosenTime: String) -> Unit
)

data class CheckInNowFeedbackData(
    val title: String,
    val subtitle: String,
    val actualTime: String,
    val courseStartTime: String,
    val onConfirm: (actualTime: String) -> Unit
)

private fun calculateTimeDiffMinutes(timeStr: String, baseTimeStr: String): Int {
    return try {
        val parts1 = timeStr.split(":").map { it.trim().toInt() }
        val parts2 = baseTimeStr.split(":").map { it.trim().toInt() }
        val m1 = parts1[0] * 60 + parts1[1]
        val m2 = parts2[0] * 60 + parts2[1]
        m1 - m2
    } catch (e: Exception) {
        0
    }
}

enum class StudentConfirmType {
    CHECK_IN, CHECK_OUT, ABSENT, EXCUSED, LEAVE, RESET
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun StudentUnifiedAttendanceDialog(
    viewModel: MainViewModel,
    confirmActionType: StudentConfirmType,
    targetStudentIds: Set<Int>,
    onConfirm: (time: String, trainerSync: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val studentAttendanceList by viewModel.studentAttendanceList.collectAsState()
    val selectedCourse by viewModel.selectedCourseForStudentAttendance.collectAsState()
    val attendanceDate by viewModel.studentAttendanceDateInput.collectAsState()
    val attendanceDay by viewModel.studentAttendanceDayInput.collectAsState()

    val fieldCheckIn by viewModel.studentCheckInTimeInput.collectAsState()
    val fieldCheckOut by viewModel.studentCheckOutTimeInput.collectAsState()

    // Find trainer record for sync info
    val dbAttendance by viewModel.dbAttendance.collectAsState()
    val trainerRecordForDay = dbAttendance.find { it.courseId == selectedCourse?.id && it.date == attendanceDate }
    val trainerCheckedOut = trainerRecordForDay != null && trainerRecordForDay.actualCheckOut.isNotEmpty()
    val trainerCheckOutTime = trainerRecordForDay?.actualCheckOut ?: ""

    val currentTime = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date()) }
    val isCheckIn = confirmActionType == StudentConfirmType.CHECK_IN
    val isCheckOut = confirmActionType == StudentConfirmType.CHECK_OUT

    val initialTime = when {
        isCheckIn -> if (fieldCheckIn.isNotEmpty()) fieldCheckIn else currentTime
        isCheckOut -> if (fieldCheckOut.isNotEmpty()) fieldCheckOut else currentTime
        else -> currentTime
    }

    var confirmSelectedTime by remember { mutableStateOf(initialTime) }
    var trainerSyncEnabled by remember { mutableStateOf(!trainerCheckedOut && isCheckOut) }

    val targetStudents = studentAttendanceList.filter { it.studentId in targetStudentIds }

    // --- Logic for Unrecorded Students Handling ---
    val readyForCheckOut = targetStudents.filter { it.actualCheckIn.isNotEmpty() && it.actualCheckOut.isEmpty() }
    val unrecordedStudents = targetStudents.filter { it.actualCheckIn.isEmpty() && it.actualCheckOut.isEmpty() }
    
    // Action for unrecorded students: null (skip), "ABSENT", "EXCUSED", "CHECK_IN", "LEAVE"
    var unrecordedAction by remember { mutableStateOf<String?>(if (unrecordedStudents.isNotEmpty() && isCheckOut) "ABSENT" else null) }

    val studentNames = if (isCheckOut && unrecordedStudents.isNotEmpty()) {
        readyForCheckOut.map { it.studentName }
    } else {
        targetStudents.map { it.studentName }
    }

    val actionTitle = when (confirmActionType) {
        StudentConfirmType.CHECK_IN -> "تأكيد تسجيل حضور الطلاب 📥"
        StudentConfirmType.CHECK_OUT -> "تأكيد تسجيل انصراف الطلاب 📤"
        StudentConfirmType.ABSENT -> "تأكيد تسجيل غياب الطلاب ❌"
        StudentConfirmType.EXCUSED -> "تأكيد تسجيل استئذان الطلاب 🔵"
        StudentConfirmType.LEAVE -> "تأكيد تسجيل إجازة الطلاب 🟡"
        StudentConfirmType.RESET -> "تأكيد إعادة تعيين الحركة 🔄"
    }

    val themeColor = when (confirmActionType) {
        StudentConfirmType.CHECK_IN -> DawamiNavy
        StudentConfirmType.CHECK_OUT -> DawamiTeal
        StudentConfirmType.ABSENT -> Color(0xFFDC2626)
        StudentConfirmType.EXCUSED -> Color(0xFF0284C7)
        StudentConfirmType.LEAVE -> Color(0xFFD97706)
        StudentConfirmType.RESET -> Color(0xFF64748B)
    }

    val schedTime = if (isCheckIn) (selectedCourse?.startTime ?: "") else if (isCheckOut) (selectedCourse?.endTime ?: "") else ""
    val timeDiffMinutes = remember(confirmSelectedTime, schedTime) {
        if (schedTime.isNotEmpty()) calculateTimeDiffMinutes(confirmSelectedTime, schedTime) else 0
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.92f).wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier.size(44.dp).clip(CircleShape).background(themeColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (confirmActionType) {
                                StudentConfirmType.CHECK_IN -> Icons.Default.Login
                                StudentConfirmType.CHECK_OUT -> Icons.Default.Logout
                                StudentConfirmType.ABSENT -> Icons.Default.Close
                                StudentConfirmType.EXCUSED -> Icons.Default.Info
                                StudentConfirmType.LEAVE -> Icons.Default.DateRange
                                StudentConfirmType.RESET -> Icons.Default.Refresh
                            },
                            contentDescription = null,
                            tint = themeColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(text = actionTitle, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DawamiNavy)
                        Text(text = "تأكيد البيانات قبل الحفظ النهائي", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                // Students List Summary
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        val countText = if (isCheckOut && unrecordedStudents.isNotEmpty()) {
                            "الطلاب الجاهزون للانصراف (${readyForCheckOut.size}):"
                        } else {
                            "الطلاب المستهدفين (${targetStudentIds.size}):"
                        }
                        Text(text = countText, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        Text(
                            text = studentNames.joinToString(" • ").ifEmpty { "لا يوجد طلاب مؤهلون حالياً" },
                            fontSize = 10.sp,
                            color = DawamiNavy.copy(alpha = 0.8f),
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), thickness = 0.5.dp, color = Color.LightGray.copy(alpha = 0.5f))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.School, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(12.dp))
                            Text(text = "الدورة: ${selectedCourse?.name ?: ""}", fontSize = 10.sp, color = DawamiNavy)
                        }
                    }
                }

                // --- Unrecorded Students Section (Only for Check-out) ---
                if (isCheckOut && unrecordedStudents.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFFFFF7ED),
                        border = BorderStroke(1.dp, Color(0xFFFED7AA)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEA580C), modifier = Modifier.size(16.dp))
                                Text(
                                    text = "تنبيه: يوجد (${unrecordedStudents.size}) طلاب لم يسجل دخولهم!",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF9A3412)
                                )
                            }
                            
                            Text(
                                text = "ما هو الإجراء المطلوب لهؤلاء الطلاب؟",
                                fontSize = 10.sp,
                                color = Color(0xFF9A3412).copy(alpha = 0.8f)
                            )

                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val actions = listOf(
                                    Triple("ABSENT", "❌ غياب", Color(0xFFDC2626)),
                                    Triple("EXCUSED", "🔵 استئذان", Color(0xFF0284C7)),
                                    Triple("CHECK_IN", "📥 حضور", Color(0xFF16A34A)),
                                    Triple("LEAVE", "🟡 إجازة", Color(0xFFD97706)),
                                    Triple(null, "⚪ تجاهل", Color(0xFF64748B))
                                )
                                
                                actions.forEach { (key, label, color) ->
                                    val isSel = unrecordedAction == key
                                    Surface(
                                        onClick = { unrecordedAction = key },
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSel) color.copy(alpha = 0.15f) else Color.White,
                                        border = BorderStroke(1.dp, if (isSel) color else Color.LightGray.copy(alpha = 0.4f)),
                                        modifier = Modifier.wrapContentSize()
                                    ) {
                                        Text(
                                            text = label,
                                            fontSize = 9.5.sp,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSel) color else Color.Gray,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                        )
                                    }
                                }
                            }
                            
                            if (unrecordedAction != null) {
                                val actionDesc = when(unrecordedAction) {
                                    "ABSENT" -> "سيتم رصد غياب لهم"
                                    "EXCUSED" -> "سيتم رصد استئذان لهم"
                                    "CHECK_IN" -> "سيتم رصد دخول وانصراف معاً"
                                    "LEAVE" -> "سيتم رصد إجازة لهم"
                                    else -> ""
                                }
                                Text(
                                    text = "💡 $actionDesc لعدد (${unrecordedStudents.size}) طلاب.",
                                    fontSize = 9.sp,
                                    fontStyle = FontStyle.Italic,
                                    color = Color(0xFFC2410C)
                                )
                            }
                        }
                    }
                }

                // Time Display Card
                if (isCheckIn || isCheckOut) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isCheckIn) Color(0xFFF0FDF4) else Color(0xFFF0F9FF),
                        border = BorderStroke(2.dp, if (isCheckIn) Color(0xFF86EFAC) else Color(0xFFBAE6FD)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "⏰ الوقت المسجل في البطاقة:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCheckIn) Color(0xFF166534) else Color(0xFF075985)
                            )
                            Text(
                                text = formatTimeTo12HourArabic(confirmSelectedTime),
                                fontSize = 32.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isCheckIn) Color(0xFF15803D) else Color(0xFF0284C7)
                            )
                            
                            // Feedback analysis
                            if (schedTime.isNotEmpty()) {
                                val feedbackText = if (isCheckIn) {
                                    when {
                                        timeDiffMinutes > 0 -> "⚠️ تأخير بمقدار ($timeDiffMinutes د)"
                                        timeDiffMinutes == 0 -> "✅ في الموعد المجدول"
                                        else -> "⚡ حضور مبكر بـ (${-timeDiffMinutes} د)"
                                    }
                                } else {
                                    when {
                                        timeDiffMinutes < 0 -> "⚠️ انصراف مبكر بـ (${-timeDiffMinutes} د)"
                                        timeDiffMinutes == 0 -> "✅ في موعد الانصراف تماماً"
                                        else -> "ℹ️ انصراف بعد الموعد بـ ($timeDiffMinutes د)"
                                    }
                                }
                                Surface(
                                    color = Color.White.copy(alpha = 0.7f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    Text(
                                        text = feedbackText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Quick Time Options
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("الخيارات السريعة للتوقيت:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            QuickTimeChip(
                                label = "⚡ الآن",
                                isSelected = confirmSelectedTime == currentTime,
                                onClick = { confirmSelectedTime = currentTime }
                            )
                            if (schedTime.isNotEmpty()) {
                                QuickTimeChip(
                                    label = "📅 المجدول",
                                    isSelected = confirmSelectedTime == schedTime,
                                    onClick = { confirmSelectedTime = schedTime }
                                )
                            }
                            val fieldTime = if (isCheckIn) fieldCheckIn else fieldCheckOut
                            if (fieldTime.isNotEmpty() && fieldTime != currentTime && fieldTime != schedTime) {
                                QuickTimeChip(
                                    label = "✏️ وقت الحقل",
                                    isSelected = confirmSelectedTime == fieldTime,
                                    onClick = { confirmSelectedTime = fieldTime }
                                )
                            }
                            if (isCheckOut && trainerCheckedOut) {
                                QuickTimeChip(
                                    label = "👤 وقت الأستاذ",
                                    isSelected = confirmSelectedTime == trainerCheckOutTime,
                                    onClick = { confirmSelectedTime = trainerCheckOutTime }
                                )
                            }
                        }

                        // Fine tune buttons
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("تعديل دقائق:", fontSize = 10.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.width(8.dp))
                            listOf(-5, -1, 1, 5).forEach { delta ->
                                Surface(
                                    onClick = { confirmSelectedTime = adjustTimeMinutes(confirmSelectedTime, delta) },
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.padding(end = 4.dp)
                                ) {
                                    Text(
                                        text = if (delta > 0) "+$delta" else "$delta",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Trainer Sync Checkbox
                if (isCheckOut && !trainerCheckedOut) {
                    Surface(
                        color = DawamiNavy.copy(alpha = 0.05f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth().clickable { trainerSyncEnabled = !trainerSyncEnabled }
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Checkbox(checked = trainerSyncEnabled, onCheckedChange = { trainerSyncEnabled = it }, colors = CheckboxDefaults.colors(checkedColor = DawamiNavy))
                            Column {
                                Text(text = "تسجيل انصراف المدرب أيضاً بنفس الوقت 🎓⏱️", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                Text(text = "سيتم إغلاق يوم التدريب لك وللطلاب في خطوة واحدة", fontSize = 9.sp, color = Color(0xFFB45309))
                            }
                        }
                    }
                }

                // Buttons
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                        Text("تراجع", fontSize = 13.sp)
                    }
                    Button(
                        onClick = { 
                            // Perform extra actions for unrecorded students if needed
                            if (isCheckOut && unrecordedStudents.isNotEmpty() && unrecordedAction != null) {
                                unrecordedStudents.forEach { att ->
                                    when (unrecordedAction) {
                                        "ABSENT" -> viewModel.registerStudentAbsent(att)
                                        "EXCUSED" -> viewModel.registerStudentExcused(att)
                                        "LEAVE" -> viewModel.registerStudentLeave(att)
                                        "CHECK_IN" -> {
                                            viewModel.registerStudentCheckIn(att, confirmSelectedTime)
                                            // Check-out will be handled by the main onConfirm callback
                                        }
                                    }
                                }
                            }
                            onConfirm(confirmSelectedTime, trainerSyncEnabled) 
                        },
                        modifier = Modifier.weight(1.5f),
                        colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                        shape = RoundedCornerShape(12.dp),
                        enabled = !isCheckOut || readyForCheckOut.isNotEmpty() || unrecordedAction != null
                    ) {
                        Text("اعتماد وحفظ ✅", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickTimeChip(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) DawamiNavy.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (isSelected) DawamiNavy else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Text(text = label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium, color = DawamiNavy, modifier = Modifier.padding(vertical = 6.dp, horizontal = 12.dp))
    }
}

private fun adjustTimeMinutes(timeStr: String, deltaMinutes: Int): String {
    try {
        val parts = timeStr.split(":").map { it.trim().toInt() }
        if (parts.size >= 2) {
            var totalMin = parts[0] * 60 + parts[1] + deltaMinutes
            if (totalMin < 0) totalMin += 24 * 60
            totalMin %= (24 * 60)
            val h = totalMin / 60
            val m = totalMin % 60
            return String.format(java.util.Locale.US, "%02d:%02d", h, m)
        }
    } catch (_: Exception) { }
    return timeStr
}


