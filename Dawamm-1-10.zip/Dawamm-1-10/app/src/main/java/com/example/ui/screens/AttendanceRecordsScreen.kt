package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.entity.Attendance
import com.example.data.entity.Course
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import com.example.utils.AudioPlayerHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceRecordsScreen(
    viewModel: MainViewModel,
    attendanceViewModel: AttendanceViewModel? = null,
    showMainLayout: Boolean = true
) {
    val tempAttendance by (attendanceViewModel?.allAttendance ?: viewModel.tempAttendance).collectAsState()
    val activeCourses by viewModel.activeCourses.collectAsState()
    val showCompletedCourses by viewModel.showCompletedCoursesInDropdowns.collectAsState()

    val selectedCourse by viewModel.selectedCourseForAttendance.collectAsState()
    val attendanceDay by viewModel.attendanceDayInput.collectAsState()
    val attendanceDate by viewModel.attendanceDateInput.collectAsState()
    val attendanceCheckIn by viewModel.attendanceCheckInInput.collectAsState()
    val attendanceCheckOut by viewModel.attendanceCheckOutInput.collectAsState()
    val attendanceStatus by viewModel.attendanceStatusInput.collectAsState()

    val checkInAlert by viewModel.checkInAlert.collectAsState()
    val checkOutAlert by viewModel.checkOutAlert.collectAsState()
    val calculatedDurationText by viewModel.calculatedDurationText.collectAsState()
    val selectedAttendanceEdit by viewModel.selectedAttendanceForEdit.collectAsState()
    val attendanceNote by viewModel.attendanceNoteInput.collectAsState()
    val isExamDaySelected by viewModel.isExamDayForNextRecord.collectAsState()

    val allSubjects by viewModel.dbSubjects.collectAsState()
    val dbCourseSubjects by viewModel.dbCourseSubjects.collectAsState()
    val studentAttendanceSelectedSubject by viewModel.studentAttendanceSubjectInput.collectAsState()
    val dbAllStudentAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()

    val context = LocalContext.current
    var isCourseDropdownExpanded by remember { mutableStateOf(false) }
    var isDayDropdownExpanded by remember { mutableStateOf(false) }
    var isSubjectDropdownExpanded by remember { mutableStateOf(false) }
    var isSelectingSubjectForTrainerCheckIn by remember { mutableStateOf(false) }
    var filterSubjectName by remember { mutableStateOf("") }
    var showCompletedSubjectsInAttendance by remember { mutableStateOf(false) }
    var expandedCardIds by remember { mutableStateOf(setOf<Int>()) }
    var isTrainerFormExpanded by remember { mutableStateOf(true) }
    var showTrainerLeaveDialog by remember { mutableStateOf(false) }

    var attendanceToDelete by remember { mutableStateOf<Attendance?>(null) }
    var showDeleteAttendanceConfirmDialog by remember { mutableStateOf(false) }

    var showTrainerOtherStatusConfirmDialog by remember { mutableStateOf(false) }
    var showTrainerEditConfirmDialog by remember { mutableStateOf(false) }
    var showNavigateToStudentsDialog by remember { mutableStateOf(false) }

    var showUnifiedTrainerDialog by remember { mutableStateOf(false) }
    var unifiedDialogMode by remember { mutableStateOf(AttendanceConfirmType.CHECK_IN) }

    var showAbsentSummaryDialog by remember { mutableStateOf(false) }
    var absentSummaryStudentsList by remember { mutableStateOf<List<String>>(emptyList()) }

    var isEditableInPastTrainer by remember(attendanceDate) { mutableStateOf(false) }
    var pendingTrainerStatusChange by remember { mutableStateOf<String?>(null) }
    var showTrainerStatusChangeConfirmDialog by remember { mutableStateOf(false) }

    val daysList = listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")

    val todayStr = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()) }
    val recordedDates = remember(tempAttendance, selectedCourse) {
        if (selectedCourse == null) {
            tempAttendance.map { it.date }.distinct().sorted()
        } else {
            tempAttendance
                .filter { it.courseId == selectedCourse!!.id }
                .map { it.date }
                .distinct()
                .sorted()
        }
    }

    MainLayout(viewModel, showScaffold = showMainLayout) { innerPadding ->
        if (showDeleteAttendanceConfirmDialog && attendanceToDelete != null) {
            val hasActiveStudents = dbAllStudentAttendance.any {
                it.courseId == attendanceToDelete!!.courseId &&
                it.date == attendanceToDelete!!.date &&
                it.status.isNotEmpty() &&
                it.status != "لم يسجل"
            }
            if (hasActiveStudents) {
                AlertDialog(
                    onDismissRequest = { showDeleteAttendanceConfirmDialog = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFDC2626))
                            Text("عذراً، لا يمكن الحذف المباشر! 🚫", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFDC2626))
                        }
                    },
                    text = {
                        Text(
                            text = "تم رصد حركات حضور وانصراف مسجلة للطلاب في هذا اليوم.\n\nيرجى إعادة تعيين حركات الطلاب وحذف حركتك اليوم؟",
                            fontSize = 11.sp
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                attendanceToDelete?.let { record ->
                                    viewModel.deleteStudentAttendancesForDate(record.courseId, record.date)
                                    viewModel.deleteAttendanceTemp(record)
                                }
                                showDeleteAttendanceConfirmDialog = false
                                attendanceToDelete = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                        ) {
                            Text("إعادة تعيين الطلاب وحذف حركتي 🔄", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        OutlinedButton(onClick = { showDeleteAttendanceConfirmDialog = false }) {
                            Text("إلغاء", fontSize = 11.sp)
                        }
                    }
                )
            } else {
                AlertDialog(
                    onDismissRequest = { showDeleteAttendanceConfirmDialog = false },
                    title = { Text("تأكيد الحذف", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.error) },
                    text = { Text("هل أنت متأكد من رغبتك في حذف بطاقة تحضير المدرب؟\nسيتم إزالة الحركة تماماً ولا يمكن التراجع عن ذلك.", fontSize = 13.sp) },
                    confirmButton = {
                        Button(
                            onClick = {
                                attendanceToDelete?.let { viewModel.deleteAttendanceTemp(it) }
                                showDeleteAttendanceConfirmDialog = false
                                attendanceToDelete = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("نعم، احذف", color = Color.White)
                        }
                    },
                    dismissButton = {
                        OutlinedButton(onClick = { showDeleteAttendanceConfirmDialog = false }) {
                            Text("إلغاء")
                        }
                    }
                )
            }
        }

        if (showTrainerStatusChangeConfirmDialog && pendingTrainerStatusChange != null) {
            AlertDialog(
                onDismissRequest = { 
                    showTrainerStatusChangeConfirmDialog = false 
                    pendingTrainerStatusChange = null
                },
                title = { 
                    Text("تأكيد تغيير حالة الأستاذ 👨‍🏫", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DawamiNavy) 
                },
                text = { 
                    Text("هل أنت متأكد من رغبتك في تغيير حالة الأستاذ اليوم إلى (${pendingTrainerStatusChange})؟", fontSize = 13.sp) 
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.attendanceStatusInput.value = pendingTrainerStatusChange!!
                            showTrainerStatusChangeConfirmDialog = false
                            pendingTrainerStatusChange = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                    ) {
                        Text("نعم، تغيير", color = Color.White)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = { 
                            showTrainerStatusChangeConfirmDialog = false 
                            pendingTrainerStatusChange = null
                        }
                    ) {
                        Text("إلغاء")
                    }
                }
            )
        }
        
        if (showTrainerLeaveDialog) {
            AlertDialog(
                onDismissRequest = { showTrainerLeaveDialog = false },
                title = {
                    Text(
                        text = "تأكيد تسجيل إجازة للأستاذ 🌴",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = DawamiNavy
                    )
                },
                text = {
                    Text(
                        text = "لقد قمت بتسجيل حركة 'إجازة' للأستاذ اليوم. هل ترغب في اعتماد 'غياب' للطلاب لهذه الدورة اليوم أم اعتماد 'إجازة معتمدة' أم تسجيل حركة الأستاذ فقط دون تغيير على حركات الطلاب؟",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                confirmButton = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val err = viewModel.addOrUpdateAttendanceTemp()
                                if (err == null) {
                                    val course = viewModel.selectedCourseForAttendance.value
                                    if (course != null) {
                                        viewModel.autoRegisterStudentStatusForCourseAndDate(
                                            courseId = course.id,
                                            dateStr = viewModel.attendanceDateInput.value,
                                            dayName = viewModel.attendanceDayInput.value,
                                            status = "غياب"
                                        )
                                        Toast.makeText(context, "تم تسجيل إجازة المعلم ورصد غياب للطلاب!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                showTrainerLeaveDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("رصد غياب للطلاب ❌", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val err = viewModel.addOrUpdateAttendanceTemp()
                                if (err == null) {
                                    val course = viewModel.selectedCourseForAttendance.value
                                    if (course != null) {
                                        viewModel.autoRegisterStudentStatusForCourseAndDate(
                                            courseId = course.id,
                                            dateStr = viewModel.attendanceDateInput.value,
                                            dayName = viewModel.attendanceDayInput.value,
                                            status = "إجازة"
                                        )
                                        Toast.makeText(context, "تم تسجيل إجازة المعلم وإجازة معتمدة للطلاب!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                showTrainerLeaveDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("رصد إجازة للطلاب 🌴", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val err = viewModel.addOrUpdateAttendanceTemp()
                                if (err != null) {
                                    Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "تم تسجيل إجازة الأستاذ فقط بنجاح!", Toast.LENGTH_SHORT).show()
                                }
                                showTrainerLeaveDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("تسجيل حركة الأستاذ فقط 👨‍🏫", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { showTrainerLeaveDialog = false },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("إلغاء التراجع", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                        }
                    }
                },
                shape = RoundedCornerShape(20.dp),
                containerColor = MaterialTheme.colorScheme.surface
            )
        }


        val availableFilterSubjects = remember(tempAttendance, selectedCourse, allSubjects, dbCourseSubjects, attendanceDate, dbAllStudentAttendance) {
            val fromRecords = tempAttendance
                .filter { (selectedCourse == null || it.courseId == selectedCourse?.id) && it.date == attendanceDate }
                .map { 
                    if (it.subjectName.isNotEmpty()) {
                        it.subjectName
                    } else {
                        dbAllStudentAttendance.firstOrNull { studentAtt ->
                            studentAtt.courseId == it.courseId && studentAtt.date == it.date && studentAtt.subjectName.isNotEmpty()
                        }?.subjectName ?: ""
                    }
                }
                .filter { it.isNotEmpty() }
            
            val linked = if (selectedCourse != null) {
                val courseCrossRefs = dbCourseSubjects.filter { it.courseId == selectedCourse!!.id }
                val courseSubjectIds = courseCrossRefs.map { it.subjectId }
                val direct = allSubjects.filter { it.id in courseSubjectIds }
                val diploma = if (selectedCourse!!.diplomaName.isNotEmpty()) {
                    allSubjects.filter { it.diplomaName.equals(selectedCourse!!.diplomaName, ignoreCase = true) }
                } else emptyList()
                val dept = if (selectedCourse!!.departmentName.isNotEmpty()) {
                    allSubjects.filter { it.departmentName.equals(selectedCourse!!.departmentName, ignoreCase = true) }
                } else emptyList()
                (direct + diploma + dept).map { it.name }
            } else emptyList()

            (fromRecords + linked).distinct().filter { it.isNotEmpty() }
        }

        val displayedAttendance = (if (selectedCourse == null) {
            tempAttendance.filter { it.date == attendanceDate }
        } else {
            tempAttendance.filter { it.courseId == selectedCourse?.id && it.date == attendanceDate }
        }).filter {
            true
        }

        val attendanceCardRows = remember(displayedAttendance, expandedCardIds) {
            val rows = mutableListOf<List<Attendance>>()
            var currentRow = mutableListOf<Attendance>()
            for (att in displayedAttendance) {
                val isExpanded = att.id in expandedCardIds
                if (isExpanded) {
                    if (currentRow.isNotEmpty()) {
                        rows.add(currentRow)
                        currentRow = mutableListOf()
                    }
                    rows.add(listOf(att))
                } else {
                    currentRow.add(att)
                    if (currentRow.size == 2) {
                        rows.add(currentRow)
                        currentRow = mutableListOf()
                    }
                }
            }
            if (currentRow.isNotEmpty()) {
                rows.add(currentRow)
            }
            rows
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // Form Card
            item {
                val isTrainerFormEnabled = (attendanceDate == todayStr || isEditableInPastTrainer)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(attendanceDate) {
                            detectTapGestures(
                                onDoubleTap = {
                                    if (attendanceDate != todayStr) {
                                        isEditableInPastTrainer = !isEditableInPastTrainer
                                        Toast.makeText(
                                            context,
                                            if (isEditableInPastTrainer) "تم تمكين التعديل لليوم السابق 🔓" else "تم قفل الشاشة للقراءة فقط 🔒",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )
                        },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (attendanceDate != todayStr) {
                            val bannerText = if (isEditableInPastTrainer) 
                                "وضع التعديل مفعل لليوم السابق 🔓 (انقر مرتين للإغلاق والتحويل للقراءة فقط 🔒)" 
                            else 
                                "وضع القراءة فقط لمنع التعديل غير المقصود 🔒 (انقر مرتين لتمكين التعديل 🔓)"
                            
                            val bannerBg = if (isEditableInPastTrainer) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)
                            val bannerBorder = if (isEditableInPastTrainer) Color(0xFFBBF7D0) else Color(0xFFFEE2E2)
                            val bannerTextCol = if (isEditableInPastTrainer) Color(0xFF15803D) else Color(0xFFB91C1C)
                            
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(bannerBg, RoundedCornerShape(8.dp))
                                    .border(1.dp, bannerBorder, RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = bannerText,
                                    color = bannerTextCol,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isTrainerFormExpanded = !isTrainerFormExpanded },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (selectedAttendanceEdit != null) Icons.Default.EditCalendar else Icons.Default.EventAvailable,
                                    contentDescription = null,
                                    tint = DawamiNavy,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = if (selectedAttendanceEdit != null) "تعديل حركة الدخول والخروج" else "تسجيل حركة حضور وانصراف جديدة",
                                    color = DawamiNavy,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (!isTrainerFormExpanded) {
                                    Surface(
                                        color = DawamiNavy.copy(alpha = 0.08f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "${selectedCourse?.name ?: "كل الدورات"} • $attendanceDate",
                                            fontSize = 9.5.sp,
                                            color = DawamiNavy,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = { isTrainerFormExpanded = !isTrainerFormExpanded },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isTrainerFormExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = if (isTrainerFormExpanded) "طي النموذج" else "توسيع النموذج",
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        AnimatedVisibility(visible = isTrainerFormExpanded) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                        if (activeCourses.isEmpty() && selectedAttendanceEdit == null) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(DawamiGold.copy(alpha = 0.08f), RoundedCornerShape(10.dp))
                                    .border(1.dp, DawamiGold.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = DawamiGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "لا توجد دورات تدريبية نشطة حالياً",
                                        color = DawamiNavy,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "جميع دوراتك التدريبية الحالية منتهية أو لم يتم إضافة دورات بعد. تفضل بزيارة شاشة 'دوراتي' لإضافة دورة جديدة.",
                                        color = Color(0xFF475569),
                                        fontSize = 10.sp,
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        } else {
                            // Course Dropdown Selector
                            val rawSubjectsToSelect = remember(selectedCourse, allSubjects, dbCourseSubjects) {
                                val currentSelCourse = selectedCourse
                                if (currentSelCourse == null) {
                                    emptyList<com.example.data.entity.Subject>()
                                } else {
                                    val courseCrossRefs = dbCourseSubjects.filter { it.courseId == currentSelCourse.id }
                                    val courseSubjectIds = courseCrossRefs.map { it.subjectId }
                                    val directLinkedSubjects = allSubjects.filter { it.id in courseSubjectIds }
                                    val diplomaLinkedSubjects = if (currentSelCourse.diplomaName.isNotEmpty()) {
                                        allSubjects.filter { it.diplomaName.equals(currentSelCourse.diplomaName, ignoreCase = true) }
                                    } else emptyList()
                                    val deptLinkedSubjects = if (currentSelCourse.departmentName.isNotEmpty()) {
                                        allSubjects.filter { it.departmentName.equals(currentSelCourse.departmentName, ignoreCase = true) }
                                    } else emptyList()

                                    ((directLinkedSubjects + diplomaLinkedSubjects + deptLinkedSubjects).distinctBy { it.id }.ifEmpty { allSubjects })
                                        .sortedWith(compareBy<com.example.data.entity.Subject> { com.example.data.entity.StudentGradeConfig.getSubjectRank(it.name) }.thenBy { it.name })
                                        .ifEmpty { allSubjects }
                                }
                            }

                            var courseSubjectStats by remember { mutableStateOf<List<com.example.data.entity.CourseSubjectStat>>(emptyList()) }
                            LaunchedEffect(selectedCourse, dbAllStudentAttendance, allSubjects, dbCourseSubjects, activeCourses) {
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                                    courseSubjectStats = if (selectedCourse != null) viewModel.getCourseSubjectStats(selectedCourse!!.id)
                                    else emptyList()
                                }
                            }

                            val activeSubjectsToSelect = remember(rawSubjectsToSelect, selectedCourse, dbCourseSubjects, showCompletedSubjectsInAttendance, courseSubjectStats) {
                                val currentSelCourse = selectedCourse
                                if (currentSelCourse == null) {
                                    emptyList<com.example.data.entity.Subject>()
                                } else {
                                    val courseCrossRefs = dbCourseSubjects.filter { it.courseId == currentSelCourse.id }
                                    rawSubjectsToSelect.filter { sub ->
                                        val ref = courseCrossRefs.find { it.subjectId == sub.id }
                                        val stat = courseSubjectStats.find { it.subjectId == sub.id || it.subjectName.trim().equals(sub.name.trim(), ignoreCase = true) }
                                        val status = stat?.status ?: ref?.status ?: "قيد التدريس"
                                        val isCompleted = status == "مكتملة التدريس" || status == "مكتملة بالكامل" || status == "في انتظار الاختبار" || status.contains("مكتمل")
                                        showCompletedSubjectsInAttendance || !isCompleted
                                    }
                                }
                            }

                            // الصف الأول: الدورة والمادة بجانب بعضهما
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Course Dropdown Selector
                                Box(modifier = Modifier.weight(1f)) {
                                    ExposedDropdownMenuBox(
                                        expanded = isCourseDropdownExpanded,
                                        onExpandedChange = { isCourseDropdownExpanded = it }
                                    ) {
                                        OutlinedTextField(
                                            value = selectedCourse?.name ?: "كل الدورات",
                                            onValueChange = {},
                                            readOnly = true,
                                            label = { Text("اختر الدورة التدريبية", fontSize = 10.sp, maxLines = 1) },
                                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCourseDropdownExpanded) },
                                            leadingIcon = if (selectedCourse == null) {
                                                { Icon(Icons.Default.Apps, contentDescription = null, tint = DawamiGold, modifier = Modifier.size(16.dp)) }
                                            } else null,
                                            modifier = Modifier
                                                .menuAnchor()
                                                .fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            singleLine = true,
                                            textStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selectedCourse == null) DawamiGold else DawamiNavy)
                                        )
                                        ExposedDropdownMenu(
                                            expanded = isCourseDropdownExpanded,
                                            onDismissRequest = { isCourseDropdownExpanded = false }
                                        ) {
                                            DropdownMenuItem(
                                                leadingIcon = {
                                                    Icon(
                                                        imageVector = Icons.Default.Apps,
                                                        contentDescription = null,
                                                        tint = DawamiGold,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                },
                                                text = {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "كل الدورات (عرض حركات اليوم)",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (selectedCourse == null) DawamiGold else MaterialTheme.colorScheme.onSurface
                                                        )
                                                        if (selectedCourse == null) {
                                                            Text("● محدد", fontSize = 9.sp, color = DawamiGold, fontWeight = FontWeight.Bold)
                                                        }
                                                    }
                                                },
                                                onClick = {
                                                    viewModel.selectCourseForAttendance(null)
                                                    isCourseDropdownExpanded = false
                                                }
                                            )
                                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                            DropdownMenuItem(
                                                text = {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = if (showCompletedCourses) "إخفاء الدورات المنتهية" else "إظهار الدورات المنتهية",
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (showCompletedCourses) DawamiTeal else DawamiNavy
                                                        )
                                                        Icon(
                                                            imageVector = if (showCompletedCourses) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                            contentDescription = null,
                                                            tint = if (showCompletedCourses) DawamiTeal else DawamiNavy,
                                                            modifier = Modifier.size(15.dp)
                                                        )
                                                    }
                                                },
                                                onClick = {
                                                    viewModel.toggleShowCompletedCoursesInDropdowns()
                                                }
                                            )
                                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                            activeCourses.forEach { course ->
                                                val isSelected = selectedCourse?.id == course.id
                                                DropdownMenuItem(
                                                    text = {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Text(
                                                                text = if (course.isCompleted) "${course.name} (منتهية 🔒)" else course.name,
                                                                fontSize = 11.sp,
                                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                                color = if (course.isCompleted) Color.Gray else if (isSelected) DawamiNavy else MaterialTheme.colorScheme.onSurface,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis
                                                            )
                                                            if (isSelected) {
                                                                Text("● محدد", fontSize = 9.sp, color = DawamiNavy, fontWeight = FontWeight.Bold)
                                                            }
                                                        }
                                                    },
                                                    onClick = {
                                                        viewModel.selectCourseForAttendance(course)
                                                        isCourseDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                // Subject Selector Box (Opens Bottom Sheet)
                                Box(modifier = Modifier.weight(1f)) {
                                    OutlinedTextField(
                                        value = if (selectedCourse == null) "كل المواد (كل الدورات)" else studentAttendanceSelectedSubject.ifEmpty { "لم يتم تحديد مادة" },
                                        onValueChange = {},
                                        readOnly = true,
                                        label = {
                                            Text(
                                                "المادة التدريسية",
                                                fontSize = 10.sp,
                                                maxLines = 1,
                                                fontWeight = FontWeight.Bold,
                                                color = if (selectedCourse != null) DawamiTeal else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                            )
                                        },
                                        textStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selectedCourse != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)),
                                        trailingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.KeyboardArrowDown,
                                                contentDescription = null,
                                                tint = if (selectedCourse != null) DawamiTeal else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        },
                                        leadingIcon = { Icon(Icons.Default.Book, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(12.dp)) },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        singleLine = true,
                                        enabled = selectedCourse != null,
                                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                                    )

                                    if (selectedCourse != null) {
                                        Box(
                                            modifier = Modifier
                                                .matchParentSize()
                                                .clip(RoundedCornerShape(10.dp))
                                                .clickable {
                                                    isSubjectDropdownExpanded = true
                                                }
                                        )
                                    }
                                }

                                val currentCourse = selectedCourse
                                if (isSubjectDropdownExpanded && currentCourse != null) {
                                    val courseCrossRefs = dbCourseSubjects.filter { it.courseId == currentCourse.id }
                                    SubjectSelectionBottomSheet(
                                        currentCourse = currentCourse,
                                        allSubjects = allSubjects,
                                        courseSubjectStats = courseSubjectStats,
                                        courseCrossRefs = courseCrossRefs,
                                        selectedSubjectName = studentAttendanceSelectedSubject,
                                        onSelectSubject = { subject ->
                                            viewModel.updateTeacherAttendanceSubject(subject.name)
                                            isSubjectDropdownExpanded = false
                                            if (isSelectingSubjectForTrainerCheckIn) {
                                                isSelectingSubjectForTrainerCheckIn = false
                                                unifiedDialogMode = AttendanceConfirmType.CHECK_IN
                                                showUnifiedTrainerDialog = true
                                            }
                                        },
                                        onDismiss = {
                                            isSubjectDropdownExpanded = false
                                            isSelectingSubjectForTrainerCheckIn = false
                                        }
                                    )
                                }
                            }

                            if (selectedCourse != null) {
                                val completedCount = remember(rawSubjectsToSelect, courseSubjectStats, dbCourseSubjects, selectedCourse) {
                                    val courseCrossRefs = dbCourseSubjects.filter { it.courseId == selectedCourse!!.id }
                                    rawSubjectsToSelect.count { sub ->
                                        val ref = courseCrossRefs.find { it.subjectId == sub.id }
                                        val stat = courseSubjectStats.find { it.subjectId == sub.id || it.subjectName.trim().equals(sub.name.trim(), ignoreCase = true) }
                                        val status = stat?.status ?: ref?.status ?: "قيد التدريس"
                                        status == "مكتملة التدريس" || status == "مكتملة بالكامل" || status == "في انتظار الاختبار" || status.contains("مكتمل")
                                    }
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 2.dp, vertical = 1.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier.clickable {
                                            showCompletedSubjectsInAttendance = !showCompletedSubjectsInAttendance
                                        }
                                    ) {
                                        Checkbox(
                                            checked = showCompletedSubjectsInAttendance,
                                            onCheckedChange = { showCompletedSubjectsInAttendance = it },
                                            colors = CheckboxDefaults.colors(checkedColor = DawamiNavy),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = if (completedCount > 0) "إظهار المواد المكتملة في القائمة 🏁 ($completedCount)" else "إظهار المواد المكتملة في القائمة 🏁",
                                            fontSize = 9.5.sp,
                                            fontWeight = if (showCompletedSubjectsInAttendance) FontWeight.Bold else FontWeight.Normal,
                                            color = if (showCompletedSubjectsInAttendance) DawamiNavy else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                                        )
                                    }

                                    if (studentAttendanceSelectedSubject.isNotEmpty()) {
                                        val currentStat = courseSubjectStats.find { it.subjectName.trim().equals(studentAttendanceSelectedSubject.trim(), ignoreCase = true) }
                                        val currentTaughtDays = currentStat?.taughtDaysCount ?: 0
                                        Text(
                                            text = if (currentTaughtDays > 0) "المادة: $studentAttendanceSelectedSubject ($currentTaughtDays يوم)" else "المادة: $studentAttendanceSelectedSubject",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiTeal,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }

                            // الصف الثاني: اليوم والتاريخ الفعلي
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Day Dropdown
                                Box(modifier = Modifier.weight(1f)) {
                                    ExposedDropdownMenuBox(
                                        expanded = isDayDropdownExpanded,
                                        onExpandedChange = { isDayDropdownExpanded = it }
                                    ) {
                                        OutlinedTextField(
                                            value = attendanceDay,
                                            onValueChange = {},
                                            readOnly = true,
                                            label = { Text("اليوم", fontSize = 11.sp) },
                                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDayDropdownExpanded) },
                                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            singleLine = true
                                        )
                                        ExposedDropdownMenu(
                                            expanded = isDayDropdownExpanded,
                                            onDismissRequest = { isDayDropdownExpanded = false }
                                        ) {
                                            daysList.forEach { day ->
                                                DropdownMenuItem(
                                                    text = { Text(day, fontSize = 11.sp) },
                                                    onClick = {
                                                        viewModel.attendanceDayInput.value = day
                                                        isDayDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                // Date Picker
                                Box(modifier = Modifier.weight(1f)) {
                                    com.example.ui.components.InlineExpandableDatePicker(
                                        selectedDate = attendanceDate,
                                        onDateSelected = { viewModel.setAttendanceDate(it) },
                                        label = "التاريخ الفعلي",
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }

                            // Status Selector Segmented Row
                            Text("الحالة اليومية للدورة التدريبية", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("حضور", "غياب", "إجازة").forEach { status ->
                                    val isSelected = attendanceStatus == status
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable(enabled = isTrainerFormEnabled) {
                                                if (attendanceStatus != status) {
                                                    pendingTrainerStatusChange = status
                                                    showTrainerStatusChangeConfirmDialog = true
                                                }
                                            },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) {
                                                if (isTrainerFormEnabled) DawamiTeal else DawamiTeal.copy(alpha = 0.5f)
                                            } else {
                                                Color(0xFFF1F5F9).copy(alpha = if (isTrainerFormEnabled) 1f else 0.5f)
                                            }
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, if (isSelected) DawamiTeal else Color(0xFFE2E8F0))
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 6.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                             Text(
                                                text = status,
                                                color = if (isSelected) Color.White else Color(0xFF475569).copy(alpha = if (isTrainerFormEnabled) 1f else 0.5f),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }

                            // Session Type Segmented Selector (Lesson vs Exam)
                            Text("نوع الجلسة / الحركة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // Lesson Option
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable(enabled = isTrainerFormEnabled) {
                                            viewModel.setIsExamDayForNextRecord(false)
                                        },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (!isExamDaySelected) DawamiNavy else Color(0xFFF1F5F9).copy(alpha = if (isTrainerFormEnabled) 1f else 0.5f)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, if (!isExamDaySelected) DawamiNavy else Color(0xFFE2E8F0))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp, horizontal = 8.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.MenuBook,
                                            contentDescription = null,
                                            tint = if (!isExamDaySelected) Color.White else Color(0xFF475569),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "درس / محاضرة 📖",
                                            color = if (!isExamDaySelected) Color.White else Color(0xFF475569).copy(alpha = if (isTrainerFormEnabled) 1f else 0.5f),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.5.sp
                                        )
                                    }
                                }

                                // Exam Option
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable(enabled = isTrainerFormEnabled) {
                                            viewModel.setIsExamDayForNextRecord(true)
                                        },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isExamDaySelected) Color(0xFFD97706) else Color(0xFFF1F5F9).copy(alpha = if (isTrainerFormEnabled) 1f else 0.5f)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, if (isExamDaySelected) Color(0xFFD97706) else Color(0xFFE2E8F0))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp, horizontal = 8.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Assignment,
                                            contentDescription = null,
                                            tint = if (isExamDaySelected) Color.White else Color(0xFF475569),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "امتحان / اختبار 📝",
                                            color = if (isExamDaySelected) Color.White else Color(0xFF475569).copy(alpha = if (isTrainerFormEnabled) 1f else 0.5f),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.5.sp
                                        )
                                    }
                                }
                            }

                            if (attendanceStatus == "حضور") {
                                // Actual Check-In and Check-Out Time Pickers Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    com.example.ui.components.InlineExpandableTimePicker(
                                        selectedTime = attendanceCheckIn,
                                        label = "وقت الحضور الفعلي",
                                        onTimeSelected = {
                                            viewModel.attendanceCheckInInput.value = it
                                            viewModel.onAttendanceTimeChanged()
                                        },
                                        modifier = Modifier.weight(1f),
                                        enabled = isTrainerFormEnabled
                                    )

                                    com.example.ui.components.InlineExpandableTimePicker(
                                        selectedTime = attendanceCheckOut,
                                        label = "وقت الانصراف الفعلي",
                                        onTimeSelected = {
                                            viewModel.attendanceCheckOutInput.value = it
                                            viewModel.onAttendanceTimeChanged()
                                        },
                                        modifier = Modifier.weight(1f),
                                        enabled = isTrainerFormEnabled
                                    )
                                }

                                // Elapsed Hours Auto Calculation Display
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = DawamiTeal.copy(alpha = 0.05f)),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.2f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("الفارق الزمني الإجمالي المحسوب للدوام:", fontSize = 10.sp, color = DawamiNavy)
                                        Text(
                                            text = calculatedDurationText,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp,
                                            color = DawamiTeal
                                        )
                                    }
                                }
                            } else {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = DawamiGold.copy(alpha = 0.05f)),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.2f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Info, contentDescription = null, tint = DawamiGold, modifier = Modifier.size(16.dp))
                                        Text(
                                            text = "الحالة المحددة (${attendanceStatus}) لا تتطلب تسجيل أوقات حضور وانصراف.",
                                            fontSize = 10.sp,
                                            color = DawamiNavy,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Note text field for Teacher
                            OutlinedTextField(
                                value = attendanceNote,
                                onValueChange = { viewModel.attendanceNoteInput.value = it },
                                label = { Text("ملاحظة الحركة اليومية للأستاذ", fontSize = 11.sp) },
                                placeholder = { Text("مثال: تم إعطاء المحاضرة الثانية...", fontSize = 10.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                singleLine = true,
                                enabled = isTrainerFormEnabled
                            )

                            // Action Buttons
                            if (selectedAttendanceEdit != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val isEditEnabled = isTrainerFormEnabled && selectedCourse != null && attendanceDay.isNotEmpty() && attendanceDate.isNotEmpty() &&
                                            (attendanceStatus != "حضور" || attendanceCheckIn.isNotEmpty())
                                    Button(
                                        onClick = {
                                            val isPresent = attendanceStatus == "حضور"
                                            if (isPresent && viewModel.attendanceCheckInInput.value.isEmpty()) {
                                                Toast.makeText(context, "يرجى تحديد وقت الدخول الفعلي!", Toast.LENGTH_LONG).show()
                                            } else {
                                                showTrainerEditConfirmDialog = true
                                            }
                                        },
                                        enabled = isEditEnabled,
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("حفظ التعديلات", fontSize = 11.sp)
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.clearAttendanceForm() },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("إلغاء", fontSize = 11.sp)
                                    }
                                }
                            } else {
                                if (attendanceStatus == "حضور") {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        val isCheckInEnabled = isTrainerFormEnabled && selectedCourse != null && attendanceDay.isNotEmpty() && attendanceDate.isNotEmpty()
                                        Button(
                                            onClick = {
                                                isSelectingSubjectForTrainerCheckIn = true
                                                isSubjectDropdownExpanded = true
                                            },
                                            enabled = isCheckInEnabled,
                                            colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Icon(Icons.Default.Login, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("تسجيل دخول 📥", fontSize = 11.sp)
                                        }

                                        val isCheckOutEnabled = isTrainerFormEnabled && selectedCourse != null && attendanceDay.isNotEmpty() && attendanceDate.isNotEmpty()
                                        Button(
                                            onClick = {
                                                unifiedDialogMode = AttendanceConfirmType.CHECK_OUT
                                                showUnifiedTrainerDialog = true
                                            },
                                            enabled = isCheckOutEnabled,
                                            colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("تسجيل خروج 📤", fontSize = 11.sp)
                                        }
                                    }
                                } else {
                                    val isOtherStatusEnabled = isTrainerFormEnabled && selectedCourse != null && attendanceDay.isNotEmpty() && attendanceDate.isNotEmpty()
                                    Button(
                                        onClick = { showTrainerOtherStatusConfirmDialog = true },
                                        enabled = isOtherStatusEnabled,
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تسجيل حركة (${attendanceStatus}) 💾", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
            }

            // شريط التنقل العصري بين الأيام (يخفى أثناء وضع تعديل حركة المدرب)
            if (selectedAttendanceEdit == null) {
                item {
                    ModernDayNavigator(
                        currentDate = attendanceDate,
                        currentDayName = attendanceDay,
                        todayDate = todayStr,
                        recordedDates = recordedDates,
                        onDateSelected = { newDate ->
                            viewModel.setAttendanceDate(newDate)
                        },
                        courseEndDate = selectedCourse?.endDate,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                    )
                }
            }

            // Quick Transition Banner to Student Attendance
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.openStudentsGroup(0)
                        },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DawamiTeal.copy(alpha = 0.08f)),
                    border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Groups, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(20.dp))
                            Column {
                                Text("الانتقال المباشر لتحضير الطلاب 👥", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                Text("اضغط هنا للانتقال مباشرة لرصد وتحضير الطلاب لهذه الدورة", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Temp            // Records List Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (selectedCourse == null) "سجل حركات اليوم لجميع الدورات ($attendanceDate)" else "سجل حركات الدورة في تاريخ ($attendanceDate)",
                            color = DawamiNavy,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Badge(containerColor = DawamiGold) {
                            Text("${displayedAttendance.size} حركات", color = Color.White, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp), fontSize = 10.sp)
                        }
                    }

                    if (displayedAttendance.isNotEmpty()) {
                        val allExpanded = displayedAttendance.all { it.id in expandedCardIds }
                        TextButton(
                            onClick = {
                                expandedCardIds = if (allExpanded) {
                                    emptySet()
                                } else {
                                    displayedAttendance.map { it.id }.toSet()
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = if (allExpanded) Icons.Default.UnfoldLess else Icons.Default.UnfoldMore,
                                contentDescription = null,
                                tint = DawamiNavy,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (allExpanded) "طي الكل" else "توسيع الكل",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiNavy
                            )
                        }
                    }
                }
            }

            if (displayedAttendance.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(0.6f))
                    ) {
                        Text(
                            text = if (selectedCourse == null) "لا توجد حركات حضور وانصراف مسجلة في تاريخ ($attendanceDate) لجميع الدورات." else "لا توجد حركة مسجلة لهذه الدورة في تاريخ ($attendanceDate).",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        )
                    }
                }
            } else {
                items(
                    items = attendanceCardRows,
                    key = { row -> row.joinToString("-") { it.id.toString() } }
                ) { rowRecords ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        for (record in rowRecords) {
                            val isExpanded = record.id in expandedCardIds
                            val cardModifier = if (rowRecords.size == 1 && !isExpanded) {
                                Modifier.weight(0.5f)
                            } else {
                                Modifier.weight(1f)
                            }

                            TrainerAttendanceMovementCard(
                                modifier = cardModifier,
                                record = record,
                                isExpanded = isExpanded,
                                isSelectedForEdit = selectedAttendanceEdit?.id == record.id,
                                dbAllStudentAttendance = dbAllStudentAttendance,
                                onToggleExpand = {
                                    expandedCardIds = if (isExpanded) expandedCardIds - record.id else expandedCardIds + record.id
                                },
                                onToggleExam = { viewModel.toggleAttendanceExamDay(record) },
                                onEdit = { viewModel.selectAttendanceForEdit(record) },
                                onDelete = {
                                    attendanceToDelete = record
                                    showDeleteAttendanceConfirmDialog = true
                                }
                            )
                        }
                        if (rowRecords.size == 1 && (rowRecords.first().id !in expandedCardIds)) {
                            Spacer(modifier = Modifier.weight(0.5f))
                        }
                    }
                }
            }
        }
    }

    // --- Trainer Confirmation Dialogs ---
    // --- Unified Trainer Attendance Dialog ---
    if (showUnifiedTrainerDialog) {
        TrainerUnifiedAttendanceDialog(
            viewModel = viewModel,
            confirmActionType = unifiedDialogMode,
            subjectName = studentAttendanceSelectedSubject,
            onConfirm = { time, isExam ->
                showUnifiedTrainerDialog = false
                viewModel.setIsExamDayForNextRecord(isExam)
                if (unifiedDialogMode == AttendanceConfirmType.CHECK_IN) {
                    viewModel.attendanceCheckInInput.value = time
                    viewModel.onAttendanceTimeChanged()
                    
                    // Supplementary day logic: if plan finished and not exam, increment targetDays
                    val stats = viewModel.getCourseSubjectStats(selectedCourse?.id ?: -1)
                    val stat = stats.find { it.subjectName.trim().equals(studentAttendanceSelectedSubject.trim(), ignoreCase = true) }
                    if (stat != null && !isExam && stat.targetDays > 0 && (stat.taughtDaysCount + 1) > stat.targetDays) {
                        viewModel.updateCourseSubjectStatus(
                            courseId = selectedCourse?.id ?: -1,
                            subjectId = stat.subjectId,
                            newStatus = stat.status,
                            targetDays = stat.taughtDaysCount + 1
                        )
                    }

                    val err = viewModel.recordCheckInOnly()
                    if (err != null) {
                        Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                    } else {
                        AudioPlayerHelper.playAudioOrSpeak(context, "trainer_checkin_success", "تم تسجيل حضور المدرب بنجاح", viewModel.voiceGender.value)
                        Toast.makeText(context, "📥 تم تسجيل الدخول بنجاح بتوقيت ($time)!", Toast.LENGTH_SHORT).show()
                        showNavigateToStudentsDialog = true
                    }
                } else if (unifiedDialogMode == AttendanceConfirmType.CHECK_OUT) {
                    viewModel.attendanceCheckOutInput.value = time
                    viewModel.onAttendanceTimeChanged()

                    // Supplementary day logic: if plan finished and not exam, increment targetDays
                    val stats = viewModel.getCourseSubjectStats(selectedCourse?.id ?: -1)
                    val stat = stats.find { it.subjectName.trim().equals(studentAttendanceSelectedSubject.trim(), ignoreCase = true) }
                    if (stat != null && !isExam && stat.targetDays > 0 && stat.taughtDaysCount > stat.targetDays) {
                        viewModel.updateCourseSubjectStatus(
                            courseId = selectedCourse?.id ?: -1,
                            subjectId = stat.subjectId,
                            newStatus = stat.status,
                            targetDays = stat.taughtDaysCount
                        )
                    }

                    val err = viewModel.recordCheckOutAndComplete()
                    if (err != null) {
                        Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                    } else {
                        AudioPlayerHelper.playAudioOrSpeak(context, "trainer_checkout_success", "تم تسجيل انصراف المدرب بنجاح", viewModel.voiceGender.value)
                        Toast.makeText(context, "📤 تم تسجيل الخروج بنجاح بتوقيت ($time)!", Toast.LENGTH_SHORT).show()
                        showNavigateToStudentsDialog = true
                    }
                }
            },
            onDismiss = { showUnifiedTrainerDialog = false }
        )
    }

    if (showAbsentSummaryDialog) {
        AlertDialog(
            onDismissRequest = { showAbsentSummaryDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("📋", fontSize = 16.sp)
                    Text(
                        text = "تم اعتماد الغياب (${absentSummaryStudentsList.size} طلاب)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp,
                        color = DawamiNavy
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "تم رصد حركة الغياب ❌ للطلاب التالية أسماؤهم لعدم وجود تسجيل حركة مسبقة لهم اليوم:",
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        color = Color(0xFFFEF2F2),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFFECACA)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            absentSummaryStudentsList.forEachIndexed { index, name ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("❌", fontSize = 9.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${index + 1}. $name",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF991B1B)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAbsentSummaryDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("حسناً", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    if (showTrainerOtherStatusConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showTrainerOtherStatusConfirmDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = DawamiNavy)
                    Text("تأكيد تسجيل حالة الأستاذ 💾", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DawamiNavy)
                }
            },
            text = {
                Text(
                    text = "هل أنت متأكد من تسجيل حالة الأستاذ كـ (${attendanceStatus}) في الدورة \"${selectedCourse?.name}\"؟\n\n📅 التاريخ: ${attendanceDate}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showTrainerOtherStatusConfirmDialog = false
                        val err = viewModel.addOrUpdateAttendanceTemp()
                        if (err != null) {
                            Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "💾 تم تسجيل حركة (${attendanceStatus}) بنجاح!", Toast.LENGTH_SHORT).show()
                            showNavigateToStudentsDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("تأكيد الحفظ", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showTrainerOtherStatusConfirmDialog = false },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("تراجع", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    if (showTrainerEditConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showTrainerEditConfirmDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = DawamiNavy)
                    Text("تأكيد حفظ تعديلات الأستاذ 💾", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DawamiNavy)
                }
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حفظ وتحديث التعديلات الجديدة لحركة الأستاذ في الدورة \"${selectedCourse?.name}\"؟\n\n📅 التاريخ: ${attendanceDate}\n📌 الحالة: ${attendanceStatus}\n📝 نوع الجلسة: ${if (isExamDaySelected) "امتحان / اختبار 📝" else "درس / محاضرة 📖"}" +
                            if (attendanceStatus == "حضور") "\n⏰ دخول: ${attendanceCheckIn} | انصراف: ${attendanceCheckOut}" else "",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showTrainerEditConfirmDialog = false
                        val err = viewModel.addOrUpdateAttendanceTemp()
                        if (err != null) {
                            Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "💾 تم تحديث وحفظ التعديلات بنجاح!", Toast.LENGTH_SHORT).show()
                            showNavigateToStudentsDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("تأكيد الحفظ", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showTrainerEditConfirmDialog = false },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("تراجع", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    if (showNavigateToStudentsDialog) {
        AlertDialog(
            onDismissRequest = { showNavigateToStudentsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Groups, contentDescription = null, tint = DawamiTeal)
                    Text("الانتقال لتحضير الطلاب 👥", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DawamiNavy)
                }
            },
            text = {
                val subjectFeedback = if (studentAttendanceSelectedSubject.isNotEmpty()) "\n📚 المادة المعتمدة: $studentAttendanceSelectedSubject" else ""
                Text(
                    text = "تم تسجيل حركة الأستاذ بنجاح! 🎉$subjectFeedback\n\nهل ترغب في الانتقال المباشر الآن لرصد وتحضير الطلاب لهذه الدورة؟",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showNavigateToStudentsDialog = false
                        viewModel.openStudentsGroup(0)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiTeal),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("الانتقال لتحضير الطلاب ➡️", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showNavigateToStudentsDialog = false },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("البقاء هنا", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

@Composable
fun TrainerAttendanceMovementCard(
    modifier: Modifier = Modifier,
    record: Attendance,
    isExpanded: Boolean,
    isSelectedForEdit: Boolean,
    dbAllStudentAttendance: List<com.example.data.entity.StudentAttendance>,
    onToggleExpand: () -> Unit,
    onToggleExam: (() -> Unit)? = null,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onToggleExpand() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelectedForEdit) DawamiNavy else Color(0xFFE2E8F0)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Header: Course Name + Expand Icon + Action Buttons (Edit/Delete)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.School,
                        contentDescription = null,
                        tint = DawamiNavy,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = record.courseName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = DawamiNavy, modifier = Modifier.size(12.dp))
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(12.dp))
                    }
                    IconButton(
                        onClick = onToggleExpand,
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = if (isExpanded) "طي" else "توسيع",
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Status badge & Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    StatusBadge(status = record.status)
                    if (record.isExamDay) {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "📝 امتحان نهائي",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB45309),
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Text(
                    text = "${record.dayOfWeek} • ${record.date}",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Times Row (Always visible so at a glance user sees time)
            if (record.status == "حضور") {
                val checkOutText = if (record.actualCheckOut.isEmpty()) "⏳" else formatTimeTo12HourArabic(record.actualCheckOut)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "من ${formatTimeTo12HourArabic(record.actualCheckIn)} إلى $checkOutText",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (record.actualCheckOut.isEmpty()) Color(0xFFC2410C) else DawamiNavy
                    )
                    if (!isExpanded) {
                        val inDelay = record.checkInDelayMinutes
                        if (inDelay > 0) {
                            Text(
                                text = "تأخير ($inDelay د)",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFEF4444)
                            )
                        } else {
                            Text(
                                text = "مثالي ✓",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = DawamiTeal
                            )
                        }
                    }
                }
            }

            // EXPANDED DETAILS
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Subject Name Row
                    val resolvedSubjectName = if (record.subjectName.isNotEmpty()) {
                        record.subjectName
                    } else {
                        dbAllStudentAttendance.firstOrNull { studentAtt ->
                            studentAtt.courseId == record.courseId && studentAtt.date == record.date && studentAtt.subjectName.isNotEmpty()
                        }?.subjectName ?: ""
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Book,
                            contentDescription = null,
                            tint = DawamiTeal,
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = "المادة: ${resolvedSubjectName.ifEmpty { "عام (بدون تحديد)" }}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (resolvedSubjectName.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant else DawamiTeal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (record.isExamDay) {
                            Surface(
                                color = Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(4.dp),
                                border = BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.5f)),
                                modifier = Modifier.clickable { onToggleExam?.invoke() }
                            ) {
                                Text(
                                    text = "📝 امتحان",
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFB45309),
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }

                    if (record.status == "حضور") {
                        val durationText = if (record.actualCheckOut.isEmpty()) "قيد الانتظار" else "${record.durationHours}س و ${record.durationMinutes}د"
                        Text(
                            text = "المدة المحسوبة: $durationText",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (record.actualCheckOut.isEmpty()) Color(0xFFC2410C) else DawamiTeal
                        )

                        // Status Badges (delay / early exit)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            val inDelay = record.checkInDelayMinutes
                            val inStatusText = if (inDelay > 0) "تأخير ($inDelay د)" else "حضور مثالي"
                            val inColor = if (inDelay > 0) Color(0xFFEF4444) else DawamiTeal
                            val inBgColor = if (inDelay > 0) Color(0xFFFEF2F2) else DawamiTeal.copy(alpha = 0.08f)

                            Surface(
                                color = inBgColor,
                                shape = RoundedCornerShape(4.dp),
                                border = BorderStroke(1.dp, inColor.copy(alpha = 0.2f))
                            ) {
                                Text(
                                    text = inStatusText,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = inColor,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }

                            if (record.actualCheckOut.isNotEmpty()) {
                                val outDiff = record.checkOutDifferenceMinutes
                                val outStatusText = if (outDiff < 0) "انصراف مبكر (${-outDiff} د)" else if (outDiff > 0) "متأخر ($outDiff د)" else "انصراف مثالي"
                                val outColor = if (outDiff < 0) Color(0xFFD97706) else if (outDiff > 0) DawamiNavy else DawamiTeal
                                val outBgColor = if (outDiff < 0) Color(0xFFFFFBEB) else if (outDiff > 0) DawamiNavy.copy(alpha = 0.08f) else DawamiTeal.copy(alpha = 0.08f)

                                Surface(
                                    color = outBgColor,
                                    shape = RoundedCornerShape(4.dp),
                                    border = BorderStroke(1.dp, outColor.copy(alpha = 0.2f))
                                ) {
                                    Text(
                                        text = outStatusText,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = outColor,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (record.systemCreatedAt.isNotEmpty()) {
                        Text(
                            text = "⏰ ${formatSystemDateTime(record.systemCreatedAt)}",
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                }
            }
        }
    }
}

private fun calculateTimeDiffMinutes(timeA: String, timeB: String): Int? {
    try {
        val partsA = timeA.split(":").map { it.trim().toInt() }
        val partsB = timeB.split(":").map { it.trim().toInt() }
        if (partsA.size >= 2 && partsB.size >= 2) {
            val mA = partsA[0] * 60 + partsA[1]
            val mB = partsB[0] * 60 + partsB[1]
            return mA - mB
        }
    } catch (_: Exception) { }
    return null
}

private fun adjustTimeMinutes(timeStr: String, deltaMinutes: Int): String {
    try {
        val parts = timeStr.split(":").map { it.trim().toInt() }
        if (parts.size >= 2) {
            var totalMin = parts[0] * 60 + parts[1] + deltaMinutes
            if (totalMin < 0) totalMin += 24 * 60
            totalMin %= (24 * 60)
            val h = totalMin / 60
            val m = totalMin % 60
            return String.format(java.util.Locale.US, "%02d:%02d", h, m)
        }
    } catch (_: Exception) { }
    return timeStr
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainerUnifiedAttendanceDialog(
    viewModel: MainViewModel,
    confirmActionType: AttendanceConfirmType,
    subjectName: String,
    onConfirm: (time: String, isExam: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val loggedInUser by viewModel.loggedInUser.collectAsState()
    val selectedCourse by viewModel.selectedCourseForAttendance.collectAsState()
    val attendanceDate by viewModel.attendanceDateInput.collectAsState()
    val attendanceDay by viewModel.attendanceDayInput.collectAsState()
    
    val fieldCheckIn by viewModel.attendanceCheckInInput.collectAsState()
    val fieldCheckOut by viewModel.attendanceCheckOutInput.collectAsState()

    val dbAllStudentAttendance by viewModel.dbAllStudentAttendance.collectAsState()
    val courseSubjectStats = remember(selectedCourse, dbAllStudentAttendance) {
        if (selectedCourse != null) viewModel.getCourseSubjectStats(selectedCourse!!.id) else emptyList()
    }
    val currentStat = courseSubjectStats.find { it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true) }
    val taughtDays = currentStat?.taughtDaysCount ?: 0
    val targetDays = currentStat?.targetDays ?: 0
    
    val isCheckIn = confirmActionType == AttendanceConfirmType.CHECK_IN
    val isCheckOut = confirmActionType == AttendanceConfirmType.CHECK_OUT
    val currentDayNumber = if (isCheckIn) taughtDays + 1 else taughtDays
    val isLastDay = targetDays > 0 && currentDayNumber == targetDays
    val isExceedingPlan = targetDays > 0 && currentDayNumber > targetDays
    val isPlanFinished = isLastDay || isExceedingPlan

    val currentTime = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date()) }
    val initialTime = when (confirmActionType) {
        AttendanceConfirmType.CHECK_IN -> if (fieldCheckIn.isNotEmpty()) fieldCheckIn else currentTime
        AttendanceConfirmType.CHECK_OUT -> if (fieldCheckOut.isNotEmpty()) fieldCheckOut else currentTime
        else -> currentTime
    }
    
    var confirmSelectedTime by remember { mutableStateOf(initialTime) }
    
    val initialIsExam by viewModel.isExamDayForNextRecord.collectAsState()
    var isExamDaySelected by remember { mutableStateOf(initialIsExam) }

    val actionTitle = when (confirmActionType) {
        AttendanceConfirmType.CHECK_IN -> "تأكيد تسجيل حضور الأستاذ 📥"
        AttendanceConfirmType.CHECK_OUT -> "تأكيد تسجيل انصراف الأستاذ 📤"
        AttendanceConfirmType.ABSENT -> "تأكيد تسجيل الغياب ❌"
        AttendanceConfirmType.EXCUSED -> "تأكيد تسجيل الاستئذان 🔵"
        AttendanceConfirmType.LEAVE -> "تأكيد تسجيل الإجازة 🟡"
    }

    val themeColor = when (confirmActionType) {
        AttendanceConfirmType.CHECK_IN -> DawamiNavy
        AttendanceConfirmType.CHECK_OUT -> DawamiTeal
        AttendanceConfirmType.ABSENT -> Color(0xFFDC2626)
        AttendanceConfirmType.EXCUSED -> Color(0xFF0284C7)
        AttendanceConfirmType.LEAVE -> Color(0xFFD97706)
    }

    val schedTime = if (isCheckIn) (selectedCourse?.startTime ?: "") else if (isCheckOut) (selectedCourse?.endTime ?: "") else ""
    val timeDiffMinutes = remember(confirmSelectedTime, schedTime) {
        if (schedTime.isNotEmpty()) calculateTimeDiffMinutes(confirmSelectedTime, schedTime) else null
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(themeColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (confirmActionType) {
                                AttendanceConfirmType.CHECK_IN -> Icons.Default.Login
                                AttendanceConfirmType.CHECK_OUT -> Icons.Default.Logout
                                AttendanceConfirmType.ABSENT -> Icons.Default.Close
                                AttendanceConfirmType.EXCUSED -> Icons.Default.Info
                                AttendanceConfirmType.LEAVE -> Icons.Default.DateRange
                            },
                            contentDescription = null,
                            tint = themeColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            text = actionTitle,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = DawamiNavy
                        )
                        Text(
                            text = "تأكيد البيانات قبل الحفظ النهائي",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Info Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        InfoRow(Icons.Default.Person, "المستهدف:", loggedInUser)
                        InfoRow(Icons.Default.School, "الدورة:", selectedCourse?.name ?: "غير محددة")
                        InfoRow(Icons.Default.Book, "المادة:", subjectName.ifEmpty { "غير محددة" })
                        InfoRow(Icons.Default.DateRange, "التاريخ:", "$attendanceDay | $attendanceDate")
                    }
                }

                // Exam Checkbox
                if (isCheckIn) {
                    Surface(
                        color = if (isExamDaySelected) Color(0xFFFEF3C7) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, if (isExamDaySelected) Color(0xFFD97706) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isExamDaySelected = !isExamDaySelected }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Checkbox(
                                checked = isExamDaySelected,
                                onCheckedChange = { isExamDaySelected = it },
                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFFD97706))
                            )
                            Text(
                                text = "📝 تعيين جلسة اليوم كامتحان / اختبار",
                                fontSize = 13.sp,
                                fontWeight = if (isExamDaySelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isExamDaySelected) Color(0xFF92400E) else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Plan Status Warning
                if (isPlanFinished && (isCheckIn || isCheckOut)) {
                    Surface(
                        color = if (isExceedingPlan) Color(0xFFFEF2F2) else Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, if (isExceedingPlan) Color(0xFFEF4444).copy(alpha = 0.5f) else Color(0xFF22C55E).copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (isExceedingPlan) Icons.Default.Warning else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (isExceedingPlan) Color(0xFFDC2626) else Color(0xFF16A34A),
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = if (isExceedingPlan) "تنبيه: تجاوز أيام الخطة المجدولة!" else "اليوم الأخير في خطة المادة 🏁",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isExceedingPlan) Color(0xFF991B1B) else Color(0xFF166534)
                                )
                                Text(
                                    text = "اليوم الحالي: ($currentDayNumber) من أصل ($targetDays) أيام. " + 
                                           if (!isExamDaySelected) "سيتم اعتبار اليوم 'تكميلياً' ما لم تحدد خيار الامتحان." else "سيتم إغلاق المادة كمكتملة بعد الحفظ.",
                                    fontSize = 10.sp,
                                    color = if (isExceedingPlan) Color(0xFFB91C1C) else Color(0xFF15803D)
                                )
                            }
                        }
                    }
                }

                // Time Display Card
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isCheckIn) Color(0xFFF0FDF4) else Color(0xFFF0F9FF),
                    border = BorderStroke(2.dp, if (isCheckIn) Color(0xFF86EFAC) else Color(0xFFBAE6FD)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "⏰ الوقت المسجل في البطاقة:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCheckIn) Color(0xFF166534) else Color(0xFF075985)
                        )
                        
                        Text(
                            text = formatTimeTo12HourArabic(confirmSelectedTime),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isCheckIn) Color(0xFF15803D) else Color(0xFF0284C7)
                        )
                        Text(
                            text = "التوقيت الفعلي: $confirmSelectedTime",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )

                        // Feedback Analysis
                        if (schedTime.isNotEmpty() && timeDiffMinutes != null) {
                            val feedbackBg: Color
                            val feedbackBorder: Color
                            val feedbackText: String
                            val feedbackTextColor: Color

                            if (isCheckIn) {
                                when {
                                    timeDiffMinutes > 0 -> {
                                        feedbackBg = Color(0xFFFEF3C7)
                                        feedbackBorder = Color(0xFFFCD34D)
                                        feedbackTextColor = Color(0xFFB45309)
                                        feedbackText = "⚠️ تأخير بمقدار ($timeDiffMinutes د) عن الموعد المجدول (${formatTimeTo12HourArabic(schedTime)})"
                                    }
                                    timeDiffMinutes == 0 -> {
                                        feedbackBg = Color(0xFFDCFCE7)
                                        feedbackBorder = Color(0xFF86EFAC)
                                        feedbackTextColor = Color(0xFF15803D)
                                        feedbackText = "✅ في الموعد المجدول تماماً (${formatTimeTo12HourArabic(schedTime)})"
                                    }
                                    else -> {
                                        feedbackBg = Color(0xFFCCFBF1)
                                        feedbackBorder = Color(0xFF5EEAD4)
                                        feedbackTextColor = Color(0xFF0F766E)
                                        feedbackText = "⚡ حضور مبكر بـ (${-timeDiffMinutes} د) قبل الموعد (${formatTimeTo12HourArabic(schedTime)})"
                                    }
                                }
                            } else {
                                when {
                                    timeDiffMinutes < 0 -> {
                                        feedbackBg = Color(0xFFFFEDD5)
                                        feedbackBorder = Color(0xFFFDBA74)
                                        feedbackTextColor = Color(0xFFC2410C)
                                        feedbackText = "⚠️ انصراف مبكر قبل موعد النهاية بـ (${-timeDiffMinutes} د) (${formatTimeTo12HourArabic(schedTime)})"
                                    }
                                    timeDiffMinutes == 0 -> {
                                        feedbackBg = Color(0xFFDCFCE7)
                                        feedbackBorder = Color(0xFF86EFAC)
                                        feedbackTextColor = Color(0xFF15803D)
                                        feedbackText = "✅ في موعد الانصراف المجدول تماماً"
                                    }
                                    else -> {
                                        feedbackBg = Color(0xFFE0F2FE)
                                        feedbackBorder = Color(0xFF7DD3FC)
                                        feedbackTextColor = Color(0xFF0369A1)
                                        feedbackText = "ℹ️ انصراف بعد الموعد المجدول بـ ($timeDiffMinutes د)"
                                    }
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = feedbackBg,
                                border = BorderStroke(1.dp, feedbackBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = feedbackText,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = feedbackTextColor,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                // Quick Time Options
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الخيارات السريعة للتوقيت:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                    
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            QuickTimeChip(
                                label = "⚡ الآن (${formatTimeTo12HourArabic(currentTime)})",
                                isSelected = confirmSelectedTime == currentTime,
                                onClick = { confirmSelectedTime = currentTime },
                                modifier = Modifier.weight(1f)
                            )
                            if (schedTime.isNotEmpty()) {
                                QuickTimeChip(
                                    label = "📅 المجدول (${formatTimeTo12HourArabic(schedTime)})",
                                    isSelected = confirmSelectedTime == schedTime,
                                    onClick = { confirmSelectedTime = schedTime },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        
                        // Current time in field option (User Request!)
                        val fieldTime = if (isCheckIn) fieldCheckIn else fieldCheckOut
                        if (fieldTime.isNotEmpty() && fieldTime != currentTime && fieldTime != schedTime) {
                            QuickTimeChip(
                                label = "✏️ وقت الحقل الحالي (${formatTimeTo12HourArabic(fieldTime)})",
                                isSelected = confirmSelectedTime == fieldTime,
                                onClick = { confirmSelectedTime = fieldTime },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    // Fine tune buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("تعديل دقائق:", fontSize = 10.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.weight(1f))
                        listOf(-5, -1, 1, 5).forEach { delta ->
                            Surface(
                                onClick = { confirmSelectedTime = adjustTimeMinutes(confirmSelectedTime, delta) },
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Text(
                                    text = if (delta > 0) "+$delta" else "$delta",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Footer Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("تراجع", fontSize = 13.sp)
                    }
                    Button(
                        onClick = { onConfirm(confirmSelectedTime, isExamDaySelected) },
                        modifier = Modifier.weight(1.5f),
                        colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("اعتماد وحفظ ✅", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(icon, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = "$label ", fontSize = 11.sp, color = DawamiNavy.copy(alpha = 0.7f))
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
    }
}

@Composable
private fun QuickTimeChip(label: String, isSelected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) DawamiNavy.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (isSelected) DawamiNavy else MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier
    ) {
        Box(modifier = Modifier.padding(vertical = 8.dp, horizontal = 12.dp), contentAlignment = Alignment.Center) {
            Text(text = label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium, color = DawamiNavy)
        }
    }
}
