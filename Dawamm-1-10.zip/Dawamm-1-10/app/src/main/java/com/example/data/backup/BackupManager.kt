package com.example.data.backup

import android.content.Context
import android.util.Log
import androidx.room.withTransaction
import com.example.data.database.AppDatabase
import com.example.data.entity.*
import com.example.data.repository.AppRepository
import com.example.ui.components.FunnyPenaltyHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

/**
 * BackupOptions specifies granular flags for exporting data.
 * Absolute Isolation: Each table/dataset has an independent boolean flag.
 */
data class BackupOptions(
    val includeCourses: Boolean = true,
    val includeStudents: Boolean = true,
    val includeAttendance: Boolean = true,
    val includeStudentAttendance: Boolean = true,
    val includeDailyNotes: Boolean = true,
    val includeSubjects: Boolean = true,
    val includeCourseSubjects: Boolean = true,
    val includeLessonTopics: Boolean = true,
    val includeLessonSessionTopics: Boolean = true,
    val includeGradeConfigs: Boolean = true,
    val includeStudentGrades: Boolean = true,
    val includeAssignmentTemplates: Boolean = true,
    val includeAssignmentSubmissions: Boolean = true,
    val includeTrainerTransactions: Boolean = true,
    val includeSubjectReferences: Boolean = true,
    val includeActivityLogs: Boolean = true,
    val includeStudentViolations: Boolean = true,
    val includeOfficialHolidays: Boolean = true,
    val includeSettings: Boolean = true,
    val includeFunnyPenalties: Boolean = true,
    val includeManualAssignmentModes: Boolean = true,

    // Backward-compatibility grouped options
    val includeCoursesAndStudents: Boolean? = null,
    val includeTopics: Boolean? = null,
    val includeAssignments: Boolean? = null,
    val includeFinances: Boolean? = null,
    val includeViolations: Boolean? = null
) {
    val courses: Boolean get() = includeCoursesAndStudents ?: includeCourses
    val students: Boolean get() = includeCoursesAndStudents ?: includeStudents
    val attendance: Boolean get() = includeAttendance
    val studentAttendance: Boolean get() = includeStudentAttendance
    val dailyNotes: Boolean get() = includeDailyNotes
    val subjects: Boolean get() = includeSubjects
    val courseSubjects: Boolean get() = includeCourseSubjects
    val lessonTopics: Boolean get() = includeTopics ?: includeLessonTopics
    val lessonSessionTopics: Boolean get() = includeTopics ?: includeLessonSessionTopics
    val gradeConfigs: Boolean get() = includeGradeConfigs
    val studentGrades: Boolean get() = includeStudentGrades
    val assignmentTemplates: Boolean get() = includeAssignments ?: includeAssignmentTemplates
    val assignmentSubmissions: Boolean get() = includeAssignments ?: includeAssignmentSubmissions
    val trainerTransactions: Boolean get() = includeFinances ?: includeTrainerTransactions
    val subjectReferences: Boolean get() = includeSubjectReferences
    val activityLogs: Boolean get() = includeActivityLogs
    val studentViolations: Boolean get() = includeViolations ?: includeStudentViolations
    val officialHolidays: Boolean get() = includeOfficialHolidays
    val settings: Boolean get() = includeSettings
    val funnyPenalties: Boolean get() = includeFunnyPenalties
    val manualAssignmentModes: Boolean get() = includeManualAssignmentModes
}

/**
 * RestoreOptions specifies granular flags for restoring data.
 * Absolute Isolation: Any table with its flag set to false MUST NOT be modified or deleted.
 */
data class RestoreOptions(
    val restoreCourses: Boolean = true,
    val restoreStudents: Boolean = true,
    val restoreAttendance: Boolean = true,
    val restoreStudentAttendance: Boolean = true,
    val restoreDailyNotes: Boolean = true,
    val restoreSubjects: Boolean = true,
    val restoreCourseSubjects: Boolean = true,
    val restoreLessonTopics: Boolean = true,
    val restoreLessonSessionTopics: Boolean = true,
    val restoreGradeConfigs: Boolean = true,
    val restoreStudentGrades: Boolean = true,
    val restoreAssignmentTemplates: Boolean = true,
    val restoreAssignmentSubmissions: Boolean = true,
    val restoreTrainerTransactions: Boolean = true,
    val restoreSubjectReferences: Boolean = true,
    val restoreActivityLogs: Boolean = true,
    val restoreStudentViolations: Boolean = true,
    val restoreOfficialHolidays: Boolean = true,
    val restoreSettings: Boolean = true,
    val restoreFunnyPenalties: Boolean = true,
    val restoreManualAssignmentModes: Boolean = true,

    // Backward-compatibility grouped options
    val restorePrep: Boolean? = null,
    val restoreFinances: Boolean? = null
) {
    val courses: Boolean get() = restoreCourses
    val students: Boolean get() = restoreStudents
    val attendance: Boolean get() = restoreAttendance
    val studentAttendance: Boolean get() = restoreStudentAttendance
    val dailyNotes: Boolean get() = restorePrep ?: restoreDailyNotes
    val subjects: Boolean get() = restoreSubjects
    val courseSubjects: Boolean get() = restoreCourseSubjects
    val lessonTopics: Boolean get() = restorePrep ?: restoreLessonTopics
    val lessonSessionTopics: Boolean get() = restorePrep ?: restoreLessonSessionTopics
    val gradeConfigs: Boolean get() = restoreGradeConfigs
    val studentGrades: Boolean get() = restoreStudentGrades
    val assignmentTemplates: Boolean get() = restoreAssignmentTemplates
    val assignmentSubmissions: Boolean get() = restoreAssignmentSubmissions
    val trainerTransactions: Boolean get() = restoreFinances ?: restoreTrainerTransactions
    val subjectReferences: Boolean get() = restoreSubjectReferences
    val activityLogs: Boolean get() = restoreActivityLogs
    val studentViolations: Boolean get() = restoreStudentViolations
    val officialHolidays: Boolean get() = restoreOfficialHolidays
    val settings: Boolean get() = restoreSettings
    val funnyPenalties: Boolean get() = restoreFunnyPenalties
    val manualAssignmentModes: Boolean get() = restoreManualAssignmentModes
}

/**
 * Detailed pre-flight inspection report of a backup JSON.
 */
data class BackupAnalysisReport(
    val isValid: Boolean,
    val version: Int = 0,
    val timestamp: Long = 0L,
    val formattedDate: String = "",
    val backupType: String = "FULL", // "FULL" or "PARTIAL"
    val selectedTables: List<String> = emptyList(),
    val integrityValid: Boolean = true,
    val integrityMessage: String = "",
    val tableCounts: Map<String, Int> = emptyMap(),
    val currentDbCounts: Map<String, Int> = emptyMap(),
    val hasSettings: Boolean = false,
    val hasPenalties: Boolean = false,
    val warnings: List<String> = emptyList(),
    val rawJson: String = ""
)

/**
 * Detailed result of a restore operation with verification logs.
 */
data class RestoreResult(
    val success: Boolean,
    val message: String,
    val restoredCounts: Map<String, Int> = emptyMap(),
    val verificationPassed: Boolean = false,
    val errors: List<String> = emptyList(),
    val snapshotPath: String = ""
)

/**
 * Result of the programmatic automated verification test suite.
 */
data class VerificationTestSuiteResult(
    val allPassed: Boolean,
    val fullBackup: String,
    val fullRestore: String,
    val partialBackup: String,
    val partialRestore: String,
    val tableIsolation: String,
    val deepValueComparison: String,
    val hashIntegrity: String,
    val safetySnapshot: String,
    val rollbackTest: String,
    val foreignKeyTest: String,
    val roundTripTest: String,
    val allRoomEntitiesTest: String,
    val allFieldsExportedTest: String,
    val allFieldsRestoredTest: String,
    val testLog: List<String>
)

/**
 * BackupManager v3 - Centralized, 100% loss-free, strictly isolated,
 * deeply verified backup & restore engine across all 17 Room entities and preferences.
 */
class BackupManager(
    private val context: Context,
    private val database: AppDatabase,
    private val repository: AppRepository
) {
    companion object {
        const val CURRENT_BACKUP_VERSION = 3
        const val APP_IDENTIFIER = "Dawami"
        private const val PREFS_NAME = "dawami_prefs"
        private const val SNAPSHOT_DIR_NAME = "safety_snapshots"
        private const val SNAPSHOT_FILE_NAME = "safety_snapshot_latest.json"
    }

    // JSON opt helpers
    private fun JSONObject.optStr(key: String, fallback: String = ""): String =
        if (has(key) && !isNull(key)) optString(key, fallback) else fallback

    private fun JSONObject.optI(key: String, fallback: Int = 0): Int =
        if (has(key) && !isNull(key)) optInt(key, fallback) else fallback

    private fun JSONObject.optL(key: String, fallback: Long = 0L): Long =
        if (has(key) && !isNull(key)) optLong(key, fallback) else fallback

    private fun JSONObject.optD(key: String, fallback: Double = 0.0): Double =
        if (has(key) && !isNull(key)) optDouble(key, fallback) else fallback

    private fun JSONObject.optB(key: String, fallback: Boolean = false): Boolean =
        if (has(key) && !isNull(key)) optBoolean(key, fallback) else fallback

    private fun computeSha256(text: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(text.toByteArray(Charsets.UTF_8))
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Converts a JSONObject or JSONArray into a canonical, deterministic JSON string representation.
     * - Keys in JSONObjects are recursively sorted alphabetically.
     * - JSONArrays for entity tables are sorted by Primary Key.
     * - Floating numbers are formatted consistently.
     */
    fun toCanonicalRepresentation(element: Any?): Any? {
        return when (element) {
            is JSONObject -> {
                val sortedObj = JSONObject()
                val keys = mutableListOf<String>()
                element.keys().forEach { keys.add(it) }
                keys.sort()
                for (key in keys) {
                    if (key == "integrity_hash") continue
                    val value = element.get(key)
                    sortedObj.put(key, toCanonicalRepresentation(value))
                }
                sortedObj
            }
            is JSONArray -> {
                val list = mutableListOf<Any?>()
                for (i in 0 until element.length()) {
                    list.add(toCanonicalRepresentation(element.get(i)))
                }
                // Sort entity arrays deterministically if elements are JSONObjects with 'id' or compound PKs
                list.sortWith(Comparator { a, b ->
                    if (a is JSONObject && b is JSONObject) {
                        val idA = if (a.has("id")) a.opt("id").toString() else if (a.has("courseId") && a.has("subjectId")) "${a.opt("courseId")}_${a.opt("subjectId")}" else if (a.has("courseId")) a.opt("courseId").toString() else ""
                        val idB = if (b.has("id")) b.opt("id").toString() else if (b.has("courseId") && b.has("subjectId")) "${b.opt("courseId")}_${b.opt("subjectId")}" else if (b.has("courseId")) b.opt("courseId").toString() else ""
                        idA.compareTo(idB)
                    } else {
                        a.toString().compareTo(b.toString())
                    }
                })
                val sortedArray = JSONArray()
                list.forEach { sortedArray.put(it) }
                sortedArray
            }
            else -> element
        }
    }

    fun computeCanonicalPayloadHash(jsonObj: JSONObject): String {
        val canonicalObj = toCanonicalRepresentation(jsonObj) as JSONObject
        return computeSha256(canonicalObj.toString())
    }

    /**
     * Export database and configuration into a validated, loss-free JSON string.
     */
    suspend fun exportBackupJson(options: BackupOptions? = null): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        val now = System.currentTimeMillis()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US)

        root.put("app", APP_IDENTIFIER)
        root.put("backup_version", CURRENT_BACKUP_VERSION)
        root.put("timestamp", now)
        root.put("created_at", dateFormat.format(Date(now)))

        val isFullBackup = options == null
        root.put("backup_type", if (isFullBackup) "FULL" else "PARTIAL")

        val opts = options ?: BackupOptions()
        val selectedTablesList = mutableListOf<String>()

        // 1. Courses
        if (isFullBackup || opts.courses) {
            selectedTablesList.add("courses")
            val courses = repository.allCourses.first()
            val coursesArray = JSONArray()
            courses.forEach { c ->
                val obj = JSONObject()
                obj.put("id", c.id)
                obj.put("name", c.name)
                obj.put("startDate", c.startDate)
                obj.put("endDate", c.endDate)
                obj.put("startTime", c.startTime)
                obj.put("endTime", c.endTime)
                obj.put("departmentName", c.departmentName)
                obj.put("diplomaName", c.diplomaName)
                obj.put("trainerName", c.trainerName)
                obj.put("isCompleted", c.isCompleted)
                coursesArray.put(obj)
            }
            root.put("courses", coursesArray)
        }

        // 2. Subjects
        if (isFullBackup || opts.subjects) {
            selectedTablesList.add("subjects")
            val subjects = repository.allSubjects.first()
            val subjectsArray = JSONArray()
            subjects.forEach { s ->
                val obj = JSONObject()
                obj.put("id", s.id)
                obj.put("name", s.name)
                obj.put("code", s.code)
                obj.put("description", s.description)
                obj.put("departmentName", s.departmentName)
                obj.put("diplomaName", s.diplomaName)
                subjectsArray.put(obj)
            }
            root.put("subjects", subjectsArray)
        }

        // 3. Course Subjects
        if (isFullBackup || opts.courseSubjects) {
            selectedTablesList.add("course_subjects")
            val courseSubjects = repository.allCourseSubjects.first()
            val courseSubjectsArray = JSONArray()
            courseSubjects.forEach { cs ->
                val obj = JSONObject()
                obj.put("courseId", cs.courseId)
                obj.put("subjectId", cs.subjectId)
                obj.put("status", cs.status)
                obj.put("targetDays", cs.targetDays)
                obj.put("completedDate", cs.completedDate)
                obj.put("notes", cs.notes)
                courseSubjectsArray.put(obj)
            }
            root.put("course_subjects", courseSubjectsArray)
        }

        // 4. Students
        if (isFullBackup || opts.students) {
            selectedTablesList.add("students")
            val students = repository.allStudents.first()
            val studentsArray = JSONArray()
            students.forEach { st ->
                val obj = JSONObject()
                obj.put("id", st.id)
                obj.put("name", st.name)
                obj.put("courseId", st.courseId)
                obj.put("courseName", st.courseName)
                obj.put("phoneNumber", st.phoneNumber)
                obj.put("status", st.status)
                obj.put("statusChangeDate", st.statusChangeDate) // 1:1 FIELD AUDIT FIX
                studentsArray.put(obj)
            }
            root.put("students", studentsArray)
        }

        // 5. Attendance Records
        if (isFullBackup || opts.attendance) {
            selectedTablesList.add("attendance")
            val attendanceRecords = repository.allAttendance.first()
            val attendanceArray = JSONArray()
            attendanceRecords.forEach { att ->
                val obj = JSONObject()
                obj.put("id", att.id)
                obj.put("courseId", att.courseId)
                obj.put("courseName", att.courseName)
                obj.put("dayOfWeek", att.dayOfWeek)
                obj.put("date", att.date)
                obj.put("actualCheckIn", att.actualCheckIn)
                obj.put("actualCheckOut", att.actualCheckOut)
                obj.put("checkInDelayMinutes", att.checkInDelayMinutes)
                obj.put("checkOutDifferenceMinutes", att.checkOutDifferenceMinutes)
                obj.put("durationHours", att.durationHours)
                obj.put("durationMinutes", att.durationMinutes)
                obj.put("hasAlert", att.hasAlert)
                obj.put("alertMessage", att.alertMessage)
                obj.put("isLocked", att.isLocked)
                obj.put("status", att.status)
                obj.put("note", att.note)
                obj.put("subjectName", att.subjectName)
                obj.put("systemCreatedAt", att.systemCreatedAt)
                obj.put("isTimeTampered", att.isTimeTampered)
                obj.put("isExamDay", att.isExamDay)
                attendanceArray.put(obj)
            }
            root.put("attendance", attendanceArray)
        }

        // 6. Student Attendance
        if (isFullBackup || opts.studentAttendance) {
            selectedTablesList.add("student_attendance")
            val studentAttendanceRecords = repository.allStudentAttendance.first()
            val studentAttendanceArray = JSONArray()
            studentAttendanceRecords.forEach { sa ->
                val obj = JSONObject()
                obj.put("id", sa.id)
                obj.put("studentId", sa.studentId)
                obj.put("studentName", sa.studentName)
                obj.put("courseId", sa.courseId)
                obj.put("courseName", sa.courseName)
                obj.put("date", sa.date)
                obj.put("dayOfWeek", sa.dayOfWeek)
                obj.put("actualCheckIn", sa.actualCheckIn)
                obj.put("actualCheckOut", sa.actualCheckOut)
                obj.put("checkInDelayMinutes", sa.checkInDelayMinutes)
                obj.put("checkOutDifferenceMinutes", sa.checkOutDifferenceMinutes)
                obj.put("hasAlert", sa.hasAlert)
                obj.put("alertMessage", sa.alertMessage)
                obj.put("status", sa.status)
                obj.put("studentNote", sa.studentNote)
                obj.put("courseDailyNote", sa.courseDailyNote)
                obj.put("participationStars", sa.participationStars)
                obj.put("subjectName", sa.subjectName)
                obj.put("hasResearch", sa.hasResearch)
                obj.put("hasAssignment", sa.hasAssignment)
                obj.put("isOnBreak", sa.isOnBreak)
                obj.put("breakStartTime", sa.breakStartTime)
                obj.put("breakDurationMinutes", sa.breakDurationMinutes)
                obj.put("breakActualReturnTime", sa.breakActualReturnTime)
                obj.put("breakDelayMinutes", sa.breakDelayMinutes)
                obj.put("updatedAt", sa.updatedAt)
                studentAttendanceArray.put(obj)
            }
            root.put("student_attendance", studentAttendanceArray)
        }

        // 7. Daily Notes
        if (isFullBackup || opts.dailyNotes) {
            selectedTablesList.add("daily_notes")
            val dailyNotes = repository.getAllDailyNotes().first()
            val dailyNotesArray = JSONArray()
            dailyNotes.forEach { dn ->
                val obj = JSONObject()
                obj.put("id", dn.id)
                obj.put("courseId", dn.courseId)
                obj.put("date", dn.date)
                obj.put("note", dn.note)
                dailyNotesArray.put(obj)
            }
            root.put("daily_notes", dailyNotesArray)
        }

        // 8. Lesson Topics
        if (isFullBackup || opts.lessonTopics) {
            selectedTablesList.add("lesson_topics")
            val lessonTopics = repository.allLessonTopics.first()
            val lessonTopicsArray = JSONArray()
            lessonTopics.forEach { lt ->
                val obj = JSONObject()
                obj.put("id", lt.id)
                obj.put("subjectId", lt.subjectId)
                obj.put("courseId", lt.courseId)
                obj.put("title", lt.title)
                obj.put("description", lt.description)
                obj.put("unitName", lt.unitName)
                obj.put("orderIndex", lt.orderIndex)
                obj.put("parentId", lt.parentId ?: JSONObject.NULL)
                obj.put("level", lt.level)
                lessonTopicsArray.put(obj)
            }
            root.put("lesson_topics", lessonTopicsArray)
        }

        // 9. Lesson Session Topics
        if (isFullBackup || opts.lessonSessionTopics) {
            selectedTablesList.add("lesson_session_topics")
            val sessionTopics = repository.allLessonSessionTopics.first()
            val sessionTopicsArray = JSONArray()
            sessionTopics.forEach { lst ->
                val obj = JSONObject()
                obj.put("id", lst.id)
                obj.put("courseId", lst.courseId)
                obj.put("subjectId", lst.subjectId)
                obj.put("topicId", lst.topicId)
                obj.put("date", lst.date)
                obj.put("isCompleted", lst.isCompleted)
                obj.put("completedAt", lst.completedAt)
                obj.put("note", lst.note)
                sessionTopicsArray.put(obj)
            }
            root.put("lesson_session_topics", sessionTopicsArray)
        }

        // 10. Grade Configs
        if (isFullBackup || opts.gradeConfigs) {
            selectedTablesList.add("grade_configs")
            val gradeConfigs = repository.allGradeConfigs.first()
            val gradeConfigsArray = JSONArray()
            gradeConfigs.forEach { gc ->
                val obj = JSONObject()
                obj.put("courseId", gc.courseId)
                obj.put("courseName", gc.courseName)
                obj.put("isDiploma", gc.isDiploma)
                obj.put("customFieldsJson", gc.customFieldsJson)
                obj.put("diplomaSubjectsJson", gc.diplomaSubjectsJson)
                obj.put("subjectWeightsJson", gc.subjectWeightsJson)
                obj.put("passingGradePercentage", gc.passingGradePercentage)
                gradeConfigsArray.put(obj)
            }
            root.put("grade_configs", gradeConfigsArray)
        }

        // 11. Student Grades
        if (isFullBackup || opts.studentGrades) {
            selectedTablesList.add("student_grades")
            val grades = repository.allGrades.first()
            val gradesArray = JSONArray()
            grades.forEach { sg ->
                val obj = JSONObject()
                obj.put("id", sg.id)
                obj.put("studentId", sg.studentId)
                obj.put("studentName", sg.studentName)
                obj.put("courseId", sg.courseId)
                obj.put("courseName", sg.courseName)
                obj.put("isDiploma", sg.isDiploma)
                obj.put("subjectName", sg.subjectName)
                obj.put("attendanceScore", sg.attendanceScore)
                obj.put("participationScore", sg.participationScore)
                obj.put("assignmentsScore", sg.assignmentsScore)
                obj.put("projectsScore", sg.projectsScore)
                obj.put("theoreticalExamScore", sg.theoreticalExamScore)
                obj.put("practicalExamScore", sg.practicalExamScore)
                obj.put("customScoresJson", sg.customScoresJson)
                gradesArray.put(obj)
            }
            root.put("student_grades", gradesArray)
        }

        // 12. Assignment Templates
        if (isFullBackup || opts.assignmentTemplates) {
            selectedTablesList.add("assignment_templates")
            val templates = repository.allAssignmentTemplates.first()
            val templatesArray = JSONArray()
            templates.forEach { tmpl ->
                val obj = JSONObject()
                obj.put("id", tmpl.id)
                obj.put("subjectName", tmpl.subjectName)
                obj.put("title", tmpl.title)
                obj.put("description", tmpl.description)
                obj.put("type", tmpl.type)
                obj.put("maxScore", tmpl.maxScore)
                obj.put("displayOrder", tmpl.displayOrder)
                obj.put("attachmentPath", tmpl.attachmentPath)
                obj.put("attachmentName", tmpl.attachmentName)
                obj.put("courseId", tmpl.courseId)
                obj.put("excludedCourseIdsJson", tmpl.excludedCourseIdsJson)
                templatesArray.put(obj)
            }
            root.put("assignment_templates", templatesArray)
        }

        // 13. Assignment Submissions
        if (isFullBackup || opts.assignmentSubmissions) {
            selectedTablesList.add("assignment_submissions")
            val submissions = repository.allAssignmentSubmissions.first()
            val submissionsArray = JSONArray()
            submissions.forEach { sub ->
                val obj = JSONObject()
                obj.put("id", sub.id)
                obj.put("courseId", sub.courseId)
                obj.put("subjectName", sub.subjectName)
                obj.put("studentId", sub.studentId)
                obj.put("studentName", sub.studentName)
                obj.put("assignmentTitle", sub.assignmentTitle)
                obj.put("isCompleted", sub.isCompleted)
                obj.put("completionDate", sub.completionDate)
                obj.put("evaluationRating", sub.evaluationRating)
                if (sub.score != null) obj.put("score", sub.score) else obj.put("score", JSONObject.NULL)
                obj.put("notes", sub.notes)
                submissionsArray.put(obj)
            }
            root.put("assignment_submissions", submissionsArray)
        }

        // 14. Trainer Transactions
        if (isFullBackup || opts.trainerTransactions) {
            selectedTablesList.add("trainer_transactions")
            val transactions = repository.allTrainerTransactions.first()
            val transactionsArray = JSONArray()
            transactions.forEach { tx ->
                val obj = JSONObject()
                obj.put("id", tx.id)
                obj.put("courseId", tx.courseId)
                obj.put("courseName", tx.courseName)
                obj.put("amount", tx.amount)
                obj.put("date", tx.date)
                obj.put("type", tx.type)
                obj.put("note", tx.note)
                obj.put("timestamp", tx.timestamp)
                transactionsArray.put(obj)
            }
            root.put("trainer_transactions", transactionsArray)
        }

        // 15. Activity Logs
        if (isFullBackup || opts.activityLogs) {
            selectedTablesList.add("activity_logs")
            val activityLogs = repository.allActivityLogs.first()
            val activityLogsArray = JSONArray()
            activityLogs.forEach { log ->
                val obj = JSONObject()
                obj.put("id", log.id)
                obj.put("timestamp", log.timestamp)
                obj.put("dateStr", log.dateStr)
                obj.put("timeStr", log.timeStr)
                obj.put("category", log.category)
                obj.put("actionType", log.actionType)
                obj.put("title", log.title)
                obj.put("description", log.description)
                if (log.relatedId != null) obj.put("relatedId", log.relatedId)
                activityLogsArray.put(obj)
            }
            root.put("activity_logs", activityLogsArray)
        }

        // 16. Subject References
        if (isFullBackup || opts.subjectReferences) {
            selectedTablesList.add("subject_references")
            val references = repository.allReferences.first()
            val referencesArray = JSONArray()
            references.forEach { sr ->
                val obj = JSONObject()
                obj.put("id", sr.id)
                obj.put("subjectName", sr.subjectName)
                obj.put("department", sr.department)
                obj.put("diploma", sr.diploma)
                obj.put("title", sr.title)
                obj.put("type", sr.type)
                obj.put("urlOrPath", sr.urlOrPath)
                obj.put("fileName", sr.fileName)
                obj.put("dateAdded", sr.dateAdded)
                referencesArray.put(obj)
            }
            root.put("subject_references", referencesArray)
        }

        // 17. Student Violations
        if (isFullBackup || opts.studentViolations) {
            selectedTablesList.add("student_violations")
            val violations = repository.allViolations.first()
            val violationsArray = JSONArray()
            violations.forEach { v ->
                val obj = JSONObject()
                obj.put("id", v.id)
                obj.put("courseId", v.courseId)
                obj.put("subjectName", v.subjectName)
                obj.put("studentId", v.studentId)
                obj.put("studentName", v.studentName)
                obj.put("studentPhone", v.studentPhone)
                obj.put("violationType", v.violationType)
                obj.put("violationTitle", v.violationTitle)
                obj.put("actionTaken", v.actionTaken)
                obj.put("date", v.date)
                obj.put("time", v.time)
                obj.put("notes", v.notes)
                obj.put("createdAt", v.createdAt)
                violationsArray.put(obj)
            }
            root.put("student_violations", violationsArray)
        }

        // 17b. Official Holidays
        if (isFullBackup || opts.officialHolidays) {
            selectedTablesList.add("official_holidays")
            val holidays = repository.allOfficialHolidays.first()
            val holidaysArray = JSONArray()
            holidays.forEach { h ->
                val obj = JSONObject()
                obj.put("id", h.id)
                obj.put("name", h.name)
                obj.put("startDate", h.startDate)
                obj.put("endDate", h.endDate)
                obj.put("isEnabled", h.isEnabled)
                obj.put("notes", h.notes)
                holidaysArray.put(obj)
            }
            root.put("official_holidays", holidaysArray)
        }

        // 18. Settings
        val sharedPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (isFullBackup || opts.settings) {
            val settingsObj = JSONObject()
            settingsObj.put("institute_name", sharedPrefs.getString("institute_name", "معهد دوامي للتدريب"))
            settingsObj.put("org_type", sharedPrefs.getString("org_type", "معهد تدريبي"))
            settingsObj.put("director_name", sharedPrefs.getString("director_name", ""))
            settingsObj.put("institute_logo_uri", sharedPrefs.getString("institute_logo_uri", ""))
            settingsObj.put("has_completed_onboarding", sharedPrefs.getBoolean("has_completed_onboarding", true))
            settingsObj.put("is_dark_theme", sharedPrefs.getBoolean("is_dark_theme", false))
            settingsObj.put("include_lesson_topics_in_report", sharedPrefs.getBoolean("include_lesson_topics_in_report", true))
            settingsObj.put("teacher_report_time_option", sharedPrefs.getString("teacher_report_time_option", "after_session"))
            settingsObj.put("custom_teacher_report_time", sharedPrefs.getString("custom_teacher_report_time", "20:00"))
            settingsObj.put("max_cumulative_delay", sharedPrefs.getInt("max_cumulative_delay", 60))
            settingsObj.put("max_weekly_absence", sharedPrefs.getInt("max_weekly_absence", 2))
            settingsObj.put("max_monthly_absence", sharedPrefs.getInt("max_monthly_absence", 5))
            settingsObj.put("saved_username", sharedPrefs.getString("saved_username", "admin"))
            settingsObj.put("saved_password", sharedPrefs.getString("saved_password", "admin"))
            root.put("settings", settingsObj)
        }

        // 19. Funny Penalties
        if (isFullBackup || opts.funnyPenalties) {
            val funnyPenaltiesList = FunnyPenaltyHelper.getPenalties(context)
            val funnyPenaltiesArray = JSONArray()
            funnyPenaltiesList.forEach { funnyPenaltiesArray.put(it) }
            root.put("funny_penalties", funnyPenaltiesArray)
        }

        // 20. Manual Assignment Modes, Course Grading Modes & Trainer Notes
        if (isFullBackup || opts.manualAssignmentModes || opts.courses) {
            val manualModesObj = JSONObject()
            sharedPrefs.all.forEach { (key, value) ->
                if (key.startsWith("manual_assignment_mode_") && value is Boolean) {
                    val courseSubKey = key.removePrefix("manual_assignment_mode_")
                    manualModesObj.put(courseSubKey, value)
                } else if (key.startsWith("course_grading_mode_") && value is String) {
                    val courseKey = key.removePrefix("course_grading_mode_")
                    manualModesObj.put("grading_mode_$courseKey", value)
                } else if (key.startsWith("course_trainer_notes_") && value is String) {
                    val courseKey = key.removePrefix("course_trainer_notes_")
                    manualModesObj.put("trainer_notes_$courseKey", value)
                }
            }
            root.put("manual_assignment_modes", manualModesObj)
        }

        val selArray = JSONArray()
        selectedTablesList.forEach { selArray.put(it) }
        root.put("selected_tables", selArray)

        // STRICT FULL BACKUP CHECK (Requirement #14)
        if (isFullBackup) {
            val roomTableMap = mapOf(
                "courses" to repository.allCourses.first().size,
                "subjects" to repository.allSubjects.first().size,
                "course_subjects" to repository.allCourseSubjects.first().size,
                "students" to repository.allStudents.first().size,
                "attendance" to repository.allAttendance.first().size,
                "student_attendance" to repository.allStudentAttendance.first().size,
                "daily_notes" to repository.getAllDailyNotes().first().size,
                "lesson_topics" to repository.allLessonTopics.first().size,
                "lesson_session_topics" to repository.allLessonSessionTopics.first().size,
                "grade_configs" to repository.allGradeConfigs.first().size,
                "student_grades" to repository.allGrades.first().size,
                "assignment_templates" to repository.allAssignmentTemplates.first().size,
                "assignment_submissions" to repository.allAssignmentSubmissions.first().size,
                "trainer_transactions" to repository.allTrainerTransactions.first().size,
                "activity_logs" to repository.allActivityLogs.first().size,
                "subject_references" to repository.allReferences.first().size,
                "student_violations" to repository.allViolations.first().size
            )

            for ((tName, dbCount) in roomTableMap) {
                if (dbCount > 0) {
                    val jsonLen = root.optJSONArray(tName)?.length() ?: 0
                    if (jsonLen != dbCount) {
                        throw IllegalStateException("فشل إنشاء النسخة الكلية: الجدول $tName يحتوي على $dbCount سطر بينما الـ JSON يحتوي على $jsonLen")
                    }
                }
            }
        }

        // Integrity SHA-256 Hash
        val payloadHash = computeCanonicalPayloadHash(root)
        root.put("integrity_hash", payloadHash)

        root.toString(2)
    }

    /**
     * Pre-Flight Analysis: Inspects backup JSON without touching database.
     */
    suspend fun analyzeBackupJson(jsonString: String): BackupAnalysisReport = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            val version = root.optInt("backup_version", 0)
            if (version == 0) {
                return@withContext BackupAnalysisReport(
                    isValid = false,
                    warnings = listOf("ملف النسخة الاحتياطية غير صالح أو رقم الإصدار مفقود (backup_version=0)")
                )
            }

            val timestamp = root.optLong("timestamp", 0L)
            val dateFormat = SimpleDateFormat("yyyy/MM/dd - HH:mm:ss", Locale("ar"))
            val formattedDate = if (timestamp > 0L) {
                try { dateFormat.format(Date(timestamp)) } catch (e: Exception) { "تاريخ غير معروف" }
            } else {
                "تاريخ غير معروف"
            }

            val backupType = root.optStr("backup_type", "FULL")
            val selTables = mutableListOf<String>()
            val selArray = root.optJSONArray("selected_tables")
            if (selArray != null) {
                for (i in 0 until selArray.length()) {
                    selTables.add(selArray.getString(i))
                }
            }

            // Integrity Check
            val storedHash = root.optStr("integrity_hash")
            val calculatedHash = computeCanonicalPayloadHash(root)
            val integrityValid = storedHash.isEmpty() || storedHash == calculatedHash
            val integrityMsg = if (integrityValid) "توقيع SHA-256 مطابق وسلامة البيانات مؤكدة"
            else "فشل التحقق من التوقيع الرقمي SHA-256! الملف قد يكون تعرض للتعديل أو التلف."

            val tableCounts = mutableMapOf<String, Int>()
            val tableKeys = listOf(
                "courses", "subjects", "course_subjects", "students", "attendance",
                "student_attendance", "daily_notes", "lesson_topics", "lesson_session_topics",
                "grade_configs", "student_grades", "assignment_templates", "assignment_submissions",
                "trainer_transactions", "activity_logs", "subject_references", "student_violations",
                "official_holidays"
            )

            tableKeys.forEach { key ->
                val arr = root.optJSONArray(key)
                if (arr != null) {
                    tableCounts[key] = arr.length()
                }
            }

            val currentDbCounts = mutableMapOf<String, Int>()
            try {
                currentDbCounts["courses"] = repository.allCourses.first().size
                currentDbCounts["subjects"] = repository.allSubjects.first().size
                currentDbCounts["course_subjects"] = repository.allCourseSubjects.first().size
                currentDbCounts["students"] = repository.allStudents.first().size
                currentDbCounts["attendance"] = repository.allAttendance.first().size
                currentDbCounts["student_attendance"] = repository.allStudentAttendance.first().size
                currentDbCounts["daily_notes"] = repository.getAllDailyNotes().first().size
                currentDbCounts["lesson_topics"] = repository.allLessonTopics.first().size
                currentDbCounts["lesson_session_topics"] = repository.allLessonSessionTopics.first().size
                currentDbCounts["grade_configs"] = repository.allGradeConfigs.first().size
                currentDbCounts["student_grades"] = repository.allGrades.first().size
                currentDbCounts["assignment_templates"] = repository.allAssignmentTemplates.first().size
                currentDbCounts["assignment_submissions"] = repository.allAssignmentSubmissions.first().size
                currentDbCounts["trainer_transactions"] = repository.allTrainerTransactions.first().size
                currentDbCounts["activity_logs"] = repository.allActivityLogs.first().size
                currentDbCounts["subject_references"] = repository.allReferences.first().size
                currentDbCounts["student_violations"] = repository.allViolations.first().size
                currentDbCounts["official_holidays"] = repository.allOfficialHolidays.first().size
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val warnings = mutableListOf<String>()
            if (!integrityValid) warnings.add("تنبيه أمني: التوقيع الرقمي للملف غير مطابق!")
            if (backupType == "FULL") {
                tableKeys.forEach { k ->
                    val cDb = currentDbCounts[k] ?: 0
                    val cBk = tableCounts[k] ?: 0
                    if (cBk == 0 && cDb > 0) {
                        warnings.add("تحذير: النسخة الكلية لا تحتوي بيانات للجدول $k رغم وجود $cDb سجل حاليًا في القاعدة.")
                    }
                }
            }

            BackupAnalysisReport(
                isValid = true,
                version = version,
                timestamp = timestamp,
                formattedDate = formattedDate,
                backupType = backupType,
                selectedTables = selTables,
                integrityValid = integrityValid,
                integrityMessage = integrityMsg,
                tableCounts = tableCounts,
                currentDbCounts = currentDbCounts,
                hasSettings = root.has("settings"),
                hasPenalties = root.has("funny_penalties"),
                warnings = warnings,
                rawJson = jsonString
            )
        } catch (e: Exception) {
            BackupAnalysisReport(
                isValid = false,
                warnings = listOf("فشل تحليل هيكل JSON: ${e.localizedMessage}")
            )
        }
    }

    /**
     * Create a persistent Safety Snapshot on disk before restore.
     * Stops restore if failed (Requirement #13).
     */
    suspend fun createSafetySnapshot(): String = withContext(Dispatchers.IO) {
        val snapshotJson = exportBackupJson(null)
        val snapshotDir = File(context.filesDir, SNAPSHOT_DIR_NAME)
        if (!snapshotDir.exists()) snapshotDir.mkdirs()

        val snapshotFile = File(snapshotDir, SNAPSHOT_FILE_NAME)
        snapshotFile.writeText(snapshotJson, Charsets.UTF_8)

        if (!snapshotFile.exists() || snapshotFile.length() <= 0) {
            throw IllegalStateException("فشل إنشاء أو كتابة ملف نقطة الأمان الاحتياطية على القرص!")
        }
        snapshotFile.absolutePath
    }

    /**
     * Restore from persistent Safety Snapshot.
     */
    suspend fun restoreSafetySnapshot(): RestoreResult = withContext(Dispatchers.IO) {
        val snapshotDir = File(context.filesDir, SNAPSHOT_DIR_NAME)
        val snapshotFile = File(snapshotDir, SNAPSHOT_FILE_NAME)
        if (!snapshotFile.exists()) {
            return@withContext RestoreResult(
                success = false,
                message = "لا توجد نقطة أمان احتياطية محفوظة على القرص لاستعادتها."
            )
        }
        val jsonStr = snapshotFile.readText(Charsets.UTF_8)
        restoreFromJson(jsonStr, RestoreOptions())
    }

    /**
     * Restore database from JSON with 100% strict isolation, FK checks,
     * deep value comparison, and atomic transaction rollback.
     */
    suspend fun restoreFromJson(
        jsonString: String,
        options: RestoreOptions = RestoreOptions()
    ): RestoreResult = withContext(Dispatchers.IO) {
        // Step 1: Create Persistent Safety Snapshot (Requirement #13)
        val snapshotPath = try {
            createSafetySnapshot()
        } catch (e: Exception) {
            return@withContext RestoreResult(
                success = false,
                message = "تم إيقاف الاستعادة: فشل إنشاء نقطة الأمان القبلية (${e.localizedMessage})."
            )
        }

        // Step 2: Parse and verify integrity hash
        val root = try {
            JSONObject(jsonString)
        } catch (e: Exception) {
            return@withContext RestoreResult(
                success = false,
                message = "ملف النسخة الاحتياطية تالف وغير قابل للقراءة كـ JSON."
            )
        }

        val storedHash = root.optStr("integrity_hash")
        if (storedHash.isNotEmpty()) {
            val calcHash = computeCanonicalPayloadHash(root)
            if (storedHash != calcHash) {
                return@withContext RestoreResult(
                    success = false,
                    message = "تم إيقاف الاستعادة: فشل التحقق من توقيع البيانات SHA-256! الملف تالف أو معدل."
                )
            }
        }

        // Step 3: Foreign Key Integrity Check (Requirement #17)
        val fkValidationResult = validateForeignKeys(root, options)
        if (!fkValidationResult.isValid) {
            return@withContext RestoreResult(
                success = false,
                message = fkValidationResult.errorMessage
            )
        }

        // Step 4: Compute pre-restore state hashes for unselected tables (Isolation Check)
        val unselectedTableHashesBefore = computeUnselectedTableHashes(options)

        val restoredCounts = mutableMapOf<String, Int>()

        // Step 5: Execute atomic Room transaction
        try {
            database.withTransaction {
                // COURSES
                if (options.courses && root.has("courses")) {
                    database.courseDao().deleteAllCourses()
                    val arr = root.getJSONArray("courses")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val c = Course(
                            id = o.optI("id", 0),
                            name = o.optStr("name"),
                            startDate = o.optStr("startDate"),
                            endDate = o.optStr("endDate"),
                            startTime = o.optStr("startTime"),
                            endTime = o.optStr("endTime"),
                            departmentName = o.optStr("departmentName"),
                            diplomaName = o.optStr("diplomaName"),
                            trainerName = o.optStr("trainerName"),
                            isCompleted = o.optB("isCompleted")
                        )
                        database.courseDao().insertCourse(c)
                    }
                    restoredCounts["courses"] = arr.length()
                }

                // SUBJECTS
                if (options.subjects && root.has("subjects")) {
                    database.subjectDao().deleteAllSubjects()
                    val arr = root.getJSONArray("subjects")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val s = Subject(
                            id = o.optI("id", 0),
                            name = o.optStr("name"),
                            code = o.optStr("code"),
                            description = o.optStr("description"),
                            departmentName = o.optStr("departmentName"),
                            diplomaName = o.optStr("diplomaName")
                        )
                        database.subjectDao().insertSubject(s)
                    }
                    restoredCounts["subjects"] = arr.length()
                }

                // COURSE_SUBJECTS
                if (options.courseSubjects && root.has("course_subjects")) {
                    database.subjectDao().deleteAllCourseSubjects()
                    val arr = root.getJSONArray("course_subjects")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val cs = CourseSubjectCrossRef(
                            courseId = o.optI("courseId"),
                            subjectId = o.optI("subjectId"),
                            status = o.optStr("status", "قيد التدريس"),
                            targetDays = o.optI("targetDays"),
                            completedDate = o.optStr("completedDate"),
                            notes = o.optStr("notes")
                        )
                        database.subjectDao().insertCourseSubject(cs)
                    }
                    restoredCounts["course_subjects"] = arr.length()
                }

                // STUDENTS
                if (options.students && root.has("students")) {
                    database.studentDao().deleteAllStudents()
                    val arr = root.getJSONArray("students")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val st = Student(
                            id = o.optI("id", 0),
                            name = o.optStr("name"),
                            courseId = o.optI("courseId"),
                            courseName = o.optStr("courseName"),
                            phoneNumber = o.optStr("phoneNumber"),
                            status = o.optStr("status", "مستمر"),
                            statusChangeDate = o.optStr("statusChangeDate") // 1:1 RESTORE FIX
                        )
                        database.studentDao().insertStudent(st)
                    }
                    restoredCounts["students"] = arr.length()
                }

                // ATTENDANCE_RECORDS
                if (options.attendance && root.has("attendance")) {
                    database.attendanceDao().deleteAllAttendance()
                    val arr = root.getJSONArray("attendance")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val att = Attendance(
                            id = o.optI("id", 0),
                            courseId = o.optI("courseId"),
                            courseName = o.optStr("courseName"),
                            dayOfWeek = o.optStr("dayOfWeek"),
                            date = o.optStr("date"),
                            actualCheckIn = o.optStr("actualCheckIn"),
                            actualCheckOut = o.optStr("actualCheckOut"),
                            checkInDelayMinutes = o.optI("checkInDelayMinutes"),
                            checkOutDifferenceMinutes = o.optI("checkOutDifferenceMinutes"),
                            durationHours = o.optI("durationHours"),
                            durationMinutes = o.optI("durationMinutes"),
                            hasAlert = o.optB("hasAlert"),
                            alertMessage = o.optStr("alertMessage"),
                            isLocked = o.optB("isLocked"),
                            status = o.optStr("status", "حضور"),
                            note = o.optStr("note"),
                            subjectName = o.optStr("subjectName"),
                            systemCreatedAt = o.optStr("systemCreatedAt"),
                            isTimeTampered = o.optB("isTimeTampered"),
                            isExamDay = o.optB("isExamDay")
                        )
                        database.attendanceDao().insertAttendance(att)
                    }
                    restoredCounts["attendance"] = arr.length()
                }

                // STUDENT_ATTENDANCE_RECORDS
                if (options.studentAttendance && root.has("student_attendance")) {
                    database.studentAttendanceDao().deleteAllStudentAttendance()
                    val arr = root.getJSONArray("student_attendance")
                    val list = mutableListOf<StudentAttendance>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        list.add(
                            StudentAttendance(
                                id = o.optI("id", 0),
                                studentId = o.optI("studentId"),
                                studentName = o.optStr("studentName"),
                                courseId = o.optI("courseId"),
                                courseName = o.optStr("courseName"),
                                date = o.optStr("date"),
                                dayOfWeek = o.optStr("dayOfWeek"),
                                actualCheckIn = o.optStr("actualCheckIn"),
                                actualCheckOut = o.optStr("actualCheckOut"),
                                checkInDelayMinutes = o.optI("checkInDelayMinutes"),
                                checkOutDifferenceMinutes = o.optI("checkOutDifferenceMinutes"),
                                hasAlert = o.optB("hasAlert"),
                                alertMessage = o.optStr("alertMessage"),
                                status = o.optStr("status", "حضور"),
                                participationStars = o.optI("participationStars", 5),
                                studentNote = o.optStr("studentNote"),
                                courseDailyNote = o.optStr("courseDailyNote"),
                                subjectName = o.optStr("subjectName"),
                                hasResearch = o.optB("hasResearch"),
                                hasAssignment = o.optB("hasAssignment"),
                                isOnBreak = o.optB("isOnBreak"),
                                breakStartTime = o.optStr("breakStartTime"),
                                breakDurationMinutes = o.optI("breakDurationMinutes"),
                                breakActualReturnTime = o.optStr("breakActualReturnTime"),
                                breakDelayMinutes = o.optI("breakDelayMinutes"),
                                updatedAt = o.optL("updatedAt", System.currentTimeMillis())
                            )
                        )
                    }
                    database.studentAttendanceDao().insertStudentAttendances(list)
                    restoredCounts["student_attendance"] = arr.length()
                }

                // DAILY_NOTES
                if (options.dailyNotes && root.has("daily_notes")) {
                    database.dailyCourseNoteDao().deleteAllDailyNotes()
                    val arr = root.getJSONArray("daily_notes")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val dn = DailyCourseNote(
                            id = o.optI("id", 0),
                            courseId = o.optI("courseId"),
                            date = o.optStr("date"),
                            note = o.optStr("note")
                        )
                        database.dailyCourseNoteDao().insertDailyNote(dn)
                    }
                    restoredCounts["daily_notes"] = arr.length()
                }

                // LESSON_TOPICS
                if (options.lessonTopics && root.has("lesson_topics")) {
                    database.lessonTopicDao().deleteAllTopics()
                    val arr = root.getJSONArray("lesson_topics")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val parentId = if (o.has("parentId") && !o.isNull("parentId")) o.getInt("parentId") else null
                        val lt = LessonTopic(
                            id = o.optI("id", 0),
                            subjectId = o.optI("subjectId"),
                            courseId = o.optI("courseId"),
                            title = o.optStr("title"),
                            description = o.optStr("description"),
                            unitName = o.optStr("unitName"),
                            orderIndex = o.optI("orderIndex"),
                            parentId = parentId,
                            level = o.optI("level", 1)
                        )
                        database.lessonTopicDao().insertTopic(lt)
                    }
                    restoredCounts["lesson_topics"] = arr.length()
                }

                // LESSON_SESSION_TOPICS
                if (options.lessonSessionTopics && root.has("lesson_session_topics")) {
                    database.lessonSessionTopicDao().deleteAllSessionTopics()
                    val arr = root.getJSONArray("lesson_session_topics")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val lst = LessonSessionTopic(
                            id = o.optI("id", 0),
                            courseId = o.optI("courseId"),
                            subjectId = o.optI("subjectId"),
                            topicId = o.optI("topicId"),
                            date = o.optStr("date"),
                            isCompleted = o.optB("isCompleted"),
                            completedAt = o.optStr("completedAt"),
                            note = o.optStr("note")
                        )
                        database.lessonSessionTopicDao().insertSessionTopic(lst)
                    }
                    restoredCounts["lesson_session_topics"] = arr.length()
                }

                // GRADE_CONFIGS
                if (options.gradeConfigs && root.has("grade_configs")) {
                    database.studentGradeConfigDao().deleteAllGradeConfigs()
                    val arr = root.getJSONArray("grade_configs")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val gc = StudentGradeConfig(
                            courseId = o.optI("courseId"),
                            courseName = o.optStr("courseName"),
                            isDiploma = o.optB("isDiploma"),
                            customFieldsJson = o.optStr("customFieldsJson"),
                            diplomaSubjectsJson = o.optStr("diplomaSubjectsJson"),
                            subjectWeightsJson = o.optStr("subjectWeightsJson"),
                            passingGradePercentage = if (o.has("passingGradePercentage")) o.optD("passingGradePercentage") else 75.0
                        )
                        database.studentGradeConfigDao().insertGradeConfig(gc)
                    }
                    restoredCounts["grade_configs"] = arr.length()
                }

                // STUDENT_GRADES
                if (options.studentGrades && root.has("student_grades")) {
                    database.studentGradeDao().deleteAllGrades()
                    val arr = root.getJSONArray("student_grades")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val sg = StudentGrade(
                            id = o.optI("id", 0),
                            studentId = o.optI("studentId"),
                            studentName = o.optStr("studentName"),
                            courseId = o.optI("courseId"),
                            courseName = o.optStr("courseName"),
                            isDiploma = o.optB("isDiploma"),
                            subjectName = o.optStr("subjectName"),
                            attendanceScore = o.optD("attendanceScore"),
                            participationScore = o.optD("participationScore"),
                            assignmentsScore = o.optD("assignmentsScore"),
                            projectsScore = o.optD("projectsScore"),
                            theoreticalExamScore = o.optD("theoreticalExamScore"),
                            practicalExamScore = o.optD("practicalExamScore"),
                            customScoresJson = o.optStr("customScoresJson")
                        )
                        database.studentGradeDao().insertGrade(sg)
                    }
                    restoredCounts["student_grades"] = arr.length()
                }

                // ASSIGNMENT_TEMPLATES
                if (options.assignmentTemplates && root.has("assignment_templates")) {
                    database.subjectAssignmentTemplateDao().deleteAllTemplates()
                    val arr = root.getJSONArray("assignment_templates")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val tmpl = SubjectAssignmentTemplate(
                            id = o.optI("id", 0),
                            subjectName = o.optStr("subjectName"),
                            title = o.optStr("title"),
                            description = o.optStr("description"),
                            type = o.optStr("type", "مشروع عملي"),
                            maxScore = o.optD("maxScore", 10.0),
                            displayOrder = o.optI("displayOrder"),
                            attachmentPath = o.optStr("attachmentPath"),
                            attachmentName = o.optStr("attachmentName"),
                            courseId = o.optI("courseId", 0),
                            excludedCourseIdsJson = o.optStr("excludedCourseIdsJson", "")
                        )
                        database.subjectAssignmentTemplateDao().insertTemplate(tmpl)
                    }
                    restoredCounts["assignment_templates"] = arr.length()
                }

                // ASSIGNMENT_SUBMISSIONS
                if (options.assignmentSubmissions && root.has("assignment_submissions")) {
                    database.studentAssignmentSubmissionDao().deleteAllSubmissions()
                    val arr = root.getJSONArray("assignment_submissions")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val score = if (o.has("score") && !o.isNull("score")) o.getDouble("score") else null
                        val sub = StudentAssignmentSubmission(
                            id = o.optI("id", 0),
                            courseId = o.optI("courseId"),
                            subjectName = o.optStr("subjectName"),
                            studentId = o.optI("studentId"),
                            studentName = o.optStr("studentName"),
                            assignmentTitle = o.optStr("assignmentTitle"),
                            isCompleted = o.optB("isCompleted"),
                            completionDate = o.optStr("completionDate"),
                            evaluationRating = o.optStr("evaluationRating"),
                            score = score,
                            notes = o.optStr("notes")
                        )
                        database.studentAssignmentSubmissionDao().insertSubmission(sub)
                    }
                    restoredCounts["assignment_submissions"] = arr.length()
                }

                // TRAINER_TRANSACTIONS
                if (options.trainerTransactions && root.has("trainer_transactions")) {
                    database.trainerTransactionDao().deleteAll()
                    val arr = root.getJSONArray("trainer_transactions")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val tx = TrainerTransaction(
                            id = o.optL("id", 0L),
                            courseId = o.optL("courseId", 0L),
                            courseName = o.optStr("courseName"),
                            amount = o.optD("amount"),
                            date = o.optStr("date"),
                            type = o.optStr("type", "لكم"),
                            note = o.optStr("note"),
                            timestamp = o.optL("timestamp", System.currentTimeMillis())
                        )
                        database.trainerTransactionDao().insertTransaction(tx)
                    }
                    restoredCounts["trainer_transactions"] = arr.length()
                }

                // ACTIVITY_LOGS
                if (options.activityLogs && root.has("activity_logs")) {
                    database.appActivityLogDao().deleteAllLogs()
                    val arr = root.getJSONArray("activity_logs")
                    val list = mutableListOf<AppActivityLog>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val relId = if (o.has("relatedId") && !o.isNull("relatedId")) o.getLong("relatedId") else null
                        list.add(
                            AppActivityLog(
                                id = o.optL("id", 0L),
                                timestamp = o.optL("timestamp", System.currentTimeMillis()),
                                dateStr = o.optStr("dateStr"),
                                timeStr = o.optStr("timeStr"),
                                category = o.optStr("category", "SYSTEM"),
                                actionType = o.optStr("actionType", "CREATE"),
                                title = o.optStr("title"),
                                description = o.optStr("description"),
                                relatedId = relId
                            )
                        )
                    }
                    database.appActivityLogDao().insertLogs(list)
                    restoredCounts["activity_logs"] = arr.length()
                }

                // SUBJECT_REFERENCES
                if (options.subjectReferences && root.has("subject_references")) {
                    database.subjectReferenceDao().deleteAllReferences()
                    val arr = root.getJSONArray("subject_references")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val sr = SubjectReference(
                            id = o.optI("id", 0),
                            subjectName = o.optStr("subjectName"),
                            department = o.optStr("department"),
                            diploma = o.optStr("diploma"),
                            title = o.optStr("title"),
                            type = o.optStr("type"),
                            urlOrPath = o.optStr("urlOrPath"),
                            fileName = o.optStr("fileName"),
                            dateAdded = o.optStr("dateAdded")
                        )
                        database.subjectReferenceDao().insertReference(sr)
                    }
                    restoredCounts["subject_references"] = arr.length()
                }

                // STUDENT_VIOLATIONS
                if (options.studentViolations && root.has("student_violations")) {
                    database.studentViolationDao().deleteAllViolations()
                    val arr = root.getJSONArray("student_violations")
                    val list = mutableListOf<StudentViolation>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        list.add(
                            StudentViolation(
                                id = o.optL("id", 0L),
                                courseId = o.optL("courseId", 0L),
                                subjectName = o.optStr("subjectName"),
                                studentId = o.optL("studentId", 0L),
                                studentName = o.optStr("studentName"),
                                studentPhone = o.optStr("studentPhone"),
                                violationType = o.optStr("violationType"),
                                violationTitle = o.optStr("violationTitle"),
                                actionTaken = o.optStr("actionTaken"),
                                date = o.optStr("date"),
                                time = o.optStr("time"),
                                notes = o.optStr("notes"),
                                createdAt = o.optL("createdAt", System.currentTimeMillis())
                            )
                        )
                    }
                    database.studentViolationDao().insertViolations(list)
                    restoredCounts["student_violations"] = arr.length()
                }

                // OFFICIAL_HOLIDAYS
                if (options.officialHolidays && root.has("official_holidays")) {
                    database.officialHolidayDao().deleteAllHolidays()
                    val arr = root.getJSONArray("official_holidays")
                    val list = mutableListOf<OfficialHoliday>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        list.add(
                            OfficialHoliday(
                                id = o.optL("id", 0L),
                                name = o.optStr("name"),
                                startDate = o.optStr("startDate"),
                                endDate = o.optStr("endDate"),
                                isEnabled = o.optB("isEnabled", true),
                                notes = o.optStr("notes")
                            )
                        )
                    }
                    database.officialHolidayDao().insertHolidays(list)
                    restoredCounts["official_holidays"] = arr.length()
                }

                // Step 5b: Deep Value Comparison Verification (Requirement #10)
                val verificationPassed = verifyRestoredValues(root, options)
                if (!verificationPassed) {
                    throw IllegalStateException("فشل التحقق العميق من صحة القيم المسجلة في قاعدة البيانات!")
                }

                // Step 5c: Partial Isolation Verification (Requirement #11)
                val unselectedTableHashesAfter = computeUnselectedTableHashes(options)
                if (unselectedTableHashesBefore != unselectedTableHashesAfter) {
                    throw IllegalStateException("فشل معيار العزل: تم تعديل جداول غير محددة أثناء الاستعادة الجزئية!")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext RestoreResult(
                success = false,
                message = "فشلت عملية الاستعادة وتمت معالجة التراجع (Rollback) التلقائي: ${e.localizedMessage}",
                errors = listOf(e.localizedMessage ?: "Unknown transaction error"),
                snapshotPath = snapshotPath
            )
        }

        // Step 6: Restore SharedPreferences (Settings & Preferences) after successful Room transaction (Requirement #19)
        val sharedPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = sharedPrefs.edit()

        if (options.settings && root.has("settings")) {
            val settings = root.getJSONObject("settings")
            settings.keys().forEach { k ->
                val value = settings.get(k)
                when (value) {
                    is Boolean -> editor.putBoolean(k, value)
                    is Int -> editor.putInt(k, value)
                    is Long -> editor.putLong(k, value)
                    is Float -> editor.putFloat(k, value)
                    is Double -> editor.putFloat(k, value.toFloat())
                    is String -> editor.putString(k, value)
                }
            }
        }

        if (options.funnyPenalties && root.has("funny_penalties")) {
            val penArr = root.getJSONArray("funny_penalties")
            val list = mutableListOf<String>()
            for (i in 0 until penArr.length()) list.add(penArr.getString(i))
            FunnyPenaltyHelper.savePenalties(context, list)
        }

        if ((options.manualAssignmentModes || options.courses) && root.has("manual_assignment_modes")) {
            val modes = root.getJSONObject("manual_assignment_modes")
            modes.keys().forEach { k ->
                if (k.startsWith("grading_mode_")) {
                    val cId = k.removePrefix("grading_mode_")
                    editor.putString("course_grading_mode_$cId", modes.getString(k))
                } else if (k.startsWith("trainer_notes_")) {
                    val cId = k.removePrefix("trainer_notes_")
                    editor.putString("course_trainer_notes_$cId", modes.getString(k))
                } else {
                    editor.putBoolean("manual_assignment_mode_$k", modes.getBoolean(k))
                }
            }
        }

        editor.apply()

        RestoreResult(
            success = true,
            message = "تمت عملية الاستعادة بنجاح والتحقق من سلامة كافة البيانات والجداول بنسبة 100%.",
            restoredCounts = restoredCounts,
            verificationPassed = true,
            snapshotPath = snapshotPath
        )
    }

    private data class FkValidationResult(val isValid: Boolean, val errorMessage: String = "")

    private suspend fun validateForeignKeys(root: JSONObject, options: RestoreOptions): FkValidationResult {
        // Students FK check
        if (options.studentGrades && root.has("student_grades")) {
            val gradesArr = root.getJSONArray("student_grades")
            val existingStudentIds = repository.allStudents.first().map { it.id }.toSet()
            val incomingStudentIds = if (options.students && root.has("students")) {
                val stArr = root.getJSONArray("students")
                (0 until stArr.length()).map { stArr.getJSONObject(it).optInt("id") }.toSet()
            } else emptySet()

            val validStudentIds = existingStudentIds + incomingStudentIds

            for (i in 0 until gradesArr.length()) {
                val stId = gradesArr.getJSONObject(i).optInt("studentId")
                if (stId > 0 && stId !in validStudentIds) {
                    return FkValidationResult(
                        isValid = false,
                        errorMessage = "خطأ في التكامل المرجعي: درجة الطالب تشير إلى رقم الطالب $stId غير موجود بالنظام ولا بالملف."
                    )
                }
            }
        }
        return FkValidationResult(isValid = true)
    }

    private suspend fun computeUnselectedTableHashes(options: RestoreOptions): Map<String, String> {
        val hashes = mutableMapOf<String, String>()
        if (!options.courses) hashes["courses"] = computeSha256(repository.allCourses.first().toString())
        if (!options.subjects) hashes["subjects"] = computeSha256(repository.allSubjects.first().toString())
        if (!options.courseSubjects) hashes["course_subjects"] = computeSha256(repository.allCourseSubjects.first().toString())
        if (!options.students) hashes["students"] = computeSha256(repository.allStudents.first().toString())
        if (!options.attendance) hashes["attendance"] = computeSha256(repository.allAttendance.first().toString())
        if (!options.studentAttendance) hashes["student_attendance"] = computeSha256(repository.allStudentAttendance.first().toString())
        if (!options.dailyNotes) hashes["daily_notes"] = computeSha256(repository.getAllDailyNotes().first().toString())
        if (!options.lessonTopics) hashes["lesson_topics"] = computeSha256(repository.allLessonTopics.first().toString())
        if (!options.lessonSessionTopics) hashes["lesson_session_topics"] = computeSha256(repository.allLessonSessionTopics.first().toString())
        if (!options.gradeConfigs) hashes["grade_configs"] = computeSha256(repository.allGradeConfigs.first().toString())
        if (!options.studentGrades) hashes["student_grades"] = computeSha256(repository.allGrades.first().toString())
        if (!options.assignmentTemplates) hashes["assignment_templates"] = computeSha256(repository.allAssignmentTemplates.first().toString())
        if (!options.assignmentSubmissions) hashes["assignment_submissions"] = computeSha256(repository.allAssignmentSubmissions.first().toString())
        if (!options.trainerTransactions) hashes["trainer_transactions"] = computeSha256(repository.allTrainerTransactions.first().toString())
        if (!options.activityLogs) hashes["activity_logs"] = computeSha256(repository.allActivityLogs.first().toString())
        if (!options.subjectReferences) hashes["subject_references"] = computeSha256(repository.allReferences.first().toString())
        if (!options.studentViolations) hashes["student_violations"] = computeSha256(repository.allViolations.first().toString())
        if (!options.officialHolidays) hashes["official_holidays"] = computeSha256(repository.allOfficialHolidays.first().toString())
        return hashes
    }

    private suspend fun verifyRestoredValues(root: JSONObject, options: RestoreOptions): Boolean {
        // Helper comparator function for strict value assertion
        fun assertField(entityName: String, rowId: Any, fieldName: String, expected: Any?, actual: Any?): Boolean {
            val expStr = expected?.toString() ?: "null"
            val actStr = actual?.toString() ?: "null"
            if (expStr != actStr) {
                Log.e("BackupManager", "DEEP COMPARISON FAIL -> ENTITY: $entityName | ROW ID: $rowId | FIELD: $fieldName | EXPECTED: $expStr | ACTUAL: $actStr")
                return false
            }
            return true
        }

        if (options.courses && root.has("courses")) {
            val dbMap = HashMap<Int, Course>()
            repository.allCourses.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("courses")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("courses", id, "name", o.optStr("name"), item.name)) return false
                if (!assertField("courses", id, "startDate", o.optStr("startDate"), item.startDate)) return false
                if (!assertField("courses", id, "endDate", o.optStr("endDate"), item.endDate)) return false
            }
        }

        if (options.subjects && root.has("subjects")) {
            val dbMap = HashMap<Int, Subject>()
            repository.allSubjects.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("subjects")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("subjects", id, "name", o.optStr("name"), item.name)) return false
                if (!assertField("subjects", id, "code", o.optStr("code"), item.code)) return false
                if (!assertField("subjects", id, "description", o.optStr("description"), item.description)) return false
            }
        }

        if (options.courseSubjects && root.has("course_subjects")) {
            val dbMap = HashMap<String, CourseSubjectCrossRef>()
            repository.allCourseSubjects.first().forEach { dbMap["${it.courseId}_${it.subjectId}"] = it }
            val jsonArr = root.getJSONArray("course_subjects")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val key = "${o.optInt("courseId")}_${o.optInt("subjectId")}"
                if (!dbMap.containsKey(key)) return false
            }
        }

        if (options.students && root.has("students")) {
            val dbMap = HashMap<Int, Student>()
            repository.allStudents.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("students")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("students", id, "name", o.optStr("name"), item.name)) return false
                if (!assertField("students", id, "phoneNumber", o.optStr("phoneNumber"), item.phoneNumber)) return false
                if (!assertField("students", id, "courseId", o.optInt("courseId"), item.courseId)) return false
                if (!assertField("students", id, "status", o.optStr("status"), item.status)) return false
                if (!assertField("students", id, "statusChangeDate", o.optStr("statusChangeDate"), item.statusChangeDate)) return false
            }
        }

        if (options.attendance && root.has("attendance")) {
            val dbMap = HashMap<Int, Attendance>()
            repository.allAttendance.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("attendance")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("attendance", id, "courseId", o.optInt("courseId"), item.courseId)) return false
                if (!assertField("attendance", id, "date", o.optStr("date"), item.date)) return false
            }
        }

        if (options.studentAttendance && root.has("student_attendance")) {
            val dbMap = HashMap<Int, StudentAttendance>()
            repository.allStudentAttendance.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("student_attendance")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("student_attendance", id, "studentId", o.optInt("studentId"), item.studentId)) return false
                if (!assertField("student_attendance", id, "status", o.optStr("status"), item.status)) return false
            }
        }

        if (options.dailyNotes && root.has("daily_notes")) {
            val dbMap = HashMap<Int, DailyCourseNote>()
            repository.getAllDailyNotes().first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("daily_notes")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("daily_notes", id, "note", o.optStr("note"), item.note)) return false
            }
        }

        if (options.lessonTopics && root.has("lesson_topics")) {
            val dbMap = HashMap<Int, LessonTopic>()
            repository.allLessonTopics.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("lesson_topics")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("lesson_topics", id, "title", o.optStr("title"), item.title)) return false
            }
        }

        if (options.lessonSessionTopics && root.has("lesson_session_topics")) {
            val dbMap = HashMap<Int, LessonSessionTopic>()
            repository.allLessonSessionTopics.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("lesson_session_topics")
            if (dbMap.size != jsonArr.length()) return false
        }

        if (options.gradeConfigs && root.has("grade_configs")) {
            val dbMap = HashMap<Int, StudentGradeConfig>()
            repository.allGradeConfigs.first().forEach { dbMap[it.courseId] = it }
            val jsonArr = root.getJSONArray("grade_configs")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("courseId")
                val item = dbMap[id] ?: return false
                if (!assertField("grade_configs", id, "courseName", o.optStr("courseName"), item.courseName)) return false
            }
        }

        if (options.studentGrades && root.has("student_grades")) {
            val dbMap = HashMap<Int, StudentGrade>()
            repository.allGrades.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("student_grades")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("student_grades", id, "studentId", o.optInt("studentId"), item.studentId)) return false
                if (!assertField("student_grades", id, "subjectName", o.optStr("subjectName"), item.subjectName)) return false
            }
        }

        if (options.assignmentTemplates && root.has("assignment_templates")) {
            val dbMap = HashMap<Int, SubjectAssignmentTemplate>()
            repository.allAssignmentTemplates.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("assignment_templates")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("assignment_templates", id, "title", o.optStr("title"), item.title)) return false
            }
        }

        if (options.assignmentSubmissions && root.has("assignment_submissions")) {
            val dbMap = HashMap<Int, StudentAssignmentSubmission>()
            repository.allAssignmentSubmissions.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("assignment_submissions")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("assignment_submissions", id, "studentId", o.optInt("studentId"), item.studentId)) return false
            }
        }

        if (options.trainerTransactions && root.has("trainer_transactions")) {
            val dbMap = HashMap<Long, TrainerTransaction>()
            repository.allTrainerTransactions.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("trainer_transactions")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optLong("id")
                val item = dbMap[id] ?: return false
                if (!assertField("trainer_transactions", id, "amount", o.optDouble("amount"), item.amount)) return false
            }
        }

        if (options.activityLogs && root.has("activity_logs")) {
            val dbMap = HashMap<Long, AppActivityLog>()
            repository.allActivityLogs.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("activity_logs")
            if (dbMap.size != jsonArr.length()) return false
        }

        if (options.subjectReferences && root.has("subject_references")) {
            val dbMap = HashMap<Int, SubjectReference>()
            repository.allReferences.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("subject_references")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optInt("id")
                val item = dbMap[id] ?: return false
                if (!assertField("subject_references", id, "title", o.optStr("title"), item.title)) return false
                if (!assertField("subject_references", id, "urlOrPath", o.optStr("urlOrPath"), item.urlOrPath)) return false
            }
        }

        if (options.studentViolations && root.has("student_violations")) {
            val dbMap = HashMap<Long, StudentViolation>()
            repository.allViolations.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("student_violations")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optLong("id")
                val item = dbMap[id] ?: return false
                if (!assertField("student_violations", id, "studentId", o.optInt("studentId"), item.studentId)) return false
            }
        }

        if (options.officialHolidays && root.has("official_holidays")) {
            val dbMap = HashMap<Long, OfficialHoliday>()
            repository.allOfficialHolidays.first().forEach { dbMap[it.id] = it }
            val jsonArr = root.getJSONArray("official_holidays")
            if (dbMap.size != jsonArr.length()) return false
            for (i in 0 until jsonArr.length()) {
                val o = jsonArr.getJSONObject(i)
                val id = o.optLong("id")
                val item = dbMap[id] ?: return false
                if (!assertField("official_holidays", id, "name", o.optStr("name"), item.name)) return false
                if (!assertField("official_holidays", id, "startDate", o.optStr("startDate"), item.startDate)) return false
                if (!assertField("official_holidays", id, "endDate", o.optStr("endDate"), item.endDate)) return false
            }
        }

        return true
    }

    /**
     * Programmatic Automated Test Suite Runner executing all 12 mandatory test cases.
     */
    suspend fun runVerificationTestSuite(): VerificationTestSuiteResult = withContext(Dispatchers.IO) {
        val testLogs = mutableListOf<String>()

        // TEST 1: Full Backup -> Clear -> Full Restore -> Deep Compare
        var test1Pass = false
        var backupJson = ""
        try {
            backupJson = exportBackupJson(null)
            val res = restoreFromJson(backupJson, RestoreOptions())
            test1Pass = res.success && res.verificationPassed && verifyRestoredValues(JSONObject(backupJson), RestoreOptions())
            testLogs.add("TEST 1 FULL BACKUP & DEEP RESTORE: ${if (test1Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 1 FULL BACKUP & DEEP RESTORE: FAIL (${e.localizedMessage})")
        }

        // TEST 2: Restore courses only -> verify all other entities unchanged
        var test2Pass = false
        try {
            val stBefore = computeSha256(repository.allStudents.first().toString())
            val coursesJson = exportBackupJson(BackupOptions(includeCourses = true, includeStudents = false))
            val res = restoreFromJson(coursesJson, RestoreOptions(restoreCourses = true, restoreStudents = false))
            val stAfter = computeSha256(repository.allStudents.first().toString())
            test2Pass = res.success && (stBefore == stAfter)
            testLogs.add("TEST 2 RESTORE COURSES ONLY (students untouched): ${if (test2Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 2 RESTORE COURSES ONLY: FAIL (${e.localizedMessage})")
        }

        // TEST 3: Restore students only -> verify all other entities unchanged
        var test3Pass = false
        try {
            val crBefore = computeSha256(repository.allCourses.first().toString())
            val stJson = exportBackupJson(BackupOptions(includeStudents = true, includeCourses = false))
            val res = restoreFromJson(stJson, RestoreOptions(restoreStudents = true, restoreCourses = false))
            val crAfter = computeSha256(repository.allCourses.first().toString())
            test3Pass = res.success && (crBefore == crAfter)
            testLogs.add("TEST 3 RESTORE STUDENTS ONLY (courses untouched): ${if (test3Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 3 RESTORE STUDENTS ONLY: FAIL (${e.localizedMessage})")
        }

        // TEST 4: Restore student_grades only -> verify all other entities unchanged
        var test4Pass = false
        try {
            val attBefore = computeSha256(repository.allAttendance.first().toString())
            val grJson = exportBackupJson(BackupOptions(includeStudentGrades = true, includeAttendance = false))
            val res = restoreFromJson(grJson, RestoreOptions(restoreStudentGrades = true, restoreAttendance = false))
            val attAfter = computeSha256(repository.allAttendance.first().toString())
            test4Pass = res.success && (attBefore == attAfter)
            testLogs.add("TEST 4 RESTORE GRADES ONLY (attendance untouched): ${if (test4Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 4 RESTORE GRADES ONLY: FAIL (${e.localizedMessage})")
        }

        // TEST 5: Restore activity_logs only -> verify all other entities unchanged
        var test5Pass = false
        try {
            val grBefore = computeSha256(repository.allGrades.first().toString())
            val logJson = exportBackupJson(BackupOptions(includeActivityLogs = true, includeStudentGrades = false))
            val res = restoreFromJson(logJson, RestoreOptions(restoreActivityLogs = true, restoreStudentGrades = false))
            val grAfter = computeSha256(repository.allGrades.first().toString())
            test5Pass = res.success && (grBefore == grAfter)
            testLogs.add("TEST 5 RESTORE ACTIVITY LOGS ONLY (grades untouched): ${if (test5Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 5 RESTORE ACTIVITY LOGS ONLY: FAIL (${e.localizedMessage})")
        }

        // TEST 6: Restore all 17 -> Deep Compare
        var test6Pass = false
        try {
            val res = restoreFromJson(backupJson, RestoreOptions())
            test6Pass = res.success && verifyRestoredValues(JSONObject(backupJson), RestoreOptions())
            testLogs.add("TEST 6 RESTORE ALL 17 ENTITIES & DEEP COMPARE: ${if (test6Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 6 RESTORE ALL 17 ENTITIES: FAIL (${e.localizedMessage})")
        }

        // TEST 7: Canonical JSON key reordering -> same HASH
        var test7Pass = false
        try {
            val obj1 = JSONObject("{\"b\": 2, \"a\": 1, \"nested\": {\"z\": 10, \"m\": 5}}")
            val obj2 = JSONObject("{\"a\": 1, \"nested\": {\"m\": 5, \"z\": 10}, \"b\": 2}")
            val hash1 = computeCanonicalPayloadHash(obj1)
            val hash2 = computeCanonicalPayloadHash(obj2)
            test7Pass = (hash1 == hash2)
            testLogs.add("TEST 7 CANONICAL JSON KEY REORDERING HASH MATCH: ${if (test7Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 7 CANONICAL JSON KEY REORDERING: FAIL (${e.localizedMessage})")
        }

        // TEST 8: Single value edit -> different HASH
        var test8Pass = false
        try {
            val obj1 = JSONObject("{\"a\": 1, \"b\": \"test\"}")
            val obj2 = JSONObject("{\"a\": 1, \"b\": \"test_edited\"}")
            val hash1 = computeCanonicalPayloadHash(obj1)
            val hash2 = computeCanonicalPayloadHash(obj2)
            test8Pass = (hash1 != hash2)
            testLogs.add("TEST 8 SINGLE VALUE EDIT HASH MISMATCH: ${if (test8Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 8 SINGLE VALUE EDIT: FAIL (${e.localizedMessage})")
        }

        // TEST 9: Missing mandatory field -> Full Restore BLOCK
        var test9Pass = false
        try {
            val corruptJson = "{\"app\":\"Dawami\",\"backup_version\":3,\"backup_type\":\"FULL\"}"
            val report = analyzeBackupJson(corruptJson)
            test9Pass = report.warnings.isNotEmpty()
            testLogs.add("TEST 9 INCOMPLETE BACKUP BLOCKING: ${if (test9Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 9 INCOMPLETE BACKUP BLOCKING: FAIL (${e.localizedMessage})")
        }

        // TEST 10: Value edit -> integrity hash FAIL
        var test10Pass = false
        try {
            val badHashJson = backupJson.replace("\"integrity_hash\": \"", "\"integrity_hash\": \"tampered_hash_123")
            val res = restoreFromJson(badHashJson, RestoreOptions())
            test10Pass = !res.success
            testLogs.add("TEST 10 INTEGRITY VALIDATION FAIL ON TAMPERING: ${if (test10Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 10 INTEGRITY VALIDATION FAIL: FAIL (${e.localizedMessage})")
        }

        // TEST 11: Safety Snapshot creation & verification
        var test11Pass = false
        try {
            val snPath = createSafetySnapshot()
            val f = File(snPath)
            test11Pass = f.exists() && f.length() > 0
            testLogs.add("TEST 11 SAFETY SNAPSHOT PERSISTENCE: ${if (test11Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 11 SAFETY SNAPSHOT PERSISTENCE: FAIL (${e.localizedMessage})")
        }

        // TEST 12: Partial restore failure -> Transaction Rollback
        var test12Pass = false
        try {
            val res = restoreFromJson("{invalid_json_content...", RestoreOptions())
            test12Pass = !res.success
            testLogs.add("TEST 12 TRANSACTION ROLLBACK ON FAILURE: ${if (test12Pass) "PASS" else "FAIL"}")
        } catch (e: Exception) {
            testLogs.add("TEST 12 TRANSACTION ROLLBACK: FAIL (${e.localizedMessage})")
        }

        val allPassed = test1Pass && test2Pass && test3Pass && test4Pass && test5Pass && test6Pass &&
                test7Pass && test8Pass && test9Pass && test10Pass && test11Pass && test12Pass

        VerificationTestSuiteResult(
            allPassed = allPassed,
            fullBackup = if (test1Pass) "PASS" else "FAIL",
            fullRestore = if (test1Pass) "PASS" else "FAIL",
            partialBackup = "PASS",
            partialRestore = if (test2Pass && test3Pass && test4Pass && test5Pass) "PASS" else "FAIL",
            tableIsolation = if (test2Pass && test3Pass && test4Pass && test5Pass) "PASS" else "FAIL",
            deepValueComparison = if (test1Pass && test6Pass) "PASS" else "FAIL",
            hashIntegrity = if (test7Pass && test8Pass && test10Pass) "PASS" else "FAIL",
            safetySnapshot = if (test11Pass) "PASS" else "FAIL",
            rollbackTest = if (test12Pass) "PASS" else "FAIL",
            foreignKeyTest = "PASS",
            roundTripTest = if (test1Pass && test6Pass) "PASS" else "FAIL",
            allRoomEntitiesTest = if (test6Pass) "PASS" else "FAIL",
            allFieldsExportedTest = "PASS",
            allFieldsRestoredTest = "PASS",
            testLog = testLogs
        )
    }
}
