package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.Course
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen

// ---------------- COURSE HUB CARD (مركز إدارة الدورة التدريبية الشامل) ----------------
@Composable
fun CourseHubCard(
    course: Course,
    subjectName: String = "",
    studentCount: Int = 0,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier,
    isInitiallyExpanded: Boolean = true
) {
    var isExpanded by remember { mutableStateOf(isInitiallyExpanded) }
    val dbAttendance by viewModel.dbAttendance.collectAsState()
    val todayDate = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()) }
    val todayAttendance = remember(dbAttendance, course.id, todayDate) {
        dbAttendance.find { it.courseId == course.id && it.date == todayDate }
    }
    val isExamDay = todayAttendance?.isExamDay == true

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("course_hub_card_${course.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.5.dp, DawamiNavy.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Header Section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                DawamiNavy.copy(alpha = 0.08f),
                                DawamiTeal.copy(alpha = 0.04f)
                            )
                        )
                    )
                    .clickable { isExpanded = !isExpanded }
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = DawamiNavy,
                            shape = CircleShape,
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = null,
                                    tint = DawamiGold,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = course.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiNavy,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )

                                Surface(
                                    color = if (course.isCompleted) Color(0xFFF1F5F9) else Color(0xFFECFDF5),
                                    shape = RoundedCornerShape(6.dp),
                                    border = BorderStroke(0.6.dp, if (course.isCompleted) Color(0xFF94A3B8) else Color(0xFF10B981))
                                ) {
                                    Text(
                                        text = if (course.isCompleted) "مكتملة 🏁" else "نشطة ⚡",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (course.isCompleted) Color(0xFF64748B) else Color(0xFF047857),
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (subjectName.isNotBlank()) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            text = "المادة: $subjectName",
                                            fontSize = 10.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                        if (isExamDay) {
                                            Surface(
                                                color = DawamiGold.copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(4.dp),
                                                border = BorderStroke(0.6.dp, DawamiGold)
                                            ) {
                                                Text(
                                                    text = "🛡️ امتحان",
                                                    fontSize = 8.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF92400E),
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                if (course.diplomaName.isNotBlank()) {
                                    Text(
                                        text = "• ${course.diplomaName}",
                                        fontSize = 10.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1
                                    )
                                }
                                if (studentCount > 0) {
                                    Text(
                                        text = "• 👥 $studentCount طالب",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = DawamiNavy
                                    )
                                }
                            }
                        }
                    }

                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = if (isExpanded) "طي مركز الدورة" else "توسيع مركز الدورة",
                            tint = DawamiNavy
                        )
                    }
                }
            }

            // Expanded Hub Actions
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Time and Department Banner
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = null,
                                    tint = DawamiTeal,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = if (course.startTime.isNotBlank() && course.endTime.isNotBlank())
                                        "${course.startTime} - ${course.endTime}"
                                    else "توقيت مرن",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            if (course.departmentName.isNotBlank()) {
                                Text(
                                    text = "القسم: ${course.departmentName}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Text(
                        text = "مركز خدمات ومتابعة الدورة 🎯",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = DawamiNavy
                    )

                    // Quick Action Grid (2 columns or responsive flow)
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            HubActionButton(
                                label = "⚡ رصد الحضور",
                                subLabel = "تحضير سريع لطلاب الدورة",
                                icon = Icons.Default.FactCheck,
                                color = Color(0xFF10B981),
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    viewModel.selectCourseForAttendance(course)
                                    viewModel.navigateTo(Screen.StudentAttendance)
                                }
                            )

                            HubActionButton(
                                label = "👥 الطلاب",
                                subLabel = "سجل وبيانات الطلاب",
                                icon = Icons.Default.Group,
                                color = DawamiNavy,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    viewModel.selectCourseForAttendance(course)
                                    viewModel.navigateTo(Screen.Students)
                                }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            HubActionButton(
                                label = "📚 المنهج والتحضير",
                                subLabel = "خطة الدروس اليومية",
                                icon = Icons.Default.MenuBook,
                                color = Color(0xFF6366F1),
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    viewModel.selectCourseForAttendance(course)
                                    viewModel.navigateTo(Screen.LessonPreparation)
                                }
                            )

                            HubActionButton(
                                label = "📝 الدرجات والتقييم",
                                subLabel = "رصد وتحديث درجات الطلاب",
                                icon = Icons.Default.Grade,
                                color = Color(0xFF0284C7),
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    viewModel.selectCourseForAttendance(course)
                                    viewModel.selectCourseForGrades(course)
                                    viewModel.setSelectedGradesTabIndex(0)
                                    viewModel.navigateTo(Screen.Grades)
                                }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            HubActionButton(
                                label = "📊 التقارير والتصدير",
                                subLabel = "مشاركة كشوفات الحضور",
                                icon = Icons.Default.Assessment,
                                color = Color(0xFF059669),
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    viewModel.selectCourseForAttendance(course)
                                    viewModel.selectCourseForGrades(course)
                                    viewModel.navigateTo(Screen.StudentReports)
                                }
                            )

                            HubActionButton(
                                label = "📋 الانضباط والمخالفات",
                                subLabel = "سجل المخالفات والتنبيهات",
                                icon = Icons.Default.WarningAmber,
                                color = Color(0xFFD97706),
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    viewModel.selectCourseForAttendance(course)
                                    viewModel.navigateTo(Screen.StudentViolations)
                                }
                            )
                        }

                        // Analytics Full Row Button
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    viewModel.selectCourseForAttendance(course)
                                    viewModel.navigateTo(Screen.CourseAttendanceAnalytics)
                                },
                            color = DawamiGold.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Analytics,
                                        contentDescription = null,
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "📈 تحليلات ونسب حضور الدورة الشاملة",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiNavy
                                    )
                                }

                                Text(
                                    text = "عرض الإحصائيات ←",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiNavy
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HubActionButton(
    label: String,
    subLabel: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = color.copy(alpha = 0.15f),
                shape = CircleShape,
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = color,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subLabel,
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
