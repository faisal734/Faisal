package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import com.example.data.entity.DailyCourseNote
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyCourseNoteDao {
    @Query("SELECT * FROM daily_course_notes")
    fun getAllDailyNotes(): Flow<List<DailyCourseNote>>

    @Query("SELECT * FROM daily_course_notes WHERE courseId = :courseId AND date = :date LIMIT 1")
    fun getDailyNoteForCourseAndDate(courseId: Int, date: String): Flow<DailyCourseNote?>

    @Query("SELECT * FROM daily_course_notes WHERE courseId = :courseId AND date = :date LIMIT 1")
    suspend fun getDailyNoteForCourseAndDateSync(courseId: Int, date: String): DailyCourseNote?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyNote(dailyNote: DailyCourseNote): Long

    @Update
    suspend fun updateDailyNote(dailyNote: DailyCourseNote)

    @Delete
    suspend fun deleteDailyNote(dailyNote: DailyCourseNote)

    @Query("DELETE FROM daily_course_notes WHERE courseId = :courseId")
    suspend fun deleteDailyNotesByCourseId(courseId: Int)

    @Query("DELETE FROM daily_course_notes")
    suspend fun deleteAllDailyNotes()
}
