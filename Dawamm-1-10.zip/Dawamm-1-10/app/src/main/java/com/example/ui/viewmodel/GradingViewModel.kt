package com.example.ui.viewmodel

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.entity.StudentAssignmentSubmission
import com.example.data.entity.StudentGrade
import com.example.data.entity.StudentGradeConfig
import com.example.data.entity.SubjectAssignmentTemplate
import com.example.data.repository.GradingRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * GradingViewModel: المسؤول الحصري عن إدارة درجات الطلاب وكشوف الدرجات،
 * وتوزيع وإعدادات درجات المقررات والدبلومات، وإدارة التكاليف والواجبات والمشاريع وتسليماتها.
 */
class GradingViewModel(
    application: Application,
    private val gradingRepository: GradingRepository = run {
        val database = AppDatabase.getDatabase(application)
        GradingRepository(
            database.studentGradeDao(),
            database.studentGradeConfigDao(),
            database.subjectAssignmentTemplateDao(),
            database.studentAssignmentSubmissionDao()
        )
    }
) : AndroidViewModel(application) {

    // --- تدفقات البيانات الشاملة (State Flows) ---
    val allGrades: StateFlow<List<StudentGrade>> = gradingRepository.allGrades
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allGradeConfigs: StateFlow<List<StudentGradeConfig>> = gradingRepository.allGradeConfigs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAssignmentTemplates: StateFlow<List<SubjectAssignmentTemplate>> = gradingRepository.allAssignmentTemplates
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAssignmentSubmissions: StateFlow<List<StudentAssignmentSubmission>> = gradingRepository.allAssignmentSubmissions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Activity Logging Helper ---
    private val appActivityLogDao = AppDatabase.getDatabase(application).appActivityLogDao()

    fun logActivity(
        category: String,
        actionType: String,
        title: String,
        description: String,
        relatedId: Long? = null,
        customDateStr: String? = null,
        customTimeStr: String? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = java.util.Date()
            val sdfDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH)
            val sdfTime = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ENGLISH)
            val dateStr = customDateStr ?: sdfDate.format(now)
            val timeStr = customTimeStr ?: sdfTime.format(now)
            val log = com.example.data.entity.AppActivityLog(
                category = category,
                actionType = actionType,
                title = title,
                description = description,
                dateStr = dateStr,
                timeStr = timeStr,
                relatedId = relatedId
            )
            appActivityLogDao.insertLog(log)
        }
    }

    // --- عمليات رصد وتحديث درجات الطلاب (Student Grades) ---
    fun saveStudentGrade(grade: StudentGrade) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val isActivated = sharedPrefs.getBoolean("is_activated", false)
        if (!isActivated) {
            val exists = allGrades.value.any { it.studentId == grade.studentId && it.courseId == grade.courseId }
            if (!exists && allGrades.value.size >= 5) {
                Toast.makeText(
                    getApplication(),
                    "النسخة التجريبية تتيح لك رصد 5 درجات للطلاب فقط! يرجى تفعيل البرنامج لفتح جميع المزايا.",
                    Toast.LENGTH_LONG
                ).show()
                return
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            val existing = allGrades.value.find { 
                (grade.id != 0 && it.id == grade.id) ||
                (it.studentId == grade.studentId && it.courseId == grade.courseId && it.subjectName.trim().equals(grade.subjectName.trim(), ignoreCase = true))
            }
            val gradeToSave = if (existing != null && grade.id == 0) grade.copy(id = existing.id) else grade

            if (existing != null) {
                val hasChanged = existing.attendanceScore != gradeToSave.attendanceScore ||
                    existing.participationScore != gradeToSave.participationScore ||
                    existing.assignmentsScore != gradeToSave.assignmentsScore ||
                    existing.projectsScore != gradeToSave.projectsScore ||
                    existing.theoreticalExamScore != gradeToSave.theoreticalExamScore ||
                    existing.practicalExamScore != gradeToSave.practicalExamScore ||
                    existing.customScoresJson != gradeToSave.customScoresJson ||
                    existing.studentName != gradeToSave.studentName ||
                    existing.isDiploma != gradeToSave.isDiploma

                if (!hasChanged) {
                    return@launch // No change, skip duplicate writes and log inflation
                }
            }

            val isUpdate = existing != null
            val actionType = if (isUpdate) "UPDATE" else "CREATE"
            val actionTitle = if (isUpdate) "تعديل درجات الطالب: ${grade.studentName}" else "رصد درجات جديدة للطالب: ${grade.studentName}"
            val desc = buildString {
                append("المادة: ${grade.subjectName} | المجموع: ${gradeToSave.getTotalScore()} | الدورة: ${grade.courseName}")
                append(" | الدرجات: ")
                append("حضور: ${gradeToSave.attendanceScore}، مشاركة: ${gradeToSave.participationScore}، تكاليف: ${gradeToSave.assignmentsScore}، مشاريع: ${gradeToSave.projectsScore}، نظري: ${gradeToSave.theoreticalExamScore}، عملي: ${gradeToSave.practicalExamScore}")
            }

            gradingRepository.insertGrade(gradeToSave)
            logActivity(
                category = "GRADES",
                actionType = actionType,
                title = actionTitle,
                description = desc,
                relatedId = grade.courseId.toLong()
            )
        }
    }

    fun saveStudentGradesBulk(grades: List<StudentGrade>, onComplete: ((Int) -> Unit)? = null) {
        if (grades.isEmpty()) {
            onComplete?.invoke(0)
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            var count = 0
            grades.forEach { grade ->
                val existing = allGrades.value.find { 
                    (grade.id != 0 && it.id == grade.id) ||
                    (it.studentId == grade.studentId && it.courseId == grade.courseId && it.subjectName.trim().equals(grade.subjectName.trim(), ignoreCase = true))
                }
                val gradeToSave = if (existing != null && grade.id == 0) grade.copy(id = existing.id) else grade
                gradingRepository.insertGrade(gradeToSave)
                count++
            }
            val first = grades.first()
            logActivity(
                category = "GRADES",
                actionType = "IMPORT",
                title = "استيراد درجات الطلاب (${grades.size} طالب)",
                description = "تم استيراد ورصد درجات (${grades.size}) طالب في مادة (${first.subjectName}) لدورة (${first.courseName}) من ملف خارجي بنجاح.",
                relatedId = first.courseId.toLong()
            )
            withContext(Dispatchers.Main) {
                onComplete?.invoke(count)
            }
        }
    }

    fun insertGrade(grade: StudentGrade, onInserted: ((Long) -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = gradingRepository.insertGrade(grade)
            onInserted?.invoke(id)
        }
    }

    fun deleteGrade(grade: StudentGrade) {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteGrade(grade)
        }
    }

    fun deleteGradesByCourseId(courseId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteGradesByCourseId(courseId)
        }
    }

    fun deleteGradesByStudentId(studentId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteGradesByStudentId(studentId)
        }
    }

    fun deleteAllGrades() {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteAllGrades()
        }
    }

    // --- عمليات إعدادات وتوزيع الدرجات (Grade Configs) ---
    fun insertGradeConfig(config: StudentGradeConfig, onInserted: ((Long) -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = gradingRepository.insertGradeConfig(config)
            onInserted?.invoke(id)
        }
    }

    fun deleteGradeConfig(config: StudentGradeConfig) {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteGradeConfig(config)
        }
    }

    fun deleteGradeConfigByCourseId(courseId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteGradeConfigByCourseId(courseId)
            logActivity(
                category = "GRADES",
                actionType = "DELETE",
                title = "إعادة ضبط توزيع الدرجات للدورة",
                description = "تم حذف وتصفير توزيع الدرجات",
                relatedId = courseId.toLong()
            )
        }
    }

    fun deleteAllGradeConfigs() {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteAllGradeConfigs()
        }
    }

    // --- نماذج التكاليف والواجبات والمشاريع (Assignment Templates) ---
    fun insertAssignmentTemplate(template: SubjectAssignmentTemplate, onInserted: ((Long) -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = gradingRepository.insertAssignmentTemplate(template)
            logActivity(
                category = "CURRICULUM",
                actionType = "CREATE",
                title = "إضافة قالب تكليف/مشروع: ${template.title}",
                description = "المادة: ${template.subjectName} | النوع: ${template.type} | الدرجة القصوى: ${template.maxScore}"
            )
            onInserted?.invoke(id)
        }
    }

    fun updateAssignmentTemplate(template: SubjectAssignmentTemplate) {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.updateAssignmentTemplate(template)
            logActivity(
                category = "CURRICULUM",
                actionType = "UPDATE",
                title = "تعديل قالب تكليف/مشروع: ${template.title}",
                description = "المادة: ${template.subjectName} | النوع: ${template.type} | الدرجة القصوى: ${template.maxScore}"
            )
        }
    }

    fun deleteAssignmentTemplate(template: SubjectAssignmentTemplate) {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteAssignmentTemplate(template)
            logActivity(
                category = "CURRICULUM",
                actionType = "DELETE",
                title = "حذف قالب تكليف/مشروع: ${template.title}",
                description = "المادة: ${template.subjectName} | النوع: ${template.type}"
            )
        }
    }

    fun deleteAssignmentTemplateFromCourse(template: SubjectAssignmentTemplate, courseId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            if (template.courseId == courseId) {
                gradingRepository.deleteAssignmentTemplate(template)
                logActivity(
                    category = "CURRICULUM",
                    actionType = "DELETE",
                    title = "حذف مشروع خاص بالدورة: ${template.title}",
                    description = "الدورة: $courseId | المادة: ${template.subjectName}"
                )
            } else {
                val updated = template.withCourseExcluded(courseId)
                gradingRepository.updateAssignmentTemplate(updated)
                logActivity(
                    category = "CURRICULUM",
                    actionType = "UPDATE",
                    title = "استبعاد مشروع من الدورة: ${template.title}",
                    description = "تم استبعاد المشروع من الدورة $courseId فقط دون حذفه من القوالب العامة للمادة"
                )
            }
        }
    }

    fun restoreAssignmentTemplateToCourse(template: SubjectAssignmentTemplate, courseId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = template.withCourseRestored(courseId)
            gradingRepository.updateAssignmentTemplate(updated)
            logActivity(
                category = "CURRICULUM",
                actionType = "UPDATE",
                title = "استعادة مشروع للدورة: ${template.title}",
                description = "تم إعادة تفعيل المشروع في الدورة $courseId"
            )
        }
    }

    fun exportAssignmentTemplateToGlobal(template: SubjectAssignmentTemplate, onFinished: (() -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val globalCopy = template.copy(
                id = 0,
                courseId = 0,
                excludedCourseIdsJson = ""
            )
            gradingRepository.insertAssignmentTemplate(globalCopy)
            logActivity(
                category = "CURRICULUM",
                actionType = "CREATE",
                title = "تصدير مشروع إلى القوالب العامة: ${template.title}",
                description = "المادة: ${template.subjectName} | النوع: ${template.type} | الدرجة القصوى: ${template.maxScore}"
            )
            onFinished?.invoke()
        }
    }

    fun deleteAssignmentTemplatesBySubject(subjectName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteAssignmentTemplatesBySubject(subjectName)
        }
    }

    fun deleteAllAssignmentTemplates() {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteAllAssignmentTemplates()
        }
    }

    // --- تسليمات وتقييم واجبات الطلاب (Assignment Submissions) ---
    fun insertAssignmentSubmission(submission: StudentAssignmentSubmission, onInserted: ((Long) -> Unit)? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = gradingRepository.insertAssignmentSubmission(submission)
            onInserted?.invoke(id)
        }
    }

    fun updateAssignmentSubmission(submission: StudentAssignmentSubmission) {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.updateAssignmentSubmission(submission)
        }
    }

    fun deleteAssignmentSubmission(submission: StudentAssignmentSubmission) {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteAssignmentSubmission(submission)
        }
    }

    fun deleteAllAssignmentSubmissions() {
        viewModelScope.launch(Dispatchers.IO) {
            gradingRepository.deleteAllAssignmentSubmissions()
        }
    }

    // --- حفظ وحذف إعدادات وقوالب الدرجات (Grade Configs & Templates) ---
    fun saveGradeConfig(
        courseId: Int,
        courseName: String,
        isDiploma: Boolean,
        customFields: List<Pair<String, Int>>,
        subjectWeights: Map<String, Double> = emptyMap()
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val config = StudentGradeConfig(
                courseId = courseId,
                courseName = courseName,
                isDiploma = isDiploma,
                customFieldsJson = StudentGradeConfig.serializeFields(customFields),
                subjectWeightsJson = StudentGradeConfig.serializeSubjectWeights(subjectWeights)
            )
            gradingRepository.insertGradeConfig(config)
        }
    }

    fun saveCustomTemplate(
        templateName: String,
        isDiploma: Boolean,
        customFields: List<Pair<String, Int>>,
        subjectWeights: Map<String, Double>
    ) {
        if (templateName.isBlank()) return
        val templateId = StudentGradeConfig.getCustomTemplateId(templateName)
        saveGradeConfig(
            courseId = templateId,
            courseName = "قالب مخصص: $templateName",
            isDiploma = isDiploma,
            customFields = customFields,
            subjectWeights = subjectWeights
        )
    }

    fun saveDepartmentTemplate(
        departmentName: String,
        isDiploma: Boolean,
        customFields: List<Pair<String, Int>>,
        subjectWeights: Map<String, Double>
    ) {
        if (departmentName.isBlank()) return
        val templateId = StudentGradeConfig.getDepartmentTemplateId(departmentName)
        saveGradeConfig(
            courseId = templateId,
            courseName = "قالب قسم: $departmentName",
            isDiploma = isDiploma,
            customFields = customFields,
            subjectWeights = subjectWeights
        )
    }

    fun saveDiplomaTemplate(
        diplomaName: String,
        isDiploma: Boolean,
        customFields: List<Pair<String, Int>>,
        subjectWeights: Map<String, Double>
    ) {
        if (diplomaName.isBlank()) return
        val templateId = StudentGradeConfig.getDiplomaTemplateId(diplomaName)
        saveGradeConfig(
            courseId = templateId,
            courseName = "قالب دبلوم: $diplomaName",
            isDiploma = isDiploma,
            customFields = customFields,
            subjectWeights = subjectWeights
        )
    }

    fun deleteStudentGradeConfigByCourseId(courseId: Int) {
        deleteGradeConfigByCourseId(courseId)
    }

    // --- التقييم اليدوي للتكاليف لكل دورة ومادة ---
    private val _manualAssignmentGradingMap = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val manualAssignmentGradingMap: StateFlow<Map<String, Boolean>> = _manualAssignmentGradingMap.asStateFlow()

    // --- Course Grading Mode ("AUTO", "MANUAL_BREAKDOWN", "MANUAL_FINAL") ---
    private val _courseGradingModes = MutableStateFlow<Map<Int, String>>(emptyMap())
    val courseGradingModes: StateFlow<Map<Int, String>> = _courseGradingModes.asStateFlow()

    private val courseDao = AppDatabase.getDatabase(application).courseDao()
    private val studentDao = AppDatabase.getDatabase(application).studentDao()

    init {
        loadManualAssignmentGradingMap()
        loadCourseGradingModes()
    }

    fun loadCourseGradingModes() {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val allEntries = sharedPrefs.all
        val map = mutableMapOf<Int, String>()
        allEntries.forEach { (key, value) ->
            if (key.startsWith("course_grading_mode_") && value is String) {
                val cId = key.removePrefix("course_grading_mode_").toIntOrNull()
                if (cId != null) {
                    map[cId] = value
                }
            }
        }
        _courseGradingModes.value = map
    }

    fun getCourseGradingMode(courseId: Int): String {
        return _courseGradingModes.value[courseId] ?: run {
            val saved = getApplication<Application>()
                .getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
                .getString("course_grading_mode_$courseId", "AUTO") ?: "AUTO"
            saved
        }
    }

    fun setCourseGradingMode(courseId: Int, mode: String) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit().putString("course_grading_mode_$courseId", mode).apply()
        _courseGradingModes.value = _courseGradingModes.value + (courseId to mode)
    }

    fun loadManualAssignmentGradingMap() {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val allEntries = sharedPrefs.all
        val map = mutableMapOf<String, Boolean>()
        allEntries.forEach { (key, value) ->
            if (key.startsWith("manual_assignment_mode_") && value is Boolean) {
                map[key.removePrefix("manual_assignment_mode_")] = value
            }
        }
        _manualAssignmentGradingMap.value = map
    }

    fun isManualAssignmentGrading(courseId: Int, subjectName: String): Boolean {
        val key = "${courseId}_${subjectName.trim()}"
        return _manualAssignmentGradingMap.value[key] ?: false
    }

    fun setManualAssignmentGrading(courseId: Int, subjectName: String, isManual: Boolean) {
        val key = "${courseId}_${subjectName.trim()}"
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        sharedPrefs.edit().putBoolean("manual_assignment_mode_$key", isManual).apply()
        _manualAssignmentGradingMap.value = _manualAssignmentGradingMap.value + (key to isManual)
    }

    fun setCourseAllSubjectsManualGrading(courseId: Int, subjectNames: List<String>, isManual: Boolean) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("dawami_prefs", Application.MODE_PRIVATE)
        val editor = sharedPrefs.edit()
        val current = _manualAssignmentGradingMap.value.toMutableMap()
        subjectNames.forEach { subjectName ->
            val key = "${courseId}_${subjectName.trim()}"
            editor.putBoolean("manual_assignment_mode_$key", isManual)
            current[key] = isManual
        }
        editor.apply()
        _manualAssignmentGradingMap.value = current
    }

    fun bulkApplyComponentGrade(courseId: Int, subjectNames: List<String>, componentName: String, score: Double, onlyIfEmpty: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val course = courseDao.getCourseById(courseId) ?: return@launch
            val allStudents = studentDao.getAllStudents().first()
            val students = allStudents.filter { it.courseId == courseId && (it.status == "مستمر" || it.status.isEmpty()) }
            val currentConfig = allGradeConfigs.value.find { it.courseId == courseId }
            val isDiploma = currentConfig?.isDiploma ?: course.diplomaName.isNotBlank()

            subjectNames.forEach { subjectName ->
                val currentGrades = allGrades.value.filter { it.courseId == courseId && (subjectName.isEmpty() || it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true)) }

                students.forEach { student ->
                    val existing = currentGrades.find { it.studentId == student.id }
                    if (onlyIfEmpty && existing != null && existing.getTotalScore() > 0) {
                        return@forEach
                    }
                    val base = (existing ?: StudentGrade(
                        studentId = student.id,
                        studentName = student.name,
                        courseId = courseId,
                        courseName = course.name,
                        subjectName = subjectName,
                        isDiploma = isDiploma
                    )).copy(isDiploma = isDiploma)

                    val updatedGrade = if (isDiploma) {
                        when {
                            componentName.contains("حضور") -> base.copy(attendanceScore = score)
                            componentName.contains("مشاركة") -> base.copy(participationScore = score)
                            componentName.contains("تكاليف") || componentName.contains("واجبات") -> base.copy(assignmentsScore = score)
                            componentName.contains("مشاريع") || componentName.contains("مشروع") -> base.copy(projectsScore = score)
                            componentName.contains("نظري") -> base.copy(theoreticalExamScore = score)
                            componentName.contains("عملي") -> base.copy(practicalExamScore = score)
                            else -> {
                                val map = base.getScoresMap().toMutableMap()
                                map[componentName] = score
                                base.copy(customScoresJson = map.entries.joinToString("|") { "${it.key}:${it.value}" })
                            }
                        }
                    } else {
                        val map = base.getScoresMap().toMutableMap()
                        map[componentName] = score
                        base.copy(customScoresJson = map.entries.joinToString("|") { "${it.key}:${it.value}" })
                    }.withManualGrading(true)
                    saveStudentGrade(updatedGrade)
                }
            }
        }
    }

    fun bulkApplyFinalGrade(courseId: Int, subjectNames: List<String>, finalScore: Double, onlyIfEmpty: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val course = courseDao.getCourseById(courseId) ?: return@launch
            val allStudents = studentDao.getAllStudents().first()
            val students = allStudents.filter { it.courseId == courseId && (it.status == "مستمر" || it.status.isEmpty()) }
            val currentConfig = allGradeConfigs.value.find { it.courseId == courseId }
            val isDiploma = currentConfig?.isDiploma ?: course.diplomaName.isNotBlank()

            subjectNames.forEach { subjectName ->
                val currentGrades = allGrades.value.filter { it.courseId == courseId && (subjectName.isEmpty() || it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true)) }

                students.forEach { student ->
                    val existing = currentGrades.find { it.studentId == student.id }
                    if (onlyIfEmpty && existing != null && existing.getTotalScore() > 0) {
                        return@forEach
                    }
                    val base = (existing ?: StudentGrade(
                        studentId = student.id,
                        studentName = student.name,
                        courseId = courseId,
                        courseName = course.name,
                        subjectName = subjectName,
                        isDiploma = isDiploma
                    )).copy(isDiploma = isDiploma)
                    val updatedGrade = base.withManualFinalGrading(finalScore)
                    saveStudentGrade(updatedGrade)
                }
            }
        }
    }

    fun smartPrefillBreakdownGrades(courseId: Int, subjectName: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            val currentGrades = allGrades.value.filter { it.courseId == courseId && (subjectName.isEmpty() || it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true)) }
            currentGrades.forEach { existing ->
                val updated = existing.withManualGrading(true)
                saveStudentGrade(updated)
            }
        }
    }

    fun updateStudentAssignmentAndProjectScore(
        courseId: Int,
        subjectName: String,
        studentId: Int,
        studentName: String,
        assignmentScore: Double,
        projectScore: Double
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val currentConfig = allGradeConfigs.value.find { it.courseId == courseId }
            val existingGradeRecord = allGrades.value.find { 
                it.studentId == studentId && it.courseId == courseId && 
                (it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true) || (it.subjectName.isEmpty() && subjectName.isEmpty()))
            }
            
            if (currentConfig?.isDiploma != false) {
                val gradeObj = StudentGrade(
                    id = existingGradeRecord?.id ?: 0,
                    studentId = studentId,
                    studentName = studentName,
                    courseId = courseId,
                    courseName = currentConfig?.courseName ?: "",
                    isDiploma = true,
                    subjectName = subjectName,
                    attendanceScore = existingGradeRecord?.attendanceScore ?: 0.0,
                    participationScore = existingGradeRecord?.participationScore ?: 0.0,
                    assignmentsScore = assignmentScore,
                    projectsScore = projectScore,
                    theoreticalExamScore = existingGradeRecord?.theoreticalExamScore ?: 0.0,
                    practicalExamScore = existingGradeRecord?.practicalExamScore ?: 0.0
                )
                saveStudentGrade(gradeObj)
            } else {
                val scoresMap = (existingGradeRecord?.getScoresMap() ?: emptyMap()).toMutableMap()
                val allConfigFields = StudentGradeConfig.deserializeFields(currentConfig.customFieldsJson)
                val subjectFields = allConfigFields.filter { it.first.startsWith("${subjectName}_") }
                    .map { Pair(it.first.substringAfter("${subjectName}_"), it.second) }
                val assName = subjectFields.find { it.first.contains("تكاليف") || it.first.contains("واجبات") || it.first.contains("بحوث") }?.first ?: "تكاليف"
                val projName = subjectFields.find { it.first.contains("مشاريع") || it.first.contains("مشروع") }?.first ?: "مشاريع"
                scoresMap[assName] = assignmentScore
                scoresMap[projName] = projectScore
                val gradeObj = StudentGrade(
                    id = existingGradeRecord?.id ?: 0,
                    studentId = studentId,
                    studentName = studentName,
                    courseId = courseId,
                    courseName = currentConfig.courseName,
                    isDiploma = false,
                    subjectName = subjectName,
                    customScoresJson = StudentGrade.serializeScores(scoresMap)
                )
                saveStudentGrade(gradeObj)
            }
            setManualAssignmentGrading(courseId, subjectName, true)
            logActivity(
                category = "GRADES",
                actionType = "UPDATE",
                title = "رصد يدوي لدرجات الطالب: $studentName",
                description = "المادة: $subjectName | تكاليف: $assignmentScore | مشاريع: $projectScore",
                relatedId = courseId.toLong()
            )
        }
    }
}
