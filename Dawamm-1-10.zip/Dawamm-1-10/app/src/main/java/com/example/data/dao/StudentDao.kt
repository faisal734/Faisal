package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import com.example.data.entity.Student
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY id DESC")
    fun getAllStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE courseId = :courseId ORDER BY name ASC")
    fun getStudentsByCourse(courseId: Int): Flow<List<Student>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student): Long

    @Update
    suspend fun updateStudent(student: Student)

    @Delete
    suspend fun deleteStudent(student: Student)

    @Query("DELETE FROM students WHERE courseId = :courseId")
    suspend fun deleteStudentsByCourseId(courseId: Int)

    @Query("UPDATE students SET courseName = :newName WHERE courseId = :courseId")
    suspend fun updateCourseName(courseId: Int, newName: String)

    @Query("UPDATE students SET courseId = :newCourseId, courseName = :newCourseName WHERE id = :studentId")
    suspend fun transferStudent(studentId: Int, newCourseId: Int, newCourseName: String)

    @Query("DELETE FROM students")
    suspend fun deleteAllStudents()
}
