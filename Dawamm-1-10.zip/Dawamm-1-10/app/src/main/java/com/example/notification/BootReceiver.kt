package com.example.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.database.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || 
            intent.action == "android.intent.action.QUICKBOOT_POWERON" ||
            intent.action == "com.htc.intent.action.QUICKBOOT_POWERON"
        ) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val sharedPrefs = context.getSharedPreferences("dawami_prefs", Context.MODE_PRIVATE)
                    val enabled = sharedPrefs.getBoolean("smart_notifications_enabled", true)
                    
                    if (enabled) {
                        val trainerMins = sharedPrefs.getInt("trainer_reminder_minutes", 15)
                        val checkInMins = sharedPrefs.getInt("student_check_in_reminder_minutes", 10)
                        val checkOutMins = sharedPrefs.getInt("student_check_out_reminder_minutes", 10)
                        
                        val db = AppDatabase.getDatabase(context)
                        val courses = db.courseDao().getAllCourses().first()
                        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                        
                        courses.forEach { course ->
                            if (!course.isCompleted && (course.endDate.isBlank() || course.endDate >= todayStr)) {
                                NotificationHelper.scheduleCourseReminders(
                                    context,
                                    course,
                                    trainerMins,
                                    checkInMins,
                                    checkOutMins
                                )
                            } else {
                                NotificationHelper.cancelCourseReminders(context, course.id)
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
