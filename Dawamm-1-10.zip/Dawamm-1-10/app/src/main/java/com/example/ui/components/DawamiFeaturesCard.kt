package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal

/**
 * بطاقة عرض مميزات نظام دوامي الذكي
 */
@Composable
fun DawamiFeaturesCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = DawamiTeal.copy(alpha = 0.12f),
                    shape = CircleShape,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = DawamiTeal,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Text(
                    text = "مميزات نظام دوامي الذكي ✨",
                    color = DawamiNavy,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            val features = listOf(
                Triple(Icons.Default.School, "إدارة حضور الأستاذ", "رصد التواجد وساعات العمل الذاتية للمدربين تلقائياً وبدقة عالية."),
                Triple(Icons.Default.People, "متابعة الطلاب والدوام", "إضافة بيانات الطلاب، رصد غيابهم وحضورهم اليومي بنقرة واحدة سريعة."),
                Triple(Icons.Default.Share, "مشاركة واتساب الذكية", "إرسال تقارير الغياب والنتائج فوراً عبر واتساب أو واتساب الأعمال."),
                Triple(Icons.Default.Assignment, "رصد وتعديل الدرجات", "تقسيم درجات دبلوم الحاسوب أو دورة مخصصة بالمجموع والمعدل والتقديرات."),
                Triple(Icons.Default.PictureAsPdf, "تقارير PDF احترافية", "تصدير كشوفات درجات وتقارير دوام رسمية تفصيلية ومشاركتها بمرونة."),
                Triple(Icons.Default.Backup, "النسخ الاحتياطي وتخصيص الهوية", "حفظ واستعادة البيانات بقاعدة البيانات مع تخصيص شعار واسم المعهد.")
            )

            features.forEach { (icon, title, desc) ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Surface(
                        color = DawamiNavy.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .size(28.dp)
                            .padding(top = 2.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = DawamiNavy,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = title,
                            color = DawamiNavy,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Text(
                            text = desc,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.5.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}
