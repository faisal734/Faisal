package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import com.example.data.entity.StudentAttendance
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentAttendanceDao {
    @Query("SELECT * FROM student_attendance_records ORDER BY date DESC, actualCheckIn DESC")
    fun getAllStudentAttendance(): Flow<List<StudentAttendance>>

    @Query("SELECT * FROM student_attendance_records WHERE courseId = :courseId ORDER BY date DESC, studentName ASC")
    fun getStudentAttendanceByCourse(courseId: Int): Flow<List<StudentAttendance>>

    @Query("SELECT * FROM student_attendance_records WHERE courseId = :courseId AND date = :date ORDER BY studentName ASC")
    fun getStudentAttendanceByCourseAndDate(courseId: Int, date: String): Flow<List<StudentAttendance>>

    @Query("SELECT * FROM student_attendance_records WHERE courseId = :courseId AND date = :date")
    suspend fun getStudentAttendanceByCourseAndDateSync(courseId: Int, date: String): List<StudentAttendance>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudentAttendance(attendance: StudentAttendance): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudentAttendances(attendances: List<StudentAttendance>)

    @Update
    suspend fun updateStudentAttendance(attendance: StudentAttendance)

    @Update
    suspend fun updateStudentAttendances(attendances: List<StudentAttendance>)

    @Delete
    suspend fun deleteStudentAttendance(attendance: StudentAttendance)

    @Delete
    suspend fun deleteStudentAttendances(attendances: List<StudentAttendance>)

    @Query("DELETE FROM student_attendance_records WHERE courseId = :courseId")
    suspend fun deleteStudentAttendanceByCourseId(courseId: Int)

    @Query("DELETE FROM student_attendance_records WHERE studentId = :studentId")
    suspend fun deleteStudentAttendanceByStudentId(studentId: Int)

    @Query("UPDATE student_attendance_records SET studentName = :newName WHERE studentId = :studentId")
    suspend fun updateStudentAttendanceName(studentId: Int, newName: String)

    @Query("UPDATE student_attendance_records SET courseName = :newName WHERE courseId = :courseId")
    suspend fun updateCourseName(courseId: Int, newName: String)

    @Query("UPDATE student_attendance_records SET subjectName = :newName WHERE subjectName = :oldName")
    suspend fun updateSubjectName(oldName: String, newName: String)

    @Query("UPDATE student_attendance_records SET courseId = :newCourseId, courseName = :newCourseName WHERE studentId = :studentId")
    suspend fun transferStudentAttendance(studentId: Int, newCourseId: Int, newCourseName: String)

    @Query("DELETE FROM student_attendance_records")
    suspend fun deleteAllStudentAttendance()
}
