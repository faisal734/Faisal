package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.Course
import com.example.data.entity.Subject
import com.example.data.entity.LessonTopic
import com.example.data.entity.LessonSessionTopic
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LessonPreparationScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    showMainLayout: Boolean = true
) {
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val courses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val subjects by (courseViewModel?.allSubjects ?: viewModel.dbSubjects).collectAsState()
    val courseSubjects by (courseViewModel?.allCourseSubjects ?: viewModel.dbCourseSubjects).collectAsState()
    val allTopics by (attendanceViewModel?.allLessonTopics ?: viewModel.dbLessonTopics).collectAsState()
    val sessionTopics by (attendanceViewModel?.allLessonSessionTopics ?: viewModel.dbLessonSessionTopics).collectAsState()
    val includeLessonTopicsInReport by viewModel.includeLessonTopicsInReport.collectAsState()

    val context = LocalContext.current

    // State for Selected Course, Subject, and Date
    var selectedCourseId by remember { mutableIntStateOf(courses.firstOrNull()?.id ?: 0) }
    var selectedSubjectId by remember { mutableIntStateOf(subjects.firstOrNull()?.id ?: 0) }
    var selectedDate by remember {
        mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
    }

    // Auto update selected course / subject if default is 0 or when course changes
    LaunchedEffect(selectedCourseId, courses, subjects, courseSubjects) {
        if (selectedCourseId == 0 && courses.isNotEmpty()) {
            selectedCourseId = courses.first().id
        }
        val assignedSubjects = courseSubjects.filter { it.courseId == selectedCourseId }.map { cs ->
            subjects.find { it.id == cs.subjectId }
        }.filterNotNull()

        if (selectedSubjectId == 0 || selectedSubjectId !in assignedSubjects.map { it.id }) {
            selectedSubjectId = assignedSubjects.firstOrNull()?.id ?: 0
        }
    }

    val currentCourse = courses.find { it.id == selectedCourseId }
    val currentSubject = subjects.find { it.id == selectedSubjectId }

    // Dropdown expanded states
    var courseDropdownExpanded by remember { mutableStateOf(false) }
    var subjectDropdownExpanded by remember { mutableStateOf(false) }

    // Dialog state for editing topic note
    var noteEditingSessionTopic by remember { mutableStateOf<LessonSessionTopic?>(null) }
    var noteInput by remember { mutableStateOf("") }

    // State for expandable main topics
    val expandedTopics = remember { mutableStateMapOf<Int, Boolean>() }
    fun isTopicExpanded(id: Int) = expandedTopics[id] ?: true
    fun toggleTopicExpanded(id: Int) { expandedTopics[id] = !(expandedTopics[id] ?: true) }

    MainLayout(viewModel = viewModel, showScaffold = showMainLayout) { innerPadding ->
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Header Banner & Filter Selectors Card
                Surface(
                    color = if (isDarkTheme) DarkSurface else Color.White,
                    tonalElevation = 2.dp,
                    border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Title Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    color = DawamiTeal.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.MenuBook,
                                            contentDescription = null,
                                            tint = DawamiTeal,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "تحضير ومتابعة الدروس والمنهج 📖",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDarkTheme) Color.White else DawamiNavy
                                    )
                                    Text(
                                        text = "اختر الدورة، المادة، والتاريخ لتحديد الدروس المشروحة",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Quick Link to Subjects Bank Screen
                            IconButton(
                                onClick = { viewModel.navigateTo(Screen.Subjects) }
                            ) {
                                Surface(
                                    color = DawamiNavy.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Settings,
                                            contentDescription = "بنك المواد",
                                            tint = DawamiNavy,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Divider(color = if (isDarkTheme) Color(0xFF334155) else Color(0xFFF1F5F9))

                        // --- 3 SELECTORS: COURSE, SUBJECT, DATE ---
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // 1. Select Course Dropdown
                            Column(modifier = Modifier.weight(1f)) {
                                Text("الدورة / الصف *", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedButton(
                                        onClick = { courseDropdownExpanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                                        ),
                                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.3f))
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = currentCourse?.name ?: "اختر الدورة",
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isDarkTheme) Color.White else DawamiNavy,
                                                maxLines = 1
                                            )
                                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    DropdownMenu(
                                        expanded = courseDropdownExpanded,
                                        onDismissRequest = { courseDropdownExpanded = false }
                                    ) {
                                        courses.forEach { course ->
                                            DropdownMenuItem(
                                                text = { Text(course.name, fontWeight = if (course.id == selectedCourseId) FontWeight.Bold else FontWeight.Normal) },
                                                onClick = {
                                                    selectedCourseId = course.id
                                                    courseDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            // 2. Select Subject Dropdown
                            Column(modifier = Modifier.weight(1f)) {
                                Text("المادة الدراسية *", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedButton(
                                        onClick = { subjectDropdownExpanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                                        ),
                                        border = BorderStroke(1.dp, DawamiTeal.copy(alpha = 0.5f))
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = currentSubject?.name ?: "اختر المادة",
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isDarkTheme) Color.White else DawamiTeal,
                                                maxLines = 1
                                            )
                                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    DropdownMenu(
                                        expanded = subjectDropdownExpanded,
                                        onDismissRequest = { subjectDropdownExpanded = false }
                                    ) {
                                        // Filter subjects strictly assigned to selected course
                                        val assignedSubjectIds = courseSubjects.filter { it.courseId == selectedCourseId }.map { it.subjectId }
                                        val availableSubjects = subjects.filter { it.id in assignedSubjectIds }

                                        if (availableSubjects.isEmpty()) {
                                            DropdownMenuItem(
                                                text = { Text("لا توجد مواد مخصصة لهذه الدورة", fontSize = 11.sp, color = Color.Gray) },
                                                onClick = { subjectDropdownExpanded = false }
                                            )
                                        } else {
                                            availableSubjects.forEach { subject ->
                                                DropdownMenuItem(
                                                    text = { Text(subject.name, fontWeight = if (subject.id == selectedSubjectId) FontWeight.Bold else FontWeight.Normal) },
                                                    onClick = {
                                                        selectedSubjectId = subject.id
                                                        subjectDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // 3. Select Preparation Date
                            Column(modifier = Modifier.weight(1f)) {
                                Text("تاريخ التحضير *", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                OutlinedButton(
                                    onClick = {
                                        viewModel.triggerDatePicker { date ->
                                            selectedDate = date
                                            viewModel.triggerWeekendWarningIfNeeded(date)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                                    ),
                                    border = BorderStroke(1.dp, Color(0xFF64748B))
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = selectedDate,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDarkTheme) Color.White else Color(0xFF334155),
                                            maxLines = 1
                                        )
                                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }

                        // WhatsApp Report Integration Option
                        Surface(
                            color = DawamiGold.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, DawamiGold.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = null,
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Column {
                                        Text(
                                            text = "دمج مواضيع المنهج في تقرير الواتساب اليومي",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy
                                        )
                                        Text(
                                            text = "عند التفعيل، سيتم إدراج المواضيع المشروحة (مستويين) في التقرير.",
                                            fontSize = 9.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Switch(
                                    checked = includeLessonTopicsInReport,
                                    onCheckedChange = { viewModel.setIncludeLessonTopicsInReport(it) },
                                    modifier = Modifier.scale(0.8f)
                                )
                            }
                        }
                    }
                }

                // Main Checklist & Progress Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (selectedCourseId == 0 || selectedSubjectId == 0) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "الرجاء تحديد المادة والدورة من الشريط العلوي لبدء التحضير.",
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        // Filter topics for the selected Subject (and legacy topics for selected course if subjectId is 0)
                        val subjectTopics = allTopics.filter {
                            it.subjectId == selectedSubjectId || (it.subjectId == 0 && it.courseId == selectedCourseId)
                        }

                        val mainTopics = subjectTopics.filter { it.level == 1 || it.parentId == null }

                        // Session completions for this course and date
                        val currentSessionTopics = sessionTopics.filter {
                            it.courseId == selectedCourseId && it.date == selectedDate
                        }

                        // Total completion progress calculation for this subject and course based on MAIN topics
                        val totalTopicsCount = mainTopics.size
                        val completedTopicsCount = mainTopics.count { mainTopic ->
                            val subTopics = subjectTopics.filter { it.parentId == mainTopic.id && it.level == 2 }
                            if (subTopics.isEmpty()) {
                                currentSessionTopics.any { it.topicId == mainTopic.id && it.isCompleted }
                            } else {
                                subTopics.all { sub -> currentSessionTopics.any { it.topicId == sub.id && it.isCompleted } }
                            }
                        }
                        val progressRatio = if (totalTopicsCount > 0) completedTopicsCount.toFloat() / totalTopicsCount else 0f

                        // Subject Progress Summary Bar
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDarkTheme) DarkSurface else Color.White
                            ),
                            border = BorderStroke(1.dp, if (isDarkTheme) Color(0xFF334155) else Color(0xFFE2E8F0))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "إنجاز مادة (${currentSubject?.name ?: ""}) لـ (${currentCourse?.name ?: ""}):",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDarkTheme) Color.White else DawamiNavy
                                    )
                                    Text(
                                        text = "$completedTopicsCount من $totalTopicsCount موضوع رئيسي (${(progressRatio * 100).toInt()}%)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiTeal
                                    )
                                }

                                LinearProgressIndicator(
                                    progress = { progressRatio },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = DawamiTeal,
                                    trackColor = DawamiTeal.copy(alpha = 0.2f)
                                )
                            }
                        }

                        if (mainTopics.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Category,
                                        contentDescription = null,
                                        tint = Color.Gray,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Text(
                                        text = "لا توجد مواضيع مضافة لمادة '${currentSubject?.name ?: ""}' بعد.",
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDarkTheme) Color.White else DawamiNavy
                                    )
                                    Button(
                                        onClick = { viewModel.navigateTo(Screen.Subjects) },
                                        colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("إضافة مواضيع المادة في بنك المواد ⚙️", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(mainTopics, key = { it.id }) { mainTopic ->
                                    val subTopics = subjectTopics.filter { it.parentId == mainTopic.id && it.level == 2 }
                                    val subTopicIds = subTopics.map { it.id }

                                    val mainSessionTopic = currentSessionTopics.find { it.topicId == mainTopic.id }
                                    
                                    val isMainCompleted = if (subTopics.isEmpty()) {
                                        mainSessionTopic?.isCompleted == true
                                    } else {
                                        subTopics.all { sub -> currentSessionTopics.any { it.topicId == sub.id && it.isCompleted } }
                                    }

                                    val completedSubCount = subTopics.count { sub ->
                                        currentSessionTopics.any { it.topicId == sub.id && it.isCompleted }
                                    }

                                    val isExpanded = isTopicExpanded(mainTopic.id)

                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isDarkTheme) DarkSurface else Color.White
                                        ),
                                        border = BorderStroke(1.dp, if (isMainCompleted) DawamiTeal else Color(0xFFE2E8F0))
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // Level 1 Topic Check Row
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable(enabled = subTopics.isNotEmpty()) {
                                                        toggleTopicExpanded(mainTopic.id)
                                                    },
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Checkbox(
                                                        checked = isMainCompleted,
                                                        onCheckedChange = { checked ->
                                                            viewModel.toggleMainTopicAndChildren(
                                                                courseId = selectedCourseId,
                                                                subjectId = selectedSubjectId,
                                                                mainTopicId = mainTopic.id,
                                                                date = selectedDate,
                                                                isCompleted = checked,
                                                                subTopicIds = subTopicIds
                                                            )
                                                        }
                                                    )

                                                    Column {
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                        ) {
                                                            Surface(
                                                                color = Color(0xFF1E3A8A),
                                                                shape = RoundedCornerShape(4.dp)
                                                            ) {
                                                                Text(
                                                                    text = "م1 رئيسي",
                                                                    fontSize = 8.5.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = Color.White,
                                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                                )
                                                            }
                                                            Text(
                                                                text = mainTopic.title,
                                                                fontSize = 13.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = if (isDarkTheme) Color.White else DawamiNavy
                                                            )

                                                            if (subTopics.isNotEmpty()) {
                                                                Surface(
                                                                    color = if (isMainCompleted) DawamiTeal.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.12f),
                                                                    shape = RoundedCornerShape(10.dp)
                                                                ) {
                                                                    Text(
                                                                        text = "$completedSubCount / ${subTopics.size} فرعي",
                                                                        fontSize = 9.5.sp,
                                                                        fontWeight = FontWeight.Bold,
                                                                        color = if (isMainCompleted) DawamiTeal else Color.Gray,
                                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                                    )
                                                                }
                                                            }
                                                        }
                                                        if (mainSessionTopic?.completedAt?.isNotEmpty() == true) {
                                                            Text(
                                                                text = "شُرح في: ${mainSessionTopic.completedAt}",
                                                                fontSize = 9.5.sp,
                                                                color = DawamiTeal,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }
                                                }

                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                                ) {
                                                    // Note Icon Button
                                                    IconButton(
                                                        onClick = {
                                                            if (mainSessionTopic == null) {
                                                                viewModel.addTopicToSession(
                                                                    courseId = selectedCourseId,
                                                                    subjectId = selectedSubjectId,
                                                                    topicId = mainTopic.id,
                                                                    date = selectedDate
                                                                )
                                                            }
                                                            val target = currentSessionTopics.find { it.topicId == mainTopic.id }
                                                            noteEditingSessionTopic = target
                                                            noteInput = target?.note ?: ""
                                                        }
                                                    ) {
                                                        Icon(
                                                            imageVector = if (mainSessionTopic?.note?.isNotEmpty() == true) Icons.Default.EditNote else Icons.Default.StickyNote2,
                                                            contentDescription = "ملاحظة",
                                                            tint = if (mainSessionTopic?.note?.isNotEmpty() == true) DawamiGold else Color.Gray,
                                                            modifier = Modifier.size(20.dp)
                                                        )
                                                    }

                                                    if (subTopics.isNotEmpty()) {
                                                        IconButton(
                                                            onClick = { toggleTopicExpanded(mainTopic.id) }
                                                        ) {
                                                            Icon(
                                                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                                contentDescription = if (isExpanded) "طي" else "توسيع",
                                                                tint = if (isDarkTheme) Color.White else DawamiNavy,
                                                                modifier = Modifier.size(22.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            if (mainSessionTopic?.note?.isNotEmpty() == true) {
                                                Surface(
                                                    color = DawamiGold.copy(alpha = 0.15f),
                                                    shape = RoundedCornerShape(6.dp),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text(
                                                        text = "📝 ملاحظة: ${mainSessionTopic.note}",
                                                        fontSize = 10.5.sp,
                                                        color = DawamiNavy,
                                                        fontWeight = FontWeight.Medium,
                                                        modifier = Modifier.padding(6.dp)
                                                    )
                                                }
                                            }

                                            // Level 2 Sub-Topics (if any) with Animation
                                            if (subTopics.isNotEmpty()) {
                                                AnimatedVisibility(
                                                    visible = isExpanded,
                                                    enter = fadeIn() + expandVertically(),
                                                    exit = fadeOut() + shrinkVertically()
                                                ) {
                                                    Column(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(start = 12.dp),
                                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        subTopics.forEach { subTopic ->
                                                            val subSessionTopic = currentSessionTopics.find { it.topicId == subTopic.id }
                                                            val isSubCompleted = subSessionTopic?.isCompleted == true

                                                            Surface(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                color = if (isSubCompleted) DawamiTeal.copy(alpha = 0.08f)
                                                                else if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC),
                                                                shape = RoundedCornerShape(8.dp),
                                                                border = BorderStroke(1.dp, if (isSubCompleted) DawamiTeal else Color(0xFFCBD5E1))
                                                            ) {
                                                                Row(
                                                                    modifier = Modifier
                                                                        .fillMaxWidth()
                                                                        .padding(horizontal = 6.dp, vertical = 2.dp),
                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                                ) {
                                                                    Row(
                                                                        verticalAlignment = Alignment.CenterVertically,
                                                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                                        modifier = Modifier.weight(1f)
                                                                    ) {
                                                                        Checkbox(
                                                                            checked = isSubCompleted,
                                                                            onCheckedChange = { checked ->
                                                                                viewModel.toggleSubTopicAndCheckParent(
                                                                                    courseId = selectedCourseId,
                                                                                    subjectId = selectedSubjectId,
                                                                                    subTopicId = subTopic.id,
                                                                                    mainTopicId = mainTopic.id,
                                                                                    date = selectedDate,
                                                                                    isCompleted = checked,
                                                                                    allSubTopicIds = subTopicIds
                                                                                )
                                                                            },
                                                                            modifier = Modifier.scale(0.85f)
                                                                        )

                                                                        Column {
                                                                            Row(
                                                                                verticalAlignment = Alignment.CenterVertically,
                                                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                                            ) {
                                                                                Surface(
                                                                                    color = Color(0xFF0284C7),
                                                                                    shape = RoundedCornerShape(3.dp)
                                                                                ) {
                                                                                    Text(
                                                                                        text = "م2 فرعي",
                                                                                        fontSize = 7.5.sp,
                                                                                        fontWeight = FontWeight.Bold,
                                                                                        color = Color.White,
                                                                                        modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                                                                                    )
                                                                                }
                                                                                Text(
                                                                                    text = subTopic.title,
                                                                                    fontSize = 11.5.sp,
                                                                                    fontWeight = FontWeight.Medium,
                                                                                    color = if (isDarkTheme) Color.White else DawamiNavy
                                                                                )
                                                                            }
                                                                            if (subSessionTopic?.completedAt?.isNotEmpty() == true) {
                                                                                Text(
                                                                                    text = "شُرح في: ${subSessionTopic.completedAt}",
                                                                                    fontSize = 8.5.sp,
                                                                                    color = DawamiTeal
                                                                                )
                                                                            }
                                                                        }
                                                                    }

                                                                    IconButton(
                                                                        onClick = {
                                                                            if (subSessionTopic == null) {
                                                                                viewModel.addTopicToSession(
                                                                                    courseId = selectedCourseId,
                                                                                    subjectId = selectedSubjectId,
                                                                                    topicId = subTopic.id,
                                                                                    date = selectedDate
                                                                                )
                                                                            }
                                                                            val target = currentSessionTopics.find { it.topicId == subTopic.id }
                                                                            noteEditingSessionTopic = target
                                                                            noteInput = target?.note ?: ""
                                                                        }
                                                                    ) {
                                                                        Icon(
                                                                            imageVector = if (subSessionTopic?.note?.isNotEmpty() == true) Icons.Default.EditNote else Icons.Default.StickyNote2,
                                                                            contentDescription = "ملاحظة",
                                                                            tint = if (subSessionTopic?.note?.isNotEmpty() == true) DawamiGold else Color.Gray,
                                                                            modifier = Modifier.size(16.dp)
                                                                        )
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Note Editing Dialog
    if (noteEditingSessionTopic != null) {
        AlertDialog(
            onDismissRequest = { noteEditingSessionTopic = null },
            title = {
                Text("ملاحظة شرح الموضوع / التمرين 📝", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DawamiNavy)
            },
            text = {
                OutlinedTextField(
                    value = noteInput,
                    onValueChange = { noteInput = it },
                    label = { Text("أدخل ملاحظات الشرح أو نقاط المراجعة") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    maxLines = 4
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        noteEditingSessionTopic?.let { sessionTopic ->
                            viewModel.updateSessionTopicNote(sessionTopic, noteInput)
                        }
                        Toast.makeText(context, "تم حفظ الملاحظة 👍", Toast.LENGTH_SHORT).show()
                        noteEditingSessionTopic = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DawamiNavy)
                ) {
                    Text("حفظ الملاحظة", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { noteEditingSessionTopic = null }) {
                    Text("إلغاء", color = Color.Gray)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = if (isDarkTheme) DarkSurface else Color.White
        )
    }
}
