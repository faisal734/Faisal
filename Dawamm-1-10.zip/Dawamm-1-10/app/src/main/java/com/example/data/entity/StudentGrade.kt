package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student_grade_configs")
data class StudentGradeConfig(
    @PrimaryKey val courseId: Int,
    val courseName: String,
    val isDiploma: Boolean, // true = Computer Diploma (7 subjects), false = Custom Fields
    val customFieldsJson: String = "", // Format: Name1:Max1|Name2:Max2
    val diplomaSubjectsJson: String = "", // Custom names if modified, otherwise we use standard
    val subjectWeightsJson: String = "", // Format: Subject1:Weight1|Subject2:Weight2
    val passingGradePercentage: Double = 75.0 // Default passing grade is 75%
) {
    fun getPassingPercentage(): Double {
        return if (passingGradePercentage > 0.0) passingGradePercentage else 75.0
    }

    fun getSubjectPassingThreshold(subjectName: String): Double {
        val weights = getSubjectWeights()
        val weight = weights[subjectName]
            ?: weights.entries.find { it.key.trim().equals(subjectName.trim(), ignoreCase = true) }?.value
            ?: 0.0
        val passPercent = getPassingPercentage()
        return if (weight > 0.0) {
            (passPercent / 100.0) * weight
        } else {
            passPercent
        }
    }

    fun getDiplomaSubjects(): List<String> {
        val list = if (diplomaSubjectsJson.isEmpty()) DEFAULT_DIPLOMA_SUBJECTS
        else diplomaSubjectsJson.split("|").filter { it.isNotEmpty() }
        return sortSubjectsList(list)
    }

    fun getSubjectWeights(): Map<String, Double> {
        if (subjectWeightsJson.isBlank()) return emptyMap()
        return subjectWeightsJson.split("|").mapNotNull { entry ->
            val parts = entry.split(":")
            if (parts.size == 2) {
                val name = parts[0].trim()
                val weight = parts[1].trim().toDoubleOrNull() ?: 0.0
                name to weight
            } else {
                null
            }
        }.toMap()
    }

    companion object {
        fun serializeSubjectWeights(weights: Map<String, Double>): String {
            return weights.entries.joinToString("|") { "${it.key.trim()}:${it.value}" }
        }

        fun getDepartmentTemplateId(deptName: String): Int = -100000 - Math.abs(deptName.trim().hashCode())
        fun getDiplomaTemplateId(diplName: String): Int = -500000 - Math.abs(diplName.trim().hashCode())
        fun getCustomTemplateId(templateName: String): Int = -800000 - Math.abs(templateName.trim().hashCode())

        fun getSubjectRank(subjectName: String): Int {
            val s = subjectName.trim()
            if (s.contains("مقدمة") && s.contains("حاسوب")) return 0
            if (s.contains("وورد") || s.contains("معالج النصوص")) return 1
            if (s.contains("بوربوينت") || s.contains("العروض") || s.contains("عروض")) return 2
            if (s.contains("اكسل") || s.contains("إكسل") || s.contains("الجداول")) return 3
            if (s.contains("اكسس") || s.contains("أكسس") || s.contains("قواعد")) return 4
            if (s.contains("التعاون")) return 5
            if (s.contains("انترنت") || s.contains("إنترنت") || s.contains("الشبكات")) return 6
            return 100
        }

        fun sortSubjectsList(subjects: List<String>): List<String> {
            return subjects.sortedWith(compareBy<String> { getSubjectRank(it) }.thenBy { it })
        }

        // Standard Computer Diploma subjects ordered with PowerPoint after Word as default
        val DEFAULT_DIPLOMA_SUBJECTS = listOf(
            "مقدمة في الحاسوب",
            "معالج النصوص (وورد)",
            "العروض التقديمية (بوربوينت)",
            "الجداول الإلكترونية (إكسل)",
            "قواعد البيانات (أكسس)",
            "التعاون",
            "أساسيات الإنترنت والشبكات"
        )

        fun serializeFields(fields: List<Pair<String, Int>>): String {
            return fields.joinToString("|") { "${it.first}:${it.second}" }
        }

        fun deserializeFields(data: String): List<Pair<String, Int>> {
            if (data.isEmpty()) return emptyList()
            return data.split("|").mapNotNull {
                val parts = it.split(":")
                if (parts.size == 2) {
                    val name = parts[0]
                    val max = parts[1].toIntOrNull() ?: 0
                    name to max
                } else {
                    null
                }
            }
        }
    }
}

@Entity(tableName = "student_grades")
data class StudentGrade(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studentId: Int,
    val studentName: String,
    val courseId: Int,
    val courseName: String,
    val isDiploma: Boolean,
    val subjectName: String = "", // e.g. one of the 7 subjects
    
    // Diploma scores
    val attendanceScore: Double = 0.0,       // Max 5
    val participationScore: Double = 0.0,    // Max 5
    val assignmentsScore: Double = 0.0,      // Max 10
    val projectsScore: Double = 0.0,         // Max 20
    val theoreticalExamScore: Double = 0.0,  // Max 20
    val practicalExamScore: Double = 0.0,    // Max 40
    
    // Custom other courses scores
    val customScoresJson: String = "" // Format: Name1:Score1|Name2:Score2
) {
    fun getDiplomaTotal(): Double {
        return attendanceScore + participationScore + assignmentsScore + projectsScore + theoreticalExamScore + practicalExamScore
    }

    fun getTotalScore(): Double {
        if (isManualFinalGrading()) {
            return getManualFinalScore() ?: if (isDiploma) getDiplomaTotal() else deserializeScores(customScoresJson).values.sum()
        }
        return if (isDiploma) {
            getDiplomaTotal()
        } else {
            deserializeScores(customScoresJson).values.sum()
        }
    }

    fun getGradeNote(): String {
        if (customScoresJson.isEmpty()) return ""
        val noteEntry = customScoresJson.split("|").find { it.startsWith("__note__:") }
        return noteEntry?.substringAfter("__note__:")?.replace("&&pipe&&", "|") ?: ""
    }

    fun isManualGrading(): Boolean {
        return customScoresJson.contains("__manual__:true") || isManualFinalGrading()
    }

    fun isManualFinalGrading(): Boolean {
        return customScoresJson.contains("__manual_final__:true")
    }

    fun getManualFinalScore(): Double? {
        val entry = customScoresJson.split("|").find { it.startsWith("final_score:") }
        return entry?.substringAfter("final_score:")?.toDoubleOrNull()
    }

    fun withManualGrading(isManual: Boolean): StudentGrade {
        val nonManualEntries = customScoresJson.split("|").filter { it.isNotEmpty() && !it.startsWith("__manual__:") }.toMutableList()
        if (isManual) {
            nonManualEntries.add("__manual__:true")
        }
        return copy(customScoresJson = nonManualEntries.joinToString("|"))
    }

    fun withManualFinalGrading(score: Double): StudentGrade {
        val nonFinalEntries = customScoresJson.split("|").filter {
            it.isNotEmpty() && !it.startsWith("__manual_final__:") && !it.startsWith("final_score:") && !it.startsWith("__manual__:")
        }.toMutableList()
        nonFinalEntries.add("__manual__:true")
        nonFinalEntries.add("__manual_final__:true")
        nonFinalEntries.add("final_score:$score")
        return copy(customScoresJson = nonFinalEntries.joinToString("|"))
    }

    fun getScoresMap(): Map<String, Double> {
        if (isManualFinalGrading()) {
            return mapOf("الدرجة النهائية المعتمدة" to getTotalScore())
        }
        return if (isDiploma) {
            mapOf(
                "حضور" to attendanceScore,
                "مشاركة" to participationScore,
                "تكاليف" to assignmentsScore,
                "مشاريع" to projectsScore,
                "اختبار نظري" to theoreticalExamScore,
                "اختبار عملي" to practicalExamScore
            )
        } else {
            deserializeScores(customScoresJson)
        }
    }

    companion object {
        fun createManualFinalGrade(
            id: Int = 0,
            studentId: Int,
            studentName: String,
            courseId: Int,
            courseName: String,
            isDiploma: Boolean,
            subjectName: String,
            finalScore: Double
        ): StudentGrade {
            return StudentGrade(
                id = id,
                studentId = studentId,
                studentName = studentName,
                courseId = courseId,
                courseName = courseName,
                isDiploma = isDiploma,
                subjectName = subjectName,
                customScoresJson = "__manual__:true|__manual_final__:true|final_score:$finalScore"
            )
        }

        fun withNote(customScoresJson: String, note: String): String {
            val cleanNote = note.trim().replace("|", "&&pipe&&")
            val nonNoteEntries = customScoresJson.split("|").filter { it.isNotEmpty() && !it.startsWith("__note__:") }
            val list = nonNoteEntries.toMutableList()
            if (cleanNote.isNotEmpty()) {
                list.add("__note__:$cleanNote")
            }
            return list.joinToString("|")
        }

        fun serializeScores(scores: Map<String, Double>): String {
            return scores.entries.joinToString("|") { "${it.key}:${it.value}" }
        }

        fun deserializeScores(data: String): Map<String, Double> {
            if (data.isEmpty()) return emptyMap()
            return data.split("|").filter { 
                !it.startsWith("__note__:") && 
                !it.startsWith("__manual__:") && 
                !it.startsWith("__manual_final__:") && 
                !it.startsWith("final_score:") 
            }.mapNotNull {
                val parts = it.split(":")
                if (parts.size == 2) {
                    val name = parts[0]
                    val score = parts[1].toDoubleOrNull()
                    if (score != null) {
                        name to score
                    } else {
                        null
                    }
                } else {
                    null
                }
            }.toMap()
        }
    }
}
