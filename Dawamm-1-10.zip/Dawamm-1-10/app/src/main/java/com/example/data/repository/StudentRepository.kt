package com.example.data.repository

import com.example.data.dao.StudentDao
import com.example.data.dao.StudentViolationDao
import com.example.data.entity.Student
import com.example.data.entity.StudentViolation
import kotlinx.coroutines.flow.Flow

/**
 * StudentRepository: مسؤول عن إدارة سجلات الطلاب والمخالفات السلوكية وعمليات النقل.
 */
class StudentRepository(
    private val studentDao: StudentDao,
    private val studentViolationDao: StudentViolationDao
) {
    val allStudents: Flow<List<Student>> = studentDao.getAllStudents()
    val allViolations: Flow<List<StudentViolation>> = studentViolationDao.getAllViolations()

    fun getStudentsByCourse(courseId: Int): Flow<List<Student>> = studentDao.getStudentsByCourse(courseId)
    suspend fun insertStudent(student: Student): Long = studentDao.insertStudent(student)
    suspend fun updateStudent(student: Student) = studentDao.updateStudent(student)
    suspend fun deleteStudent(student: Student) = studentDao.deleteStudent(student)
    suspend fun deleteStudentsByCourseId(courseId: Int) = studentDao.deleteStudentsByCourseId(courseId)
    suspend fun updateCourseNameInStudents(courseId: Int, newName: String) = studentDao.updateCourseName(courseId, newName)
    suspend fun transferStudent(studentId: Int, newCourseId: Int, newCourseName: String) = studentDao.transferStudent(studentId, newCourseId, newCourseName)
    suspend fun deleteAllStudents() = studentDao.deleteAllStudents()

    // Violations
    fun getViolationsForCourse(courseId: Long): Flow<List<StudentViolation>> = studentViolationDao.getViolationsForCourse(courseId)
    fun getViolationsForCourseAndSubject(courseId: Long, subjectName: String): Flow<List<StudentViolation>> = studentViolationDao.getViolationsForCourseAndSubject(courseId, subjectName)
    fun getViolationsForStudent(studentId: Long): Flow<List<StudentViolation>> = studentViolationDao.getViolationsForStudent(studentId)
    suspend fun insertViolation(violation: StudentViolation): Long = studentViolationDao.insertViolation(violation)
    suspend fun insertViolations(violations: List<StudentViolation>): List<Long> = studentViolationDao.insertViolations(violations)
    suspend fun updateViolation(violation: StudentViolation) = studentViolationDao.updateViolation(violation)
    suspend fun deleteViolation(violation: StudentViolation) = studentViolationDao.deleteViolation(violation)
    suspend fun deleteViolationById(id: Long) = studentViolationDao.deleteViolationById(id)
    suspend fun deleteAllViolations() = studentViolationDao.deleteAllViolations()
}
