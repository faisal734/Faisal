package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val courseId: Int,
    val courseName: String,
    val phoneNumber: String = "",
    val status: String = "مستمر",
    val statusChangeDate: String = ""
)
