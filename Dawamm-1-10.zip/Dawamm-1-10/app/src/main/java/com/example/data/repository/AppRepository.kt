package com.example.data.repository

import com.example.data.dao.CourseDao
import com.example.data.dao.AttendanceDao
import com.example.data.dao.StudentDao
import com.example.data.dao.StudentAttendanceDao
import com.example.data.dao.DailyCourseNoteDao
import com.example.data.dao.StudentGradeConfigDao
import com.example.data.dao.StudentGradeDao
import com.example.data.dao.LessonTopicDao
import com.example.data.dao.LessonSessionTopicDao
import com.example.data.dao.SubjectDao
import com.example.data.dao.TrainerTransactionDao
import com.example.data.dao.SubjectAssignmentTemplateDao
import com.example.data.dao.StudentAssignmentSubmissionDao
import com.example.data.dao.SubjectReferenceDao
import com.example.data.dao.AppActivityLogDao
import com.example.data.dao.StudentViolationDao
import com.example.data.dao.OfficialHolidayDao
import com.example.data.entity.*
import kotlinx.coroutines.flow.Flow

/**
 * AppRepository: الواجهة المركزية الموحدة (Facade Repository) التي تفوض المهام
 * للمستودعات المتخصصة النظيفة مع الحفاظ على التوافق التام 100% مع كامل استدعاءات المشروع السابقة.
 */
class AppRepository(
    private val courseDao: CourseDao,
    private val attendanceDao: AttendanceDao,
    private val studentDao: StudentDao,
    private val studentAttendanceDao: StudentAttendanceDao,
    private val dailyCourseNoteDao: DailyCourseNoteDao,
    private val studentGradeConfigDao: StudentGradeConfigDao,
    private val studentGradeDao: StudentGradeDao,
    private val lessonTopicDao: LessonTopicDao,
    private val lessonSessionTopicDao: LessonSessionTopicDao,
    private val subjectDao: SubjectDao,
    private val trainerTransactionDao: TrainerTransactionDao,
    private val subjectAssignmentTemplateDao: SubjectAssignmentTemplateDao,
    private val studentAssignmentSubmissionDao: StudentAssignmentSubmissionDao,
    private val subjectReferenceDao: SubjectReferenceDao,
    private val appActivityLogDao: AppActivityLogDao,
    private val studentViolationDao: StudentViolationDao,
    private val officialHolidayDao: OfficialHolidayDao
) {
    // المستودعات المتخصصة المدمجة
    val courses = CourseRepository(courseDao, subjectDao, subjectReferenceDao)
    val attendance = AttendanceRepository(attendanceDao, studentAttendanceDao, lessonTopicDao, lessonSessionTopicDao, dailyCourseNoteDao)
    val students = StudentRepository(studentDao, studentViolationDao)
    val grading = GradingRepository(studentGradeDao, studentGradeConfigDao, subjectAssignmentTemplateDao, studentAssignmentSubmissionDao)
    val admin = AppAdminRepository(trainerTransactionDao, appActivityLogDao)
    val officialHolidays = OfficialHolidayRepository(officialHolidayDao)

    // Flow Streams (المطابقة الكاملة)
    val allCourses: Flow<List<Course>> = courses.allCourses
    val allAttendance: Flow<List<Attendance>> = attendance.allAttendance
    val allStudents: Flow<List<Student>> = students.allStudents
    val allStudentAttendance: Flow<List<StudentAttendance>> = attendance.allStudentAttendance
    val allGrades: Flow<List<StudentGrade>> = grading.allGrades
    val allGradeConfigs: Flow<List<StudentGradeConfig>> = grading.allGradeConfigs
    val allLessonTopics: Flow<List<LessonTopic>> = attendance.allLessonTopics
    val allLessonSessionTopics: Flow<List<LessonSessionTopic>> = attendance.allLessonSessionTopics
    val allSubjects: Flow<List<Subject>> = courses.allSubjects
    val allCourseSubjects: Flow<List<CourseSubjectCrossRef>> = courses.allCourseSubjects
    val allTrainerTransactions: Flow<List<TrainerTransaction>> = admin.allTrainerTransactions
    val allActivityLogs: Flow<List<AppActivityLog>> = admin.allActivityLogs
    val allAssignmentTemplates: Flow<List<SubjectAssignmentTemplate>> = grading.allAssignmentTemplates
    val allAssignmentSubmissions: Flow<List<StudentAssignmentSubmission>> = grading.allAssignmentSubmissions
    val allOfficialHolidays: Flow<List<OfficialHoliday>> = officialHolidays.allHolidaysFlow
    val enabledOfficialHolidays: Flow<List<OfficialHoliday>> = officialHolidays.enabledHolidaysFlow
    val allViolations: Flow<List<StudentViolation>> = students.allViolations
    val allReferences: Flow<List<SubjectReference>> = courses.allReferences

    // Student Violations
    fun getViolationsForCourse(courseId: Long): Flow<List<StudentViolation>> = students.getViolationsForCourse(courseId)
    fun getViolationsForCourseAndSubject(courseId: Long, subjectName: String): Flow<List<StudentViolation>> = students.getViolationsForCourseAndSubject(courseId, subjectName)
    fun getViolationsForStudent(studentId: Long): Flow<List<StudentViolation>> = students.getViolationsForStudent(studentId)
    suspend fun insertViolation(violation: StudentViolation): Long = students.insertViolation(violation)
    suspend fun insertViolations(violations: List<StudentViolation>): List<Long> = students.insertViolations(violations)
    suspend fun updateViolation(violation: StudentViolation) = students.updateViolation(violation)
    suspend fun deleteViolation(violation: StudentViolation) = students.deleteViolation(violation)
    suspend fun deleteViolationById(id: Long) = students.deleteViolationById(id)
    suspend fun deleteAllViolations() = students.deleteAllViolations()

    // Assignment Templates & Submissions
    suspend fun insertAssignmentTemplate(template: SubjectAssignmentTemplate): Long = grading.insertAssignmentTemplate(template)
    suspend fun updateAssignmentTemplate(template: SubjectAssignmentTemplate) = grading.updateAssignmentTemplate(template)
    suspend fun deleteAssignmentTemplate(template: SubjectAssignmentTemplate) = grading.deleteAssignmentTemplate(template)
    suspend fun deleteAssignmentTemplatesBySubject(subjectName: String) = grading.deleteAssignmentTemplatesBySubject(subjectName)

    fun getReferencesForSubject(subjectName: String): Flow<List<SubjectReference>> = courses.getReferencesForSubject(subjectName)
    suspend fun insertSubjectReference(reference: SubjectReference): Long = courses.insertSubjectReference(reference)
    suspend fun updateSubjectReference(reference: SubjectReference) = courses.updateSubjectReference(reference)
    suspend fun deleteSubjectReference(reference: SubjectReference) = courses.deleteSubjectReference(reference)
    suspend fun deleteReferencesBySubject(subjectName: String) = courses.deleteReferencesBySubject(subjectName)
    suspend fun updateSubjectReferenceName(oldName: String, newName: String) = courses.updateSubjectReferenceName(oldName, newName)

    suspend fun insertAssignmentSubmission(submission: StudentAssignmentSubmission): Long = grading.insertAssignmentSubmission(submission)
    suspend fun updateAssignmentSubmission(submission: StudentAssignmentSubmission) = grading.updateAssignmentSubmission(submission)
    suspend fun deleteAssignmentSubmission(submission: StudentAssignmentSubmission) = grading.deleteAssignmentSubmission(submission)
    suspend fun getSubmissionsForCourseDirect(courseId: Int): List<StudentAssignmentSubmission> = grading.getSubmissionsForCourseDirect(courseId)
    suspend fun getLatestAssignmentSubmissionDirect(courseId: Int, subjectName: String, studentId: Int, assignmentTitle: String): StudentAssignmentSubmission? = grading.getLatestAssignmentSubmissionDirect(courseId, subjectName, studentId, assignmentTitle)

    // Trainer Transactions
    suspend fun insertTrainerTransaction(tx: TrainerTransaction): Long = admin.insertTrainerTransaction(tx)
    suspend fun updateTrainerTransaction(tx: TrainerTransaction) = admin.updateTrainerTransaction(tx)
    suspend fun deleteTrainerTransaction(tx: TrainerTransaction) = admin.deleteTrainerTransaction(tx)
    suspend fun deleteAllTrainerTransactions() = admin.deleteAllTrainerTransactions()

    // Subject operations
    suspend fun insertSubject(subject: Subject): Long = courses.insertSubject(subject)
    suspend fun updateSubject(subject: Subject) {
        val oldSubject = courses.getSubjectById(subject.id)
        courses.updateSubject(subject)
        if (oldSubject != null && oldSubject.name != subject.name) {
            grading.updateSubjectNameInGrades(oldSubject.name, subject.name)
            attendance.updateSubjectNameInStudentAttendance(oldSubject.name, subject.name)
            attendance.updateSubjectNameInAttendance(oldSubject.name, subject.name)
            grading.updateSubjectNameInAssignmentTemplates(oldSubject.name, subject.name)
            grading.updateSubjectNameInSubmissions(oldSubject.name, subject.name)
        }
    }
    suspend fun deleteSubject(subject: Subject) {
        courses.deleteSubject(subject)
        subjectDao.deleteCoursesBySubjectId(subject.id)
    }

    suspend fun insertCourseSubject(crossRef: CourseSubjectCrossRef) = courses.insertCourseSubject(crossRef)
    suspend fun deleteCourseSubject(crossRef: CourseSubjectCrossRef) = courses.deleteCourseSubject(crossRef)

    // Course operations
    suspend fun insertCourse(course: Course): Long = courses.insertCourse(course)
    suspend fun updateCourse(course: Course) {
        val oldCourse = courses.getCourseById(course.id)
        courses.updateCourse(course)
        if (oldCourse != null && oldCourse.name != course.name) {
            students.updateCourseNameInStudents(course.id, course.name)
            grading.updateCourseNameInGrades(course.id, course.name)
            attendance.updateCourseNameInStudentAttendance(course.id, course.name)
            attendance.updateCourseNameInAttendance(course.id, course.name)
            trainerTransactionDao.updateCourseName(course.id, course.name)
        }
    }

    suspend fun deleteCourse(course: Course) {
        courses.deleteCourse(course)
        attendance.deleteAttendanceByCourseId(course.id)
        students.deleteStudentsByCourseId(course.id)
        attendance.deleteStudentAttendanceByCourseId(course.id)
        attendance.deleteDailyNotesByCourseId(course.id)
        grading.deleteGradeConfigByCourseId(course.id)
        grading.deleteGradesByCourseId(course.id)
        attendance.deleteTopicsByCourseId(course.id)
        attendance.deleteSessionTopicsByCourseId(course.id)
    }

    suspend fun getCourseById(courseId: Int): Course? = courses.getCourseById(courseId)

    // Trainer Attendance
    suspend fun insertAttendance(attendanceRecord: Attendance): Long = attendance.insertAttendance(attendanceRecord)
    suspend fun updateAttendance(attendanceRecord: Attendance) = attendance.updateAttendance(attendanceRecord)
    suspend fun deleteAttendance(attendanceRecord: Attendance) = attendance.deleteAttendance(attendanceRecord)
    fun getAttendanceByCourse(courseId: Int): Flow<List<Attendance>> = attendance.getAttendanceByCourse(courseId)

    // Student Operations
    fun getStudentsByCourse(courseId: Int): Flow<List<Student>> = students.getStudentsByCourse(courseId)
    suspend fun insertStudent(student: Student): Long = students.insertStudent(student)
    suspend fun updateStudent(student: Student) {
        students.updateStudent(student)
        attendance.updateStudentAttendanceName(student.id, student.name)
        grading.updateStudentGradeName(student.id, student.name)
    }
    suspend fun transferStudent(studentId: Int, newCourseId: Int, newCourseName: String) {
        students.transferStudent(studentId, newCourseId, newCourseName)
    }
    suspend fun deleteStudent(student: Student) {
        students.deleteStudent(student)
        attendance.deleteStudentAttendanceByStudentId(student.id)
    }

    // Student Attendance Operations
    fun getStudentAttendanceByCourse(courseId: Int): Flow<List<StudentAttendance>> = attendance.getStudentAttendanceByCourse(courseId)
    fun getStudentAttendanceByCourseAndDate(courseId: Int, date: String): Flow<List<StudentAttendance>> = attendance.getStudentAttendanceByCourseAndDate(courseId, date)
    suspend fun getStudentAttendanceByCourseAndDateSync(courseId: Int, date: String): List<StudentAttendance> = attendance.getStudentAttendanceByCourseAndDateSync(courseId, date)
    suspend fun insertStudentAttendance(attendanceRecord: StudentAttendance): Long = attendance.insertStudentAttendance(attendanceRecord)
    suspend fun insertStudentAttendances(attendances: List<StudentAttendance>) = attendance.insertStudentAttendances(attendances)
    suspend fun updateStudentAttendance(attendanceRecord: StudentAttendance) = attendance.updateStudentAttendance(attendanceRecord)
    suspend fun updateStudentAttendances(attendances: List<StudentAttendance>) = attendance.updateStudentAttendances(attendances)
    suspend fun deleteStudentAttendance(attendanceRecord: StudentAttendance) = attendance.deleteStudentAttendance(attendanceRecord)
    suspend fun deleteStudentAttendances(attendances: List<StudentAttendance>) = attendance.deleteStudentAttendances(attendances)

    // Daily Course Note Operations
    fun getAllDailyNotes(): Flow<List<DailyCourseNote>> = attendance.allDailyNotes
    fun getDailyNoteForCourseAndDate(courseId: Int, date: String): Flow<DailyCourseNote?> = attendance.getDailyNoteForCourseAndDate(courseId, date)
    suspend fun getDailyNoteForCourseAndDateSync(courseId: Int, date: String): DailyCourseNote? = attendance.getDailyNoteForCourseAndDateSync(courseId, date)
    suspend fun insertDailyNote(dailyNote: DailyCourseNote): Long = attendance.insertDailyNote(dailyNote)
    suspend fun updateDailyNote(dailyNote: DailyCourseNote) = attendance.updateDailyNote(dailyNote)
    suspend fun deleteDailyNote(dailyNote: DailyCourseNote) = attendance.deleteDailyNote(dailyNote)

    // Student Grade Config Operations
    fun getGradeConfigForCourse(courseId: Int): Flow<StudentGradeConfig?> = grading.getGradeConfigForCourse(courseId)
    suspend fun getGradeConfigForCourseSync(courseId: Int): StudentGradeConfig? = grading.getGradeConfigForCourseSync(courseId)
    suspend fun insertGradeConfig(config: StudentGradeConfig): Long = grading.insertGradeConfig(config)
    suspend fun deleteGradeConfig(config: StudentGradeConfig) = grading.deleteGradeConfig(config)
    suspend fun deleteGradeConfigByCourseId(courseId: Int) {
        grading.deleteGradeConfigByCourseId(courseId)
        grading.deleteGradesByCourseId(courseId)
    }

    // Student Grade Operations
    fun getGradesByCourse(courseId: Int): Flow<List<StudentGrade>> = grading.getGradesByCourse(courseId)
    fun getGradesByStudent(studentId: Int): Flow<List<StudentGrade>> = grading.getGradesByStudent(studentId)
    suspend fun getGradeByStudentAndSubjectSync(studentId: Int, subjectName: String): StudentGrade? = grading.getGradeByStudentAndSubjectSync(studentId, subjectName)
    suspend fun insertGrade(grade: StudentGrade): Long = grading.insertGrade(grade)
    suspend fun deleteGrade(grade: StudentGrade) = grading.deleteGrade(grade)

    // Lesson Topics Operations
    fun getTopicsForCourse(courseId: Int): Flow<List<LessonTopic>> = attendance.getTopicsForCourse(courseId)
    suspend fun insertLessonTopic(topic: LessonTopic): Long = attendance.insertLessonTopic(topic)
    suspend fun updateLessonTopic(topic: LessonTopic) = attendance.updateLessonTopic(topic)
    suspend fun deleteLessonTopic(topic: LessonTopic) = attendance.deleteLessonTopic(topic)

    // Lesson Session Topics Operations
    fun getSessionTopics(courseId: Int, date: String): Flow<List<LessonSessionTopic>> = attendance.getSessionTopics(courseId, date)
    suspend fun insertLessonSessionTopic(sessionTopic: LessonSessionTopic): Long = attendance.insertSessionTopic(sessionTopic)
    suspend fun updateLessonSessionTopic(sessionTopic: LessonSessionTopic) = attendance.updateSessionTopic(sessionTopic)
    suspend fun deleteLessonSessionTopic(sessionTopic: LessonSessionTopic) = attendance.deleteSessionTopic(sessionTopic)

    // Activity Log Operations
    suspend fun insertActivityLog(log: AppActivityLog): Long = admin.insertActivityLog(log)
    suspend fun insertActivityLogs(logs: List<AppActivityLog>) = admin.insertActivityLogs(logs)
    suspend fun deleteActivityLog(log: AppActivityLog) = admin.deleteActivityLog(log)
    suspend fun deleteAllActivityLogs() = admin.deleteAllActivityLogs()

    // Bulk Delete For Restore Cleanup
    suspend fun deleteAllCourses() = courses.deleteAllCourses()
    suspend fun deleteAllAttendance() = attendance.deleteAllAttendance()
    suspend fun deleteAllStudents() = students.deleteAllStudents()
    suspend fun deleteAllStudentAttendance() = attendance.deleteAllStudentAttendance()
    suspend fun deleteAllDailyNotes() = attendance.deleteAllDailyNotes()
    suspend fun deleteAllGradeConfigs() = grading.deleteAllGradeConfigs()
    suspend fun deleteAllGrades() = grading.deleteAllGrades()
    suspend fun deleteAllSubjects() = courses.deleteAllSubjects()
    suspend fun deleteAllCourseSubjects() = courses.deleteAllCourseSubjects()
    suspend fun deleteAllLessonTopics() = attendance.deleteAllLessonTopics()
    suspend fun deleteAllLessonSessionTopics() = attendance.deleteAllLessonSessionTopics()
    suspend fun deleteAllAssignmentTemplates() = grading.deleteAllAssignmentTemplates()
    suspend fun deleteAllAssignmentSubmissions() = grading.deleteAllAssignmentSubmissions()
    suspend fun deleteAllSubjectReferences() = courses.deleteAllSubjectReferences()
    suspend fun deleteAllOfficialHolidays() = officialHolidays.deleteAllHolidays()
}
