package com.example.ui.screens
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.AppActivityLog
import com.example.data.entity.Course
import com.example.ui.components.AppHeader
import com.example.ui.components.CourseHubCard
import com.example.ui.components.DawamiBottomNavigationBar
import com.example.ui.components.DawamiLogo
import com.example.ui.components.SmartRescueBanner
import com.example.ui.theme.DawamiGold
import com.example.ui.theme.DawamiNavy
import com.example.ui.theme.DawamiTeal
import com.example.ui.viewmodel.AttendanceViewModel
import com.example.ui.viewmodel.CourseViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.ui.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------- DAILY TASK ITEM (عنصر قائمة المهام والمتابعة اليومية) ----------------
@Composable
private fun DailyTaskItem(
    title: String,
    subtitle: String,
    isCompleted: Boolean,
    onToggle: () -> Unit,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    val checkColor by animateColorAsState(
        targetValue = if (isCompleted) Color(0xFF10B981) else Color(0xFF94A3B8),
        label = "task_check_color"
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .then(
                if (onAction != null) {
                    Modifier.clickable { onAction() }
                } else {
                    Modifier.clickable { onToggle() }
                }
            ),
        color = if (isCompleted) Color(0xFF10B981).copy(alpha = 0.05f) else Color.Transparent,
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconButton(
                onClick = onToggle,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = if (isCompleted) "مكتمل" else "قيد الانتظار",
                    tint = checkColor,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    textDecoration = if (isCompleted) TextDecoration.LineThrough else TextDecoration.None
                )
                Text(
                    text = subtitle,
                    fontSize = 9.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (actionLabel != null && onAction != null) {
                Button(
                    onClick = onAction,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DawamiNavy.copy(alpha = 0.1f),
                        contentColor = DawamiNavy
                    ),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text(
                        text = actionLabel,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ---------------- QUICK ACTION BUTTON (زر إجراء سريع في لوحة المتابعة الأكاديمية) ----------------
@Composable
private fun DashboardQuickActionButton(
    label: String,
    icon: ImageVector,
    primaryColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier),
        color = primaryColor.copy(alpha = 0.08f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.25f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                color = primaryColor.copy(alpha = 0.15f),
                shape = CircleShape,
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = primaryColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ---------------- SELECTION SCREEN (لوحة المتابعة الأكاديمية التفاعلية) ----------------
@Composable
fun SelectionScreen(
    viewModel: MainViewModel,
    courseViewModel: CourseViewModel? = null,
    studentViewModel: StudentViewModel? = null,
    attendanceViewModel: AttendanceViewModel? = null,
    showMainLayout: Boolean = true
) {
    val loggedInUser by viewModel.loggedInUser.collectAsState()
    val trainerNameConfig by viewModel.trainerNameConfig.collectAsState()
    val effectiveTrainerName = remember(loggedInUser, trainerNameConfig) {
        if (trainerNameConfig.isNotBlank() && trainerNameConfig != "المدرب") trainerNameConfig
        else loggedInUser.ifBlank { "المدرب" }
    }

    val instituteName by viewModel.instituteName.collectAsState()
    val instituteLogoUri by viewModel.instituteLogoUri.collectAsState()
    val dbCourses by (courseViewModel?.allCourses ?: viewModel.dbCourses).collectAsState()
    val dbAllStudents by (studentViewModel?.allStudents ?: viewModel.dbAllStudents).collectAsState()
    val dbAttendance by (attendanceViewModel?.allAttendance ?: viewModel.dbAttendance).collectAsState()
    val dbAllStudentAttendance by (attendanceViewModel?.allStudentAttendance ?: viewModel.dbAllStudentAttendance).collectAsState()
    val dbActivityLogs by viewModel.dbActivityLogs.collectAsState()
    val lastBackupDate by viewModel.lastBackupDate.collectAsState()
    val trainerBaseDirUri by viewModel.trainerBaseDirUri.collectAsState()

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showExitDialog by remember { mutableStateOf(false) }
    var showQuickAttendanceAssistant by remember { mutableStateOf(false) }
    var isQuickBackingUp by remember { mutableStateOf(false) }

    val fullBackupSaveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val jsonString = viewModel.exportBackupAsJson(null)
                    withContext(Dispatchers.Main) {
                        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                            outputStream.write(jsonString.toByteArray(Charsets.UTF_8))
                        }
                        viewModel.recordBackupSuccess()
                        Toast.makeText(context, "تم حفظ النسخة الاحتياطية الشاملة بنجاح! 💾✅", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "فشل تصدير الملف: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
                isQuickBackingUp = false
            }
        } else {
            isQuickBackingUp = false
        }
    }

    fun executeQuickFullBackup() {
        if (isQuickBackingUp) return
        isQuickBackingUp = true
        if (trainerBaseDirUri.isNotEmpty()) {
            coroutineScope.launch(Dispatchers.IO) {
                val success = viewModel.createBackupInSubfolder(context, null)
                withContext(Dispatchers.Main) {
                    if (success) {
                        Toast.makeText(context, "تم حفظ نسخة احتياطية شاملة لكافة البيانات تلقائياً في مجلد Backups! 💾✅", Toast.LENGTH_LONG).show()
                        isQuickBackingUp = false
                    } else {
                        val suggestedFileName = viewModel.generateBackupFileName(null, true)
                        fullBackupSaveLauncher.launch(suggestedFileName)
                    }
                }
            }
        } else {
            val suggestedFileName = viewModel.generateBackupFileName(null, true)
            fullBackupSaveLauncher.launch(suggestedFileName)
        }
    }

    // Daily Tasks Local State (Persisted per day)
    val todayDateStr = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }
    val todayDateFormatted = remember {
        val sdf = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar"))
        sdf.format(Date())
    }

    val activeCourses = remember(dbCourses) { dbCourses.filter { !it.isCompleted } }
    val activeCoursesCount = remember(activeCourses) { activeCourses.size }
    val completedCoursesCount = remember(dbCourses) { dbCourses.count { it.isCompleted } }

    val activeStudentsCount = remember(dbAllStudents, dbCourses) {
        dbAllStudents.count { s ->
            val st = s.status?.trim().orEmpty()
            val sCourseName = s.courseName?.trim().orEmpty()
            val isSuspendedOrWithdrawn = st.contains("توقيف") || st.contains("موقف") || st.contains("منسحب")
            val isExplicitlyCompleted = st.contains("منتهي") || st.contains("خريج") || st.contains("متخرج")
            val course = dbCourses.find { c ->
                val cName = c.name?.trim().orEmpty()
                c.id == s.courseId || (s.courseId <= 0 && cName.isNotEmpty() && cName.equals(sCourseName, ignoreCase = true))
            }
            val isCourseCompleted = course?.isCompleted == true

            !isSuspendedOrWithdrawn && !isExplicitlyCompleted && !isCourseCompleted
        }
    }
    val suspendedStudentsCount = remember(dbAllStudents) {
        dbAllStudents.count { s ->
            val st = s.status?.trim().orEmpty()
            st.contains("توقيف") || st.contains("موقف")
        }
    }
    val withdrawnStudentsCount = remember(dbAllStudents) {
        dbAllStudents.count { s ->
            val st = s.status?.trim().orEmpty()
            st.contains("منسحب")
        }
    }
    val completedStudentsCount = remember(dbAllStudents, dbCourses) {
        dbAllStudents.count { s ->
            val st = s.status?.trim().orEmpty()
            val sCourseName = s.courseName?.trim().orEmpty()
            val isSuspendedOrWithdrawn = st.contains("توقيف") || st.contains("موقف") || st.contains("منسحب")
            val isExplicitlyCompleted = st.contains("منتهي") || st.contains("خريج") || st.contains("متخرج")
            val course = dbCourses.find { c ->
                val cName = c.name?.trim().orEmpty()
                c.id == s.courseId || (s.courseId <= 0 && cName.isNotEmpty() && cName.equals(sCourseName, ignoreCase = true))
            }
            val isCourseCompleted = course?.isCompleted == true

            isExplicitlyCompleted || (isCourseCompleted && !isSuspendedOrWithdrawn)
        }
    }

    // Determine current / upcoming course session safely from existing active courses
    val currentCourse: Course? = remember(activeCourses) {
        if (activeCourses.isEmpty()) return@remember null
        val nowTimeStr = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        // Try finding a course currently in session
        val ongoing = activeCourses.firstOrNull { c ->
            c.startTime.isNotBlank() && c.endTime.isNotBlank() &&
            c.startTime <= nowTimeStr && c.endTime >= nowTimeStr
        }
        if (ongoing != null) return@remember ongoing
        // Try next upcoming course today
        val upcoming = activeCourses.filter { c ->
            c.startTime.isNotBlank() && c.startTime > nowTimeStr
        }.minByOrNull { it.startTime }
        if (upcoming != null) return@remember upcoming
        // Otherwise the first active course
        activeCourses.firstOrNull()
    }

    val sharedPrefs = remember {
        context.getSharedPreferences("dawami_prefs", android.content.Context.MODE_PRIVATE)
    }
    var checkedTasks by remember {
        mutableStateOf(sharedPrefs.getStringSet("daily_tasks_$todayDateStr", emptySet()) ?: emptySet())
    }

    fun toggleTask(taskId: String) {
        val newSet = if (checkedTasks.contains(taskId)) checkedTasks - taskId else checkedTasks + taskId
        checkedTasks = newSet
        sharedPrefs.edit().putStringSet("daily_tasks_$todayDateStr", newSet).apply()
    }

    androidx.activity.compose.BackHandler {
        showExitDialog = true
    }

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = {
                Text(
                    text = "تأكيد الخروج 🚪",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = DawamiNavy
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في إغلاق تطبيق دوامي؟",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        (context as? android.app.Activity)?.finish()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("نعم، خروج", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showExitDialog = false }
                ) {
                    Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val notifications by viewModel.inAppNotifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    LaunchedEffect(Unit) {
        viewModel.triggerPendingActionsPopupIfNeeded()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                AppHeader(
                    title = "لوحة المتابعة الذكية",
                    username = loggedInUser,
                    onHomeClick = { viewModel.navigateTo(Screen.Selection) },
                    isDark = isDarkTheme,
                    onToggleTheme = { viewModel.toggleTheme() },
                    unreadNotificationCount = unreadCount,
                    onNotificationClick = { viewModel.openNotificationCenter() },
                    isMainScreen = true,
                    logoUri = instituteLogoUri
                )
            },
            bottomBar = {
                DawamiBottomNavigationBar(viewModel = viewModel)
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth(0.96f)
                        .padding(horizontal = 4.dp, vertical = 4.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // 1. SMART RESCUE BAR BANNER
                    SmartRescueBanner(viewModel = viewModel, isDark = isDarkTheme)

                    // 2. HEADER CARD (اسم المعهد + اسم المدرب + التاريخ اليومي + الإعدادات السريعة)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.12f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            DawamiNavy.copy(alpha = 0.06f),
                                            Color.Transparent
                                        )
                                    )
                                )
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier.size(44.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (instituteLogoUri.isNotEmpty()) {
                                            coil.compose.AsyncImage(
                                                model = instituteLogoUri,
                                                contentDescription = "شعار المعهد",
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(RoundedCornerShape(8.dp)),
                                                contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                                                error = painterResource(id = com.example.R.drawable.app_icon_new_1789091045526)
                                            )
                                        } else {
                                            DawamiLogo(size = 40.dp)
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = instituteName.ifBlank { "معهد دوامي للتدريب" },
                                            color = DawamiNavy,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "المدرب: $effectiveTrainerName 👤",
                                            color = DawamiTeal,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.clickable { viewModel.navigateTo(Screen.TrainerProfile) }
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    // Trainer Profile Icon
                                    IconButton(
                                        onClick = { viewModel.navigateTo(Screen.TrainerProfile) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AccountCircle,
                                            contentDescription = "الملف الشخصي للمدرب",
                                            tint = DawamiTeal,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }

                                    // Quick Settings Icon
                                    IconButton(
                                        onClick = { viewModel.navigateTo(Screen.InstituteSettings) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Settings,
                                            contentDescription = "إعدادات المعهد",
                                            tint = DawamiNavy,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }

                            // Date Badge
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CalendarToday,
                                            contentDescription = null,
                                            tint = DawamiTeal,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Text(
                                            text = todayDateFormatted,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Text(
                                        text = "لوحة المتابعة اليومية ⚡",
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiNavy
                                    )
                                }
                            }
                        }
                    }

                    // 3. LIVE ACADEMIC STATS (الإحصائيات الأكاديمية الحية والشاملة)
                    var isStatsExpanded by remember { mutableStateOf(false) }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.12f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp)
                                .animateContentSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "📊 مؤشرات وإحصائيات المعهد",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiNavy
                                )
                                Text(
                                    text = if (isStatsExpanded) "إخفاء التفاصيل" else "عرض التفاصيل",
                                    fontSize = 9.5.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { isStatsExpanded = !isStatsExpanded }
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // 1. Courses Card
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { isStatsExpanded = !isStatsExpanded },
                                    color = DawamiNavy.copy(alpha = 0.08f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(Icons.Default.School, contentDescription = null, tint = DawamiNavy, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("$activeCoursesCount نشطة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                        }
                                        Text(
                                            text = "من ${dbCourses.size} كلي",
                                            fontSize = 8.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                // 2. Students Card
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { isStatsExpanded = !isStatsExpanded },
                                    color = DawamiTeal.copy(alpha = 0.08f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(Icons.Default.People, contentDescription = null, tint = DawamiTeal, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("$activeStudentsCount نشط", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DawamiTeal)
                                        }
                                        Text(
                                            text = "من ${dbAllStudents.size} طالب",
                                            fontSize = 8.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                // 3. Suspended Students Card
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { isStatsExpanded = !isStatsExpanded },
                                    color = Color(0xFFFFF3E0),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Text("🟠 الموقفين", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                                        Text(
                                            text = "$suspendedStudentsCount طالب",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFFE65100)
                                        )
                                    }
                                }
                            }

                            // Expanded Breakdown Panel
                            if (isStatsExpanded) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp)),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "تفاصيل وحالات الطلاب الإجمالية:",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                color = Color(0xFFE8F5E9),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(4.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text("🟢 نشط", fontSize = 8.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                                    Text("$activeStudentsCount", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                                                }
                                            }

                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                color = Color(0xFFFFF3E0),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(4.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text("🟠 موقف", fontSize = 8.sp, color = Color(0xFFE65100), fontWeight = FontWeight.Bold)
                                                    Text("$suspendedStudentsCount", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                                                }
                                            }

                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                color = Color(0xFFFFEBEE),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(4.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text("🔴 منسحب", fontSize = 8.sp, color = Color(0xFFC62828), fontWeight = FontWeight.Bold)
                                                    Text("$withdrawnStudentsCount", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB71C1C))
                                                }
                                            }

                                            Surface(
                                                modifier = Modifier.weight(1f),
                                                color = Color(0xFFE3F2FD),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(4.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text("🎓 منتهي", fontSize = 8.sp, color = Color(0xFF1565C0), fontWeight = FontWeight.Bold)
                                                    Text("$completedStudentsCount", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0D47A1))
                                                }
                                            }
                                        }

                                        Text(
                                            text = "الدورات: $activeCoursesCount نشطة • $completedCoursesCount مكتملة • إجمالي ${dbCourses.size} دورة",
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 4. LIVE DAILY ACTIVITY & ATTENDANCE DASHBOARD (موجز النشاط اليومي الاحترافي)
                    val todayAttendanceRecords = remember(dbAllStudentAttendance, todayDateStr) {
                        dbAllStudentAttendance.filter { it.date?.trim().orEmpty() == todayDateStr }
                    }
                    val todayPresentCount = remember(todayAttendanceRecords) {
                        todayAttendanceRecords.count {
                            val st = it.status?.trim().orEmpty()
                            st == "حضور" || st == "حاضر" || st.contains("حضور") || st.contains("حاضر")
                        }
                    }
                    val todayAbsentCount = remember(todayAttendanceRecords) {
                        todayAttendanceRecords.count {
                            val st = it.status?.trim().orEmpty()
                            st == "غياب" || st == "غائب" || st.contains("غياب") || st.contains("غائب")
                        }
                    }
                    val todayExcusedCount = remember(todayAttendanceRecords) {
                        todayAttendanceRecords.count {
                            val st = it.status?.trim().orEmpty()
                            st == "مستأذن" || st == "استئذان" || st == "إجازة" || st == "اجازة" || st == "متأخر" ||
                            st.contains("إجازة") || st.contains("اجازة") || st.contains("مستأذن") || st.contains("استئذان") || st.contains("تأخير") || st.contains("متأخر")
                        }
                    }
                    val todayTotalRecorded = todayAttendanceRecords.count {
                        val st = it.status?.trim().orEmpty()
                        st.isNotEmpty() && st != "لم يسجل"
                    }.let { if (it > 0) it else todayAttendanceRecords.size }

                    val todayAttendancePercentage = remember(todayTotalRecorded, todayPresentCount) {
                        if (todayTotalRecorded > 0) {
                            val raw = (todayPresentCount.toFloat() / todayTotalRecorded.toFloat()) * 100f
                            if (raw.isNaN() || raw.isInfinite()) 0 else raw.toInt().coerceIn(0, 100)
                        } else 0
                    }
                    val todayCoursesWithAttendanceCount = remember(dbCourses, dbAllStudentAttendance, todayDateStr) {
                        dbCourses.count { course ->
                            !course.isCompleted && dbAllStudentAttendance.any { att ->
                                att.courseId == course.id && att.date?.trim().orEmpty() == todayDateStr
                            }
                        }
                    }

                    val isAllCoursesRecorded = activeCoursesCount > 0 && todayCoursesWithAttendanceCount >= activeCoursesCount

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.12f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Header & Progress Tag
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Analytics,
                                        contentDescription = null,
                                        tint = DawamiNavy,
                                        modifier = Modifier.size(17.dp)
                                    )
                                    Text(
                                        text = "موجز النشاط اليومي",
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiNavy
                                    )
                                }
                                Surface(
                                    color = when {
                                        todayTotalRecorded == 0 -> Color.Gray.copy(alpha = 0.12f)
                                        todayAttendancePercentage >= 90 -> Color(0xFF10B981).copy(alpha = 0.15f)
                                        todayAttendancePercentage >= 75 -> Color(0xFFF59E0B).copy(alpha = 0.15f)
                                        else -> Color(0xFFEF4444).copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (todayTotalRecorded > 0) "نسبة الحضور: $todayAttendancePercentage%" else "لم يرصد اليوم",
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when {
                                            todayTotalRecorded == 0 -> MaterialTheme.colorScheme.onSurfaceVariant
                                            todayAttendancePercentage >= 90 -> Color(0xFF10B981)
                                            todayAttendancePercentage >= 75 -> Color(0xFFD97706)
                                            else -> Color(0xFFEF4444)
                                        },
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            // Linear Progress Indicator
                            if (todayTotalRecorded > 0) {
                                LinearProgressIndicator(
                                    progress = {
                                        val p = todayAttendancePercentage.toFloat() / 100f
                                        if (p.isNaN() || p.isInfinite()) 0f else p.coerceIn(0f, 1f)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(5.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = when {
                                        todayAttendancePercentage >= 90 -> Color(0xFF10B981)
                                        todayAttendancePercentage >= 75 -> DawamiTeal
                                        else -> Color(0xFFEF4444)
                                    },
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }

                            // 2x2 Activity Metrics Cards
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // 1. Courses Covered
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp)),
                                    color = DawamiNavy.copy(alpha = 0.06f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Text("🏫 رصد الدورات", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DawamiNavy)
                                        Text(
                                            text = "$todayCoursesWithAttendanceCount من $activeCoursesCount دورة",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = DawamiNavy
                                        )
                                    }
                                }

                                // 2. Attendance Status
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp)),
                                    color = Color(0xFFE8F5E9),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Text("✅ حضور اليوم", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                                        Text(
                                            text = "$todayPresentCount حاضر",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFF1B5E20)
                                        )
                                    }
                                }

                                // 3. Absences
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp)),
                                    color = Color(0xFFFFEBEE),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Text("🔴 غياب اليوم", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                                        Text(
                                            text = "$todayAbsentCount غائب",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFFB71C1C)
                                        )
                                    }
                                }

                                // 4. Excused / Late
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp)),
                                    color = Color(0xFFFFF3E0),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Text("🟡 استئذان/تأخير", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                                        Text(
                                            text = "$todayExcusedCount طالب",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFFE65100)
                                        )
                                    }
                                }
                            }

                            // Smart Insights Bar
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp)),
                                color = when {
                                    isAllCoursesRecorded -> Color(0xFFECFDF5)
                                    todayTotalRecorded == 0 -> Color(0xFFFEF3C7)
                                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = when {
                                            isAllCoursesRecorded -> "🟢 ممتاز! اكتمل رصد وتغطية كافة دورات اليوم بنجاح."
                                            todayTotalRecorded == 0 -> "⏳ لم يبدأ رصد حضور وغياب اليوم بعد."
                                            else -> "📊 تم رصد $todayCoursesWithAttendanceCount دورة من أصل $activeCoursesCount دورات نشطة."
                                        },
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = when {
                                            isAllCoursesRecorded -> Color(0xFF065F46)
                                            todayTotalRecorded == 0 -> Color(0xFF92400E)
                                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    if (!isAllCoursesRecorded) {
                                        Text(
                                            text = "لم يكتمل ⚠️",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 5. CURRENT / UPCOMING COURSE SESSION CARD (مركز الدورة التدريبية الحالية)
                    if (currentCourse != null) {
                        val currentCourseEnrolledCount = remember(currentCourse.id, dbAllStudents) {
                            dbAllStudents.count { s ->
                                val st = s.status?.trim().orEmpty()
                                val notWithdrawn = !st.contains("منسحب")
                                (s.courseId == currentCourse.id || s.courseName?.trim().equals(currentCourse.name.trim(), ignoreCase = true)) && notWithdrawn
                            }
                        }
                        CourseHubCard(
                            course = currentCourse,
                            studentCount = currentCourseEnrolledCount,
                            viewModel = viewModel,
                            isInitiallyExpanded = false
                        )
                    } else {
                        // Card when there are no active courses
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { viewModel.navigateTo(Screen.Courses) },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EventBusy,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(24.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "لا توجد دورات تدريبية نشطة حالياً",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "اضغط هنا لإضافة دورة جديدة أو تفعيل الدورات المكتملة",
                                        fontSize = 9.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowForwardIos,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }

                    // 6. QUICK ACADEMIC ACTIONS (الإجراءات السريعة الخمسة + الرصد السريع)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.12f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "⚡ الإجراءات والعمليات السريعة",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DawamiNavy
                                )
                                Text(
                                    text = "وصول مباشر",
                                    fontSize = 9.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // 5 Main Academic Action Buttons (Row)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // 1. Quick Attendance (فتح الرصد أو المساعد)
                                DashboardQuickActionButton(
                                    label = "الرصد",
                                    icon = Icons.Default.HowToReg,
                                    primaryColor = Color(0xFFF59E0B),
                                    onClick = { viewModel.openQuickAttendanceAssistant() },
                                    modifier = Modifier.weight(1f),
                                    testTag = "quick_action_attendance"
                                )

                                // 2. Add Student
                                DashboardQuickActionButton(
                                    label = "إضافة طالب",
                                    icon = Icons.Default.PersonAdd,
                                    primaryColor = DawamiNavy,
                                    onClick = { viewModel.navigateTo(Screen.Students) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "quick_action_add_student"
                                )

                                // 3. Grades
                                DashboardQuickActionButton(
                                    label = "الدرجات",
                                    icon = Icons.Default.Grading,
                                    primaryColor = Color(0xFF8B5CF6),
                                    onClick = { viewModel.navigateTo(Screen.Grades) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "quick_action_grades"
                                )

                                // 4. Lesson Prep
                                DashboardQuickActionButton(
                                    label = "التحضير",
                                    icon = Icons.Default.EditCalendar,
                                    primaryColor = DawamiTeal,
                                    onClick = { viewModel.navigateTo(Screen.LessonPreparation) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "quick_action_prep"
                                )

                                // 5. Reports
                                DashboardQuickActionButton(
                                    label = "التقارير",
                                    icon = Icons.Default.Assessment,
                                    primaryColor = Color(0xFF10B981),
                                    onClick = { viewModel.navigateTo(Screen.Reports) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "quick_action_reports"
                                )
                            }

                            // PROMINENT QUICK ATTENDANCE CARD (حفظ الكرت الأصلي ذو التفاعل الفوري)
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        viewModel.openQuickAttendanceAssistant()
                                    }
                                    .testTag("quick_attendance_card"),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFFFFBEB)
                                ),
                                border = BorderStroke(
                                    1.dp,
                                    if (isDarkTheme) DawamiGold.copy(alpha = 0.6f) else Color(0xFFF59E0B)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.horizontalGradient(
                                                colors = if (isDarkTheme) listOf(
                                                    Color(0xFF78350F).copy(alpha = 0.35f),
                                                    Color.Transparent
                                                ) else listOf(
                                                    Color(0xFFFEF3C7),
                                                    Color(0xFFFFFBEB)
                                                )
                                            )
                                        )
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        color = Color(0xFFF59E0B),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.size(36.dp),
                                        shadowElevation = 1.dp
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.Bolt,
                                                contentDescription = "الرصد السريع",
                                                tint = Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = "⚡ الرصد السريع الفوري",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isDarkTheme) DawamiGold else Color(0xFF92400E)
                                            )
                                            Surface(
                                                color = Color(0xFFEF4444),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = "فوري",
                                                    fontSize = 7.5.sp,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "رصد حضور وغياب الطلاب والمدرب بلمسة واحدة",
                                            fontSize = 9.sp,
                                            color = if (isDarkTheme) Color(0xFFCBD5E1) else Color(0xFF78350F),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Button(
                                        onClick = { viewModel.openQuickAttendanceAssistant() },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier
                                            .height(30.dp)
                                            .testTag("quick_attendance_button")
                                    ) {
                                        Text(
                                            text = "بدء الرصد ⚡",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 7. ACTIONABLE ALERTS & RECENT ACTIVITY (التنبيهات الإجرائية وسجل آخر العمليات)
                    val unreadNotifications = remember(notifications) {
                        notifications.filter { !it.isRead }.take(3)
                    }
                    val recentLogs = remember(dbActivityLogs) {
                        dbActivityLogs.sortedByDescending { it.timestamp }.take(4)
                    }

                    // Show Notifications / Alerts Card if there are unread notifications or important alerts
                    if (unreadNotifications.isNotEmpty() || todayAbsentCount > 0 || todayTotalRecorded == 0) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.3f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.NotificationsActive,
                                            contentDescription = null,
                                            tint = Color(0xFFF59E0B),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = "تنبيهات المتابعة الأكاديمية",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF92400E)
                                        )
                                    }

                                    if (unreadNotifications.isNotEmpty()) {
                                        Text(
                                            text = "مركز الإشعارات (${unreadNotifications.size})",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy,
                                            modifier = Modifier.clickable { viewModel.openNotificationCenter() }
                                        )
                                    }
                                }

                                if (todayTotalRecorded == 0 && activeCoursesCount > 0) {
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        color = Color(0xFFFFFBEB),
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(0.5.dp, Color(0xFFFDE68A))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "⚠️ لم يتم رصد أي دورة اليوم بعد. يرجى البدء بالرصد.",
                                                fontSize = 9.5.sp,
                                                color = Color(0xFF92400E),
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Text(
                                                text = "رصد الآن",
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFD97706),
                                                modifier = Modifier.clickable { viewModel.openQuickAttendanceAssistant() }
                                            )
                                        }
                                    }
                                }

                                if (todayAbsentCount > 0) {
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        color = Color(0xFFFEF2F2),
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(0.5.dp, Color(0xFFFECACA))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "🔴 تم تسجيل $todayAbsentCount حالة غياب اليوم. يمكنك متابعة السجل.",
                                                fontSize = 9.5.sp,
                                                color = Color(0xFF991B1B),
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Text(
                                                text = "عرض السجل",
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFDC2626),
                                                modifier = Modifier.clickable { viewModel.navigateTo(Screen.StudentAttendance) }
                                            )
                                        }
                                    }
                                }

                                unreadNotifications.forEach { n ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 5.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Info,
                                                contentDescription = null,
                                                tint = DawamiNavy,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Text(
                                                text = n.title.ifBlank { n.message },
                                                fontSize = 9.5.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Recent Activity Log Card (سجل أحدث العمليات من dbActivityLogs الحقيقية)
                    if (recentLogs.isNotEmpty()) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, DawamiNavy.copy(alpha = 0.12f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.History,
                                            contentDescription = null,
                                            tint = DawamiNavy,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Text(
                                            text = "أحدث العمليات والأنشطة",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DawamiNavy
                                        )
                                    }

                                    Text(
                                        text = "عرض الكل",
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DawamiTeal,
                                        modifier = Modifier.clickable { viewModel.navigateTo(Screen.ActivityLogs) }
                                    )
                                }

                                recentLogs.forEach { log ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                val logIcon = when (log.category.uppercase()) {
                                                    "ATTENDANCE" -> Icons.Default.HowToReg
                                                    "GRADES" -> Icons.Default.Grading
                                                    "COURSES" -> Icons.Default.School
                                                    "STUDENTS" -> Icons.Default.Person
                                                    "FINANCIAL" -> Icons.Default.AccountBalanceWallet
                                                    else -> Icons.Default.CheckCircle
                                                }
                                                val logTint = when (log.category.uppercase()) {
                                                    "ATTENDANCE" -> Color(0xFFF59E0B)
                                                    "GRADES" -> Color(0xFF8B5CF6)
                                                    "COURSES" -> DawamiNavy
                                                    "STUDENTS" -> DawamiTeal
                                                    "FINANCIAL" -> Color(0xFF10B981)
                                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                                }

                                                Icon(
                                                    imageVector = logIcon,
                                                    contentDescription = null,
                                                    tint = logTint,
                                                    modifier = Modifier.size(14.dp)
                                                )

                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = log.title.ifBlank { log.description },
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = MaterialTheme.colorScheme.onSurface,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    if (log.description.isNotBlank() && log.title.isNotBlank()) {
                                                        Text(
                                                            text = log.description,
                                                            fontSize = 8.5.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                    }
                                                }
                                            }

                                            if (log.timeStr.isNotBlank()) {
                                                Text(
                                                    text = log.timeStr,
                                                    fontSize = 8.5.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 8. LAST BACKUP STATUS HINT & QUICK BACKUP (شريط الأمان والنسخ الاحتياطي السريع)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                viewModel.navigateTo(Screen.BackupRestore)
                            }
                            .testTag("last_backup_hint_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (lastBackupDate.isNotBlank()) {
                                if (isDarkTheme) DawamiTeal.copy(alpha = 0.4f) else Color(0xFFCBD5E1)
                            } else {
                                Color(0xFFF59E0B).copy(alpha = 0.4f)
                            }
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                color = if (lastBackupDate.isNotBlank()) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFFF59E0B).copy(alpha = 0.15f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (lastBackupDate.isNotBlank()) Icons.Default.CloudDone else Icons.Default.Backup,
                                        contentDescription = "النسخ الاحتياطي",
                                        tint = if (lastBackupDate.isNotBlank()) Color(0xFF10B981) else Color(0xFFF59E0B),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                if (lastBackupDate.isNotBlank()) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = "آخر نسخ احتياطي:",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = lastBackupDate,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = DawamiTeal
                                        )
                                    }
                                    Text(
                                        text = "البيانات مؤمنة • نسخة شاملة لكافة البيانات 💾",
                                        fontSize = 9.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                } else {
                                    Text(
                                        text = "لم يتم إنشاء نسخة احتياطية بعد ⚠️",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFF59E0B)
                                    )
                                    Text(
                                        text = "اضغط زر الحفظ الآن لعمل نسخة شاملة وتأمين بياناتك 💾",
                                        fontSize = 9.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Quick Full Backup Button (حفظ نسخة شاملة فوراً)
                            Button(
                                onClick = {
                                    executeQuickFullBackup()
                                },
                                enabled = !isQuickBackingUp,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF10B981),
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("quick_full_backup_button")
                            ) {
                                if (isQuickBackingUp) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(14.dp),
                                        strokeWidth = 2.dp,
                                        color = Color.White
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Save,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "حفظ نسخة الآن",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
        }
    }

    if (showQuickAttendanceAssistant) {
        QuickAttendanceAssistantDialog(
            viewModel = viewModel,
            courseViewModel = courseViewModel,
            attendanceViewModel = attendanceViewModel,
            onDismiss = { showQuickAttendanceAssistant = false }
        )
    }
}
