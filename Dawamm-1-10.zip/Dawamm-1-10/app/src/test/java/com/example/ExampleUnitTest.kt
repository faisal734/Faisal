package com.example

import com.example.data.entity.Attendance
import com.example.data.entity.Course
import com.example.data.entity.CourseSubjectCrossRef
import com.example.data.entity.CourseSubjectStat
import com.example.data.entity.StudentAttendance
import com.example.data.entity.Subject
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

  private fun calculateTaughtDays(
      courseId: Int,
      subjectName: String,
      attendanceList: List<Attendance>
  ): Int {
      val subAttendance = attendanceList.filter {
          it.courseId == courseId &&
          it.subjectName.trim().equals(subjectName.trim(), ignoreCase = true)
      }
      val distinctDates = subAttendance
          .map { it.date.trim() }
          .filter { it.isNotBlank() }
          .distinct()
      return distinctDates.size
  }

  @Test
  fun test1_fiveDistinctDates_returnsFiveDays() {
      val attendanceList = listOf(
          Attendance(id = 1, courseId = 1, courseName = "دورة الحاسب", dayOfWeek = "الأحد", date = "2026-09-01", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          Attendance(id = 2, courseId = 1, courseName = "دورة الحاسب", dayOfWeek = "الإثنين", date = "2026-09-02", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          Attendance(id = 3, courseId = 1, courseName = "دورة الحاسب", dayOfWeek = "الثلاثاء", date = "2026-09-03", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          Attendance(id = 4, courseId = 1, courseName = "دورة الحاسب", dayOfWeek = "الأربعاء", date = "2026-09-04", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          Attendance(id = 5, courseId = 1, courseName = "دورة الحاسب", dayOfWeek = "الخميس", date = "2026-09-05", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل")
      )
      val days = calculateTaughtDays(1, "إكسل", attendanceList)
      assertEquals(5, days)
  }

  @Test
  fun test2_duplicateDate_countedOnceOnly() {
      val attendanceList = listOf(
          Attendance(id = 1, courseId = 1, courseName = "دورة الحاسب", dayOfWeek = "الأحد", date = "2026-09-13", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          Attendance(id = 2, courseId = 1, courseName = "دورة الحاسب", dayOfWeek = "الإثنين", date = "2026-09-14", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          Attendance(id = 3, courseId = 1, courseName = "دورة الحاسب", dayOfWeek = "الثلاثاء", date = "2026-09-15", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          Attendance(id = 4, courseId = 1, courseName = "دورة الحاسب", dayOfWeek = "الثلاثاء", date = "2026-09-15", actualCheckIn = "10:00", actualCheckOut = "12:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل")
      )
      val days = calculateTaughtDays(1, "إكسل", attendanceList)
      assertEquals(3, days)
  }

  @Test
  fun test3_studentCountOrStudentAttendance_doesNotChangeTaughtDays() {
      val attendanceList = listOf(
          Attendance(id = 1, courseId = 1, courseName = "دورة الحاسب", dayOfWeek = "الأحد", date = "2026-09-13", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل")
      )
      val studentAttendances = listOf(
          StudentAttendance(id = 1, courseId = 1, courseName = "دورة الحاسب", studentId = 101, studentName = "أحمد", dayOfWeek = "الأحد", date = "2026-09-13", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          StudentAttendance(id = 2, courseId = 1, courseName = "دورة الحاسب", studentId = 102, studentName = "محمد", dayOfWeek = "الأحد", date = "2026-09-13", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          StudentAttendance(id = 3, courseId = 1, courseName = "دورة الحاسب", studentId = 103, studentName = "سالم", dayOfWeek = "الأحد", date = "2026-09-14", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل")
      )
      // Taught days must strictly come from attendanceList (teacher only), so 1 day
      val days = calculateTaughtDays(1, "إكسل", attendanceList)
      assertEquals(1, days)
  }

  @Test
  fun test4_courseIndependence_differentCoursesSeparated() {
      val attendanceList = listOf(
          Attendance(id = 1, courseId = 1, courseName = "دورة صباحية", dayOfWeek = "الأحد", date = "2026-09-01", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          Attendance(id = 2, courseId = 1, courseName = "دورة صباحية", dayOfWeek = "الإثنين", date = "2026-09-02", actualCheckIn = "08:00", actualCheckOut = "10:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل"),
          Attendance(id = 3, courseId = 2, courseName = "دورة مسائية", dayOfWeek = "الأحد", date = "2026-09-01", actualCheckIn = "16:00", actualCheckOut = "18:00", checkInDelayMinutes = 0, checkOutDifferenceMinutes = 0, durationHours = 2, durationMinutes = 0, hasAlert = false, alertMessage = "", subjectName = "إكسل")
      )
      val daysCourse1 = calculateTaughtDays(1, "إكسل", attendanceList)
      val daysCourse2 = calculateTaughtDays(2, "إكسل", attendanceList)
      assertEquals(2, daysCourse1)
      assertEquals(1, daysCourse2)
  }
}
